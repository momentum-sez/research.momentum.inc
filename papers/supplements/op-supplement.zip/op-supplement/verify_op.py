#!/usr/bin/env python3
"""Bounded executable verifier for the finite Op profile in op.tex.

This is an executable model, not a production cryptographic implementation.
Its deterministic signature fixtures test authority, scope, revocation, and
binding logic.  Run ``python3 verify_op.py --self-test`` for positive witnesses
and injected negative controls.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import heapq
import json
import sys
import unicodedata
from dataclasses import dataclass
from typing import Any, Callable, Iterable


SCHEMA = "op-bounded-verifier-v1"
INT_MIN = -(2**63)
INT_MAX = 2**63 - 1
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_PROGRAM_BYTES = 1 * 1024 * 1024
MAX_INPUT_BYTES = 1 * 1024 * 1024
MAX_EVIDENCE_BYTES = 4 * 1024 * 1024
MAX_BUNDLE_BYTES = 4 * 1024 * 1024
MAX_INSTRUCTIONS = 4096
MAX_EDGES = 8192
MAX_EVIDENCE = 4096
MAX_DEPTH = 16

TOP_FIELDS = {
    "schema",
    "program",
    "inputs",
    "trust_root",
    "evidence_log",
    "evidence_log_commitment",
    "resume_claim",
    "claimed_bundle",
    "claimed_provider_state",
    "subsequent_graph",
    "residuals",
    "reconciliation",
    "uncertainty",
    "corridor",
    "verdicts",
    "bilateral_commit",
}

FAILURE_CLASSES = {
    "parse",
    "type",
    "authorization",
    "evidence",
    "primitive",
    "resource",
    "trap",
}

PROVIDER_SCOPE_FIELDS = {
    "provider",
    "rail",
    "rulebook",
    "jurisdiction",
    "asset",
    "operation_class",
}

SEVEN_COORDINATES = {
    "authorization",
    "dispatch",
    "provider_phase",
    "finality",
    "reconciliation",
    "subsequent_effects",
    "obstructions",
}

EVIDENCE_PAYLOAD_FIELDS = {
    "LedgerConfirmation": {"operation_key", "ledger", "block_reference"},
    "ProviderOutcome": {
        "scope",
        "operation_key",
        "request_digest",
        "provider_event_id",
        "event_time",
        "phase",
        "quantity",
        "occurrence_key",
        "assertion_id",
    },
    "FinalityWitness": {
        "outcome_digest",
        "provider",
        "rail",
        "rulebook",
        "jurisdiction",
        "asset",
        "evaluation_time",
        "legal_policy_id",
        "policy_version",
        "authority",
    },
    "BeneficiaryReceipt": {
        "operation_key",
        "beneficiary",
        "quantity",
        "received_at",
    },
}

COMMON_EVIDENCE_FIELDS = {
    "type",
    "stream",
    "sequence",
    "evaluation_time",
    "signer",
    "key_id",
    "payload",
    "digest",
    "signature",
}

REVERSAL_KINDS = {"NoStateChange", "Compensate", "Subsequent", "Irreversible"}
SUBSEQUENT_KINDS = {
    "Original",
    "Return",
    "Refund",
    "RailReversal",
    "LegalUnwind",
    "Compensation",
}
PROVIDER_PHASES = {
    "Accepted",
    "Processing",
    "Partial",
    "Succeeded",
    "Failed",
    "Reversed",
}

BSC_MESSAGE_FIELDS = {
    "sequence",
    "from_role",
    "to_role",
    "kind",
    "session_id",
    "operation_key",
    "evaluation_id",
    "prior",
    "body",
    "key_id",
    "digest",
    "signature",
}

BSC_SEQUENCE = (
    ("A", "B", "Begin"),
    ("B", "A", "Lock"),
    ("A", "B", "Lock"),
    ("A", "B", "Verdict"),
    ("B", "A", "Verdict"),
    ("A", "B", "Decision"),
    ("B", "A", "Ack"),
)


class RejectError(Exception):
    def __init__(self, code: str, path: str, detail: str):
        super().__init__(f"{code} at {path}: {detail}")
        self.code = code
        self.path = path
        self.detail = detail


@dataclass(frozen=True)
class VerifyResult:
    accepted: bool
    code: str
    path: str
    detail: str
    bundle_head: str | None
    failure_receipt: dict[str, Any] | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "code": self.code,
            "path": self.path,
            "detail": self.detail,
            "bundle_head": self.bundle_head,
            "failure_receipt": self.failure_receipt,
        }


def reject(code: str, path: str, detail: str) -> None:
    raise RejectError(code, path, detail)


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def digest(domain: str, value: Any) -> str:
    h = hashlib.sha256()
    h.update(domain.encode("ascii"))
    h.update(b"\x00")
    h.update(canonical_bytes(value))
    return h.hexdigest()


def raw_digest(domain: str, value: bytes) -> str:
    h = hashlib.sha256()
    h.update(domain.encode("ascii"))
    h.update(b"\x00")
    h.update(value)
    return h.hexdigest()


def exact_fields(obj: Any, expected: set[str], path: str) -> None:
    if not isinstance(obj, dict):
        reject("TYPE_MISMATCH", path, "expected object")
    actual = set(obj)
    extra = sorted(actual - expected)
    missing = sorted(expected - actual)
    if extra:
        reject("UNKNOWN_FIELD", f"{path}.{extra[0]}", "field is outside the closed schema")
    if missing:
        reject("MISSING_FIELD", f"{path}.{missing[0]}", "required field is absent")


def preflight_depth(raw: bytes) -> None:
    depth = 0
    in_string = False
    escaped = False
    for index, byte in enumerate(raw):
        ch = chr(byte)
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch in "[{":
            depth += 1
            if depth > MAX_DEPTH:
                reject("RESOURCE_BOUND", f"$byte[{index}]", "schema depth exceeds 16")
        elif ch in "]}":
            depth -= 1
            if depth < 0:
                reject("MALFORMED_BYTES", f"$byte[{index}]", "unbalanced delimiter")


def parse_canonical(raw: bytes) -> Any:
    if len(raw) > MAX_TOTAL_BYTES:
        reject("RESOURCE_BOUND", "$", "top-level input exceeds 16 MiB")
    preflight_depth(raw)
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        reject("MALFORMED_BYTES", f"$byte[{exc.start}]", "invalid UTF-8")

    def pairs_hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key, value in pairs:
            if key in out:
                reject("DUPLICATE_KEY", f"$.{key}", "duplicate object key")
            out[key] = value
        return out

    def reject_float(value: str) -> Any:
        reject("MALFORMED_NUMBER", "$", f"floating-point value {value!r} is forbidden")

    def reject_constant(value: str) -> Any:
        reject("MALFORMED_NUMBER", "$", f"numeric constant {value!r} is forbidden")

    try:
        value = json.loads(
            text,
            object_pairs_hook=pairs_hook,
            parse_float=reject_float,
            parse_constant=reject_constant,
        )
    except RejectError:
        raise
    except (json.JSONDecodeError, RecursionError) as exc:
        reject("MALFORMED_BYTES", "$", str(exc))
    if canonical_bytes(value) != raw:
        reject("NONCANONICAL_ENCODING", "$", "canonical round trip changed the bytes")
    return value


def validate_scalar_tree(value: Any, path: str = "$", depth: int = 0) -> None:
    if depth > MAX_DEPTH:
        reject("RESOURCE_BOUND", path, "schema depth exceeds 16")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, int):
        if value < INT_MIN or value > INT_MAX:
            reject("INTEGER_RANGE", path, "integer is outside signed 64-bit range")
        return
    if isinstance(value, float):
        reject("MALFORMED_NUMBER", path, "floating-point values are forbidden")
    if isinstance(value, str):
        if unicodedata.normalize("NFC", value) != value:
            reject("NONNORMALIZED_STRING", path, "string is not Unicode NFC")
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            validate_scalar_tree(item, f"{path}[{index}]", depth + 1)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                reject("TYPE_MISMATCH", path, "object key is not a string")
            validate_scalar_tree(key, f"{path}.<key>", depth + 1)
            validate_scalar_tree(item, f"{path}.{key}", depth + 1)
        return
    reject("TYPE_MISMATCH", path, f"unsupported value type {type(value).__name__}")


def without_fields(value: dict[str, Any], fields: Iterable[str]) -> dict[str, Any]:
    out = copy.deepcopy(value)
    for field in fields:
        out.pop(field, None)
    return out


def normalized_program(program: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(program)
    out.pop("program_digest", None)
    out.pop("request_digest", None)
    for instruction in out.get("instructions", []):
        instruction.pop("request_digest", None)
        instruction.pop("operation_key", None)
    return out


def program_digest(program: dict[str, Any]) -> str:
    return digest("op:program:v1", normalized_program(program))


def request_digest(request: dict[str, Any]) -> str:
    return digest("op:request:v1", request)


def operation_key(inputs: dict[str, Any], p_digest: str) -> str:
    fields = {
        "operation_id": inputs["operation_id"],
        "program_digest": p_digest,
        "step_id": inputs["step_id"],
        "attempt": inputs["attempt"],
    }
    return digest("op:operation-key:v1", fields)


def occurrence_key(payload: dict[str, Any]) -> str:
    fields = {
        "provider": payload["scope"]["provider"],
        "operation_key": payload["operation_key"],
        "provider_event_id": payload["provider_event_id"],
        "event_time": payload["event_time"],
        "phase": payload["phase"],
        "quantity": payload["quantity"],
    }
    return digest("op:provider-occurrence:v1", fields)


def residual_key(parent: str, quantity: int, child_index: int) -> str:
    return digest(
        "op:residual-child:v1",
        {
            "parent_operation_key": parent,
            "label": "residual",
            "quantity": quantity,
            "child_index": child_index,
        },
    )


def evidence_digest(item: dict[str, Any]) -> str:
    return digest("op:evidence:v1", without_fields(item, {"digest", "signature"}))


def fixture_signature(key_material: str, item_digest: str) -> str:
    return digest(
        "op:fixture-signature:v1",
        {"key_material": key_material, "evidence_digest": item_digest},
    )


def seal_evidence(item: dict[str, Any], keys: dict[str, str]) -> None:
    item["digest"] = evidence_digest(item)
    item["signature"] = fixture_signature(keys[item["key_id"]], item["digest"])


def evidence_sort_key(item: dict[str, Any]) -> tuple[int, str, int, str]:
    return (
        item["evaluation_time"],
        item["stream"],
        item["sequence"],
        item["digest"],
    )


def evidence_commitment(evidence: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "count": len(evidence),
        "digest": digest("op:evidence-log:v1", evidence),
    }


def bsc_message_digest(message: dict[str, Any]) -> str:
    return digest("op:bsc-message:v1", without_fields(message, {"digest", "signature"}))


def seal_bsc_message(message: dict[str, Any], keys: dict[str, str]) -> None:
    message["digest"] = bsc_message_digest(message)
    message["signature"] = fixture_signature(keys[message["key_id"]], message["digest"])


def bsc_authorized(role_name: str, key_id: str, trust_root: dict[str, Any]) -> bool:
    return any(
        record.get("designated") is True
        and record.get("signer") == role_name
        and record.get("key_id") == key_id
        and record.get("evidence_type") == "BSCMessage"
        and record.get("valid_from") <= trust_root["evaluation_time"] <= record.get("valid_until")
        for record in trust_root["authorities"]
    )


def extract_blame(
    left: dict[str, Any],
    right: dict[str, Any],
    roles: dict[str, dict[str, str]],
    trust_root: dict[str, Any],
) -> dict[str, Any]:
    for label, message in (("left", left), ("right", right)):
        exact_fields(message, BSC_MESSAGE_FIELDS, f"$.blame.{label}")
        if message["kind"] != "Verdict":
            reject("BSC_BLAME_INPUT", f"$.blame.{label}.kind", "blame extraction requires verdict messages")
        if message["digest"] != bsc_message_digest(message):
            reject("BSC_BLAME_INPUT", f"$.blame.{label}.digest", "verdict digest is invalid")
        role = message["from_role"]
        if role not in roles or message["key_id"] != roles[role]["key_id"]:
            reject("BSC_BLAME_INPUT", f"$.blame.{label}.key_id", "verdict key is not bound to the role")
        key_material = trust_root["keys"].get(message["key_id"])
        if key_material is None or message["signature"] != fixture_signature(key_material, message["digest"]):
            reject("BSC_BLAME_INPUT", f"$.blame.{label}.signature", "verdict signature is invalid")
        if not bsc_authorized(roles[role]["name"], message["key_id"], trust_root):
            reject("BSC_BLAME_INPUT", f"$.blame.{label}.key_id", "role lacks designated signing authority")
    same_index = all(
        left[field] == right[field]
        for field in ("from_role", "session_id", "operation_key", "evaluation_id")
    )
    if not same_index or left["body"] == right["body"]:
        reject("BSC_NO_EQUIVOCATION", "$.blame", "messages are not contradictory verdicts by one role at one session index")
    role = left["from_role"]
    witness = {
        "kind": "BlameWitness",
        "role": role,
        "role_name": roles[role]["name"],
        "session_id": left["session_id"],
        "operation_key": left["operation_key"],
        "evaluation_id": left["evaluation_id"],
        "left_digest": left["digest"],
        "right_digest": right["digest"],
    }
    witness["digest"] = digest("op:bsc-blame:v1", witness)
    return witness


def validate_bilateral_commit(doc: dict[str, Any], expected_operation: str) -> dict[str, Any]:
    bsc = doc["bilateral_commit"]
    roles = bsc["roles"]
    if roles["A"]["name"] == roles["B"]["name"] or roles["A"]["key_id"] == roles["B"]["key_id"]:
        reject("BSC_ARITY", "$.bilateral_commit.roles", "bilateral commit requires two distinct roles and keys")
    if bsc["operation_key"] != expected_operation:
        reject("BSC_INDEX", "$.bilateral_commit.operation_key", "session is bound to another operation")
    if not bsc["session_id"] or not bsc["evaluation_id"]:
        reject("BSC_INDEX", "$.bilateral_commit", "session and evaluation identifiers are required")

    messages = bsc["messages"]
    prior = "0" * 64
    verdicts: dict[str, list[dict[str, Any]]] = {"A": [], "B": []}
    locks: dict[str, str] = {}
    for index, message in enumerate(messages):
        path = f"$.bilateral_commit.messages[{index}]"
        exact_fields(message, BSC_MESSAGE_FIELDS, path)
        if message["sequence"] != index + 1 or message["prior"] != prior:
            reject("BSC_ORDER", path, "session sequence or transcript head is invalid")
        if message["from_role"] not in roles or message["to_role"] not in roles or message["from_role"] == message["to_role"]:
            reject("BSC_ARITY", path, "message must cross the two declared roles")
        if (
            message["session_id"] != bsc["session_id"]
            or message["operation_key"] != bsc["operation_key"]
            or message["evaluation_id"] != bsc["evaluation_id"]
        ):
            reject("BSC_INDEX", path, "message is bound to another session index")
        if message["key_id"] != roles[message["from_role"]]["key_id"]:
            reject("BSC_AUTHORITY", f"{path}.key_id", "sender role and key differ")
        key_material = doc["trust_root"]["keys"].get(message["key_id"])
        if key_material is None:
            reject("BSC_AUTHORITY", f"{path}.key_id", "key is absent from the trust root")
        if message["digest"] != bsc_message_digest(message):
            reject("BSC_DIGEST", f"{path}.digest", "message digest does not match canonical bytes")
        if message["signature"] != fixture_signature(key_material, message["digest"]):
            reject("BSC_SIGNATURE", f"{path}.signature", "message signature fixture does not verify")
        if not bsc_authorized(roles[message["from_role"]]["name"], message["key_id"], doc["trust_root"]):
            reject("BSC_AUTHORITY", f"{path}.key_id", "role has identity but no designated BSC authority")
        for revocation in doc["trust_root"]["revocations"]:
            if revocation["key_id"] == message["key_id"] and revocation["effective_time"] <= doc["trust_root"]["evaluation_time"]:
                reject("BSC_AUTHORITY", f"{path}.key_id", "BSC signing key is revoked")
        body_schemas = {
            "Begin": {"program_digest"},
            "Lock": {"lock_id"},
            "Verdict": {"verdict"},
            "Decision": {"decision"},
            "Ack": {"decision"},
        }
        if message["kind"] not in body_schemas:
            reject("BSC_ORDER", f"{path}.kind", "unknown session message")
        exact_fields(message["body"], body_schemas[message["kind"]], f"{path}.body")
        if message["kind"] == "Begin" and message["body"]["program_digest"] != doc["program"]["program_digest"]:
            reject("BSC_PROGRAM_BINDING", f"{path}.body.program_digest", "session begins against another program")
        if message["kind"] == "Lock":
            locks[message["from_role"]] = message["body"]["lock_id"]
        elif message["kind"] == "Verdict":
            verdicts[message["from_role"]].append(message)
        prior = message["digest"]

    for role, role_verdicts in verdicts.items():
        if len(role_verdicts) > 1:
            first = role_verdicts[0]
            conflicting = next((item for item in role_verdicts[1:] if item["body"] != first["body"]), None)
            if conflicting is not None:
                witness = extract_blame(first, conflicting, roles, doc["trust_root"])
                reject("BSC_EQUIVOCATION", f"$.bilateral_commit.messages.{role}", f"typed blame witness {witness['digest']}")
            reject("BSC_DUPLICATE_VERDICT", f"$.bilateral_commit.messages.{role}", "role signed the same verdict twice")

    if len(messages) != len(BSC_SEQUENCE):
        reject("BSC_ORDER", "$.bilateral_commit.messages", "complete transcript has exactly seven messages")
    for index, (from_role, to_role, kind) in enumerate(BSC_SEQUENCE):
        message = messages[index]
        if (message["from_role"], message["to_role"], message["kind"]) != (from_role, to_role, kind):
            reject("BSC_ORDER", f"$.bilateral_commit.messages[{index}]", "message does not match the projected session type")
    if set(locks) != {"A", "B"} or locks["A"] == locks["B"]:
        reject("BSC_LINEAR_LOCK", "$.bilateral_commit.messages", "each role must contribute one distinct linear lock")
    if any(len(items) != 1 for items in verdicts.values()):
        reject("BSC_VERIFIED_ENTRY", "$.bilateral_commit.messages", "both signed verdicts must be durable before decision")

    decision = messages[5]["body"]["decision"]
    expected_decision = "Commit" if all(items[0]["body"]["verdict"] == "Admit" for items in verdicts.values()) else "Abort"
    if decision != expected_decision:
        reject("BSC_DECISION", "$.bilateral_commit.messages[5].body.decision", "decision is not the deterministic function of both verdicts")
    if messages[6]["body"]["decision"] != decision:
        reject("BSC_ACK_MISMATCH", "$.bilateral_commit.messages[6].body.decision", "acknowledgement changed the decision")

    expected_terminal = "Committed" if decision == "Commit" else "Aborted"
    expected_states = ["Init", "Locked", "Verified", expected_terminal]
    if bsc["states"]["A"] != expected_states or bsc["states"]["B"] != expected_states:
        reject("BSC_VERIFIED_ENTRY", "$.bilateral_commit.states", "both roles must enter Verified before the terminal decision")
    return {"decision": decision, "transcript_head": messages[-1]["digest"]}


def failure_receipt(raw: bytes, error: RejectError) -> dict[str, Any]:
    body = {
        "kind": "FailureReceipt",
        "input_digest": raw_digest("op:verifier-input:v1", raw),
        "code": error.code,
        "path": error.path,
        "detail": error.detail,
    }
    body["receipt_digest"] = digest("op:failure-receipt:v1", body)
    return body


def validate_top_schema(doc: Any) -> None:
    exact_fields(doc, TOP_FIELDS, "$")
    if doc["schema"] != SCHEMA:
        reject("SCHEMA_VERSION", "$.schema", "unsupported verifier schema")

    exact_fields(
        doc["inputs"],
        {"operation_id", "step_id", "attempt", "subjects", "jurisdiction"},
        "$.inputs",
    )
    if not isinstance(doc["inputs"]["subjects"], list) or not doc["inputs"]["subjects"]:
        reject("TYPE_MISMATCH", "$.inputs.subjects", "nonempty subject array required")

    exact_fields(
        doc["program"],
        {
            "entry",
            "instructions",
            "effect_declarations",
            "request",
            "request_digest",
            "program_digest",
            "failure_receipts",
            "idempotency_status",
        },
        "$.program",
    )
    exact_fields(
        doc["program"]["request"],
        {
            "provider",
            "rail",
            "rulebook",
            "jurisdiction",
            "asset",
            "operation_class",
            "source",
            "route",
            "destination",
            "amount",
            "idempotency_key",
            "reversal",
        },
        "$.program.request",
    )
    exact_fields(doc["program"]["request"]["reversal"], {"kind", "operation"}, "$.program.request.reversal")
    if not isinstance(doc["program"]["effect_declarations"], dict):
        reject("TYPE_MISMATCH", "$.program.effect_declarations", "effect declaration table must be an object")

    exact_fields(
        doc["trust_root"],
        {
            "rule_pack_digest",
            "type_registry_digest",
            "corridor_map_digest",
            "evaluation_time",
            "keys",
            "authorities",
            "revocations",
            "provider_scope",
        },
        "$.trust_root",
    )
    exact_fields(doc["trust_root"]["provider_scope"], PROVIDER_SCOPE_FIELDS, "$.trust_root.provider_scope")
    if not isinstance(doc["trust_root"]["keys"], dict):
        reject("TYPE_MISMATCH", "$.trust_root.keys", "key registry must be an object")
    if not isinstance(doc["trust_root"]["authorities"], list):
        reject("TYPE_MISMATCH", "$.trust_root.authorities", "authority registry must be an array")
    if not isinstance(doc["trust_root"]["revocations"], list):
        reject("TYPE_MISMATCH", "$.trust_root.revocations", "revocations must be an array")

    if not isinstance(doc["evidence_log"], list):
        reject("TYPE_MISMATCH", "$.evidence_log", "evidence log must be an array")
    exact_fields(doc["evidence_log_commitment"], {"count", "digest"}, "$.evidence_log_commitment")
    exact_fields(doc["resume_claim"], {"await_id", "evidence_digest"}, "$.resume_claim")
    if not isinstance(doc["claimed_provider_state"], dict) or set(doc["claimed_provider_state"]) != SEVEN_COORDINATES:
        reject("SEVEN_COORDINATE_SCHEMA", "$.claimed_provider_state", "provider state must have exactly the seven named coordinates")

    exact_fields(doc["subsequent_graph"], {"root", "nodes"}, "$.subsequent_graph")
    if not isinstance(doc["subsequent_graph"]["nodes"], list):
        reject("TYPE_MISMATCH", "$.subsequent_graph.nodes", "nodes must be an array")
    if not isinstance(doc["residuals"], list):
        reject("TYPE_MISMATCH", "$.residuals", "residuals must be an array")
    exact_fields(doc["reconciliation"], {"local", "provider", "claimed"}, "$.reconciliation")
    exact_fields(doc["uncertainty"], {"caps", "items"}, "$.uncertainty")
    exact_fields(
        doc["corridor"],
        {
            "source_jurisdiction",
            "receiver_jurisdiction",
            "route_digest",
            "source_pack_digest",
            "receiver_pack_digest",
            "route_consistent",
            "fresh_domains",
        },
        "$.corridor",
    )
    exact_fields(doc["verdicts"], {"source", "receiver"}, "$.verdicts")
    for side in ("source", "receiver"):
        exact_fields(doc["verdicts"][side], {"jurisdiction", "pack_digest", "status"}, f"$.verdicts.{side}")
    exact_fields(
        doc["bilateral_commit"],
        {"session_id", "operation_key", "evaluation_id", "roles", "states", "messages"},
        "$.bilateral_commit",
    )
    exact_fields(doc["bilateral_commit"]["roles"], {"A", "B"}, "$.bilateral_commit.roles")
    exact_fields(doc["bilateral_commit"]["states"], {"A", "B"}, "$.bilateral_commit.states")
    for role in ("A", "B"):
        exact_fields(doc["bilateral_commit"]["roles"][role], {"name", "key_id"}, f"$.bilateral_commit.roles.{role}")
    if not isinstance(doc["bilateral_commit"]["messages"], list):
        reject("TYPE_MISMATCH", "$.bilateral_commit.messages", "session transcript must be an array")


def validate_limits(doc: dict[str, Any]) -> None:
    if len(canonical_bytes(doc["program"])) > MAX_PROGRAM_BYTES:
        reject("RESOURCE_BOUND", "$.program", "program exceeds 1 MiB")
    if len(canonical_bytes(doc["inputs"])) > MAX_INPUT_BYTES:
        reject("RESOURCE_BOUND", "$.inputs", "inputs exceed 1 MiB")
    if len(canonical_bytes(doc["evidence_log"])) > MAX_EVIDENCE_BYTES:
        reject("RESOURCE_BOUND", "$.evidence_log", "evidence exceeds 4 MiB")
    if len(canonical_bytes(doc["claimed_bundle"])) > MAX_BUNDLE_BYTES:
        reject("RESOURCE_BOUND", "$.claimed_bundle", "bundle exceeds 4 MiB")
    if len(doc["program"]["instructions"]) > MAX_INSTRUCTIONS:
        reject("RESOURCE_BOUND", "$.program.instructions", "instruction count exceeds 4096")
    if len(doc["evidence_log"]) > MAX_EVIDENCE:
        reject("RESOURCE_BOUND", "$.evidence_log", "evidence count exceeds 4096")


def instruction_schema(instruction: dict[str, Any], index: int) -> None:
    path = f"$.program.instructions[{index}]"
    if not isinstance(instruction, dict) or "op" not in instruction:
        reject("TYPE_MISMATCH", path, "instruction object with opcode required")
    schemas = {
        "check_sanctions": {"id", "op", "next", "subjects", "jurisdiction", "snapshot_digest", "fresh"},
        "defer_write": {"id", "op", "next", "resource", "effect", "reversal", "subjects", "jurisdiction"},
        "commit": {"id", "op", "next", "consume", "request_digest", "subjects", "jurisdiction"},
        "await_provider": {"id", "op", "next", "expected", "scope", "operation_key", "continuation_resource"},
        "halt": {"id", "op", "next"},
        "direct_write": {"id", "op", "next", "subjects", "jurisdiction"},
    }
    opcode = instruction["op"]
    if opcode not in schemas:
        reject("UNKNOWN_OPCODE", f"{path}.op", str(opcode))
    exact_fields(instruction, schemas[opcode], path)
    if not isinstance(instruction["id"], str) or not instruction["id"]:
        reject("TYPE_MISMATCH", f"{path}.id", "nonempty instruction identifier required")
    if not isinstance(instruction["next"], list):
        reject("TYPE_MISMATCH", f"{path}.next", "successors must be an array")
    if opcode == "defer_write":
        exact_fields(instruction["reversal"], {"kind", "operation"}, f"{path}.reversal")
    if opcode == "await_provider":
        exact_fields(instruction["scope"], PROVIDER_SCOPE_FIELDS, f"{path}.scope")


def graph_and_static_checks(doc: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], list[str], dict[str, set[str]]]:
    program = doc["program"]
    instructions = program["instructions"]
    if not isinstance(instructions, list) or not instructions:
        reject("TYPE_MISMATCH", "$.program.instructions", "nonempty instruction array required")
    nodes: dict[str, dict[str, Any]] = {}
    for index, instruction in enumerate(instructions):
        instruction_schema(instruction, index)
        if instruction["op"] == "await_provider" and instruction["expected"] != "ProviderOutcome":
            reject("UNTYPED_AWAIT", f"$.program.instructions[{index}].expected", "provider awaits accept ProviderOutcome only")
        node_id = instruction["id"]
        if node_id in nodes:
            reject("DUPLICATE_NODE", f"$.program.instructions[{index}].id", node_id)
        nodes[node_id] = instruction
    entry = program["entry"]
    if entry not in nodes:
        reject("MISSING_ENTRY", "$.program.entry", str(entry))

    edge_count = 0
    predecessors = {node_id: set() for node_id in nodes}
    for node_id, instruction in nodes.items():
        edge_count += len(instruction["next"])
        for successor in instruction["next"]:
            if successor not in nodes:
                reject("MISSING_SUCCESSOR", f"$.program.instructions.{node_id}.next", str(successor))
            predecessors[successor].add(node_id)
    if edge_count > MAX_EDGES:
        reject("RESOURCE_BOUND", "$.program.instructions", "edge count exceeds 8192")

    reachable: set[str] = set()
    pending = [entry]
    while pending:
        node_id = pending.pop()
        if node_id in reachable:
            continue
        reachable.add(node_id)
        pending.extend(nodes[node_id]["next"])

    indegree = {node_id: len(predecessors[node_id]) for node_id in nodes}
    ready = [node_id for node_id, degree in indegree.items() if degree == 0]
    heapq.heapify(ready)
    topo: list[str] = []
    while ready:
        node_id = heapq.heappop(ready)
        topo.append(node_id)
        for successor in sorted(nodes[node_id]["next"]):
            indegree[successor] -= 1
            if indegree[successor] == 0:
                heapq.heappush(ready, successor)
    if len(topo) != len(nodes):
        cyclic = sorted(node_id for node_id, degree in indegree.items() if degree > 0)[0]
        reject("GRAPH_CYCLE", f"$.program.instructions.{cyclic}", "control-flow graph is cyclic")

    for node_id, instruction in nodes.items():
        if instruction["op"] in {"commit", "direct_write"} and node_id not in reachable:
            reject("UNREACHABLE_WRITE", f"$.program.instructions.{node_id}", "write is unreachable")
    if any(instruction["op"] == "direct_write" for instruction in nodes.values()):
        reject("DIRECT_WRITE", "$.program.instructions", "durable writes must be deferred requests")

    for node_id, instruction in nodes.items():
        if instruction["op"] == "defer_write":
            reversal = instruction["reversal"]
            if reversal["kind"] not in REVERSAL_KINDS or not reversal["operation"]:
                reject("MISSING_REVERSAL", f"$.program.instructions.{node_id}.reversal", "effect has no valid reversal declaration")
    request_reversal = program["request"]["reversal"]
    if request_reversal["kind"] not in REVERSAL_KINDS or not request_reversal["operation"]:
        reject("MISSING_REVERSAL", "$.program.request.reversal", "request has no valid reversal declaration")
    for node_id, instruction in nodes.items():
        if instruction["op"] == "defer_write" and instruction["reversal"] != request_reversal:
            reject("REVERSAL_MISMATCH", f"$.program.instructions.{node_id}.reversal", "deferred effect and canonical request declare different responses")

    no_state_change = {"kind": "NoStateChange", "operation": "NoStateChange"}
    expected_effects: dict[str, tuple[str, dict[str, str]]] = {
        "proof-bundle": ("ProofEmit", no_state_change),
    }
    effect_name_by_opcode = {
        "check_sanctions": "SanctionsCheck",
        "defer_write": "Write",
        "await_provider": "AwaitProviderOutcome",
    }
    for node_id, instruction in nodes.items():
        if instruction["op"] in effect_name_by_opcode:
            reversal = instruction["reversal"] if instruction["op"] == "defer_write" else no_state_change
            expected_effects[node_id] = (effect_name_by_opcode[instruction["op"]], reversal)
    declarations = program["effect_declarations"]
    missing_effects = sorted(set(expected_effects) - set(declarations))
    extra_effects = sorted(set(declarations) - set(expected_effects))
    if missing_effects:
        reject("MISSING_EFFECT_DECLARATION", f"$.program.effect_declarations.{missing_effects[0]}", "effect has no reversal declaration")
    if extra_effects:
        reject("UNKNOWN_EFFECT_DECLARATION", f"$.program.effect_declarations.{extra_effects[0]}", "declaration has no effect instance")
    for effect_id, (effect_name, reversal) in expected_effects.items():
        declaration = declarations[effect_id]
        exact_fields(declaration, {"effect", "reversal"}, f"$.program.effect_declarations.{effect_id}")
        exact_fields(declaration["reversal"], {"kind", "operation"}, f"$.program.effect_declarations.{effect_id}.reversal")
        if declaration["effect"] != effect_name or declaration["reversal"] != reversal:
            reject("EFFECT_DECLARATION_MISMATCH", f"$.program.effect_declarations.{effect_id}", "effect class or reversal differs from the typed instruction")

    if set(program["failure_receipts"]) != FAILURE_CLASSES:
        reject("MISSING_FAILURE_RECEIPT", "$.program.failure_receipts", "every failure class must emit a receipt")
    if program["idempotency_status"] != "assumption":
        reject("IDEMPOTENCY_OVERCLAIM", "$.program.idempotency_status", "provider retry safety is an assumption")

    # Exact linear use by deterministic forward data flow on the acyclic graph.
    incoming: dict[str, frozenset[str]] = {entry: frozenset()}
    introduced_resources: set[str] = set()
    for node_id in (candidate for candidate in topo if candidate in reachable):
        instruction = nodes[node_id]
        if node_id not in incoming:
            reject("LINEAR_JOIN", f"$.program.instructions.{node_id}", "reachable node has no linear input state")
        current = set(incoming[node_id])
        if instruction["op"] == "defer_write":
            resource = instruction["resource"]
            if not isinstance(resource, str) or not resource:
                reject("TYPE_MISMATCH", f"$.program.instructions.{node_id}.resource", "linear resource identifier must be nonempty")
            if resource in introduced_resources:
                reject("LINEAR_DUPLICATE", f"$.program.instructions.{node_id}.resource", resource)
            introduced_resources.add(resource)
            current.add(resource)
        elif instruction["op"] == "commit":
            consume = instruction["consume"]
            if not isinstance(consume, list) or len(consume) != len(set(consume)):
                reject("LINEAR_DUPLICATE", f"$.program.instructions.{node_id}.consume", "resource consumed more than once")
            for resource in consume:
                if resource not in current:
                    reject("LINEAR_USE", f"$.program.instructions.{node_id}.consume", f"resource {resource!r} is unavailable")
                current.remove(resource)
        if not instruction["next"]:
            if current:
                reject("LINEAR_DROP", f"$.program.instructions.{node_id}", f"unconsumed resources {sorted(current)!r}")
            if instruction["op"] != "halt":
                reject("TYPE_MISMATCH", f"$.program.instructions.{node_id}.op", "terminal instruction must halt")
            continue
        outgoing = frozenset(current)
        for successor in instruction["next"]:
            if successor in incoming and incoming[successor] != outgoing:
                reject("LINEAR_JOIN", f"$.program.instructions.{successor}", "predecessor paths have different residual linear contexts")
            incoming[successor] = outgoing

    # Dominators and subject-matched sanctions.
    dominators: dict[str, set[str]] = {}
    for node_id in (candidate for candidate in topo if candidate in reachable):
        if node_id == entry:
            dominators[node_id] = {entry}
            continue
        preds = predecessors[node_id] & reachable
        intersection = set.intersection(*(dominators[p] for p in preds)) if preds else set()
        dominators[node_id] = {node_id} | intersection

    for node_id, instruction in nodes.items():
        if instruction["op"] != "commit" or node_id not in reachable:
            continue
        declared_subjects = doc["inputs"]["subjects"]
        if set(instruction["subjects"]) != set(declared_subjects):
            reject("SANCTIONS_OMITTED_SUBJECT", f"$.program.instructions.{node_id}.subjects", "write subjects differ from the operation subject set")
        candidates = [
            nodes[dom]
            for dom in dominators[node_id]
            if nodes[dom]["op"] == "check_sanctions"
        ]
        if not candidates:
            reject("SANCTIONS_BYPASS", f"$.program.instructions.{node_id}", "no sanctions check dominates this write")
        matched = False
        for check in candidates:
            matched = (
                set(instruction["subjects"]).issubset(set(check["subjects"]))
                and check["jurisdiction"] == instruction["jurisdiction"]
                and check["snapshot_digest"] == doc["trust_root"]["rule_pack_digest"]
                and check["fresh"] is True
            )
            if matched:
                break
        if not matched:
            reject("SANCTIONS_SUBJECT", f"$.program.instructions.{node_id}", "dominating witness has the wrong subject, scope, snapshot, or freshness")

    return nodes, topo, dominators


def validate_derived_program(doc: dict[str, Any], nodes: dict[str, dict[str, Any]]) -> tuple[str, str, str, dict[str, Any]]:
    program = doc["program"]
    computed_program = program_digest(program)
    if program["program_digest"] != computed_program:
        reject("PROGRAM_DIGEST_MISMATCH", "$.program.program_digest", "program digest does not match canonical instructions")
    computed_request = request_digest(program["request"])
    if program["request_digest"] != computed_request:
        reject("REQUEST_DIGEST_MISMATCH", "$.program.request_digest", "request digest must bind source, route, and every request field")
    commits = [instruction for instruction in nodes.values() if instruction["op"] == "commit"]
    if not commits:
        reject("TYPE_MISMATCH", "$.program.instructions", "the bounded fixture requires one deferred commit")
    for commit in commits:
        if commit["request_digest"] != computed_request:
            reject("REQUEST_DIGEST_MISMATCH", f"$.program.instructions.{commit['id']}.request_digest", "commit digest differs from request")
    awaits = [instruction for instruction in nodes.values() if instruction["op"] == "await_provider"]
    if len(awaits) != 1:
        reject("TYPE_MISMATCH", "$.program.instructions", "the bounded fixture requires one provider await")
    await_instruction = awaits[0]
    if await_instruction["expected"] != "ProviderOutcome":
        reject("UNTYPED_AWAIT", f"$.program.instructions.{await_instruction['id']}.expected", "provider awaits accept ProviderOutcome only")
    if await_instruction["scope"] != doc["trust_root"]["provider_scope"]:
        reject("PROVIDER_SCOPE_MISMATCH", f"$.program.instructions.{await_instruction['id']}.scope", "all six provider-scope coordinates must match")
    computed_operation = operation_key(doc["inputs"], computed_program)
    if await_instruction["operation_key"] != computed_operation:
        reject("OPERATION_KEY_MISMATCH", f"$.program.instructions.{await_instruction['id']}.operation_key", "operation key is not bound to program and attempt")
    return computed_program, computed_request, computed_operation, await_instruction


def authority_for(item: dict[str, Any], trust_root: dict[str, Any]) -> dict[str, Any]:
    matches = []
    for record in trust_root["authorities"]:
        exact_fields(
            record,
            {"signer", "key_id", "evidence_type", "provider_scope", "valid_from", "valid_until", "designated"},
            "$.trust_root.authorities[]",
        )
        if (
            record["signer"] == item["signer"]
            and record["key_id"] == item["key_id"]
            and record["evidence_type"] == item["type"]
        ):
            matches.append(record)
    designated = [
        record
        for record in matches
        if record["designated"]
        and (
            item["type"] != "ProviderOutcome"
            or record["provider_scope"] == item["payload"]["scope"]
        )
    ]
    if not designated:
        reject("UNAUTHORIZED_SIGNER", f"$.evidence_log.{item['digest']}.signer", "identity has no designated authority for this evidence type")
    active = [
        record
        for record in designated
        if record["valid_from"] <= item["evaluation_time"] <= record["valid_until"]
    ]
    if not active:
        reject("UNAUTHORIZED_SIGNER", f"$.evidence_log.{item['digest']}.evaluation_time", "designation is outside its validity interval")
    record = sorted(
        active,
        key=lambda value: (value["key_id"], value["signer"], value["valid_from"], value["valid_until"]),
    )[0]
    for revocation in trust_root["revocations"]:
        exact_fields(revocation, {"key_id", "effective_time"}, "$.trust_root.revocations[]")
        if revocation["key_id"] == item["key_id"] and revocation["effective_time"] <= item["evaluation_time"]:
            reject("REVOKED_SIGNER", f"$.evidence_log.{item['digest']}.key_id", "key was revoked at evidence evaluation time")
    return record


def validate_evidence(
    doc: dict[str, Any],
    expected_request: str,
    expected_operation: str,
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], list[dict[str, Any]]]:
    evidence = doc["evidence_log"]
    trust_root = doc["trust_root"]
    seen_digests: set[str] = set()
    by_digest: dict[str, dict[str, Any]] = {}
    for index, item in enumerate(evidence):
        path = f"$.evidence_log[{index}]"
        exact_fields(item, COMMON_EVIDENCE_FIELDS, path)
        evidence_type = item["type"]
        if evidence_type not in EVIDENCE_PAYLOAD_FIELDS:
            reject("EVIDENCE_TYPE", f"{path}.type", str(evidence_type))
        exact_fields(item["payload"], EVIDENCE_PAYLOAD_FIELDS[evidence_type], f"{path}.payload")
        if item["sequence"] < 1:
            reject("LOG_GAP", f"{path}.sequence", "stream sequences start at one")
        computed_digest = evidence_digest(item)
        if item["digest"] != computed_digest:
            reject("EVIDENCE_DIGEST_MISMATCH", f"{path}.digest", "evidence digest does not match canonical bytes")
        if item["digest"] in seen_digests:
            reject("DUPLICATE_EVIDENCE", f"{path}.digest", "duplicate evidence assertion")
        seen_digests.add(item["digest"])
        by_digest[item["digest"]] = item
        key_material = trust_root["keys"].get(item["key_id"])
        if key_material is None:
            reject("UNAUTHORIZED_SIGNER", f"{path}.key_id", "key is absent from the pinned registry")
        expected_signature = fixture_signature(key_material, item["digest"])
        if item["signature"] != expected_signature:
            reject("BAD_SIGNATURE", f"{path}.signature", "signature fixture does not verify")
        authority_for(item, trust_root)

        payload = item["payload"]
        if evidence_type == "ProviderOutcome":
            if payload["scope"] != trust_root["provider_scope"]:
                reject("PROVIDER_SCOPE_MISMATCH", f"{path}.payload.scope", "outcome has the wrong six-coordinate scope")
            if payload["operation_key"] != expected_operation:
                reject("OPERATION_KEY_MISMATCH", f"{path}.payload.operation_key", "outcome refers to another operation")
            if payload["request_digest"] != expected_request:
                reject("REQUEST_DIGEST_MISMATCH", f"{path}.payload.request_digest", "outcome is not bound to the full request")
            if payload["phase"] not in PROVIDER_PHASES:
                reject("PROVIDER_PHASE", f"{path}.payload.phase", "unknown provider phase")
            if payload["quantity"] < 0:
                reject("QUANTITY", f"{path}.payload.quantity", "quantity must be nonnegative")
            if payload["occurrence_key"] != occurrence_key(payload):
                reject("OCCURRENCE_KEY_MISMATCH", f"{path}.payload.occurrence_key", "occurrence key does not bind provider event fields")
        elif evidence_type != "FinalityWitness" and payload["operation_key"] != expected_operation:
            reject("OPERATION_KEY_MISMATCH", f"{path}.payload.operation_key", "evidence refers to another operation")

    streams: dict[str, list[dict[str, Any]]] = {}
    for item in evidence:
        streams.setdefault(item["stream"], []).append(item)
    for stream, entries in streams.items():
        ordered = sorted(entries, key=lambda item: item["sequence"])
        for expected_sequence, item in enumerate(ordered, start=1):
            if item["sequence"] != expected_sequence:
                reject("LOG_GAP", f"$.evidence_log.{stream}", f"expected sequence {expected_sequence}")
            if expected_sequence > 1 and ordered[expected_sequence - 2]["evaluation_time"] > item["evaluation_time"]:
                reject("LOG_ORDER", f"$.evidence_log.{stream}", "evaluation time moves backward within a stream")

    if doc["evidence_log_commitment"] != evidence_commitment(evidence):
        reject("LOG_COMMITMENT", "$.evidence_log_commitment", "count or byte commitment differs from the evidence log")

    ordered_evidence = sorted(evidence, key=evidence_sort_key)
    provider_occurrences: dict[str, dict[str, Any]] = {}
    unique_provider: list[dict[str, Any]] = []
    for item in ordered_evidence:
        if item["type"] != "ProviderOutcome":
            continue
        occurrence = item["payload"]["occurrence_key"]
        semantic = without_fields(item["payload"], {"assertion_id"})
        if occurrence in provider_occurrences:
            if provider_occurrences[occurrence] != semantic:
                reject("OCCURRENCE_EQUIVOCATION", f"$.evidence_log.{occurrence}", "same occurrence key has different event facts")
            continue
        provider_occurrences[occurrence] = semantic
        unique_provider.append(item)
    return ordered_evidence, by_digest, unique_provider


def validate_resume(
    doc: dict[str, Any],
    await_instruction: dict[str, Any],
    by_digest: dict[str, dict[str, Any]],
    ordered_evidence: list[dict[str, Any]],
) -> dict[str, Any]:
    claim = doc["resume_claim"]
    if claim["await_id"] != await_instruction["id"]:
        reject("CONTINUATION_MISMATCH", "$.resume_claim.await_id", "resume targets another continuation")
    item = by_digest.get(claim["evidence_digest"])
    if item is None:
        reject("CONTINUATION_MISMATCH", "$.resume_claim.evidence_digest", "resume evidence is absent")
    if item["type"] != "ProviderOutcome":
        reject("WRONG_RESUME_EVIDENCE", "$.resume_claim.evidence_digest", "only ProviderOutcome can resume a provider wait")
    eligible = [
        candidate
        for candidate in ordered_evidence
        if candidate["type"] == "ProviderOutcome"
        and candidate["payload"]["operation_key"] == await_instruction["operation_key"]
        and candidate["payload"]["scope"] == await_instruction["scope"]
    ]
    if not eligible or item["digest"] != eligible[0]["digest"]:
        reject("CONTINUATION_MISMATCH", "$.resume_claim.evidence_digest", "resume did not consume the first eligible authenticated outcome")
    return item


def validate_finality(
    doc: dict[str, Any],
    by_digest: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    witnesses = [item for item in doc["evidence_log"] if item["type"] == "FinalityWitness"]
    claimed_finality = doc["claimed_provider_state"]["finality"]
    if isinstance(claimed_finality, dict) and claimed_finality.get("kind") == "Final" and not witnesses:
        reject("FINALITY_MISSING", "$.claimed_provider_state.finality", "Final requires a separate FinalityWitness")
    for index, witness in enumerate(witnesses):
        payload = witness["payload"]
        outcome = by_digest.get(payload["outcome_digest"])
        if outcome is None or outcome["type"] != "ProviderOutcome":
            reject("FINALITY_NO_OUTCOME", f"$.evidence_log.finality[{index}].payload.outcome_digest", "finality must cite a prior authenticated provider outcome")
        if evidence_sort_key(outcome) >= evidence_sort_key(witness):
            reject("FINALITY_NO_OUTCOME", f"$.evidence_log.finality[{index}]", "provider outcome must precede finality assessment")
        scope = outcome["payload"]["scope"]
        bindings = {
            "provider": scope["provider"],
            "rail": scope["rail"],
            "rulebook": scope["rulebook"],
            "jurisdiction": scope["jurisdiction"],
            "asset": scope["asset"],
            "evaluation_time": witness["evaluation_time"],
        }
        for field, expected in bindings.items():
            if payload[field] != expected:
                reject("FINALITY_BINDING_MISMATCH", f"$.evidence_log.finality[{index}].payload.{field}", "legal-policy witness has the wrong binding")
        if not payload["legal_policy_id"] or not payload["policy_version"] or payload["authority"] != witness["signer"]:
            reject("FINALITY_BINDING_MISMATCH", f"$.evidence_log.finality[{index}].payload", "policy identity, version, and named authority are required")
    return sorted(witnesses, key=evidence_sort_key)


def validate_residuals(doc: dict[str, Any], unique_provider: list[dict[str, Any]], expected_operation: str) -> None:
    residuals = doc["residuals"]
    for index, residual in enumerate(residuals):
        exact_fields(residual, {"parent_operation_key", "quantity", "child_index", "child_key"}, f"$.residuals[{index}]")
        if residual["child_key"] != residual_key(residual["parent_operation_key"], residual["quantity"], residual["child_index"]):
            reject("BAD_RESIDUAL", f"$.residuals[{index}].child_key", "residual child key does not bind quantity and index")
    amount = doc["program"]["request"]["amount"]
    partials = [item for item in unique_provider if item["payload"]["phase"] == "Partial"]
    for partial in partials:
        quantity = partial["payload"]["quantity"]
        expected_quantity = amount - quantity
        matches = [
            residual
            for residual in residuals
            if residual["parent_operation_key"] == expected_operation and residual["quantity"] == expected_quantity
        ]
        if expected_quantity <= 0 or len(matches) != 1:
            reject("BAD_RESIDUAL", "$.residuals", "each partial outcome requires one child tranche for the exact residual")


def validate_subsequent(
    doc: dict[str, Any],
    unique_provider: list[dict[str, Any]],
    expected_operation: str,
    expected_request: str,
) -> None:
    graph = doc["subsequent_graph"]
    nodes = graph["nodes"]
    if graph["root"] != expected_operation or not nodes:
        reject("ORIGINAL_REWRITE", "$.subsequent_graph.root", "graph root must be the original operation")
    seen: set[str] = set()
    root = nodes[0]
    exact_fields(root, {"node_id", "kind", "parent", "request_digest", "amount", "source_occurrence", "new_payment_key"}, "$.subsequent_graph.nodes[0]")
    if (
        root["node_id"] != expected_operation
        or root["kind"] != "Original"
        or root["parent"] is not None
        or root["request_digest"] != expected_request
        or root["amount"] != doc["program"]["request"]["amount"]
        or root["source_occurrence"] is not None
        or root["new_payment_key"] is not None
    ):
        reject("ORIGINAL_REWRITE", "$.subsequent_graph.nodes[0]", "original operation fields are immutable")
    seen.add(root["node_id"])
    rail_counts: dict[str, int] = {}
    for index, node in enumerate(nodes[1:], start=1):
        path = f"$.subsequent_graph.nodes[{index}]"
        exact_fields(node, {"node_id", "kind", "parent", "request_digest", "amount", "source_occurrence", "new_payment_key"}, path)
        if node["node_id"] in seen:
            reject("SUBSEQUENT_DUPLICATE_NODE", f"{path}.node_id", "node identifier is not fresh")
        if node["kind"] not in SUBSEQUENT_KINDS - {"Original"}:
            reject("SUBSEQUENT_KIND", f"{path}.kind", "unknown subsequent-effect kind")
        if node["parent"] not in seen:
            reject("SUBSEQUENT_GRAPH", f"{path}.parent", "parent must be an earlier node")
        if node["request_digest"] is not None or node["amount"] is not None:
            reject("ORIGINAL_REWRITE", path, "subsequent nodes cannot replace original request fields")
        if node["kind"] == "Refund":
            if not node["new_payment_key"] or node["new_payment_key"] == expected_operation:
                reject("REFUND_TYPE", f"{path}.new_payment_key", "refund is a fresh payment")
        elif node["new_payment_key"] is not None:
            reject("SUBSEQUENT_KIND", f"{path}.new_payment_key", "only Refund carries a new payment key")
        if node["kind"] == "RailReversal":
            if not node["source_occurrence"]:
                reject("RAIL_REVERSAL_MISSING", f"{path}.source_occurrence", "rail reversal must cite a provider occurrence")
            rail_counts[node["source_occurrence"]] = rail_counts.get(node["source_occurrence"], 0) + 1
        seen.add(node["node_id"])

    reversed_occurrences = {
        item["payload"]["occurrence_key"]
        for item in unique_provider
        if item["payload"]["phase"] == "Reversed"
    }
    for occurrence in reversed_occurrences:
        count = rail_counts.get(occurrence, 0)
        if count == 0:
            reject("RAIL_REVERSAL_MISSING", "$.subsequent_graph", "provider reversal has no RailReversal node")
        if count > 1:
            reject("DUPLICATE_RAIL_REVERSAL", "$.subsequent_graph", "one provider reversal occurrence produced more than one node")
    for occurrence in rail_counts:
        if occurrence not in reversed_occurrences:
            reject("RAIL_REVERSAL_SOURCE", "$.subsequent_graph", "RailReversal does not cite an authenticated reversal occurrence")


def classify_reconciliation(
    local: dict[str, int],
    provider: dict[str, int],
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for key in sorted(set(local) | set(provider)):
        if key in local and key not in provider:
            result[key] = {"kind": "OrphanLocal"}
        elif key in provider and key not in local:
            result[key] = {"kind": "OrphanProvider"}
        elif local[key] == provider[key]:
            result[key] = {"kind": "Matched", "quantity": local[key]}
        else:
            result[key] = {"kind": "Break", "difference": local[key] - provider[key]}
    return result


def reconciliation_fold(
    doc: dict[str, Any],
    unique_provider: list[dict[str, Any]],
    expected_operation: str,
    compare_claimed: bool = True,
) -> dict[str, dict[str, Any]]:
    reconciliation = doc["reconciliation"]
    local = reconciliation["local"]
    provider = reconciliation["provider"]
    if not isinstance(local, dict) or not isinstance(provider, dict):
        reject("TYPE_MISMATCH", "$.reconciliation", "statement folds must be objects")
    expected_local = {expected_operation: doc["program"]["request"]["amount"]}
    intended_quantity = doc["program"]["request"]["amount"]
    executed_quantity: int | None = None
    for item in unique_provider:
        phase = item["payload"]["phase"]
        if phase in {"Partial", "Succeeded"}:
            next_quantity = item["payload"]["quantity"]
            if next_quantity > intended_quantity:
                reject("RECONCILIATION_SOURCE", "$.evidence_log", "executed quantity exceeds the canonical request")
            if executed_quantity is not None and next_quantity < executed_quantity:
                reject("RECONCILIATION_SOURCE", "$.evidence_log", "cumulative executed quantity decreased")
            executed_quantity = next_quantity
        elif phase == "Failed" and executed_quantity is None:
            executed_quantity = 0
    expected_provider = {} if executed_quantity is None else {expected_operation: executed_quantity}
    if local != expected_local or provider != expected_provider:
        reject("RECONCILIATION_SOURCE", "$.reconciliation", "maps differ from the canonical request and authenticated outcome fold")
    result = classify_reconciliation(local, provider)
    if compare_claimed and reconciliation["claimed"] != result:
        reject("RECONCILIATION_ERROR", "$.reconciliation.claimed", "claimed fold differs from signed statement maps")
    return result


def uncertainty_obstructions(doc: dict[str, Any]) -> list[dict[str, Any]]:
    caps = doc["uncertainty"]["caps"]
    items = doc["uncertainty"]["items"]
    if not isinstance(caps, dict) or not isinstance(items, list):
        reject("TYPE_MISMATCH", "$.uncertainty", "caps object and item array required")
    totals: dict[str, int] = {}
    seen: set[str] = set()
    obstructions: list[dict[str, Any]] = []
    for index, item in enumerate(items):
        exact_fields(item, {"asset", "quantity", "occurrence_key"}, f"$.uncertainty.items[{index}]")
        if item["quantity"] < 0 or item["occurrence_key"] in seen:
            reject("UNCERTAINTY_ITEM", f"$.uncertainty.items[{index}]", "uncertainty item must be nonnegative and occurrence-unique")
        seen.add(item["occurrence_key"])
        totals[item["asset"]] = totals.get(item["asset"], 0) + item["quantity"]
        obstructions.append({"kind": "UncertainEffect", **item})
    for asset, quantity in totals.items():
        cap = caps.get(asset)
        if cap is None or quantity > cap:
            reject("UNCERTAINTY_CAP", f"$.uncertainty.caps.{asset}", "unresolved quantity exceeds the declared bound")
    return obstructions


def validate_corridor(doc: dict[str, Any]) -> None:
    corridor = doc["corridor"]
    if doc["trust_root"]["corridor_map_digest"] != digest("op:corridor-map:v1", corridor):
        reject("CORRIDOR_DIGEST", "$.trust_root.corridor_map_digest", "corridor map is not pinned")
    if not corridor["route_consistent"]:
        reject("ROUTE_COHERENCE", "$.corridor.route_consistent", "direct and staged route facts disagree")
    source = doc["verdicts"]["source"]
    receiver = doc["verdicts"]["receiver"]
    if (
        source["jurisdiction"] != corridor["source_jurisdiction"]
        or source["pack_digest"] != corridor["source_pack_digest"]
        or receiver["jurisdiction"] != corridor["receiver_jurisdiction"]
        or receiver["pack_digest"] != corridor["receiver_pack_digest"]
    ):
        reject("VERDICT_BINDING", "$.verdicts", "verdict jurisdiction or pack binding is wrong")
    if source is receiver or canonical_bytes(source) == canonical_bytes(receiver):
        reject("VERDICT_CONFLATION", "$.verdicts", "source and receiving-jurisdiction verdicts must remain distinct")


def derive_provider_state(
    doc: dict[str, Any],
    unique_provider: list[dict[str, Any]],
    finality_witnesses: list[dict[str, Any]],
    reconciliation: dict[str, dict[str, Any]],
    obstructions: list[dict[str, Any]],
) -> dict[str, Any]:
    scope = doc["trust_root"]["provider_scope"]
    outcome_authorities = [
        record
        for record in doc["trust_root"]["authorities"]
        if record["evidence_type"] == "ProviderOutcome"
        and record["provider_scope"] == scope
        and record["designated"]
    ]
    evaluation_time = doc["trust_root"]["evaluation_time"]
    revoked_keys = {
        record["key_id"]
        for record in doc["trust_root"]["revocations"]
        if record["effective_time"] <= evaluation_time
    }
    active_authorities = [
        record
        for record in outcome_authorities
        if record["valid_from"] <= evaluation_time <= record["valid_until"]
        and record["key_id"] not in revoked_keys
    ]
    if active_authorities:
        authority = sorted(active_authorities, key=lambda record: (record["key_id"], record["signer"]))[0]
        authorization: dict[str, Any] = {
            "kind": "Designated",
            "provider": scope["provider"],
            "signer": authority["signer"],
            "key_id": authority["key_id"],
        }
    elif any(record["key_id"] in revoked_keys for record in outcome_authorities):
        authorization = {"kind": "Revoked", "provider": scope["provider"]}
    else:
        authorization = {"kind": "Undesignated", "provider": scope["provider"]}
    if unique_provider:
        last_outcome = unique_provider[-1]
        provider_phase: dict[str, Any] = {
            "kind": last_outcome["payload"]["phase"],
            "quantity": last_outcome["payload"]["quantity"],
            "occurrence_key": last_outcome["payload"]["occurrence_key"],
        }
    else:
        provider_phase = {"kind": "Unobserved"}
    if finality_witnesses:
        last_finality = finality_witnesses[-1]
        finality: dict[str, Any] = {"kind": "Final", "witness_digest": last_finality["digest"]}
    else:
        finality = {"kind": "Unassessed"}
    subsequent = [
        {"node_id": node["node_id"], "kind": node["kind"], "parent": node["parent"]}
        for node in doc["subsequent_graph"]["nodes"][1:]
    ]
    return {
        "authorization": authorization,
        "dispatch": {"kind": "Sent", "request_digest": doc["program"]["request_digest"]},
        "provider_phase": provider_phase,
        "finality": finality,
        "reconciliation": reconciliation,
        "subsequent_effects": subsequent,
        "obstructions": obstructions,
    }


def append_bundle_entry(bundle: list[dict[str, Any]], kind: str, data: dict[str, Any]) -> None:
    prior = bundle[-1]["digest"] if bundle else "0" * 64
    body = {"index": len(bundle), "kind": kind, "data": data, "prior": prior}
    body["digest"] = digest("op:bundle-entry:v1", body)
    bundle.append(body)


def replay_bundle(
    doc: dict[str, Any],
    nodes: dict[str, dict[str, Any]],
    bsc_result: dict[str, Any],
    ordered_evidence: list[dict[str, Any]],
    resume_item: dict[str, Any],
    reconciliation: dict[str, dict[str, Any]],
    obstructions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    bundle: list[dict[str, Any]] = []
    append_bundle_entry(bundle, "ProgramAccepted", {"program_digest": doc["program"]["program_digest"]})
    append_bundle_entry(bundle, "BilateralCommitReceipt", bsc_result)
    checks = sorted((node for node in nodes.values() if node["op"] == "check_sanctions"), key=lambda node: node["id"])
    for check in checks:
        append_bundle_entry(
            bundle,
            "SanctionsReceipt",
            {
                "instruction": check["id"],
                "subjects": check["subjects"],
                "jurisdiction": check["jurisdiction"],
                "snapshot_digest": check["snapshot_digest"],
            },
        )
    append_bundle_entry(bundle, "DeferredWrite", {"request_digest": doc["program"]["request_digest"]})
    append_bundle_entry(bundle, "DispatchReceipt", {"request_digest": doc["program"]["request_digest"]})
    append_bundle_entry(
        bundle,
        "PauseToken",
        {
            "await_id": doc["resume_claim"]["await_id"],
            "expected": "ProviderOutcome",
            "operation_key": resume_item["payload"]["operation_key"],
        },
    )
    for item in ordered_evidence:
        kinds = {
            "LedgerConfirmation": "LedgerObservation",
            "ProviderOutcome": "OutcomeReceipt",
            "FinalityWitness": "FinalityReceipt",
            "BeneficiaryReceipt": "BeneficiaryReceipt",
        }
        append_bundle_entry(bundle, kinds[item["type"]], {"evidence_digest": item["digest"]})
    for residual in doc["residuals"]:
        append_bundle_entry(bundle, "ResidualChild", residual)
    for node in doc["subsequent_graph"]["nodes"][1:]:
        append_bundle_entry(bundle, "SubsequentEffect", {"node_id": node["node_id"], "kind": node["kind"], "parent": node["parent"]})
    append_bundle_entry(bundle, "Reconciliation", {"fold_digest": digest("op:reconciliation:v1", reconciliation)})
    for obstruction in obstructions:
        append_bundle_entry(bundle, "Obstruction", obstruction)
    append_bundle_entry(bundle, "HaltReceipt", {"status": "suspended-then-complete"})
    return bundle


def validate_bundle_chain(claimed: Any) -> None:
    if not isinstance(claimed, list):
        reject("TYPE_MISMATCH", "$.claimed_bundle", "bundle must be an array")
    prior = "0" * 64
    for index, entry in enumerate(claimed):
        path = f"$.claimed_bundle[{index}]"
        exact_fields(entry, {"index", "kind", "data", "prior", "digest"}, path)
        if entry["index"] != index or entry["prior"] != prior:
            reject("BUNDLE_CHAIN", path, "index or prior digest breaks append-only order")
        computed = digest("op:bundle-entry:v1", without_fields(entry, {"digest"}))
        if entry["digest"] != computed:
            reject("BUNDLE_CHAIN", f"{path}.digest", "entry digest does not match its canonical body")
        prior = entry["digest"]


def verify_document(doc: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    validate_scalar_tree(doc)
    validate_top_schema(doc)
    validate_limits(doc)
    nodes, _topo, _dominators = graph_and_static_checks(doc)
    _p_digest, req_digest, op_key, await_instruction = validate_derived_program(doc, nodes)
    bsc_result = validate_bilateral_commit(doc, op_key)
    ordered_evidence, by_digest, unique_provider = validate_evidence(doc, req_digest, op_key)
    resume_item = validate_resume(doc, await_instruction, by_digest, ordered_evidence)
    finality_witnesses = validate_finality(doc, by_digest)
    validate_residuals(doc, unique_provider, op_key)
    validate_subsequent(doc, unique_provider, op_key, req_digest)
    reconciliation = reconciliation_fold(doc, unique_provider, op_key)
    obstructions = uncertainty_obstructions(doc)
    validate_corridor(doc)
    derived_state = derive_provider_state(doc, unique_provider, finality_witnesses, reconciliation, obstructions)
    if doc["claimed_provider_state"] != derived_state:
        reject("PROVIDER_STATE_MISMATCH", "$.claimed_provider_state", "declared seven-coordinate product differs from the event fold")
    validate_bundle_chain(doc["claimed_bundle"])
    computed_bundle = replay_bundle(doc, nodes, bsc_result, ordered_evidence, resume_item, reconciliation, obstructions)
    if doc["claimed_bundle"] != computed_bundle:
        limit = min(len(doc["claimed_bundle"]), len(computed_bundle))
        mismatch = next(
            (index for index in range(limit) if doc["claimed_bundle"][index] != computed_bundle[index]),
            limit,
        )
        reject("BUNDLE_MISMATCH", f"$.claimed_bundle[{mismatch}]", "claimed bytes differ from deterministic replay")
    head = computed_bundle[-1]["digest"] if computed_bundle else "0" * 64
    return head, computed_bundle


def verify_bytes(raw: bytes) -> VerifyResult:
    try:
        doc = parse_canonical(raw)
        head, _bundle = verify_document(doc)
        return VerifyResult(True, "ACCEPT", "$", "verified", head, None)
    except RejectError as error:
        return VerifyResult(False, error.code, error.path, error.detail, None, failure_receipt(raw, error))
    except Exception as exc:  # Closed fallback for any implementation fault in this bounded model.
        error = RejectError("INTERNAL_ERROR", "$", f"{type(exc).__name__}: {exc}")
        return VerifyResult(False, error.code, error.path, error.detail, None, failure_receipt(raw, error))


def make_evidence(
    evidence_type: str,
    stream: str,
    sequence: int,
    evaluation_time: int,
    signer: str,
    key_id: str,
    payload: dict[str, Any],
    keys: dict[str, str],
) -> dict[str, Any]:
    item = {
        "type": evidence_type,
        "stream": stream,
        "sequence": sequence,
        "evaluation_time": evaluation_time,
        "signer": signer,
        "key_id": key_id,
        "payload": payload,
        "digest": "",
        "signature": "",
    }
    seal_evidence(item, keys)
    return item


def make_bsc_message(
    sequence: int,
    from_role: str,
    to_role: str,
    kind: str,
    session_id: str,
    operation: str,
    evaluation_id: str,
    prior: str,
    body: dict[str, Any],
    key_id: str,
    keys: dict[str, str],
) -> dict[str, Any]:
    message = {
        "sequence": sequence,
        "from_role": from_role,
        "to_role": to_role,
        "kind": kind,
        "session_id": session_id,
        "operation_key": operation,
        "evaluation_id": evaluation_id,
        "prior": prior,
        "body": body,
        "key_id": key_id,
        "digest": "",
        "signature": "",
    }
    seal_bsc_message(message, keys)
    return message


def build_fixture() -> dict[str, Any]:
    scope = {
        "provider": "provider-one",
        "rail": "rail-a",
        "rulebook": "rulebook-7",
        "jurisdiction": "J-A",
        "asset": "USD",
        "operation_class": "credit-transfer",
    }
    keys = {
        "provider-key": "fixture-provider-key-material",
        "ledger-key": "fixture-ledger-key-material",
        "legal-key": "fixture-legal-key-material",
        "beneficiary-key": "fixture-beneficiary-key-material",
        "bsc-a-key": "fixture-bsc-a-key-material",
        "bsc-b-key": "fixture-bsc-b-key-material",
    }
    inputs = {
        "operation_id": "operation-0001",
        "step_id": "dispatch-1",
        "attempt": 1,
        "subjects": ["payer-17", "beneficiary-23"],
        "jurisdiction": "J-A",
    }
    request = {
        **scope,
        "source": "account-source-41",
        "route": ["gateway-a", "rail-a"],
        "destination": "account-destination-84",
        "amount": 100,
        "idempotency_key": "idem-operation-0001-attempt-1",
        "reversal": {"kind": "Subsequent", "operation": "RailReversal"},
    }
    program: dict[str, Any] = {
        "entry": "screen",
        "instructions": [
            {
                "id": "screen",
                "op": "check_sanctions",
                "next": ["defer"],
                "subjects": ["payer-17", "beneficiary-23"],
                "jurisdiction": "J-A",
                "snapshot_digest": "rule-pack-a",
                "fresh": True,
            },
            {
                "id": "defer",
                "op": "defer_write",
                "next": ["commit"],
                "resource": "linear-request-1",
                "effect": "credit-transfer",
                "reversal": {"kind": "Subsequent", "operation": "RailReversal"},
                "subjects": ["payer-17", "beneficiary-23"],
                "jurisdiction": "J-A",
            },
            {
                "id": "commit",
                "op": "commit",
                "next": ["await"],
                "consume": ["linear-request-1"],
                "request_digest": "",
                "subjects": ["payer-17", "beneficiary-23"],
                "jurisdiction": "J-A",
            },
            {
                "id": "await",
                "op": "await_provider",
                "next": ["halt"],
                "expected": "ProviderOutcome",
                "scope": scope,
                "operation_key": "",
                "continuation_resource": "continuation-1",
            },
            {"id": "halt", "op": "halt", "next": []},
        ],
        "effect_declarations": {
            "await": {
                "effect": "AwaitProviderOutcome",
                "reversal": {"kind": "NoStateChange", "operation": "NoStateChange"},
            },
            "defer": {
                "effect": "Write",
                "reversal": {"kind": "Subsequent", "operation": "RailReversal"},
            },
            "proof-bundle": {
                "effect": "ProofEmit",
                "reversal": {"kind": "NoStateChange", "operation": "NoStateChange"},
            },
            "screen": {
                "effect": "SanctionsCheck",
                "reversal": {"kind": "NoStateChange", "operation": "NoStateChange"},
            },
        },
        "request": request,
        "request_digest": "",
        "program_digest": "",
        "failure_receipts": sorted(FAILURE_CLASSES),
        "idempotency_status": "assumption",
    }
    p_digest = program_digest(program)
    req_digest = request_digest(request)
    op_key = operation_key(inputs, p_digest)
    program["program_digest"] = p_digest
    program["request_digest"] = req_digest
    for instruction in program["instructions"]:
        if instruction["op"] == "commit":
            instruction["request_digest"] = req_digest
        elif instruction["op"] == "await_provider":
            instruction["operation_key"] = op_key

    trust_root = {
        "rule_pack_digest": "rule-pack-a",
        "type_registry_digest": "type-registry-a",
        "corridor_map_digest": "",
        "evaluation_time": 1700000200,
        "keys": keys,
        "authorities": [
            {
                "signer": "provider-one",
                "key_id": "provider-key",
                "evidence_type": "ProviderOutcome",
                "provider_scope": scope,
                "valid_from": 1699990000,
                "valid_until": 1700010000,
                "designated": True,
            },
            {
                "signer": "ledger-observer",
                "key_id": "ledger-key",
                "evidence_type": "LedgerConfirmation",
                "provider_scope": None,
                "valid_from": 1699990000,
                "valid_until": 1700010000,
                "designated": True,
            },
            {
                "signer": "named-legal-authority",
                "key_id": "legal-key",
                "evidence_type": "FinalityWitness",
                "provider_scope": None,
                "valid_from": 1699990000,
                "valid_until": 1700010000,
                "designated": True,
            },
            {
                "signer": "beneficiary-23",
                "key_id": "beneficiary-key",
                "evidence_type": "BeneficiaryReceipt",
                "provider_scope": None,
                "valid_from": 1699990000,
                "valid_until": 1700010000,
                "designated": True,
            },
            {
                "signer": "jurisdiction-a",
                "key_id": "bsc-a-key",
                "evidence_type": "BSCMessage",
                "provider_scope": None,
                "valid_from": 1699990000,
                "valid_until": 1700010000,
                "designated": True,
            },
            {
                "signer": "jurisdiction-b",
                "key_id": "bsc-b-key",
                "evidence_type": "BSCMessage",
                "provider_scope": None,
                "valid_from": 1699990000,
                "valid_until": 1700010000,
                "designated": True,
            },
        ],
        "revocations": [],
        "provider_scope": scope,
    }

    partial_payload = {
        "scope": scope,
        "operation_key": op_key,
        "request_digest": req_digest,
        "provider_event_id": "provider-event-partial",
        "event_time": 1700000010,
        "phase": "Partial",
        "quantity": 60,
        "occurrence_key": "",
        "assertion_id": "assertion-partial-a",
    }
    partial_payload["occurrence_key"] = occurrence_key(partial_payload)
    partial = make_evidence("ProviderOutcome", "provider-stream", 1, 1700000011, "provider-one", "provider-key", partial_payload, keys)
    repeated_payload = copy.deepcopy(partial_payload)
    repeated_payload["assertion_id"] = "assertion-partial-b"
    repeated = make_evidence("ProviderOutcome", "provider-stream", 2, 1700000012, "provider-one", "provider-key", repeated_payload, keys)

    succeeded_payload = {
        "scope": scope,
        "operation_key": op_key,
        "request_digest": req_digest,
        "provider_event_id": "provider-event-succeeded",
        "event_time": 1700000020,
        "phase": "Succeeded",
        "quantity": 100,
        "occurrence_key": "",
        "assertion_id": "assertion-succeeded",
    }
    succeeded_payload["occurrence_key"] = occurrence_key(succeeded_payload)
    succeeded = make_evidence("ProviderOutcome", "provider-stream", 3, 1700000021, "provider-one", "provider-key", succeeded_payload, keys)

    reversed_payload = {
        "scope": scope,
        "operation_key": op_key,
        "request_digest": req_digest,
        "provider_event_id": "provider-event-reversed",
        "event_time": 1700000050,
        "phase": "Reversed",
        "quantity": 100,
        "occurrence_key": "",
        "assertion_id": "assertion-reversed",
    }
    reversed_payload["occurrence_key"] = occurrence_key(reversed_payload)
    reversed_outcome = make_evidence("ProviderOutcome", "provider-stream", 4, 1700000051, "provider-one", "provider-key", reversed_payload, keys)

    ledger = make_evidence(
        "LedgerConfirmation",
        "ledger-stream",
        1,
        1700000005,
        "ledger-observer",
        "ledger-key",
        {"operation_key": op_key, "ledger": "ledger-a", "block_reference": "block-900"},
        keys,
    )
    finality = make_evidence(
        "FinalityWitness",
        "legal-stream",
        1,
        1700000030,
        "named-legal-authority",
        "legal-key",
        {
            "outcome_digest": succeeded["digest"],
            "provider": scope["provider"],
            "rail": scope["rail"],
            "rulebook": scope["rulebook"],
            "jurisdiction": scope["jurisdiction"],
            "asset": scope["asset"],
            "evaluation_time": 1700000030,
            "legal_policy_id": "policy-finality-4",
            "policy_version": "2026-09",
            "authority": "named-legal-authority",
        },
        keys,
    )
    beneficiary = make_evidence(
        "BeneficiaryReceipt",
        "beneficiary-stream",
        1,
        1700000040,
        "beneficiary-23",
        "beneficiary-key",
        {
            "operation_key": op_key,
            "beneficiary": "beneficiary-23",
            "quantity": 100,
            "received_at": 1700000039,
        },
        keys,
    )

    # Deliberately not in evaluation order. Replay sorts by the normative tuple.
    evidence_log = [reversed_outcome, beneficiary, partial, ledger, finality, repeated, succeeded]
    rail_node_id = digest("op:subsequent-node:v1", {"kind": "RailReversal", "source_occurrence": reversed_payload["occurrence_key"]})
    subsequent_graph = {
        "root": op_key,
        "nodes": [
            {
                "node_id": op_key,
                "kind": "Original",
                "parent": None,
                "request_digest": req_digest,
                "amount": 100,
                "source_occurrence": None,
                "new_payment_key": None,
            },
            {
                "node_id": rail_node_id,
                "kind": "RailReversal",
                "parent": op_key,
                "request_digest": None,
                "amount": None,
                "source_occurrence": reversed_payload["occurrence_key"],
                "new_payment_key": None,
            },
        ],
    }
    residual_quantity = 40
    residuals = [
        {
            "parent_operation_key": op_key,
            "quantity": residual_quantity,
            "child_index": 1,
            "child_key": residual_key(op_key, residual_quantity, 1),
        }
    ]
    reconciliation = {"local": {op_key: 100}, "provider": {op_key: 100}, "claimed": {}}
    uncertainty = {
        "caps": {"USD": 25},
        "items": [{"asset": "USD", "quantity": 10, "occurrence_key": "unresolved-attempt-2"}],
    }
    corridor = {
        "source_jurisdiction": "J-A",
        "receiver_jurisdiction": "J-B",
        "route_digest": "route-direct-equals-staged",
        "source_pack_digest": "rule-pack-a",
        "receiver_pack_digest": "rule-pack-b",
        "route_consistent": True,
        "fresh_domains": ["sanctions", "asset-authority"],
    }
    trust_root["corridor_map_digest"] = digest("op:corridor-map:v1", corridor)

    session_id = "bsc-session-0001"
    evaluation_id = "evaluation-2026-09-a"
    roles = {
        "A": {"name": "jurisdiction-a", "key_id": "bsc-a-key"},
        "B": {"name": "jurisdiction-b", "key_id": "bsc-b-key"},
    }
    bsc_specs = [
        ("A", "B", "Begin", {"program_digest": p_digest}),
        ("B", "A", "Lock", {"lock_id": "lock-b-0001"}),
        ("A", "B", "Lock", {"lock_id": "lock-a-0001"}),
        ("A", "B", "Verdict", {"verdict": "Admit"}),
        ("B", "A", "Verdict", {"verdict": "Admit"}),
        ("A", "B", "Decision", {"decision": "Commit"}),
        ("B", "A", "Ack", {"decision": "Commit"}),
    ]
    bsc_messages: list[dict[str, Any]] = []
    prior = "0" * 64
    for sequence, (from_role, to_role, kind, body) in enumerate(bsc_specs, start=1):
        message = make_bsc_message(
            sequence,
            from_role,
            to_role,
            kind,
            session_id,
            op_key,
            evaluation_id,
            prior,
            body,
            roles[from_role]["key_id"],
            keys,
        )
        bsc_messages.append(message)
        prior = message["digest"]
    bilateral_commit = {
        "session_id": session_id,
        "operation_key": op_key,
        "evaluation_id": evaluation_id,
        "roles": roles,
        "states": {
            "A": ["Init", "Locked", "Verified", "Committed"],
            "B": ["Init", "Locked", "Verified", "Committed"],
        },
        "messages": bsc_messages,
    }

    doc: dict[str, Any] = {
        "schema": SCHEMA,
        "program": program,
        "inputs": inputs,
        "trust_root": trust_root,
        "evidence_log": evidence_log,
        "evidence_log_commitment": evidence_commitment(evidence_log),
        "resume_claim": {"await_id": "await", "evidence_digest": partial["digest"]},
        "claimed_bundle": [],
        "claimed_provider_state": {key: None for key in sorted(SEVEN_COORDINATES)},
        "subsequent_graph": subsequent_graph,
        "residuals": residuals,
        "reconciliation": reconciliation,
        "uncertainty": uncertainty,
        "corridor": corridor,
        "verdicts": {
            "source": {"jurisdiction": "J-A", "pack_digest": "rule-pack-a", "status": "Admit"},
            "receiver": {"jurisdiction": "J-B", "pack_digest": "rule-pack-b", "status": "PendingFreshEvaluation"},
        },
        "bilateral_commit": bilateral_commit,
    }
    ordered, by_digest, unique_provider = validate_evidence(doc, req_digest, op_key)
    doc["reconciliation"]["claimed"] = reconciliation_fold(
        doc,
        unique_provider,
        op_key,
        compare_claimed=False,
    )
    resume_item = validate_resume(doc, next(i for i in program["instructions"] if i["op"] == "await_provider"), by_digest, ordered)
    finality_witnesses = validate_finality(doc, by_digest)
    obstructions = uncertainty_obstructions(doc)
    bsc_result = validate_bilateral_commit(doc, op_key)
    doc["claimed_provider_state"] = derive_provider_state(doc, unique_provider, finality_witnesses, doc["reconciliation"]["claimed"], obstructions)
    nodes = {instruction["id"]: instruction for instruction in program["instructions"]}
    doc["claimed_bundle"] = replay_bundle(doc, nodes, bsc_result, ordered, resume_item, doc["reconciliation"]["claimed"], obstructions)
    return doc


def reseal_item(doc: dict[str, Any], predicate: Callable[[dict[str, Any]], bool]) -> dict[str, Any]:
    item = next(item for item in doc["evidence_log"] if predicate(item))
    seal_evidence(item, doc["trust_root"]["keys"])
    doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    return item


def reseal_bsc_chain(doc: dict[str, Any]) -> None:
    prior = "0" * 64
    for sequence, message in enumerate(doc["bilateral_commit"]["messages"], start=1):
        message["sequence"] = sequence
        message["prior"] = prior
        seal_bsc_message(message, doc["trust_root"]["keys"])
        prior = message["digest"]


def mutate(name: str, base: dict[str, Any]) -> dict[str, Any]:
    doc = copy.deepcopy(base)
    instructions = doc["program"]["instructions"]
    by_op = {instruction["op"]: instruction for instruction in instructions}
    if name == "UNKNOWN_FIELD":
        doc["unexpected"] = True
    elif name == "INTEGER_RANGE":
        doc["inputs"]["attempt"] = INT_MAX + 1
    elif name == "GRAPH_CYCLE":
        by_op["halt"]["next"] = [doc["program"]["entry"]]
    elif name == "UNREACHABLE_CYCLE":
        instructions.extend(
            [
                {
                    "id": "dead-a",
                    "op": "check_sanctions",
                    "next": ["dead-b"],
                    "subjects": ["payer-17", "beneficiary-23"],
                    "jurisdiction": "J-A",
                    "snapshot_digest": "rule-pack-a",
                    "fresh": True,
                },
                {
                    "id": "dead-b",
                    "op": "check_sanctions",
                    "next": ["dead-a"],
                    "subjects": ["payer-17", "beneficiary-23"],
                    "jurisdiction": "J-A",
                    "snapshot_digest": "rule-pack-a",
                    "fresh": True,
                },
            ]
        )
        doc["program"]["effect_declarations"]["dead-a"] = {
            "effect": "SanctionsCheck",
            "reversal": {"kind": "NoStateChange", "operation": "NoStateChange"},
        }
        doc["program"]["effect_declarations"]["dead-b"] = {
            "effect": "SanctionsCheck",
            "reversal": {"kind": "NoStateChange", "operation": "NoStateChange"},
        }
    elif name == "MISSING_REVERSAL":
        by_op["defer_write"]["reversal"]["operation"] = ""
    elif name == "REVERSAL_MISMATCH":
        by_op["defer_write"]["reversal"] = {"kind": "Compensate", "operation": "Compensation"}
    elif name == "MISSING_EFFECT_DECLARATION":
        del doc["program"]["effect_declarations"]["await"]
    elif name == "EFFECT_DECLARATION_MISMATCH":
        doc["program"]["effect_declarations"]["await"]["reversal"] = {
            "kind": "Compensate",
            "operation": "Compensation",
        }
    elif name == "DIRECT_WRITE":
        commit = by_op["commit"]
        commit.clear()
        commit.update({"id": "commit", "op": "direct_write", "next": ["await"], "subjects": ["payer-17", "beneficiary-23"], "jurisdiction": "J-A"})
    elif name == "LINEAR_DUPLICATE":
        by_op["commit"]["consume"] = ["linear-request-1", "linear-request-1"]
    elif name == "LINEAR_DROP":
        by_op["commit"]["consume"] = []
    elif name == "LINEAR_JOIN":
        branch = {
            "id": "branch",
            "op": "check_sanctions",
            "next": ["await"],
            "subjects": ["payer-17", "beneficiary-23"],
            "jurisdiction": "J-A",
            "snapshot_digest": "rule-pack-a",
            "fresh": True,
        }
        instructions.append(branch)
        doc["program"]["effect_declarations"]["branch"] = {
            "effect": "SanctionsCheck",
            "reversal": {"kind": "NoStateChange", "operation": "NoStateChange"},
        }
        by_op["check_sanctions"]["next"] = ["defer", "branch"]
        by_op["defer_write"]["next"] = ["await"]
        by_op["await_provider"]["next"] = ["commit"]
        by_op["commit"]["next"] = ["halt"]
    elif name == "SANCTIONS_BYPASS":
        doc["program"]["entry"] = "defer"
    elif name == "SANCTIONS_SUBJECT":
        by_op["commit"]["subjects"] = ["payer-17", "unscreened-99"]
        doc["inputs"]["subjects"] = ["payer-17", "unscreened-99"]
    elif name == "SANCTIONS_OMITTED_SUBJECT":
        by_op["commit"]["subjects"] = ["payer-17"]
    elif name == "MISSING_FAILURE_RECEIPT":
        doc["program"]["failure_receipts"].remove("trap")
    elif name == "IDEMPOTENCY_OVERCLAIM":
        doc["program"]["idempotency_status"] = "theorem"
    elif name == "PROGRAM_DIGEST_MISMATCH":
        doc["program"]["program_digest"] = "0" * 64
    elif name == "REQUEST_DIGEST_MISMATCH":
        doc["program"]["request"]["source"] = "changed-source"
        doc["program"]["program_digest"] = program_digest(doc["program"])
    elif name == "UNTYPED_AWAIT":
        by_op["await_provider"]["expected"] = "LedgerConfirmation"
    elif name == "BSC_ORDER":
        messages = doc["bilateral_commit"]["messages"]
        messages[1], messages[2] = messages[2], messages[1]
        reseal_bsc_chain(doc)
    elif name == "BSC_LINEAR_LOCK":
        messages = doc["bilateral_commit"]["messages"]
        messages[2]["body"]["lock_id"] = messages[1]["body"]["lock_id"]
        reseal_bsc_chain(doc)
    elif name == "BSC_VERIFIED_ENTRY":
        doc["bilateral_commit"]["states"]["A"] = ["Init", "Locked", "Committed"]
    elif name == "BSC_DECISION":
        messages = doc["bilateral_commit"]["messages"]
        messages[5]["body"]["decision"] = "Abort"
        messages[6]["body"]["decision"] = "Abort"
        reseal_bsc_chain(doc)
    elif name == "BSC_ACK_MISMATCH":
        doc["bilateral_commit"]["messages"][6]["body"]["decision"] = "Abort"
        reseal_bsc_chain(doc)
    elif name == "BSC_SIGNATURE":
        doc["bilateral_commit"]["messages"][0]["signature"] = "0" * 64
    elif name == "BSC_AUTHORITY":
        next(
            record
            for record in doc["trust_root"]["authorities"]
            if record["evidence_type"] == "BSCMessage" and record["signer"] == "jurisdiction-a"
        )["designated"] = False
    elif name == "BSC_EXPIRED_AUTHORITY":
        next(
            record
            for record in doc["trust_root"]["authorities"]
            if record["evidence_type"] == "BSCMessage" and record["signer"] == "jurisdiction-a"
        )["valid_until"] = doc["trust_root"]["evaluation_time"] - 1
    elif name == "BSC_PROGRAM_BINDING":
        doc["bilateral_commit"]["messages"][0]["body"]["program_digest"] = "0" * 64
        reseal_bsc_chain(doc)
    elif name == "BSC_ARITY":
        doc["bilateral_commit"]["roles"]["B"]["name"] = doc["bilateral_commit"]["roles"]["A"]["name"]
    elif name == "BSC_INDEX":
        doc["bilateral_commit"]["messages"][3]["evaluation_id"] = "wrong-evaluation"
        reseal_bsc_chain(doc)
    elif name == "BSC_EQUIVOCATION":
        original = next(
            message
            for message in doc["bilateral_commit"]["messages"]
            if message["kind"] == "Verdict" and message["from_role"] == "A"
        )
        conflicting = copy.deepcopy(original)
        conflicting["body"] = {"verdict": "Reject"}
        doc["bilateral_commit"]["messages"].append(conflicting)
        reseal_bsc_chain(doc)
    elif name == "WRONG_RESUME_EVIDENCE":
        ledger = next(item for item in doc["evidence_log"] if item["type"] == "LedgerConfirmation")
        doc["resume_claim"]["evidence_digest"] = ledger["digest"]
    elif name == "BAD_SIGNATURE":
        next(item for item in doc["evidence_log"] if item["type"] == "ProviderOutcome")["signature"] = "0" * 64
    elif name == "UNAUTHORIZED_SIGNER":
        next(record for record in doc["trust_root"]["authorities"] if record["evidence_type"] == "ProviderOutcome")["designated"] = False
    elif name == "REVOKED_SIGNER":
        doc["trust_root"]["revocations"] = [{"key_id": "provider-key", "effective_time": 1700000000}]
    elif name == "OCCURRENCE_KEY_MISMATCH":
        item = next(item for item in doc["evidence_log"] if item["type"] == "ProviderOutcome")
        item["payload"]["occurrence_key"] = "0" * 64
        seal_evidence(item, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "LOG_GAP":
        item = next(item for item in doc["evidence_log"] if item["type"] == "ProviderOutcome" and item["sequence"] == 4)
        item["sequence"] = 5
        seal_evidence(item, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "LOG_COMMITMENT":
        doc["evidence_log_commitment"]["digest"] = "0" * 64
    elif name == "FINALITY_NO_OUTCOME":
        item = reseal_item(doc, lambda value: value["type"] == "FinalityWitness")
        item["payload"]["outcome_digest"] = "0" * 64
        seal_evidence(item, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "FINALITY_BINDING_MISMATCH":
        item = next(item for item in doc["evidence_log"] if item["type"] == "FinalityWitness")
        item["payload"]["asset"] = "EUR"
        seal_evidence(item, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name.startswith("FINALITY_FIELD_"):
        field = name.removeprefix("FINALITY_FIELD_").lower()
        replacements = {
            "provider": "provider-two",
            "rail": "rail-two",
            "rulebook": "rulebook-two",
            "jurisdiction": "J-Z",
            "evaluation_time": 1700000031,
        }
        item = next(item for item in doc["evidence_log"] if item["type"] == "FinalityWitness")
        item["payload"][field] = replacements[field]
        seal_evidence(item, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "FINALITY_POLICY_IDENTITY":
        item = next(item for item in doc["evidence_log"] if item["type"] == "FinalityWitness")
        item["payload"]["legal_policy_id"] = ""
        seal_evidence(item, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "FINALITY_UNAUTHORIZED":
        next(record for record in doc["trust_root"]["authorities"] if record["evidence_type"] == "FinalityWitness")["designated"] = False
    elif name == "FINALITY_MISSING":
        doc["evidence_log"] = [item for item in doc["evidence_log"] if item["type"] != "FinalityWitness"]
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "DUPLICATE_RAIL_REVERSAL":
        duplicate = copy.deepcopy(doc["subsequent_graph"]["nodes"][1])
        duplicate["node_id"] = digest("op:subsequent-node:v1", {"duplicate": True})
        doc["subsequent_graph"]["nodes"].append(duplicate)
    elif name == "RAIL_REVERSAL_MISSING":
        doc["subsequent_graph"]["nodes"] = doc["subsequent_graph"]["nodes"][:1]
    elif name == "ORIGINAL_REWRITE":
        doc["subsequent_graph"]["nodes"][0]["amount"] = 101
    elif name == "BAD_RESIDUAL":
        doc["residuals"][0]["quantity"] = 39
    elif name == "RECONCILIATION_ERROR":
        key = next(iter(doc["reconciliation"]["claimed"]))
        doc["reconciliation"]["claimed"][key] = {"kind": "Break", "difference": 1}
    elif name == "RECONCILIATION_SOURCE":
        doc["reconciliation"]["local"]["unsigned-local-key"] = 7
    elif name in {"RECONCILIATION_NONMONOTONE", "RECONCILIATION_OVEREXECUTION"}:
        item = next(
            item
            for item in doc["evidence_log"]
            if item["type"] == "ProviderOutcome" and item["payload"]["phase"] == "Succeeded"
        )
        item["payload"]["quantity"] = 50 if name == "RECONCILIATION_NONMONOTONE" else 101
        item["payload"]["occurrence_key"] = occurrence_key(item["payload"])
        seal_evidence(item, doc["trust_root"]["keys"])
        finality = next(value for value in doc["evidence_log"] if value["type"] == "FinalityWitness")
        finality["payload"]["outcome_digest"] = item["digest"]
        seal_evidence(finality, doc["trust_root"]["keys"])
        doc["evidence_log_commitment"] = evidence_commitment(doc["evidence_log"])
    elif name == "UNCERTAINTY_CAP":
        doc["uncertainty"]["items"][0]["quantity"] = 26
    elif name == "ROUTE_COHERENCE":
        doc["corridor"]["route_consistent"] = False
        doc["trust_root"]["corridor_map_digest"] = digest("op:corridor-map:v1", doc["corridor"])
    elif name == "SEVEN_COORDINATE_SCHEMA":
        del doc["claimed_provider_state"]["obstructions"]
    elif name == "PROVIDER_STATE_MISMATCH":
        doc["claimed_provider_state"]["provider_phase"]["kind"] = "Succeeded"
    elif name == "BUNDLE_CHAIN":
        doc["claimed_bundle"][2]["prior"] = "0" * 64
    elif name == "BUNDLE_MISMATCH":
        entry = doc["claimed_bundle"][-1]
        entry["data"]["status"] = "changed"
        entry["digest"] = digest("op:bundle-entry:v1", without_fields(entry, {"digest"}))
    else:
        raise KeyError(name)
    return doc


def run_self_test() -> int:
    base = build_fixture()
    positive = verify_bytes(canonical_bytes(base))
    if not positive.accepted:
        print(json.dumps(positive.as_dict(), sort_keys=True))
        print("SELF-TEST FAILED: complete witness did not verify", file=sys.stderr)
        return 1
    print(f"ACCEPT positive_complete head={positive.bundle_head}")

    permuted = copy.deepcopy(base)
    permuted["evidence_log"] = list(reversed(permuted["evidence_log"]))
    permuted["evidence_log_commitment"] = evidence_commitment(permuted["evidence_log"])
    deterministic = verify_bytes(canonical_bytes(permuted))
    if not deterministic.accepted or deterministic.bundle_head != positive.bundle_head:
        print(json.dumps(deterministic.as_dict(), sort_keys=True))
        print("SELF-TEST FAILED: evidence permutation changed replay", file=sys.stderr)
        return 1
    print(f"ACCEPT deterministic_evidence_order head={deterministic.bundle_head}")

    abort_doc = copy.deepcopy(base)
    abort_messages = abort_doc["bilateral_commit"]["messages"]
    abort_messages[4]["body"]["verdict"] = "Reject"
    abort_messages[5]["body"]["decision"] = "Abort"
    abort_messages[6]["body"]["decision"] = "Abort"
    abort_doc["bilateral_commit"]["states"] = {
        "A": ["Init", "Locked", "Verified", "Aborted"],
        "B": ["Init", "Locked", "Verified", "Aborted"],
    }
    reseal_bsc_chain(abort_doc)
    abort_nodes, _abort_topo, _abort_dominators = graph_and_static_checks(abort_doc)
    _abort_program, abort_request, abort_operation, abort_await = validate_derived_program(abort_doc, abort_nodes)
    abort_bsc = validate_bilateral_commit(abort_doc, abort_operation)
    abort_ordered, abort_by_digest, abort_unique = validate_evidence(abort_doc, abort_request, abort_operation)
    abort_resume = validate_resume(abort_doc, abort_await, abort_by_digest, abort_ordered)
    abort_reconciliation = reconciliation_fold(abort_doc, abort_unique, abort_operation)
    abort_obstructions = uncertainty_obstructions(abort_doc)
    abort_doc["claimed_bundle"] = replay_bundle(
        abort_doc,
        abort_nodes,
        abort_bsc,
        abort_ordered,
        abort_resume,
        abort_reconciliation,
        abort_obstructions,
    )
    abort_result = verify_bytes(canonical_bytes(abort_doc))
    if not abort_result.accepted:
        print(json.dumps(abort_result.as_dict(), sort_keys=True))
        print("SELF-TEST FAILED: deterministic Abort transcript did not verify", file=sys.stderr)
        return 1
    print(f"ACCEPT bilateral_abort head={abort_result.bundle_head}")

    left_verdict = next(
        message
        for message in base["bilateral_commit"]["messages"]
        if message["kind"] == "Verdict" and message["from_role"] == "A"
    )
    right_verdict = copy.deepcopy(left_verdict)
    right_verdict["body"] = {"verdict": "Reject"}
    seal_bsc_message(right_verdict, base["trust_root"]["keys"])
    try:
        blame = extract_blame(
            left_verdict,
            right_verdict,
            base["bilateral_commit"]["roles"],
            base["trust_root"],
        )
    except RejectError as error:
        print(f"SELF-TEST FAILED: blame extraction rejected {error}", file=sys.stderr)
        return 1
    if blame["kind"] != "BlameWitness" or blame["role"] != "A":
        print("SELF-TEST FAILED: blame extraction named the wrong role", file=sys.stderr)
        return 1
    print(f"ACCEPT bilateral_blame_extraction witness={blame['digest']}")

    four_way = classify_reconciliation(
        {"matched": 5, "local-only": 7, "break": 9},
        {"matched": 5, "provider-only": 3, "break": 8},
    )
    expected_four_way = {
        "break": {"kind": "Break", "difference": 1},
        "local-only": {"kind": "OrphanLocal"},
        "matched": {"kind": "Matched", "quantity": 5},
        "provider-only": {"kind": "OrphanProvider"},
    }
    if four_way != expected_four_way:
        print("SELF-TEST FAILED: reconciliation classifier omitted a case", file=sys.stderr)
        return 1
    print("ACCEPT reconciliation_four_way cases=4")

    malformed_controls: list[tuple[str, bytes, str]] = [
        ("noncanonical_whitespace", json.dumps(base, ensure_ascii=False, sort_keys=True, indent=1).encode("utf-8"), "NONCANONICAL_ENCODING"),
        ("duplicate_key", b'{"schema":"a","schema":"b"}', "DUPLICATE_KEY"),
        ("malformed_bytes", b'{"schema":', "MALFORMED_BYTES"),
        ("float_forbidden", b'{"value":1.5}', "MALFORMED_NUMBER"),
    ]
    structured_controls = [
        "UNKNOWN_FIELD",
        "INTEGER_RANGE",
        "GRAPH_CYCLE",
        "UNREACHABLE_CYCLE",
        "MISSING_REVERSAL",
        "REVERSAL_MISMATCH",
        "MISSING_EFFECT_DECLARATION",
        "EFFECT_DECLARATION_MISMATCH",
        "DIRECT_WRITE",
        "LINEAR_DUPLICATE",
        "LINEAR_DROP",
        "LINEAR_JOIN",
        "SANCTIONS_BYPASS",
        "SANCTIONS_SUBJECT",
        "SANCTIONS_OMITTED_SUBJECT",
        "MISSING_FAILURE_RECEIPT",
        "IDEMPOTENCY_OVERCLAIM",
        "PROGRAM_DIGEST_MISMATCH",
        "REQUEST_DIGEST_MISMATCH",
        "UNTYPED_AWAIT",
        "BSC_ORDER",
        "BSC_LINEAR_LOCK",
        "BSC_VERIFIED_ENTRY",
        "BSC_DECISION",
        "BSC_ACK_MISMATCH",
        "BSC_SIGNATURE",
        "BSC_AUTHORITY",
        "BSC_EXPIRED_AUTHORITY",
        "BSC_PROGRAM_BINDING",
        "BSC_ARITY",
        "BSC_INDEX",
        "BSC_EQUIVOCATION",
        "WRONG_RESUME_EVIDENCE",
        "BAD_SIGNATURE",
        "UNAUTHORIZED_SIGNER",
        "REVOKED_SIGNER",
        "OCCURRENCE_KEY_MISMATCH",
        "LOG_GAP",
        "LOG_COMMITMENT",
        "FINALITY_NO_OUTCOME",
        "FINALITY_BINDING_MISMATCH",
        "FINALITY_FIELD_PROVIDER",
        "FINALITY_FIELD_RAIL",
        "FINALITY_FIELD_RULEBOOK",
        "FINALITY_FIELD_JURISDICTION",
        "FINALITY_FIELD_EVALUATION_TIME",
        "FINALITY_POLICY_IDENTITY",
        "FINALITY_UNAUTHORIZED",
        "FINALITY_MISSING",
        "DUPLICATE_RAIL_REVERSAL",
        "RAIL_REVERSAL_MISSING",
        "ORIGINAL_REWRITE",
        "BAD_RESIDUAL",
        "RECONCILIATION_ERROR",
        "RECONCILIATION_SOURCE",
        "RECONCILIATION_NONMONOTONE",
        "RECONCILIATION_OVEREXECUTION",
        "UNCERTAINTY_CAP",
        "ROUTE_COHERENCE",
        "SEVEN_COORDINATE_SCHEMA",
        "PROVIDER_STATE_MISMATCH",
        "BUNDLE_CHAIN",
        "BUNDLE_MISMATCH",
    ]

    failures = 0
    negative_count = 0
    for label, raw, expected in malformed_controls:
        result = verify_bytes(raw)
        negative_count += 1
        if result.accepted or result.code != expected or result.failure_receipt is None:
            failures += 1
            print(f"FAIL {label}: expected={expected} actual={result.code} accepted={result.accepted}")
        else:
            print(f"REJECT {label}: {result.code}")
    expected_aliases = {
        "BSC_EXPIRED_AUTHORITY": "BSC_AUTHORITY",
        "UNREACHABLE_CYCLE": "GRAPH_CYCLE",
        "FINALITY_FIELD_PROVIDER": "FINALITY_BINDING_MISMATCH",
        "FINALITY_FIELD_RAIL": "FINALITY_BINDING_MISMATCH",
        "FINALITY_FIELD_RULEBOOK": "FINALITY_BINDING_MISMATCH",
        "FINALITY_FIELD_JURISDICTION": "FINALITY_BINDING_MISMATCH",
        "FINALITY_FIELD_EVALUATION_TIME": "FINALITY_BINDING_MISMATCH",
        "FINALITY_POLICY_IDENTITY": "FINALITY_BINDING_MISMATCH",
        "FINALITY_UNAUTHORIZED": "UNAUTHORIZED_SIGNER",
        "RECONCILIATION_NONMONOTONE": "RECONCILIATION_SOURCE",
        "RECONCILIATION_OVEREXECUTION": "RECONCILIATION_SOURCE",
    }
    for control in structured_controls:
        expected = expected_aliases.get(control, control)
        result = verify_bytes(canonical_bytes(mutate(control, base)))
        negative_count += 1
        if result.accepted or result.code != expected or result.failure_receipt is None:
            failures += 1
            print(f"FAIL {control}: expected={expected} actual={result.code} accepted={result.accepted}")
        else:
            print(f"REJECT {control}: {result.code}")

    coverage = [
        "closed-canonical-parser",
        "acyclic-control-flow",
        "exhaustive-and-consistent-effect-reversal-declarations",
        "deferred-write-only",
        "linear-resource-conservation",
        "sanctions-dominance-and-subject-match",
        "typed-provider-suspension",
        "bilateral-session-order-linear-locks-verified-entry-and-ack",
        "deterministic-bilateral-decision-and-typed-blame",
        "provider-scope-authority-and-revocation",
        "request-source-route-binding",
        "occurrence-versus-assertion-deduplication",
        "deterministic-evidence-order-and-log-completeness",
        "provider-only-resumption",
        "separate-finality-witness-and-seven-field-binding",
        "partial-outcome-residual-child",
        "append-only-subsequent-effect-graph",
        "exactly-one-rail-reversal-per-occurrence",
        "matched-orphan-local-orphan-provider-and-break-reconciliation",
        "uncertain-effect-cap",
        "seven-coordinate-product-state",
        "cross-jurisdiction-verdict-separation",
        "proof-bundle-hash-chain-and-byte-replay",
        "closed-failure-receipts",
        "idempotency-assumption-boundary",
    ]
    print(f"COVERAGE {','.join(coverage)}")
    print(f"SUMMARY positive=5 negative={negative_count} coverage={len(coverage)} failures={failures}")
    return 1 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--self-test", action="store_true", help="run positive and injected-negative controls")
    group.add_argument("--verify", metavar="PATH", help="verify one canonical JSON document")
    group.add_argument("--emit-fixture", metavar="PATH", help="write the complete canonical test witness")
    args = parser.parse_args()
    if args.emit_fixture:
        with open(args.emit_fixture, "wb") as handle:
            handle.write(canonical_bytes(build_fixture()))
        return 0
    if args.verify:
        with open(args.verify, "rb") as handle:
            result = verify_bytes(handle.read())
        print(json.dumps(result.as_dict(), ensure_ascii=False, sort_keys=True))
        return 0 if result.accepted else 1
    return run_self_test()


if __name__ == "__main__":
    raise SystemExit(main())
