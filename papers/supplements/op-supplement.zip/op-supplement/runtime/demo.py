"""A fixed due receives two partial payments, closes, then receives a return."""
from pathlib import Path
import tempfile
from codec import encode, digest
from store import SettlementStore
from online import OnlineAdapter
from provider_fixture import SyntheticProvider
from replay import replay

def example(directory):
    directory = Path(directory)
    due = {"id": "due:example", "amount": "125", "asset": "USD", "unit": "cent", "payer": "payer-account", "payee": "payee-account"}
    store = SettlementStore.create(directory / "op.sqlite", 125)
    store.create_target(due["id"], 125, due["payee"], digest("resolved-due", due))
    provider = SyntheticProvider(directory / "provider.sqlite")
    adapter = OnlineAdapter(store)
    command = store.prepare(due["id"], "first-execution", 125)
    provider.plan(command, [40, 60], close=True)
    adapter.dispatch(command, provider)
    partial = store.settlement_export(due["id"])
    original = next(oid for oid, fact in partial["occurrences"].items() if fact["physical_quantity"]["decimal"] == "60")
    provider.post_return(command, original, 20)
    adapter.recover(provider)
    returned = store.settlement_export(due["id"])
    reconstructed = replay(store.export_journal())
    if reconstructed.state != store.read():
        raise ValueError("EXAMPLE_REPLAY")
    return {"due": due, "partial": partial, "after_return": returned, "pool": store.snapshot()["pool"], "provider_calls": provider.counts(), "journal_entries": reconstructed.entries, "journal_head": reconstructed.head}

if __name__ == "__main__":
    with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent, prefix="durable-demo-") as directory:
        print(encode(example(directory)).decode())
