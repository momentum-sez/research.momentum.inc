"""Process-isolated fault worker for the durable reference tests."""
import argparse
from pathlib import Path
from codec import parse
from store import SettlementStore
from online import OnlineAdapter
from provider_fixture import SyntheticProvider

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("directory", type=Path)
    p.add_argument("operation", choices=("prepare", "dispatch", "consume", "receive", "funding"))
    p.add_argument("--fault")
    p.add_argument("--key")
    p.add_argument("--target", default="target")
    p.add_argument("--amount", type=int, default=100)
    a = p.parse_args()
    store = SettlementStore(a.directory / "host.sqlite")
    if a.operation == "prepare":
        print(store.prepare(a.target, "attempt", a.amount, a.fault))
    elif a.operation == "dispatch":
        provider = SyntheticProvider(a.directory / "provider.sqlite", a.fault)
        OnlineAdapter(store).dispatch(a.key, provider, a.fault)
    elif a.operation == "consume":
        store.consume_local(a.fault)
    elif a.operation == "receive":
        store.receive(parse((a.directory / "callback.json").read_bytes()), a.fault)
    elif a.operation == "funding":
        store.record_backing_change("backing-loss", -40, a.fault)
