from copy import deepcopy
from pathlib import Path
import sqlite3
import tempfile
import unittest
from codec import encode, i64
from contract import SCOPE, CONTRACT
from historical import HistoricalPolicy, HistoricalInbox, TemporalPending, signed, provider_assertion, assertion_id
from model import validate
from online import OnlineAdapter
from replay import replay
from store import SettlementStore

REGISTRY = b"synthetic-registry-root"
CLOCK = b"synthetic-time-root"
HOST = b"synthetic-admission-root"
OLD = b"synthetic-old-provider-key"
NEW = b"synthetic-new-provider-key"


class HistoricalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.policy = HistoricalPolicy(REGISTRY, CLOCK, HOST)
        self.store = SettlementStore.create(root / "settlement.sqlite", 100, policy=self.policy)
        self.store.create_target("claim", 100, "payee", "immutable-entitlement")
        self.key = self.store.prepare("claim", "attempt", 100)
        self.store.commit("arm", {"command": self.key, "authority_epoch": 0})
        self.store.commit("transmit", {"command": self.key, "authority_epoch": 0})
        self.store.set_authority(False, "revoke-execution", 1)
        self.inbox = HistoricalInbox(root / "historical.sqlite", self.policy)

    def checkpoint(self, compromise="clear", compromised_from=None, complete=40):
        old = {"key": OLD.hex(), "scope": SCOPE, "contract": CONTRACT, "role": "attest", "from": 0, "until": 20,
               "compromise": compromise, "compromised_from": compromised_from}
        new = dict(old, key=NEW.hex(), **{"from": 20, "until": 100, "compromise": "clear", "compromised_from": None})
        return signed(REGISTRY, "key-checkpoint", {"epoch": 2 if compromise == "clear" else 3, "previous": "checkpoint-one", "as_of": 30,
            "complete_through": complete, "valid_until": 40, "keys": {"old": old, "new": new}})

    def statement(self, key_id="old", sequence=1, amount=40, event_time=9):
        body = {"provider": SCOPE, "contract": CONTRACT, "command": self.key,
            "request": self.store.read()["commands"][self.key]["request_digest"], "sequence": sequence,
            "kind": "payment", "occurrence": {"provider": SCOPE, "account": "payee", "asset": "USD", "unit": "cent",
                "namespace": "provider-posting-id", "epoch": "ledger-one", "reference": "physical-payment-one"},
            "amount": i64(amount), "reverses": None}
        return provider_assertion(OLD if key_id == "old" else NEW, key_id, body, event_time)

    def anchor(self, assertion, lo=9, hi=10, meaning="signing-interval"):
        return signed(CLOCK, "signature-time", {"assertion": assertion_id(assertion), "meaning": meaning, "lower": lo, "upper": hi})

    def admit(self, assertion=None, checkpoint=None, anchor=True):
        assertion = assertion or self.statement()
        return self.inbox.receive(assertion, current_checkpoint=checkpoint or self.checkpoint(),
            anchor=self.anchor(assertion) if anchor is True else anchor, admission_time=30)

    def test_late_retired_key_recovers_once_and_preserves_reservation(self):
        assertion = self.statement()
        admitted = self.admit(assertion)
        self.assertEqual(admitted["status"], "admitted")
        self.inbox.deliver(assertion_id(assertion), self.store)
        self.inbox.deliver(assertion_id(assertion), self.store)
        state = self.store.snapshot()
        self.assertEqual(state["targets"]["claim"]["paid"], "40")
        self.assertEqual(state["pool"]["reserved"], "60")
        self.assertFalse(self.store.read()["pool"]["permitted"])
        validate(self.store.read())

    def test_revoked_new_dispatch_cannot_call_provider(self):
        class NeverSubmit:
            def submit(self, *args):
                raise AssertionError("NEW_EXTERNAL_SUBMISSION")
        with self.assertRaisesRegex(ValueError, "CURRENT_USE_AUTHORITY"):
            OnlineAdapter(self.store).dispatch(self.key, NeverSubmit())

    def test_backdated_post_retirement_signature_rejected(self):
        assertion = self.statement(event_time=9)
        result = self.admit(assertion, anchor=self.anchor(assertion, 22, 23))
        self.assertEqual((result["status"], result["reason"]), ("rejected", "SIGNING_OUTSIDE_DESIGNATION"))
        self.assertEqual(self.store.snapshot()["pool"]["reserved"], "100")

    def test_compromise_before_signing_rejected(self):
        result = self.admit(checkpoint=self.checkpoint("known", 8))
        self.assertEqual((result["status"], result["reason"]), ("rejected", "COMPROMISED_SIGNING"))

    def test_interval_crossing_compromise_remains_pending(self):
        result = self.admit(checkpoint=self.checkpoint("known", 10))
        self.assertEqual((result["status"], result["reason"]), ("pending", "COMPROMISE_BOUNDARY_UNRESOLVED"))

    def test_missing_time_is_durable_and_reconsiderable(self):
        assertion = self.statement()
        self.assertEqual(self.admit(assertion, anchor=None)["status"], "pending")
        restarted = HistoricalInbox(self.inbox.path, self.policy)
        with self.assertRaises(TemporalPending):
            restarted.deliver(assertion_id(assertion), self.store)
        result = restarted.receive(assertion, current_checkpoint=self.checkpoint(), anchor=self.anchor(assertion), admission_time=30)
        self.assertEqual(result["status"], "admitted")
        with sqlite3.connect(self.inbox.path) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM attempts").fetchone()[0], 2)

    def test_inclusion_upper_bound_is_not_signing_interval(self):
        assertion = self.statement()
        result = self.admit(assertion, anchor=self.anchor(assertion, 9, 10, "existence-upper-bound"))
        self.assertEqual(result["reason"], "INSUFFICIENT_TIME_MEANING")

    def test_misattributed_anchor_or_signer_scope_fails(self):
        assertion = self.statement()
        other = self.statement(amount=41)
        self.assertEqual(self.admit(assertion, anchor=self.anchor(other))["reason"], "TIME_EVIDENCE_BINDING")
        view = self.checkpoint()["value"]
        view["keys"]["old"]["role"] = "dispatch"
        self.assertEqual(self.admit(assertion, checkpoint=signed(REGISTRY, "key-checkpoint", view))["reason"], "HISTORICAL_SCOPE")

    def test_incomplete_or_unknown_history_is_pending(self):
        self.assertEqual(self.admit(checkpoint=self.checkpoint(complete=29))["reason"], "CHECKPOINT_COVERAGE")
        self.assertEqual(self.admit(checkpoint=self.checkpoint("unknown"))["reason"], "COMPROMISE_INTERVAL_UNKNOWN")

    def test_successor_key_reports_historical_event_without_new_occurrence(self):
        old = self.statement()
        self.admit(old)
        self.inbox.deliver(assertion_id(old), self.store)
        new = self.statement("new", sequence=2)
        result = self.admit(new, anchor=self.anchor(new, 25, 26))
        self.assertEqual(result["status"], "admitted")
        self.inbox.deliver(assertion_id(new), self.store)
        self.assertEqual(len(self.store.read()["occurrences"]), 1)
        self.assertEqual(self.store.snapshot()["targets"]["claim"]["paid"], "40")

    def test_renewed_endorsement_same_body_preserves_single_stream_slot(self):
        old = self.statement()
        self.admit(old)
        self.inbox.deliver(assertion_id(old), self.store)
        new = self.statement("new")
        self.admit(new, anchor=self.anchor(new, 25, 26))
        self.inbox.deliver(assertion_id(new), self.store)
        state = self.store.read()
        self.assertEqual(state["assertions"][assertion_id(new)]["status"], "endorsement")
        self.assertEqual(len(state["occurrences"]), 1)
        self.assertFalse(state["alerts"])

    def test_later_compromise_appends_obstruction_and_replay_preserves_original(self):
        assertion = self.statement()
        record = self.admit(assertion)["record"]
        self.inbox.deliver(assertion_id(assertion), self.store)
        journal = self.store.export_journal()
        before = self.store.read()
        result = self.inbox.reassess(assertion_id(assertion), current_checkpoint=self.checkpoint("known", 8), evaluation_time=30, store=self.store)
        self.assertEqual(result["value"]["status"], "obstruction")
        self.assertEqual(result["value"]["reason"], "COMPROMISED_SIGNING")
        self.policy.verify(record)
        self.assertEqual(replay(journal, policy=self.policy).state, before)
        self.assertEqual(replay(self.store.export_journal(), policy=self.policy).state, self.store.read())
        self.assertEqual(self.store.snapshot()["pool"]["status"], "impaired")
        self.assertEqual(self.store.read()["occurrences"], before["occurrences"])
        self.assertEqual(self.store.read()["consumed"], before["consumed"])

    def test_tampered_admission_and_provider_signature_fail(self):
        assertion = self.statement()
        record = self.admit(assertion)["record"]
        bad = deepcopy(record)
        bad["value"]["admission_time"] = 31
        with self.assertRaisesRegex(ValueError, "SIGNED_RECORD_AUTHENTICATION"):
            self.policy.verify(bad)
        bad = deepcopy(assertion)
        bad["value"]["event_time"] = 8
        self.assertEqual(self.admit(bad)["reason"], "SIGNED_RECORD_AUTHENTICATION")

    def test_known_compromise_before_first_delivery_cannot_change_cash(self):
        assertion = self.statement()
        self.admit(assertion)
        self.inbox.reassess(assertion_id(assertion), current_checkpoint=self.checkpoint("known", 8), evaluation_time=30)
        self.inbox.deliver(assertion_id(assertion), self.store)
        state = self.store.read()
        self.assertEqual(state["assertions"][assertion_id(assertion)]["status"], "unsupported")
        self.assertEqual(state["occurrences"], {})
        self.assertEqual(self.store.snapshot()["pool"]["reserved"], "100")

    def test_reassessment_blocks_a_frozen_unconsumed_member(self):
        assertion = self.statement()
        record = self.admit(assertion)["record"]
        self.store.receive(record)
        self.store.commit("epoch", {})
        self.inbox.reassess(assertion_id(assertion), current_checkpoint=self.checkpoint("known", 8), evaluation_time=30, store=self.store)
        self.store.consume_local()
        self.assertEqual(self.store.read()["occurrences"], {})
        self.assertEqual(replay(self.store.export_journal(), policy=self.policy).state, self.store.read())

    def test_valid_successor_endorsement_recovers_unsupported_slot(self):
        old = self.statement()
        self.admit(old)
        self.inbox.reassess(assertion_id(old), current_checkpoint=self.checkpoint("known", 8), evaluation_time=30)
        self.inbox.deliver(assertion_id(old), self.store)
        new = self.statement("new")
        self.admit(new, checkpoint=self.checkpoint("known", 8), anchor=self.anchor(new, 25, 26))
        self.inbox.deliver(assertion_id(new), self.store)
        state = self.store.read()
        self.assertEqual(state["assertions"][assertion_id(old)]["status"], "unsupported")
        self.assertEqual(state["assertions"][assertion_id(new)]["status"], "applied")
        self.assertEqual(self.store.snapshot()["targets"]["claim"]["paid"], "40")
        self.assertEqual(self.store.snapshot()["pool"]["status"], "impaired")

    def test_same_assertion_with_another_admission_certificate_is_retained_once(self):
        assertion = self.statement()
        first = self.admit(assertion)["record"]
        second = self.policy.admit(assertion, current_checkpoint=self.checkpoint(), anchor=self.anchor(assertion), admission_time=31)
        self.store.receive(first)
        self.store.receive(second)
        self.store.receive(second)
        self.store.consume_local()
        state = self.store.read()
        self.assertEqual(state["assertions"][assertion_id(assertion)]["additional_admissions"], [second])
        self.assertEqual(len(state["consumed"]), 1)
        self.assertEqual(self.store.snapshot()["targets"]["claim"]["paid"], "40")
        self.assertEqual(replay(self.store.export_journal(), policy=self.policy).state, state)

    def test_sequence_blocked_admission_receives_reassessment_before_other_delivery(self):
        first = self.statement("new")
        second = self.statement(sequence=2, amount=10)
        value = deepcopy(second["value"])
        from codec import parse
        body = parse(value["body"].encode())
        body["occurrence"]["reference"] = "physical-payment-two"
        second = provider_assertion(OLD, "old", body, 9)
        self.admit(second)
        self.inbox.deliver(assertion_id(second), self.store)
        self.inbox.reassess(assertion_id(second), current_checkpoint=self.checkpoint("known", 8), evaluation_time=30)
        self.admit(first, checkpoint=self.checkpoint("known", 8), anchor=self.anchor(first, 25, 26))
        self.inbox.deliver(assertion_id(first), self.store)
        state = self.store.read()
        self.assertEqual(state["assertions"][assertion_id(second)]["status"], "unsupported")
        self.assertEqual(len(state["occurrences"]), 1)
        self.assertEqual(self.store.snapshot()["targets"]["claim"]["paid"], "40")

    def test_additional_admission_can_supply_bound_reassessment(self):
        assertion = self.statement()
        first = self.admit(assertion)["record"]
        second = self.policy.admit(assertion, current_checkpoint=self.checkpoint(), anchor=self.anchor(assertion), admission_time=31)
        self.store.receive(first)
        self.store.receive(second)
        review = self.policy.reassess(second, current_checkpoint=self.checkpoint("known", 8), evaluation_time=32)
        self.store.commit("evidence_reassessment", {"assertion": assertion_id(assertion), "record": review})
        self.store.consume_local()
        self.assertEqual(self.store.read()["occurrences"], {})
        self.assertEqual(self.store.read()["assertions"][assertion_id(assertion)]["status"], "unsupported")


if __name__ == "__main__":
    unittest.main(verbosity=2)
