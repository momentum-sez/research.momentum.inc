import ast
from copy import deepcopy
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from codec import encode, parse, digest, i64
from contract import SCOPE, CONTRACT, sign_fixture, occurrence_key
from model import target_view, pool_view, validate
from store import SettlementStore
from provider_fixture import SyntheticProvider
from online import OnlineAdapter, ProviderUnavailable
from replay import replay

ROOT = Path(__file__).resolve().parent
PYTHON = [sys.executable, "-B"] + (["-O"] if sys.flags.optimize else [])

class DurableTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT, prefix="durable-test-")
        self.root = Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()
    def setup(self, name="case", funding=100, target=100):
        path = self.root / name
        store = SettlementStore.create(path / "host.sqlite", funding)
        store.create_target("target", target, "payee", "payoff-source-digest")
        provider = SyntheticProvider(path / "provider.sqlite")
        return path, store, provider, OnlineAdapter(store)
    def run_worker(self, path, operation, fault=None, key=None, target="target", amount=100):
        cmd = PYTHON + [str(ROOT / "worker.py"), str(path), operation, "--target", target, "--amount", str(amount)]
        if fault: cmd += ["--fault", fault]
        if key: cmd += ["--key", key]
        return subprocess.run(cmd, capture_output=True)
    def check_replay(self, store):
        result = replay(store.export_journal())
        self.assertEqual(result.state, store.read())
        validate(result.state)
        return result
    def key(self, store, amount=100):
        return store.prepare("target", "attempt", amount)
    def envelope(self, store, key, sequence, kind, amount, reference=None, reverses=None):
        c = store.read()["commands"][key]
        identity = None
        if kind in {"payment", "return"}:
            identity = {"provider": SCOPE, "account": "payee" if kind == "payment" else "payer-account", "asset": "USD", "unit": "cent", "namespace": "provider-posting-id", "epoch": "account-ledger-1", "reference": reference}
        return sign_fixture({"provider": SCOPE, "contract": CONTRACT, "command": key, "request": c["request_digest"], "sequence": sequence, "kind": kind, "occurrence": identity, "amount": i64(amount), "reverses": reverses})

    def test_partial_target_closure_residual_child_and_return(self):
        _, s, p, a = self.setup(funding=125, target=125)
        k = self.key(s, 125)
        p.plan(k, [40], close=False)
        a.dispatch(k, p)
        v = s.snapshot()
        self.assertEqual((v["targets"]["target"]["paid"], v["targets"]["target"]["outstanding"], v["pool"]["reserved"]), ("40", "85", "85"))
        with self.assertRaisesRegex(ValueError, "TARGET_ALREADY_RESERVED"):
            s.prepare("target", "overlap", 85)
        second, envelope = p.post_payment(k, 60)
        s.receive(envelope); s.consume_local()
        s.receive(p.progress(k, 100)); s.consume_local()
        self.assertEqual(s.snapshot()["pool"]["reserved"], "25")
        with self.assertRaisesRegex(ValueError, "TARGET_ALREADY_RESERVED"):
            s.prepare("target", "unfenced-residual", 25)
        s.receive(p.close(k)); s.consume_local()
        self.assertEqual(s.snapshot()["targets"]["target"]["outstanding"], "25")
        child = s.prepare("target", "residual", 25)
        p.plan(child, [10, 15], close=True); a.dispatch(child, p)
        self.assertEqual(s.snapshot()["targets"]["target"]["status"], "paid")
        _, returned = p.post_return(k, second, 20)
        s.receive(returned); s.consume_local()
        self.assertEqual(s.snapshot()["targets"]["target"]["outstanding"], "20")
        self.assertEqual(s.snapshot()["pool"]["free"], "20")
        replacement = s.prepare("target", "returned-slice", 20)
        p.plan(replacement, [20], close=True); a.dispatch(replacement, p)
        self.assertEqual(s.snapshot()["targets"]["target"]["status"], "paid")
        rows = s.allocation_rows("target")
        self.assertEqual(sum(int(r["quantity"]) * (1 if r["kind"] == "payment" else -1) for r in rows), 125)
        self.assertEqual(p.counts()["commands"], 3)
        self.check_replay(s)

    def test_offline_restart_consumes_durable_inbox_first(self):
        _, s, p, a = self.setup()
        k = self.key(s)
        p.plan(k, [30, 40], close=True)
        # Provider succeeds; callbacks are durable but remain unconsumed.
        s.commit("arm", {"command": k, "authority_epoch": 0})
        c = s.read()["commands"][k]
        for e in p.submit(k, c["request_digest"], encode(c["request"])): s.receive(e)
        before = p.counts(); p.available(False)
        restarted = OnlineAdapter(SettlementStore(s.path))
        result = restarted.recover(p)
        self.assertEqual(p.counts()["submits"], before["submits"])
        self.assertEqual(p.counts()["recovers"], before["recovers"]+1)
        self.assertEqual((result["targets"]["target"]["outstanding"], result["pool"]["reserved"]), ("30", "0"))
        self.check_replay(s)

    def test_offline_partial_retains_uncertain_reservation(self):
        _, s, p, a = self.setup()
        k = self.key(s); p.plan(k, [35], close=False)
        s.commit("arm", {"command": k, "authority_epoch": 0})
        c = s.read()["commands"][k]
        for e in p.submit(k, c["request_digest"], encode(c["request"])): s.receive(e)
        p.available(False)
        result = a.recover(p)
        self.assertEqual(result["commands"][k]["status"], "uncertain")
        self.assertEqual((result["targets"]["target"]["outstanding"], result["pool"]["reserved"]), ("65", "65"))
        self.check_replay(s)

    def test_duplicate_assertions_and_physical_occurrences(self):
        _, s, p, a = self.setup(); k = self.key(s)
        a.dispatch(k, p)
        oid, e = p.post_payment(k, 40)
        for _ in range(3): s.receive(e)
        s.receive(p.repeat_assertion(k, oid)); s.receive(p.progress(k, 40)); s.consume_local()
        self.assertEqual((len(s.read()["occurrences"]), s.snapshot()["targets"]["target"]["paid"], s.snapshot()["pool"]["reserved"]), (1, "40", "60"))
        self.check_replay(s)

    def test_relabelled_occurrence_cannot_fund_two_commands(self):
        _,s,p,a=self.setup(funding=200)
        s.create_target("second",100,"payee","second-source")
        first=self.key(s);second=s.prepare("second","attempt",100)
        a.dispatch(first,p);a.dispatch(second,p)
        _,e=p.post_payment(first,40,"one-physical-credit")
        s.receive(e);s.consume_local()
        s.receive(self.envelope(s,second,1,"payment",40,"one-physical-credit"));s.consume_local()
        view=s.snapshot()
        self.assertEqual((view["pool"]["cash"],view["targets"]["target"]["paid"],view["targets"]["second"]["paid"]),("160","40","0"))
        self.assertEqual(view["pool"]["reserved"],"160")
        self.assertEqual(view["pool"]["status"],"impaired")
        self.check_replay(s)

    def test_export_preserves_physical_excess_and_supported_return(self):
        _, s, p, a = self.setup(); k = self.key(s); a.dispatch(k, p)
        payment = self.envelope(s, k, 1, "payment", 120, "excess-credit")
        oid = occurrence_key(parse(payment["body"].encode())["occurrence"])
        s.receive(payment); s.consume_local()
        s.receive(self.envelope(s, k, 2, "return", 30, "excess-return", oid)); s.consume_local()
        exported = s.settlement_export("target")
        rows = {r["data"]["kind"]: r["data"] for r in exported["receipts"]}
        self.assertEqual((rows["payment"]["physical_quantity"], rows["payment"]["quantity"]), (i64(120), i64(100)))
        self.assertEqual((rows["return"]["physical_quantity"], rows["return"]["quantity"]), (i64(30), i64(10)))
        for row in rows.values():
            fact = exported["occurrences"][row["occurrence"]]
            self.assertEqual(row["physical_identity"], fact["identity"])
            self.assertEqual(row["physical_quantity"], fact["physical_quantity"])
            self.assertEqual(occurrence_key(fact["identity"]), row["occurrence"])
        self.assertEqual((exported["view"]["outstanding"], s.snapshot()["pool"]["cash"]), ("10", "10"))
        self.check_replay(s)

    def test_closed_command_return_poll_does_not_redispatch(self):
        _,s,p,a=self.setup();k=self.key(s);p.plan(k,[100],close=True);a.dispatch(k,p)
        original=next(oid for oid,o in s.read()["occurrences"].items() if o["kind"]=="payment")
        p.post_return(k,original,25)
        before=p.counts()["submits"]
        a.recover(p,include_closed=True)
        self.assertEqual(p.counts()["submits"],before)
        self.assertEqual((s.snapshot()["targets"]["target"]["outstanding"],s.snapshot()["pool"]["free"]),("25","25"))
        self.check_replay(s)

    def test_unfunded_target_remains_pending_until_one_pool_receives_funding(self):
        _,s,p,a=self.setup(funding=0);self.assertEqual(s.snapshot()["targets"]["target"]["status"],"pending")
        with self.assertRaisesRegex(ValueError,"AGGREGATE_FUNDING"):self.key(s)
        s.record_backing_change("actual-synthetic-credit",100)
        k=self.key(s);p.plan(k,[20,30,50],close=True);a.dispatch(k,p)
        self.assertEqual(s.snapshot()["targets"]["target"]["status"],"paid")
        self.check_replay(s)

    def test_return_before_linked_payment_resolves_without_lost_cash(self):
        _, s, p, a = self.setup(); k = self.key(s); a.dispatch(k, p)
        payment = self.envelope(s, k, 2, "payment", 100, "late-credit")
        oid = occurrence_key(parse(payment["body"].encode())["occurrence"])
        returned = self.envelope(s, k, 1, "return", 40, "early-return", oid)
        s.receive(returned); s.consume_local()
        self.assertEqual((s.snapshot()["pool"]["cash"], s.snapshot()["pool"]["unmatched_returns"], s.snapshot()["targets"]["target"]["outstanding"]), ("140", "40", "100"))
        self.assertEqual(len(s.read()["pending_returns"]), 1)
        self.assertEqual(s.settlement_export("target")["receipts"],[])
        s.receive(payment); s.consume_local()
        self.assertEqual((s.snapshot()["pool"]["cash"], s.snapshot()["pool"]["unmatched_returns"], s.snapshot()["targets"]["target"]["outstanding"]), ("40", "0", "40"))
        self.assertFalse(s.read()["pending_returns"])
        exported=s.settlement_export("target")
        self.assertEqual(len(exported["receipts"]),2)
        self.assertEqual(sum(int(r["data"]["quantity"]["decimal"])*(1 if r["data"]["kind"]=="payment" else -1) for r in exported["receipts"]),60)
        old_receipts=deepcopy(exported["receipts"])
        s.receive(returned);s.consume_local()
        self.assertEqual(s.settlement_export("target")["receipts"],old_receipts)
        self.check_replay(s)

    def test_conflicting_occurrence_is_retained_and_impairs_dispatch(self):
        _, s, p, a = self.setup(); k = self.key(s); a.dispatch(k, p)
        _, e = p.post_payment(k, 40, "same-root")
        s.receive(e); s.consume_local()
        conflict = self.envelope(s, k, 2, "payment", 45, "same-root")
        s.receive(conflict); s.consume_local()
        v = s.snapshot()
        self.assertEqual((len(s.read()["occurrences"]), v["targets"]["target"]["paid"], v["pool"]["reserved"]), (1, "40", "60"))
        self.assertEqual(v["commands"][k]["status"], "impaired")
        with self.assertRaisesRegex(ValueError, "FUNDING_IMPAIRED"): a.dispatch(k, p)
        self.check_replay(s)

    def test_equivocation_after_epoch_freeze_does_not_apply_conflicted_payment(self):
        _, s, p, a = self.setup(); k = self.key(s); a.dispatch(k, p)
        e = self.envelope(s, k, 1, "payment", 40, "a")
        s.receive(e); s.receive(self.envelope(s, k, 2, "payment", 20, "b")); s.commit("epoch", {})
        s.receive(self.envelope(s, k, 1, "payment", 45, "a")); s.consume_local()
        self.assertEqual(s.snapshot()["targets"]["target"]["paid"], "0")
        self.assertEqual(s.snapshot()["pool"]["reserved"], "100")
        self.assertTrue(s.snapshot()["alerts"])
        self.check_replay(s)

    def test_backing_loss_and_current_authority_do_not_erase_reservations(self):
        _, s, p, a = self.setup(); k = self.key(s, 80)
        s.record_backing_change("loss", -40)
        self.assertEqual((s.snapshot()["pool"]["reserved"], s.snapshot()["pool"]["deficit"]), ("80", "20"))
        with self.assertRaisesRegex(ValueError, "FUNDING_IMPAIRED"): a.dispatch(k, p)
        s.record_backing_change("restored", 40)
        s.set_authority(False, "revocation", 1)
        with self.assertRaisesRegex(ValueError, "CURRENT_USE_AUTHORITY"): a.dispatch(k, p)
        self.assertEqual(p.counts()["submits"], 0)
        s.set_authority(True, "new-authority", 2)
        p.plan(k, [30], close=False); a.dispatch(k, p)
        s.set_authority(False, "later-revocation", 3)
        _, e = p.post_payment(k, 20); s.receive(e); a.recover(None)
        self.assertEqual((s.snapshot()["targets"]["target"]["paid"], s.snapshot()["pool"]["reserved"]), ("50", "30"))
        with self.assertRaisesRegex(ValueError, "CURRENT_USE_AUTHORITY"): a.dispatch(k, p)
        self.check_replay(s)

    def test_immutable_target_retry_and_explicit_cancellation(self):
        _, s, p, a = self.setup()
        s.cancel_target("target", 20, "amendment")
        s.create_target("target", 100, "payee", "payoff-source-digest")
        self.assertEqual(s.snapshot()["targets"]["target"]["cancelled"], "20")
        with self.assertRaisesRegex(ValueError, "FIXED_TARGET_CONFLICT"): s.create_target("target", 80, "payee", "payoff-source-digest")
        k = self.key(s, 80)
        with self.assertRaisesRegex(ValueError, "UNFENCED_CANCELLATION"): s.cancel_target("target", 1, "invalid")
        s.commit("cancel_prepared", {"command": k})
        a.dispatch(k, p)
        self.assertEqual(p.counts()["submits"], 0)
        self.assertEqual(s.snapshot()["targets"]["target"]["outstanding"], "80")
        self.check_replay(s)

    def test_authority_and_cancellation_evidence_replay_is_idempotent(self):
        _,s,p,a=self.setup()
        s.cancel_target("target",20,"amendment")
        s.cancel_target("target",20,"amendment")
        self.assertEqual(s.snapshot()["targets"]["target"]["cancelled"],"20")
        with self.assertRaisesRegex(ValueError,"CANCELLATION_EVIDENCE_CONFLICT"):s.cancel_target("target",30,"amendment")
        s.set_authority(True,"grant-1",1)
        s.set_authority(False,"revoke-2",2)
        epoch=s.read()["pool"]["authority_epoch"]
        s.set_authority(True,"grant-1",1)
        s.set_authority(True,"delayed-other-grant",1)
        self.assertFalse(s.read()["pool"]["permitted"])
        self.assertEqual(s.read()["pool"]["authority_epoch"],epoch)
        s.cancel_target("target",20,"amendment")
        self.assertEqual(s.snapshot()["targets"]["target"]["cancelled"],"20")
        with self.assertRaisesRegex(ValueError,"AUTHORITY_EVIDENCE_CONFLICT"):s.set_authority(True,"revoke-2",2)
        s.set_authority(True,"grant-3",3)
        self.assertTrue(s.read()["pool"]["permitted"])
        self.check_replay(s)

    def test_unsolicited_forward_evidence_is_recorded_as_a_breach(self):
        _,s,p,a=self.setup();k=self.key(s)
        s.receive(self.envelope(s,k,1,"payment",40,"unsolicited"));s.consume_local()
        view=s.snapshot()
        self.assertEqual((view["pool"]["cash"],view["targets"]["target"]["paid"],view["targets"]["target"]["outstanding"]),("60","0","100"))
        self.assertEqual(view["commands"][k]["status"],"impaired")
        self.check_replay(s)

    def test_two_useful_commands_share_one_funded_pool_concurrently(self):
        path, s, p, a = self.setup(target=60)
        s.create_target("second", 40, "other-payee", "second-payoff")
        processes = [subprocess.Popen(PYTHON+[str(ROOT/"worker.py"),str(path),"prepare","--target",t,"--amount",str(q)],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for t,q in [("target",60),("second",40)]]
        keys=[]
        for child in processes:
            out,err=child.communicate(); self.assertEqual(child.returncode,0,err); keys.append(out.decode().strip())
        self.assertEqual(s.snapshot()["pool"]["reserved"], "100")
        p.plan(keys[0],[20,40],close=True);p.plan(keys[1],[10,30],close=True)
        children=[subprocess.Popen(PYTHON+[str(ROOT/"worker.py"),str(path),"dispatch","--key",k],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for k in keys]
        for child in children:
            _,err=child.communicate();self.assertEqual(child.returncode,0,err)
        a.recover(p)
        self.assertEqual((s.snapshot()["pool"]["cash"],s.snapshot()["pool"]["reserved"]),("0","0"))
        self.assertEqual((s.snapshot()["targets"]["target"]["paid"],s.snapshot()["targets"]["second"]["paid"]),("60","40"))
        self.assertEqual(p.counts()["occurrences"],4)
        self.check_replay(s)

    def test_concurrent_overreservation_is_rejected_globally(self):
        path,s,p,a=self.setup();s.create_target("second",60,"other-payee","second-payoff")
        children=[subprocess.Popen(PYTHON+[str(ROOT/"worker.py"),str(path),"prepare","--target",t,"--amount","60"],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for t in ["target","second"]]
        results=[(child.communicate(),child.returncode) for child in children]
        self.assertEqual(sorted(code for _,code in results),[0,1])
        self.assertTrue(any(b"AGGREGATE_FUNDING" in output[1] for output,_ in results))
        self.assertEqual(s.snapshot()["pool"]["reserved"],"60")
        self.check_replay(s)

    def test_late_evidence_and_replay_have_no_external_effect(self):
        _,s,p,a=self.setup();k=self.key(s);a.dispatch(k,p)
        _,first=p.post_payment(k,30);_,second=p.post_payment(k,20)
        s.receive(second);s.consume_local()
        self.assertEqual(s.snapshot()["targets"]["target"]["paid"],"0")
        prefix=s.export_journal();prefix_result=replay(prefix)
        s.receive(first);s.consume_local()
        self.assertEqual(s.snapshot()["targets"]["target"]["paid"],"50")
        before=p.counts()
        self.assertEqual(replay(prefix),prefix_result)
        self.check_replay(s);self.check_replay(s)
        self.assertEqual(p.counts(),before)
        tree=ast.parse((ROOT/"replay.py").read_text())
        imports=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
        self.assertFalse(set(imports)&{"online","provider_fixture","store"})
        broken=parse(s.export_journal());broken[-1]["state_hash"]="bad"
        with self.assertRaisesRegex(ValueError,"JOURNAL_STATE"):replay(encode(broken))

    def test_process_crashes_at_atomic_reservation_and_backing_changes(self):
        for operation in ("prepare","funding"):
            for stage in ("before","inside","after"):
                with self.subTest(operation=operation,stage=stage):
                    path,s,p,a=self.setup(name=operation+stage)
                    if operation=="funding":self.key(s,80)
                    result=self.run_worker(path,operation,stage+"_"+operation)
                    self.assertEqual(result.returncode,77,result.stderr)
                    if operation=="prepare":
                        self.assertEqual(s.snapshot()["pool"]["reserved"],"100" if stage=="after" else "0")
                        s.prepare("target","attempt",100)
                        self.assertEqual(s.snapshot()["pool"]["reserved"],"100")
                    else:
                        self.assertEqual(s.snapshot()["pool"]["cash"],"60" if stage=="after" else "100")
                        s.record_backing_change("backing-loss",-40)
                        self.assertEqual((s.snapshot()["pool"]["cash"],s.snapshot()["pool"]["reserved"]),("60","80"))
                    self.check_replay(s)

    def test_process_crashes_around_receive_and_consume(self):
        for operation in ("receive","epoch","consume","finish_epoch"):
            for stage in ("before","inside","after"):
                with self.subTest(operation=operation,stage=stage):
                    path,s,p,a=self.setup(name=operation+stage);k=self.key(s)
                    a.dispatch(k,p);_,e=p.post_payment(k,40)
                    if operation=="receive":
                        (path/"callback.json").write_bytes(encode(e))
                        result=self.run_worker(path,"receive",stage+"_receive")
                        self.assertEqual(result.returncode,77,result.stderr)
                        self.assertEqual(len(s.read()["assertions"]),int(stage=="after"))
                        s.receive(e)
                    else:
                        s.receive(e)
                        result=self.run_worker(path,"consume",stage+"_"+operation)
                        self.assertEqual(result.returncode,77,result.stderr)
                        paid=s.snapshot()["targets"]["target"]["paid"]
                        self.assertEqual(paid,"40" if operation=="finish_epoch" or (operation=="consume" and stage=="after") else "0")
                        self.assertEqual(int(s.snapshot()["pool"]["cash"]),100-int(paid))
                        self.assertEqual(int(s.snapshot()["pool"]["reserved"]),100-int(paid))
                    p.available(False);a.recover(p)
                    self.assertEqual((s.snapshot()["targets"]["target"]["paid"],s.snapshot()["pool"]["reserved"]),("40","60"))
                    self.assertEqual(len(s.read()["consumed"]),1)
                    self.check_replay(s)

    def test_process_crashes_at_arm_transmit_and_provider_commit(self):
        points=[f"{stage}_{kind}" for kind in ("arm","transmit") for stage in ("before","inside","after")]+["before_provider","inside_provider","after_provider"]
        for point in points:
            with self.subTest(point=point):
                path,s,p,a=self.setup(name=point);k=self.key(s);p.plan(k,[40],close=False)
                result=self.run_worker(path,"dispatch",point,key=k)
                self.assertEqual(result.returncode,77,result.stderr)
                self.assertEqual(s.snapshot()["pool"]["reserved"],"100")
                a.recover(p);a.dispatch(k,p);a.dispatch(k,p)
                self.assertEqual((s.snapshot()["targets"]["target"]["paid"],s.snapshot()["pool"]["reserved"]),("40","60"))
                self.assertEqual((p.counts()["commands"],p.counts()["occurrences"]),(1,1))
                self.check_replay(s)

if __name__=="__main__":unittest.main(verbosity=2)
