"""Executable finite transition, witness, screening, and epoch constructions.

The finite registry below is its actual checked transition relation. It is not a
claim of refinement for the complete Op language or a production authority feed.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from canonical_profile import digest

@dataclass(frozen=True)
class State:
    grant: bool=False
    balance: int=0
    holds: frozenset[str]=frozenset()

STATES=tuple(State(g,b,frozenset(h)) for g,b,h in product((False,True),range(3),((),("h",))))
DEPENDENCIES={"authorized":frozenset({"grant"}),"funded":frozenset({"balance"}),"clear":frozenset({"holds"})}
WRITES={"grant":frozenset({"grant"}),"revoke":frozenset({"grant"}),"topup":frozenset({"balance"}),"spend":frozenset({"balance"}),"hold":frozenset({"holds"}),"unhold":frozenset({"holds"})}

def predicate(name:str,s:State)->bool:
    if name=="authorized":return s.grant
    if name=="funded":return s.balance>=1
    if name=="clear":return not s.holds
    raise ValueError("PREDICATE")

def step(name:str,s:State)->State:
    if name=="grant":return State(True,s.balance,s.holds)
    if name=="revoke":return State(False,s.balance,s.holds)
    if name=="topup":return State(s.grant,min(2,s.balance+1),s.holds)
    if name=="spend":return State(s.grant,0,s.holds)
    if name=="hold":return State(s.grant,s.balance,frozenset({"h"}))
    if name=="unhold":return State(s.grant,s.balance,frozenset())
    raise ValueError("TRANSITION")

def execute(program:tuple[str,...],s:State)->State:
    for op in program:s=step(op,s)
    return s

def certificate(kind:str,p:str,program:tuple[str,...],entry:tuple[str,...]=())->bool:
    # The finite transition table is exhausted. No unverified preservation hint is accepted.
    if kind=="frame":
        return not (DEPENDENCIES[p] & frozenset().union(*(WRITES[op] for op in program)))
    if kind not in {"preserve","reestablish"}:raise ValueError("CERTIFICATE")
    domain=[s for s in STATES if all(predicate(a,s) for a in entry)]
    if kind=="preserve":domain=[s for s in domain if predicate(p,s)]
    return all(predicate(p,execute(program,s)) for s in domain)

class WitnessMachine:
    def __init__(self,state:State):
        self.state=state;self.cursor=0;self.current={};self.history=[]
    def establish(self,p:str):
        if not predicate(p,self.state):raise ValueError("FALSE_PREDICATE")
        self.current[p]=self.cursor
        self.history.append((self.cursor,p,self.state))
    def advance(self,op:str,certificates:dict[str,str]|None=None):
        certificates=certificates or {};old=self.state;self.state=step(op,old);self.cursor+=1
        kept={}
        for p in self.current:
            kind=certificates.get(p,"frame")
            if certificate(kind,p,(op,)) and predicate(p,self.state):kept[p]=self.cursor
        self.current=kept
        self.history.append((self.cursor,op,self.state))
    def use(self,p:str,cursor:int|None=None):
        if self.current.get(p)!=self.cursor or (cursor is not None and cursor!=self.cursor):
            raise ValueError("STALE_WITNESS")
        return True

@dataclass(frozen=True)
class Screen:
    subject:str
    jurisdiction:str
    policy:str
    issued:int
    identity:str

def screen_join(operands:dict[str,Screen|None],subject:str,jurisdiction:str,policy:str)->dict[str,Screen]:
    if not operands:raise ValueError("MISSING_PREDECESSORS")
    for w in operands.values():
        if w is None or (w.subject,w.jurisdiction,w.policy)!=(subject,jurisdiction,policy):
            raise ValueError("UNCOVERED_PATH")
    return dict(operands)

def select_screen(operands:dict[str,Screen],edge:str,now:int,max_age:int)->Screen:
    w=operands[edge]
    if not 0<=now-w.issued<=max_age:raise ValueError("STALE_SCREEN")
    return w

class EpochLog:
    def __init__(self):
        self.inbox={};self.frontiers={};self.admitted=[];self.epochs=[];self.consumed={};self.used=set()
    def receive(self,stream:str,sequence:int,event_time:int,identity:str):
        if sequence<1:raise ValueError("SEQUENCE")
        key=(stream,sequence);item={"stream":stream,"sequence":sequence,"time":event_time,"identity":identity}
        if key in self.inbox and self.inbox[key]!=item:raise ValueError("STREAM_CONFLICT")
        self.inbox[key]=item
        next_sequence=self.frontiers.get(stream,0)+1
        while (stream,next_sequence) in self.inbox:
            self.admitted.append(dict(self.inbox[(stream,next_sequence)],ordinal=len(self.admitted)+1))
            self.frontiers[stream]=next_sequence;next_sequence+=1
    def commit(self,trust:str,state:str):
        epoch={"previous":self.epochs[-1][0] if self.epochs else "genesis",
               "frontier":len(self.admitted),"members":[dict(x) for x in self.admitted],
               "streams":dict(self.frontiers),"trust":trust,"state":state}
        root=digest("epoch",epoch);self.epochs.append((root,epoch));return root,epoch
    def consume(self,continuation:str,epoch:dict,root:str,stream:str|None=None):
        if digest("epoch",epoch)!=root:raise ValueError("EPOCH_ROOT")
        if root not in {r for r,_ in self.epochs}:raise ValueError("UNCOMMITTED_EPOCH")
        if continuation in self.consumed:return self.consumed[continuation]
        candidates=[x for x in epoch["members"] if x["ordinal"] not in self.used and (stream is None or x["stream"]==stream)]
        if not candidates:raise ValueError("SUSPENDED")
        first=min(candidates,key=lambda x:x["ordinal"])
        receipt=digest("continuation",{"continuation":continuation,"epoch":root,"ordinal":first["ordinal"]})
        result=(first["identity"],receipt);self.consumed[continuation]=result;self.used.add(first["ordinal"]);return result
