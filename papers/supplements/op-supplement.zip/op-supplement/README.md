# Op: Compliance-Carrying Operations — executable supplement

This archive supplies the executable references described in the paper dated September 2026.
The source files retain their original bytes.

## Contents

- `verify_op.py` contains the bounded instruction verifier and its complete witness and mutation fixtures.
- `canonical_profile.py` and `canonical_profile.mjs` implement the exact-integer canonical encoding profile.
- `semantic_core.py` supplies the finite witness, screening, intent, and epoch constructions.
- `reference_adapter.py` supplies the persistent single-step adapter.
- `test_upgrade.py` tests these constructions and their canonical encodings.
- `runtime/` contains the shared-pool settlement model, persistent stores, provider fixture, recovery, and historical-attestation admission.
- `runtime/test_durable.py` and `runtime/test_historical.py` contain their fixtures and tests.

The `runtime/codec.py` import requires `canonical_profile.py` in its parent directory.
Preserve this directory layout.
The fixtures are defined in the Python sources and require no external event records.

## Requirements

Use Python 3.10 or later with SQLite support.
Use a Node.js runtime whose Unicode table identifier is `17.0`.
The Python dependency is pinned to `unicodedata2==17.0.1`, which supplies Unicode tables `17.0.0`.
The modules reject other Unicode tables at startup.
The Python dependency is installed for the reader's platform.
No platform-specific compiled extension is included in this archive.

From the extracted `op-supplement` directory:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -c 'import unicodedata2; print(unicodedata2.unidata_version)'
node -p 'process.versions.unicode'
```

The last two commands must print `17.0.0` and `17.0`, respectively.
Use a directory that permits temporary files and SQLite databases.
The tests create synthetic provider databases and terminate child processes at specified recovery boundaries.

## Reproduction

Run the following commands from the extracted archive root:

```sh
python3 -B verify_op.py --self-test
python3 -B -O verify_op.py --self-test
python3 -B -m unittest -v test_upgrade
python3 -B -O -m unittest -v test_upgrade
(cd runtime && python3 -B -m unittest -v test_historical test_durable)
(cd runtime && python3 -B -O -m unittest -v test_historical test_durable)
```

The bounded verifier reports five positive cases, 67 negative controls, 25 coverage classes, and zero failures.
The upgrade suite runs 11 tests.
The runtime suite runs 19 historical-admission tests and 21 durable-settlement tests.
Every command must exit with code zero.

To export and verify the bounded verifier's complete witness:

```sh
python3 -B verify_op.py --emit-fixture fixture.json
python3 -B verify_op.py --verify fixture.json
```

To check the packaged file hashes before creating local test output:

```sh
shasum -a 256 -c MANIFEST.sha256
```

## Recorded validation

Checks completed on 6 September 2026 (UTC+07:00), using Python 3.14.6 and Node.js 25.2.1.
The Python and Node Unicode tables were `17.0.0` and `17.0`.
All six test commands and the exported-fixture check passed from a fresh extraction.
These checks cover the supplied reference models and their stated assumptions.

## Scope

These programs exercise the finite models identified in the paper.
The bounded verifier retains its stated screening, serialization, occurrence-identity, and evidence-order differences from the specified language.
The separate canonical and settlement modules supply the corresponding named evidence.
The deterministic signature fixtures and synthetic HMAC roots test control, message binding, and temporal admission.
Production cryptography, authenticated authority feeds, timing evidence, event completeness, provider behavior, and institutional contracts retain the paper's external assumptions.
Full-language refinement and the other stated implementation obligations remain separate.

## Rights and dependency notice

The supplied first-party source files contain no attached license declaration.
This archive introduces no additional license grant.
The included third-party notice in `third-party/unicodedata2-LICENSE.txt` applies to the separately installed `unicodedata2` dependency.
