from __future__ import annotations
import hashlib
import hmac
import itertools
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from canonical_profile import SAFE, I64_MIN, I64_MAX, encode,parse,i64,decode_i64,digest
import reference_adapter as adapter
import semantic_core as core

ROOT=Path(__file__).resolve().parent
PYTHON=[sys.executable]+(["-O"] if sys.flags.optimize else [])

class CanonicalTests(unittest.TestCase):
    def test_independent_javascript_vectors(self):
        values=[None,True,False,0,SAFE,-SAFE,{"\ue000":1,"\U00010000":2},["é","𐀀","\n",{"2":2,"10":10}],"\U000105c9"]
        requests=[{"value":v} for v in values]
        requests += [{"value":i64(v),"i64":True} for v in [0,1,-1,2**53+1,I64_MIN,I64_MAX]]
        requests += [{"value":v} for v in [SAFE+1,2**53+1,"e\u0301","\ud800","\ufdd0","\U000105d2\u0307"]]
        requests += [{"value":{"type":"i64","decimal":v},"i64":True} for v in ["01","-0","1\n",str(I64_MAX+1)]]
        node=subprocess.check_output(["node",str(ROOT/"canonical_profile.mjs")],input=json.dumps(requests).encode())
        results=json.loads(node)
        for request,result in zip(requests,results):
            with self.subTest(request=request):
                try:
                    b=encode(request["value"]).decode()
                    n=str(decode_i64(request["value"])) if request.get("i64") else None
                except ValueError:
                    self.assertFalse(result["ok"])
                else:
                    self.assertEqual(result,{"ok":True,"bytes":b,"integer":n})
        self.assertEqual(encode({"\ue000":1,"\U00010000":2}).hex(),"7b22f0908080223a322c22ee8080223a317d")

    def test_wire_rejection_and_exact_roundtrip(self):
        for b in [b'{"a":1,"\\u0061":2}',b'9007199254740993',b'9007199254740991.1',b'1e-999',b'-0',b'1.0',b'1e0',b'"\\ud800"',b'"\\u00e9"',b'{"b":0,"a":1}',b'NaN']:
            with self.subTest(b=b),self.assertRaises(ValueError):parse(b)
        for n in [I64_MIN,-1,0,1,2**53+1,I64_MAX]:self.assertEqual(decode_i64(parse(encode(i64(n)))),n)
        self.assertNotEqual(digest("request",i64(1)),hashlib.sha256(b'op:request:v1'+encode(i64(1))).hexdigest())

class SemanticTests(unittest.TestCase):
    def test_framed_postconditions(self):
        for p in core.DEPENDENCIES:
            for program in itertools.product(core.WRITES,repeat=2):
                for kind in ("frame","preserve","reestablish"):
                    if core.certificate(kind,p,program):
                        for state in core.STATES:
                            if kind=="reestablish" or core.predicate(p,state):
                                self.assertTrue(core.predicate(p,core.execute(program,state)))
        m=core.WitnessMachine(core.State(True,1))
        m.establish("authorized");m.establish("funded");old=m.cursor
        m.advance("topup",{"funded":"preserve"})
        self.assertTrue(m.use("authorized"));self.assertTrue(m.use("funded"))
        m.advance("revoke")
        with self.assertRaisesRegex(ValueError,"STALE_WITNESS"):m.use("authorized")
        m.advance("grant");m.establish("authorized")
        self.assertTrue(m.use("authorized"))
        with self.assertRaisesRegex(ValueError,"STALE_WITNESS"):m.use("authorized",old)
        self.assertEqual(m.history[0][1],"authorized")
        m.establish("clear");m.advance("hold")
        with self.assertRaisesRegex(ValueError,"STALE_WITNESS"):m.use("clear")
        for initial in range(3):
            for replacement in range(3):
                state={"balance":initial,"owner":"a"}
                facts={"balance":initial,"owner":"a"};history=[dict(state)]
                writes={"balance"}
                kept={k:v for k,v in facts.items() if k not in writes}
                state["balance"]=replacement
                kept["balance"]=replacement;history.append(dict(state))
                self.assertTrue(all(state[k]==v for k,v in kept.items()))
                self.assertEqual(history[0]["balance"],initial)
                if initial!=replacement:self.assertNotEqual(kept["balance"],facts["balance"])
        old={"balance":100}; new={"balance":0}
        self.assertFalse(all(new[k]==v for k,v in old.items()))

    def test_all_path_screening_diamond(self):
        left=core.Screen("a","j","p",10,"left")
        right=core.Screen("a","j","p",18,"right")
        operands=core.screen_join({"left":left,"right":right},"a","j","p")
        self.assertEqual(core.select_screen(operands,"right",20,5),right)
        with self.assertRaisesRegex(ValueError,"STALE_SCREEN"):core.select_screen(operands,"left",20,5)
        with self.assertRaisesRegex(ValueError,"UNCOVERED_PATH"):core.screen_join({"left":left,"right":None},"a","j","p")
        with self.assertRaisesRegex(ValueError,"UNCOVERED_PATH"):core.screen_join({"left":left,"right":core.Screen("b","j","p",18,"wrong")},"a","j","p")
        # Must facts use intersection at the join and actual edge witness selection.
        signatures=[frozenset({"subject-a","subject-b"}),frozenset({"subject-a"}),frozenset()]
        for left,right in itertools.product(signatures,repeat=2):
            required={"subject-a"}
            admitted=required <= (left & right)
            exhaustive=all(required <= branch for branch in (left,right))
            self.assertEqual(admitted,exhaustive)
        left_witness="left-screen";right_witness="right-screen"
        self.assertNotEqual(left_witness,right_witness)
        self.assertTrue({"subject-a"}<=(signatures[1]&signatures[1]))
        self.assertFalse({"subject-a"}<=(signatures[1]&signatures[2]))

    def test_closed_epoch_late_event(self):
        log=core.EpochLog();log.receive("A",2,5,"A2");log.receive("B",1,20,"B1")
        self.assertEqual([e["identity"] for e in log.admitted],["B1"])
        root,first=log.commit("authority-1","state-1")
        receipt0=log.consume("continuation-1",first,root)
        log.receive("A",1,10,"A1")
        self.assertEqual([e["identity"] for e in log.admitted],["B1","A1","A2"])
        self.assertEqual(log.consume("continuation-1",first,root),receipt0)
        later,later_epoch=log.commit("authority-2","state-2")
        self.assertNotEqual(root,later)
        self.assertEqual(log.consume("continuation-1",later_epoch,later),receipt0)
        self.assertEqual(log.consume("continuation-2",later_epoch,later,"A")[0],"A1")
        self.assertEqual(log.consume("continuation-3",later_epoch,later,"A")[0],"A2")
        with self.assertRaisesRegex(ValueError,"SUSPENDED"):log.consume("continuation-4",later_epoch,later,"A")
        final,final_epoch=log.commit("authority-3","state-3")
        with self.assertRaisesRegex(ValueError,"SUSPENDED"):log.consume("continuation-5",final_epoch,final,"A")
        for key,value in (("trust","changed"),("frontier",0),("streams",{}),("members",[])):
            corrupted=dict(first);corrupted[key]=value
            with self.assertRaisesRegex(ValueError,"EPOCH_ROOT"):log.consume("new",corrupted,root)
        admitted=[{"append":1,"event_time":20,"event":"first"}]
        epoch=encode({"frontier":1,"members":admitted,"previous":"root"})
        receipt=digest("execution",{"epoch":hashlib.sha256(epoch).hexdigest(),"chosen":"first"})
        admitted.append({"append":2,"event_time":10,"event":"late"})
        old_members=admitted[:json.loads(epoch)["frontier"]]
        self.assertEqual(old_members[0]["event"],"first")
        self.assertEqual(receipt,digest("execution",{"epoch":hashlib.sha256(epoch).hexdigest(),"chosen":old_members[0]["event"]}))
        self.assertEqual(sorted(admitted,key=lambda x:x["event_time"])[0]["event"],"late")
        successor=digest("reassessment",{"source_receipt":receipt,"frontier":2})
        self.assertNotEqual(successor,receipt)

    def test_intent_conservation(self):
        original=125;paid=100;returned=0;cancelled=0;outstanding=25
        self.assertEqual(original,paid-returned+cancelled+outstanding)
        parent_target=100;child_target=25
        self.assertEqual(parent_target+child_target,original)
        self.assertEqual(outstanding,child_target)
        returned=40;outstanding+=40
        self.assertEqual(original,paid-returned+cancelled+outstanding)
        cancelled=25;outstanding-=25
        self.assertEqual(original,paid-returned+cancelled+outstanding)
        self.assertGreater(original-paid,0)

class AdapterTests(unittest.TestCase):
    def invoke(self,path:Path,fault:str|None=None):
        cmd=PYTHON+[str(ROOT/"reference_adapter.py"),str(path)]
        if fault:cmd += ["--fault",fault]
        return subprocess.run(cmd,capture_output=True)
    def inspect(self,path:Path):
        with adapter.connect(path/"host.sqlite") as db:
            command=db.execute("SELECT quantity,reserved,state FROM commands").fetchall()
            consumed=db.execute("SELECT quantity FROM consumed").fetchall()
            inbox=db.execute("SELECT count(*) FROM inbox").fetchone()[0]
        with adapter.connect(path/"provider.sqlite") as db:effects=db.execute("SELECT count(*) FROM effects").fetchone()[0]
        return command,consumed,inbox,effects
    def test_every_process_crash_boundary(self):
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="crash-tests-") as temp:
            for fault in adapter.CRASH_POINTS:
                with self.subTest(fault=fault):
                    path=Path(temp)/fault
                    crashed=self.invoke(path,fault)
                    self.assertEqual(crashed.returncode,77,crashed.stderr)
                    commands,consumed,inbox,effects=self.inspect(path)
                    if fault in {"before_prepare","inside_prepare"}:
                        self.assertEqual((commands,consumed,inbox,effects),([],[],0,0))
                    elif fault=="after_consume":
                        self.assertEqual((commands,consumed,inbox,effects),([(100,0,"Final")],[(100,)],1,1))
                    else:
                        self.assertEqual(consumed,[])
                        self.assertEqual(commands[0][1],100)
                        self.assertEqual(effects,int(fault in {"after_provider","inside_inbox","after_inbox","inside_consume"}))
                    recovered=self.invoke(path)
                    self.assertEqual(recovered.returncode,0,recovered.stderr)
                    repeated=self.invoke(path)
                    self.assertEqual(repeated.returncode,0,repeated.stderr)
                    self.assertEqual(self.inspect(path),([(100,0,"Final")],[(100,)],1,1))
    def test_concurrent_duplicate_deliveries(self):
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="concurrent-tests-") as temp:
            path=Path(temp);adapter.initialize(path)
            processes=[subprocess.Popen(PYTHON+[str(ROOT/"reference_adapter.py"),str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for _ in range(4)]
            for proc in processes:
                _,err=proc.communicate();self.assertEqual(proc.returncode,0,err)
            self.assertEqual(self.inspect(path),([(100,0,"Final")],[(100,)],1,1))
    def test_revocation_preserves_commitment_and_recovers_effect(self):
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="authority-tests-") as temp:
            for point,expected_effects in [("after_prepare",0),("after_provider",1)]:
                path=Path(temp)/point;self.assertEqual(self.invoke(path,point).returncode,77)
                with adapter.connect(path/"host.sqlite") as db:db.execute("UPDATE authority SET permitted=0")
                result=self.invoke(path)
                if expected_effects:
                    self.assertEqual(result.returncode,0,result.stderr)
                    self.assertEqual(self.inspect(path),([(100,0,"Final")],[(100,)],1,1))
                else:
                    self.assertNotEqual(result.returncode,0)
                    self.assertEqual(self.inspect(path),([(100,100,"Prepared")],[],0,0))
    def test_immutable_request_and_bad_outcome(self):
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="binding-tests-") as temp:
            path=Path(temp);adapter.initialize(path);adapter.run(path)
            with self.assertRaisesRegex(ValueError,"COMMAND_CONFLICT"):adapter.run(path,quantity=101)
            with adapter.connect(path/"provider.sqlite") as db:db.execute("UPDATE effects SET signature='bad'")
            with self.assertRaisesRegex(ValueError,"BAD_PROVIDER_EVIDENCE"):adapter.run(path)

    def test_signed_outcome_closure_identity_and_inbox_conflict(self):
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="outcome-tests-") as temp:
            for mutation in ("tuple_event","open","second_event"):
                with self.subTest(mutation=mutation):
                    path=Path(temp)/mutation
                    fault="after_inbox" if mutation=="second_event" else "after_provider"
                    self.assertEqual(self.invoke(path,fault).returncode,77)
                    with adapter.connect(path/"provider.sqlite") as db:
                        event,body,signature=db.execute("SELECT event,body,signature FROM effects").fetchone()
                        if mutation=="tuple_event":
                            event="unbound-event"
                        else:
                            payload=parse(body)
                            if mutation=="open":payload["closed"]=False
                            else:payload["event"]=event="second-event"
                            body=encode(payload)
                            signature=hmac.new(adapter.KEY,body,hashlib.sha256).hexdigest()
                        db.execute("UPDATE effects SET event=?,body=?,signature=?",(event,body,signature))
                    result=self.invoke(path)
                    self.assertNotEqual(result.returncode,0)
                    expected={"tuple_event":"OUTCOME_BINDING","open":"OUTCOME_OPEN","second_event":"COMMAND_OUTCOME_CONFLICT"}[mutation]
                    self.assertIn(expected.encode(),result.stderr)
                    commands,consumed,inbox,effects=self.inspect(path)
                    self.assertEqual(commands,[(100,100,"Armed")])
                    self.assertEqual(consumed,[])
                    self.assertEqual(inbox,int(mutation=="second_event"))

if __name__=="__main__":unittest.main(verbosity=2)
