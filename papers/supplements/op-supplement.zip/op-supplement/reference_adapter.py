"""Durable outbox/inbox reference with a separate persistent provider contract fixture.

SQLite commits model durable local storage. The fixture models provider idempotency.
It does not establish a live provider's authority, honesty, retention, or durability.
"""
from __future__ import annotations
import argparse
import hashlib
import hmac
import os
from pathlib import Path
import sqlite3
from canonical_profile import encode, parse, digest

KEY = b"public-reference-provider-test-key"
CRASH_POINTS = (
    "before_prepare", "inside_prepare", "after_prepare", "inside_arm", "after_arm",
    "before_provider", "inside_provider", "after_provider", "inside_inbox", "after_inbox",
    "inside_consume", "after_consume",
)

def crash(point: str, configured: str | None) -> None:
    if point == configured: os._exit(77)

class ClosingConnection(sqlite3.Connection):
    def __exit__(self,*args):
        try:return super().__exit__(*args)
        finally:self.close()

def connect(path: Path) -> sqlite3.Connection:
    db=sqlite3.connect(path,timeout=10,isolation_level=None,factory=ClosingConnection)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    db.execute("PRAGMA foreign_keys=ON")
    return db

def initialize(directory: Path) -> None:
    directory.mkdir(parents=True,exist_ok=True)
    with connect(directory/"host.sqlite") as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS commands(k TEXT PRIMARY KEY, h TEXT NOT NULL, body BLOB NOT NULL,
          quantity INTEGER NOT NULL, reserved INTEGER NOT NULL, state TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS authority(id INTEGER PRIMARY KEY, permitted INTEGER NOT NULL);
        INSERT OR IGNORE INTO authority VALUES(1,1);
        CREATE TABLE IF NOT EXISTS inbox(event TEXT PRIMARY KEY, command TEXT UNIQUE NOT NULL,
          body BLOB NOT NULL, signature TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS consumed(command TEXT PRIMARY KEY REFERENCES commands(k),
          event TEXT UNIQUE NOT NULL REFERENCES inbox(event), quantity INTEGER NOT NULL);
        """)
    with connect(directory/"provider.sqlite") as db:
        db.execute("CREATE TABLE IF NOT EXISTS effects(k TEXT PRIMARY KEY,h TEXT NOT NULL,event TEXT UNIQUE NOT NULL,body BLOB NOT NULL,signature TEXT NOT NULL)")

def prepare(directory: Path, k: str, request: dict, fault: str | None) -> str:
    body=encode(request);h=digest("request",request);q=request["quantity"]
    crash("before_prepare",fault)
    with connect(directory/"host.sqlite") as db:
        db.execute("BEGIN IMMEDIATE")
        row=db.execute("SELECT h,body FROM commands WHERE k=?",(k,)).fetchone()
        if row:
            if row!=(h,body): raise ValueError("COMMAND_CONFLICT")
        else:
            db.execute("INSERT INTO commands VALUES(?,?,?,?,?,?)",(k,h,body,q,q,"Prepared"))
        crash("inside_prepare",fault)
        db.commit()
    crash("after_prepare",fault)
    return h

def query(directory: Path,k: str):
    with connect(directory/"provider.sqlite") as db:
        return db.execute("SELECT event,body,signature FROM effects WHERE k=?",(k,)).fetchone()

def submit(directory: Path,k: str,h: str,request: dict,fault: str | None):
    crash("before_provider",fault)
    with connect(directory/"provider.sqlite") as db:
        db.execute("BEGIN IMMEDIATE")
        old=db.execute("SELECT h,event,body,signature FROM effects WHERE k=?",(k,)).fetchone()
        if old:
            if old[0]!=h: raise ValueError("PROVIDER_CONFLICT")
            result=old[1:]
        else:
            event=digest("fixture-credit",{"provider":"reference","command":k})
            body=encode({"command":k,"request":h,"event":event,"quantity":request["quantity"],"closed":True})
            signature=hmac.new(KEY,body,hashlib.sha256).hexdigest()
            db.execute("INSERT INTO effects VALUES(?,?,?,?,?)",(k,h,event,body,signature))
            result=(event,body,signature)
        crash("inside_provider",fault)
        db.commit()
    crash("after_provider",fault)
    return result

def run(directory: Path, k: str="command-1", quantity: int=100,fault: str | None=None) -> None:
    initialize(directory)
    request={"asset":"USD","payer":"payer","payee":"payee","quantity":quantity}
    h=prepare(directory,k,request,fault)
    result=query(directory,k)
    if result is None:
        with connect(directory/"host.sqlite") as db:
            db.execute("BEGIN IMMEDIATE")
            if not db.execute("SELECT permitted FROM authority WHERE id=1").fetchone()[0]: raise ValueError("CURRENT_USE_AUTHORITY")
            state=db.execute("SELECT state FROM commands WHERE k=?",(k,)).fetchone()[0]
            if state=="Cancelled": raise ValueError("CANCELLED")
            if state=="Prepared":db.execute("UPDATE commands SET state='Armed' WHERE k=?",(k,))
            crash("inside_arm",fault);db.commit()
        crash("after_arm",fault)
        with connect(directory/"host.sqlite") as db:
            if not db.execute("SELECT permitted FROM authority WHERE id=1").fetchone()[0]:raise ValueError("CURRENT_USE_AUTHORITY")
        # A live effect-time authority contract requires its own provider-enforced boundary.
        result=submit(directory,k,h,request,fault)
    event,body,signature=result
    if not hmac.compare_digest(signature,hmac.new(KEY,body,hashlib.sha256).hexdigest()):raise ValueError("BAD_PROVIDER_EVIDENCE")
    payload=parse(body)
    if not isinstance(payload,dict) or set(payload)!={"command","request","event","quantity","closed"}:raise ValueError("OUTCOME_SCHEMA")
    if payload["command"]!=k or payload["request"]!=h or payload["event"]!=event or type(payload["quantity"]) is not int or payload["quantity"]!=quantity:raise ValueError("OUTCOME_BINDING")
    if payload["closed"] is not True:raise ValueError("OUTCOME_OPEN")
    with connect(directory/"host.sqlite") as db:
        db.execute("BEGIN IMMEDIATE")
        old=db.execute("SELECT command,body,signature FROM inbox WHERE event=?",(event,)).fetchone()
        if old and old!=(k,body,signature):raise ValueError("EVENT_CONFLICT")
        command_row=db.execute("SELECT event,body,signature FROM inbox WHERE command=?",(k,)).fetchone()
        if command_row and command_row!=(event,body,signature):raise ValueError("COMMAND_OUTCOME_CONFLICT")
        db.execute("INSERT OR IGNORE INTO inbox VALUES(?,?,?,?)",(event,k,body,signature))
        crash("inside_inbox",fault);db.commit()
    crash("after_inbox",fault)
    with connect(directory/"host.sqlite") as db:
        db.execute("BEGIN IMMEDIATE")
        stored=db.execute("SELECT event,body,signature FROM inbox WHERE command=?",(k,)).fetchone()
        if stored!=(event,body,signature):raise ValueError("INBOX_CONSUMPTION_BINDING")
        previous=db.execute("SELECT event,quantity FROM consumed WHERE command=?",(k,)).fetchone()
        if previous and previous!=(event,quantity):raise ValueError("CONSUMPTION_CONFLICT")
        db.execute("INSERT OR IGNORE INTO consumed VALUES(?,?,?)",(k,event,quantity))
        db.execute("UPDATE commands SET reserved=0,state='Final' WHERE k=?",(k,))
        crash("inside_consume",fault);db.commit()
    crash("after_consume",fault)

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("directory",type=Path);p.add_argument("--fault",choices=CRASH_POINTS);p.add_argument("--quantity",type=int,default=100)
    a=p.parse_args();run(a.directory,quantity=a.quantity,fault=a.fault)
