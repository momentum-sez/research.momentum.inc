// Independent ECMAScript implementation of the exact-integer JCS profile.
import fs from "node:fs";
if (process.versions.unicode !== "17.0") throw Error("UNICODE_VERSION");
const SAFE = Number.MAX_SAFE_INTEGER;
function text(s) {
  if (s.normalize("NFC") !== s) throw Error("NON_NFC");
  for(const c of s) {
    const cp=c.codePointAt(0);
    if((cp>=0xfdd0 && cp<=0xfdef) || [0xfffe,0xffff].includes(cp&0xffff)) throw Error("UNICODE_NONCHARACTER");
  }
  for (let i=0;i<s.length;i++) {
    const c=s.charCodeAt(i);
    if (c>=0xd800 && c<=0xdbff) {
      const d=s.charCodeAt(++i);
      if (!(d>=0xdc00 && d<=0xdfff)) throw Error("UNPAIRED_SURROGATE");
    } else if(c>=0xdc00 && c<=0xdfff) throw Error("UNPAIRED_SURROGATE");
  }
  return JSON.stringify(s);
}
function emit(v) {
  if(v===null || typeof v==="boolean") return JSON.stringify(v);
  if(typeof v==="number") {
    if(!Number.isSafeInteger(v) || Math.abs(v)>SAFE || Object.is(v,-0)) throw Error("UNSAFE_JSON_INTEGER");
    return JSON.stringify(v);
  }
  if(typeof v==="string") return text(v);
  if(Array.isArray(v)) return "["+v.map(emit).join(",")+"]";
  if(typeof v==="object") return "{"+Object.keys(v).sort().map(k=>text(k)+":"+emit(v[k])).join(",")+"}";
  throw Error("PROFILE_TYPE");
}
function decodeI64(v) {
  if(Object.keys(v).sort().join(",")!=="decimal,type" || v.type!=="i64" || typeof v.decimal!=="string" || !/^(0|-?[1-9][0-9]*)$(?![\s\S])/.test(v.decimal)) throw Error("I64_SCHEMA");
  const n=BigInt(v.decimal);
  if(n<-(1n<<63n) || n>(1n<<63n)-1n) throw Error("I64_RANGE");
  return n.toString();
}
// This transport supplies already validated values to an encoder oracle.
// It is not a raw-wire admission parser.
const requests=JSON.parse(fs.readFileSync(0,"utf8"));
const results=requests.map(r=>{
  try { return {ok:true, bytes:emit(r.value), integer:r.i64?decodeI64(r.value):null}; }
  catch(error) { return {ok:false,error:error.message}; }
});
process.stdout.write(JSON.stringify(results));
