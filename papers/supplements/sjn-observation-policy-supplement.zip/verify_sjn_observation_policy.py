#!/usr/bin/env python3
"""Exact finite checks for SJN observation and action-policy profiles.

The input tables supply the complete worlds, observations, and permissions.
Labels are integers, strings, bytes, or tuples of those types. An adapter must
preserve the observer's distinctions, for example through canonical bytes.
These checks do not authenticate those inputs or implement durable admission,
physical timing controls, random sampling, or external performance.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Hashable, Iterable, Sequence, Union

from disclosure_composition_checker import admit_release


Rational = Union[int, str, Fraction]


def _q(value: Rational) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (int, str, Fraction)):
        raise ValueError("use exact integers, rational strings, or Fraction values")
    return Fraction(value)


def _matrix(rows: Sequence[Sequence[Rational]], width: int) -> tuple:
    if type(width) is not int or width <= 0:
        raise ValueError("matrix width must be a positive integer")
    result = tuple(tuple(_q(value) for value in row) for row in rows)
    if any(len(row) != width for row in result):
        raise ValueError("matrix rows must have the declared width")
    return result


def affine_pullback(phi, offset, rows, *, width: int) -> tuple:
    """Return the latent rows R Phi and public offsets R c."""
    phi = _matrix(phi, width)
    if not phi:
        raise ValueError("an affine snapshot must have at least one coordinate")
    offset = tuple(_q(value) for value in offset)
    if len(offset) != len(phi):
        raise ValueError("snapshot map and offset must have equal heights")
    rows = _matrix(rows, len(phi))
    lifted = tuple(tuple(sum((r[i] * phi[i][j] for i in range(len(phi))), Fraction(0))
                         for j in range(width)) for r in rows)
    constants = tuple(sum((r[i] * offset[i] for i in range(len(phi))), Fraction(0))
                      for r in rows)
    return lifted, constants


def normalize_observation(phi, offset, rows, answers, *, width: int) -> tuple:
    """Return the complete normalized equations for one affine observation."""
    lifted, constants = affine_pullback(phi, offset, rows, width=width)
    answers = tuple(_q(value) for value in answers)
    if len(answers) != len(lifted):
        raise ValueError("every query row must have one supplied answer")
    return lifted, tuple(y - c for y, c in zip(answers, constants))


def _labels(values: Sequence[Hashable]) -> tuple:
    def validate(value):
        if type(value) in (int, str, bytes):
            return
        if type(value) is tuple:
            for member in value:
                validate(member)
            return
        raise ValueError("labels must be integers, strings, bytes, or tuples of those types")

    values = tuple(values)
    for value in values:
        validate(value)
    return values


def _belief(size: int, belief: Iterable[int] | None) -> tuple[int, ...]:
    if size <= 0:
        raise ValueError("the world set must be nonempty")
    worlds = tuple(range(size)) if belief is None else tuple(belief)
    if not worlds or len(set(worlds)) != len(worlds):
        raise ValueError("a belief must be a nonempty set of world indices")
    if any(type(w) is not int or not 0 <= w < size for w in worlds):
        raise ValueError("belief contains an unknown world")
    return worlds


def output_fibres(outputs: Sequence[Hashable], belief=None) -> tuple:
    """Partition the belief by the complete supplied visible output."""
    outputs = _labels(outputs)
    worlds = _belief(len(outputs), belief)
    groups: dict[Hashable, list[int]] = {}
    for w in worlds:
        groups.setdefault(outputs[w], []).append(w)
    return tuple((label, tuple(group)) for label, group in groups.items())


@dataclass(frozen=True)
class AmbiguityObstruction:
    output: Hashable
    worlds: tuple[int, ...]
    attribute: int
    values: frozenset[Hashable]
    required: int


def fibre_obstructions(outputs, protected, floors, *, belief=None) -> tuple:
    """Return every output fibre that violates a protected-value floor."""
    outputs = _labels(outputs)
    protected = tuple(_labels(attribute) for attribute in protected)
    floors = tuple(floors)
    if len(protected) != len(floors):
        raise ValueError("each protected attribute needs one ambiguity floor")
    if any(len(attribute) != len(outputs) for attribute in protected):
        raise ValueError("each protected attribute must cover every world")
    if any(type(k) is not int or k < 2 for k in floors):
        raise ValueError("ambiguity floors must be integers at least two")
    failures = []
    for label, worlds in output_fibres(outputs, belief):
        for j, (attribute, floor) in enumerate(zip(protected, floors)):
            values = frozenset(attribute[w] for w in worlds)
            if len(values) < floor:
                failures.append(AmbiguityObstruction(label, worlds, j, values, floor))
    return tuple(failures)


def public_answer_admission(answers, protected, floors, *, belief=None) -> tuple:
    """Choose a whole answer map or one constant complete refusal output."""
    answers = _labels(answers)
    protected = tuple(tuple(attribute) for attribute in protected)
    floors = tuple(floors)
    belief = None if belief is None else tuple(belief)
    refusal = tuple(("Refuse",) for _ in answers)
    if fibre_obstructions(refusal, protected, floors, belief=belief):
        raise ValueError("the preceding belief already violates ambiguity")
    if fibre_obstructions(answers, protected, floors, belief=belief):
        return refusal
    return tuple(("Answer", answer) for answer in answers)


def _profile(actions, observations, privacy_edges, permitted, successful) -> tuple:
    actions = _labels(actions)
    if not actions or len(set(actions)) != len(actions):
        raise ValueError("actions must be a nonempty ordered set")
    observations = _labels(observations)
    size = len(observations)
    _belief(size, None)
    permitted = tuple(frozenset(_labels(row)) for row in permitted)
    successful = tuple(frozenset(_labels(row)) for row in successful)
    if len(permitted) != size or len(successful) != size:
        raise ValueError("permission and success tables must cover every world")
    if any(not row <= set(actions) for row in (*permitted, *successful)):
        raise ValueError("permission or success table contains an unknown action")
    edges = set()
    for edge in privacy_edges:
        if len(edge) != 2:
            raise ValueError("a privacy edge must contain two worlds")
        w, v = edge
        if any(type(x) is not int or not 0 <= x < size for x in (w, v)):
            raise ValueError("privacy edge contains an unknown world")
        edges.add(tuple(sorted((w, v))))
    return actions, observations, tuple(sorted(edges)), permitted, successful


@dataclass(frozen=True)
class PolicyObstruction:
    worlds: tuple[int, ...]
    excluded_by: tuple[tuple[Hashable, int], ...]


@dataclass(frozen=True)
class SelectorResult:
    components: tuple[tuple[int, ...], ...]
    policy: tuple[Hashable, ...] | None
    obstructions: tuple[PolicyObstruction, ...]


def joined_selector(actions, observations, privacy_edges, permitted, successful) -> SelectorResult:
    """Select common permitted-successful actions on the joined components."""
    actions, observations, edges, permitted, successful = _profile(
        actions, observations, privacy_edges, permitted, successful)
    neighbours = [set() for _ in observations]
    for w, v in edges:
        neighbours[w].add(v)
        neighbours[v].add(w)
    first: dict[Hashable, int] = {}
    for w, observation in enumerate(observations):
        v = first.setdefault(observation, w)
        neighbours[w].add(v)
        neighbours[v].add(w)
    unseen = set(range(len(observations)))
    components = []
    choices: list[Hashable] = [None] * len(observations)
    obstructions = []
    while unseen:
        pending = [min(unseen)]
        component = set()
        while pending:
            w = pending.pop()
            if w in component:
                continue
            component.add(w)
            pending.extend(neighbours[w] - component)
        unseen -= component
        worlds = tuple(sorted(component))
        components.append(worlds)
        common = set(actions)
        for w in worlds:
            common &= permitted[w] & successful[w]
        if common:
            action = next(a for a in actions if a in common)
            for w in worlds:
                choices[w] = action
        else:
            exclusions = tuple((a, next(w for w in worlds
                                        if a not in permitted[w] & successful[w]))
                               for a in actions)
            obstructions.append(PolicyObstruction(worlds, exclusions))
    policy = None if obstructions else tuple(choices)
    return SelectorResult(tuple(components), policy, tuple(obstructions))


@dataclass(frozen=True)
class ChannelViolation:
    kind: str
    worlds: tuple[int, ...]
    event: tuple[Hashable, ...]
    value: Fraction
    bound: Fraction


def channel_violations(actions, observations, privacy_edges, permitted, successful,
                       probabilities, *, E: Rational, delta: Rational, eta: Rational) -> tuple:
    """Check normalization, legal support, success, source views, and all DP events."""
    actions, observations, edges, permitted, successful = _profile(
        actions, observations, privacy_edges, permitted, successful)
    probabilities = _matrix(probabilities, len(actions))
    E, delta, eta = _q(E), _q(delta), _q(eta)
    if E < 1 or not 0 <= delta < 1 or not 0 <= eta <= 1:
        raise ValueError("require E >= 1, 0 <= delta < 1, and 0 <= eta <= 1")
    if len(probabilities) != len(observations):
        raise ValueError("the channel must contain one row per world")
    failures = []
    for w, row in enumerate(probabilities):
        for a, value in zip(actions, row):
            if value < 0:
                failures.append(ChannelViolation("negative", (w,), (a,), value, Fraction(0)))
        total = sum(row, Fraction(0))
        if total != 1:
            failures.append(ChannelViolation("normalization", (w,), actions, total, Fraction(1)))
        forbidden = tuple(a for a in actions if a not in permitted[w])
        for a, value in zip(actions, row):
            if a in forbidden and value != 0:
                failures.append(ChannelViolation("permission", (w,), (a,), value, Fraction(0)))
        success = sum((value for a, value in zip(actions, row)
                       if a in permitted[w] & successful[w]), Fraction(0))
        if success < 1 - eta:
            failures.append(ChannelViolation("success", (w,), (), success, 1 - eta))
    for w in range(len(observations)):
        for v in range(w):
            if observations[w] == observations[v] and probabilities[w] != probabilities[v]:
                failures.append(ChannelViolation("source-view", (w, v), (), Fraction(1), Fraction(0)))
    ordered_edges = sorted({pair for w, v in edges for pair in ((w, v), (v, w))})
    for w, v in ordered_edges:
        differences = tuple(p - E * q for p, q in zip(probabilities[w], probabilities[v]))
        event = tuple(a for a, value in zip(actions, differences) if value > 0)
        gap = sum((max(value, Fraction(0)) for value in differences), Fraction(0))
        if gap > delta:
            failures.append(ChannelViolation("privacy", (w, v), event, gap, delta))
    return tuple(failures)


def private_route_channel(k: int, *, E: Rational, delta: Rational) -> tuple:
    """Construct the sharp route channel, conditional on its admitted support."""
    E, delta = _q(E), _q(delta)
    if type(k) is not int or k < 2 or E < 1 or not 0 <= delta < 1:
        raise ValueError("require k >= 2, E >= 1, and 0 <= delta < 1")
    base = (1 - delta) / (E + k - 1)
    return tuple(tuple(delta + E * base if i == j else base for j in range(k))
                 for i in range(k))


def selector_channel(traces, weights, *, reveal_selector: bool = False) -> tuple:
    """Construct complete trace laws for one world-independent selector law.

    Each row supplies all selector-indexed traces in one world. The caller
    supplies the actual joint trace, including every reused random choice.
    """
    traces = tuple(_labels(row) for row in traces)
    _belief(len(traces), None)
    weights = tuple(_q(weight) for weight in weights)
    if not weights or any(weight < 0 for weight in weights) or sum(weights) != 1:
        raise ValueError("selector weights must be a nonempty probability distribution")
    if any(len(row) != len(weights) for row in traces):
        raise ValueError("each world must supply one trace for every selector")
    if type(reveal_selector) is not bool:
        raise ValueError("selector visibility must be Boolean")
    outputs = tuple(tuple((j, trace) if reveal_selector else trace
                          for j, trace in enumerate(row)) for row in traces)
    alphabet = tuple(dict.fromkeys(output for row in outputs for output in row))
    positions = {output: i for i, output in enumerate(alphabet)}
    channel = []
    for row in outputs:
        probabilities = [Fraction(0)] * len(alphabet)
        for output, weight in zip(row, weights):
            probabilities[positions[output]] += weight
        channel.append(tuple(probabilities))
    return alphabet, tuple(channel)


def self_test() -> int:
    """Run positive and adverse witnesses in normal and optimized Python."""
    checks = 0

    def require(value, expected, name):
        nonlocal checks
        if value != expected:
            raise AssertionError(name)
        checks += 1

    initial, values = normalize_observation(((1, 0), (0, 1)), (0, 0), ((1, 1),), (20,), width=2)
    later, values_later = normalize_observation(((2, 0), (0, 1)), (3, -1), ((1, 1),), (29,), width=2)
    require((initial, values, later, values_later),
            (((Fraction(1), Fraction(1)),), (Fraction(20),),
             ((Fraction(2), Fraction(1)),), (Fraction(27),)), "affine offset and row normalization")
    require(admit_release(initial, later, ((1, 0), (0, 1))), False, "later snapshot reconstructs source")
    secret = ((0, 1, 2, 3),)
    censored = (("Refuse",), ("Refuse",), ("Answer", 2), ("Answer", 2))
    require(fibre_obstructions(censored, secret, (2,)), (), "safe censored output")
    timed = (("Refuse", 0), ("Refuse", 1), ("Answer", 2), ("Answer", 2))
    require(len(fibre_obstructions(timed, secret, (2,))), 2, "visible refusal timing reveals values")
    raw = (0, 1, 2, 2)
    require(public_answer_admission(raw, secret, (2,)), (("Refuse",),) * 4, "whole-query refusal")
    require(public_answer_admission((0, 0, 1, 1), ((0, 1, 0, 1),), (2,)),
            (("Answer", 0), ("Answer", 0), ("Answer", 1), ("Answer", 1)), "useful whole-query answer")
    actions = ("a", "b", "c", "d")
    success = ({"a", "c"}, {"a", "d"}, {"b", "c"}, {"b", "d"})
    joined = joined_selector(actions, (0, 0, 1, 1), ((0, 2), (1, 3)), (set(actions),) * 4, success)
    require(joined.policy, None, "joined information and privacy obstruction")
    repaired = joined_selector((*actions, "e"), (0, 0, 1, 1), ((0, 2), (1, 3)),
                               (set((*actions, "e")),) * 4, tuple(s | {"e"} for s in success))
    require(repaired.policy, ("e",) * 4, "admitted common action")
    routes = private_route_channel(3, E=2, delta="1/5")
    require(channel_violations((0, 1, 2), (0, 1, 2), ((0, 1), (0, 2), (1, 2)),
                               ({0, 1, 2},) * 3, ({0}, {1}, {2}), routes,
                               E=2, delta="1/5", eta="2/5"), (), "sharp private route channel")
    require(bool(channel_violations((0, 1, 2), (0, 1, 2), ((0, 1), (0, 2), (1, 2)),
                                    ({0}, {1}, {2}), ({0}, {1}, {2}), routes,
                                    E=2, delta="1/5", eta="2/5")), True, "randomization cannot grant permission")
    failures = channel_violations(actions, (0, 1), ((0, 1),), (set(actions),) * 2,
                                  (set(actions),) * 2,
                                  (("3/10", "3/10", "1/5", "1/5"),
                                   ("1/5", "1/5", "3/10", "3/10")),
                                  E=1, delta="1/10", eta=0)
    require(tuple(f.event for f in failures if f.kind == "privacy"),
            (("a", "b"), ("c", "d")), "privacy needs all events")
    alphabet, rows = selector_channel(((0, 1), (1, 0)), ("1/2", "1/2"))
    require(channel_violations(alphabet, (0, 1), ((0, 1),), (set(alphabet),) * 2,
                               (set(alphabet),) * 2, rows, E=1, delta=0, eta=0),
            (), "private selector hides the protected bit")
    alphabet, rows = selector_channel(((0, 1), (1, 0)), ("1/2", "1/2"), reveal_selector=True)
    require(tuple(f.value for f in channel_violations(
        alphabet, (0, 1), ((0, 1),), (set(alphabet),) * 2, (set(alphabet),) * 2,
        rows, E=2, delta=0, eta=0) if f.kind == "privacy"),
        (Fraction(1), Fraction(1)), "public selector reveals the protected bit")
    return checks


if __name__ == "__main__":
    print(f"SJN observation-policy checker: {self_test()} checks passed")
