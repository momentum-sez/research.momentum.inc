# SJN observation and policy supplement

This supplement checks the finite constructions in *The Sovereign Jurisdiction Network*. It contains exact affine normalization, complete output-fibre checks, joined policy selectors, finite channel certificates, and selector trace laws.

## Requirements and execution

Use Python 3.9 or later. The checked interpreter is CPython 3.9.6. All dependencies are included or belong to the Python standard library. Extract every archive member into one directory. Run these commands there:

```sh
python3 verify_sjn_observation_policy.py
python3 -O verify_sjn_observation_policy.py
python3 -m unittest discover -s . -p test_verify_sjn_observation_policy.py
python3 -O -m unittest discover -s . -p test_verify_sjn_observation_policy.py
```

Each CLI command prints `SJN observation-policy checker: 13 checks passed` and exits with code zero. Each unittest command reports `Ran 40 tests` followed by `OK`. Test durations vary. Six in-memory mutations must fail their targeted behavioral assertions for the enclosing suite to pass.

The original exact linear and grant checker is included as `disclosure_composition_checker.py`. The new tests use its admitted row-span and source-grant interfaces.

## Model and evidence boundary

`PROFILE.json` records the supplied model, commands, checked interpreter, and expected results. Rational values use integers, rational strings, or `Fraction`. Supply the rational parameter `E = exp(epsilon)` directly. Floating-point inputs are excluded from certificate arithmetic.

Output, observation, action, and protected-value labels use exact integers, strings, bytes, or tuples of those types. Canonical bytes can represent complete visible records. Their adapter must preserve every modeled distinction, including refusal, pending, reasons, identifiers, timing, and effects. A mislabeled observation does not establish privacy.

The tests include reconstruction across snapshots, adaptive disclosure, useful censored answers, private permission leaks, empty joined action intersections, and combined privacy events. Selector tests retain complete traces and distinguish private common entropy, selector publication, independent choices, mask reuse, and conditional dependence.

The selector calculation uses supplied world-independent weights. It does not implement random sampling. Entropy availability, ownership, secrecy, independence, and permitted sharing require their own evidence. A nonce, digest, or replay identifier supplies none of those properties by its name.

The finite tables supply world completeness, actual knowledge, permissions, successful effects, and observer correspondence. The supplement supplies no authentication of these premises, durable transaction refinement, physical timing controls, retention enforcement, or provider-performance evidence.

## Integrity

`SHA256SUMS` records every other archive member and excludes itself. Verify the extracted bytes with:

```sh
python3 - <<'PYVERIFY'
from pathlib import Path
import hashlib
for line in Path('SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    actual = hashlib.sha256(Path(name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit('checksum mismatch: ' + name)
print('All member checksums match.')
PYVERIFY
```

The archive uses sorted names, fixed timestamps, stored entries, and mode 0644. It contains no current manuscript or rendered-paper hash.
