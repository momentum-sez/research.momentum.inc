#!/usr/bin/env python3
"""Bounded exact checker for the linear disclosure and grant model.

This file checks only the finite, noiseless, rational model stated in
Sovereign Jurisdiction Network, section 4.  It is a reference witness, not a
production privacy mechanism or a legal authority evaluator.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable, Sequence, Union


Number = Union[int, str, Fraction]
Row = Sequence[Number]


def _q(value: Number) -> Fraction:
    return value if isinstance(value, Fraction) else Fraction(value)


def _matrix(rows: Iterable[Row], width: int) -> list[list[Fraction]]:
    result = [list(map(_q, row)) for row in rows]
    if width <= 0 or any(len(row) != width for row in result):
        raise ValueError("matrix shape")
    return result


def rank(rows: Iterable[Row], width: int) -> int:
    """Return exact row rank over Q by deterministic Gaussian elimination."""

    matrix = _matrix(rows, width)
    pivot = 0
    for column in range(width):
        candidate = next(
            (row for row in range(pivot, len(matrix)) if matrix[row][column]),
            None,
        )
        if candidate is None:
            continue
        matrix[pivot], matrix[candidate] = matrix[candidate], matrix[pivot]
        scale = matrix[pivot][column]
        matrix[pivot] = [value / scale for value in matrix[pivot]]
        for row in range(len(matrix)):
            if row == pivot:
                continue
            factor = matrix[row][column]
            if factor:
                matrix[row] = [
                    value - factor * base
                    for value, base in zip(matrix[row], matrix[pivot])
                ]
        pivot += 1
        if pivot == len(matrix):
            break
    return pivot


def identifies(rows: Sequence[Row], target: Row) -> bool:
    """Return whether exact observations identify the target linear value."""

    width = len(target)
    if any(len(row) != width for row in rows):
        raise ValueError("target and observations have different widths")
    return rank(rows, width) == rank([*rows, target], width)


def admit_release(
    history: Sequence[Row], proposed: Sequence[Row], protected: Sequence[Row]
) -> bool:
    """Validate the common positive width, then test protected quantities."""

    if not proposed:
        raise ValueError("a release must contain at least one row")
    width = len(proposed[0])
    # Validate every row even when protection is empty or an earlier target
    # already refuses the release. Shape is a premise of the rational model.
    combined = _matrix([*history, *proposed], width)
    protected = _matrix(protected, width)
    return not any(identifies(combined, target) for target in protected)


@dataclass(frozen=True)
class Grant:
    source: str
    acts: frozenset[str]
    purpose: str
    audience: str
    valid_from: int
    valid_until: int
    retain_from: int
    retain_until: int


def admit_action(
    lineage: Iterable[str],
    grants: Iterable[Grant],
    *,
    act: str,
    purpose: str,
    audience: str,
    at: int,
    retain_until: int,
) -> bool:
    """Check one current grant and retention interval for every source."""

    if retain_until < at:
        return False
    by_source: dict[str, list[Grant]] = {}
    for grant in grants:
        by_source.setdefault(grant.source, []).append(grant)
    for source in set(lineage):
        if not any(
            act in grant.acts
            and grant.purpose == purpose
            and grant.audience == audience
            and grant.valid_from <= at <= grant.valid_until
            and max(at, grant.retain_from) <= retain_until <= grant.retain_until
            for grant in by_source.get(source, ())
        ):
            return False
    return True


def self_test() -> int:
    """Run admission checks whose execution is unchanged by Python -O."""

    checks = 0

    def require(actual: bool, expected: bool, name: str) -> None:
        nonlocal checks
        if actual is not expected:
            raise AssertionError(name)
        checks += 1

    a_plus_b = (1, 1, 0)
    b_plus_c = (0, 1, 1)
    a_plus_c = (1, 0, 1)
    protected = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    require(admit_release([], [a_plus_b], protected), True, "first aggregate")
    require(admit_release([a_plus_b], [b_plus_c], protected), True, "second aggregate")
    require(admit_release([a_plus_b, b_plus_c], [a_plus_c], protected), False,
            "three sums reconstruct protected coordinates")
    require(admit_release([], [(1, 1), (1, 1 + Fraction(1, 10**80))],
                          [(1, 0), (0, 1)]), False,
            "distinct rational rows must not collapse through rounding")

    compute = Grant("source-a", frozenset({"compute"}), "research", "team", 0, 10, 0, 10)
    require(admit_action(
        ["source-a"], [compute], act="compute", purpose="research",
        audience="team", at=2, retain_until=5,
    ), True, "permitted research computation")
    require(admit_action(
        ["source-a"], [compute], act="train", purpose="research",
        audience="team", at=2, retain_until=5,
    ), False, "computation grant is not a training grant")
    train = Grant("source-a", frozenset({"train"}), "model", "team", 0, 10, 0, 10)
    require(admit_action(
        ["source-a"], [compute, train], act="train", purpose="model",
        audience="team", at=2, retain_until=5,
    ), True, "separately permitted training")
    require(admit_action(
        ["source-a", "source-b"], [compute], act="compute", purpose="research",
        audience="team", at=2, retain_until=5,
    ), False, "every lineage source requires a grant")
    second = Grant("source-b", frozenset({"compute"}), "research", "team", 0, 10, 0, 10)
    require(admit_action(
        ["source-a", "source-b"], [compute, second], act="compute", purpose="research",
        audience="team", at=2, retain_until=5,
    ), True, "compatible grants for both sources")
    require(admit_action(
        ["source-a"], [compute], act="compute", purpose="research",
        audience="team", at=2, retain_until=11,
    ), False, "retention cannot exceed the source grant")
    for deadline, expected in ((2, False), (5, True), (8, True)):
        require(admit_action(
            [], [], act="compute", purpose="research", audience="team",
            at=5, retain_until=deadline,
        ), expected, "empty lineage still requires retention through use time")
    return checks


if __name__ == "__main__":
    count = self_test()
    print(f"disclosure-composition checker: {count} admission checks passed")
