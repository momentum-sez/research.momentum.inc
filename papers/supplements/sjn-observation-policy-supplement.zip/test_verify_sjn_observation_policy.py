"""Finite adverse witnesses for the SJN observation and policy constructions.

Run with python3 -m unittest discover -s papers -p test_verify_sjn_observation_policy.py.
The tests compare small instances with enumeration independent of the checker.
"""

from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

import verify_sjn_observation_policy as checker
from disclosure_composition_checker import Grant, admit_action, admit_release, identifies


def dot(row, vector):
    return sum((Fraction(a) * Fraction(b) for a, b in zip(row, vector)), Fraction(0))


def subsets(values):
    return tuple(frozenset(values[i] for i in range(len(values)) if mask & (1 << i))
                 for mask in range(1 << len(values)))


class AffineTests(unittest.TestCase):
    def test_offsets_and_current_protected_rows_use_the_same_pullback(self):
        phi, offset = ((2, 0), (0, 1), (1, 1)), (3, -1, 7)
        self.assertEqual(checker.affine_pullback(phi, offset, ((1, 2, 0),), width=2),
                         (((2, 2),), (1,)))
        self.assertEqual(checker.affine_pullback(phi, offset, ((0, 0, 1),), width=2),
                         (((1, 1),), (7,)))

    def test_later_snapshot_cannot_reset_the_observation_history(self):
        first, y0 = checker.normalize_observation(((1, 0), (0, 1)), (0, 0), ((1, 1),), (20,), width=2)
        later, y1 = checker.normalize_observation(((2, 0), (0, 1)), (3, -1), ((1, 1),), (29,), width=2)
        protected = ((1, 0), (0, 1))
        self.assertTrue(admit_release([], first, protected))
        self.assertTrue(admit_release([], later, protected))
        self.assertFalse(admit_release(first, later, protected))
        self.assertEqual((y1[0] - y0[0], 2 * y0[0] - y1[0]), (7, 13))

    def test_finite_affine_substitution_matches_direct_snapshot_evaluation(self):
        for entries in product((0, 1), repeat=4):
            phi = (entries[:2], entries[2:])
            offset = (-1, 2)
            for query in product((-1, 0, 1), repeat=2):
                lifted, constants = checker.affine_pullback(phi, offset, (query,), width=2)
                for latent in product((-1, 0, 1), repeat=2):
                    snapshot = tuple(dot(row, latent) + c for row, c in zip(phi, offset))
                    self.assertEqual(dot(query, snapshot), dot(lifted[0], latent) + constants[0])

    def test_public_map_change_can_make_a_protected_quantity_constant(self):
        rows, offsets = checker.affine_pullback(((0, 0), (0, 1)), (7, 0), ((1, 0),), width=2)
        self.assertEqual(offsets, (7,))
        self.assertTrue(identifies([], rows[0]))
        self.assertFalse(admit_release([], ((0, 1),), rows))

    def test_exact_rationals_and_invalid_shapes(self):
        near = Fraction(1, 10**80)
        rows, constants = checker.affine_pullback(((1, 0), (0, 1)), (0, 0),
                                                  ((1, 1), (1, 1 + near)), width=2)
        self.assertEqual(constants, (0, 0))
        self.assertFalse(admit_release([], rows, ((1, 0),)))
        invalid = (
            ((), (), (), 2), (((1,),), (0,), ((1,),), 2),
            (((1, 0),), (), ((1,),), 2), (((1, 0),), (0,), ((1, 0),), 2),
            (((1, 0),), (0,), (), 0), (((1, 0),), (0.1,), (), 2),
            (((1, 0),), (False,), (), 2),
        )
        for phi, offset, query, width in invalid:
            with self.subTest(input=(phi, offset, query, width)), self.assertRaises(ValueError):
                checker.affine_pullback(phi, offset, query, width=width)
        with self.assertRaises(ValueError):
            checker.normalize_observation(((1,),), (0,), ((1,),), (), width=1)


class FibreTests(unittest.TestCase):
    def test_public_gate_releases_a_useful_entire_answer_map(self):
        self.assertEqual(checker.public_answer_admission((0, 0, 1, 1), ((0, 1, 0, 1),), (2,)),
                         (("Answer", 0), ("Answer", 0), ("Answer", 1), ("Answer", 1)))

    def test_actual_answer_gate_refuses_only_at_a_secret_singleton(self):
        raw = (0, 1, 1)
        protected = ((0, 1, 2),)
        actual = (("Refuse",), ("Answer", 1), ("Answer", 1))
        failures = checker.fibre_obstructions(actual, protected, (2,))
        self.assertEqual(tuple(f.worlds for f in failures), ((0,),))
        admitted = checker.public_answer_admission(raw, protected, (2,))
        self.assertEqual(admitted, (("Refuse",),) * 3)
        self.assertEqual(checker.fibre_obstructions(admitted, protected, (2,)), ())

    def test_censored_actual_fibres_can_be_safe_when_raw_fibres_are_unsafe(self):
        protected = ((0, 1, 2, 3),)
        self.assertTrue(checker.fibre_obstructions((0, 1, 2, 2), protected, (2,)))
        censored = (("Refuse",), ("Refuse",), ("Answer", 2), ("Answer", 2))
        self.assertEqual(checker.fibre_obstructions(censored, protected, (2,)), ())

    def test_private_permission_gate_can_reveal_a_secret_despite_safe_raw_answers(self):
        protected = ((0, 0, 1, 1),)
        raw = (0, 1, 0, 1)
        self.assertEqual(checker.fibre_obstructions(raw, protected, (2,)), ())
        actual = (("Answer", 0), ("Answer", 1), ("Refuse",), ("Refuse",))
        self.assertEqual(len(checker.fibre_obstructions(actual, protected, (2,))), 3)

    def test_refusal_pending_reason_timing_and_identifier_are_all_visible(self):
        for field in ("reason", "timing", "query-id", "profile-id", "effect"):
            for status in ("Refuse", "Pending", "Answer"):
                outputs = ((status, field, 0), (status, field, 1), (status, "shared"), (status, "shared"))
                with self.subTest(field=field, status=status):
                    self.assertEqual(tuple(f.worlds for f in checker.fibre_obstructions(
                        outputs, ((0, 1, 2, 3),), (2,))), ((0,), (1,)))

    def test_distinct_serialized_outputs_cannot_merge_through_python_numeric_equality(self):
        for value in (False, 0.0, Fraction(0), None, frozenset()):
            with self.subTest(value=value), self.assertRaises(ValueError):
                checker.fibre_obstructions((("Answer", value), ("Answer", 0)), ((0, 1),), (2,))
        canonical = (b'["Answer",false]', b'["Answer",0]')
        self.assertEqual(len(checker.fibre_obstructions(canonical, ((0, 1),), (2,))), 2)
        with self.assertRaises(ValueError):
            checker.fibre_obstructions((0, 0), ((False, 0),), (2,))

    def test_count_distinct_protected_values_and_check_every_attribute(self):
        failures = checker.fibre_obstructions((0, 0, 1, 1), ((0, 0, 1, 1),), (2,))
        self.assertEqual(tuple(f.values for f in failures), (frozenset({0}), frozenset({1})))
        failures = checker.fibre_obstructions((0, 0, 1, 1),
                                              ((0, 1, 0, 1), (0, 0, 1, 1)), (2, 2))
        self.assertEqual(tuple(f.attribute for f in failures), (1, 1))

    def test_all_small_output_maps_match_direct_possible_value_enumeration(self):
        secret = (0, 0, 1, 1)
        for outputs in product(range(3), repeat=4):
            expected = {y for y in outputs if len({secret[w] for w in range(4) if outputs[w] == y}) < 2}
            found = {f.output for f in checker.fibre_obstructions(outputs, (secret,), (2,))}
            self.assertEqual(found, expected)

    def test_adaptive_history_prevents_two_separately_safe_answers_from_composing(self):
        first, second, secret = (0, 0, 1, 1), (0, 1, 0, 1), (0, 1, 1, 0)
        self.assertEqual(checker.fibre_obstructions(first, (secret,), (2,)), ())
        self.assertEqual(checker.fibre_obstructions(second, (secret,), (2,)), ())
        for _, belief in checker.output_fibres(first):
            self.assertTrue(checker.fibre_obstructions(second, (secret,), (2,), belief=belief))
            gated = checker.public_answer_admission(second, (secret,), (2,), belief=belief)
            self.assertEqual(checker.output_fibres(gated, belief)[0][1], belief)

    def test_coarsening_complete_safe_outputs_preserves_ambiguity(self):
        secret = (0, 1, 0, 1)
        for outputs in ((0, 0, 1, 1), (0, 0, 0, 0)):
            self.assertEqual(checker.fibre_obstructions(outputs, (secret,), (2,)), ())

    def test_admission_retains_iterated_protection_and_belief_across_both_checks(self):
        result = checker.public_answer_admission(iter((0, 1, 2, 2)),
                                                 iter((iter((0, 1, 2, 3)),)),
                                                 iter((2,)), belief=iter(range(4)))
        self.assertEqual(result, (("Refuse",),) * 4)

    def test_profile_and_belief_validation(self):
        invalid = (
            ((), (), (), None), ((0, 1), ((0,),), (2,), None),
            ((0, 1), ((0, 1),), (), None), ((0, 1), ((0, 1),), (1,), None),
            ((0, 1), ((0, 1),), (2,), ()), ((0, 1), ((0, 1),), (2,), (0, 0)),
            ((0, 1), ((0, 1),), (2,), (2,)), ((0, 1), ((0, 1),), (2,), (True,)),
        )
        for outputs, protected, floors, belief in invalid:
            with self.subTest(input=(outputs, protected, floors, belief)), self.assertRaises(ValueError):
                checker.fibre_obstructions(outputs, protected, floors, belief=belief)
        with self.assertRaises(ValueError):
            checker.public_answer_admission((0, 0), ((1, 1),), (2,))


class SelectorTests(unittest.TestCase):
    def test_current_source_grants_supply_the_action_permission_table(self):
        compute = Grant("source", frozenset({"compute"}), "research", "team", 0, 10, 0, 10)
        train = Grant("source", frozenset({"train"}), "research", "team", 0, 10, 0, 10)
        actions = ("train", "compute")
        permitted = tuple({act for act in actions if admit_action(
            ["source"], grants, act=act, purpose="research", audience="team", at=2, retain_until=5)}
            for grants in ((compute, train), (compute,)))
        self.assertEqual(permitted, ({"compute", "train"}, {"compute"}))
        result = checker.joined_selector(actions, ("same", "same"), ((0, 1),),
                                          permitted, (set(actions),) * 2)
        self.assertEqual(result.policy, ("compute", "compute"))
        self.assertIsNone(checker.joined_selector(actions, ("same", "same"), ((0, 1),),
                                                   permitted, ({"train"},) * 2).policy)

    def test_separate_selectors_do_not_supply_a_joined_selector(self):
        actions = ("a", "b", "c", "d")
        good = ({"a", "c"}, {"a", "d"}, {"b", "c"}, {"b", "d"})
        permitted = (set(actions),) * 4
        rows, columns = (0, 0, 1, 1), ((0, 2), (1, 3))
        self.assertEqual(checker.joined_selector(actions, rows, (), permitted, good).policy,
                         ("a", "a", "b", "b"))
        self.assertEqual(checker.joined_selector(actions, range(4), columns, permitted, good).policy,
                         ("c", "d", "c", "d"))
        result = checker.joined_selector(actions, rows, columns, permitted, good)
        self.assertIsNone(result.policy)
        self.assertEqual(result.components, ((0, 1, 2, 3),))
        self.assertEqual(len(result.obstructions), 1)
        for action, witness in result.obstructions[0].excluded_by:
            self.assertNotIn(action, good[witness])

    def test_success_without_permission_cannot_supply_the_common_action(self):
        result = checker.joined_selector(("a",), (0, 0), (), ({"a"}, set()), ({"a"}, {"a"}))
        self.assertIsNone(result.policy)
        self.assertEqual(result.obstructions[0].excluded_by, (("a", 1),))

    def test_all_small_profiles_match_exhaustive_local_private_policy_search(self):
        actions = (0, 1)
        edge_universe = ((0, 1), (0, 2), (1, 2))
        for observations in ((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 2)):
            for edges in subsets(edge_universe):
                for good in product(subsets(actions), repeat=3):
                    possible = any(
                        all(policy[w] in good[w] for w in range(3))
                        and all(policy[w] == policy[v] for w, v in edges)
                        and all(observations[w] != observations[v] or policy[w] == policy[v]
                                for w in range(3) for v in range(3))
                        for policy in product(actions, repeat=3))
                    result = checker.joined_selector(actions, observations, edges, ({0, 1},) * 3, good)
                    self.assertEqual(result.policy is not None, possible)

    def test_profile_validation(self):
        for actions, observations, edges, permitted, successful in (
            ((), (0,), (), (set(),), (set(),)), ((0, 0), (0,), (), ({0},), ({0},)),
            ((0,), (), (), (), ()), ((0,), (0,), ((0, 1),), ({0},), ({0},)),
            ((0,), (0,), (), (), ({0},)), ((0,), (0,), (), ({1},), ({0},)),
            ((0,), (0,), ((0,),), ({0},), ({0},)),
            ((0,), (0,), (), ({False},), ({0},)),
        ):
            with self.subTest(input=(actions, observations, edges, permitted, successful)), self.assertRaises(ValueError):
                checker.joined_selector(actions, observations, edges, permitted, successful)


class ChannelTests(unittest.TestCase):
    def test_singleton_privacy_can_pass_while_a_combined_event_fails(self):
        rows = ((Fraction(3, 10), Fraction(3, 10), Fraction(1, 5), Fraction(1, 5)),
                (Fraction(1, 5), Fraction(1, 5), Fraction(3, 10), Fraction(3, 10)))
        self.assertTrue(all(abs(p - q) <= Fraction(1, 10) for p, q in zip(*rows)))
        failures = checker.channel_violations(tuple(range(4)), (0, 1), ((0, 1),),
                                              (set(range(4)),) * 2, (set(range(4)),) * 2,
                                              rows, E=1, delta="1/10", eta=0)
        self.assertEqual(tuple(f.event for f in failures), ((0, 1), (2, 3)))
        self.assertEqual(tuple(f.value for f in failures), (Fraction(1, 5),) * 2)

    def test_privacy_checker_matches_independent_all_event_enumeration(self):
        actions = (0, 1, 2)
        distributions = tuple(tuple(Fraction(x, 3) for x in row)
                              for row in product(range(4), repeat=3) if sum(row) == 3)
        for p, q, E, delta in product(distributions, distributions, (1, 2), (0, Fraction(1, 3))):
            expected = all(sum(p[a] for a in event) <= E * sum(q[a] for a in event) + delta
                           and sum(q[a] for a in event) <= E * sum(p[a] for a in event) + delta
                           for event in subsets(actions))
            failures = checker.channel_violations(actions, (0, 1), ((0, 1),), (set(actions),) * 2,
                                                  (set(actions),) * 2, (p, q), E=E, delta=delta, eta=0)
            self.assertEqual(not failures, expected)

    def test_sharp_route_channels_and_strictly_better_failure_requests(self):
        for k, E, delta in product(range(2, 6), (1, 2, Fraction(5, 3)), (0, Fraction(1, 5))):
            actions = tuple(range(k))
            rows = checker.private_route_channel(k, E=E, delta=delta)
            eta = (k - 1) * (1 - delta) / (Fraction(E) + k - 1)
            profile = (actions, actions, tuple(combinations(actions, 2)), (set(actions),) * k,
                       tuple({i} for i in actions), rows)
            self.assertEqual(checker.channel_violations(*profile, E=E, delta=delta, eta=eta), ())
            self.assertTrue(any(f.kind == "success" for f in checker.channel_violations(
                *profile, E=E, delta=delta, eta=eta / 2)))

    def test_private_route_selection_needs_source_knowledge(self):
        rows = checker.private_route_channel(2, E=2, delta=0)
        failures = checker.channel_violations((0, 1), ("same", "same"), ((0, 1),),
                                              ({0, 1},) * 2, ({0}, {1}), rows, E=2, delta=0, eta="1/3")
        self.assertEqual(tuple(f.kind for f in failures), ("source-view",))

    def test_prohibited_wrong_routes_have_zero_probability_even_with_delta(self):
        rows = checker.private_route_channel(2, E=2, delta="1/5")
        failures = checker.channel_violations((0, 1), (0, 1), ((0, 1),),
                                              ({0}, {1}), ({0}, {1}), rows, E=2, delta="1/5", eta=1)
        self.assertEqual(tuple(f.kind for f in failures), ("permission", "permission"))
        allowed = ({0, "refuse"}, {1, "refuse"})
        rows = (("1/5", 0, "4/5"), (0, "1/5", "4/5"))
        self.assertEqual(checker.channel_violations((0, 1, "refuse"), (0, 1), ((0, 1),),
                                                    allowed, ({0}, {1}), rows,
                                                    E=2, delta="1/5", eta="4/5"), ())

    def test_distinct_routes_without_privacy_edges_can_succeed_certainly(self):
        self.assertEqual(checker.channel_violations((0, 1), (0, 1), (), ({0}, {1}), ({0}, {1}),
                                                    ((1, 0), (0, 1)), E=1, delta=0, eta=0), ())

    def test_malformed_and_nonprobability_certificates_fail(self):
        profile = ((0, 1), (0, 1), ((0, 1),), ({0, 1},) * 2, ({0, 1},) * 2)
        failures = checker.channel_violations(*profile, ((-1, 2), (1, 1)), E=2, delta=0, eta=0)
        self.assertTrue({"negative", "normalization"} <= {f.kind for f in failures})
        for rows, E, delta, eta in ((((1,), (1,)), 2, 0, 0), (((1, 0),), 2, 0, 0),
                                    (((1, 0), (0, 1)), 0, 0, 0), (((1, 0), (0, 1)), 2, 1, 0),
                                    (((1, 0), (0, 1)), 2, 0, -1), (((1, 0), (0, 1)), 2.0, 0, 0)):
            with self.subTest(input=(rows, E, delta, eta)), self.assertRaises(ValueError):
                checker.channel_violations(*profile, rows, E=E, delta=delta, eta=eta)


class EntropyTests(unittest.TestCase):
    def privacy_failures(self, alphabet, rows):
        worlds = tuple(range(len(rows)))
        return checker.channel_violations(alphabet, worlds, tuple(combinations(worlds, 2)),
                                           (set(alphabet),) * len(rows), (set(alphabet),) * len(rows),
                                           rows, E=1, delta=0, eta=0)

    def test_private_selector_and_public_selector_have_different_observers(self):
        traces, weights = ((0, 1), (1, 0)), ("1/2", "1/2")
        private = checker.selector_channel(traces, weights)
        self.assertEqual(self.privacy_failures(*private), ())
        public = checker.selector_channel(traces, weights, reveal_selector=True)
        self.assertEqual(tuple(f.value for f in self.privacy_failures(*public)), (1, 1))
        alphabet, rows = public
        for secret, row in enumerate(rows):
            for (selector, output), probability in zip(alphabet, row):
                if probability:
                    self.assertEqual(selector ^ output, secret)

    def test_shared_and_independent_fair_selectors_have_distinct_joint_laws(self):
        shared = checker.selector_channel((((0, 0), (1, 1)),), ("1/2", "1/2"))
        independent = checker.selector_channel((tuple(product((0, 1), repeat=2)),), ("1/4",) * 4)
        for (alphabet, rows), agreement in ((shared, 1), (independent, Fraction(1, 2))):
            self.assertEqual(sum(p for pair, p in zip(alphabet, rows[0]) if pair[0] == pair[1]), agreement)
            for coordinate in (0, 1):
                self.assertEqual(sum(p for pair, p in zip(alphabet, rows[0]) if pair[coordinate] == 0),
                                 Fraction(1, 2))

    def test_separately_private_marginals_can_reveal_the_secret_jointly(self):
        joint = tuple(tuple((r, secret ^ r) for r in (0, 1)) for secret in (0, 1))
        for coordinate in (0, 1):
            marginal = tuple(tuple(trace[coordinate] for trace in row) for row in joint)
            self.assertEqual(self.privacy_failures(*checker.selector_channel(marginal, ("1/2",) * 2)), ())
        alphabet, rows = checker.selector_channel(joint, ("1/2",) * 2)
        self.assertTrue(self.privacy_failures(alphabet, rows))
        for secret, row in enumerate(rows):
            self.assertEqual(sum(p for (r, masked), p in zip(alphabet, row) if r ^ masked == secret), 1)

    def test_reused_mask_reveals_parity_while_fresh_independent_masks_do_not(self):
        worlds = tuple(product((0, 1), repeat=2))
        reused = tuple(tuple((s ^ r, t ^ r) for r in (0, 1)) for s, t in worlds)
        alphabet, rows = checker.selector_channel(reused, ("1/2",) * 2)
        self.assertTrue(self.privacy_failures(alphabet, rows))
        for (s, t), row in zip(worlds, rows):
            self.assertEqual(sum(p for (a, b), p in zip(alphabet, row) if a ^ b == s ^ t), 1)
        fresh = tuple(tuple((s ^ r, t ^ u) for r, u in product((0, 1), repeat=2)) for s, t in worlds)
        alphabet, rows = checker.selector_channel(fresh, ("1/4",) * 4)
        self.assertEqual(self.privacy_failures(alphabet, rows), ())
        self.assertEqual(rows, ((Fraction(1, 4),) * 4,) * 4)

    def test_public_prefix_can_correlate_initially_independent_selectors(self):
        selectors = tuple(product((0, 1), repeat=2))
        traces = (tuple((a ^ b, (a, b)) for a, b in selectors),)
        alphabet, rows = checker.selector_channel(traces, ("1/4",) * 4)
        prefix_mass = sum(p for (parity, pair), p in zip(alphabet, rows[0]) if parity == 0)
        posterior = {pair: p / prefix_mass for (parity, pair), p in zip(alphabet, rows[0]) if parity == 0}
        self.assertEqual(posterior, {(0, 0): Fraction(1, 2), (1, 1): Fraction(1, 2)})
        self.assertNotEqual(posterior[(0, 0)], Fraction(1, 2) * Fraction(1, 2))

    def test_private_trace_laws_need_not_have_equal_selector_posteriors(self):
        traces = (((0, 0), (1, 0)), ((1, 0), (0, 0)))
        self.assertEqual(self.privacy_failures(*checker.selector_channel(traces, ("1/2",) * 2)), ())
        posteriors = tuple(tuple(int(trace[0] == 0) for trace in row) for row in traces)
        self.assertEqual(posteriors, ((1, 0), (0, 1)))
        for row in traces:
            self.assertEqual({trace[1] for trace in row if trace[0] == 0}, {0})

    def test_first_output_is_checked_even_without_a_shared_nonempty_prefix(self):
        alphabet, rows = checker.selector_channel((((0,),), ((1,),)), (1,))
        self.assertEqual(tuple(f.value for f in self.privacy_failures(alphabet, rows)), (1, 1))

    def test_selector_validation_and_zero_weight_tables(self):
        alphabet, rows = checker.selector_channel(((0, 1), (0, 2)), (1, 0))
        self.assertEqual(self.privacy_failures(alphabet, rows), ())
        invalid = (((), ()), (((0,),), ()), (((0,),), ("1/2",)),
                   (((0, 1),), (-1, 2)), (((0,),), (1, 0)), (((False,),), (1,)),
                   (((0,),), (1.0,)))
        for traces, weights in invalid:
            with self.subTest(input=(traces, weights)), self.assertRaises(ValueError):
                checker.selector_channel(traces, weights)


class ExecutionTests(unittest.TestCase):
    def test_cli_self_checks_run_in_normal_and_optimized_python(self):
        script = Path(checker.__file__)
        for flags in ([], ["-O"]):
            result = subprocess.run([sys.executable, *flags, str(script)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("13 checks passed", result.stdout)

    def test_self_test_checks_actual_fibre_and_channel_functions(self):
        for function in ("fibre_obstructions", "channel_violations"):
            with self.subTest(function=function), patch.object(checker, function, return_value=()):
                with self.assertRaises(AssertionError):
                    checker.self_test()

    def test_semantic_mutations_are_detected_without_writing_source_files(self):
        mutations = (
            ("groups.setdefault(outputs[w], []).append(w)",
             "groups.setdefault('constant', []).append(w)",
             "FibreTests.test_refusal_pending_reason_timing_and_identifier_are_all_visible"),
            ("common &= permitted[w] & successful[w]", "common &= successful[w]",
             "SelectorTests.test_success_without_permission_cannot_supply_the_common_action"),
            ("pending.extend(neighbours[w] - component)", "pending.extend(())",
             "SelectorTests.test_separate_selectors_do_not_supply_a_joined_selector"),
            ("gap = sum((max(value, Fraction(0)) for value in differences), Fraction(0))",
             "gap = max((max(value, Fraction(0)) for value in differences), default=Fraction(0))",
             "ChannelTests.test_singleton_privacy_can_pass_while_a_combined_event_fails"),
            ("return lifted, tuple(y - c for y, c in zip(answers, constants))",
             "return lifted, answers", "AffineTests.test_later_snapshot_cannot_reset_the_observation_history"),
            ("(j, trace) if reveal_selector else trace", "trace",
             "EntropyTests.test_private_selector_and_public_selector_have_different_observers"),
        )
        harness = """
import pathlib, sys, types, unittest
folder, old, new, target = sys.argv[1:]
sys.path.insert(0, folder)
source = pathlib.Path(folder, 'verify_sjn_observation_policy.py').read_text()
if source.count(old) != 1:
    raise RuntimeError('mutation anchor must be unique')
module = types.ModuleType('verify_sjn_observation_policy')
module.__file__ = str(pathlib.Path(folder, 'verify_sjn_observation_policy.py'))
sys.modules[module.__name__] = module
exec(compile(source.replace(old, new), module.__file__, 'exec'), module.__dict__)
suite = unittest.defaultTestLoader.loadTestsFromName('test_verify_sjn_observation_policy.' + target)
result = unittest.TextTestRunner().run(suite)
if result.testsRun != 1 or result.wasSuccessful() or result.errors:
    raise RuntimeError('semantic mutant was not rejected by its behavioral test')
"""
        for old, new, target in mutations:
            with self.subTest(target=target):
                result = subprocess.run([sys.executable, "-c", harness, str(Path(checker.__file__).parent),
                                         old, new, target], capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
