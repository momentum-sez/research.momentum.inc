# Finite Compliance Relations

This supplement contains an exact finite relation checker and its tests for
*How Compliance Composes*. It covers rectangularity, the bit triangle,
join trees, separator equality, exhaustive joins, projections, and local
extensions. Its source-choice example selects one applicable source cell
per coordinate and derives each grade directly from that cell.

Use Python 3.9 or newer. The recorded run used Python 3.9.6.
No external packages are required. From this extracted directory, run:

```sh
python3 -B verify_compliance_join_tree.py
python3 -B -O verify_compliance_join_tree.py
python3 -B -m unittest -v test_verify_compliance_join_tree.py
python3 -B -O -m unittest -v test_verify_compliance_join_tree.py
```

Each checker run prints:

```json
{"checked_assignments": 8, "constructed_extensions": 4, "global_witnesses": 2}
```

Each test run must report 22 tests and OK. The tests enumerate 377 small
relations and all 4,096 binary three-table path families. Exactly 712
families have equal separator projections. Adverse cases include empty
scopes, omitted global constraints, stale profiles, changed source
conditions, unrelated decoders, and altered source bodies. Local-decision
examples retain Refuse, Await, current guards, grade caps, and thresholds.

PROFILE.json records the complete declared example and reproduction
profile. Authentication results, source owners, current adverse conditions,
and local judgments are supplied model inputs. These checks do not prove
cryptographic authentication, legal adoption, completeness of actual source
records, or evaluator refinement. A digest identifies the finite profile
and supplies no authority.

CHECKSUMS.sha256 contains SHA-256 values for every other archive member.
It excludes itself. Verify it before running the programs:

```sh
shasum -a 256 -c CHECKSUMS.sha256
```

The archive uses sorted member names and a fixed timestamp. It contains no
paper or PDF digest. The release records its archive association separately.
