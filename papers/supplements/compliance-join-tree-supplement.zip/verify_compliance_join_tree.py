#!/usr/bin/env python3
"""Exact finite relations and witness binding for How Compliance Composes.

Values are finite string symbols. The witness specialization selects one
applicable source cell per coordinate and derives its grade directly from that
cell. Authentication results, source ownership, and adverse conditions are
declared inputs. This program does not verify signatures or interpret law.
All checks remain active under Python optimization. No external packages are used.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from itertools import product
import json
from typing import Iterable

Row = tuple[str, ...]
Edge = tuple[int, int]


class CheckError(ValueError):
    """A finite input or a claimed certificate fails its check."""


def _need(condition: bool, message: str) -> None:
    if not condition:
        raise CheckError(message)


def _symbols(values: Iterable[str], name: str) -> tuple[str, ...]:
    _need(not isinstance(values, str), f"{name}: expected a collection")
    result = tuple(values)
    _need(all(isinstance(v, str) and v for v in result),
          f"{name}: expected nonempty string symbols")
    return result


def _integer(value: int) -> bool:
    return type(value) is int


def _restrict(scope: tuple[str, ...], row: Row, target: tuple[str, ...]) -> Row:
    values = dict(zip(scope, row))
    return tuple(values[c] for c in target)


@dataclass(frozen=True)
class Relation:
    scope: tuple[str, ...]
    rows: tuple[Row, ...]

    def __post_init__(self) -> None:
        original = _symbols(self.scope, "relation scope")
        _need(len(set(original)) == len(original), "duplicate coordinate")
        scope = tuple(sorted(original))
        rows = []
        for raw in self.rows:
            row = _symbols(raw, "relation row")
            _need(len(row) == len(original), "relation row has wrong arity")
            rows.append(_restrict(original, row, scope))
        object.__setattr__(self, "scope", scope)
        object.__setattr__(self, "rows", tuple(sorted(set(rows))))

    def project(self, coordinates: Iterable[str]) -> Relation:
        scope = _symbols(coordinates, "projection scope")
        _need(len(set(scope)) == len(scope), "duplicate projection coordinate")
        _need(set(scope) <= set(self.scope), "projection exceeds relation scope")
        return Relation(scope, tuple(_restrict(self.scope, row, scope)
                                     for row in self.rows))


def rectangularity_obstruction(relation: Relation) -> Row | None:
    """Return the first missing recombination, or None for an exact product."""
    values = [tuple(row[0] for row in relation.project((c,)).rows)
              for c in relation.scope]
    present = set(relation.rows)
    return next((row for row in product(*values) if row not in present), None)


def natural_join(relations: Iterable[Relation]) -> Relation:
    """Enumerate the full join over the union of the supplied scopes."""
    relations = tuple(relations)
    scope = tuple(sorted({c for r in relations for c in r.scope}))
    values = {c: set() for c in scope}
    for relation in relations:
        for row in relation.rows:
            for c, value in zip(relation.scope, row):
                values[c].add(value)
    tables = tuple(set(r.rows) for r in relations)
    candidates = product(*(sorted(values[c]) for c in scope))
    rows = tuple(row for row in candidates if all(
        _restrict(scope, row, r.scope) in table
        for r, table in zip(relations, tables)))
    return Relation(scope, rows)


def validate_tree(relations: tuple[Relation, ...], edges: Iterable[Edge]
                  ) -> tuple[tuple[int, ...], ...]:
    """Check the graph and running intersection, including repeated scopes."""
    count = len(relations)
    normalized = []
    for edge in edges:
        _need(len(edge) == 2, "tree edge must have two endpoints")
        a, b = edge
        _need(_integer(a) and _integer(b) and 0 <= a < count and 0 <= b < count,
              "tree edge has an unknown endpoint")
        _need(a != b, "tree edge is a loop")
        normalized.append(tuple(sorted((a, b))))
    _need(len(set(normalized)) == len(normalized), "duplicate tree edge")
    _need(len(normalized) == max(0, count - 1), "tree edge count is incorrect")
    adjacency: list[list[int]] = [[] for _ in relations]
    for a, b in normalized:
        adjacency[a].append(b)
        adjacency[b].append(a)

    def reached(start: int, allowed: set[int]) -> set[int]:
        seen = {start}
        todo = [start]
        for node in todo:
            for child in adjacency[node]:
                if child in allowed and child not in seen:
                    seen.add(child)
                    todo.append(child)
        return seen

    if count:
        _need(len(reached(0, set(range(count)))) == count, "tree is disconnected")
    for coordinate in sorted({c for r in relations for c in r.scope}):
        containing = {i for i, r in enumerate(relations) if coordinate in r.scope}
        _need(reached(min(containing), containing) == containing,
              f"running intersection fails at {coordinate}")
    return tuple(tuple(sorted(neighbors)) for neighbors in adjacency)


def _separators(relations: tuple[Relation, ...], adjacency: tuple[tuple[int, ...], ...]
                ) -> None:
    for a, neighbors in enumerate(adjacency):
        for b in neighbors:
            if a < b:
                separator = tuple(sorted(set(relations[a].scope) & set(relations[b].scope)))
                _need(relations[a].project(separator) == relations[b].project(separator),
                      f"separator projections differ at edge {a},{b}")


def _extend(relations: tuple[Relation, ...], adjacency: tuple[tuple[int, ...], ...],
            root: int, local_row: Row) -> Row:
    _need(_integer(root) and 0 <= root < len(relations), "unknown root relation")
    _need(local_row in relations[root].rows, "selected tuple is not local")
    assignment = dict(zip(relations[root].scope, local_row))
    visited = {root}
    todo = [root]
    for node in todo:
        for child in adjacency[node]:
            if child in visited:
                continue
            relation = relations[child]
            match = next((row for row in relation.rows if all(
                c not in assignment or assignment[c] == value
                for c, value in zip(relation.scope, row))), None)
            _need(match is not None, f"no extension at relation {child}")
            assignment.update(zip(relation.scope, match))
            visited.add(child)
            todo.append(child)
    return tuple(assignment[c] for c in sorted(assignment))


def extend_tuple(relations: Iterable[Relation], edges: Iterable[Edge],
                 root: int, local_row: Row) -> Row:
    relations = tuple(relations)
    adjacency = validate_tree(relations, edges)
    _separators(relations, adjacency)
    return _extend(relations, adjacency, root, local_row)


@dataclass(frozen=True)
class Extension:
    root: int
    local_row: Row
    global_row: Row


@dataclass(frozen=True)
class JoinTreeResult:
    joined: Relation
    extensions: tuple[Extension, ...]


def check_join_tree(relations: Iterable[Relation], edges: Iterable[Edge]) -> JoinTreeResult:
    """Compare exhaustive joins and projections with every constructed extension."""
    relations = tuple(relations)
    adjacency = validate_tree(relations, edges)
    _separators(relations, adjacency)
    joined = natural_join(relations)
    extensions = []
    for root, relation in enumerate(relations):
        _need(joined.project(relation.scope) == relation, "global projection differs")
        for row in relation.rows:
            whole = _extend(relations, adjacency, root, row)
            _need(whole in joined.rows, "constructed tuple is outside the full join")
            _need(_restrict(joined.scope, whole, relation.scope) == row,
                  "extension changed the selected tuple")
            extensions.append(Extension(root, row, whole))
    return JoinTreeResult(joined, tuple(extensions))


@dataclass(frozen=True)
class Context:
    destination: str
    request_id: str
    subject: str
    act: str
    purpose: str
    authority_snapshot: str
    rule_pack: str
    guard_snapshot: str
    at: int

    def __post_init__(self) -> None:
        _symbols((self.destination, self.request_id, self.subject, self.act,
                  self.purpose, self.authority_snapshot, self.rule_pack,
                  self.guard_snapshot), "context")
        _need(_integer(self.at), "use time must be an integer")


@dataclass(frozen=True)
class SourceCell:
    identifier: str
    fact: str
    issuer: str
    subject: str
    act: str
    purpose: str
    rule_pack: str
    issue_anchor: str
    valid_from: int
    valid_until: int
    grade: int
    authenticated: bool
    dependencies: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _symbols((self.identifier, self.fact, self.issuer, self.subject, self.act,
                  self.purpose, self.rule_pack, self.issue_anchor), "source cell")
        _need(_integer(self.valid_from) and _integer(self.valid_until)
              and self.valid_from < self.valid_until, "invalid original validity interval")
        _need(_integer(self.grade) and self.grade >= 0, "grade must be a nonnegative integer")
        _need(type(self.authenticated) is bool, "authentication result must be Boolean")
        dependencies = _symbols(self.dependencies, "source dependencies")
        object.__setattr__(self, "dependencies", tuple(sorted(set(dependencies))))


@dataclass(frozen=True)
class WitnessProfile:
    context: Context
    choices: tuple[tuple[str, tuple[str, ...]], ...]
    sources: tuple[SourceCell, ...]
    owners: tuple[tuple[str, str], ...]
    revoked: tuple[str, ...] = ()
    superseded: tuple[str, ...] = ()
    forbidden_sets: tuple[tuple[str, ...], ...] = ()

    def __post_init__(self) -> None:
        coordinates = _symbols((c for c, _ in self.choices), "profile coordinates")
        _need(len(set(coordinates)) == len(coordinates), "duplicate profile coordinate")
        choices = tuple(sorted((c, tuple(sorted(set(_symbols(values, "source choices")))))
                               for c, values in self.choices))
        sources = {}
        for cell in self.sources:
            _need(cell.identifier not in sources or sources[cell.identifier] == cell,
                  "one source identifier has conflicting bodies")
            sources[cell.identifier] = cell
        owners = tuple(self.owners)
        _symbols((c for c, _ in owners), "owned facts")
        _symbols((owner for _, owner in owners), "source owners")
        _need(len({c for c, _ in owners}) == len(owners), "duplicate source ownership")
        _need(set(coordinates) <= {c for c, _ in owners}, "missing source ownership")
        revoked = tuple(sorted(set(_symbols(self.revoked, "revoked sources"))))
        superseded = tuple(sorted(set(_symbols(self.superseded, "superseded sources"))))
        forbidden = tuple(sorted(set(tuple(sorted(set(_symbols(part, "forbidden support"))))
                                     for part in self.forbidden_sets)))
        references = set(revoked) | set(superseded)
        references.update(s for _, values in choices for s in values)
        references.update(s for cell in sources.values() for s in cell.dependencies)
        references.update(s for part in forbidden for s in part)
        _need(references <= set(sources), "profile references an unknown source")
        object.__setattr__(self, "choices", choices)
        object.__setattr__(self, "sources", tuple(sources[s] for s in sorted(sources)))
        object.__setattr__(self, "owners", tuple(sorted(owners)))
        object.__setattr__(self, "revoked", revoked)
        object.__setattr__(self, "superseded", superseded)
        object.__setattr__(self, "forbidden_sets", forbidden)

    @property
    def scope(self) -> tuple[str, ...]:
        return tuple(c for c, _ in self.choices)

    def assignments(self) -> Iterable[Row]:
        return product(*(values for _, values in self.choices))


@dataclass(frozen=True)
class CandidateWitness:
    assignment: tuple[tuple[str, str], ...]
    sources: tuple[SourceCell, ...]
    derivation: tuple[tuple[str, str, int], ...]


def decode(profile: WitnessProfile, row: Row) -> CandidateWitness:
    """Retain exactly the selected cells and their direct leaf derivations."""
    _need(len(row) == len(profile.choices), "witness assignment has wrong arity")
    _need(all(value in choices for value, (_, choices) in zip(row, profile.choices)),
          "witness assignment is outside the profile")
    catalogue = {cell.identifier: cell for cell in profile.sources}
    return CandidateWitness(
        tuple(zip(profile.scope, row)),
        tuple(catalogue[s] for s in sorted(set(row))),
        tuple((c, s, catalogue[s].grade) for c, s in zip(profile.scope, row)),
    )


def valid_witness(profile: WitnessProfile, row: Row, witness: CandidateWitness) -> bool:
    """Check realization, exact derivation, and all declared source constraints."""
    if witness != decode(profile, row):
        return False
    context = profile.context
    owners = dict(profile.owners)
    selected = {cell.identifier: cell for cell in witness.sources}
    for coordinate, identifier in witness.assignment:
        cell = selected[identifier]
        if (cell.fact != coordinate or cell.issuer != owners[coordinate]
                or not cell.authenticated or cell.subject != context.subject
                or cell.act != context.act or cell.purpose != context.purpose
                or cell.rule_pack != context.rule_pack
                or not cell.valid_from <= context.at < cell.valid_until
                or identifier in profile.revoked or identifier in profile.superseded
                or not set(cell.dependencies) <= set(selected)):
            return False
    return not any(set(part) <= set(selected) for part in profile.forbidden_sets)


@dataclass(frozen=True)
class BindingResult:
    checked_assignments: int
    admissible: Relation


def check_profile_binding(profile: WitnessProfile,
                          relations: Iterable[Relation]) -> BindingResult:
    """Check the local conjunction iff the complete witness checks, on every input."""
    relations = tuple(relations)
    scope = tuple(sorted({c for r in relations for c in r.scope}))
    _need(scope == profile.scope, "relation scopes do not cover the exact profile")
    choices = dict(profile.choices)
    for relation in relations:
        for row in relation.rows:
            _need(all(value in choices[c] for c, value in zip(relation.scope, row)),
                  "local relation contains an unknown source choice")
    tables = tuple(set(r.rows) for r in relations)
    admitted = []
    checked = 0
    for row in profile.assignments():
        checked += 1
        local = all(_restrict(scope, row, r.scope) in table
                    for r, table in zip(relations, tables))
        whole = valid_witness(profile, row, decode(profile, row))
        if local != whole:
            kind = "admit an unsupported" if local else "omit an admissible"
            raise CheckError(f"local constraints {kind} tuple: {row}")
        if whole:
            admitted.append(row)
    return BindingResult(checked, Relation(scope, tuple(admitted)))


def profile_identity(profile: WitnessProfile, relations: Iterable[Relation],
                     edges: Iterable[Edge]) -> str:
    """Identify the complete finite input. The digest supplies no authority."""
    body = {"schema": "finite-compliance-relations-1", "profile": asdict(profile),
            "relations": [asdict(r) for r in relations],
            "edges": sorted(tuple(sorted(edge)) for edge in edges)}
    return sha256(json.dumps(body, sort_keys=True, separators=(",", ":"),
                             ensure_ascii=True).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class LinkCertificate:
    profile_identity: str
    root: int
    local_row: Row
    global_row: Row
    local_restrictions: tuple[Row, ...]
    witness: CandidateWitness


def link_certificate(profile: WitnessProfile, relations: Iterable[Relation],
                     edges: Iterable[Edge], root: int, local_row: Row) -> LinkCertificate:
    relations, edges = tuple(relations), tuple(edges)
    check_profile_binding(profile, relations)
    check_join_tree(relations, edges)
    row = extend_tuple(relations, edges, root, local_row)
    return LinkCertificate(
        profile_identity(profile, relations, edges), root, local_row, row,
        tuple(_restrict(profile.scope, row, r.scope) for r in relations),
        decode(profile, row),
    )


def verify_link(certificate: LinkCertificate, profile: WitnessProfile,
                relations: Iterable[Relation], edges: Iterable[Edge], *,
                expected_identity: str) -> CandidateWitness:
    """Check a link against the relying context's separately selected identity."""
    relations, edges = tuple(relations), tuple(edges)
    identity = profile_identity(profile, relations, edges)
    _need(identity == expected_identity == certificate.profile_identity,
          "certificate profile identity differs from the relying context")
    check_profile_binding(profile, relations)
    result = check_join_tree(relations, edges)
    root = certificate.root
    _need(_integer(root) and 0 <= root < len(relations), "unknown certificate root")
    _need(certificate.local_row in relations[root].rows, "certificate tuple is not local")
    row = certificate.global_row
    _need(row in result.joined.rows, "certificate tuple is outside the full join")
    restrictions = tuple(_restrict(profile.scope, row, r.scope) for r in relations)
    _need(certificate.local_restrictions == restrictions,
          "certificate local restrictions differ")
    _need(restrictions[root] == certificate.local_row,
          "certificate changed the selected local tuple")
    _need(valid_witness(profile, row, certificate.witness),
          "certificate witness does not realize the assignment")
    return certificate.witness


@dataclass(frozen=True)
class LocalDecision:
    profile_identity: str
    assignment: Row
    verdict: str
    cap: tuple[int, ...]
    threshold: tuple[int, ...]
    current: bool


def allows(certificate: LinkCertificate, decision: LocalDecision,
           profile: WitnessProfile, relations: Iterable[Relation], edges: Iterable[Edge], *,
           expected_identity: str) -> bool:
    """Apply a supplied local decision and chain threshold to the same witness."""
    witness = verify_link(certificate, profile, relations, edges,
                          expected_identity=expected_identity)
    _need(decision.profile_identity == expected_identity
          and decision.assignment == certificate.global_row, "local decision binding differs")
    _need(decision.verdict in {"Permit", "Refuse", "Await"}, "unknown local decision")
    _need(type(decision.current) is bool, "current guard result must be Boolean")
    size = len(profile.scope)
    _need(len(decision.cap) == size == len(decision.threshold), "decision grade arity differs")
    _need(all(_integer(v) and v >= 0 for v in (*decision.cap, *decision.threshold)),
          "decision grades must be nonnegative integers")
    grades = tuple(grade for _, _, grade in witness.derivation)
    return (decision.verdict == "Permit" and decision.current
            and all(min(grade, cap) >= target
                    for grade, cap, target in zip(grades, decision.cap, decision.threshold)))


def example_profile() -> tuple[WitnessProfile, tuple[Relation, ...], tuple[Edge, ...]]:
    """A declared three-coordinate source-choice path with exact pair constraints."""
    context = Context("B", "request", "subject", "act", "purpose", "authority",
                      "rules", "guards", 5)
    cells = tuple(SourceCell(f"{c}{bit}", c, f"owner-{c}", "subject", "act", "purpose",
                             "rules", f"issue-{c}{bit}", 0, 10, bit, True)
                  for c in ("x", "y", "z") for bit in (0, 1))
    profile = WitnessProfile(
        context, tuple((c, (f"{c}0", f"{c}1")) for c in ("x", "y", "z")), cells,
        tuple((c, f"owner-{c}") for c in ("x", "y", "z")),
        forbidden_sets=(("x0", "y0"), ("x1", "y1"), ("y0", "z0"), ("y1", "z1")),
    )
    relations = (Relation(("x", "y"), (("x0", "y1"), ("x1", "y0"))),
                 Relation(("y", "z"), (("y0", "z1"), ("y1", "z0"))))
    return profile, relations, ((0, 1),)


def self_test() -> dict[str, int]:
    profile, relations, edges = example_profile()
    binding = check_profile_binding(profile, relations)
    result = check_join_tree(relations, edges)
    for extension in result.extensions:
        certificate = link_certificate(profile, relations, edges,
                                       extension.root, extension.local_row)
        verify_link(certificate, profile, relations, edges,
                    expected_identity=profile_identity(profile, relations, edges))
    triangle = tuple(Relation(scope, (("0", "1"), ("1", "0")))
                     for scope in (("x", "y"), ("y", "z"), ("z", "x")))
    _need(natural_join(triangle).rows == (), "the bit triangle acquired a global tuple")
    _need(rectangularity_obstruction(Relation((), ())) == (), "nullary failure was lost")
    return {"checked_assignments": binding.checked_assignments,
            "global_witnesses": len(result.joined.rows),
            "constructed_extensions": len(result.extensions)}


if __name__ == "__main__":
    print(json.dumps(self_test(), sort_keys=True))
