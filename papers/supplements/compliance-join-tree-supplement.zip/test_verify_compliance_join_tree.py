"""Adverse and exhaustive finite checks for relation extension and witness binding."""
from dataclasses import replace
from itertools import combinations, product
import unittest

from verify_compliance_join_tree import (
    CheckError, LocalDecision, Relation, WitnessProfile, allows,
    check_join_tree, check_profile_binding, decode, example_profile, extend_tuple,
    link_certificate, natural_join, profile_identity, rectangularity_obstruction,
    valid_witness, validate_tree, verify_link,
)


def subsets(rows):
    rows = tuple(rows)
    return tuple(tuple(row for i, row in enumerate(rows) if mask & (1 << i))
                 for mask in range(1 << len(rows)))


class RelationTests(unittest.TestCase):
    def test_rectangularity_including_empty_domains(self):
        checked = 0
        for width in range(4):
            scope = tuple(f"c{i}" for i in range(width))
            for sizes in product(range(3), repeat=width):
                universe = tuple(product(*(tuple(str(v) for v in range(size))
                                           for size in sizes)))
                for rows in subsets(universe):
                    relation = Relation(scope, rows)
                    feasible_values = tuple({row[i] for row in rows} for i in range(width))
                    recombinations = set(product(*feasible_values))
                    obstruction = rectangularity_obstruction(relation)
                    if set(rows) == recombinations:
                        self.assertIsNone(obstruction)
                    else:
                        self.assertIsNotNone(obstruction)
                        self.assertIn(obstruction, recombinations - set(rows))
                    checked += 1
        self.assertEqual(checked, 377)

    def test_nullary_and_empty_projection_conventions(self):
        false = Relation((), ())
        true = Relation((), ((),))
        self.assertEqual(rectangularity_obstruction(false), ())
        self.assertIsNone(rectangularity_obstruction(true))
        self.assertEqual(Relation(("x",), ()).project(()), false)
        self.assertEqual(Relation(("x",), (("0",),)).project(()), true)
        self.assertEqual(natural_join(()), true)
        self.assertEqual(natural_join((true, false)), false)
        empty_result = check_join_tree((), ())
        self.assertEqual(empty_result.joined, true)
        self.assertEqual(empty_result.extensions, ())
        with self.assertRaisesRegex(CheckError, "root"):
            extend_tuple((), (), 0, ())

    def test_bit_triangle(self):
        relations = tuple(Relation(scope, (("0", "1"), ("1", "0")))
                          for scope in (("x", "y"), ("y", "z"), ("z", "x")))
        for a, b in combinations(range(3), 2):
            separator = set(relations[a].scope) & set(relations[b].scope)
            self.assertEqual(relations[a].project(separator), relations[b].project(separator))
            self.assertEqual(len(natural_join((relations[a], relations[b])).rows), 2)
        self.assertEqual(natural_join(relations).rows, ())
        for edges in combinations(((0, 1), (1, 2), (0, 2)), 2):
            with self.assertRaisesRegex(CheckError, "running intersection"):
                check_join_tree(relations, edges)

    def test_every_binary_path_family(self):
        pairs = tuple(product(("0", "1"), repeat=2))
        all_rows = tuple(product(("0", "1"), repeat=4))
        accepted = 0
        empty_accepted = 0
        for ab, bc, cd in product(subsets(pairs), repeat=3):
            relations = (Relation(("a", "b"), ab), Relation(("b", "c"), bc),
                         Relation(("c", "d"), cd))
            expected = tuple(row for row in all_rows
                             if row[:2] in ab and row[1:3] in bc and row[2:] in cd)
            self.assertEqual(natural_join(relations).rows, expected)
            consistent = ({row[1] for row in ab} == {row[0] for row in bc}
                          and {row[1] for row in bc} == {row[0] for row in cd})
            exact_projections = (set(ab) == {row[:2] for row in expected}
                                 and set(bc) == {row[1:3] for row in expected}
                                 and set(cd) == {row[2:] for row in expected})
            self.assertEqual(consistent, exact_projections)
            if consistent:
                result = check_join_tree(relations, ((0, 1), (1, 2)))
                self.assertEqual(result.joined.rows, expected)
                self.assertEqual(len(result.extensions), len(ab) + len(bc) + len(cd))
                for extension in result.extensions:
                    self.assertIn(extension.global_row, expected)
                    start = extension.root
                    self.assertEqual(extension.global_row[start:start + 2], extension.local_row)
                accepted += 1
                empty_accepted += not expected
        self.assertEqual(accepted, 712)
        self.assertEqual(empty_accepted, 1)

    def test_empty_separator_retains_feasibility(self):
        x = Relation(("x",), (("0",), ("1",)))
        y = Relation(("y",), (("0",), ("1",)))
        result = check_join_tree((x, y), ((0, 1),))
        self.assertEqual(len(result.joined.rows), 4)
        with self.assertRaisesRegex(CheckError, "separator"):
            check_join_tree((x, Relation(("y",), ())), ((0, 1),))
        empty = check_join_tree((Relation(("x",), ()), Relation(("y",), ())), ((0, 1),))
        self.assertEqual(empty.joined.rows, ())
        self.assertEqual(empty.extensions, ())
        self.assertEqual(check_join_tree((Relation((), ((),)), x), ((0, 1),)).joined, x)
        with self.assertRaisesRegex(CheckError, "separator"):
            check_join_tree((Relation((), ()), x), ((0, 1),))

    def test_local_extension_does_not_recover_omitted_constraint(self):
        diagonal = Relation(("x", "y"), (("0", "0"), ("1", "1")))
        relations = (diagonal.project(("x",)), diagonal.project(("y",)))
        joined = check_join_tree(relations, ((0, 1),)).joined
        self.assertEqual(len(joined.rows), 4)
        self.assertNotEqual(joined, diagonal)
        self.assertIsNotNone(rectangularity_obstruction(diagonal))

    def test_dangling_tuple_is_not_certified_by_nonempty_join(self):
        x = Relation(("x",), (("0",), ("1",)))
        xy = Relation(("x", "y"), (("0", "0"),))
        self.assertEqual(len(natural_join((x, xy)).rows), 1)
        with self.assertRaisesRegex(CheckError, "separator"):
            check_join_tree((x, xy), ((0, 1),))

    def test_repeated_scopes_and_arbitrary_root(self):
        xy = Relation(("x", "y"), (("0", "1"), ("1", "0")))
        relations = (xy, xy, xy.project(("y",)))
        result = check_join_tree(relations, ((0, 1), (1, 2)))
        self.assertEqual(result.joined, xy)
        self.assertEqual(len(result.extensions), 6)
        self.assertEqual(extend_tuple(relations, ((0, 1), (1, 2)), 2, ("0",)), ("1", "0"))

    def test_schema_normalization_and_malformed_inputs(self):
        self.assertEqual(Relation(("y", "x"), (("1", "0"), ("1", "0"))),
                         Relation(("x", "y"), (("0", "1"),)))
        for scope, rows in ((("x", "x"), (("0", "1"),)), (("x",), (("0", "1"),)),
                            (("x",), ((0,),))):
            with self.subTest(scope=scope, rows=rows), self.assertRaises(CheckError):
                Relation(scope, rows)
        one = Relation(("x",), (("0",),))
        for edges in (((0, 0),), ((0, 1), (1, 0)), ((0, 2),), ((0, True),), ()):
            with self.subTest(edges=edges), self.assertRaises(CheckError):
                validate_tree((one, one), edges)
        with self.assertRaisesRegex(CheckError, "disconnected"):
            validate_tree((one,) * 4, ((0, 1), (1, 2), (2, 0)))
        with self.assertRaisesRegex(CheckError, "not local"):
            extend_tuple((one,), (), 0, ("missing",))


class WitnessBindingTests(unittest.TestCase):
    def setUp(self):
        self.profile, self.relations, self.edges = example_profile()
        self.identity = profile_identity(self.profile, self.relations, self.edges)
        self.certificate = link_certificate(self.profile, self.relations, self.edges,
                                            0, ("x0", "y1"))

    def verify(self, certificate, profile=None, expected_identity=None):
        return verify_link(certificate, self.profile if profile is None else profile,
                           self.relations, self.edges,
                           expected_identity=self.identity if expected_identity is None
                           else expected_identity)

    def changed_source(self, identifier, **changes):
        return replace(self.profile, sources=tuple(
            replace(cell, **changes) if cell.identifier == identifier else cell
            for cell in self.profile.sources))

    def test_complete_profile_and_every_local_choice(self):
        binding = check_profile_binding(self.profile, self.relations)
        self.assertEqual(binding.checked_assignments, 8)
        self.assertEqual(binding.admissible.rows, (("x0", "y1", "z0"), ("x1", "y0", "z1")))
        for root, relation in enumerate(self.relations):
            for row in relation.rows:
                certificate = link_certificate(self.profile, self.relations, self.edges, root, row)
                self.assertEqual(self.verify(certificate), decode(self.profile, certificate.global_row))

    def test_adverse_sources_are_whole_set_constraints(self):
        changed_profiles = {
            "authentication": self.changed_source("x1", authenticated=False),
            "issuer": self.changed_source("x1", issuer="other-owner"),
            "subject": self.changed_source("x1", subject="other-subject"),
            "act": self.changed_source("x1", act="other-act"),
            "purpose": self.changed_source("x1", purpose="other-purpose"),
            "rule pack": self.changed_source("x1", rule_pack="other-rules"),
            "fact": self.changed_source("x1", fact="y"),
            "original expiry": self.changed_source("x1", valid_until=5),
            "not yet valid": self.changed_source("x1", valid_from=6),
            "revocation": replace(self.profile, revoked=("x1",)),
            "supersession": replace(self.profile, superseded=("x1",)),
            "unmet dependency": self.changed_source("x1", dependencies=("z0",)),
            "global conflict": replace(self.profile, forbidden_sets=(
                *self.profile.forbidden_sets, ("x1", "z1"))),
        }
        for name, profile in changed_profiles.items():
            with self.subTest(name=name):
                with self.assertRaisesRegex(CheckError, "admit an unsupported"):
                    check_profile_binding(profile, self.relations)
                self.assertFalse(valid_witness(profile, ("x1", "y0", "z1"),
                                              decode(profile, ("x1", "y0", "z1"))))
                repaired = (Relation(profile.scope, (("x0", "y1", "z0"),)),)
                self.assertEqual(check_profile_binding(profile, repaired).admissible, repaired[0])
                self.assertEqual(len(check_join_tree(repaired, ()).extensions), 1)

    def test_missing_global_constraint_and_overrestriction_both_fail(self):
        independent = tuple(Relation((c,), tuple((s,) for s in values))
                            for c, values in self.profile.choices)
        self.assertEqual(len(check_join_tree(independent, ((0, 1), (1, 2))).joined.rows), 8)
        with self.assertRaisesRegex(CheckError, "admit an unsupported"):
            check_profile_binding(self.profile, independent)
        restrictive = (Relation(self.profile.scope, (("x0", "y1", "z0"),)),)
        with self.assertRaisesRegex(CheckError, "omit an admissible"):
            check_profile_binding(self.profile, restrictive)

    def test_decoder_must_realize_the_same_assignment(self):
        other = link_certificate(self.profile, self.relations, self.edges, 0, ("x1", "y0"))
        forged = replace(other, witness=self.certificate.witness)
        with self.assertRaisesRegex(CheckError, "realize the assignment"):
            self.verify(forged)
        inflated = replace(self.certificate.witness,
                           derivation=(("x", "x0", 100), ("y", "y1", 1), ("z", "z0", 0)))
        with self.assertRaisesRegex(CheckError, "realize the assignment"):
            self.verify(replace(self.certificate, witness=inflated))

    def test_certificate_retains_complete_source_bodies(self):
        cells = self.certificate.witness.sources
        changed = replace(self.certificate.witness,
                          sources=(replace(cells[0], issue_anchor="new-receipt"), *cells[1:]))
        with self.assertRaisesRegex(CheckError, "realize the assignment"):
            self.verify(replace(self.certificate, witness=changed))
        with self.assertRaisesRegex(CheckError, "local restrictions"):
            self.verify(replace(self.certificate, local_restrictions=()))
        with self.assertRaisesRegex(CheckError, "selected local tuple"):
            self.verify(replace(self.certificate, local_row=("x1", "y0")))

    def test_every_context_field_and_unused_source_bind_identity(self):
        for field in ("destination", "request_id", "subject", "act", "purpose",
                      "authority_snapshot", "rule_pack", "guard_snapshot", "at"):
            value = 6 if field == "at" else "different"
            profile = replace(self.profile, context=replace(self.profile.context, **{field: value}))
            with self.subTest(field=field), self.assertRaisesRegex(CheckError, "profile identity"):
                self.verify(self.certificate, profile)
        # x1 is absent from this certificate but remains part of its finite profile.
        profile = self.changed_source("x1", issue_anchor="different-original-issue")
        with self.assertRaisesRegex(CheckError, "profile identity"):
            self.verify(self.certificate, profile)
        new_identity = profile_identity(profile, self.relations, self.edges)
        with self.assertRaisesRegex(CheckError, "profile identity"):
            self.verify(self.certificate, profile, new_identity)

    def test_table_changes_bind_identity_even_when_extension_survives(self):
        changed = (Relation(("x", "y"), (("x0", "y1"),)), self.relations[1])
        with self.assertRaisesRegex(CheckError, "profile identity"):
            verify_link(self.certificate, self.profile, changed, self.edges,
                        expected_identity=self.identity)

    def test_content_order_does_not_change_identity(self):
        profile = replace(self.profile, choices=tuple(reversed(self.profile.choices)),
                          sources=tuple(reversed(self.profile.sources)),
                          owners=tuple(reversed(self.profile.owners)),
                          forbidden_sets=tuple(tuple(reversed(s))
                                               for s in reversed(self.profile.forbidden_sets)))
        relations = tuple(Relation(tuple(reversed(r.scope)),
                                   tuple(tuple(reversed(row)) for row in reversed(r.rows)))
                          for r in self.relations)
        self.assertEqual(profile_identity(profile, relations, ((1, 0),)), self.identity)
        self.assertEqual(verify_link(self.certificate, profile, relations, ((1, 0),),
                                    expected_identity=self.identity), self.certificate.witness)

    def test_duplicate_source_body_is_not_a_new_origin(self):
        profile = replace(self.profile, sources=(*self.profile.sources, self.profile.sources[0]))
        self.assertEqual(profile, self.profile)
        with self.assertRaisesRegex(CheckError, "conflicting bodies"):
            replace(self.profile, sources=(*self.profile.sources,
                                          replace(self.profile.sources[0], grade=100)))

    def test_absent_coordinate_and_unknown_source_fail(self):
        # An empty choice set cannot silently erase a coordinate omitted by the local tables.
        missing = replace(self.profile, choices=(*self.profile.choices, ("unused", ())),
                          owners=(*self.profile.owners, ("unused", "owner")))
        with self.assertRaisesRegex(CheckError, "cover the exact profile"):
            check_profile_binding(missing, self.relations)
        with self.assertRaisesRegex(CheckError, "unknown source"):
            replace(self.profile, revoked=("unknown",))
        unknown = (Relation(("x", "y"), (("unknown", "y1"),)), self.relations[1])
        with self.assertRaisesRegex(CheckError, "unknown source choice"):
            check_profile_binding(self.profile, unknown)

    def test_empty_family_requires_a_valid_empty_witness(self):
        profile = WitnessProfile(self.profile.context, (), (), ())
        result = check_profile_binding(profile, ())
        self.assertEqual(result.checked_assignments, 1)
        self.assertEqual(result.admissible, Relation((), ((),)))
        forbidden = replace(profile, forbidden_sets=((),))
        with self.assertRaisesRegex(CheckError, "admit an unsupported"):
            check_profile_binding(forbidden, ())
        self.assertEqual(check_profile_binding(forbidden, (Relation((), ()),)).admissible.rows, ())

    def test_half_open_original_validity(self):
        profile = replace(self.profile, context=replace(self.profile.context, at=0))
        self.assertEqual(len(check_profile_binding(profile, self.relations).admissible.rows), 2)
        expired = replace(self.profile, context=replace(self.profile.context, at=10))
        with self.assertRaisesRegex(CheckError, "admit an unsupported"):
            check_profile_binding(expired, self.relations)
        empty_tables = tuple(Relation(r.scope, ()) for r in self.relations)
        self.assertEqual(check_profile_binding(expired, empty_tables).admissible.rows, ())
        self.assertEqual(check_join_tree(empty_tables, self.edges).extensions, ())

    def test_permission_keeps_each_local_conjunct(self):
        decision = LocalDecision(self.identity, self.certificate.global_row, "Permit",
                                 (1, 1, 1), (0, 1, 0), True)

        def permitted(selected):
            return allows(self.certificate, selected, self.profile, self.relations,
                          self.edges, expected_identity=self.identity)

        self.assertTrue(permitted(decision))
        for denied in (replace(decision, verdict="Refuse"), replace(decision, verdict="Await"),
                       replace(decision, current=False), replace(decision, cap=(1, 0, 1)),
                       replace(decision, threshold=(1, 1, 0))):
            self.assertFalse(permitted(denied))
        for wrong in (replace(decision, profile_identity="other"),
                      replace(decision, assignment=("x1", "y0", "z1"))):
            with self.assertRaisesRegex(CheckError, "local decision binding"):
                permitted(wrong)


if __name__ == "__main__":
    unittest.main()
