"""Verify the archive manifest and run its finite reference checks."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SUITES = (
    ("lifecycle", ".", ["verify_allocated_title.py"], 31),
    ("transfer", "models/title-transfer/reference", ["-m", "unittest", "test_transfers", "-v"], 20),
    ("durable-transfer", "models/title-transfer/reference", ["-m", "unittest", "test_durable", "-v"], 18),
    ("physical", "models/physical-performance/reference", ["-m", "unittest", "test_performance", "-v"], 19),
    ("durable-physical", "extensions/durable-physical", ["-m", "unittest", "test_durable_physical", "-v"], 16),
    ("interval", "extensions/interval-physical", ["-m", "unittest", "test_interval_physical", "-v"], 6),
    ("continuation", "extensions/physical-continuation", ["-m", "unittest", "test_continuation", "-v"], 5),
)


def verify():
    for line in (ROOT / "MANIFEST.sha256").read_text().splitlines():
        expected, relative = line.split("  ", 1)
        path = ROOT / relative
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError("Archive file mismatch: " + relative)


def run_suite(suite):
    name, directory, arguments, expected_cases = suite
    records = []
    for optimized in (False, True):
        mode = "optimized" if optimized else "normal"
        flags = ["-B", "-O"] if optimized else ["-B"]
        command = [sys.executable, *flags, *arguments]
        env = dict(os.environ)
        env["TMPDIR"] = str(ROOT / "reproduction-results/tmp")
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        start = time.monotonic()
        result = subprocess.run(command, cwd=ROOT / directory, env=env, capture_output=True)
        output = result.stdout + result.stderr
        log = f"{name}-{mode}.log"
        (ROOT / "reproduction-results" / log).write_bytes(output)
        passed = result.returncode == 0
        if name == "lifecycle" and passed:
            passed = json.loads(result.stdout)["passed"] == expected_cases
        elif passed:
            passed = f"Ran {expected_cases} tests" in output.decode() and "\nOK\n" in output.decode()
        records.append({"suite": name, "mode": mode, "command": ["python", *flags, *arguments],
            "directory": directory, "expected_cases": expected_cases, "exit_code": result.returncode,
            "passed": passed, "elapsed_seconds": round(time.monotonic() - start, 3),
            "log": log, "log_sha256": hashlib.sha256(output).hexdigest()})
        print(f"{name} {mode}: {'PASS' if passed else 'FAIL'}", flush=True)
    return records


def main():
    verify()
    (ROOT / "reproduction-results/tmp").mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        groups = list(executor.map(run_suite, SUITES))
    records = [record for group in groups for record in group]
    summary = {"python": sys.version, "runs": records,
        "passed": all(record["passed"] for record in records),
        "cases_per_mode": sum(suite[3] for suite in SUITES)}
    (ROOT / "reproduction-results/RESULTS.json").write_text(json.dumps(summary, indent=2) + "\n")
    raise SystemExit(0 if summary["passed"] else 1)


if __name__ == "__main__":
    main()
