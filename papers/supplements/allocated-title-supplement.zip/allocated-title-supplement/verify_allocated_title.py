"""Exact finite checks for the Allocated Title construction.

Synthetic model only. No network, provider, custody, legal, or dispatch effects.
Run with Python and Python -O. Explicit checks remain active in both modes.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from fractions import Fraction as F
from itertools import permutations, product
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal(actual, expected):
    if actual != expected:
        raise RuntimeError(f"{actual!r} != {expected!r}")


def rejected(fn):
    try:
        fn()
    except ValueError:
        return
    raise RuntimeError("Expected rejection did not occur")


@dataclass
class Physical:
    amount: F
    supported: F
    location: str = "vault-a"
    owner: dict = field(default_factory=dict)
    transit: str | None = None
    aliases: set = field(default_factory=lambda: {"lot-1"})

    def allocate(self, holder, start, end, lot="lot-1"):
        start, end = F(start), F(end)
        require(lot in self.aliases, "Unknown lot")
        require(0 <= start < end <= self.supported, "Unsupported fine weight")
        require(holder not in self.owner, "Existing allocation identity")
        require(all(end <= a or b <= start for a, b in self.owner.values()),
                "Physical overlap")
        require(self.transit is None, "Existing exclusive transit control")
        self.owner[holder] = (start, end)

    def support(self, holder):
        a, b = self.owner[holder]
        return max(F(0), min(b, self.supported) - a)

    def correct(self, amount):
        require(0 <= amount <= self.amount, "Evidence outside lot coordinates")
        self.supported = F(amount)

    def dispatch(self, destination, accepted):
        require(accepted and self.transit is None, "Missing carrier or duplicate dispatch")
        self.transit = destination
        self.location = "transit"

    def intake(self, destination, confirmed):
        require(confirmed and destination == self.transit, "Unmatched intake")
        self.location = destination
        self.transit = None

    def split(self, parent, left, right, at):
        require(parent in self.owner and left not in self.owner and right not in self.owner,
                "Invalid split identities")
        a, b = self.owner[parent]
        require(a < at < b, "Invalid split quantity")
        del self.owner[parent]
        self.owner[left], self.owner[right] = (a, F(at)), (F(at), b)


@dataclass
class Receipt:
    face: int
    supported: int
    currency: str = "GBP"
    ownership: dict = field(default_factory=dict)
    aliases: set = field(default_factory=set)

    def allocate(self, allocation, quantity, currency="GBP"):
        require(currency == self.currency, "Currency mismatch")
        require(allocation not in self.ownership, "Allocation replay")
        used = set().union(*self.ownership.values()) if self.ownership else set()
        free = sorted(set(range(self.supported)) - used)
        require(0 <= quantity <= len(free), "Receipt over-allocation")
        self.ownership[allocation] = set(free[:quantity])

    def current(self, allocation):
        return len(self.ownership[allocation] & set(range(self.supported)))

    def correct(self, amount):
        require(0 <= amount <= self.face, "Unsupported correction coordinates")
        self.supported = amount

    def free(self):
        used = set().union(*self.ownership.values()) if self.ownership else set()
        return len(set(range(self.supported)) - used)

    def reassign(self, old, new, authorised, old_claim_adjusted):
        require(authorised and old_claim_adjusted and new not in self.ownership,
                "Reassignment requires both claim adjustments")
        self.ownership[new] = self.ownership.pop(old)


@dataclass
class Cash:
    balance: F
    reserved: dict = field(default_factory=dict)
    encumbered: F = F(0)
    occurrences: set = field(default_factory=set)

    def free(self):
        return max(F(0), self.balance-sum(self.reserved.values())-self.encumbered)

    def deficit(self):
        return max(F(0), sum(self.reserved.values())+self.encumbered-self.balance)

    def reserve(self, command, amount):
        if command in self.reserved:
            equal(self.reserved[command], F(amount))
            return
        require(0 <= amount <= self.free(), "Insufficient funded cash")
        self.reserved[command] = F(amount)

    def receipt(self, occurrence, amount):
        if occurrence not in self.occurrences:
            self.occurrences.add(occurrence)
            self.balance += amount

    def spend(self, command, occurrence, amount, terminal=False):
        if occurrence in self.occurrences:
            return
        require(command in self.reserved, "Missing command")
        # Actual excess is retained rather than rejected.
        self.occurrences.add(occurrence)
        self.balance -= amount
        self.reserved[command] = max(F(0), self.reserved[command]-amount)
        if terminal:
            del self.reserved[command]

    def adverse_debit(self, occurrence, amount):
        self.receipt(occurrence, -amount)


@dataclass
class Gap:
    cap: F
    reserve: dict = field(default_factory=dict)
    allowance: dict = field(default_factory=dict)
    cash: dict = field(default_factory=dict)
    unmatched: dict = field(default_factory=dict)

    def total(self):
        return sum(self.reserve.values())+sum(self.allowance.values())

    def admit(self, command, amount):
        if command in self.reserve or command in self.allowance:
            return
        require(self.total()+amount <= self.cap, "Gap cap")
        self.reserve[command] = F(amount)

    def receive(self, occurrence, command, cash, grams):
        if occurrence in self.cash:
            return
        self.cash[occurrence] = F(cash)
        if command in self.reserve and self.reserve[command] == grams:
            self.allowance[command] = self.reserve.pop(command)
        else:
            self.unmatched[occurrence] = F(cash)

    def perform(self, command, grams):
        require(0 <= grams <= self.allowance[command], "Allowance overperformance")
        self.allowance[command] -= grams

    def release(self, command, no_further_effect):
        require(no_further_effect, "Timeout is not command closure")
        del self.reserve[command]


@dataclass
class Unit:
    state: str = "AP"
    payoff: F = F(0)
    history: list = field(default_factory=lambda: ["AP"])
    claims: dict = field(default_factory=dict)

    def transition(self, target, authority=True):
        require(authority, "Missing authority")
        require((self.state,target) in {("AP","EN"),("EN","AP"),("AP","IR"),
                                      ("IR","DV"),("AP","LO"),("LO","AP")},
                "Inadmissible state transition")
        self.state = target
        self.history.append(target)

    def release(self, due, lender_release, custody_release):
        require(self.payoff >= due and lender_release and custody_release,
                "Incomplete release")
        self.transition("AP")

    def reversal(self, occurrence, amount):
        if occurrence not in self.claims:
            self.claims[occurrence] = F(amount)


@dataclass
class Escrow:
    cash_ready: bool = False
    metal_ready: bool = False
    decision: str | None = None
    certificates_valid: bool = True
    providers_able: bool = True
    decision_authority: bool = True
    abort_authority: bool = True

    def eligible(self):
        return (self.decision is None and self.cash_ready and self.metal_ready
                and self.certificates_valid and self.providers_able
                and self.decision_authority)

    def decide(self, decision):
        require(self.decision is None, "Decision already durable")
        require(decision in {"commit","abort"}, "Unknown decision")
        require(self.eligible() if decision == "commit"
                else not self.eligible() and self.abort_authority,
                "Commit requires full eligibility; abort requires failed eligibility and authority")
        self.decision = decision

    def scheduled_step(self):
        # A scheduler may stutter finitely before this enabled transition.
        # Weak fairness itself is a theorem premise, not a finite test result.
        if self.eligible():
            self.decide("commit")

    def final(self):
        # Implements the named common-condition entitlement contract.
        return (self.decision == "commit", self.decision == "commit")


def physical_overlap_and_fractional_split():
    p=Physical(F(10),F(10))
    p.allocate("a",0,F(7,2))
    rejected(lambda:p.allocate("b",3,5))
    p.allocate("b",F(7,2),10)
    p.split("a","a1","a2",F(3,2))
    equal(sum(b-a for a,b in p.owner.values()),10)


def aliases_and_migration():
    p=Physical(F(10),F(10))
    p.aliases.add("foreign-vault-name")
    p.allocate("a",0,10)
    rejected(lambda:p.allocate("b",0,10,"foreign-vault-name"))
    rejected(lambda:p.dispatch("vault-b",False))
    p.dispatch("vault-b",True)
    rejected(lambda:p.allocate("b",0,1))
    rejected(lambda:p.intake("vault-c",True))
    p.intake("vault-b",True)
    equal((p.location,p.support("a")),("vault-b",10))


def shortage_restoration():
    p=Physical(F(100),F(100)); p.allocate("a",0,100)
    p.correct(90); equal(p.support("a"),90)
    rejected(lambda:p.allocate("b",90,100))
    p.correct(100); equal(p.support("a"),100)
    rejected(lambda:p.allocate("b",90,100))


def receipt_restoration():
    r=Receipt(100,100); r.allocate("claim-a",100)
    r.correct(90); equal(r.current("claim-a"),90)
    r.correct(100); equal((r.current("claim-a"),r.free()),(100,0))
    rejected(lambda:r.allocate("claim-b",10))


def multi_beneficiary():
    r=Receipt(120,120)
    for name,q in [("lender",80),("fee",10),("surplus",30)]:r.allocate(name,q)
    equal(sum(r.current(x) for x in r.ownership),120)
    rejected(lambda:r.allocate("other-origin",1))
    rejected(lambda:r.allocate("wrong-currency",1,"USD"))


def authorised_reassignment():
    r=Receipt(100,100); r.allocate("a",100)
    rejected(lambda:r.reassign("a","b",True,False))
    r.reassign("a","b",True,True)
    equal((r.current("b"),r.free()),(100,0))


def receipt_attribution_after_spending():
    c=Cash(F(100)); r=Receipt(100,100)
    c.reserve("spend",100); c.spend("spend","debit",100,True)
    r.allocate("old-debt",100)
    equal((c.balance,r.current("old-debt"),r.free()),(0,100,0))


def concurrent_gap():
    for order in permutations(["a","b"]):
        g=Gap(F(10));g.admit(order[0],6)
        rejected(lambda:g.admit(order[1],6))
        g.admit(order[0],6)
        g.receive("credit",order[0],600,6)
        equal(g.total(),6)
        g.perform(order[0],2);equal(g.total(),4)


def unmatched_cash_is_obligation():
    g=Gap(F(10));g.receive("credit","expired-command",250,2)
    g.receive("credit","expired-command",250,2)
    equal((sum(g.cash.values()),sum(g.unmatched.values()),g.total()),(250,250,0))


def cap_reduction_retains_commitments():
    g=Gap(F(10));g.admit("a",8);g.cap=5
    equal(max(0,g.total()-g.cap),3)
    rejected(lambda:g.admit("b",1))
    rejected(lambda:g.release("a",False))
    g.release("a",True);g.admit("b",5);equal(g.total(),5)


def partial_command_reservation():
    c=Cash(F(100));c.reserve("parent",100)
    c.spend("parent","partial-1",60)
    equal((c.balance,c.reserved["parent"],c.free()),(40,40,0))
    rejected(lambda:c.reserve("child",40))
    c.spend("parent","partial-2",10,True)
    c.reserve("child",30);equal(c.reserved["child"],30)


def adverse_debit_and_dedup():
    c=Cash(F(100),encumbered=F(40));c.reserve("a",60)
    c.adverse_debit("return",90);c.adverse_debit("return",90)
    equal((c.balance,c.deficit(),c.free()),(10,90,0))
    equal(c.balance+c.deficit(),c.free()+sum(c.reserved.values())+c.encumbered)


def full_release_redemption_trace():
    u=Unit();u.transition("EN")
    rejected(lambda:u.transition("IR"))
    rejected(lambda:u.release(50,True,True))
    u.payoff=50;u.release(50,True,True);u.transition("IR");u.transition("DV")
    equal(u.history,["AP","EN","AP","IR","DV"])
    u.reversal("chargeback",30);u.reversal("chargeback",30)
    equal((u.state,sum(u.claims.values())),("DV",30))
    rejected(lambda:u.transition("AP"))


def lease_and_return():
    u=Unit();rejected(lambda:u.transition("LO",False))
    u.transition("LO");p=Physical(F(2),F(2));p.allocate("returned",0,1)
    u.transition("AP");equal((u.state,p.support("returned")),("AP",1))
    rejected(lambda:p.allocate("another-return",0,1))


def escrow_cases():
    for cash,metal in product([False,True],repeat=2):
        e=Escrow(cash,metal)
        if cash and metal:e.decide("commit")
        else:
            rejected(lambda:e.decide("commit"));e.decide("abort")
        equal(e.final()[0],e.final()[1])
        rejected(lambda:e.decide("abort"))
    e=Escrow(True,True)
    equal(e.final(),(False,False))  # Timeout does not cancel prepared rights.
    e.decide("commit");equal(e.final(),(True,True))


def escrow_fair_commit_and_authority_change():
    for finite_delay in range(21):
        e=Escrow(True,True)
        for _ in range(finite_delay):
            equal(e.eligible(),True)
            equal(e.final(),(False,False))
        rejected(lambda:e.decide("abort"))
        e.scheduled_step()
        equal((e.decision,e.final()),("commit",(True,True)))
    # Prepared instruments retain original rights if current commit authority lapses.
    e=Escrow(True,True);e.decision_authority=False
    rejected(lambda:e.decide("commit"));e.decide("abort")
    equal((e.decision,e.final()),("abort",(False,False)))
    # A separately valid authority renewal can still complete an undecided trade.
    e=Escrow(True,True);e.decision_authority=False
    e.scheduled_step();equal(e.decision,None)
    e.decision_authority=True;e.scheduled_step();equal(e.final(),(True,True))
    for failed in ["cash_ready","metal_ready","certificates_valid","providers_able"]:
        e=Escrow(True,True);setattr(e,failed,False)
        rejected(lambda:e.decide("commit"));e.decide("abort")
        equal(e.final(),(False,False))
    e=Escrow(True,True,decision_authority=False,abort_authority=False)
    rejected(lambda:e.decide("abort"));equal(e.decision,None)


def physical_history_current_owner_projection():
    # Retained historical coordinates alone duplicate the split parent's support.
    history={"parent":set(range(100))}
    state={"parent":"AP"};active={"parent"};current=history.copy()
    supported=set(range(100));holds=set();lo={}
    def support(unit):
        if unit not in active or state[unit] not in {"AP","EN","IR"}:
            return set()
        return current[unit] & supported - holds
    def disjoint_current():
        allocations=[support(u) for u in history]
        equal(sum(map(len,allocations)),len(set().union(*allocations)))
    active.remove("parent")
    for unit,coordinates in [("left",set(range(40))),("right",set(range(40,100)))]:
        history[unit]=coordinates;current[unit]=coordinates;state[unit]="AP";active.add(unit)
    equal(sum(len(j & supported) for j in history.values()),200)
    equal((len(support("parent")),len(support("left")),len(support("right"))),(0,40,60))
    disjoint_current()
    # Lease releases 40 grams and preserves a redelivery claim, not physical support.
    state["left"]="LO";lo["left"]=40;supported-=current["left"]
    equal((len(support("left")),lo["left"],len(history["left"])),(0,40,40))
    # Actual intake supplies fresh checked slices before LO returns to AP.
    returned=set(range(100,140));supported |= returned
    current["left"]=returned;state["left"]="AP";lo["left"]-=40
    equal((len(support("left")),lo["left"]),(40,0));disjoint_current()
    # The other title is delivered. A buyer's new current allocation may use it.
    state["right"]="DV"
    history["buyer"]=current["right"].copy();current["buyer"]=history["buyer"]
    state["buyer"]="AP";active.add("buyer")
    equal((len(support("right")),len(support("buyer"))),(0,60));disjoint_current()
    supported-=set(range(120,140))
    equal((len(support("left")),40-len(support("left"))),(20,20))
    supported |= set(range(120,140))
    equal((len(support("left")),len(support("parent"))),(40,0));disjoint_current()


def partial_exchange_recovery():
    actual_cash=F(100);title_delivered=F(0);remaining_refund=F(100)
    equal(actual_cash>0 and title_delivered==0,True)
    c=Cash(actual_cash);c.reserve("refund",100)
    c.spend("refund","refund-1",40);remaining_refund-=40
    equal((remaining_refund,c.reserved["refund"]),(60,60))
    c.spend("refund","refund-2",60,True);remaining_refund-=60
    equal((remaining_refund,c.balance),(0,0))


def pro_rata_order_independence():
    weights={"a":F(60),"b":F(40)}
    quota={h:F(80)*w/100 for h,w in weights.items()}
    for order in permutations(weights):
        remaining=quota.copy();physical=F(80);delivered={h:F(0) for h in weights}
        for h in order:
            x=remaining[h];physical-=x;delivered[h]+=x;remaining[h]-=x
        equal((delivered,physical),({"a":F(48),"b":F(32)},0))
    equal({h:weights[h]-quota[h] for h in weights},{"a":12,"b":8})


def senior_and_pledge_once():
    stock=F(100);senior=F(20);distributable=stock-senior
    quotas={"a":distributable*F(3,5),"b":distributable*F(2,5)}
    lender=min(F(30),quotas["a"]);surplus=quotas["a"]-lender
    equal(senior+lender+surplus+quotas["b"],stock)


def funding_stress():
    replacement=F(10)*150;capital=F(1000)
    equal(replacement-capital,500)
    refunds=F(1000);equal(max(0,refunds-capital),0)


def service_outage():
    q=0;history=[]
    for arrivals,service in [(4,0),(4,3),(0,5)]:
        require(0<=service<=q+arrivals,"Service exceeds claim")
        q+=arrivals-service;history.append(q)
    equal(history,[4,5,0])


def queue_bound_arithmetic():
    # Independent exact envelope evaluation, with a nonzero arrival rate.
    sigma,rho,R,T,q0=F(5),F(2),F(3),F(4),F(1)
    backlog=q0+sigma+rho*T;delay=T+(q0+sigma)/R
    for u in [F(i,5) for i in range(301)]:
        require(q0+sigma+rho*u-R*max(F(0),u-T)<=backlog,"Backlog bound")
        require(q0+sigma+rho*u<=R*(u+delay-T),"Delay bound")
    equal((backlog,delay),(14,6))


def all_small_receipt_partitions():
    for q in range(1,21):
        for a in range(q+1):
            r=Receipt(q,q);r.allocate("a",a);r.allocate("b",q-a)
            for supported in range(q+1):
                r.correct(supported)
                equal(sum(r.current(k) for k in r.ownership),supported)
            r.correct(q);equal(r.free(),0)


def authority_is_not_observation():
    u=Unit();rejected(lambda:u.transition("EN",False))
    bank=Cash(F(0));bank.receipt("observed-without-authority",100)
    equal(bank.balance,100)
    equal(u.state,"AP")


def stale_assay_preserves_ownership():
    p=Physical(F(10),F(10));p.allocate("a",0,10)
    p.correct(0)  # The declared freshness cutoff expires.
    equal(p.support("a"),0)
    rejected(lambda:p.allocate("b",0,1))
    p.correct(10);equal(p.support("a"),10)
    rejected(lambda:p.allocate("b",0,1))


def late_alias_conflict_and_joint_repair():
    a=Receipt(100,100);b=Receipt(100,100)
    a.allocate("claim-a",100);b.allocate("claim-b",100)
    # Authenticated identity correction identifies the two records as one posting.
    owners={i:{name for r in [a,b] for name,slices in r.ownership.items() if i in slices}
            for i in range(100)}
    held={i for i,names in owners.items() if len(names)>1}
    supported={name:sum(names=={name} for names in owners.values())
               for name in ["claim-a","claim-b"]}
    equal((len(held),sum(supported.values())),(100,0))
    # An explicit joint claim correction assigns the existing posting to A.
    current_discharge={"claim-a":100,"claim-b":0}
    remaining_claim={"claim-a":0,"claim-b":100}
    equal(sum(current_discharge.values()),100)
    equal(current_discharge["claim-b"]+remaining_claim["claim-b"],100)


def returned_title_has_fresh_history():
    original=Unit();original.transition("IR");original.transition("DV")
    intake=Physical(F(1),F(1));intake.allocate("new-title",0,1)
    returned=Unit()
    equal((original.state,returned.state,intake.support("new-title")),("DV","AP",1))
    rejected(lambda:intake.allocate("old-title-restored",0,1))


def remelt_mass_and_owners():
    original={"a":F(5),"b":F(5)}
    certified_output=F(19,2)
    process_loss=sum(original.values())-certified_output
    returned={h:q*certified_output/10 for h,q in original.items()}
    deficits={h:original[h]-returned[h] for h in original}
    equal((sum(returned.values()),sum(deficits.values())),(certified_output,process_loss))
    equal(returned,{"a":F(19,4),"b":F(19,4)})


def integrated_purchase_pledge_sale_and_reversal():
    gap=Gap(F(1));bank=Cash(F(0));metal=Physical(F(1),F(1))
    gap.admit("purchase",1)
    bank.receipt("purchase-credit",100)
    payment=Receipt(100,100);payment.allocate("purchase-performance",100)
    gap.receive("purchase-credit","purchase",100,1)
    bank.reserve("supplier-payment",100)
    bank.spend("supplier-payment","supplier-debit",100,True)
    metal.allocate("customer",0,1);gap.perform("purchase",1);unit=Unit()
    unit.transition("EN")
    rejected(lambda:unit.transition("IR"))
    payoff=Receipt(50,50);payoff.allocate("loan-discharge",50)
    unit.payoff=payoff.current("loan-discharge")
    unit.release(50,True,True);unit.transition("IR")
    # Actual title disposition and payment are separate state changes.
    unit.transition("DV");del metal.owner["customer"];metal.allocate("buyer",0,1)
    bank.receipt("sale-credit",120);sale=Receipt(120,120)
    sale.allocate("holder-proceeds",110);sale.allocate("fee",10)
    bank.reserve("holder-payment",110);bank.reserve("fee-payment",10)
    bank.spend("holder-payment","holder-debit",110,True)
    bank.spend("fee-payment","fee-debit",10,True)
    equal((gap.total(),bank.balance,unit.state,metal.support("buyer")),(0,0,"DV",1))
    bank.adverse_debit("chargeback",30);unit.reversal("chargeback",30)
    bank.adverse_debit("chargeback",30);unit.reversal("chargeback",30)
    equal((unit.state,bank.deficit(),sum(unit.claims.values()),sale.free()),("DV",30,30,0))


def physical_priority_reconciliation():
    p=Physical(F(100),F(100));p.allocate("a",0,60);p.allocate("b",60,100)
    history=p.owner.copy();p.correct(80)
    # Coordinate order alone would produce 60/20, which is not the legal 48/32 quota.
    equal((p.support("a"),p.support("b")),(60,20))
    replacement={"a-backed":(F(0),F(48)),"b-backed":(F(48),F(80)),
                 "a-deficit":(F(80),F(92)),"b-deficit":(F(92),F(100))}
    intervals=sorted(replacement.values())
    require(all(b<=c for (a,b),(c,d) in zip(intervals,intervals[1:])),"Priority overlap")
    for h,face in [("a",60),("b",40)]:
        equal(sum(b-a for k,(a,b) in replacement.items() if k.startswith(h+"-")),face)
    # The synthetic effective order replaces all affected ownership rows together.
    p.owner=replacement
    equal((p.support("a-backed"),p.support("b-backed")),(48,32))
    equal(history,{"a":(F(0),F(60)),"b":(F(60),F(100))})
    p.correct(100)
    equal((p.support("a-backed")+p.support("a-deficit"),
           p.support("b-backed")+p.support("b-deficit")),(60,40))


def main():
    checks=[physical_overlap_and_fractional_split,aliases_and_migration,
            shortage_restoration,receipt_restoration,multi_beneficiary,
            authorised_reassignment,receipt_attribution_after_spending,
            concurrent_gap,unmatched_cash_is_obligation,cap_reduction_retains_commitments,
            partial_command_reservation,adverse_debit_and_dedup,
            full_release_redemption_trace,lease_and_return,escrow_cases,
            partial_exchange_recovery,pro_rata_order_independence,senior_and_pledge_once,
            funding_stress,service_outage,queue_bound_arithmetic,
            all_small_receipt_partitions,authority_is_not_observation,
            stale_assay_preserves_ownership,late_alias_conflict_and_joint_repair,
            returned_title_has_fresh_history,remelt_mass_and_owners,
            integrated_purchase_pledge_sale_and_reversal,physical_priority_reconciliation,
            escrow_fair_commit_and_authority_change,physical_history_current_owner_projection]
    for check in checks:
        check()
    print(json.dumps({"passed":len(checks),"checks":[x.__name__ for x in checks],
                      "scope":"finite synthetic model; no legal or custody attestation"},indent=2))


if __name__=="__main__":
    main()
