"""Executable P09 family, evidence, diagnostic, and archive construction.

The authority keys in tests are fixtures. They establish protocol behavior,
not an institutional mandate or the truth of a provider assertion.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import date
from hashlib import sha256
import json
import os
import threading
from typing import Any
from pathlib import Path
from functools import wraps

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


_LOADED_SOURCE_DIGEST = sha256(Path(__file__).read_bytes()).hexdigest()


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def canonical(value):
    """This reference format is typed UTF-8 JSON, not a claim of JCS conformance."""
    def domain(x):
        require(x is None or type(x) in (str,bool,int,list,dict), 'canonical value type')
        if type(x) is int:require(x.bit_length()<=256,'canonical integer bound')
        if type(x) is list:
            for v in x:domain(v)
        if type(x) is dict:
            require(all(type(k) is str for k in x),'canonical key type')
            for v in x.values():domain(v)
    domain(value)
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def digest(value):
    return sha256(canonical(value)).hexdigest()


def natural(value, label='quantity'):
    require(type(value) is int and value >= 0, f'invalid {label}')
    require(value.bit_length() <= 256, f'{label} limit')
    return value


def identifier(value):
    require(type(value) is str and 0 < len(value.encode('utf-8')) <= 256, 'identifier')
    require(all(ord(c) >= 32 for c in value), 'identifier control')
    return value


DIAGNOSTIC_SCHEMAS = {
    'MissingFact': {'predicate': 'id', 'subject': 'id', 'authority': 'id', 'at': 'date'},
    'Blocked': {'predicate': 'id', 'subject': 'id'},
    'Amount': {'available': 'nat', 'requested': 'nat', 'unit': 'id'},
    'AlreadyUsed': {'allocation': 'id'},
    'Lifecycle': {'event': 'id'},
    'DueFirst': {'due': 'id'},
}


def diagnostic(tag, payload):
    require(tag in DIAGNOSTIC_SCHEMAS, 'diagnostic tag')
    schema = DIAGNOSTIC_SCHEMAS[tag]
    require(type(payload) is dict and set(payload) == set(schema), 'diagnostic payload fields')
    for key, kind in schema.items():
        if kind == 'id':
            identifier(payload[key])
        elif kind == 'nat':
            natural(payload[key])
        else:
            require(type(payload[key]) is str, 'date type')
            require(date.fromisoformat(payload[key]).isoformat() == payload[key], 'date format')
    result = {'schema': 1, 'tag': tag, 'payload': deepcopy(payload)}
    require(len(canonical(result)) <= 4096, 'diagnostic size')
    return result


def sign(private, payload):
    return {'payload': deepcopy(payload), 'signature': private.sign(canonical(payload)).hex()}


def verify(public, envelope):
    require(type(envelope) is dict and set(envelope) == {'payload', 'signature'}, 'signed envelope')
    try:
        public.verify(bytes.fromhex(envelope['signature']), canonical(envelope['payload']))
    except Exception as exc:
        raise Invalid('authentication') from exc
    return deepcopy(envelope['payload'])


def settlement_policy(policy):
    require(type(policy) is dict and set(policy) == {'mode', 'asset', 'unit', 'route', 'purpose', 'maximum',
                           'finality_source', 'basis', 'redemption'}, 'settlement policy fields')
    require(policy['mode'] in ('Redeemable', 'Native'), 'settlement mode')
    for key in ('asset', 'unit', 'route', 'purpose', 'finality_source', 'basis'):
        identifier(policy[key])
    natural(policy['maximum'])
    require(policy['maximum'] > 0, 'settlement maximum')
    if policy['mode'] == 'Redeemable':
        require(type(policy['redemption']) is dict and
                set(policy['redemption']) == {'obligor', 'rule', 'clock'}, 'redemption record')
        for v in policy['redemption'].values():
            identifier(v)
    else:
        require(policy['redemption'] is None, 'native typed none')
    return deepcopy(policy)


def pack_check(pack):
    fields = {'family', 'issuer', 'holder', 'unit', 'components', 'authorities',
              'settlement', 'due_order', 'reliance', 'code'}
    require(type(pack) is dict and set(pack) == fields, 'pack fields')
    require(pack['family'] in ('Receivable', 'MilestoneGrant'), 'family constructor')
    require(pack['code'] == 'p09-reference-1', 'unsupported family program')
    for key in ('issuer', 'holder', 'unit'):
        identifier(pack[key])
    components = pack['components']
    require(type(components) is dict and 0 < len(components) <= 1024, 'component cardinality')
    if pack['family'] == 'Receivable':
        require(set(components) == {'principal'}, 'receivable principal')
    for key, component in components.items():
        identifier(key)
        require(type(component) is dict and set(component) == {'amount', 'due'}, 'component fields')
        require(natural(component['amount']) > 0, 'positive amount')
        require(natural(component['due'], 'due time')<=3652058,'reachable due time')
    require(pack['due_order'] == sorted(components, key=lambda k: (components[k]['due'], k)),
            'well-founded due order')
    require(type(pack['authorities']) is dict and set(pack['authorities']) == {'authority', 'eligible', 'complete', 'settlement'},
            'authority map')
    for value in pack['authorities'].values():
        identifier(value)
    settlement_policy(pack['settlement'])
    require(pack['unit'] == pack['settlement']['unit'], 'unit agreement')
    require(pack['reliance'] == ['engine-audit'], 'default reliance scope')
    return deepcopy(pack)


def initial():
    return {'issued': False, 'holder': None, 'vested': [], 'settled': {},
            'consumed': [], 'observed': {}, 'completions': {}}


def projection(pack, state):
    return {c: pack['components'][c]['amount'] -
            sum(item['amount'] for item in state['settled'].values() if item['component'] == c)
            for c in state['vested']}


def obligations(pack, state):
    """Contingent rights remain represented before vesting, separately from payables."""
    payable = projection(pack, state)
    return {c: {'contingent': pack['components'][c]['amount']
                if state['issued'] and c not in state['vested'] else 0,
                'payable': payable.get(c, 0)} for c in pack['components']}


def invariant(pack, state):
    require(set(state) == set(initial()), 'state fields')
    require(type(state['issued']) is bool, 'issued type')
    require(len(state['vested']) == len(set(state['vested'])), 'unique vested components')
    require(set(state['vested']) <= set(pack['components']), 'known components')
    require(len(state['consumed']) == len(set(state['consumed'])), 'unique consumed identities')
    if not state['issued']:
        require(state == initial(), 'draft invariant')
    else:
        identifier(state['holder'])
    require(set(state['completions'])<=set(state['consumed']),'completion use retained')
    if pack['family']=='MilestoneGrant':
        require(sorted(state['completions'].values())==sorted(state['vested']),'exact keyed completion')
    else:require(state['completions']=={},'receivable completion namespace')
    require(all(v >= 0 for v in projection(pack, state).values()), 'obligation nonnegative')
    require(set(state['settled']) <= set(state['consumed']), 'settlement use retained')
    for key, entry in state['settled'].items():
        require(entry['component'] in state['vested'], 'settlement vested')
        natural(entry['amount'])
        require(state['observed'].get(key) == 'Final', 'settled evidence final')
    require(all(v in ('Pending', 'Final') for v in state['observed'].values()), 'evidence class')
    return True


class Engine:
    """One serialized reference engine; remote protocols remain separate interfaces."""
    def __init__(self, public_keys, epochs=None):
        self.keys = dict(public_keys)
        self.epochs = dict(epochs or {key: 0 for key in public_keys})
        self.lock = threading.RLock()
        self.packs = {}
        self.claims = {}
        self.evidence = {}
        self.fact_heads = {}
        self.evidence_revision = 0
        self.status_revision = 0
        self.nonces = {}
        self.rows = []
        self.allocated_slices = {}
        self.credit_roots = {}
        self.fact_history = []
        self.input_nonces = {}
        self.input_journal = []

    def register(self, claim, pack):
        with self.lock:
            identifier(claim)
            require(claim not in self.claims, 'claim exists')
            verified = pack_check(pack)
            key = digest(verified)
            if key in self.packs:
                require(self.packs[key] == verified, 'digest collision')
            self.packs[key] = verified
            self.claims[claim] = {'pack': key, 'state': initial(), 'revision': 0, 'root': '0'*64, 'derived': {}, 'generations': {c:0 for c in verified['components']}}
            return key

    def ingest(self, envelope):
        """Cure input records an authenticated fact; it performs no claim transition."""
        with self.lock:
            candidate = envelope.get('payload', {})
            require(candidate.get('issuer') in self.keys, 'fact issuer')
            fact = verify(self.keys[candidate['issuer']], envelope)
            require(set(fact) == {'id', 'issuer', 'claim', 'predicate', 'subject', 'value',
                                  'from', 'until', 'epoch', 'serial'}, 'fact fields')
            for key in ('id', 'issuer', 'claim', 'predicate', 'subject'):
                identifier(fact[key])
            for key in ('from', 'until', 'epoch', 'serial'):
                natural(fact[key], key)
            require(fact['from'] <= fact['until'], 'fact period')
            require(len(canonical(fact)) <= 16384, 'fact payload limit')
            identity = (fact['issuer'], fact['id'])
            if identity in self.evidence:
                require(self.evidence[identity] == envelope, 'fact identity equivocation')
                return self.evidence_revision
            # Record adverse evidence even when the former authority has expired.
            # It remains historical evidence until admission selects a current source.
            key = (fact['claim'], fact['predicate'], fact['subject'], fact['issuer'], fact['epoch'])
            prior = self.fact_heads.get(key)
            if prior is not None and fact['serial']==prior['payload']['serial']:
                require(canonical(fact)==canonical(prior['payload']), 'source serial equivocation')
            self.evidence[identity] = deepcopy(envelope)
            if prior is None or fact['serial']>prior['payload']['serial']:
                self.fact_heads[key] = deepcopy(envelope)
            self.fact_history.append(deepcopy(envelope))
            self.evidence_revision += 1
            return self.evidence_revision

    def credit(self, envelope):
        """Admit one authoritative booked credit, before allocating its quantity slices."""
        with self.lock:
            p=envelope.get('payload',{});issuer=p.get('issuer')
            require(issuer in self.keys,'credit authority key')
            root=verify(self.keys[issuer],envelope)
            require(set(root)=={'issuer','book','account','epoch','event','kind','asset','unit','quantity'},'credit fields')
            for key in ('issuer','book','account','event','asset','unit'):identifier(root[key])
            natural(root['epoch']);require(root['kind']=='RecipientCredit','credit kind')
            require(natural(root['quantity'])>0,'credit quantity')
            name=digest({k:root[k] for k in ('book','account','epoch','event','kind','asset','unit')})
            prior=self.credit_roots.get(name)
            require(prior is None or prior==envelope,'credit root correction requires reconciliation')
            self.credit_roots[name]=deepcopy(envelope)
            return name

    def input(self, envelope):
        """Authenticated Input/Cure/Review journal, separate from claim revisions."""
        with self.lock:
            candidate=envelope.get('payload',{});actor=candidate.get('actor')
            require(actor in self.keys,'input standing')
            operation=verify(self.keys[actor],envelope)
            require(set(operation)=={'op','claim','actor','nonce','target','requirement','facts'},'input fields')
            require(operation['claim'] in self.claims,'input claim')
            require(operation['op'] in ('Input','Cure','Review'),'input constructor')
            identifier(operation['nonce'])
            identity=(operation['claim'],operation['nonce'])
            if identity in self.input_nonces:
                previous,result=self.input_nonces[identity]
                require(previous==digest(operation),'input nonce conflict')
                return deepcopy(result)
            if operation['op'] in ('Cure','Review'):
                targets=[row['receipt'] for row in self.rows if digest(row['receipt'])==operation['target']]
                require(len(targets)==1 and targets[0]['claim']==operation['claim'],'input receipt target')
                if operation['op']=='Cure':
                    require(targets[0]['decision']=='Awaiting' and operation['requirement']==targets[0]['diagnostic'],'exact awaiting requirement')
                else:
                    require(operation['requirement'] is None and operation['facts']==[],'review records request only')
            else:
                require(operation['target'] is None and operation['requirement'] is None,'input target none')
            require(type(operation['facts']) is list,'input facts')
            saved=deepcopy((self.evidence,self.fact_heads,self.fact_history,self.evidence_revision))
            try:
                for fact in operation['facts']:
                    require(fact['payload']['claim']==operation['claim'],'input fact claim')
                    self.ingest(fact)
            except Exception:
                self.evidence,self.fact_heads,self.fact_history,self.evidence_revision=saved
                raise
            result={'result':'Recorded','input':digest(operation),'index':len(self.input_journal)}
            self.input_journal.append(deepcopy(operation))
            self.input_nonces[identity]=(digest(operation),deepcopy(result))
            return result

    def change_epoch(self, issuer, epoch):
        """Named authoritative status-store interface; never callable from a cure payload."""
        with self.lock:
            require(issuer in self.keys and natural(epoch) > self.epochs[issuer], 'status advance')
            self.epochs[issuer] = epoch
            self.status_revision += 1

    def fact(self, claim, predicate, subject, at, pack, refs=None):
        issuer = pack['authorities'][predicate]
        env = self.fact_heads.get((claim, predicate, subject, issuer, self.epochs[issuer]))
        if env is None or (refs is not None and [env['payload']['issuer'], env['payload']['id']] not in refs):
            return None
        p = verify(self.keys[issuer], env)
        if p['epoch'] != self.epochs[issuer] or not p['from'] <= at <= p['until']:
            return None
        return p

    def due(self, claim, at):
        row = self.claims[claim];pack=self.packs[row['pack']];state=row['state']
        if pack['family'] != 'MilestoneGrant' or not state['issued']:
            return []
        return [component for component in pack['due_order']
                if pack['components'][component]['due'] <= at and component not in state['vested']
                and row['derived'].get(self.derived_id(claim,component)) not in ('Accepted','Refused')]

    def derived_id(self,claim,component):
        row=self.claims[claim]
        return digest({'claim':claim,'pack':row['pack'],'event':'Vest','component':component,'generation':row['generations'][component]})

    def decision(self, claim, request, at):
        return self.constructor(claim,request,at)

    def constructor(self, claim, request, at):
        row=self.claims[claim];pack=self.packs[row['pack']];old=row['state'];new=deepcopy(old)
        kind=request['kind'];data=request['data'];facts=[];uses=[]
        def refuse(tag,payload):
            return {'result':'Refused','diagnostic':diagnostic(tag,payload),'state':deepcopy(old),'facts':facts,'uses':[]}
        def need(predicate,subject):
            fact=self.fact(claim,predicate,subject,at,pack,request['evidence'])
            if fact is None:
                return {'result':'Awaiting','diagnostic':diagnostic('MissingFact',{'predicate':predicate,'subject':subject,'authority':pack['authorities'][predicate],'at':date.fromordinal(at+1).isoformat()}),'state':deepcopy(old),'facts':facts,'uses':[]}
            facts.append(fact)
            if fact['value'] is False:
                return refuse('Blocked',{'predicate':predicate,'subject':subject})
            return fact
        due=self.due(claim,at)
        if due and kind!='Rearm' and not (kind=='Vest' and data.get('component')==due[0]):
            return refuse('DueFirst',{'due':due[0]})
        if kind=='Issue':
            if old['issued']:
                return refuse('Lifecycle',{'event':kind})
            require(set(data)==set(), 'Issue payload')
            result=need('authority',pack['issuer'])
            if 'result' in result:return result
            require(result['value'] is True, 'authority payload')
            require(request['actor']==pack['issuer'],'issuer request')
            eligible=need('eligible',pack['holder'])
            if 'result' in eligible:return eligible
            require(eligible['value'] is True,'initial holder eligibility')
            new['issued']=True;new['holder']=pack['holder']
            if pack['family']=='Receivable':new['vested']=['principal']
        elif kind=='Transfer':
            require(set(data)=={'holder'},'Transfer payload');identifier(data['holder'])
            if not old['issued']:
                return refuse('Lifecycle',{'event':kind})
            require(request['actor']==old['holder'],'holder authority')
            authority=need('authority',old['holder'])
            if 'result' in authority:return authority
            require(authority['value'] is True,'current holder authority')
            result=need('eligible',data['holder'])
            if 'result' in result:return result
            require(result['value'] is True,'eligibility payload')
            new['holder']=data['holder']
        elif kind=='Vest':
            require(set(data)=={'component'},'Vest payload');component=data['component']
            if pack['family']!='MilestoneGrant' or not old['issued'] or component not in pack['components'] or component in old['vested']:
                return refuse('Lifecycle',{'event':kind})
            require(request['actor']==pack['issuer'],'vesting submitter')
            result=need('complete',component)
            if 'result' in result:return result
            require(result['value'] is True,'completion payload')
            # Completion consumes one nonmonetary effect, with event identity preserved.
            effect='completion:'+digest({'issuer':result['issuer'],'event':result['id'],'kind':'Completion'})
            require(effect not in old['consumed'],'completion reused')
            new['vested']=sorted(old['vested']+[component]);new['consumed'].append(effect)
            new['completions'][effect]=component
            uses.append(effect)
        elif kind=='Rearm':
            require(set(data)=={'component','refusal'},'Rearm payload')
            component=identifier(data['component'])
            require(pack['family']=='MilestoneGrant' and old['issued'] and component in pack['components'] and component not in old['vested'],'rearm lifecycle')
            require(request['actor']==pack['issuer'],'rearm authority')
            oldid=self.derived_id(claim,component)
            require(row['derived'].get(oldid)=='Refused','rearm prior refusal')
            prior=[step['receipt'] for step in self.rows if digest(step['receipt'])==data['refusal']]
            require(len(prior)==1 and prior[0]['claim']==claim and prior[0]['decision']=='Refused','rearm refusal receipt')
            priorstep=next(step for step in self.rows if digest(step['receipt'])==data['refusal'])
            require(priorstep['request']['payload']['origin']==oldid,'rearm exact origin')
            for predicate,subject in [('authority',pack['issuer']),('complete',component)]:
                result=need(predicate,subject)
                if 'result' in result:return result
                require(result['value'] is True,'rearm favorable premise')
        elif kind=='Observe':
            require(set(data)=={'allocation','component'},'Observe payload')
            allocation=identifier(data['allocation']);component=identifier(data['component'])
            require(not allocation.startswith('completion:'),'typed allocation namespace')
            if not old['issued'] or component not in old['vested']:
                return refuse('Lifecycle',{'event':kind})
            require(request['actor'] in (pack['issuer'],old['holder']),'observation standing')
            result=need('settlement',allocation)
            if 'result' in result:return result
            value=result['value']
            require(type(value) is dict and set(value)=={'occurrence','slices','amount','unit','asset','route','purpose','class','component','policy'},'allocation evidence fields')
            require(value['component']==component and value['unit']==pack['unit'],'allocation target')
            policy=pack['settlement']
            require(all(value[k]==policy[k] for k in ('asset','route','purpose')),'settlement scope')
            require(value['policy']==digest(policy),'settlement policy binding')
            amount=natural(value['amount']);require(amount>0,'positive payment')
            require(amount<=policy['maximum'],'route size')
            require(value['class'] in ('Pending','Final'),'settlement class')
            require(type(value['slices']) is list and all(type(x) is int and x>0 for x in value['slices']),'slice type')
            require(len(value['slices'])==len(set(value['slices']))==amount,'exact slices')
            identifier(value['occurrence'])
            root_envelope=self.credit_roots.get(value['occurrence'])
            require(root_envelope is not None,'authoritative credit root')
            root=root_envelope['payload']
            require(root['issuer']==policy['finality_source'] and root['issuer']==result['issuer'],'nominated booking source')
            require(root['asset']==value['asset'] and root['unit']==value['unit'],'credit root asset')
            require(all(x<=root['quantity'] for x in value['slices']),'credit capacity bound')
            if allocation in old['consumed']:
                return refuse('AlreadyUsed',{'allocation':allocation})
            if value['class']=='Final':
                available=projection(pack,old)[component]
                if amount>available:return refuse('Amount',{'available':available,'requested':amount,'unit':pack['unit']})
                occupied=self.allocated_slices.get(value['occurrence'],{})
                require(not(set(value['slices'])&set(occupied)),'global allocation conflict')
                new['settled'][allocation]={'amount':amount,'component':component,'occurrence':value['occurrence'],'slices':value['slices']}
                new['consumed'].append(allocation);uses.append(allocation)
            require(old['observed'].get(allocation)!='Final','final evidence retained')
            new['observed'][allocation]=value['class']
        else:
            raise Invalid('event constructor')
        return {'result':'Accepted','diagnostic':None,'state':new,'facts':facts,'uses':uses}

    def check_witness(self, claim, request, decision, at):
        """Check the derivation's semantic postconditions independently of state assignment."""
        row=self.claims[claim];pack=self.packs[row['pack']];old=row['state'];new=decision['state']
        invariant(pack,new)
        # The public constructor relation is implemented by the fixed interpreter.
        # Candidate optimizers do not determine their own acceptance conditions.
        expected=Engine.constructor(self,claim,request,at)
        require(canonical(decision)==canonical(expected),'derivation differs from the registered constructor relation')
        require(decision['result'] in ('Accepted','Awaiting','Refused'),'decision constructor')
        require(set(old['consumed'])<=set(new['consumed']),'consumption persistence')
        if decision['result']!='Accepted':
            require(new==old and decision['uses']==[],'negative mutation')
            d=decision['diagnostic'];require(d==diagnostic(d['tag'],d['payload']),'diagnostic validation')
            return
        require(decision['diagnostic'] is None,'accepted diagnostic')
        kind=request['kind'];facts=decision['facts'];uses=decision['uses']
        require(len(uses)==len(set(uses)) and not(set(uses)&set(old['consumed'])),'use uniqueness')
        require(set(new['consumed'])==set(old['consumed'])|set(uses),'exact consumption')
        for f in facts:
            admitted=self.fact(claim,f['predicate'],f['subject'],at,pack,request['evidence'])
            require(canonical(admitted)==canonical(f),'admitted premise')
        if kind=='Issue':
            require(not old['issued'] and new['issued'] and new['holder']==pack['holder'],'issue relation')
            require(new['settled']=={} and new['observed']=={} and new['consumed']==[],'issue resources')
            require(new['vested']==(['principal'] if pack['family']=='Receivable' else []),'issue obligations')
            require(any(f['predicate']=='authority' and f['value'] is True for f in facts),'issue authority')
        elif kind=='Transfer':
            require(new['holder']==request['data']['holder'],'transfer holder')
            for k in old:
                if k!='holder':require(new[k]==old[k],'transfer footprint')
            require(any(f['predicate']=='eligible' and f['subject']==new['holder'] and f['value'] is True for f in facts),'holder admissibility')
        elif kind=='Vest':
            component=request['data']['component']
            require(set(new['vested'])==set(old['vested'])|{component},'vesting increment')
            require(any(f['predicate']=='complete' and f['subject']==component and f['value'] is True for f in facts),'completion evidence')
            require(len(uses)==1 and uses[0].startswith('completion:'),'completion use')
            for key in ('holder','issued','settled','observed'):require(new[key]==old[key],'vesting footprint')
        elif kind=='Rearm':
            require(new==old and uses==[],'rearm financial identity')
        elif kind=='Observe':
            allocation=request['data']['allocation'];component=request['data']['component']
            matching=[f for f in facts if f['predicate']=='settlement' and f['subject']==allocation]
            require(len(matching)==1,'one settlement witness');v=matching[0]['value']
            expected=projection(pack,old).copy()
            if v['class']=='Final':
                require(uses==[allocation],'settlement use')
                require(new['settled'].get(allocation)=={'amount':v['amount'],'component':component,'occurrence':v['occurrence'],'slices':v['slices']},'exact allocation')
                expected[component]-=v['amount']
            else:require(uses==[] and new['settled']==old['settled'],'pending no discharge')
            require(projection(pack,new)==expected,'exact obligation delta')
            require(new['observed'].get(allocation)==v['class'],'evidence ceiling')
            for key in ('issued','holder','vested','completions'):require(new[key]==old[key],'settlement footprint')
            for key in old['settled']:require(new['settled'][key]==old['settled'][key],'prior settlement retained')
            for key in old['observed']:
                if key!=allocation:require(new['observed'][key]==old['observed'][key],'effect indexed evidence')
        else:raise Invalid('unknown derivation')
        require(request['reliance']==pack['reliance'],'reliance scope')

    def submit(self, envelope, at, transform=None):
        with self.lock:
            candidate=envelope.get('payload',{});actor=candidate.get('actor')
            require(actor in self.keys,'request actor')
            q=verify(self.keys[actor],envelope)
            require(set(q)=={'claim','kind','data','nonce','revision','pack','theta','actor','reliance','evidence','origin'},'request fields')
            identifier(q['claim']);identifier(q['nonce']);natural(q['revision']);natural(q['theta']);natural(at)
            require(type(q['evidence']) is list and all(type(x) is list and len(x)==2 for x in q['evidence']),'evidence references')
            for pair in q['evidence']:
                for part in pair:identifier(part)
            require(q['evidence']==sorted(q['evidence']) and len(q['evidence'])==len({tuple(x) for x in q['evidence']}),'canonical evidence references')
            require(q['origin'] is None or type(q['origin']) is str,'derived origin type')
            require(at<=3652058 and q['theta']<=at,'commit time')
            claim=q['claim'];require(claim in self.claims,'claim registry')
            nonce=(claim,q['nonce']);request_digest=digest(q)
            if nonce in self.nonces:
                old_digest,receipt=self.nonces[nonce]
                require(old_digest==request_digest,'nonce conflict')
                return deepcopy(receipt)
            row=self.claims[claim];pack=self.packs[row['pack']]
            require(q['revision']==row['revision'] and q['pack']==row['pack'],'current base and semantics')
            if q['kind']=='Vest':
                require(type(q['data']) is dict and set(q['data'])=={'component'},'Vest payload')
                component=identifier(q['data']['component'])
                require(pack['family']=='MilestoneGrant' and row['state']['issued'] and component in pack['components'],'derived lifecycle')
                require(q['actor']==pack['issuer'],'vesting standing')
                require(q['origin']==self.derived_id(claim,component),'current derived identifier')
                require(row['derived'].get(q['origin']) not in ('Accepted','Refused'),'terminal derived identifier')
                pending=self.due(claim,at)
                require(bool(pending) and pending[0]==component,'derived event not ready')
            else:
                require(q['origin'] is None,'authored origin')
            invariant(pack,row['state'])
            before=deepcopy(row)
            decision=self.decision(claim,q,at)
            # Optional hook models an untrusted optimizer or family proposal.
            if transform is not None:decision=transform(deepcopy(decision))
            self.check_witness(claim,q,decision,at)
            new=decision['state']
            receipt={'request':request_digest,'claim':claim,'pack':row['pack'],'at':at,
                     'before':digest(row['state']),'after':digest(new),
                     'before_obligations':obligations(pack,row['state']),'after_obligations':obligations(pack,new),
                     'decision':decision['result'],'diagnostic':decision['diagnostic'],
                     'uses':decision['uses'],'facts':digest(decision['facts']),'snapshot':digest(self.epochs),
                     'revision':row['revision']+1,'prior_root':row['root'],'reliance':deepcopy(pack['reliance'])}
            nextroot=digest(receipt)
            # Every global allocation and claim write occurs under this same lock.
            for use in decision['uses']:
                if use in new['settled']:
                    item=new['settled'][use];occupied=self.allocated_slices.setdefault(item['occurrence'],{})
                    require(not(set(item['slices'])&set(occupied)),'allocation commit conflict')
                    for slice_id in item['slices']:occupied[slice_id]=(claim,use)
            row.update(state=deepcopy(new),revision=receipt['revision'],root=nextroot)
            if q['origin'] is not None and decision['result'] in ('Accepted','Refused'):
                row['derived'][q['origin']]=decision['result']
            if q['kind']=='Rearm' and decision['result']=='Accepted':
                row['generations'][q['data']['component']]+=1
            self.nonces[nonce]=(request_digest,deepcopy(receipt))
            self.rows.append({'request':deepcopy(envelope),'at':at,'receipt':deepcopy(receipt),'before':before,
                              'facts':deepcopy(self.fact_history),'epochs':deepcopy(self.epochs)})
            return receipt

    def replay(self):
        other=Engine(self.keys)
        for root in self.credit_roots.values():other.credit(root)
        for claim,row in self.claims.items():other.register(claim,self.packs[row['pack']])
        for step in self.rows:
            other.epochs=deepcopy(step['epochs'])
            for fact in step['facts']:
                key=(fact['payload']['issuer'],fact['payload']['id'])
                if key not in other.evidence:other.ingest(fact)
            actual=other.submit(step['request'],step['at'])
            require(actual==step['receipt'],'historical replay mismatch')
        require(other.claims==self.claims and other.allocated_slices==self.allocated_slices,'replay state')
        return other


def locked(function):
    @wraps(function)
    def call(self,*args,**kwargs):
        with self.lock:return function(self,*args,**kwargs)
    return call


def program_digest():
    require(sha256(Path(__file__).read_bytes()).hexdigest()==_LOADED_SOURCE_DIGEST,'loaded interpreter source drift')
    return _LOADED_SOURCE_DIGEST


class PrivateArchive:
    """Authenticated private retention with recipient key generations and honest deletion."""
    def __init__(self, authority, recipients, retain_until):
        self.authority=authority
        self.recipients=dict(recipients)
        self.retain_until=retain_until
        self.objects={};self.generation=0;self.deleted={};self.audit=[];self.references={};self.lock=threading.RLock()

    @locked
    def put(self, payload):
        require(type(payload) is bytes,'archive bytes')
        name=sha256(payload).hexdigest()
        if name in self.objects:return name
        key=AESGCM.generate_key(bit_length=256)
        nonce=os.urandom(12);aad=canonical({'digest':name,'retain_until':self.retain_until})
        ciphertext=AESGCM(key).encrypt(nonce,payload,aad)
        wraps={}
        for role,kek in self.recipients.items():
            wn=os.urandom(12)
            wraps[role]=(wn,AESGCM(kek).encrypt(wn,key,canonical({'digest':name,'role':role,'generation':self.generation})))
        self.references[name]=os.urandom(24).hex()
        self.objects[name]={'nonce':nonce,'ciphertext':ciphertext,'aad':aad,'wraps':wraps,'generation':self.generation}
        return name

    @locked
    def read(self,name,role,kek):
        require(name in self.objects,'archive unavailable')
        item=self.objects[name];require(role in item['wraps'],'archive access')
        wn,wrapped=item['wraps'][role]
        try:
            key=AESGCM(kek).decrypt(wn,wrapped,canonical({'digest':name,'role':role,'generation':item['generation']}))
            payload=AESGCM(key).decrypt(item['nonce'],item['ciphertext'],item['aad'])
        except Exception as exc:raise Invalid('archive authentication') from exc
        require(sha256(payload).hexdigest()==name,'archive digest')
        return payload

    @locked
    def rotate(self,role,old,new):
        require(role in self.recipients and self.recipients[role]==old,'rotation authority')
        candidates={}
        try:
            for name,item in self.objects.items():
                plaintext=self.read(name,role,old)
                wn,wrapped=item['wraps'][role]
                aad=canonical({'digest':name,'role':role,'generation':item['generation']})
                key=AESGCM(old).decrypt(wn,wrapped,aad)
                wn=os.urandom(12);wrapped=AESGCM(new).encrypt(wn,key,aad)
                recovered=AESGCM(new).decrypt(wn,wrapped,aad)
                require(AESGCM(recovered).decrypt(item['nonce'],item['ciphertext'],item['aad'])==plaintext,'rotation recovery')
                candidates[name]=(wn,wrapped)
        except Exception as exc:raise Invalid('rotation preparation failed') from exc
        for name,wrapped in candidates.items():self.objects[name]['wraps'][role]=wrapped
        self.recipients[role]=new;self.audit.append({'event':'Rotate','role':role})

    @locked
    def delete(self,name,at,holds,principal):
        require(principal==self.authority,'deletion authority')
        require(at>self.retain_until and not holds,'retention or legal hold')
        require(name in self.objects,'archive available')
        reference=self.references[name]
        record={'digest':name,'reference':reference,'deleted_at':at,'authority':principal,'mode':'CommitmentOnly','scope':'local-memory-archive'}
        self.audit.append({'event':'DisposeIntent','reference':reference})
        del self.objects[name]
        self.deleted[reference]=record
        self.audit.append({'event':'Disposed','reference':reference})
        return deepcopy(record)

    @locked
    def public_manifest(self):
        return {'retained':sorted(self.references[name] for name in self.objects),
                'disposed':sorted(self.deleted)}


def archive_bundle(engine, signer):
    payload={'schema':1,'interpreter':program_digest(),'packs':{claim:engine.packs[row['pack']] for claim,row in engine.claims.items()},
             'keys':{name:key.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw).hex() for name,key in engine.keys.items()},
             'credits':deepcopy(list(engine.credit_roots.values())),
             'rows':deepcopy(engine.rows),'terminal':deepcopy(engine.claims)}
    return canonical(sign(signer,payload))


def offline_replay(bundle, trusted_archive_key, *, expected_manifest, expected_program):
    require(sha256(bundle).hexdigest()==expected_manifest,'requested archive manifest')
    require(program_digest()==expected_program,'installed interpreter identity')
    envelope=json.loads(bundle);payload=verify(trusted_archive_key,envelope)
    require(set(payload)=={'schema','interpreter','packs','keys','credits','rows','terminal'} and payload['schema']==1,'archive closure schema')
    require(payload['interpreter']==expected_program,'archive interpreter binding')
    keys={name:Ed25519PublicKey.from_public_bytes(bytes.fromhex(value)) for name,value in payload['keys'].items()}
    engine=Engine(keys)
    for root in payload['credits']:engine.credit(root)
    for claim,pack in payload['packs'].items():engine.register(claim,pack)
    for step in payload['rows']:
        engine.epochs=deepcopy(step['epochs'])
        for fact in step['facts']:
            key=(fact['payload']['issuer'],fact['payload']['id'])
            if key not in engine.evidence:engine.ingest(fact)
        receipt=engine.submit(step['request'],step['at'])
        require(receipt==step['receipt'],'offline receipt mismatch')
    require(engine.claims==payload['terminal'],'offline terminal root')
    return engine
