"""SQLite custody for the exact P14 transfer relation.

The evidence admission and clock services are explicit trusted inputs. This
module never dispatches a provider action or asserts an external legal effect.
"""
from __future__ import annotations

import dataclasses
from fractions import Fraction
import hashlib
import hmac
import json
from pathlib import Path
import sqlite3
import time
import uuid

import transfers as model

MODEL_SHA = "170814aea0f508fd877468d6fe386afecebce56ebb3feb152540052b36ec0134"
if hashlib.sha256(Path(model.__file__).read_bytes()).hexdigest() != MODEL_SHA:
    raise RuntimeError("Pinned transfer semantics changed")

CLASSES = {name: getattr(model, name) for name in
           ("Interest", "Accessory", "Redelivery", "Continuation", "Unit",
            "Route", "Request", "Evidence")}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def wire(value):
    if dataclasses.is_dataclass(value):
        require(type(value).__name__ in CLASSES, "Unknown record type")
        return {"record": type(value).__name__,
                "fields": {f.name: wire(getattr(value, f.name))
                           for f in dataclasses.fields(value)}}
    if isinstance(value, Fraction):
        return {"fraction": [value.numerator, value.denominator]}
    if isinstance(value, bytes):
        return {"bytes": value.hex()}
    if isinstance(value, tuple):
        return {"tuple": [wire(x) for x in value]}
    if isinstance(value, set):
        return {"set": sorted(value)}
    if isinstance(value, list):
        return [wire(x) for x in value]
    if isinstance(value, dict):
        require(all(type(k) is str for k in value), "Non-string map key")
        return {"map": {k: wire(v) for k, v in value.items()}}
    require(value is None or type(value) in (str, int, bool), "Unsupported value")
    return value


def unwire(value):
    if isinstance(value, list):
        return [unwire(x) for x in value]
    if not isinstance(value, dict):
        return value
    if set(value) == {"record", "fields"}:
        require(value["record"] in CLASSES, "Unknown record")
        cls = CLASSES[value["record"]]
        require(set(value["fields"]) == {f.name for f in dataclasses.fields(cls)},
                "Record field mismatch")
        return cls(**{k: unwire(v) for k, v in value["fields"].items()})
    if set(value) == {"fraction"}:
        return Fraction(*value["fraction"])
    if set(value) == {"bytes"}:
        return bytes.fromhex(value["bytes"])
    if set(value) == {"tuple"}:
        return tuple(unwire(x) for x in value["tuple"])
    if set(value) == {"set"}:
        return set(value["set"])
    if set(value) == {"map"}:
        return {k: unwire(v) for k, v in value["map"].items()}
    raise ValueError("Unknown serialized value")


def encode(value):
    return json.dumps(wire(value), sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def decode(data):
    value = unwire(json.loads(data))
    require(encode(value) == data, "Noncanonical checkpoint")
    return value


def sha(data):
    return hashlib.sha256(data).hexdigest()


FIELDS = ("units", "route", "policy_generation", "completed", "revoked_evidence",
          "history", "cash_allocations", "funding_reservations", "physical_free")


def pack(register):
    require(set(register.__dict__) == set(FIELDS), "Unmapped reference state")
    return {k: getattr(register, k) for k in FIELDS}


def restore(record):
    require(set(record) == set(FIELDS), "Incomplete reference state")
    result = model.Register(list(record["units"].values()), record["route"],
                            record["policy_generation"])
    for key in FIELDS:
        setattr(result, key, record[key])
    return result


def duty_id(issuer_namespace, constituting_act, occurrence_index):
    """P09 economic-duty identity. All three inputs are authoritative names."""
    require(all(type(v) is str and v for v in
                (issuer_namespace, constituting_act, occurrence_index)), "Duty origin")
    # P09 canonical form uses compact sorted-key UTF-8 JSON.
    return sha(json.dumps(["economic-duty", issuer_namespace, constituting_act,
                           occurrence_index], sort_keys=True,
                          separators=(",", ":"), ensure_ascii=False).encode())


def validate_bindings(register, bindings):
    represented = {}
    for unit_id, binding in bindings.items():
        require(unit_id in register.units, "Unknown duty-bound unit")
        require(set(binding) == {"origin", "duty", "root_slices", "source_receipt",
                                "duty_quantity", "quantum", "asset", "unit"},
                "Duty binding fields")
        require(binding["duty"] == duty_id(*binding["origin"]), "Duty identity")
        require(binding["source_receipt"], "Missing duty source record")
        require(binding["root_slices"] and all(type(a) is int and type(b) is int
                and 0 <= a < b <= binding["duty_quantity"]
                for a, b in binding["root_slices"]), "Duty interval")
        require(type(binding["duty_quantity"]) is int and binding["duty_quantity"] > 0
                and isinstance(binding["quantum"], Fraction) and binding["quantum"] > 0
                and binding["asset"] and binding["unit"], "Duty quantity and unit")
        ordered = sorted(binding["root_slices"])
        require(all(ordered[i][1] <= ordered[i+1][0]
                    for i in range(len(ordered)-1)), "Overlapping unit duty slices")
        require(sum(b-a for a,b in ordered) * binding["quantum"]
                == register.units[unit_id].quantity, "Duty quantity conversion")
        previous = represented.setdefault(binding["duty"], [])
        require(all(b <= c or d <= a for a,b in ordered for c,d in previous),
                "Duty slices represented by two units")
        previous.extend(ordered)
        if register.units[unit_id].state == "LO":
            require(register.units[unit_id].obligation.identity == binding["duty"],
                    "Redelivery obligation does not name canonical duty")


class Store:
    def __init__(self, path, key, *, clock=None, fault=None, timeout=10):
        require(type(key) is bytes and len(key) >= 32, "Checkpoint key length")
        self.path = Path(path).resolve()
        self.key = key
        self.clock = clock or (lambda: int(time.time()))
        self.fault = fault or (lambda stage: None)
        self.timeout = timeout

    def _mac(self, domain, *values):
        return hmac.new(self.key, encode((domain, *values)), hashlib.sha256).hexdigest()

    def _connect(self):
        require(self.path.exists(), "Missing database")
        # mode=rw prevents a misspelled path from creating an empty authority.
        connection = sqlite3.connect(self.path.as_uri() + "?mode=rw", uri=True,
                                     timeout=self.timeout, isolation_level=None)
        try:
            connection.execute("PRAGMA synchronous=FULL")
        except BaseException:
            connection.close()
            raise
        return connection

    @classmethod
    def create(cls, path, key, register, *, duty_bindings=None, **kwargs):
        path = Path(path).resolve()
        require(not path.exists(), "Existing database")
        bindings = duty_bindings or {}
        validate_bindings(register, bindings)
        payload = {"format": "p14-title-custody:1", "model": MODEL_SHA,
                   "register": pack(register), "policy_commands": {},
                   "duty_bindings": bindings, "outbox": {}}
        store = cls(path, key, **kwargs)
        # Exclusive creation prevents two initializers from replacing custody.
        with path.open("xb"):
            pass
        conn = sqlite3.connect(path, isolation_level=None)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=FULL")
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("CREATE TABLE checkpoint (id INTEGER PRIMARY KEY CHECK(id=1), "
                         "book TEXT NOT NULL, revision INTEGER NOT NULL, payload BLOB NOT NULL, "
                         "head TEXT NOT NULL, mac TEXT NOT NULL)")
            conn.execute("CREATE TABLE journal (seq INTEGER PRIMARY KEY, event BLOB NOT NULL, "
                         "head TEXT NOT NULL, mac TEXT NOT NULL)")
            book = str(uuid.uuid4())
            event = encode({"kind": "create", "model": MODEL_SHA, "initial": payload})
            head = sha(encode((book, 0, "", event.hex(), sha(encode(payload)))))
            conn.execute("INSERT INTO journal VALUES(?,?,?,?)",
                         (0, event, head, store._mac("journal", book, 0, event, head)))
            data = encode(payload)
            conn.execute("INSERT INTO checkpoint VALUES(1,?,?,?,?,?)",
                         (book, 0, data, head, store._mac("checkpoint", book, 0, data, head)))
            conn.commit()
        finally:
            conn.close()
        return store

    def _load(self, conn):
        row = conn.execute("SELECT book, revision, payload, head, mac FROM checkpoint WHERE id=1").fetchone()
        require(row is not None, "Incomplete checkpoint")
        book, revision, data, head, mac = row
        require(hmac.compare_digest(mac, self._mac("checkpoint", book, revision, data, head)),
                "Checkpoint authentication")
        tail = conn.execute("SELECT event, head, mac FROM journal WHERE seq=?", (revision,)).fetchone()
        require(tail is not None and tail[1] == head
                and hmac.compare_digest(tail[2], self._mac("journal", book, revision, tail[0], head)),
                "Checkpoint journal binding")
        payload = decode(data)
        require(set(payload) == {"format", "model", "register", "policy_commands",
                                 "duty_bindings", "outbox"}
                and payload["format"] == "p14-title-custody:1"
                and payload["model"] == MODEL_SHA, "Incompatible custody semantics")
        restore(payload["register"])
        return book, revision, payload, head

    def snapshot(self):
        conn = self._connect()
        try:
            conn.execute("BEGIN")
            book, revision, payload, head = self._load(conn)
            return {"book": book, "revision": revision, "head": head, "payload": payload}
        finally:
            conn.close()

    def _transaction(self, operation):
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            self.fault("after_lock")
            book, revision, payload, old_head = self._load(conn)
            outcome, event, time_guard = operation(payload)
            if event is None:
                conn.rollback()
                return outcome
            self.fault("after_check")
            data = encode(payload)
            changed = conn.execute("UPDATE checkpoint SET revision=?,payload=? WHERE id=1 AND revision=?",
                                   (revision+1, data, revision)).rowcount
            require(changed == 1, "Checkpoint compare-and-commit")
            self.fault("after_state_write")
            self.fault("before_commit")
            event["commit_check_time"] = self.clock()
            if time_guard:
                time_guard(event["commit_check_time"])
            event_data = encode(event)
            head = sha(encode((book, revision+1, old_head, event_data.hex(), sha(data))))
            conn.execute("INSERT INTO journal VALUES(?,?,?,?)",
                         (revision+1, event_data, head,
                          self._mac("journal", book, revision+1, event_data, head)))
            conn.execute("UPDATE checkpoint SET head=?,mac=? WHERE id=1",
                         (head, self._mac("checkpoint", book, revision+1, data, head)))
            self.fault("after_journal_write")
            # Recheck expiry after the last fault point and immediately before
            # COMMIT. The record names the sampled admission time. An external
            # legal act still requires the route's own time and authority facts.
            if time_guard:
                time_guard(self.clock())
            conn.commit()
            self.fault("after_commit")
            return outcome
        except BaseException:
            if conn.in_transaction:
                conn.rollback()
            raise
        finally:
            conn.close()

    def transfer(self, request, evidence):
        evidence = tuple(evidence)
        def operation(payload):
            register = restore(payload["register"])
            require(request.command not in payload["policy_commands"], "Command namespace collision")
            old = register.units.get(request.unit)
            when = self.clock()
            replay = request.command in register.completed
            result = register.apply(request, evidence, when)
            if replay:
                return result, None, None
            new = register.units[request.unit]
            payload["register"] = pack(register)
            binding = payload["duty_bindings"].get(request.unit)
            receipt = {"command": request.command, "request": model.digest(request),
                       "unit": request.unit, "old_generation": old.generation,
                       "new_generation": new.generation, "mode": request.mode,
                       "prior_beneficiary": old.beneficiary, "beneficiary": new.beneficiary,
                       "economic_assignment": old.beneficiary != new.beneficiary,
                       "duty_binding": binding, "continuations": old.continuations,
                       "legal_effect": new.legal_effects[-1], "result": result}
            delivery = sha(encode(("title-transfer-receipt", request.command, receipt)))
            payload["outbox"][delivery] = receipt
            def time_guard(now):
                require(now >= when and all(e.valid_from <= now <= e.valid_until for e in evidence),
                        "Evidence expired during commit or clock moved backward")
            return result, {"kind": "transfer", "request": request,
                            "evidence": evidence, "admission_time": when,
                            "delivery": delivery, "result": result}, time_guard
        return self._transaction(operation)

    def policy(self, command, *, expected_generation, route=None, revoke=(), evidence_id):
        """Apply an admitted authority update in the same serialization order."""
        revoke = tuple(sorted(set(revoke)))
        request = {"command": command, "expected_generation": expected_generation,
                   "route": route, "revoke": revoke, "evidence_id": evidence_id}
        binding = sha(encode(request))
        def operation(payload):
            register = restore(payload["register"])
            require(command and evidence_id, "Authority update identity")
            require(command not in register.completed, "Command namespace collision")
            previous = payload["policy_commands"].get(command)
            if previous is not None:
                require(previous[0] == binding, "Authority command equivocation")
                return previous[1], None, None
            require(register.policy_generation == expected_generation, "Stale authority update")
            if route is not None:
                require(route.identity == register.route.identity
                        and route.generation == register.route.generation + 1,
                        "Route successor generation")
                register.route = route
            register.revoked_evidence.update(revoke)
            register.policy_generation += 1
            result = register.policy_generation
            payload["register"] = pack(register)
            payload["policy_commands"][command] = (binding, result)
            return result, {"kind": "policy", "request": request, "result": result}, None
        return self._transaction(operation)

    def journal(self):
        """Return a verified complete journal in one SQLite read snapshot."""
        conn = self._connect()
        try:
            conn.execute("BEGIN")
            book, revision, payload, head = self._load(conn)
            rows = conn.execute("SELECT seq,event,head,mac FROM journal ORDER BY seq").fetchall()
            require(len(rows) == revision+1, "Journal coverage")
            for expected, (seq, event, row_head, mac) in enumerate(rows):
                require(seq == expected and hmac.compare_digest(mac,
                        self._mac("journal", book, seq, event, row_head)), "Journal authentication")
            return {"book": book, "revision": revision, "head": head,
                    "events": [(seq, decode(event), row_head) for seq,event,row_head,_ in rows],
                    "payload": payload}
        finally:
            conn.close()


def replay(journal):
    """Reconstruct verified local events. No SQL writes or external actions."""
    current = None
    head = ""
    for seq, event, expected_head in journal["events"]:
        if seq == 0:
            require(event["kind"] == "create" and event["model"] == MODEL_SHA, "Replay origin")
            current = decode(encode(event["initial"]))
            require(current["format"] == "p14-title-custody:1"
                    and current["model"] == MODEL_SHA, "Replay custody semantics")
        elif event["kind"] == "transfer":
            reg = restore(current["register"])
            old = reg.units[event["request"].unit]
            result = reg.apply(event["request"], event["evidence"], event["admission_time"])
            require(result == event["result"], "Replay transfer result")
            current["register"] = pack(reg)
            new = reg.units[old.identity]
            receipt = {"command": event["request"].command, "request": model.digest(event["request"]),
                       "unit": old.identity, "old_generation": old.generation,
                       "new_generation": new.generation, "mode": event["request"].mode,
                       "prior_beneficiary": old.beneficiary, "beneficiary": new.beneficiary,
                       "economic_assignment": old.beneficiary != new.beneficiary,
                       "duty_binding": current["duty_bindings"].get(old.identity),
                       "continuations": old.continuations, "legal_effect": new.legal_effects[-1],
                       "result": result}
            delivery = sha(encode(("title-transfer-receipt", event["request"].command, receipt)))
            require(delivery == event["delivery"], "Replay delivery identity")
            current["outbox"][delivery] = receipt
        elif event["kind"] == "policy":
            q = event["request"]
            reg = restore(current["register"])
            require(reg.policy_generation == q["expected_generation"], "Replay authority generation")
            if q["route"] is not None:
                reg.route = q["route"]
            reg.revoked_evidence.update(q["revoke"])
            reg.policy_generation += 1
            current["register"] = pack(reg)
            current["policy_commands"][q["command"]] = (sha(encode(q)), reg.policy_generation)
        else:
            raise ValueError("Unknown journal event")
        data = encode(current)
        head = sha(encode((journal["book"], seq, head, encode(event).hex(), sha(data))))
        require(head == expected_head, "Replay state or chain mismatch")
    require(head == journal["head"] and current == journal["payload"], "Replay checkpoint mismatch")
    return current
