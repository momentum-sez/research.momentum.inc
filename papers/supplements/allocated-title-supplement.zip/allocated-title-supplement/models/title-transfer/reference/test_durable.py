"""Real SQLite and subprocess tests. Evidence and authority are synthetic."""
from dataclasses import replace
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from durable import Store, encode, decode, replay, restore, pack, duty_id
from transfers import make_request
from test_transfers import fixture, admit

KEY = b"synthetic-test-checkpoint-key-32-bytes-or-more"
HERE = Path(__file__).resolve().parent


class DurableTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.counter = 0

    def setup_store(self, state="AP", **kwargs):
        reg, unit, request = fixture(state, **kwargs)
        path = self.root / ("book-" + str(self.counter) + ".sqlite")
        self.counter += 1
        return Store.create(path, KEY, reg, clock=lambda: 3), reg, unit, request

    def worker(self, store, operation="transfer", request=None, evidence=(), **extra):
        spec = {"database": str(store.path), "key": KEY, "operation": operation,
                "request": request, "evidence": evidence, "now": 3, **extra}
        p = self.root / ("spec-" + str(self.counter) + ".json")
        self.counter += 1
        p.write_bytes(encode(spec))
        flags = ["-O"] if sys.flags.optimize else []
        return subprocess.Popen([sys.executable, *flags, str(HERE / "worker.py"), str(p)],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def finish(self, process, expected=0):
        stdout, stderr = process.communicate(timeout=20)
        self.assertEqual(process.returncode, expected, (stdout, stderr))
        if not stdout:
            return None
        result = decode(stdout)
        self.assertEqual(result["optimization"], sys.flags.optimize)
        return result

    def wait_ready(self, paths):
        deadline = time.monotonic() + 10
        while not all(p.exists() for p in paths):
            if time.monotonic() > deadline:
                self.fail("Worker readiness timeout")
            time.sleep(0.005)

    def reg(self, store):
        return restore(store.snapshot()["payload"]["register"])

    def test_all_four_modes_commit_and_reopen(self):
        for mode in ("registered", "beneficial", "outright", "assignment"):
            store, reg, unit, _ = self.setup_store("LO" if mode == "assignment" else "EN")
            owner = None if mode == "assignment" else ("Alice" if mode == "beneficial" else "Bob")
            beneficiary = "Alice" if mode == "registered" else "Bob"
            q = make_request(unit, reg.route, "t:"+mode, mode, owner, beneficiary, 2)
            result = self.finish(self.worker(store, request=q, evidence=admit(reg,unit,q)))
            fresh = self.finish(self.worker(store, operation="snapshot"))["result"]
            actual = fresh["payload"]["register"]["units"][unit.identity]
            self.assertEqual((actual.registered_owner, actual.beneficiary), (owner,beneficiary))
            self.assertEqual(actual.interests, unit.interests)
            self.assertEqual(actual.obligation, unit.obligation)
            self.assertEqual(fresh["revision"], 1)
            self.assertEqual(len(fresh["payload"]["outbox"]), 1)
            self.assertEqual(result["result"], fresh["payload"]["register"]["completed"][q.command][1])

    def test_crash_boundaries_are_atomic_and_retryable(self):
        stages = ("after_lock", "after_check", "after_state_write", "before_commit",
                  "after_journal_write", "after_commit")
        for stage in stages:
            with self.subTest(stage=stage):
                store, reg, unit, q = self.setup_store("EN", impaired=True, pending=True)
                evidence = admit(reg,unit,q)
                before = store.snapshot()
                self.finish(self.worker(store,request=q,evidence=evidence,fault=stage),77)
                current = self.finish(self.worker(store,operation="snapshot"))["result"]
                if stage == "after_commit":
                    self.assertEqual(current["revision"],1)
                    self.assertEqual(current["payload"]["register"]["units"][unit.identity].beneficiary,"Bob")
                else:
                    self.assertEqual(current,before)
                result = self.finish(self.worker(store,request=q,evidence=evidence))["result"]
                after = store.snapshot()
                self.assertEqual(after["revision"],1)
                self.assertEqual(len(after["payload"]["outbox"]),1)
                self.assertEqual(len(after["payload"]["register"]["history"]),1)
                self.assertEqual(result,after["payload"]["register"]["completed"][q.command][1])
                self.assertEqual(replay(store.journal()),after["payload"])

    def test_two_processes_competing_for_same_unit_have_one_winner(self):
        store, reg, unit, q = self.setup_store("EN")
        other = make_request(unit,reg.route,"transfer:2","outright","Carol","Carol",2)
        # Both exact requests pass separately against the same opening state.
        # That local fact alone cannot authorize their joint execution.
        local_results=[]
        for candidate in (q,other):
            isolated=restore(decode(encode(pack(reg))))
            local_results.append(isolated.apply(candidate,admit(reg,unit,candidate),3))
        self.assertNotEqual(local_results[0],local_results[1])
        start=self.root/"start";ready=[self.root/"r1",self.root/"r2"]
        processes=[self.worker(store,request=x,evidence=admit(reg,unit,x),start=str(start),ready=str(y))
                   for x,y in zip((q,other),ready)]
        self.wait_ready(ready);start.write_text("go")
        results=[p.communicate(timeout=20) for p in processes]
        self.assertEqual(sorted(p.returncode for p in processes),[0,2],results)
        current=store.snapshot()
        self.assertEqual(current["revision"],1)
        self.assertEqual(len(current["payload"]["outbox"]),1)
        self.assertEqual(self.reg(store).units[unit.identity].generation,1)

    def test_two_processes_identical_command_return_same_result_once(self):
        store,reg,unit,q=self.setup_store()
        start=self.root/"start";ready=[self.root/"r1",self.root/"r2"]
        processes=[self.worker(store,request=q,evidence=admit(reg,unit,q),start=str(start),ready=str(y))
                   for y in ready]
        self.wait_ready(ready);start.write_text("go")
        results=[self.finish(p)["result"] for p in processes]
        self.assertEqual(results[0],results[1])
        self.assertEqual(store.snapshot()["revision"],1)

    def test_disjoint_units_progress_and_command_identity_is_global(self):
        for same_command in (False,True):
            reg,u,_=fixture("EN")
            v=replace(u,identity="unit:2",allocation=("lot:2:0:5",),
                      interests=tuple(replace(i,identity="lien:2",covered_claim="unit:2") for i in u.interests))
            reg.units[v.identity]=v
            store=Store.create(self.root/("distinct-"+str(same_command)+".sqlite"),KEY,reg,clock=lambda:3)
            q1=make_request(u,reg.route,"t:1","outright","Bob","Bob",2)
            q2=make_request(v,reg.route,"t:1" if same_command else "t:2","outright","Carol","Carol",2)
            start=self.root/("start-"+str(same_command))
            ready=[self.root/("ready-"+str(same_command)+str(i)) for i in range(2)]
            processes=[self.worker(store,request=q,evidence=admit(reg,unit,q),start=str(start),ready=str(mark))
                       for q,unit,mark in zip((q1,q2),(u,v),ready)]
            self.wait_ready(ready);start.write_text("go")
            outputs=[p.communicate(timeout=20) for p in processes]
            self.assertEqual(sorted(p.returncode for p in processes),[0,2] if same_command else [0,0],outputs)
            current=store.snapshot()
            self.assertEqual(current["revision"],1 if same_command else 2)
            self.assertEqual(sum(x.generation for x in self.reg(store).units.values()),current["revision"])

    def test_same_command_different_recipient_is_equivocation(self):
        store,reg,unit,q=self.setup_store()
        other=make_request(unit,reg.route,q.command,"outright","Carol","Carol",2)
        result=store.transfer(q,admit(reg,unit,q))
        rejected=self.finish(self.worker(store,request=other,evidence=admit(reg,unit,other)),2)
        self.assertIn("equivocation",rejected["error"])
        self.assertEqual(store.transfer(q,()),result)
        self.assertEqual(store.snapshot()["revision"],1)

    def test_revocation_commits_before_waiting_transfer_reads(self):
        store,reg,unit,q=self.setup_store("EN")
        evidence=admit(reg,unit,q)
        ready=self.root/"ready";start=self.root/"start"
        process=self.worker(store,request=q,evidence=evidence,ready=str(ready),start=str(start))
        self.wait_ready([ready])
        store.policy("revoke:1",expected_generation=2,revoke=(evidence[0].identity,),evidence_id="revocation-act:1")
        start.write_text("go")
        rejected=self.finish(process,2)
        self.assertIn("generations",rejected["error"])
        self.assertEqual(self.reg(store).units[unit.identity],unit)

    def test_completed_replay_survives_route_change_and_later_transfer(self):
        store,reg,unit,q=self.setup_store()
        first=store.transfer(q,admit(reg,unit,q))
        current=self.reg(store);new=current.units[unit.identity]
        q2=make_request(new,current.route,"transfer:2","outright","Carol","Carol",2)
        store.transfer(q2,admit(current,new,q2))
        route=replace(current.route,generation=5,active=False,classification="withdrawn-scope")
        store.policy("authority:3",expected_generation=2,route=route,evidence_id="act:3")
        before=store.snapshot()
        result=self.finish(self.worker(store,request=q,evidence=(),now=99))["result"]
        self.assertEqual(first,result)
        self.assertEqual(store.snapshot(),before)

    def test_expiry_while_waiting_uses_current_clock(self):
        store,reg,unit,q=self.setup_store()
        holder=sqlite3.connect(store.path,isolation_level=None)
        holder.execute("BEGIN IMMEDIATE")
        clock_file=self.root/"clock";clock_file.write_text("3")
        ready=self.root/"ready"
        process=self.worker(store,request=q,evidence=admit(reg,unit,q),clock_file=str(clock_file),ready=str(ready))
        self.wait_ready([ready]);clock_file.write_text("11")
        holder.rollback();holder.close()
        rejected=self.finish(process,2)
        self.assertIn("time",rejected["error"])
        self.assertEqual(store.snapshot()["revision"],0)

    def test_expiry_after_state_write_rolls_back_whole_transfer(self):
        store,reg,unit,q=self.setup_store()
        current=[3]
        def fault(stage):
            if stage=="after_state_write":current[0]=11
        delayed=Store(store.path,KEY,clock=lambda:current[0],fault=fault)
        before=store.snapshot()
        with self.assertRaisesRegex(ValueError,"expired"):
            delayed.transfer(q,admit(reg,unit,q))
        self.assertEqual(store.snapshot(),before)

    def test_missing_lien_consent_cannot_commit(self):
        store,reg,unit,q=self.setup_store("EN")
        evidence=tuple(x for x in admit(reg,unit,q) if x.role!="interest-continuity")
        self.finish(self.worker(store,request=q,evidence=evidence),2)
        self.assertEqual(store.snapshot()["revision"],0)
        self.assertEqual(self.reg(store).units[unit.identity],unit)

    def test_rational_quantities_liens_and_continuations_survive_restart(self):
        reg,unit,_=fixture("EN",pending=True)
        unit=replace(unit,quantity=F(5,3),supported=F(2,3),allocation=(("lot:1",F(0),F(5,3)),))
        reg.units[unit.identity]=unit
        store=Store.create(self.root/"rational.sqlite",KEY,reg,clock=lambda:3)
        q=make_request(unit,reg.route,"rational:1","outright","Bob","Bob",2)
        self.finish(self.worker(store,request=q,evidence=admit(reg,unit,q)))
        actual=self.reg(store).units[unit.identity]
        self.assertEqual(actual.quantity-actual.supported,F(1))
        self.assertEqual(actual.interests,unit.interests)
        self.assertEqual(actual.continuations,unit.continuations)
        for name in ("cash_allocations","funding_reservations","physical_free"):
            self.assertEqual(getattr(self.reg(store),name),getattr(reg,name))

    def test_lo_assignments_keep_original_recipient_and_duty_root(self):
        reg,unit,_=fixture("LO",pending=True)
        origin=("issuer:1","constituting-act:1","occurrence:1")
        root=duty_id(*origin)
        unit=replace(unit,obligation=replace(unit.obligation,identity=root))
        reg.units[unit.identity]=unit
        binding={unit.identity:{"origin":origin,"duty":root,"root_slices":((0,5),),
                               "duty_quantity":5,"quantum":F(1),"asset":"XAU","unit":"fine-gram",
                               "source_receipt":"admitted-duty-receipt:1"}}
        store=Store.create(self.root/"duty.sqlite",KEY,reg,duty_bindings=binding,clock=lambda:3)
        for i,buyer in enumerate(("Bob","Carol")):
            current=self.reg(store);u=current.units[unit.identity]
            q=make_request(u,current.route,"assignment:"+str(i),"assignment",None,buyer,2)
            self.finish(self.worker(store,request=q,evidence=admit(current,u,q)))
        result=self.finish(self.worker(store,operation="replay"))["result"]
        current=restore(result["register"]).units[unit.identity]
        self.assertEqual(current.beneficiary,"Carol")
        self.assertEqual(current.continuations[0].original_recipient,"Alice")
        self.assertEqual(current.obligation,unit.obligation)
        self.assertEqual((current.state,current.allocation,current.supported),("LO",(),F(0)))
        self.assertEqual(result["duty_bindings"],binding)
        self.assertEqual(len(result["outbox"]),2)
        for record in result["outbox"].values():
            self.assertEqual(record["duty_binding"]["duty"],root)
            self.assertEqual(record["continuations"][0].original_recipient,"Alice")

    def test_authenticated_state_and_journal_corruption_rejected(self):
        for target in ("checkpoint","journal"):
            store,reg,unit,q=self.setup_store()
            store.transfer(q,admit(reg,unit,q))
            conn=sqlite3.connect(store.path)
            if target=="checkpoint":conn.execute("UPDATE checkpoint SET payload=?",(b"{}",))
            else:conn.execute("UPDATE journal SET event=? WHERE seq=0",(b"{}",))
            conn.commit();conn.close()
            with self.subTest(target=target),self.assertRaises(ValueError):
                store.journal()

    def test_wrong_key_and_reinitialization_cannot_restore_stale_authority(self):
        store,reg,unit,q=self.setup_store()
        store.policy("revoked",expected_generation=2,revoke=("consent:1",),evidence_id="act:1")
        with self.assertRaises(ValueError):Store.create(store.path,KEY,reg)
        with self.assertRaises(ValueError):Store(store.path,b"different-key"*3).snapshot()
        with patch("durable.MODEL_SHA", "incompatible-same-shape-model"):
            with self.assertRaisesRegex(ValueError, "Incompatible custody semantics"):
                Store(store.path,KEY).snapshot()
        self.assertEqual(self.reg(Store(store.path,KEY)).policy_generation,3)

    def test_route_successor_requires_fresh_exact_consent(self):
        store,reg,u,q=self.setup_store()
        changed=replace(reg.route,generation=5,classification="new-transfer-classification")
        store.policy("route-change",expected_generation=2,route=changed,evidence_id="classification-act")
        self.finish(self.worker(store,request=q,evidence=admit(reg,u,q)),2)
        current=self.reg(store)
        fresh=make_request(u,current.route,"fresh-transfer","outright","Bob","Bob",3)
        store.transfer(fresh,admit(current,u,fresh))
        self.assertEqual(self.reg(store).units[u.identity].beneficiary,"Bob")

    def test_pure_replay_uses_no_database_or_provider(self):
        store,reg,unit,q=self.setup_store("EN")
        store.transfer(q,admit(reg,unit,q))
        journal=store.journal()
        with patch("sqlite3.connect",side_effect=RuntimeError("No replay I/O")):
            self.assertEqual(replay(journal),journal["payload"])

    def test_policy_retry_is_idempotent_and_conflicting_payload_rejected(self):
        store,_,_,_=self.setup_store()
        args={"expected_generation":2,"revoke":("consent:1",),"evidence_id":"act:1"}
        self.assertEqual(store.policy("p:1",**args),3)
        self.assertEqual(store.policy("p:1",**args),3)
        with self.assertRaises(ValueError):store.policy("p:1",**{**args,"revoke":("consent:2",)})
        self.assertEqual(store.snapshot()["revision"],1)


if __name__=="__main__":
    unittest.main(verbosity=2)
