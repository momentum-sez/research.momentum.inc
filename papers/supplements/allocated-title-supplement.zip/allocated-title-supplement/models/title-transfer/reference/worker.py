"""Fresh-process driver for crash and concurrency witnesses."""
from pathlib import Path
import os
import sys
import time

from durable import Store, decode, encode, replay


def main():
    spec = decode(Path(sys.argv[1]).read_bytes())
    if spec.get("ready"):
        Path(spec["ready"]).write_text("ready")
    if spec.get("start"):
        deadline = time.monotonic() + 15
        while not Path(spec["start"]).exists():
            if time.monotonic() > deadline:
                raise RuntimeError("Start barrier timeout")
            time.sleep(0.005)
    def clock():
        if spec.get("clock_file"):
            return int(Path(spec["clock_file"]).read_text())
        return spec.get("now", int(time.time()))
    def fault(stage):
        if spec.get("fault") == stage:
            os._exit(77)
    store = Store(spec["database"], spec["key"], clock=clock, fault=fault)
    if spec["operation"] == "transfer":
        result = store.transfer(spec["request"], spec["evidence"])
    elif spec["operation"] == "snapshot":
        result = store.snapshot()
    elif spec["operation"] == "replay":
        result = replay(store.journal())
    else:
        raise ValueError("Unknown worker operation")
    sys.stdout.buffer.write(encode({"status": "ok", "result": result,
                                   "optimization": sys.flags.optimize}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stdout.buffer.write(encode({"status": "rejected", "error": str(exc),
                                       "optimization": sys.flags.optimize}))
        raise SystemExit(2)
