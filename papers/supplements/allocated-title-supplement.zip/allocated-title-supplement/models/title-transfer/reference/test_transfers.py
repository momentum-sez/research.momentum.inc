"""Constructive and adversarial transfer traces. All evidence is synthetic."""
from dataclasses import replace
from fractions import Fraction as F
from itertools import product
import unittest

from transfers import (Unit, Route, Request, Interest, Accessory, Redelivery,
                       Continuation, Evidence, Register,
                       digest, successor, make_request, required_evidence)


def fixture(state="AP", *, impaired=False, pending=False):
    interest = Interest("lien:1", "Lender", 1, "loan:7", "pledge:7", "unit:1")
    unit = Unit("unit:1", 0, state, F(5), "Alice" if state != "LO" else None,
                "Alice", "bulk-share:contract", ("lot:1:0:5",) if state != "LO" else (),
                F(0) if state == "LO" else F(3 if impaired else 5),
                (interest,) if state == "EN" else (),
                Redelivery("redelivery:1", "Borrower", F(5), 30, "lease:1",
                           (Accessory("collateral:1", "CollateralCustodian", "security:1", "unit:1"),))
                if state == "LO" else None,
                (Continuation("dispatch:1", "Provider", "Alice", "retained-performance-terms:1"),)
                if pending else (), ("purchase:1",), ("title-act:1",))
    route = Route("route:1", 4, unit.title_basis, "admitted-product-scope:7",
                  ("registered", "beneficial", "outright", "assignment"),
                  "Custodian", "LocalAuthority", "EligibilityAuthority", "LegalAuthority")
    register = Register([unit], route, 2)
    register.cash_allocations = (("payment:1", "Alice", F(300)),)
    register.funding_reservations = (("pending:pay", "Alice", F(40)),)
    register.physical_free = (("lot:2", F(6)),)
    mode = "assignment" if state == "LO" else "outright"
    req = make_request(unit, route, "transfer:1", mode,
                       None if state == "LO" else "Bob", "Bob", 2)
    return register, unit, req


def admit(register, unit, req):
    return tuple(Evidence("e:" + str(i), role, issuer, subject, digest(req),
                          register.route.generation, register.policy_generation,
                          1, 10, "effective" if role == "legal-effect" else "admitted")
                 for i, (role, issuer, subject) in
                 enumerate(sorted(required_evidence(unit, register.route, req))))


class TransferTests(unittest.TestCase):
    def test_clean_transfer_conserves_every_resource_projection(self):
        r, u, q = fixture()
        before = (r.cash_allocations, r.funding_reservations, r.physical_free)
        r.apply(q, admit(r, u, q), 3)
        v = r.units[u.identity]
        self.assertEqual((v.registered_owner, v.beneficiary), ("Bob", "Bob"))
        self.assertEqual((v.identity, v.quantity, v.allocation, v.supported),
                         (u.identity, u.quantity, u.allocation, u.supported))
        self.assertEqual(before, (r.cash_allocations, r.funding_reservations, r.physical_free))
        self.assertEqual(v.provenance[:-1], u.provenance)

    def test_consented_encumbered_transfer_retains_creditor_rank_and_debt(self):
        r, u, q = fixture("EN")
        r.apply(q, admit(r, u, q), 3)
        self.assertEqual(r.units[u.identity].interests, u.interests)
        self.assertEqual(r.units[u.identity].state, "EN")

    def test_missing_lender_consent_cannot_clean_title(self):
        r, u, q = fixture("EN")
        evidence = tuple(e for e in admit(r, u, q) if e.role != "interest-continuity")
        with self.assertRaises(ValueError):
            r.apply(q, evidence, 3)
        self.assertEqual(r.units[u.identity], u)
        self.assertEqual(r.completed, {})

    def test_registered_transfer_preserves_beneficiary(self):
        r, u, _ = fixture()
        q = make_request(u, r.route, "trustee:change", "registered", "Trustee", "Alice", 2)
        r.apply(q, admit(r, u, q), 3)
        self.assertEqual(r.units[u.identity].beneficiary, "Alice")
        self.assertEqual(r.units[u.identity].registered_owner, "Trustee")

    def test_beneficial_transfer_preserves_registered_owner(self):
        r, u, _ = fixture()
        q = make_request(u, r.route, "beneficial:change", "beneficial", "Alice", "Bob", 2)
        r.apply(q, admit(r, u, q), 3)
        self.assertEqual(r.units[u.identity].registered_owner, "Alice")
        self.assertEqual(r.units[u.identity].beneficiary, "Bob")

    def test_registered_transfer_cannot_relabel_economic_owner(self):
        r, u, _ = fixture()
        with self.assertRaises(ValueError):
            make_request(u, r.route, "bad", "registered", "Trustee", "Mallory", 2)

    def test_loan_assignment_preserves_obligor_maturity_collateral_and_no_metal(self):
        r, u, q = fixture("LO")
        r.apply(q, admit(r, u, q), 3)
        v = r.units[u.identity]
        self.assertEqual(v.obligation, u.obligation)
        self.assertEqual((v.state, v.registered_owner, v.allocation, v.supported),
                         ("LO", None, (), F(0)))
        self.assertEqual(v.beneficiary, "Bob")

    def test_loan_cannot_take_present_title_transfer_mode(self):
        r, u, _ = fixture("LO")
        for mode in ("registered", "beneficial", "outright"):
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                make_request(u, r.route, "bad", mode, "Bob", "Bob", 2)

    def test_impaired_transfer_preserves_deficit(self):
        r, u, q = fixture("EN", impaired=True)
        r.apply(q, admit(r, u, q), 3)
        v = r.units[u.identity]
        self.assertEqual(v.quantity - v.supported, F(2))

    def test_every_required_role_is_load_bearing(self):
        for state in ("AP", "EN", "LO"):
            r, u, q = fixture(state, pending=True)
            evidence = admit(r, u, q)
            for missing in evidence:
                with self.subTest(state=state, role=missing.role), self.assertRaises(ValueError):
                    r.apply(q, [e for e in evidence if e != missing], 3)
                self.assertEqual(r.units[u.identity], u)

    def test_current_authority_expiry_revocation_and_generation(self):
        for change in ("expiry", "revocation", "policy", "route", "inactive", "classification"):
            r, u, q = fixture()
            evidence = admit(r, u, q)
            now = 3
            if change == "expiry": now = 11
            elif change == "revocation": r.revoked_evidence.add(evidence[0].identity)
            elif change == "policy": r.policy_generation += 1
            elif change == "route": r.route = replace(r.route, generation=5)
            elif change == "inactive": r.route = replace(r.route, active=False)
            elif change == "classification": r.route = replace(r.route, classification="another bargain")
            with self.subTest(change=change), self.assertRaises(ValueError):
                r.apply(q, evidence, now)
            self.assertEqual(r.units[u.identity], u)

    def test_exact_successor_rejects_lien_stripping_or_support_restoration(self):
        for change in ("lien", "support", "obligation", "continuation"):
            r, u, q = fixture("EN", impaired=True, pending=True)
            evidence = admit(r, u, q)
            if change == "lien": r.units[u.identity] = replace(u, interests=(), state="AP")
            elif change == "support": r.units[u.identity] = replace(u, supported=F(5))
            elif change == "obligation": r.units[u.identity] = replace(u, obligation=("changed",))
            else: r.units[u.identity] = replace(u, continuations=())
            with self.subTest(change=change), self.assertRaises(ValueError):
                r.apply(q, evidence, 3)

    def test_fresh_current_evidence_enables_transfer_after_policy_change(self):
        r, u, q = fixture()
        r.policy_generation += 1
        q = make_request(u, r.route, "renewed", "outright", "Bob", "Bob", 3)
        r.apply(q, admit(r, u, q), 3)
        self.assertEqual(r.units[u.identity].beneficiary, "Bob")

    def test_completed_retry_is_read_only_after_revocation(self):
        r, u, q = fixture()
        evidence = admit(r, u, q)
        result = r.apply(q, evidence, 3)
        state = r.units[u.identity]
        r.policy_generation += 1
        r.revoked_evidence.update(e.identity for e in evidence)
        self.assertEqual(r.apply(q, (), 99), result)
        self.assertEqual(r.units[u.identity], state)
        self.assertEqual(len(r.history), 1)

    def test_command_equivocation_rejected(self):
        r, u, q = fixture()
        r.apply(q, admit(r, u, q), 3)
        with self.assertRaises(ValueError):
            r.apply(replace(q, new_beneficiary="Mallory"), (), 3)

    def test_competing_transferees_cannot_both_consume_one_generation(self):
        r, u, q = fixture()
        other = make_request(u, r.route, "transfer:2", "outright", "Carol", "Carol", 2)
        other_evidence = admit(r, u, other)
        r.apply(q, admit(r, u, q), 3)
        with self.assertRaises(ValueError):
            r.apply(other, other_evidence, 3)
        self.assertEqual(r.units[u.identity].beneficiary, "Bob")

    def test_preparation_is_not_effective_legal_transfer(self):
        r, u, q = fixture()
        evidence = tuple(replace(e, effect="prepared") if e.role == "legal-effect" else e
                         for e in admit(r, u, q))
        with self.assertRaises(ValueError): r.apply(q, evidence, 3)
        self.assertEqual(r.units[u.identity], u)

    def test_evidence_for_another_recipient_is_rejected(self):
        r, u, q = fixture()
        other = make_request(u, r.route, "other", "outright", "Carol", "Carol", 2)
        with self.assertRaises(ValueError): r.apply(q, admit(r, u, other), 3)

    def test_replay_reconstructs_without_external_actions(self):
        r, u, q = fixture("EN")
        r.apply(q, iter(admit(r, u, q)), 3)
        self.assertTrue(r.history[0][1])
        second = make_request(r.units[u.identity], r.route, "transfer:2", "outright", "Carol", "Carol", 2)
        r.apply(second, admit(r, r.units[u.identity], second), 4)
        copy, _, _ = fixture("EN")
        for request, evidence, now, result in r.history:
            self.assertEqual(copy.apply(request, evidence, now), result)
        self.assertEqual(copy.units, r.units)

    def test_finite_composition_preserves_quantity_and_right_kind(self):
        # 3 states x 2 impairment cases x 2 continuation cases x 4 destinations.
        count = 0
        for state, impaired, pending in product(("AP", "EN", "LO"), (False, True), (False, True)):
            r, initial, _ = fixture(state, impaired=impaired, pending=pending)
            for i, owner in enumerate(("Bob", "Carol", "Alice", "Dave")):
                u = r.units[initial.identity]
                mode = "assignment" if state == "LO" else "outright"
                q = make_request(u, r.route, "t:" + str(i), mode,
                                 None if state == "LO" else owner, owner, 2)
                r.apply(q, admit(r, u, q), 3)
                v = r.units[initial.identity]
                self.assertEqual((v.quantity, v.state, v.supported, v.allocation,
                                  v.interests, v.obligation, v.continuations),
                                 (initial.quantity, initial.state, initial.supported,
                                  initial.allocation, initial.interests, initial.obligation,
                                  initial.continuations))
                count += 1
        self.assertEqual(count, 48)


if __name__ == "__main__":
    unittest.main(verbosity=2)
