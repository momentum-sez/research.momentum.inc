"""Exact title-transfer reference semantics under admitted evidence premises.

Evidence admission is a trusted input boundary. This module performs no custody,
legal, provider, signature, or production-runtime operation.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from fractions import Fraction
import hashlib
import json


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(value):
    def enc(x):
        if isinstance(x, Fraction):
            return {"rational": [x.numerator, x.denominator]}
        if hasattr(x, "__dataclass_fields__"):
            return {k: enc(getattr(x, k)) for k in x.__dataclass_fields__}
        if isinstance(x, (tuple, list)):
            return [enc(y) for y in x]
        if isinstance(x, dict):
            return {k: enc(v) for k, v in x.items()}
        return x
    return hashlib.sha256(json.dumps(enc(value), sort_keys=True,
                                    separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class Interest:
    identity: str
    creditor: str
    priority: int
    secured_obligation: str
    governing_instrument: str
    covered_claim: str


@dataclass(frozen=True)
class Accessory:
    identity: str
    controller: str
    governing_instrument: str
    covered_claim: str


@dataclass(frozen=True)
class Redelivery:
    identity: str
    obligor: str
    quantity: Fraction
    maturity: int
    governing_instrument: str
    accessories: tuple[Accessory, ...]
    # The creditor is the beneficiary of the containing stable unit.


@dataclass(frozen=True)
class Continuation:
    command: str
    provider: str
    original_recipient: str
    performance_rule: str
    # This immutable rule states how the pre-issued performance affects the
    # transferred right and which separate claims each party retains.


@dataclass(frozen=True)
class Unit:
    identity: str
    generation: int
    state: str
    quantity: Fraction
    registered_owner: str | None
    beneficiary: str
    title_basis: str
    allocation: tuple
    supported: Fraction
    interests: tuple[Interest, ...] = ()
    obligation: Redelivery | None = None
    continuations: tuple[Continuation, ...] = ()
    provenance: tuple = ()
    legal_effects: tuple = ()

    def validate(self):
        require(self.state in ("AP", "EN", "LO"), "Transfer state")
        require(self.quantity > 0 and 0 <= self.supported <= self.quantity,
                "Quantity or support")
        require(bool(self.identity and self.beneficiary and self.title_basis),
                "Missing title identity")
        require(len({i.identity for i in self.interests}) == len(self.interests),
                "Duplicate interest")
        require(all(i.covered_claim == self.identity for i in self.interests),
                "Interest scope")
        if self.state == "LO":
            require(self.registered_owner is None and not self.allocation
                    and self.supported == 0 and bool(self.obligation),
                    "Redelivery claim is not present title")
            require(self.obligation.quantity == self.quantity
                    and all(a.covered_claim == self.identity
                            for a in self.obligation.accessories),
                    "Redelivery and accessory scope")
        else:
            require(bool(self.registered_owner and self.allocation),
                    "Missing present-title basis")
            require((self.state == "EN") == bool(self.interests),
                    "Encumbrance classification")


@dataclass(frozen=True)
class Route:
    identity: str
    generation: int
    title_basis: str
    classification: str
    modes: tuple[str, ...]
    custodian: str
    authority: str
    eligibility_authority: str
    legal_authority: str
    active: bool = True


@dataclass(frozen=True)
class Request:
    command: str
    unit: str
    expected_generation: int
    mode: str
    new_registered_owner: str | None
    new_beneficiary: str
    route: str
    route_generation: int
    route_snapshot: str
    expected_policy_generation: int
    successor_snapshot: str


@dataclass(frozen=True)
class Evidence:
    identity: str
    role: str
    issuer: str
    subject: str
    request_hash: str
    route_generation: int
    policy_generation: int
    valid_from: int
    valid_until: int
    effect: str


def successor(unit, request):
    unit.validate()
    require(request.unit == unit.identity, "Wrong unit")
    require(request.expected_generation == unit.generation, "Stale title generation")
    mode = request.mode
    if mode == "registered":
        require(unit.state in ("AP", "EN"), "Registered title requires present metal")
        require(request.new_registered_owner != unit.registered_owner
                and bool(request.new_registered_owner)
                and request.new_beneficiary == unit.beneficiary,
                "Registered transfer preserves beneficial ownership")
    elif mode == "beneficial":
        require(unit.state in ("AP", "EN"), "Beneficial title requires present metal")
        require(request.new_registered_owner == unit.registered_owner
                and request.new_beneficiary != unit.beneficiary
                and bool(request.new_beneficiary),
                "Beneficial transfer preserves registered ownership")
    elif mode == "outright":
        require(unit.state in ("AP", "EN"), "Outright title requires present metal")
        require(bool(request.new_registered_owner)
                and request.new_registered_owner == request.new_beneficiary
                and request.new_beneficiary != unit.beneficiary,
                "Outright transfer recipient")
    elif mode == "assignment":
        require(unit.state == "LO" and request.new_registered_owner is None
                and bool(request.new_beneficiary)
                and request.new_beneficiary != unit.beneficiary,
                "Assignment changes the redelivery creditor only")
    else:
        raise ValueError("Unknown transfer mode")
    return replace(unit, registered_owner=request.new_registered_owner,
                   beneficiary=request.new_beneficiary,
                   generation=unit.generation + 1)


def make_request(unit, route, command, mode, registered, beneficiary, policy_generation):
    request = Request(command, unit.identity, unit.generation, mode, registered,
                      beneficiary, route.identity, route.generation, digest(route),
                      policy_generation, "")
    return replace(request, successor_snapshot=digest(successor(unit, request)))


def required_evidence(unit, route, request):
    """Each listed right stays unchanged or has exact prospective permission."""
    rows = {("authority", route.authority, route.identity),
            ("legal-effect", route.legal_authority, unit.identity),
            ("eligibility", route.eligibility_authority, request.new_beneficiary)}
    if request.new_registered_owner:
        rows.add(("eligibility", route.eligibility_authority,
                  request.new_registered_owner))
    # The admitted route requires all affected owners to consent. A standing
    # mandate can supply this evidence for its precise subject and scope.
    for owner in {unit.registered_owner, unit.beneficiary} - {None}:
        rows.add(("instruction", owner, unit.identity))
    for owner in {request.new_registered_owner, request.new_beneficiary} - {None}:
        rows.add(("acceptance", owner, unit.identity))
    if unit.state != "LO":
        rows.add(("custody", route.custodian, unit.identity))
    else:
        # The governing assignment route requires debtor acknowledgment.
        rows.add(("obligor", unit.obligation.obligor, unit.identity))
        for accessory in unit.obligation.accessories:
            rows.add(("accessory-continuity", accessory.controller, accessory.identity))
    for interest in unit.interests:
        rows.add(("interest-continuity", interest.creditor, interest.identity))
    for continuation in unit.continuations:
        rows.add(("continuation", route.legal_authority, continuation.command))
        rows.add(("provider-continuation", continuation.provider, continuation.command))
    return rows


class Register:
    """One compare-and-commit authority. Callers serialize apply operations."""
    def __init__(self, units, route, policy_generation=0):
        self.units = {u.identity: u for u in units}
        require(len(self.units) == len(units), "Duplicate unit")
        for u in units:
            u.validate()
        self.route = route
        self.policy_generation = policy_generation
        self.completed = {}
        self.revoked_evidence = set()
        self.history = []
        # References to the surrounding conserved projections. A transfer
        # does not modify any of these records.
        self.cash_allocations = ()
        self.funding_reservations = ()
        self.physical_free = ()

    def apply(self, request, evidence, now):
        evidence = tuple(evidence)
        request_hash = digest(request)
        if request.command in self.completed:
            old_hash, result = self.completed[request.command]
            require(old_hash == request_hash, "Command equivocation")
            return result
        require(bool(request.command), "Missing command")
        unit = self.units[request.unit]
        route = self.route
        require(route.active and route.classification, "Current product classification")
        require(route.identity == request.route
                and route.generation == request.route_generation
                and digest(route) == request.route_snapshot
                and self.policy_generation == request.expected_policy_generation,
                "Current route and authority generations")
        require(route.title_basis == unit.title_basis and request.mode in route.modes,
                "Route does not cover this right")
        new = successor(unit, request)
        require(digest(new) == request.successor_snapshot,
                "Successor rights or obligations changed")
        rows = {}
        for item in evidence:
            require(item.identity not in self.revoked_evidence, "Revoked evidence")
            require(item.request_hash == request_hash
                    and item.route_generation == route.generation
                    and item.policy_generation == self.policy_generation
                    and item.valid_from <= now <= item.valid_until,
                    "Evidence binding, time, or current authority")
            require(item.effect == ("effective" if item.role == "legal-effect"
                                    else "admitted"), "Incomplete legal effect")
            key = (item.role, item.issuer, item.subject)
            require(key not in rows, "Duplicate evidence role")
            rows[key] = item
        require(set(rows) == required_evidence(unit, route, request),
                "Missing or unrelated authority, custody, consent, or continuation")
        # Everything before this point is a pure check. This write is the
        # single atomic transition assumed by the reference model.
        new = replace(new,
                      provenance=unit.provenance + ((request_hash, digest(unit)),),
                      legal_effects=unit.legal_effects +
                      (rows[("legal-effect", route.legal_authority, unit.identity)].identity,))
        new.validate()
        self.units[unit.identity] = new
        result = (request_hash, digest(new))
        self.completed[request.command] = (request_hash, result)
        self.history.append((request, tuple(evidence), now, result))
        return result
