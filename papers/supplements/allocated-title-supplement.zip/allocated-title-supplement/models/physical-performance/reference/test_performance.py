from copy import deepcopy
from fractions import Fraction as F
from pathlib import Path
import tempfile
import threading
import unittest

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from performance import *

AUTH = Ed25519PrivateKey.from_private_bytes(b"A" * 32)
KEYS = {name: Ed25519PrivateKey.from_private_bytes(bytes([i + 1]) * 32)
        for i, name in enumerate(sorted(ROLES))}
STORE_KEY = b"public-synthetic-physical-test-store-key"
NOW = 10


def contract(identity="sale", right="sale-right", **changes):
    c = {"id": identity, "performance_right": right, "authority_basis": "synthetic-sale-act",
        "terms": "synthetic-quantity-and-assay-terms", "debtor": "buyer", "beneficiary": "seller",
        "asset": "USD", "quantity": F(100), "unit": "kg", "total_price": F(1000),
        "delivery_point": "named-port", "quality_metric": "purity", "quality_basis": "dry-mass-fraction",
        "quality_min": F(95, 100), "quality_max": F(1), "epoch": 0,
        "keys": {role: public_hex(key.public_key()) for role, key in KEYS.items()}}
    c.update(changes)
    return c


def fact(c, role, identity, **fields):
    return signed(KEYS[role], {"id": identity, "role": role, "contract": digest(c),
        "epoch": c["epoch"], "from": 0, "until": 100, **fields})


def request(c, act="accept-1", start=F(0), stop=F(40), quantity=F(100), unit="kg",
            quality=F(99, 100), serial=0, event="cargo-1", accepted=True,
            title=True, delivery=True, point="named-port", factor=None):
    m = fact(c, "measurement", act + ":measure", provider="synthetic-surveyor",
        book="physical-book", event=event, quantity=quantity, unit=unit, point=point)
    occurrence = PhysicalBook.occurrence(m["payload"])
    physical = {k: m["payload"][k] for k in ("provider", "book", "event", "quantity", "unit", "point")}
    assay = fact(c, "assay", act + ":assay", occurrence=occurrence, metric=c["quality_metric"],
        basis=c["quality_basis"], value=quality, serial=serial)
    docs = {role: fact(c, role, act + ":" + role, occurrence=occurrence,
            measurement=digest(physical), start=start, stop=stop, accepted=value)
            for role, value in (("title", title), ("delivery", delivery))}
    conversion = None if factor is None else fact(c, "conversion", act + ":conversion",
        occurrence=occurrence, source=unit, target=c["unit"], basis=c["terms"], factor=factor)
    result = {"measurement": m, "assay": assay, "documents": docs, "conversion": conversion}
    result["acceptance"] = fact(c, "acceptance", act, occurrence=occurrence, start=start,
        stop=stop, evidence=digest(result), accepted=accepted)
    return result


def fixture(c=None):
    c = contract() if c is None else c
    b = PhysicalBook(public_hex(AUTH.public_key()))
    b.register(signed(AUTH, c))
    return b, c


class PerformanceTests(unittest.TestCase):
    def test_schedule_creates_no_earned_cash(self):
        b, c = fixture()
        self.assertEqual(b.ledger.dues(), ())
        self.assertEqual(b.balance(c["id"])["remaining_performance"], 100)

    def test_conforming_partial_cargo_resolves_actual_p08_due_once(self):
        b, c = fixture(); r = request(c)
        first = b.submit(c["id"], r, NOW)
        self.assertEqual(first["earned"], 400)
        self.assertEqual(b.submit(c["id"], r, NOW), first)
        self.assertEqual(len(b.ledger.dues()), 1)
        self.assertEqual(b.ledger.outstanding(first["due"]), 400)
        self.assertEqual(b.balance(c["id"])["remaining_performance"], 60)

    def test_new_assertion_or_contract_label_cannot_reuse_delivery_right(self):
        b, c = fixture(); b.submit(c["id"], request(c), NOW)
        alias = contract("other-label")
        b.register(signed(AUTH, alias))
        for spec in (c, alias):
            with self.assertRaisesRegex(Rejected, "PerformanceAlreadyAllocated"):
                b.submit(spec["id"], request(spec, act="new-proof"), NOW)
        self.assertEqual(len(b.ledger.dues()), 1)

    def test_separately_constituted_handling_fee_can_reuse_evidence(self):
        b, c = fixture(); b.submit(c["id"], request(c), NOW)
        fee = contract("handling", "handling-right", total_price=F(50), authority_basis="synthetic-service-act")
        b.register(signed(AUTH, fee))
        self.assertEqual(b.submit(fee["id"], request(fee), NOW)["earned"], 20)
        self.assertEqual(sum(d.amount for d in b.ledger.dues()), 420)

    def test_failed_assay_retains_dispute_and_subsequent_partial_cure(self):
        b, c = fixture()
        self.assertEqual(b.submit(c["id"], request(c, quality=F(9, 10)), NOW)["status"], "Disputed")
        self.assertEqual(b.ledger.dues(), ())
        self.assertEqual(b.balance(c["id"])["disputed_offered_quantity"], 40)
        b.submit(c["id"], request(c, "cure", stop=F(10), serial=1), NOW)
        self.assertEqual(b.balance(c["id"])["disputed_offered_quantity"], 30)
        self.assertEqual(b.balance(c["id"])["remaining_performance"], 90)

    def test_document_and_reserved_decisions_are_conjunctive(self):
        for kwargs in ({"title": False}, {"delivery": False}, {"accepted": False}, {"point": "other-port"}):
            b, c = fixture()
            self.assertEqual(b.submit(c["id"], request(c, **kwargs), NOW)["status"], "Disputed")
            self.assertEqual(b.ledger.dues(), ())

    def test_documents_from_another_interval_do_not_authorize_this_interval(self):
        b, c = fixture(); r = request(c)
        r["documents"]["title"] = request(c, stop=F(20))["documents"]["title"]
        a = r["acceptance"]["payload"]
        a["evidence"] = digest({k: v for k, v in r.items() if k != "acceptance"})
        r["acceptance"] = signed(KEYS["acceptance"], a)
        with self.assertRaisesRegex(Rejected, "DocumentInterval"):
            b.submit(c["id"], r, NOW)

    def test_exact_mass_conversion_does_not_round(self):
        b, c = fixture()
        result = b.submit(c["id"], request(c, stop=F(1, 25), quantity=F(1, 10), unit="tonne"), NOW)
        self.assertEqual(result["quantity"], 40)
        self.assertEqual(result["earned"], 400)

    def test_volume_energy_conversion_requires_bound_basis(self):
        c = contract(unit="GJ", quantity=F(1000))
        b, c = fixture(c)
        with self.assertRaisesRegex(Rejected, "EnvelopeShape"):
            b.submit(c["id"], request(c, stop=F(2), unit="m3"), NOW)
        result = b.submit(c["id"], request(c, "measured-energy", stop=F(2), unit="m3", factor=F(25)), NOW)
        self.assertEqual(result["quantity"], 50)
        self.assertEqual(result["earned"], 50)

    def test_report_relabel_cannot_change_physical_quantity(self):
        b, c = fixture(); b.submit(c["id"], request(c), NOW)
        with self.assertRaisesRegex(Rejected, "PhysicalMeasurementConflict"):
            b.submit(c["id"], request(c, "changed-report", start=F(40), stop=F(50), quantity=F(200)), NOW)

    def test_one_occurrence_conversion_cannot_change_between_partial_allocations(self):
        b, c = fixture(contract(unit="GJ", quantity=F(1000)))
        b.submit(c["id"], request(c, stop=F(2), unit="m3", factor=F(25)), NOW)
        with self.assertRaisesRegex(Rejected, "ConversionRevisionRequired"):
            b.submit(c["id"], request(c, "changed-conversion", start=F(2), stop=F(3), unit="m3", factor=F(100)), NOW)

    def test_old_assay_cannot_override_observed_adverse_assay(self):
        b, c = fixture()
        b.submit(c["id"], request(c, quality=F(9, 10), serial=2), NOW)
        with self.assertRaisesRegex(Rejected, "StaleAssay"):
            b.submit(c["id"], request(c, "old-good", serial=1), NOW)

    def test_invalid_document_does_not_commit_a_partial_assay_intake(self):
        b, c = fixture(); r = request(c, quality=F(9, 10), serial=2)
        r["documents"]["title"]["signature"] = "00" * 64
        a = r["acceptance"]["payload"]
        a["evidence"] = digest({k: v for k, v in r.items() if k != "acceptance"})
        r["acceptance"] = signed(KEYS["acceptance"], a)
        with self.assertRaisesRegex(Rejected, "Authentication"):
            b.submit(c["id"], r, NOW)
        self.assertEqual(b.assays, {})
        self.assertEqual(b.submit(c["id"], request(c, "valid-good", serial=1), NOW)["status"], "Earned")

    def test_false_exact_numbers_and_expired_evidence_reject(self):
        b, c = fixture()
        with self.assertRaisesRegex(Rejected, "ExactQuantityRequired"):
            b.submit(c["id"], request(c, stop=True), NOW)
        with self.assertRaisesRegex(Rejected, "EvidenceValidity"):
            b.submit(c["id"], request(c), 101)

    def test_boolean_document_coordinate_is_not_a_measured_number(self):
        b, c = fixture(); r = request(c, start=F(1), stop=F(2))
        for role in ("title", "delivery"):
            d = r["documents"][role]["payload"]
            d["start"] = True
            r["documents"][role] = signed(KEYS[role], d)
        a = r["acceptance"]["payload"]
        a["evidence"] = digest({k: v for k, v in r.items() if k != "acceptance"})
        r["acceptance"] = signed(KEYS["acceptance"], a)
        with self.assertRaisesRegex(Rejected, "ExactQuantityRequired"):
            b.submit(c["id"], r, NOW)
        self.assertEqual(b.ledger.dues(), ())

    def test_two_writers_cannot_allocate_same_performance(self):
        b, c = fixture(); answers = []
        def worker(i):
            try: answers.append(b.submit(c["id"], request(c, "parallel-" + str(i)), NOW)["status"])
            except Rejected as e: answers.append(str(e))
        threads = [threading.Thread(target=worker, args=(i,)) for i in range(2)]
        for t in threads: t.start()
        for t in threads: t.join()
        self.assertCountEqual(answers, ["Earned", "PerformanceAlreadyAllocated"])

    def test_paid_fee_quality_correction_preserves_cash_and_original_due(self):
        b, c = fixture(); accepted = b.submit(c["id"], request(c), NOW)
        cash = ent.OccurrenceKey("synthetic-bank", "RecipientCredit", "credit-400")
        b.ledger.record_credit(ent.CreditReport("report", cash,
            ent.Credit(cash, "seller", "USD", F(400), "booked"), "synthetic-bank", "sale-right"))
        b.ledger.allocate("payment", cash, accepted["due"], F(400), "synthetic-payment-rule")
        original = b.ledger.dues()[0]
        correction = fact(c, "correction", "assay-adjustment", economic=accepted["economic"],
            expected_head="resolution", target=F(100), basis="synthetic-resolved-quality-dispute")
        change = b.correct(accepted["economic"], correction, NOW)
        self.assertEqual(change.due.amount, 300)
        self.assertEqual((change.due.debtor, change.due.creditor), ("seller", "buyer"))
        self.assertIn(original, b.ledger.dues())
        self.assertEqual(b.ledger.outstanding(accepted["due"]), 0)
        self.assertEqual(len(b.ledger.allocation_rows()), 1)
        self.assertEqual(b.balance(c["id"])["payment_adjustment"], 300)
        self.assertEqual(b.correct(accepted["economic"], correction, NOW), change)

    def test_actual_durable_carriage_preserves_identity_and_actual_payment(self):
        b, c = fixture(); accepted = b.submit(c["id"], request(c), NOW)
        policy = {"key": public_hex(AUTH.public_key()), "epoch": 0, "name": "synthetic-carriage-authority"}
        work = Path(__file__).parent / "work"; work.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=work) as temp:
            path = Path(temp) / "earned.sqlite"
            store = b.close_to_carriage(path, STORE_KEY, AUTH, policy)
            p = program(c)
            rows = store.read(c["id"], p)
            self.assertEqual(rows["dues"], b.ledger.dues())
            self.assertEqual(cs.dp.ledger_load(rows["ledger"])._bindings, b.ledger._bindings)
            root = next(iter(store.snapshot()["carriage"]["roots"]))
            cash = ent.OccurrenceKey("synthetic-bank", "RecipientCredit", "actual-credit")
            report = ent.CreditReport("assertion", cash,
                ent.Credit(cash, "seller", "USD", F(400), "booked"), "synthetic-bank", "sale-right")
            receipt = store.apply(store.handle(c["id"], p), p, "record-credit", "ledger", "record_credit", report)
            self.assertEqual(receipt["outcome"]["status"], "Ok")
            store.allocate_alias("original", root, "payment", cash, F(400), "synthetic-payment-rule", expected_base=digest(store.snapshot()))
            self.assertEqual(dict(store.read(c["id"], p)["outstanding"])[accepted["due"]], 0)
            self.assertEqual(b.close_to_carriage(path, STORE_KEY, AUTH, policy).snapshot(), store.snapshot())
            with self.assertRaisesRegex(Rejected, "ClosedCohort"):
                b.submit(c["id"], request(c, "later", start=F(40), stop=F(50)), NOW)

    def test_two_partial_cargo_dues_keep_distinct_identity_at_durable_handover(self):
        b, c = fixture()
        first = b.submit(c["id"], request(c), NOW)
        second = b.submit(c["id"], request(c, "second", start=F(40), stop=F(70)), NOW)
        policy = {"key": public_hex(AUTH.public_key()), "epoch": 0, "name": "synthetic-carriage-authority"}
        work = Path(__file__).parent / "work"; work.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=work) as temp:
            store = b.close_to_carriage(Path(temp) / "earned.sqlite", STORE_KEY, AUTH, policy)
            current = store.read(c["id"], program(c))
            self.assertEqual(set(current["dues"]), set(b.ledger.dues()))
            self.assertEqual(dict(current["outstanding"]), {first["due"]: F(400), second["due"]: F(300)})


if __name__ == "__main__":
    unittest.main()
