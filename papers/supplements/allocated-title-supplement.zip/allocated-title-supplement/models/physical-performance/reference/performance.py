"""Exact physical-performance family using the actual P08 evaluator.

Configured keys represent admitted reference authorities. They do not establish
physical truth or legal authority. One lock serializes the finite family book.
Completed cohorts enter the actual P09/P08 durable carriage constructor.
"""
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import importlib.util
from pathlib import Path
import sys
import threading

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ROOT = Path(__file__).resolve().parents[3]
CARRIAGE = ROOT / "extensions/duty-carriage"
PINS = {
    "programmes.py": "130022ec9fb55db0ca68e1b681bfb80fce61f881b2fd4b3957a2305189e574d9",
    "carriage_store.py": "457840e8a24713a236ee4d80188d084c7f1ed0fb5f05de44da516dc4697b6065",
}


def load(name, filename):
    path = CARRIAGE / filename
    if hashlib.sha256(path.read_bytes()).hexdigest() != PINS[filename]:
        raise RuntimeError("Changed physical-family dependency: " + filename)
    if name in sys.modules:
        if Path(sys.modules[name].__file__).resolve() != path.resolve():
            raise RuntimeError("Conflicting physical-family module: " + name)
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


pr = load("programmes", "programmes.py")
cs = load("p14_actual_carriage", "carriage_store.py")
ev, ft, ent = pr.ev, pr.ft, pr.ent
digest, wire, signed, public_hex = cs.digest, cs.wire, cs.signed, cs.public_hex


class Rejected(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Rejected(reason)


def exact(value):
    require(type(value) in (int, F), "ExactQuantityRequired")
    return F(value)


UNITS = {
    "g": ("mass", F(1, 1000)), "kg": ("mass", F(1)),
    "tonne": ("mass", F(1000)), "m3": ("volume", F(1)),
    "MJ": ("energy", F(1)), "GJ": ("energy", F(1000)),
}
ROLES = {"measurement", "assay", "title", "delivery", "acceptance", "conversion", "correction"}


def verified(envelope, key):
    require(type(envelope) is dict and set(envelope) == {"payload", "signature"}, "EnvelopeShape")
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(key)).verify(
            bytes.fromhex(envelope["signature"]), wire(envelope["payload"]))
    except Exception as error:
        raise Rejected("Authentication") from error
    return deepcopy(envelope["payload"])


def named(value):
    require(type(value) is str and 0 < len(value) <= 256, "NamedIdentityRequired")
    return value


def program(contract):
    """One predeclared programme resolves only admitted acceptance observations."""
    schedule = ev.sched.Descriptor(129, 1, F=frozenset(range(1, 129)))
    money = ft.Theta(ft.Group.atom(contract["asset"]), F(1), ev.INSTANCE_DUE)
    context = "physical-performance:" + digest(contract)
    position = ev.Position(contract["performance_right"], contract["id"], "earned",
        F(1), contract["debtor"], contract["beneficiary"], contract["asset"],
        context, contract["authority_basis"], contract["terms"])
    claim = ev.Claim("earned", schedule, (ev.Case(schedule, ev.Oracle("accepted-value")),),
        money, (), (position,))
    return ev.Program((claim,), (ev.OracleContract("accepted-value", money, "performance"),), context)


def recipe(contract, height, amount, evidence):
    p = program(contract)
    theta = ft.Theta(ft.Group.atom(contract["asset"]), F(1), ev.INSTANCE_DUE)
    declaration = ft.Declaration(evidence, exact(amount), ev.at(theta, height),
        role="input", source="accepted-value", height=height, authority="performance")
    observation = ev.Observation(declaration, p.context_id)
    return pr.EvaluationRecipe(p, (("earned", height),), (observation,), height)


class PhysicalBook:
    """A family book keeps evidence reuse separate from performance allocation."""
    def __init__(self, admission_key):
        self.admission_key = admission_key
        self.lock = threading.RLock()
        self.contracts = {}
        self.rights = {}
        self.measurements = {}
        self.assays = {}
        self.conversions = {}
        self.allocations = {}
        self.acceptances = {}
        self.acts = {}
        self.disputes = {}
        self.corrections = {}
        self.ledger = ent.EntitlementLedger()
        self.closed = False

    def register(self, envelope):
        with self.lock:
            require(not self.closed, "ClosedCohort")
            c = verified(envelope, self.admission_key)
            fields = {"id", "performance_right", "authority_basis", "terms", "debtor",
                "beneficiary", "asset", "quantity", "unit", "total_price", "delivery_point",
                "quality_metric", "quality_basis", "quality_min", "quality_max", "keys", "epoch"}
            require(set(c) == fields, "ContractShape")
            for k in fields - {"quantity", "total_price", "quality_min", "quality_max", "keys", "epoch"}:
                named(c[k])
            require(c["unit"] in UNITS, "ContractUnit")
            for k in ("quantity", "total_price"):
                require(exact(c[k]) > 0, "PositiveContractQuantity")
            require(exact(c["quality_min"]) <= exact(c["quality_max"]), "QualityInterval")
            require(type(c["epoch"]) is int and c["epoch"] >= 0, "AuthorityEpoch")
            require(type(c["keys"]) is dict and set(c["keys"]) == ROLES, "AuthorityRoles")
            for key in c["keys"].values():
                require(type(key) is str and len(bytes.fromhex(key)) == 32, "PublicKey")
            prior = self.contracts.get(c["id"])
            require(prior is None or prior == c, "ContractIdentityConflict")
            terms = {k: c[k] for k in fields - {"id", "keys", "epoch"}}
            old = self.rights.get(c["performance_right"])
            require(old is None or old == terms, "ConstitutingRightConflict")
            self.rights[c["performance_right"]] = terms
            self.contracts[c["id"]] = c
            return digest(c)

    def fact(self, c, role, envelope, now):
        p = verified(envelope, c["keys"][role])
        require(p.get("role") == role and p.get("contract") == digest(c), "FactScope")
        require(type(p.get("epoch")) is int and p["epoch"] == c["epoch"], "CurrentAuthorityRequired")
        require(type(now) is int and type(p.get("from")) is int and type(p.get("until")) is int,
            "EvidenceClock")
        require(p["from"] <= now <= p["until"], "EvidenceValidity")
        named(p.get("id"))
        return p

    @staticmethod
    def occurrence(measurement):
        """Physical identity excludes assertions, contracts, and beneficiaries."""
        return digest((measurement["provider"], measurement["book"], measurement["event"]))

    def submit(self, contract_id, request, now):
        with self.lock:
            require(not self.closed, "ClosedCohort")
            c = self.contracts[contract_id]
            require(set(request) == {"measurement", "assay", "documents", "acceptance", "conversion"}, "RequestShape")
            a = self.fact(c, "acceptance", request["acceptance"], now)
            require(a["evidence"] == digest({k: v for k, v in request.items() if k != "acceptance"}), "EvidenceConjunction")
            act = (contract_id, a["id"])
            if act in self.acts:
                require(self.acts[act][0] == digest(request), "AcceptanceActConflict")
                return deepcopy(self.acts[act][1])
            m = self.fact(c, "measurement", request["measurement"], now)
            for k in ("provider", "book", "event", "point"):
                named(m[k])
            require(m["unit"] in UNITS and exact(m["quantity"]) > 0, "MeasuredQuantity")
            occurrence = self.occurrence(m)
            physical = {k: m[k] for k in ("provider", "book", "event", "quantity", "unit", "point")}
            old = self.measurements.get(occurrence)
            require(old is None or old == physical, "PhysicalMeasurementConflict")
            start, stop = exact(a["start"]), exact(a["stop"])
            require(0 <= start < stop <= m["quantity"], "PhysicalInterval")
            require(a["occurrence"] == occurrence, "AcceptanceOccurrence")
            quality = self.fact(c, "assay", request["assay"], now)
            require(quality["occurrence"] == occurrence, "AssayOccurrence")
            require(quality["metric"] == c["quality_metric"] and quality["basis"] == c["quality_basis"], "QualityBasis")
            q = exact(quality["value"])
            require(type(quality["serial"]) is int and quality["serial"] >= 0, "AssaySerial")
            assay_scope = (occurrence, c["keys"]["assay"], quality["metric"], quality["basis"])
            assay_content = {k: quality[k] for k in ("occurrence", "metric", "basis", "value", "serial")}
            latest = self.assays.get(assay_scope)
            if latest is not None:
                require(quality["serial"] >= latest["serial"], "StaleAssay")
                require(quality["serial"] != latest["serial"] or latest == assay_content, "AssayEquivocation")
            source_dim, source_scale = UNITS[m["unit"]]
            target_dim, target_scale = UNITS[c["unit"]]
            if source_dim == target_dim:
                require(request["conversion"] is None, "UnneededConversion")
                factor = source_scale / target_scale
            else:
                conversion = self.fact(c, "conversion", request["conversion"], now)
                require(conversion["occurrence"] == occurrence and conversion["source"] == m["unit"]
                    and conversion["target"] == c["unit"] and conversion["basis"] == c["terms"], "ConversionBasis")
                factor = exact(conversion["factor"])
                require(factor > 0, "PositiveConversion")
            quantity = (stop - start) * factor
            conversion_domain = (c["performance_right"], occurrence)
            require(self.conversions.get(conversion_domain, factor) == factor, "ConversionRevisionRequired")
            require(set(request["documents"]) == {"title", "delivery"}, "RequiredDocuments")
            reasons = []
            for role, envelope in request["documents"].items():
                doc = self.fact(c, role, envelope, now)
                require(doc["occurrence"] == occurrence and doc["measurement"] == digest(physical), "DocumentOccurrence")
                require(exact(doc["start"]) == start and exact(doc["stop"]) == stop, "DocumentInterval")
                require(type(doc["accepted"]) is bool, "DocumentDecision")
                if not doc["accepted"]:
                    reasons.append(role)
            if not c["quality_min"] <= q <= c["quality_max"]:
                reasons.append("quality")
            if m["point"] != c["delivery_point"]:
                reasons.append("delivery-point")
            require(type(a["accepted"]) is bool, "AcceptanceDecision")
            if not a["accepted"]:
                reasons.append("reserved-acceptance")
            domain = (c["performance_right"], occurrence)
            intervals = self.allocations.get(domain, [])
            require(not any(start < row["stop"] and row["start"] < stop for row in intervals), "PerformanceAlreadyAllocated")
            used = sum((x["quantity"] for rows in self.allocations.values() for x in rows
                        if x["right"] == c["performance_right"]), F(0))
            require(used + quantity <= c["quantity"], "ContractQuantityExceeded")
            economic = digest((c["performance_right"], occurrence, start, stop))
            self.assays[assay_scope] = assay_content
            self.measurements[occurrence] = physical
            self.conversions[conversion_domain] = factor
            if reasons:
                result = {"status": "Disputed", "economic": economic, "quantity": quantity,
                    "unit": c["unit"], "reasons": tuple(reasons), "earned": F(0)}
                self.disputes[economic] = {"request": deepcopy(request), "result": result,
                    "domain": domain, "start": start, "stop": stop, "factor": factor}
            else:
                height = 1 + sum(x["contract"] == contract_id for x in self.acceptances.values())
                require(height <= 128, "FiniteAcceptanceCohort")
                amount = c["total_price"] * quantity / c["quantity"]
                r = recipe(c, height, amount, "acceptance:" + digest(request))
                evaluated = pr.evaluate(r)
                require(len(evaluated.ledger._bindings) == 1 and len(evaluated.ledger.dues()) == 1, "OneEarnedEntitlement")
                binding = next(iter(evaluated.ledger._bindings.values()))
                self.ledger.resolve(binding)
                due = next(iter(evaluated.ledger.dues()))
                result = {"status": "Earned", "economic": economic, "quantity": quantity,
                    "unit": c["unit"], "earned": amount, "due": due.origin}
                row = {"right": c["performance_right"], "start": start, "stop": stop,
                    "quantity": quantity, "economic": economic}
                self.allocations.setdefault(domain, []).append(row)
                self.acceptances[economic] = {"request": deepcopy(request), "result": result,
                    "contract": contract_id, "height": height, "recipe": r,
                    "binding": binding, "target": amount}
                self.disputes.pop(economic, None)
            self.acts[act] = (digest(request), deepcopy(result))
            return deepcopy(result)

    def correct(self, economic, envelope, now):
        """A correction creates a directed due and retains original performance."""
        with self.lock:
            require(not self.closed, "ClosedCohort")
            row = self.acceptances[economic]
            c = self.contracts[row["contract"]]
            p = self.fact(c, "correction", envelope, now)
            require(p["economic"] == economic, "CorrectionEconomicIdentity")
            act = p["id"]
            if act in self.corrections:
                require(self.corrections[act][0] == digest(envelope), "CorrectionActConflict")
                return self.corrections[act][1]
            target = exact(p["target"])
            require(0 <= target <= row["result"]["earned"], "CorrectionTarget")
            named(p["basis"])
            change = ent.TargetCorrection(act, row["binding"].key, p["expected_head"], target, digest(envelope))
            result = self.ledger.correct_target(change)
            row["target"] = target
            self.corrections[act] = (digest(envelope), result)
            return result

    def balance(self, contract_id):
        with self.lock:
            c = self.contracts[contract_id]
            accepted = sum((x["result"]["quantity"] for x in self.acceptances.values()
                            if self.contracts[x["contract"]]["performance_right"] == c["performance_right"]), F(0))
            disputed = F(0)
            domains = {x["domain"] for x in self.disputes.values() if x["domain"][0] == c["performance_right"]}
            for domain in domains:
                rows = [x for x in self.disputes.values() if x["domain"] == domain]
                paid = self.allocations.get(domain, [])
                points = sorted({p for row in rows + paid for p in (row["start"], row["stop"])})
                for a, b in zip(points, points[1:]):
                    covering = [x for x in rows if x["start"] <= a and b <= x["stop"]]
                    if covering and not any(x["start"] <= a and b <= x["stop"] for x in paid):
                        require(all(x["factor"] == covering[0]["factor"] for x in covering), "DisputedConversionConflict")
                        disputed += (b - a) * covering[0]["factor"]
            adjustment = sum((x["result"]["earned"] - x["target"] for x in self.acceptances.values()
                if self.contracts[x["contract"]]["performance_right"] == c["performance_right"]), F(0))
            return {"accepted_quantity": accepted, "remaining_performance": c["quantity"] - accepted,
                "unit": c["unit"], "disputed_offered_quantity": disputed, "payment_adjustment": adjustment,
                "projected_unperformed_value": c["total_price"] * (c["quantity"] - accepted) / c["quantity"]}

    def close_to_carriage(self, path, store_key, authority, policy, quantum=F(1)):
        """Materialize an unpaid finite cohort through the actual durable APIs.

        The physical source is fenced before handover. The destination path is
        exclusive. Recovery retries the same path and exact durable commands.
        Paid or corrected source cohorts require an additional migration rule.
        """
        with self.lock:
            require(self.acceptances and not self.ledger._allocations and not self.corrections, "UnpaidUncorrectedHandover")
            for row in self.acceptances.values():
                cs.units(row["result"]["earned"], quantum)
            handover = digest(tuple((key, row["binding"]) for key, row in sorted(self.acceptances.items())))
            destination = (str(Path(path).resolve()), bytes(store_key), digest(policy), quantum)
            require(not hasattr(self, "destination") or self.destination == destination, "ExclusiveHandoverDestination")
            self.destination = destination
            self.closed = True
            # Check an already adopted destination without changing it.
            try:
                adopted = cs.CarriageStore(path, store_key)
                require(adopted.snapshot()["carriage"]["policy"] == policy, "HandoverPolicyConflict")
                require(getattr(self, "handover", None) == handover, "AdoptionReceiptRequired")
                return adopted
            except cs.ERROR as error:
                if str(error) not in ("ExistingAdoptedStoreRequired", "CarriageSchemaOrRevisionMismatch"):
                    raise
            store = cs.dp.DurableEvaluator(path, store_key)
            roots = []
            for economic, row in sorted(self.acceptances.items(), key=lambda item: (item[1]["contract"], item[1]["height"])):
                r = row["recipe"]
                instance = row["contract"]
                store.create(instance, r.program)
                def apply(command, method, *args, **kwargs):
                    result = store.apply(store.handle(instance, r.program), r.program,
                        economic + ":" + command, "evaluator", method, *args, **kwargs)
                    require(result["outcome"]["status"] == "Ok", "DurableEvaluationRejected")
                apply("request", "request", "earned", row["height"], context_id=r.context_id)
                apply("offer", "offer", r.observations[0], context_id=r.context_id)
                apply("run", "run", now=row["height"], context_id=r.context_id)
                actual = cs.dp.ledger_load(store.read(instance, r.program)["ledger"])
                require(actual._bindings[row["binding"].key] == row["binding"], "ExactEarnedBindingRequired")
                roots.append(cs.root_spec(instance, row["result"]["due"],
                    ["physical-performance", self.contracts[instance]["performance_right"], economic],
                    quantum=quantum, unit=self.contracts[instance]["asset"]))
            with store._connection() as db:
                db.execute("BEGIN")
                prior = store._load(db)
            envelope = signed(authority, {"kind": "Adopt", "relation": cs.RELATION,
                "authority_epoch": policy["epoch"], "authority_policy": digest(policy),
                "base": digest(prior), "roots": roots})
            self.handover = handover
            return cs.CarriageStore.adopt(path, store_key, envelope, policy)
