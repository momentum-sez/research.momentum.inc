"""Evaluate admitted financial DAGs with bounded, resumable work.

Input authentication is a caller premise. Continuation authentication uses HMAC.
The imported entitlement ledger provides process-local atomic transitions.
"""

from __future__ import annotations

import dataclasses as dc
from fractions import Fraction as F
import hashlib
import hmac
import json
import secrets
from functools import wraps
from pathlib import Path
import sys
from types import MappingProxyType
from collections import deque
from threading import RLock

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent.parent / "reference"
for directory in ("types", "numeric", "schedules", "entitlements"):
    sys.path.insert(0, str(BASE / directory))
import financial_types as ft
import exact_numeric as num
import admission as sched
import readiness
import entitlement_model as ent

Const = ft.Leaf
Oracle = sched.Oracle
Ref = ft.Ref
Window = sched.Window
LinComb, Mul, Ind = ft.LinComb, ft.Mul, ft.Ind
Cap, Floor, IfElse = ft.Cap, ft.Floor, ft.IfElse
Rescale, Convert = ft.Rescale, ft.Convert
INSTANCE_DUE = ft.Group.atom("due:$height")


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


@dc.dataclass(frozen=True)
class Envelope:
    max_bits: int = 256
    max_steps: int = 1_000_000
    max_number_bits: int = 100_000_000
    max_nodes: int = 20_000
    max_arguments: int = 100_000
    max_instances: int = 10_000
    max_window: int = 10_000
    max_input_bytes: int = 4_000_000
    max_schedule_horizon: int = 100_000


class Meter(num.Budget):
    """Count primitive work and conservative integer allocation charges."""

    def __init__(self, envelope):
        require(type(envelope) is Envelope, "InvalidEnvelope")
        require(all(type(v) is int and v > 0 for v in dc.astuple(envelope)), "InvalidEnvelope")
        super().__init__({"max_bits": envelope.max_bits, "max_steps": envelope.max_steps})
        self.envelope = envelope
        self.number_bits = 0

    def allocate(self, bits):
        if bits > self.envelope.max_number_bits - self.number_bits:
            raise num.NumericError("BudgetExceeded")
        self.number_bits += bits

    def integer(self, text, positive=False):
        self.allocate(self.max_bits)
        return super().integer(text, positive)

    def add(self, a, b):
        self.allocate(self.max_bits)
        return super().add(a, b)

    def mul(self, a, b):
        self.allocate(self.max_bits)
        return super().mul(a, b)

    def gcd(self, a, b):
        a, b = abs(a), abs(b)
        while b:
            self.charge()
            self.allocate(2 * self.max_bits)
            a, b = b, a % b
        return a

    def extend(self, envelope):
        replacement = Meter(envelope)
        require(all(b >= a for a, b in zip(dc.astuple(self.envelope), dc.astuple(envelope))),
                "EnvelopeMayOnlyIncrease")
        replacement.steps, replacement.number_bits = self.steps, self.number_bits
        return replacement


@dc.dataclass(frozen=True)
class Case:
    schedule: sched.Descriptor
    expression: object


@dc.dataclass(frozen=True)
class Position:
    issuance: str
    lot: str
    leg: str
    quantity: F
    obligor: str
    beneficiary: str
    asset: str
    context: str
    position_evidence: str
    terms_evidence: str
    payment_context: ft.Group = INSTANCE_DUE


@dc.dataclass(frozen=True)
class Claim:
    name: str
    schedule: sched.Descriptor
    cases: tuple[Case, ...]
    output: ft.Theta
    declarations: tuple[ft.Declaration, ...] = ()
    positions: tuple[Position, ...] = ()
    authority: str = "runtime"
    scope: str = "claims"
    purpose: str = "resolution"
    deadline_delay: int = 100
    deadline_action: str = "retain-and-recover"
    rate_references: tuple[tuple[str, sched.Ref], ...] = ()


@dc.dataclass(frozen=True)
class OracleContract:
    source: str
    theta: ft.Theta
    issuer: str
    conversion_rate: bool = False


@dc.dataclass(frozen=True)
class Observation:
    """An exact declaration, or its certified interval with an upper bound."""

    declaration: ft.Declaration
    context_id: str
    upper: F | None = None


@dc.dataclass(frozen=True)
class Interval:
    lower: F
    upper: F


@dc.dataclass(frozen=True)
class HistoricalRead:
    claim: str
    height: int
    resolution: str
    theta: ft.Theta


@dc.dataclass(frozen=True)
class Value:
    number: Interval | bool | None
    theta: ft.Theta
    sort: str
    evidence: frozenset = frozenset()
    witnesses: frozenset = frozenset()
    history: frozenset = frozenset()


@dc.dataclass(frozen=True)
class Instruction:
    operator: str
    parameters: tuple
    arguments: tuple[int, ...]


@dc.dataclass(frozen=True)
class CompiledCase:
    schedule: sched.Descriptor
    instructions: tuple[Instruction, ...]


@dc.dataclass(frozen=True)
class CompiledClaim:
    name: str
    schedule: sched.Descriptor
    cases: tuple[CompiledCase, ...]
    output: ft.Theta
    declarations: tuple
    positions: tuple
    authority: str
    scope: str
    purpose: str
    deadline_delay: int
    deadline_action: str
    rate_references: tuple


TAGS = {}
for module in (ft, sched, ent):
    for name in dir(module):
        item = getattr(module, name)
        if isinstance(item, type) and dc.is_dataclass(item):
            TAGS[module.__name__ + "." + name] = item
for name, item in list(globals().items()):
    if isinstance(item, type) and dc.is_dataclass(item):
        TAGS["evaluator." + name] = item


def encode(value):
    if type(value) is F:
        return {"fraction": [str(value.numerator), str(value.denominator)]}
    if dc.is_dataclass(value):
        tag = next(k for k, v in TAGS.items() if v is type(value))
        return {"record": tag, "fields": {f.name: encode(getattr(value, f.name)) for f in dc.fields(value)}}
    if type(value) in (tuple, frozenset):
        items = [encode(x) for x in value]
        if type(value) is frozenset:
            items.sort(key=lambda x: json.dumps(x, sort_keys=True))
        return {"tuple" if type(value) is tuple else "set": items}
    if type(value) is dict:
        return {"map": [[encode(k), encode(v)] for k, v in sorted(value.items(), key=lambda x: repr(x[0]))]}
    require(value is None or type(value) in (str, int, bool), "UnsupportedWireValue")
    return value


def decode(value):
    if type(value) is not dict:
        return value
    if "fraction" in value:
        n, d = value["fraction"]
        return F(int(n), int(d))
    if "record" in value:
        require(value["record"] in TAGS, "UnknownContinuationRecord")
        return TAGS[value["record"]](**{k: decode(v) for k, v in value["fields"].items()})
    if "tuple" in value:
        return tuple(decode(x) for x in value["tuple"])
    if "set" in value:
        return frozenset(decode(x) for x in value["set"])
    if "map" in value:
        return {decode(k): decode(v) for k, v in value["map"]}
    raise Invalid("UnknownContinuationWireValue")


def wire(value):
    return json.dumps(encode(value), sort_keys=True, separators=(",", ":")).encode()


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def at(theta, height):
    """Instantiate the declared current-maturity context parameter."""
    return ft.Theta(theta.unit, theta.scale,
                    ft.Group(tuple((f"due:{height}" if n == "due:$height" else n, p)
                                   for n, p in theta.context.powers)))


class ContinuationJournal:
    """Retain one current revision for each local execution lineage."""

    def __init__(self):
        self.heads = {}
        self.lock = RLock()


def current_action(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with self.journal.lock, self.ledger._lock:
            require(self.journal.heads.get(self.lineage) == self.revision, "StaleContinuationHandle")
            try:
                return method(self, *args, **kwargs)
            finally:
                # Failed attempts also consume work and cannot restore older counters.
                self.revision += 1
                self.journal.heads[self.lineage] = self.revision
    return guarded


def current_snapshot(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with self.journal.lock, self.ledger._lock:
            require(self.journal.heads.get(self.lineage) == self.revision, "StaleContinuationHandle")
            return method(self, *args, **kwargs)
    return guarded


def children(expression):
    t = type(expression)
    if t in (Const, Oracle, Ref, Window):
        return ()
    if t is LinComb:
        require(type(expression.terms) is tuple and bool(expression.terms), "EmptyOrMutableLinComb")
        require(all(type(p) is tuple and len(p) == 2 for p in expression.terms), "InvalidLinCombPair")
        return tuple(x for pair in expression.terms for x in pair)
    if t in (Mul, Ind):
        return expression.left, expression.right
    if t in (Cap, Floor):
        return expression.value, expression.bound
    if t is IfElse:
        return expression.condition, expression.positive, expression.negative
    if t in (Rescale, Convert):
        return (expression.value,)
    raise Invalid("UnknownPayoffConstructor")


def lower(expression, envelope):
    """Lower the complete admitted constructor set to one SSA sequence."""
    order, states, indices = [], {}, {}
    stack = [(expression, False)]
    edges = 0
    while stack:
        node, finish = stack.pop()
        identity = id(node)
        if finish:
            args = tuple(indices[id(c)] for c in children(node))
            t = type(node)
            if t is Const: op, params = "Const", (node.name,)
            elif t is Oracle: op, params = "Oracle", (node.source, node.tau)
            elif t is Ref: op, params = "Ref", (node.name, node.offset, node.mode)
            elif t is Window: op, params = "Window", (node.target, node.W, node.reduction)
            elif t is Ind: op, params = "Ind", (node.relation,)
            elif t is Rescale: op, params = "Rescale", (node.target_scale,)
            elif t is Convert: op, params = "Convert", (node.rate_name, node.target, node.witness_name, node.direction)
            else: op, params = t.__name__, ()
            indices[identity] = len(order)
            order.append(Instruction(op, params, args))
            states[identity] = 2
            continue
        if states.get(identity) == 2:
            continue
        require(states.get(identity) != 1, "CyclicPayoffDAG")
        require(len(states) < envelope.max_nodes, "ProgramNodeBudgetExceeded")
        states[identity] = 1
        cs = children(node)
        edges += len(cs)
        require(edges <= envelope.max_arguments, "ProgramArgumentBudgetExceeded")
        stack.append((node, True))
        stack.extend((c, False) for c in reversed(cs))
    return tuple(order)


class Program:
    def __init__(self, claims, oracles, context_id, envelope=Envelope()):
        self.context_id = context_id
        require(type(context_id) is str and bool(context_id), "MissingContext")
        require(type(claims) is tuple and type(oracles) is tuple, "MutableProgramInput")
        Meter(envelope)
        compiled, obligations = [], []
        total_nodes = total_args = 0
        for c in claims:
            require(type(c) is Claim and type(c.cases) is tuple, "InvalidClaim")
            require(type(c.declarations) is tuple and type(c.positions) is tuple, "MutableClaimInput")
            require(type(c.rate_references) is tuple, "MutableRateReferences")
            rates = dict(c.rate_references)
            require(len(rates) == len(c.rate_references) and all(type(v) is sched.Ref for v in rates.values()),
                    "InvalidRateReferences")
            require(len({d.name for d in c.declarations}) == len(c.declarations), "DuplicateLiteralDeclaration")
            for p in c.positions:
                require(type(p) is Position and type(p.quantity) in (int, F), "InvalidPosition")
                require(all(type(s) is str and s for s in (p.issuance, p.lot, p.leg, p.obligor, p.beneficiary,
                        p.asset, p.context, p.position_evidence, p.terms_evidence)), "MissingPositionBinding")
            for d in c.declarations:
                require(d.role != "resolved_claim" or d.name in rates, "ResolvedRateNeedsReferenceBinding")
            ft.Use(1, c.authority, c.scope, c.purpose)
            require(type(c.deadline_delay) is int and c.deadline_delay >= 0 and bool(c.deadline_action), "InvalidDeadline")
            cases, projected = [], []
            for case in c.cases:
                instructions = lower(case.expression, envelope)
                total_nodes += len(instructions)
                total_args += sum(len(i.arguments) for i in instructions)
                require(total_nodes <= envelope.max_nodes and total_args <= envelope.max_arguments, "ProgramGraphBudgetExceeded")
                leaves = []
                for i in instructions:
                    p = i.parameters
                    if i.operator == "Oracle": leaves.append(sched.Oracle(*p))
                    elif i.operator == "Ref": leaves.append(sched.Ref(p[0], p[1]))
                    elif i.operator == "Window": leaves.append(sched.Window(*p))
                    elif i.operator == "Convert":
                        if p[0] in rates: leaves.append(rates[p[0]])
                        elif p[0] not in {d.name for d in c.declarations}: leaves.append(sched.Oracle(p[0], 0))
                cases.append(CompiledCase(case.schedule, instructions))
                projected.append(sched.Case(case.schedule, tuple(leaves)))
            fields = {f.name: getattr(c, f.name) for f in dc.fields(c) if f.name != "cases"}
            compiled.append(CompiledClaim(cases=tuple(cases), **fields))
            obligations.append(sched.Claim(c.name, c.schedule, tuple(projected)))
        self.claims = MappingProxyType({c.name: c for c in compiled})
        self.oracles = MappingProxyType({o.source: o for o in oracles})
        require(len(self.claims) == len(claims) and len(self.oracles) == len(oracles), "DuplicateDeclaration")
        require(all(type(o) is OracleContract for o in oracles), "InvalidOracleContract")
        # Bound numeric and textual metadata before canonical serialization.
        stack = [tuple(compiled), oracles, context_id]
        input_charge = 0
        while stack:
            value = stack.pop()
            if dc.is_dataclass(value):
                stack.extend(getattr(value, f.name) for f in dc.fields(value))
                input_charge += 64
            elif type(value) in (tuple, frozenset):
                stack.extend(value)
                input_charge += 8 * len(value)
            elif type(value) in (int, F):
                f = F(value)
                if max(abs(f.numerator).bit_length(), f.denominator.bit_length()) > envelope.max_bits:
                    raise num.NumericError("BudgetExceeded")
                input_charge += 2 * envelope.max_bits
            elif type(value) is str:
                input_charge += 4 * len(value)
            else:
                require(value is None or type(value) is bool, "InvalidProgramMetadata")
            require(input_charge <= envelope.max_input_bytes * 8, "ProgramInputBudgetExceeded")
        self.certificate = sched.admit(tuple(obligations), sched.Budget(
            max_integer_bits=envelope.max_bits, max_input_bits=envelope.max_input_bytes * 8,
            max_input_items=envelope.max_nodes + envelope.max_arguments,
            max_horizon=envelope.max_schedule_horizon, max_checks=envelope.max_steps))
        self.semantics = {p.stem: hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in (Path(__file__), BASE / "types/financial_types.py", BASE / "numeric/exact_numeric.py",
                                    BASE / "schedules/admission.py", BASE / "schedules/readiness.py",
                                    BASE / "entitlements/entitlement_model.py")}
        self.identity = digest((tuple(compiled), oracles, context_id, self.semantics))
        self.encoded_size = len(wire((tuple(compiled), oracles, context_id, self.semantics)))
        require(self.encoded_size <= envelope.max_input_bytes, "ProgramInputBudgetExceeded")
        self.node_count, self.argument_count = total_nodes, total_args


class Evaluator:
    def __init__(self, program, ledger=None, envelope=Envelope(), journal=None):
        self.program = program
        self.ledger = ent.EntitlementLedger() if ledger is None else ledger
        self.meter = Meter(envelope)
        if program.certificate.membership_bound > envelope.max_steps:
            raise num.NumericError("BudgetExceeded")
        require(program.encoded_size <= envelope.max_input_bytes, "ProgramInputBudgetExceeded")
        self.input_bytes = program.encoded_size
        self.observations, self.witnesses = {}, {}
        self.tasks, self.resolutions = {}, {}
        self.requests = set()
        self.execution_counts = {}
        self.generation = 0
        self.last_run = None
        self.structural_nodes = self.structural_args = 0
        self.unexpanded = {}
        # The finite schedule admission scan contributes to cumulative work.
        self.meter.steps = program.certificate.membership_bound
        self.journal = ContinuationJournal() if journal is None else journal
        require(type(self.journal) is ContinuationJournal, "InvalidContinuationJournal")
        self.lineage, self.revision = secrets.token_hex(16), 0
        self.journal.heads[self.lineage] = self.revision

    def context(self, supplied):
        require(supplied == self.program.context_id, "StaleContext")

    def use(self, name, height):
        c = self.program.claims[name]
        return ft.Use(height, c.authority, c.scope, c.purpose)

    @current_action
    def offer(self, observation, *, context_id):
        self.context(context_id)
        require(type(observation) is Observation and observation.context_id == context_id, "ObservationContextMismatch")
        d = observation.declaration
        require(type(d) is ft.Declaration, "InvalidObservationDeclaration")
        require(type(d.height) is int and d.height.bit_length() <= self.meter.max_bits, "ObservationHeightBudgetExceeded")
        require(d.source in self.program.oracles, "UndeclaredOracle")
        contract = self.program.oracles[d.source]
        require(d.role in ("input", "observed_rate") and d.sort == "Num", "InvalidOracleRole")
        require(d.authority == contract.issuer and d.theta == at(contract.theta, d.height), "OracleContractMismatch")
        require(d.conversion_rate == contract.conversion_rate, "OracleRateRoleMismatch")
        hi = d.value if observation.upper is None else observation.upper
        require(type(hi) in (int, F) and d.value <= hi, "InvalidCertifiedInterval")
        require(max(abs(d.value.numerator).bit_length(), d.value.denominator.bit_length(),
                    abs(F(hi).numerator).bit_length(), F(hi).denominator.bit_length()) <= self.meter.max_bits,
                "ObservationNumberBudgetExceeded")
        key = (d.source, d.height)
        prior = self.observations.get(key)
        if prior == observation:
            return
        encoded_size = len(wire(observation))
        require(encoded_size <= self.meter.envelope.max_input_bytes - self.input_bytes,
                "ObservationInputBudgetExceeded")
        if prior is not None:
            low0 = prior.declaration.value
            high0 = low0 if prior.upper is None else F(prior.upper)
            require(low0 <= d.value <= hi <= high0, "EvidenceMustRefine")
            require(low0 != high0, "ResolvedObservationImmutable")
            require(d.name != prior.declaration.name, "RevisionNeedsDistinctEvidence")
        self.observations[key] = observation
        self.input_bytes += encoded_size
        self.generation += 1
        # Pending caches can depend on the changed interval through any ancestor.
        # Resolved records remain immutable because their outputs were certified exact.
        if prior is not None:
            for task in self.tasks.values():
                task["values"].clear()

    @current_action
    def offer_witness(self, name, height, witness, *, context_id):
        self.context(context_id)
        require(type(witness) is ft.Witness and witness.use == self.use(name, height), "WitnessUseMismatch")
        key = (name, height, witness.name)
        require(key not in self.witnesses or self.witnesses[key] == witness, "WitnessIdentityConflict")
        if key not in self.witnesses:
            size = len(wire(witness))
            require(size <= self.meter.envelope.max_input_bytes - self.input_bytes, "WitnessInputBudgetExceeded")
            self.witnesses[key] = witness
            self.input_bytes += size
            self.generation += 1

    @current_action
    def request(self, name, height, *, context_id):
        self.context(context_id)
        require(type(height) is int and height >= 1 and name in self.program.claims, "InvalidInstance")
        require(height.bit_length() <= self.meter.max_bits, "HeightBudgetExceeded")
        require(self.program.claims[name].schedule.contains(height), "UnscheduledInstance")
        self.requests.add((name, height))
        self.generation += 1

    def q(self, value):
        require(type(value) in (int, F), "InexactNumber")
        value = F(value)
        if max(abs(value.numerator).bit_length(), value.denominator.bit_length()) > self.meter.max_bits:
            raise num.NumericError("BudgetExceeded")
        return num.Rational.parse({"n": str(value.numerator), "d": str(value.denominator)}, self.meter)

    def scalar(self, value):
        return Interval(value, value)

    def group(self, a, b, divide=False):
        """Bound intermediate dimension and context powers as numeric metadata."""
        powers = dict(a.powers)
        for name, power in b.powers:
            powers[name] = self.meter.add(powers.get(name, 0), -power if divide else power)
        return ft.Group(tuple(powers.items()))

    def numeric(self, value):
        if value.sort == "Bool":
            require(value.number is not None, "AmbiguousBoolean")
            return dc.replace(value, number=self.scalar(F(int(value.number))), theta=ft.NEUTRAL, sort="Num")
        return value

    def combined(self, number, theta, sort, values):
        # Charge retained records before allocating their unions.
        self.meter.allocate(sum(len(v.evidence) + len(v.witnesses) + len(v.history) for v in values) * 256)
        return Value(number, theta, sort,
                     frozenset(e for v in values for e in v.evidence),
                     frozenset(e for v in values for e in v.witnesses),
                     frozenset(e for v in values for e in v.history))

    def add(self, a, b):
        return Interval(self.q(a.lower).add(self.q(b.lower)).value,
                        self.q(a.upper).add(self.q(b.upper)).value)

    def multiply(self, a, b):
        products = [self.q(x).mul(self.q(y)).value for x in (a.lower, a.upper) for y in (b.lower, b.upper)]
        lo = hi = products[0]
        for x in products[1:]:
            if self.q(x).compare(self.q(lo), "<"): lo = x
            if self.q(x).compare(self.q(hi), ">"): hi = x
        return Interval(lo, hi)

    def compare(self, a, b, relation):
        outcome = num.interval_outcome(relation,
                   [self.q(a.lower).wire(), self.q(a.upper).wire()],
                   [self.q(b.lower).wire(), self.q(b.upper).wire()], self.meter)
        return True if outcome == "CertifiedTrue" else False if outcome == "CertifiedFalse" else None

    def pick(self, a, b, maximum):
        relation = ">" if maximum else "<"
        return Interval(a.lower if self.q(a.lower).compare(self.q(b.lower), relation) else b.lower,
                        a.upper if self.q(a.upper).compare(self.q(b.upper), relation) else b.upper)

    def selected(self, instruction, height, claim):
        op, p = instruction.operator, instruction.parameters
        if op == "Convert":
            ref = dict(claim.rate_references).get(p[0])
            return () if ref is None else ((ref.target, height - ref.tau),)
        if op == "Ref":
            return ((p[0], height - p[1]),)
        if op != "Window":
            return ()
        target, width, _ = p
        if width > self.meter.envelope.max_window:
            raise num.NumericError("BudgetExceeded")
        result = []
        for h in range(height - width, height):
            self.meter.charge()
            if self.program.claims[target].schedule.contains(h):
                result.append((target, h))
        require(bool(result), "EmptyHistoricalWindow")
        return tuple(result)

    def typecheck(self, claim, instructions, height):
        """Check every edge and both branches before admitting an instance."""
        types = []
        declarations = {d.name: dc.replace(d, theta=at(d.theta, height)) for d in claim.declarations}
        checker = ft.Checker(ft.Manifest(declarations, {}), self.use(claim.name, height))
        for ins in instructions:
            self.meter.charge()
            op, p = ins.operator, ins.parameters
            args = [types[i] for i in ins.arguments]
            numeric = [(ft.NEUTRAL, "Num") if sort == "Bool" else (theta, sort) for theta, sort in args]
            sort = "Num"
            if op == "Const":
                d = checker.declaration(p[0])
                require(d.role in ("literal", "contractual_coefficient") and not d.conversion_rate,
                        "ConstRequiresIssuanceDeclaration")
                theta, sort = d.theta, d.sort
            elif op == "Oracle":
                require(p[0] in self.program.oracles, "UndeclaredOracle")
                contract = self.program.oracles[p[0]]
                require(not contract.conversion_rate, "RateRequiresConvert")
                theta = at(contract.theta, height - p[1])
            elif op in ("Ref", "Window"):
                target = self.program.claims[p[0]]
                theta = at(target.output, height - p[1])
                if op == "Ref": require(p[2] in ("sample", "amount"), "InvalidReferenceMode")
                if op == "Window" or p[2] == "sample": theta = ft.Theta(theta.unit, theta.scale, ft.Group())
            elif op == "LinComb":
                theta = numeric[1][0]
                require(all(t == ft.NEUTRAL for t, _ in numeric[::2]), "DimensionedLinCombCoefficient")
                require(all(t == theta for t, _ in numeric[1::2]), "LinCombTypeMismatch")
            elif op == "Mul":
                a, b = [t for t, _ in numeric]
                scale = self.q(a.scale).mul(self.q(b.scale)).value
                theta = ft.Theta(self.group(a.unit, b.unit), scale, self.group(a.context, b.context))
            elif op in ("Cap", "Floor", "Ind"):
                require(numeric[0][0] == numeric[1][0], "ComparisonOrBoundTypeMismatch")
                theta = numeric[0][0]
                if op == "Ind":
                    require(p[0] in ("<", "<=", "=", ">=", ">"), "InvalidRelation")
                    theta, sort = ft.NEUTRAL, "Bool"
            elif op == "IfElse":
                require(args[0][1] == "Bool" and numeric[1][0] == numeric[2][0], "ConditionalTypeMismatch")
                theta = numeric[1][0]
            elif op == "Rescale":
                a = numeric[0][0]
                theta = ft.Theta(a.unit, self.q(p[0]).value, a.context)
            elif op == "Convert":
                theta = at(p[1], height)
                a = numeric[0][0]
                reference = dict(claim.rate_references).get(p[0])
                if reference is not None:
                    rate = at(self.program.claims[reference.target].output, height - reference.tau)
                elif p[0] in declarations:
                    declaration = checker.declaration(p[0])
                    require(declaration.conversion_rate, "ConvertRequiresObservedRate")
                    rate = declaration.theta
                else:
                    require(p[0] in self.program.oracles, "UndeclaredRate")
                    contract = self.program.oracles[p[0]]
                    require(contract.conversion_rate, "ConvertRequiresObservedRate")
                    rate = at(contract.theta, height)
                require(p[3] == "source_to_target", "WitnessDirectionMismatch")
                require(rate.unit == self.group(theta.unit, a.unit, True) and
                        rate.context == self.group(theta.context, a.context, True),
                        "RateDimensionOrContextMismatch")
            else:
                raise Invalid("UnknownInstruction")
            self.q(theta.scale)
            types.append((theta, sort))
        theta, sort = types[-1]
        require((ft.NEUTRAL if sort == "Bool" else theta) == at(claim.output, height), "ClaimRootTypeMismatch")
        return tuple(types)

    def expand(self):
        queue = deque(sorted(self.requests, key=lambda x: (x[1], x[0])))
        seen = set()
        self.unexpanded = {}
        while queue:
            key = queue.popleft()
            if key in seen or key in self.resolutions:
                continue
            seen.add(key)
            name, height = key
            if key not in self.tasks:
                c = self.program.claims[name]
                cases = [x for x in c.cases if x.schedule.contains(height)]
                require(len(cases) == 1, "InvalidProgramCase")
                case = cases[0]
                nodes, args = len(case.instructions), sum(len(i.arguments) for i in case.instructions)
                e = self.meter.envelope
                if (len(self.tasks) >= e.max_instances or
                    nodes > e.max_nodes - self.structural_nodes or args > e.max_arguments - self.structural_args):
                    self.unexpanded[key] = "BudgetExceeded"
                    continue
                try:
                    checked_types = self.typecheck(c, case.instructions, height)
                    dependencies = {i: self.selected(ins, height, c) for i, ins in enumerate(case.instructions)
                                    if ins.operator in ("Ref", "Window", "Convert")}
                    self.meter.charge()
                except num.NumericError as error:
                    require(error.status == "BudgetExceeded", error.status)
                    self.unexpanded[key] = "BudgetExceeded"
                    continue
                self.tasks[key] = {"instructions": case.instructions, "dependencies": dependencies,
                                   "types": checked_types, "values": {}, "blocked": {}}
                self.structural_nodes += nodes
                self.structural_args += args
            for selected in self.tasks[key]["dependencies"].values():
                queue.extend(selected)

    def source(self, observation, use, allow_rate=False):
        declaration = observation.declaration
        checker = ft.Checker(ft.Manifest({declaration.name: declaration}, {}), use)
        checker.declaration(declaration.name)
        require(allow_rate or not declaration.conversion_rate, "RateRequiresConvert")
        low = self.q(declaration.value).value
        high = self.q(declaration.value if observation.upper is None else observation.upper).value
        return Value(Interval(low, high), declaration.theta, "Num", frozenset((observation,)))

    def execute(self, key, index, task, now):
        name, height = key
        c = self.program.claims[name]
        ins = task["instructions"][index]
        op, p = ins.operator, ins.parameters
        use = self.use(name, height)
        values = [task["values"].get(a) for a in ins.arguments]
        if any(v is None for v in values): return None, "AwaitOperands"
        if any(v.sort == "Bool" and v.number is None for v in values): return None, "AmbiguousGuard"
        self.meter.charge()
        if op == "Const":
            manifest = {d.name: dc.replace(d, theta=at(d.theta, height)) for d in c.declarations}
            checker = ft.Checker(ft.Manifest(manifest, {}), use)
            item = checker.declaration(p[0])
            require(item.role in ("literal", "contractual_coefficient") and not item.conversion_rate, "ConstRequiresIssuanceDeclaration")
            number = item.value if item.sort == "Bool" else self.scalar(self.q(item.value).value)
            return Value(number, item.theta, item.sort, frozenset((item,))), None
        if op == "Oracle":
            source, tau = p
            require(source in self.program.oracles, "UndeclaredOracle")
            observation = self.observations.get((source, height - tau))
            # Reuse the source module's exact missing-input and deadline contract.
            available = {} if observation is None else {(source, height - tau): observation.declaration.value}
            state = readiness.read_leaf(sched.Oracle(source, tau), height, {}, {}, available, now=now,
                     policy=readiness.DeadlinePolicy(height + c.deadline_delay, c.deadline_action))
            if isinstance(state, readiness.Await): return None, ("Await", state.missing, state.action)
            return self.source(observation, use), None
        if op in ("Ref", "Window"):
            deps = task["dependencies"][index]
            missing = tuple(d for d in deps if d not in self.resolutions)
            if missing: return None, ("AwaitClaims", missing)
            inputs = []
            for dep in deps:
                record = self.resolutions[dep]
                v = record["value"]
                sampled = op == "Window" or p[2] == "sample"
                require(op != "Ref" or p[2] in ("sample", "amount"), "InvalidReferenceMode")
                theta = ft.Theta(v.theta.unit, v.theta.scale, ft.Group()) if sampled else v.theta
                history = HistoricalRead(dep[0], dep[1], record["identity"], v.theta)
                inputs.append(dc.replace(v, theta=theta, history=v.history | frozenset((history,))))
            require(all(v.theta == inputs[0].theta for v in inputs), "WindowTypeMismatch")
            amount = inputs[0].number
            if op == "Window":
                reduction = p[2]
                for v in inputs[1:]:
                    amount = self.add(amount, v.number) if reduction in ("Sum", "Avg") else self.pick(amount, v.number, reduction == "Max")
                if reduction == "Avg": amount = self.multiply(amount, self.scalar(self.q(F(1, len(inputs))).value))
            return self.combined(amount, inputs[0].theta, "Num", inputs), None
        if op == "IfElse":
            cond = values[0]
            require(cond.sort == "Bool", "ConditionRequiresBool")
            a, b = map(self.numeric, values[1:])
            require(a.theta == b.theta, "BranchTypeMismatch")
            return self.combined(a.number if cond.number else b.number, a.theta, "Num", values), None
        operands = [self.numeric(v) for v in values]
        if op == "LinComb":
            pairs = list(zip(operands[::2], operands[1::2]))
            require(all(a.theta == ft.NEUTRAL for a, _ in pairs), "DimensionedLinCombCoefficient")
            theta = pairs[0][1].theta
            require(all(v.theta == theta for _, v in pairs), "LinCombTypeMismatch")
            amount = self.scalar(self.q(0).value)
            for a, v in pairs: amount = self.add(amount, self.multiply(a.number, v.number))
        elif op == "Mul":
            a, b = operands
            scale = self.q(a.theta.scale).mul(self.q(b.theta.scale)).value
            theta = ft.Theta(self.group(a.theta.unit, b.theta.unit), scale, self.group(a.theta.context, b.theta.context))
            amount = self.multiply(a.number, b.number)
        elif op in ("Ind", "Cap", "Floor"):
            a, b = operands
            require(a.theta == b.theta, "ComparisonOrBoundTypeMismatch")
            if op == "Ind": return self.combined(self.compare(a.number, b.number, p[0]), ft.NEUTRAL, "Bool", values), None
            theta, amount = a.theta, self.pick(a.number, b.number, op == "Floor")
        elif op == "Rescale":
            a = operands[0]
            theta = ft.Theta(a.theta.unit, p[0], a.theta.context)
            factor = self.q(a.theta.scale).mul(self.q(1 / theta.scale)).value
            amount = self.multiply(a.number, self.scalar(factor))
        elif op == "Convert":
            a = operands[0]
            rate_name, target, witness_name, direction = p
            theta = at(target, height)
            witness = self.witnesses.get((name, height, witness_name))
            if witness is None: return None, ("AwaitWitness", witness_name)
            declarations = {d.name: d for d in c.declarations}
            if dict(c.rate_references).get(rate_name) is not None:
                dep = task["dependencies"][index][0]
                if dep not in self.resolutions: return None, ("AwaitRateClaim", dep)
                rate = self.rate_declaration(dep, rate_name, name, height)
                record = self.resolutions[dep]
                rate_value = dc.replace(record["value"], evidence=record["value"].evidence | frozenset((rate,)),
                    history=record["value"].history | frozenset((HistoricalRead(dep[0], dep[1], record["identity"], rate.theta),)))
            elif rate_name in declarations:
                rate = declarations[rate_name]
                rate_value = self.source(Observation(rate, self.program.context_id), use, True)
            else:
                observation = self.observations.get((rate_name, height))
                if observation is None: return None, ("AwaitRate", rate_name, height)
                if observation.upper is not None and observation.upper != observation.declaration.value:
                    return None, ("AwaitExactWitnessedRate", rate_name, height)
                rate = observation.declaration
                rate_value = self.source(observation, use, True)
            require(rate.conversion_rate and witness.use == use, "WitnessUseMismatch")
            require(witness.rate == rate and witness.source_theta == a.theta and witness.target_theta == theta,
                    "WitnessBindingMismatch")
            require(witness.direction == direction == "source_to_target", "WitnessDirectionMismatch")
            require(rate.theta.unit == self.group(theta.unit, a.theta.unit, True) and
                    rate.theta.context == self.group(theta.context, a.theta.context, True),
                    "RateDimensionOrContextMismatch")
            if rate.role == "resolved_claim": require(rate.height < height, "NonhistoricalResolvedRate")
            factor = self.q(a.theta.scale).mul(self.q(rate.theta.scale)).mul(self.q(1 / theta.scale)).value
            amount = self.multiply(self.multiply(a.number, rate_value.number), self.scalar(factor))
            values += [dc.replace(rate_value, witnesses=rate_value.witnesses | frozenset((witness,)))]
        else:
            raise Invalid("UnknownInstruction")
        return self.combined(amount, theta, "Num", values), None

    def rate_declaration(self, source, rate_name, consumer, height):
        """Expose the exact resolved record that a conversion witness must bind."""
        c = self.program.claims[consumer]
        r = dict(c.rate_references).get(rate_name)
        require(r is not None and source == (r.target, height - r.tau), "RateReferenceMismatch")
        record = self.resolutions[source]
        value = record["value"]
        return ft.Declaration(rate_name, value.number.lower, value.theta, role="resolved_claim",
                             source="resolution:" + record["identity"], height=source[1],
                             authority=c.authority, conversion_rate=True)

    def commit(self, key, value):
        name, height = key
        c = self.program.claims[name]
        value = self.numeric(value)
        require(value.theta == at(c.output, height), "ClaimRootTypeMismatch")
        if value.number.lower != value.number.upper:
            return False
        identity = digest((self.program.identity, key, value))
        bindings = []
        for p in c.positions:
            # This multiplication participates in the same numerical budget.
            require(type(p.quantity) in (int, F), "InexactPosition")
            require(value.theta.unit == ft.Group.atom(p.asset), "PositionSettlementAssetMismatch")
            expected_context = at(ft.Theta(context=p.payment_context), height).context
            require(value.theta.context == expected_context, "PositionPaymentContextMismatch")
            canonical = self.q(value.number.lower).mul(self.q(value.theta.scale)).value
            self.q(p.quantity).mul(self.q(canonical))
            bindings.append(ent.BoundEntitlement(ent.CoreKey(p.issuance, p.lot, height, p.leg),
                self.program.identity, identity, F(p.quantity), canonical, p.obligor, p.beneficiary,
                p.asset, p.context, p.position_evidence, p.terms_evidence))
        # Preflight every immutable identity before changing the shared local ledger.
        with self.ledger._lock:
            batch = {}
            for binding in bindings:
                require(binding.key not in batch or batch[binding.key] == binding, "DuplicateEntitlementKeyConflict")
                batch[binding.key] = binding
                prior = self.ledger._bindings.get(binding.key)
                require(prior is None or prior == binding, "EntitlementIdentityConflict")
                require(binding.obligor != binding.beneficiary, "IdenticalCounterparties")
                for text in (binding.program_digest, binding.resolution_evidence, binding.position_evidence, binding.terms_evidence):
                    ent.evidence(text)
            for binding in batch.values():
                self.ledger.resolve(binding)
            if not bindings:
                self.ledger.record_auxiliary(name, height, value.number.lower, identity)
            self.resolutions[key] = {"identity": identity, "value": value, "bindings": tuple(batch.values())}
        return True

    @current_action
    def run(self, *, now, context_id, envelope=None):
        self.context(context_id)
        require(type(now) is int and all(h <= now for _, h in self.requests), "FutureResolution")
        if envelope is not None:
            self.meter = self.meter.extend(envelope)
            self.generation += 1
        signature = (now, self.generation)
        if self.last_run == signature:
            return self.report(now)
        try:
            self.expand()
        except num.NumericError as error:
            require(error.status == "BudgetExceeded", error.status)
            self.last_run = signature
            return self.report(now, "BudgetExceeded")
        for key in sorted(self.tasks, key=lambda x: (x[1], x[0])):
            if key in self.resolutions:
                continue
            task = self.tasks[key]
            task["blocked"] = {}
            for index in range(len(task["instructions"])):
                if index in task["values"]:
                    continue
                try:
                    value, reason = self.execute(key, index, task, now)
                    if value is not None:
                        task["values"][index] = value
                        count_key = key + (index,)
                        self.execution_counts[count_key] = self.execution_counts.get(count_key, 0) + 1
                    else: task["blocked"][index] = reason
                except num.NumericError as error:
                    require(error.status == "BudgetExceeded", error.status)
                    task["blocked"][index] = "BudgetExceeded"
            root = task["values"].get(len(task["instructions"]) - 1)
            if root is not None and not (root.sort == "Bool" and root.number is None):
                try:
                    if not self.commit(key, root): task["blocked"]["root"] = "AwaitExactAmount"
                except num.NumericError as error:
                    require(error.status == "BudgetExceeded", error.status)
                    task["blocked"]["root"] = "BudgetExceeded"
        self.last_run = signature
        return self.report(now)

    def report(self, now, global_status=None):
        pending = {}
        for key, task in self.tasks.items():
            if key not in self.resolutions:
                c = self.program.claims[key[0]]
                pending[key] = {"blocked": dict(task["blocked"]), "ready_nodes": len(task["values"]),
                                "action": "wait" if now < key[1] + c.deadline_delay else c.deadline_action}
        return {"status": global_status or ("Resolved" if all(k in self.resolutions for k in self.requests) else "Pending"),
                "resolved": tuple(sorted(self.resolutions)), "pending": pending,
                "unexpanded": dict(self.unexpanded),
                "work": self.meter.steps, "number_bits": self.meter.number_bits,
                "nodes": self.structural_nodes, "arguments": self.structural_args}

    @current_snapshot
    def checkpoint(self, key):
        require(type(key) is bytes and len(key) >= 32, "ContinuationKeyTooShort")
        require(self.journal.heads.get(self.lineage) == self.revision, "StaleContinuationHandle")
        state = {"program": self.program.identity, "context": self.program.context_id,
                 "envelope": self.meter.envelope, "work": self.meter.steps, "number_bits": self.meter.number_bits,
                 "observations": self.observations, "witnesses": self.witnesses, "tasks": self.tasks,
                 "resolutions": self.resolutions, "requests": frozenset(self.requests),
                 "execution_counts": self.execution_counts, "generation": self.generation,
                 "last_run": self.last_run, "structural_nodes": self.structural_nodes,
                 "structural_args": self.structural_args, "input_bytes": self.input_bytes,
                 "ledger_history": self.ledger_history(), "unexpanded": self.unexpanded,
                 "lineage": self.lineage, "revision": self.revision}
        payload = wire(state)
        return json.dumps({"payload": payload.decode(), "hmac": hmac.digest(key, payload, "sha256").hex()},
                          sort_keys=True).encode()

    def ledger_history(self):
        """Copy append-only records, including payments and auxiliary resolutions."""
        names = ("_bindings", "_dues", "_corrections", "_auxiliary", "_credits", "_reports",
                 "_aliases", "_alias_evidence", "_allocations", "_quantity_corrections", "_returns",
                 "_reopenings", "_cash_bookings", "_reservations", "_encumbrances")
        with self.ledger._lock:
            return {name: dict(getattr(self.ledger, name)) for name in names}

    @classmethod
    def restore(cls, program, checkpoint, key, ledger, *, context_id, journal=None, max_bytes=32_000_000):
        require(type(checkpoint) is bytes and len(checkpoint) <= max_bytes, "ContinuationSizeExceeded")
        require(type(key) is bytes and len(key) >= 32, "ContinuationKeyTooShort")
        record = json.loads(checkpoint)
        payload = record["payload"].encode()
        require(hmac.compare_digest(record["hmac"], hmac.digest(key, payload, "sha256").hex()), "ContinuationAuthenticationFailed")
        state = decode(json.loads(payload))
        require(state["program"] == program.identity and state["context"] == context_id == program.context_id,
                "ContinuationContextOrProgramMismatch")
        require(type(journal) is ContinuationJournal, "MissingContinuationJournal")
        result = object.__new__(cls)
        result.program, result.ledger, result.journal = program, ledger, journal
        result.meter = Meter(state["envelope"])
        result.lineage, result.revision = state["lineage"], state["revision"]
        for attribute in ("observations", "witnesses", "tasks", "resolutions", "execution_counts", "generation",
                          "last_run", "structural_nodes", "structural_args", "input_bytes", "unexpanded"):
            setattr(result, attribute, state[attribute])
        result.requests = set(state["requests"])
        result.meter.steps, result.meter.number_bits = state["work"], state["number_bits"]
        # Additional valid payments may occur while a continuation is suspended.
        # Every recorded predecessor entry must remain present with its exact bytes.
        with journal.lock, ledger._lock:
            require(journal.heads.get(result.lineage) == result.revision, "StaleContinuationCheckpoint")
            for name, previous in state["ledger_history"].items():
                actual = getattr(ledger, name)
                require(all(k in actual and actual[k] == v for k, v in previous.items()), "ContinuationLedgerMismatch")
            # Restore consumes the checkpoint. Its former live handle is also stale.
            result.revision += 1
            journal.heads[result.lineage] = result.revision
        return result
