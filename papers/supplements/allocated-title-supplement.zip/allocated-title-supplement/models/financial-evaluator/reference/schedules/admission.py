"""Decide schedule obligations for finite, case-indexed claim declarations.

A program records the leaves of a separately typed payoff DAG. This module
checks its schedule obligations. It does not check the remaining payoff syntax.
"""

from dataclasses import dataclass
from math import gcd


class Invalid(ValueError):
    """The input violates a schedule or declaration condition."""


class BudgetExceeded(RuntimeError):
    """The checker needs a larger explicit resource budget."""


@dataclass(frozen=True)
class Descriptor:
    """Represent F union {h >= a : h mod p belongs to R}."""

    a: int
    p: int
    F: frozenset[int] = frozenset()
    R: frozenset[int] = frozenset()

    def contains(self, h: int) -> bool:
        return h >= 1 and (h in self.F if h < self.a else h % self.p in self.R)


@dataclass(frozen=True)
class Const:
    value: int


@dataclass(frozen=True)
class Oracle:
    source: str
    tau: int = 0


@dataclass(frozen=True)
class Ref:
    target: str
    tau: int


@dataclass(frozen=True)
class Window:
    target: str
    W: int
    reduction: str = "Avg"


@dataclass(frozen=True)
class Case:
    U: Descriptor
    P: tuple = ()


@dataclass(frozen=True)
class Claim:
    name: str
    H: Descriptor
    cases: tuple[Case, ...]


@dataclass(frozen=True)
class Budget:
    max_integer_bits: int = 128
    max_input_bits: int = 1_000_000
    max_input_items: int = 20_000
    max_horizon: int = 100_000
    max_checks: int = 2_000_000


@dataclass(frozen=True)
class Certificate:
    obligations: int
    max_horizon: int
    membership_bound: int


class _Meter:
    def __init__(self, budget):
        if type(budget) is not Budget:
            raise Invalid("Expected a Budget.")
        for value in vars(budget).values():
            if type(value) is not int or value < 1:
                raise Invalid("Budget limits must be positive integers.")
        self.budget = budget
        self.items = 0
        self.bits = 0
        self.checks = 0

    def add_items(self, count):
        if count > self.budget.max_input_items - self.items:
            raise BudgetExceeded("Input item limit exceeded.")
        self.items += count

    def number(self, value, minimum=None):
        if type(value) is not int:
            raise Invalid("Expected an integer, excluding booleans.")
        bits = max(1, value.bit_length())
        if bits > self.budget.max_integer_bits:
            raise BudgetExceeded("Integer bit limit exceeded.")
        self.add_bits(bits)
        if minimum is not None and value < minimum:
            raise Invalid("Integer is below its permitted minimum.")

    def add_bits(self, count):
        if count > self.budget.max_input_bits - self.bits:
            raise BudgetExceeded("Input bit limit exceeded.")
        self.bits += count

    def name(self, value):
        if type(value) is not str or not value:
            raise Invalid("Identifiers must be nonempty strings.")
        self.add_bits(32 * len(value))

    def sequence(self, value):
        if type(value) is not tuple:
            raise Invalid("Declaration sequences must be tuples.")
        self.add_items(len(value))

    def descriptor(self, value):
        if type(value) is not Descriptor:
            raise Invalid("Expected a Descriptor.")
        if type(value.F) is not frozenset or type(value.R) is not frozenset:
            raise Invalid("Descriptor sets must be frozensets.")
        self.add_items(1 + len(value.F) + len(value.R))
        self.number(value.a, 1)
        self.number(value.p, 1)
        for h in value.F:
            self.number(h, 1)
            if h >= value.a:
                raise Invalid("A finite prefix height must be below its cutoff.")
        for r in value.R:
            self.number(r, 0)
            if r >= value.p:
                raise Invalid("A residue must be below its period.")

    def shifted_cutoff(self, cutoff, shift):
        if shift > self.budget.max_horizon - cutoff:
            raise BudgetExceeded("Shifted cutoff exceeds the horizon limit.")
        return cutoff + shift

    def horizon(self, cutoff, periods, checks_per_height):
        """Bound the LCM product and total work before multiplication."""
        if cutoff > self.budget.max_horizon:
            raise BudgetExceeded("Cutoff exceeds the horizon limit.")
        work_horizon = (self.budget.max_checks - self.checks) // checks_per_height
        if cutoff > work_horizon:
            raise BudgetExceeded("Estimated membership checks exceed the limit.")
        period_limit = min(self.budget.max_horizon, work_horizon) - cutoff + 1
        period = 1
        for p in periods:
            factor = p // gcd(period, p)
            if factor > period_limit // period:
                raise BudgetExceeded("LCM exceeds the horizon or membership check limit.")
            period *= factor
        horizon = cutoff + period - 1
        self.checks += horizon * checks_per_height
        return horizon


def _validate(claims, meter):
    """Validate bounded immutable inputs before any LCM or height loop."""
    meter.sequence(claims)
    names = {}
    for claim in claims:
        if type(claim) is not Claim:
            raise Invalid("Expected a Claim.")
        meter.name(claim.name)
        if claim.name in names:
            raise Invalid("Claim identifiers must be unique.")
        names[claim.name] = claim
        meter.descriptor(claim.H)
        if not claim.H.F and not claim.H.R:
            raise Invalid("A claim schedule must be nonempty.")
        meter.sequence(claim.cases)
        for case in claim.cases:
            if type(case) is not Case:
                raise Invalid("Expected a Case.")
            meter.descriptor(case.U)
            meter.sequence(case.P)
            for leaf in case.P:
                if type(leaf) is Const:
                    meter.number(leaf.value)
                elif type(leaf) is Oracle:
                    meter.name(leaf.source)
                    meter.number(leaf.tau, 0)
                elif type(leaf) is Ref:
                    meter.name(leaf.target)
                    meter.number(leaf.tau, 1)
                elif type(leaf) is Window:
                    meter.name(leaf.target)
                    meter.number(leaf.W, 1)
                    if type(leaf.reduction) is not str or leaf.reduction not in ("Min", "Max", "Sum", "Avg"):
                        raise Invalid("Unknown window reduction.")
                else:
                    raise Invalid("Unknown program leaf.")
    return names


def _plan(claims, names, meter):
    plans = []
    for claim in claims:
        schedules = (claim.H,) + tuple(case.U for case in claim.cases)
        end = meter.horizon(max(s.a for s in schedules), (s.p for s in schedules), len(schedules))
        plans.append(("cover", claim.name, claim.H, tuple(schedules[1:]), end))
        for case in claim.cases:
            for leaf in case.P:
                if type(leaf) is Const:
                    continue
                if type(leaf) is Oracle:
                    cutoff = max(case.U.a, meter.shifted_cutoff(1, leaf.tau))
                    end = meter.horizon(cutoff, (case.U.p,), 1)
                    plans.append(("oracle", claim.name, case.U, leaf, end))
                    continue
                if leaf.target not in names:
                    raise Invalid("A reference target is undeclared.")
                target = names[leaf.target].H
                shift = leaf.tau if type(leaf) is Ref else leaf.W
                cutoff = max(case.U.a, meter.shifted_cutoff(target.a, shift))
                cost = 2 if type(leaf) is Ref else 1 + leaf.W
                end = meter.horizon(cutoff, (case.U.p, target.p), cost)
                plans.append(("ref" if type(leaf) is Ref else "window", claim.name, case.U, (target, shift), end))
    return plans


def admit(claims: tuple[Claim, ...], budget: Budget = Budget()) -> Certificate:
    """Check every declared instance, including the infinite periodic tail.

    Invalid identifies a malformed declaration or a witnessed failure.
    BudgetExceeded gives no validity decision. Supply a larger Budget to retry.
    """
    meter = _Meter(budget)
    names = _validate(claims, meter)
    plans = _plan(claims, names, meter)
    for kind, name, source, data, end in plans:
        for h in range(1, end + 1):
            if kind == "cover":
                valid = sum(s.contains(h) for s in data) == int(source.contains(h))
            elif not source.contains(h):
                continue
            elif kind == "oracle":
                valid = h > data.tau
            elif kind == "ref":
                target, shift = data
                valid = target.contains(h - shift)
            else:
                target, width = data
                valid = h > width and any(target.contains(h - j) for j in range(1, width + 1))
            if not valid:
                raise Invalid(f"{name}: {kind} obligation fails at height {h}.")
    return Certificate(len(plans), max((p[-1] for p in plans), default=0), meter.checks)
