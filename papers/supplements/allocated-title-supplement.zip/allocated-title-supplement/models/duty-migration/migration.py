"""Finite-integer instance of the paper's duty-carriage transition.

This extends the paper state, not the production engine. Integer cells implement
the finite interval algebra. Ed25519 keys are admitted test authorities. Family
refinement and an institution's authority to migrate remain separate premises.
"""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import sys
import threading

BASE = Path(__file__).resolve().parents[2] / 'models/duty-reference'
EXPECTED_REFERENCE = '7a5cd9be8bb368a5820a734653317220c88caef584f321f29d3815bdc30e83b7'
if sha256((BASE / 'p09_reference.py').read_bytes()).hexdigest() != EXPECTED_REFERENCE:
    raise RuntimeError('P09 reference dependency changed')
sys.path.insert(0, str(BASE))
from p09_reference import canonical, digest, require, natural, identifier, verify, sign, Invalid, invariant


def economic_id(issuer_namespace, constituting_act, occurrence_index):
    for value in (issuer_namespace, constituting_act, occurrence_index):
        identifier(value)
    return digest(['economic-duty', issuer_namespace, constituting_act, occurrence_index])


def cells(row, duties):
    require(type(row) is list and row, 'nonempty representation')
    result = []
    for interval in row:
        require(type(interval) is list and len(interval) == 3, 'interval shape')
        root, start, stop = interval
        require(root in duties, 'unregistered economic duty')
        natural(start); natural(stop)
        require(start < stop <= duties[root]['quantity'], 'interval extent')
        result.extend((root, index) for index in range(start, stop))
    require(len(result) == len(set(result)), 'overlapping row')
    return result


def validate_rows(rows, journal):
    require(type(rows) is dict and rows, 'nonempty family representation')
    seen = set()
    projection = {}
    for name, intervals in rows.items():
        identifier(name)
        support = cells(intervals, journal['duties'])
        require(not seen.intersection(support), 'overlapping family representation')
        seen.update(support)
        terms = [journal['duties'][root]['terms'] for root, _ in support]
        require(all(t == terms[0] for t in terms), 'heterogeneous scalar row')
        measures = {label: 0 for label in ('Contingent', 'Payable', 'Discharged')}
        for root, index in support:
            measures[journal['duties'][root]['labels'][index]] += 1
        projection[name] = {'terms': deepcopy(terms[0]), **measures}
    expected = {(root, index) for root, duty in journal['duties'].items()
                for index in range(duty['quantity'])}
    require(seen == expected, 'lost economic duty cells')
    return projection


class CarriageEngine:
    """One serialized authority domain with stable duty and command journals."""
    def __init__(self, duties, rows, binding, authority_key, provider_key):
        self.lock = threading.RLock()
        self.authority_key = authority_key
        self.provider_key = provider_key
        self.authority_epoch = 0
        require(type(binding) in (list, tuple) and len(binding) == 4 and all(type(x) is str and x for x in binding), 'binding')
        for root, duty in duties.items():
            require(root == economic_id(*duty['origin']), 'duty constituting identity')
            natural(duty['quantity'])
            require(0 < duty['quantity'] <= 10000, 'finite reference quantity')
            require(len(duty['labels']) == duty['quantity'], 'duty labels')
            require(all(x in ('Contingent', 'Payable', 'Discharged') for x in duty['labels']), 'phase')
            require(set(duty['terms']) == {'debtor', 'beneficiary', 'asset', 'unit', 'due', 'condition', 'priority', 'governing_right'}, 'terms')
            require(all(type(x) is str and x for x in duty['terms'].values()), 'typed terms')
        journal = {'duties': deepcopy(duties), 'decisions': {}, 'generations': {}, 'commands': {}, 'effects': {}, 'credits': {}, 'funding_domain': 'one-admitted-book', 'antecedent': None}
        self.state = {'revision': 0, 'binding': list(binding), 'journal': journal,
                      'rows': deepcopy(rows), 'private_projection': validate_rows(rows, journal), 'migrations': []}

    def snapshot(self):
        with self.lock:
            return deepcopy(self.state)

    def base(self):
        return digest(self.state)

    def _advance(self):
        self.state['revision'] += 1
        self.state['private_projection'] = validate_rows(self.state['rows'], self.state['journal'])

    def proposal(self, binding, rows):
        with self.lock:
            require(type(binding) in (list, tuple) and len(binding) == 4 and all(type(x) is str and x for x in binding), 'binding')
            return {'kind': 'Carriage', 'base': self.base(), 'old_binding': deepcopy(self.state['binding']),
                    'new_binding': list(binding), 'authority_epoch': self.authority_epoch,
                    'journal': digest(self.state['journal']), 'rows': deepcopy(rows),
                    'private_projection': validate_rows(rows, self.state['journal'])}

    def migrate(self, envelope):
        with self.lock:
            p = verify(self.authority_key, envelope)
            require(set(p) == {'kind','base','old_binding','new_binding','authority_epoch','journal','rows','private_projection'}, 'migration shape')
            require(p['kind'] == 'Carriage' and p['authority_epoch'] == self.authority_epoch, 'current migration authority')
            require(p['base'] == self.base() and p['old_binding'] == self.state['binding'], 'stale migration base')
            require(type(p['new_binding']) is list and len(p['new_binding']) == 4 and all(type(x) is str and x for x in p['new_binding']), 'new binding')
            require(p['new_binding'] != p['old_binding'], 'changed semantic binding')
            require(p['journal'] == digest(self.state['journal']), 'canonical journal changed')
            require(p['private_projection'] == validate_rows(p['rows'], self.state['journal']), 'family decoding disagreement')
            self.state['migrations'].append({'witness': digest(p), 'old_base': p['base']})
            self.state['binding'] = p['new_binding']
            self.state['rows'] = p['rows']
            self._advance()
            return self.base()

    def prepare(self, command, row, quantity, base):
        with self.lock:
            require(base == self.base(), 'stale dispatch base')
            identifier(command); natural(quantity)
            require(quantity > 0, 'positive preparation')
            require(command not in self.state['journal']['commands'], 'existing command')
            require(row in self.state['rows'], 'inactive representation')
            journal = self.state['journal']
            occupied = {tuple(cell) for c in journal['commands'].values() if c['status'] == 'Prepared' for cell in c['cells']}
            available = [cell for cell in cells(self.state['rows'][row], journal['duties'])
                         if journal['duties'][cell[0]]['labels'][cell[1]] == 'Payable' and cell not in occupied]
            require(len(available) >= quantity, 'insufficient unreserved payable duty')
            selected = available[:quantity]
            original = {'command': command, 'cells': [list(c) for c in selected],
                'binding': deepcopy(self.state['binding']), 'funding_domain': journal['funding_domain'],
                'terms': {root: deepcopy(journal['duties'][root]['terms']) for root,_ in selected}}
            journal['commands'][command] = {**original, 'command_binding': digest(original), 'status': 'Prepared'}
            self._advance()
            return deepcopy(journal['commands'][command])

    def complete(self, envelope):
        """Accept delayed outcomes by original command binding, after migration."""
        with self.lock:
            p = verify(self.provider_key, envelope)
            require(set(p) == {'occurrence','command','command_binding','quantity','physical_quantity','physical_slices','kind'}, 'provider shape')
            require(p['kind'] == 'FinalRecipientCredit', 'admitted provider finality')
            identifier(p['occurrence']); natural(p['quantity'])
            journal = self.state['journal']
            assertion = digest(p)
            if assertion in journal['effects']:
                return 'Duplicate'
            require(p['command'] in journal['commands'], 'unknown original command')
            command = journal['commands'][p['command']]
            require(p['command_binding'] == command['command_binding'], 'original economic command binding')
            require(command['status'] == 'Prepared', 'command already completed')
            require(p['quantity'] == len(command['cells']), 'provider quantity mismatch')
            require(all(journal['duties'][root]['labels'][index] == 'Payable' for root,index in command['cells']), 'dischargeable cells')
            natural(p['physical_quantity'])
            require(type(p['physical_slices']) is list and len(p['physical_slices']) == p['quantity'], 'physical allocation quantity')
            require(all(type(x) is int and 1 <= x <= p['physical_quantity'] for x in p['physical_slices']), 'physical allocation domain')
            require(len(set(p['physical_slices'])) == len(p['physical_slices']), 'duplicate physical allocation slice')
            terms = next(iter(command['terms'].values()))
            credit = journal['credits'].get(p['occurrence'], {'quantity':p['physical_quantity'], 'asset':terms['asset'], 'unit':terms['unit'], 'used':[]})
            require((credit['quantity'],credit['asset'],credit['unit']) == (p['physical_quantity'],terms['asset'],terms['unit']), 'canonical physical credit changed')
            require(not set(credit['used']).intersection(p['physical_slices']), 'physical credit already allocated')
            for root,index in command['cells']:
                journal['duties'][root]['labels'][index] = 'Discharged'
            journal['credits'][p['occurrence']] = {**credit, 'used':sorted(credit['used'] + p['physical_slices'])}
            journal['effects'][assertion] = p
            command['status'] = 'Completed'
            self._advance()
            return 'Applied'

    def decision(self, root, event_class, generation, disposition, base):
        """Event decisions do not discharge or erase any economic duty."""
        with self.lock:
            require(base == self.base(), 'stale event base')
            require(root in self.state['journal']['duties'], 'known event duty')
            natural(generation); identifier(event_class)
            require(disposition in ('Pending','Accepted','Refused'), 'decision disposition')
            key = digest([root, event_class, generation])
            previous = self.state['journal']['decisions'].get(key)
            require(previous not in ('Accepted','Refused'), 'terminal event generation')
            scope = digest([root, event_class])
            require(generation == self.state['journal']['generations'].get(scope, 0), 'unadmitted event generation')
            self.state['journal']['decisions'][key] = disposition
            self._advance()
            return key

    def rearm(self, envelope):
        with self.lock:
            p = verify(self.authority_key, envelope)
            require(set(p) == {'kind','root','event_class','generation','base','authority_epoch','basis'}, 'rearm shape')
            require(p['kind'] == 'Rearm' and p['base'] == self.base(), 'current rearm base')
            require(p['authority_epoch'] == self.authority_epoch, 'current rearm authority')
            identifier(p['basis']); identifier(p['event_class']); natural(p['generation'])
            require(p['root'] in self.state['journal']['duties'], 'known rearm duty')
            journal = self.state['journal']; scope = digest([p['root'], p['event_class']])
            old = journal['generations'].get(scope, 0)
            require(p['generation'] == old + 1, 'successive rearm')
            require(journal['decisions'].get(digest([p['root'],p['event_class'],old])) == 'Refused', 'refused predecessor')
            journal['generations'][scope] = p['generation']
            journal.setdefault('rearms', []).append(p)
            self._advance()


def from_reference(engine, claim, constituting_act, authority_key, provider_key):
    """Read one locked actual P09 state into the finite carriage instance.

    The caller establishes exclusive custody at a real handover. This read-only
    adapter does not disable the original engine and therefore is not itself a
    deployable cross-engine migration protocol.
    """
    with engine.lock:
        record = deepcopy(engine.claims[claim]); pack = deepcopy(engine.packs[record['pack']])
        state = record['state']; invariant(pack, state)
        require(state['issued'], 'issued reference claim')
        duties = {}; rows = {}
        for component, term in pack['components'].items():
            origin = [pack['issuer'], constituting_act, component]
            root = economic_id(*origin)
            paid = sum(x['amount'] for x in state['settled'].values() if x['component'] == component)
            phase = 'Payable' if component in state['vested'] else 'Contingent'
            duties[root] = {'origin': origin, 'quantity': term['amount'],
                'labels': ['Discharged'] * paid + [phase] * (term['amount'] - paid),
                'terms': {'debtor': pack['issuer'], 'beneficiary': state['holder'],
                    'asset': pack['settlement']['asset'], 'unit': pack['unit'], 'due': str(term['due']),
                    'condition': 'vested' if component in state['vested'] else 'completion:' + component,
                    'priority': 'reference-equal', 'governing_right': constituting_act}}
            rows[component] = [[root, 0, term['amount']]]
        result = CarriageEngine(duties, rows, [pack['family'], record['pack'], pack['code'], digest(pack['settlement'])], authority_key, provider_key)
        mapped = set()
        for component, generation in record['generations'].items():
            root = economic_id(pack['issuer'], constituting_act, component)
            result.state['journal']['generations'][digest([root, 'Vest'])] = generation
            for old_generation in range(generation + 1):
                old_id = digest({'claim': claim, 'pack': record['pack'], 'event': 'Vest',
                    'component': component, 'generation': old_generation})
                if old_id in record['derived']:
                    result.state['journal']['decisions'][digest([root, 'Vest', old_generation])] = record['derived'][old_id]
                    mapped.add(old_id)
        require(mapped == set(record['derived']), 'unmapped historical scheduler disposition')
        for root, envelope in engine.credit_roots.items():
            physical = envelope['payload']
            result.state['journal']['credits'][root] = {'quantity':physical['quantity'],
                'asset':physical['asset'], 'unit':physical['unit'],
                'used':sorted(engine.allocated_slices.get(root, {}))}
        result.state['journal']['antecedent'] = {'source': EXPECTED_REFERENCE, 'claim': claim,
            'pack': pack, 'record': record, 'trace': deepcopy(engine.rows),
            'allocated_slices': {root: [[index, list(owner)] for index, owner in sorted(slices.items())]
                                 for root, slices in engine.allocated_slices.items()},
            'credit_roots': deepcopy(engine.credit_roots)}
        return result
