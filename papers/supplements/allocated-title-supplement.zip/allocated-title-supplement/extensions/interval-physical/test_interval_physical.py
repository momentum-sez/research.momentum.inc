"""Changed P14 adoption routes over the exact interval store."""
from contextlib import closing
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

from interval_physical import DurablePhysicalBook, base, pf, cs, iv, ent, Rejected, digest, wire, BASE

FIXTURE = Path(pf.__file__).with_name("test_performance.py")
if hashlib.sha256(FIXTURE.read_bytes()).hexdigest() != "8b231bd495ee638bf5675f9cbc264b0f21c8ed4ad10fe5e3eae4b83521164adc":
    raise RuntimeError("ChangedPhysicalFixture")
sys.modules["performance"] = pf
spec = importlib.util.spec_from_file_location("p14_interval_physical_fixtures", FIXTURE)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
AUTH, KEYS, KEY, NOW = fixture.AUTH, fixture.KEYS, fixture.STORE_KEY, fixture.NOW
contract, request, fact = fixture.contract, fixture.request, fixture.fact
ADMISSION = pf.public_hex(AUTH.public_key())
POLICY = {"key": ADMISSION, "epoch": 0, "name": "synthetic-carriage-authority"}
HERE = Path(__file__).resolve().parent


def credit(identity, amount, recipient="seller"):
    occurrence = ent.OccurrenceKey("synthetic-bank", "RecipientCredit", identity)
    report = ent.CreditReport("report:" + identity, occurrence,
        ent.Credit(occurrence, recipient, "USD", F(amount), "booked"), "synthetic-bank", "sale-right")
    return occurrence, report


def apply(store, c, command, method, *args):
    p = pf.program(c)
    result = store.apply(store.handle(c["id"], p), p, command, "ledger", method, *args)
    if result["outcome"]["status"] != "Ok":
        raise RuntimeError(result)
    return result["outcome"]["value"]


def small_semantics(state):
    """Expand only the finite differential oracle, never the implementation."""
    s = deepcopy(state)
    c = s["carriage"]
    if s["schema"] == 3:
        for duty in c["canonical"]["journal"]["duties"].values():
            if duty["quantity"] > 10000:
                raise RuntimeError("SmallOracleOnly")
            duty["labels"] = [label for a, b, label in duty.pop("segments") for _ in range(a, b)]
        for field in ("allocation_cells", "restored_cells"):
            c[field] = {key: [[root, i] for root, a, b in runs for i in range(a, b)] for key, runs in c[field].items()}
        for value in c["physical_cells"].values():
            value["cells"] = [i for a, b in value.pop("intervals") for i in range(a, b)]
        for value in c["canonical"]["journal"]["credits"].values():
            if value["quantity"] > 10000:
                raise RuntimeError("SmallOracleOnly")
            value["used"] = [i for a, b in value.pop("used_intervals") for i in range(a, b)]
    return {"ledger": s["ledger"], "heads": s["heads"], "instances": s["instances"], "commands": s["commands"],
        "roots": c["roots"], "allocation_cells": c["allocation_cells"], "restored_cells": c["restored_cells"],
        "physical_cells": c["physical_cells"], "journal": c["canonical"]["journal"],
        "rows": c["canonical"]["rows"], "projection": c["canonical"]["private_projection"]}


class IntervalPhysicalTests(unittest.TestCase):
    def setUp(self):
        (HERE / "work").mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="interval-physical-", dir=HERE / "work")
        self.home = Path(self.temp.name)
        self.path = self.home / "source.sqlite"
        self.book = DurablePhysicalBook(self.path, KEY, ADMISSION)
        self.c = contract()
        self.book.register("register", pf.signed(AUTH, self.c))

    def tearDown(self):
        self.temp.cleanup()

    def accept(self, **kwargs):
        return self.book.submit("accept", "sale", request(self.c, **kwargs), NOW)

    def test_finite_physical_history_matches_completed_durable_profile(self):
        first = self.accept(unit="tonne", quantity=F(1, 10), stop=F(1, 25))
        second = self.book.submit("second", "sale", request(self.c, act="second", unit="tonne", quantity=F(1, 10), start=F(1, 25), stop=F(3, 50)), NOW)
        self.assertEqual((first["quantity"], second["quantity"]), (40, 20))
        occurrence, report = credit("original-credit", 400)
        self.book.ledger("credit", "sale", "record_credit", report)
        self.book.ledger("payment", "sale", "allocate", "paid", occurrence, first["due"], F(300), "payment-rule")
        debit = ent.OccurrenceKey("synthetic-bank", "RecipientDebit", "original-return")
        self.book.ledger("return", "sale", "record_return", ent.ReturnDebit(debit, occurrence, F(100), "debit-evidence"))
        self.book.ledger("reopen", "sale", "reopen", ent.Reopening("reopened", debit, "paid", F(100), "return-rule", "return-authority"))
        corrected = self.book.correct("correct", first["economic"], fact(self.c, "correction", "adjustment", economic=first["economic"], expected_head="resolution", target=F(100), basis="quality-decision"), NOW)
        recovery, report = credit("partial-recovery", 50, "buyer")
        self.book.ledger("recovery-credit", "sale", "record_credit", report)
        self.book.ledger("recovery-payment", "sale", "allocate", "recovered", recovery, corrected.due.origin, F(50), "recovery-rule")
        before = self.book.snapshot()
        left = self.home / "cell-oracle.sqlite"
        with self.book.io._connection() as source, closing(sqlite3.connect(left)) as target:
            source.backup(target)
        legacy = base.DurablePhysicalBook(left, KEY, ADMISSION)
        sys.path.insert(0, str(BASE))
        try:
            old_receipt = legacy.handover(AUTH, POLICY)
        finally:
            sys.path.pop(0)
        new_receipt = self.book.handover(AUTH, POLICY)
        old, new = legacy.carriage(), self.book.carriage()
        self.assertEqual(old_receipt, new_receipt)
        self.assertEqual(legacy.snapshot()["source"], self.book.snapshot()["source"])
        self.assertEqual(new.snapshot()["ledger"], before["ledger"])
        self.assertEqual(small_semantics(old.snapshot()), small_semantics(new.snapshot()))
        root = next(r for r, value in new.snapshot()["carriage"]["roots"].items() if value["due"] == first["due"])
        follow, report = credit("follow-credit", 10)
        for store in (old, new):
            apply(store, self.c, "follow-credit", "record_credit", report)
            store.allocate_alias("original", root, "follow-pay", follow, F(5), "payment-rule",
                expected_base=digest(store.snapshot()), physical_slices=[10, 9, 8, 7, 6])
        self.assertEqual(small_semantics(old.snapshot()), small_semantics(new.snapshot()))
        self.assertEqual(new.snapshot()["carriage"]["physical_cells"]["alias-payment:follow-pay:" + root]["intervals"], [[10,11],[9,10],[8,9],[7,8],[6,7]])
        saved = {"source": digest(before["source"]), "source_ledger": digest(before["ledger"]),
                 "old_semantics": digest(small_semantics(old.snapshot())), "interval_semantics": digest(small_semantics(new.snapshot())),
                 "original_outstanding": str(cs.dp.ledger_load(new.snapshot()["ledger"]).outstanding(first["due"])),
                 "correction_outstanding": str(cs.dp.ledger_load(new.snapshot()["ledger"]).outstanding(corrected.due.origin)),
                 "physical_quantities": [str(first["quantity"]), str(second["quantity"])]}
        (HERE / ("finite-optimized.json" if sys.flags.optimize else "finite-normal.json")).write_text(json.dumps(saved, indent=2)+"\n")

    def test_large_physical_entitlement_adopts_directly_without_capped_route(self):
        large_path = self.home / "large.sqlite"
        book = DurablePhysicalBook(large_path, KEY, ADMISSION)
        c = contract(total_price=F(10**24))
        book.register("register", pf.signed(AUTH, c))
        accepted = book.submit("accept", "sale", request(c), NOW)
        earned = accepted["earned"]
        quantum = F(1, 100)
        quantity = cs.units(earned, quantum)
        self.assertEqual((accepted["quantity"], accepted["unit"], quantity), (40, "kg", 4*10**25))
        cash, report = credit("large-credit", earned)
        book.ledger("credit", "sale", "record_credit", report)
        book.ledger("payment", "sale", "allocate", "paid", cash, accepted["due"], earned/4, "payment-rule")
        debit = ent.OccurrenceKey("synthetic-bank", "RecipientDebit", "large-prior-return")
        book.ledger("return", "sale", "record_return", ent.ReturnDebit(debit, cash, earned/8, "debit-evidence"))
        book.ledger("reopen", "sale", "reopen", ent.Reopening("large-reopen", debit, "paid", earned/8, "return-rule", "return-authority"))
        correction = book.correct("correct", accepted["economic"], fact(c, "correction", "adjustment", economic=accepted["economic"], expected_head="resolution", target=earned/2, basis="quality-decision"), NOW)
        before = book.snapshot()["ledger"]
        with patch.object(base.cs, "units", side_effect=AssertionError("Capped monetary route invoked")), patch.object(base.cs.CarriageStore, "adopt", side_effect=AssertionError("Schema-two intermediate invoked")):
            book.handover(AUTH, POLICY, quantum=quantum)
        store = book.carriage()
        self.assertEqual(store.snapshot()["schema"], 3)
        self.assertEqual(store.snapshot()["ledger"], before)
        root = next(iter(store.snapshot()["carriage"]["roots"]))
        count = quantity//10
        store.allocate_alias("original", root, "large-follow", cash, count*quantum, "payment-rule",
            expected_base=digest(store.snapshot()), physical_intervals=[[quantity-count+1, quantity+1]])
        consumed = deepcopy(store.snapshot()["carriage"]["canonical"]["journal"]["credits"])
        returned = ent.OccurrenceKey("synthetic-bank", "RecipientDebit", "large-follow-return")
        apply(store, c, "follow-return", "record_return", ent.ReturnDebit(returned, cash, count*quantum/2, "return-evidence"))
        apply(store, c, "follow-reopen", "reopen", ent.Reopening("follow-reopen", returned, "alias-payment:large-follow:"+root, count*quantum/2, "return-rule", "authority"))
        self.assertEqual(store.snapshot()["carriage"]["canonical"]["journal"]["credits"], consumed)
        fresh, report = credit("large-replacement", count*quantum/2)
        apply(store, c, "replacement", "record_credit", report)
        store.allocate_alias("original", root, "replacement-payment", fresh, count*quantum/2, "payment-rule", expected_base=digest(store.snapshot()))
        reloaded = DurablePhysicalBook(large_path, KEY, ADMISSION)
        state = reloaded.carriage().snapshot()
        ledger = cs.dp.ledger_load(state["ledger"])
        self.assertEqual(ledger.outstanding(accepted["due"]), earned-earned/4+earned/8-earned/10)
        self.assertEqual(ledger.outstanding(correction.due.origin), earned/2)
        self.assertTrue(reloaded.snapshot()["source"]["closed"])
        with self.assertRaisesRegex(Rejected, "ClosedCohort"):
            book.submit("new", "sale", request(c, act="new", start=F(40), stop=F(50)), NOW)
        self.assertLessEqual(len(state["carriage"]["canonical"]["journal"]["duties"][root]["segments"]), 6)
        self.assertLess(len(wire(state)), 1_000_000)
        evidence = {"monetary_quanta": str(quantity), "quantum": str(quantum), "accepted_quantity": str(accepted["quantity"]),
                    "physical_unit": accepted["unit"], "earned": str(earned), "original_outstanding": str(ledger.outstanding(accepted["due"])),
                    "directed_correction_outstanding": str(ledger.outstanding(correction.due.origin)),
                    "schema": state["schema"], "stored_bytes": len(wire(state)), "source_ledger_at_handover": digest(before),
                    "final_ledger": digest(state["ledger"]), "label_segments": len(state["carriage"]["canonical"]["journal"]["duties"][root]["segments"]),
                    "capped_path_disabled": True}
        (HERE / ("large-optimized.json" if sys.flags.optimize else "large-normal.json")).write_text(json.dumps(evidence, indent=2)+"\n")

    def test_failed_interval_handover_leaves_source_open_and_exact(self):
        self.accept()
        before = self.book.snapshot()
        with self.assertRaisesRegex(cs.ERROR, "ExactNonnegativeQuantumRequired"):
            self.book.handover(AUTH, POLICY, quantum=F(3))
        current = self.book.snapshot()
        self.assertEqual((current["source"], current["ledger"]), (before["source"], before["ledger"]))
        self.book.submit("second", "sale", request(self.c, act="second", start=F(40), stop=F(50)), NOW)
        self.book.handover(AUTH, POLICY, quantum=F(1,100))
        self.assertEqual(len(self.book.carriage().snapshot()["carriage"]["roots"]), 2)

    def test_changed_handover_retains_old_source_client_fence(self):
        self.accept()
        cached = base.DurablePhysicalBook(self.path, KEY, ADMISSION)
        old = cs.dp.DurableEvaluator(self.path, KEY)
        p = pf.program(self.c)
        handle = old.handle("sale", p)
        self.book.handover(AUTH, POLICY)
        with self.assertRaisesRegex(cs.ERROR, "StoreRevisionMismatch"):
            old.apply(handle, p, "stale", "evaluator", "request", "earned", 2)
        with self.assertRaisesRegex(cs.ERROR, "CarriageSchemaOrRevisionMismatch"):
            cached.submit("late", "sale", request(self.c, act="late", start=F(40), stop=F(50)), NOW)

    def test_existing_closed_cohort_refines_with_its_original_fence_and_receipts(self):
        accepted = self.accept()
        previous = base.DurablePhysicalBook(self.path, KEY, ADMISSION)
        sys.path.insert(0, str(BASE))
        try:
            original_receipt = previous.handover(AUTH, POLICY)
        finally:
            sys.path.pop(0)
        old = previous.carriage()
        root = next(iter(old.snapshot()["carriage"]["roots"]))
        cash, report = credit("prior-alias-credit", 10)
        apply(old, self.c, "prior-credit", "record_credit", report)
        payment_base = digest(old.snapshot())
        paid = old.allocate_alias("original", root, "prior-pay", cash, F(5), "payment-rule",
            expected_base=payment_base, physical_slices=[8,7,6,5,4])
        prior = old.snapshot()
        source = previous.snapshot()["source"]
        with self.assertRaisesRegex(cs.ERROR, "StaleIntervalRefinementBase"):
            DurablePhysicalBook.refine_existing(self.path, KEY, ADMISSION, payment_base)
        self.assertEqual(old.snapshot(), prior)
        refined = DurablePhysicalBook.refine_existing(self.path, KEY, ADMISSION, digest(prior))
        state = refined.carriage().snapshot()
        self.assertEqual(small_semantics(state), small_semantics(prior))
        self.assertEqual(refined.snapshot()["source"], source)
        self.assertEqual(refined.handover(AUTH, POLICY), original_receipt)
        replayed = refined.carriage().allocate_alias("original", root, "prior-pay", cash, F(5), "payment-rule",
            expected_base=payment_base, physical_slices=[8,7,6,5,4])
        self.assertEqual(replayed, paid)
        self.assertEqual(DurablePhysicalBook.refine_existing(self.path, KEY, ADMISSION, digest(prior)).carriage().snapshot(), state)
        self.assertEqual(cs.dp.ledger_load(state["ledger"]).outstanding(accepted["due"]), 395)

    def test_refinement_does_not_initialize_an_unrelated_existing_database(self):
        path = self.home / "unrelated.sqlite"
        with closing(sqlite3.connect(path)) as db:
            db.execute("CREATE TABLE marker(value TEXT)")
            db.commit()
        with self.assertRaisesRegex(Rejected, "ExistingPhysicalSourceRequired"):
            DurablePhysicalBook.refine_existing(path, KEY, ADMISSION, "unrelated")
        with closing(sqlite3.connect(path)) as db:
            tables = db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
        self.assertEqual(tables, [("marker",)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
