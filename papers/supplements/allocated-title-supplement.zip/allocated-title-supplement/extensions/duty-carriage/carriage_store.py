"""Durable finite-duty carriage over the actual pinned P08 ledger.

Schema two fences schema-one writers on this same SQLite authority. It retains
old program checkpoints and ledger records. Successor programs produce checked
aliases for resolved duties, never replacement active dues. Institutional
authority, provider truth and exclusion between different databases remain
admitted premises.
"""
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import hmac
import importlib.util
import json
from pathlib import Path
import sys

from programmes import ev, ent, evaluate, EvaluationRecipe, ROOT, PINNED_DIRECTORY

P09 = ROOT / 'models/duty-migration/migration.py'
PINS = {
    P09: '69dec36ab4d97b8a6cbb0d702f89302d09c81e870da1e61e9de65df7a21f3668',
    PINNED_DIRECTORY / 'durable_evaluator.py': 'd92aed53641670d1138e0dfa0fae7fe930abb02799e83c934820785b378bc327',
    ROOT / 'models/financial-evaluator/reference/entitlements/entitlement_model.py': '6c1f7a766319c00098d16628e83197c501a1b5b5dfe7e43b40c68d9325176f88',
}
for path, expected in PINS.items():
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError('ChangedCarriageDependency:' + str(path))

def load(name, path):
    prior = sys.modules.get(name)
    if prior is not None:
        if Path(prior.__file__).resolve() != path.resolve():
            raise RuntimeError('ConflictingCarriageModule:' + name)
        return prior
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

dp = load('durable_evaluator', PINNED_DIRECTORY / 'durable_evaluator.py')
duty = load('p09_canonical_carriage', P09)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

require = dp.require
ERROR = dp.StoreError
RELATION = 'finite-resolved-duty-partition'

def encode(value):
    """The pinned value codec, extended only for canonical journal lists."""
    if type(value) is list:
        return {'carriage_list':[encode(x) for x in value]}
    if type(value) is tuple:
        return {'tuple':[encode(x) for x in value]}
    if type(value) is frozenset:
        items=[encode(x) for x in value];items.sort(key=lambda x:json.dumps(x,sort_keys=True))
        return {'set':items}
    if type(value) is dict:
        return {'map':[[encode(k),encode(v)] for k,v in sorted(value.items(),key=lambda x:repr(x[0]))]}
    return ev.encode(value)

def decode(value):
    if type(value) is dict:
        if 'carriage_list' in value:return [decode(x) for x in value['carriage_list']]
        if 'tuple' in value:return tuple(decode(x) for x in value['tuple'])
        if 'set' in value:return frozenset(decode(x) for x in value['set'])
        if 'map' in value:return {decode(k):decode(v) for k,v in value['map']}
    return ev.decode(value)

def wire(value):
    return json.dumps(encode(value),sort_keys=True,separators=(',',':')).encode()

def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()

def public_hex(key):
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()

def signed(key, payload):
    return {'payload': deepcopy(payload), 'signature': key.sign(wire(payload)).hex()}

def verified(envelope, policy):
    require(type(envelope) is dict and set(envelope) == {'payload','signature'}, 'AuthorityEnvelopeShape')
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(policy['key'])).verify(
            bytes.fromhex(envelope['signature']), wire(envelope['payload']))
    except Exception as error:
        raise ERROR('CarriageAuthorityAuthentication') from error
    p = deepcopy(envelope['payload'])
    require(p.get('authority_epoch') == policy['epoch'], 'StaleCarriageAuthority')
    require(p.get('authority_policy') == digest(policy), 'CarriageAuthorityScopeMismatch')
    require(p.get('relation') == RELATION, 'UnadmittedCarriageRelation')
    return p

def units(amount, quantum):
    require(type(amount) in (int,F) and type(quantum) is F and quantum > 0, 'ExactCarriageQuantity')
    value = F(amount)/quantum
    require(value.denominator == 1 and 0 <= value <= 10000, 'FiniteExactQuantumRequired')
    return value.numerator

def root_spec(instance, due, origin, *, quantum=F(1), unit='USD', op_binding=None):
    return {'root': duty.economic_id(*origin), 'origin': list(origin), 'instance':instance,
            'due': due, 'quantum':quantum, 'unit':unit, 'op_binding':deepcopy(op_binding)}

def state_digest(store):
    with store._connection() as db:
        db.execute('BEGIN')
        state=store._load(db)
        return state['revision'],digest(state)


class CarriageStore(dp.DurableEvaluator):
    """One actual SQLite/MAC commit for ledger writes and canonical portions."""
    def __init__(self,path,key,**kwargs):
        require(Path(path).is_file(),'ExistingAdoptedStoreRequired')
        super().__init__(path,key,**kwargs)

    def _seal(self,state):
        # Keep the outer codec intelligible to the actual schema-one reader.
        # That reader reaches its explicit schema fence, rather than failing on
        # a new value tag. Original ledger/checkpoint values remain untouched.
        outer={**state,'carriage':wire(state['carriage']).decode()}
        body=ev.wire(outer)
        require(len(body)<=self.max_snapshot_bytes,'SnapshotSizeExceeded')
        return body,hmac.digest(self.key,body,'sha256').hex()

    @classmethod
    def adopt(cls, path, key, envelope, policy, *, fault_at=None):
        # The old client performs schema-one validation, not a guessed reader.
        old=dp.DurableEvaluator(path,key)
        with old._connection() as db:
            db.execute('BEGIN IMMEDIATE'); prior=old._load(db)
            p=verified(envelope,policy)
            require(set(p)=={'kind','relation','authority_epoch','authority_policy','base','roots'},'AdoptionShape')
            require(p['kind']=='Adopt' and p['base']==digest(prior),'StaleAdoptionBase')
            dp.fault('before_action',fault_at)
            state=deepcopy(prior); ledger=dp.ledger_load(state['ledger'])
            roots={}; seen=set(); asset_quanta={}
            for spec in p['roots']:
                require(set(spec)=={'root','origin','instance','due','quantum','unit','op_binding'},'RootBindingShape')
                root=spec['root']; due_id=spec['due']
                require(root==duty.economic_id(*spec['origin']) and root not in roots and due_id not in seen,'DuplicateEconomicDuty')
                require(due_id in ledger._dues and spec['instance'] in state['instances'],'UnknownResolvedDuty')
                due=ledger._dues[due_id]; binding=ledger._bindings[due_id.core]
                instance=state['instances'][spec['instance']]
                require(binding.program_digest==instance['program'],'OriginalProgramBindingMismatch')
                require(due_id.act=='resolution','ExplicitCorrectionCarriageRequired')
                count=units(due.amount,spec['quantum']); require(count>0,'PositiveCarriedDuty')
                require(type(spec['unit']) is str and spec['unit'],'NamedCanonicalUnit')
                if due.asset in asset_quanta:
                    require(asset_quanta[due.asset]==(spec['quantum'],spec['unit']),'OneCanonicalAssetQuantum')
                asset_quanta[due.asset]=(spec['quantum'],spec['unit'])
                roots[root]={**deepcopy(spec),'program':instance['program'],'context':instance['context'],
                    'binding':binding,'original_due':due,'quantity':count}
                seen.add(due_id)
            require(roots,'NonemptyCarriageScope')
            state['schema']=2
            state['carriage']={'policy':deepcopy(policy),'roots':roots,'asset_quanta':asset_quanta,
                'source_state_sha256':digest(prior),'source_revision':prior['revision'],
                'allocation_cells':{},'restored_cells':{},'physical_cells':{},
                'representations':{},'active':'original','receipts':{},'canonical':None}
            cls._initialize(state,ledger)
            state['carriage']['representations']['original']={'rows':{r:[[r,0,x['quantity']]] for r,x in roots.items()},'outputs':(), 'program':None}
            state['carriage']['canonical']['rows']=deepcopy(state['carriage']['representations']['original']['rows'])
            dp.fault('after_action',fault_at)
            # Use the pinned writer for the real CAS, MAC and size check.
            successor=object.__new__(cls)
            successor.__dict__.update(old.__dict__)
            dp.DurableEvaluator._write(successor,db,state,prior['revision'])
            dp.fault('after_write',fault_at);dp.fault('before_commit',fault_at)
            db.commit();dp.fault('after_commit',fault_at)
        return cls(path,key)

    def _load(self, db):
        header=db.execute('SELECT revision,length(body) FROM state WHERE id=1').fetchone()
        require(header is not None and header[1]<=self.max_snapshot_bytes,'MissingOrOversizedCarriageState')
        body,mac=db.execute('SELECT body,mac FROM state WHERE id=1').fetchone()
        require(hmac.compare_digest(mac,hmac.digest(self.key,body,'sha256').hex()),'StateAuthenticationFailed')
        state=ev.decode(dp.strict_json(body))
        require(state['schema']==2 and state['revision']==header[0],'CarriageSchemaOrRevisionMismatch')
        state['carriage']=decode(dp.strict_json(state['carriage']))
        dp.ledger_load(state['ledger']);require('carriage' in state,'MissingCanonicalCarriage')
        return state

    def create(self, instance, program, *, envelope=ev.Envelope()):
        with self._connection() as db:
            db.execute('BEGIN');state=self._load(db)
            require(instance in state['instances'],'SeparateNewIssueAdmissionRequired')
        return super().create(instance,program,envelope=envelope)

    @staticmethod
    def _initialize(state, ledger):
        c=state['carriage'];duties={};rows={}
        for root,spec in c['roots'].items():
            d=spec['original_due'];binding=spec['binding'];q=spec['quantity']
            terms={'debtor':d.debtor,'beneficiary':d.creditor,'asset':d.asset,'unit':spec['unit'],
                'due':str(d.origin.core.height),'condition':'ResolvedPayoff','priority':'declared-fungible-equal',
                'governing_right':binding.terms_evidence}
            duties[root]={'origin':spec['origin'],'quantity':q,'terms':terms,'labels':['Payable']*q}
            rows[root]=[[root,0,q]]
        policy=c['policy'];pub=Ed25519PublicKey.from_public_bytes(bytes.fromhex(policy['key']))
        model=duty.CarriageEngine(duties,rows,['P08',c['source_state_sha256'],'resolved-duty-decoder',policy['name']],pub,pub)
        c['canonical']=model.snapshot()
        # Establish cell coordinates once for fungible resolved dues. Historical
        # restoration is separate from current discharge and can share old cells.
        for root,spec in c['roots'].items():
            free=list(range(spec['quantity']))
            for a in ledger.allocation_rows(due=spec['due']):
                total=units(a.amount,spec['quantum'])
                reopened=units(sum((r.amount for r in ledger._reopenings.values() if r.allocation_id==a.allocation_id),F(0)),spec['quantum'])
                require(reopened<=total<=spec['quantity'],'HistoricalCarriageQuantity')
                active=free[:total-reopened];require(len(active)==total-reopened,'HistoricalDutyOverdischarge')
                free=free[total-reopened:]
                restored=[i for i in range(spec['quantity']) if i not in active][:reopened]
                c['allocation_cells'][a.allocation_id]=[[root,i] for i in active+restored]
                c['restored_cells'][a.allocation_id]=[[root,i] for i in restored]
                for i in active:duties[root]['labels'][i]='Discharged'
            c['canonical']['journal']['duties'][root]=duties[root]
        CarriageStore._sync_physical(c,ledger)
        c['canonical']['journal']['antecedent']={'p08_state':c['source_state_sha256'], 'ledger':digest(state['ledger'])}
        CarriageStore._check(state,ledger)

    @staticmethod
    def _sync_physical(c, ledger):
        # These are physical cell identities. Party and legal-origin labels are
        # attributes and never enter the occurrence key derived here.
        credits={}
        for key,credit in ledger._credits.items():
            if credit.asset not in c['asset_quanta']:continue
            quantum,unit=c['asset_quanta'][credit.asset];quantity=units(credit.amount,quantum)
            root=digest(('p08-physical-occurrence',key));used=[]
            for a in ledger.allocation_rows(occurrence=key):
                count=units(a.amount,quantum)
                existing=c['physical_cells'].get(a.allocation_id)
                if existing is None:
                    chosen=[i for i in range(1,quantity+1) if i not in used][:count]
                    existing={'root':root,'cells':chosen};c['physical_cells'][a.allocation_id]=existing
                require(existing['root']==root and len(existing['cells'])==count,'PhysicalAllocationBinding')
                require(all(type(i) is int and 1<=i<=quantity for i in existing['cells']),'PhysicalAllocationExtent')
                require(len(set(existing['cells']))==count and not set(used).intersection(existing['cells']),'PhysicalSliceReissue')
                used.extend(existing['cells'])
            credits[root]={'quantity':quantity,'asset':credit.asset,'unit':unit,'used':sorted(used)}
        c['canonical']['journal']['credits']=credits

    @staticmethod
    def _check(state, ledger):
        c=state['carriage'];journal=c['canonical']['journal']
        for root,spec in c['roots'].items():
            require(ledger._dues.get(spec['due'])==spec['original_due'],'ImmutableOriginalDueChanged')
            require(ledger._bindings.get(spec['due'].core)==spec['binding'],'ImmutableOriginalProgramChanged')
            payable=journal['duties'][root]['labels'].count('Payable')
            require(payable*spec['quantum']==ledger.outstanding(spec['due']),'CanonicalOutstandingMismatch')
        projection=duty.validate_rows(c['canonical']['rows'],journal)
        c['canonical']['private_projection']=projection
        journal['effects']={k:digest(a) for k,a in ledger._allocations.items()}
        journal['p08_reopenings']={k:digest(r) for k,r in ledger._reopenings.items()}
        journal['p08_cash_reservations']=ev.encode(ledger._reservations)

    def _write(self, db, state, expected_revision):
        prior=self._load(db);require(prior['revision']==expected_revision,'StaleCarriageWrite')
        before=dp.ledger_load(prior['ledger']);ledger=dp.ledger_load(state['ledger']);c=state['carriage']
        for key,a in before._allocations.items():require(ledger._allocations.get(key)==a,'HistoricalAllocationChanged')
        for key,r in before._reopenings.items():require(ledger._reopenings.get(key)==r,'HistoricalReopeningChanged')
        by_due={x['due']:(root,x) for root,x in c['roots'].items()}
        for act,r in ledger._reopenings.items():
            if act in before._reopenings:continue
            a=ledger._allocations[r.allocation_id]
            if a.due not in by_due:continue
            root,spec=by_due[a.due];count=units(r.amount,spec['quantum'])
            already=c['restored_cells'].setdefault(a.allocation_id,[])
            choices=[cell for cell in c['allocation_cells'][a.allocation_id] if cell not in already][:count]
            require(len(choices)==count,'ReopeningPortionOverflow')
            for _,index in choices:
                require(c['canonical']['journal']['duties'][root]['labels'][index]=='Discharged','ReopeningUnpaidPortion')
                c['canonical']['journal']['duties'][root]['labels'][index]='Payable'
            already.extend(choices)
        for key,a in ledger._allocations.items():
            if key in before._allocations or a.due not in by_due:continue
            root,spec=by_due[a.due];count=units(a.amount,spec['quantum']);labels=c['canonical']['journal']['duties'][root]['labels']
            selected=c['allocation_cells'].get(key,[[root,i] for i,x in enumerate(labels) if x=='Payable'][:count])
            require(len(selected)==count and len({tuple(x) for x in selected})==count,'AllocationPortionQuantity')
            require(all(r==root and 0<=i<len(labels) and labels[i]=='Payable' for r,i in selected),'AllocationPortionUnavailable')
            for _,i in selected:labels[i]='Discharged'
            c['allocation_cells'][key]=selected;c['restored_cells'][key]=[]
        self._sync_physical(c,ledger);self._check(state,ledger)
        return super()._write(db,state,expected_revision)

    def snapshot(self):
        with self._connection() as db:
            db.execute('BEGIN');return self._load(db)

    def proposal(self, recipe, outputs, nonce):
        state=self.snapshot();c=state['carriage']
        return {'kind':'Install','relation':RELATION,'authority_epoch':c['policy']['epoch'],
            'authority_policy':digest(c['policy']),
            'base':digest(state),'nonce':nonce,'program':recipe.program.identity,'context':recipe.program.context_id,
            'requests':recipe.requests,'observations':recipe.observations,'now':recipe.now,'outputs':deepcopy(outputs),
            'canonical_journal':digest(c['canonical']['journal'])}

    def install(self, recipe, envelope, *, fault_at=None):
        shadow=evaluate(recipe)
        require(shadow.report(recipe.now)['status']=='Resolved','UnresolvedSuccessorRepresentation')
        with self._connection() as db:
            db.execute('BEGIN IMMEDIATE');state=self._load(db);c=state['carriage'];p=verified(envelope,c['policy'])
            require(set(p)=={'kind','relation','authority_epoch','authority_policy','base','nonce','program','context','requests','observations','now','outputs','canonical_journal'},'InstallShape')
            require(p['kind']=='Install' and p['program']==recipe.program.identity and p['context']==recipe.program.context_id,'SuccessorProgramBinding')
            require((p['requests'],p['observations'],p['now'])==(recipe.requests,recipe.observations,recipe.now),'SuccessorInputBinding')
            previous=c['receipts'].get(p['nonce'])
            if previous is not None:
                require(previous['request']==digest(p),'CarriageNonceConflict');return previous
            require(p['base']==digest(state) and p['canonical_journal']==digest(c['canonical']['journal']),'StaleCarriageBase')
            dp.fault('before_action',fault_at)
            rows={};seen=set();source_by_alias={}
            for output in p['outputs']:
                require(set(output)=={'alias','due','portions'},'AliasShape')
                alias=output['alias'];due_id=output['due']
                require(type(alias) is str and alias and alias not in rows and due_id not in seen,'UniqueSuccessorAlias')
                require(due_id in shadow.ledger._dues,'UnknownSuccessorDue')
                rows[alias]=output['portions'];seen.add(due_id);source_by_alias[alias]=due_id
            require(seen==set(shadow.ledger._dues),'CompleteSuccessorOutputCoverage')
            projected=duty.validate_rows(rows,c['canonical']['journal'])
            for alias,projection in projected.items():
                d=shadow.ledger._dues[source_by_alias[alias]];terms=projection['terms'];roots={r for r,_,_ in rows[alias]}
                quanta={c['roots'][r]['quantum'] for r in roots};contexts={c['roots'][r]['original_due'].context for r in roots}
                require(len(quanta)==1 and len(contexts)==1,'ScalarCarriageType')
                quantity=sum(projection[label] for label in ('Contingent','Payable','Discharged'))*next(iter(quanta))
                require((d.debtor,d.creditor,d.asset,d.context,d.amount)==(terms['debtor'],terms['beneficiary'],terms['asset'],next(iter(contexts)),quantity),'SuccessorEconomicMismatch')
                require(str(d.origin.core.height)==terms['due'],'SuccessorMaturityMismatch')
                require(shadow.ledger._bindings[d.origin.core].terms_evidence==terms['governing_right'],'SuccessorGoverningRightMismatch')
            require(recipe.program.identity not in [r['program'] for r in state['instances'].values()],'SuccessorAlreadyActive')
            rep=digest(p);c['representations'][rep]={'program':recipe.program.identity,'context':recipe.program.context_id,
                'rows':rows,'outputs':p['outputs'],'shadow_ledger':dp.ledger_dump(shadow.ledger),
                'shadow_checkpoint':shadow.checkpoint(self.key).decode(),'relation':RELATION,'request':p}
            c['active']=rep;c['canonical']['rows']=rows;c['canonical']['binding']=['P08-shadow',recipe.program.identity,RELATION,c['policy']['name']]
            c['canonical']['revision']+=1
            receipt={'representation':rep,'request':digest(p),'original_ledger_sha256':digest(state['ledger'])}
            c['receipts'][p['nonce']]=receipt
            dp.fault('after_action',fault_at);self._write(db,state,state['revision'])
            require(digest(c['canonical']['journal'])==p['canonical_journal'],'CarriageChangedCanonicalJournal')
            dp.fault('after_write',fault_at);dp.fault('before_commit',fault_at);db.commit();dp.fault('after_commit',fault_at)
            return receipt

    def route(self, alias):
        state=self.snapshot();c=state['carriage'];rep=c['representations'][c['active']]
        require(alias in rep['rows'],'InactiveDutyAlias')
        result=[]
        for root,start,stop in rep['rows'][alias]:
            spec=c['roots'][root]
            result.append({'root':root,'portion':[start,stop],'instance':spec['instance'],'program':spec['program'],
                'context':spec['context'],'due':spec['due'],'binding':spec['binding'],'op_binding':spec['op_binding']})
        return result

    def allocate_alias(self, representation, alias, command_id, occurrence, amount, authority,
                       *, expected_base, physical_slices=None, fault_at=None):
        request=(representation,alias,command_id,occurrence,amount,authority,physical_slices)
        with self._connection() as db:
            db.execute('BEGIN IMMEDIATE');state=self._load(db);c=state['carriage']
            key='alias-payment:'+command_id;previous=c['receipts'].get(key)
            if previous is not None:
                require(previous['request']==digest(request),'AliasPaymentConflict');return previous
            require(c['active']==representation and expected_base==digest(state),'StaleAliasPayment')
            rows=c['representations'][representation]['rows'];require(alias in rows,'InactiveDutyAlias')
            support=duty.cells(rows[alias],c['canonical']['journal']['duties']);quanta={c['roots'][r]['quantum'] for r,_ in support}
            require(len(quanta)==1,'ScalarAliasQuantum');quantum=next(iter(quanta));count=units(amount,quantum);require(count>0,'PositiveAliasPayment')
            available=[x for x in support if c['canonical']['journal']['duties'][x[0]]['labels'][x[1]]=='Payable']
            require(len(available)>=count,'AliasPortionsAlreadyPaid')
            ledger=dp.ledger_load(state['ledger']);canonical=ledger._canonical(occurrence)
            physical_root=digest(('p08-physical-occurrence',canonical));credit=c['canonical']['journal']['credits'].get(physical_root)
            require(credit is not None,'UnregisteredPhysicalCredit')
            physical=physical_slices if physical_slices is not None else [i for i in range(1,credit['quantity']+1) if i not in credit['used']][:count]
            require(type(physical) is list and len(physical)==count and len(set(physical))==count,'PhysicalSliceQuantity')
            require(all(type(i) is int and 1<=i<=credit['quantity'] and i not in credit['used'] for i in physical),'PhysicalSliceReissue')
            dp.fault('before_action',fault_at);selected=available[:count];grouped={}
            for root,i in selected:grouped.setdefault(root,[]).append([root,i])
            offset=0;allocations=[]
            for root,cells_ in grouped.items():
                allocation_id=key+':'+root;quantity=len(cells_)
                c['allocation_cells'][allocation_id]=cells_
                c['physical_cells'][allocation_id]={'root':physical_root,'cells':physical[offset:offset+quantity]};offset+=quantity
                allocations.append(ledger.allocate(allocation_id,canonical,c['roots'][root]['due'],quantity*quantum,authority))
            state['ledger']=dp.ledger_dump(ledger);receipt={'request':digest(request),'allocations':tuple(allocations),'canonical_cells':selected}
            c['receipts'][key]=receipt;dp.fault('after_action',fault_at);self._write(db,state,state['revision'])
            dp.fault('after_write',fault_at);dp.fault('before_commit',fault_at);db.commit();dp.fault('after_commit',fault_at)
            return receipt
