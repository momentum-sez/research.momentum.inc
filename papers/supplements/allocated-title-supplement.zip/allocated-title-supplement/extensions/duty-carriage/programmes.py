"""Resolve finite duty-carriage fixtures through the pinned P08 evaluator.

The fixtures compare already resolved duties at height four. They do not
establish equivalence for other inputs, future heights, or arbitrary programs.
Evidence identifiers name fixture inputs. They do not grant migration authority.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
import hashlib
import importlib.util
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[2]
P08 = ROOT / "models/financial-evaluator"
PINNED_DIRECTORY = P08 / "durable-evaluator-rate-provenance"
PINNED_FILES = {
    "evaluator.py": "d0738a9ae295e303826e8d8319ef000604bade1de3b19c0d2acfad44f796e2f7",
    "programs.py": "8d2cee4a5b8530166db0df662d261eb9f9cda55d02e5a79f1689d9b8741e2539",
}


def _load_pinned(name, filename):
    path = (PINNED_DIRECTORY / filename).resolve()
    if hashlib.sha256(path.read_bytes()).hexdigest() != PINNED_FILES[filename]:
        raise RuntimeError(f"Pinned P08 source changed: {filename}")
    existing = sys.modules.get(name)
    if existing is not None:
        loaded_path = Path(getattr(existing, "__file__", "")).resolve()
        if loaded_path != path:
            raise RuntimeError(f"Another module occupies the pinned import: {name}")
        return existing
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load pinned P08 source: {filename}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


ev = _load_pinned("evaluator", "evaluator.py")
original = _load_pinned("_p09_p08_original_programs", "programs.py")
ft, ent = ev.ft, ev.ent

for module, relative_path in (
    (ft, "types/financial_types.py"),
    (ev.num, "numeric/exact_numeric.py"),
    (ev.sched, "schedules/admission.py"),
    (ev.readiness, "schedules/readiness.py"),
    (ent, "entitlements/entitlement_model.py"),
):
    if Path(module.__file__).resolve() != (P08 / "reference" / relative_path).resolve():
        raise RuntimeError(f"Another module occupies the P08 reference import: {relative_path}")


CONTEXT = original.CONTEXT
ISSUANCE = "coupon-issuance"
POSITION_LOT = "lot:1"
OBLIGOR = "issuer"
BENEFICIARY = "holder"
ASSET = "USD"
POSITION_CONTEXT = "governing-route:retained-residual"
COUPON_NAME = "coupon"
COUPON_HEIGHT = 4
SPLIT_LEGS = ("payoff:split-20", "payoff:split-10")
COALESCED_LEG = "payoff:coalesced"
HEIGHT_FOUR = ev.sched.Descriptor(5, 1, F=frozenset((COUPON_HEIGHT,)))


@dataclass(frozen=True)
class EvaluationRecipe:
    """Supply requests and observations to the actual evaluator."""

    program: ev.Program
    requests: tuple[tuple[str, int], ...]
    observations: tuple[ev.Observation, ...]
    now: int

    @property
    def context_id(self):
        return self.program.context_id


def original_program():
    """Return the unchanged P08 memory-coupon program."""
    return original.coupon_program()


def _finite_program(*, amount, shares, beneficiary=BENEFICIARY, asset=ASSET, scale=F(1)):
    money = ft.Theta(ft.Group.atom(asset), scale, ev.INSTANCE_DUE)
    declaration = ft.Declaration("resolved-coupon", F(amount), money)
    positions = tuple(
        ev.Position(
            ISSUANCE, POSITION_LOT, leg, F(quantity), OBLIGOR, beneficiary,
            asset, POSITION_CONTEXT, "position:issued", "terms:issued",
        )
        for leg, quantity in shares
    )
    claim = ev.Claim(
        COUPON_NAME, HEIGHT_FOUR,
        (ev.Case(HEIGHT_FOUR, ev.Const(declaration.name)),),
        money, (declaration,), positions,
    )
    return ev.Program((claim,), (), CONTEXT)


def split_program():
    """Resolve one thirty-dollar coupon into twenty-dollar and ten-dollar duties."""
    return _finite_program(
        amount=30,
        shares=((SPLIT_LEGS[0], F(2, 3)), (SPLIT_LEGS[1], F(1, 3))),
    )


def coalesced_program():
    """Resolve one thirty-dollar duty under a distinct finite program and core key."""
    return _finite_program(amount=30, shares=((COALESCED_LEG, F(1)),))


def wrong_amount_program():
    """Resolve twenty dollars and eleven dollars with the original parties."""
    return _finite_program(
        amount=31,
        shares=((SPLIT_LEGS[0], F(20, 31)), (SPLIT_LEGS[1], F(11, 31))),
    )


def wrong_beneficiary_program():
    """Resolve the split coupon for a different beneficiary."""
    return _finite_program(
        amount=30, beneficiary="holder:other",
        shares=((SPLIT_LEGS[0], F(2, 3)), (SPLIT_LEGS[1], F(1, 3))),
    )


def wrong_asset_program():
    """Resolve twenty euros and ten euros with a valid euro unit."""
    return _finite_program(
        amount=30, asset="EUR",
        shares=((SPLIT_LEGS[0], F(2, 3)), (SPLIT_LEGS[1], F(1, 3))),
    )


def wrong_unit_program():
    """Resolve thirty nominal cents as three tenths of a canonical dollar."""
    return _finite_program(
        amount=30, scale=F(1, 100),
        shares=((SPLIT_LEGS[0], F(2, 3)), (SPLIT_LEGS[1], F(1, 3))),
    )


def original_recipe():
    """Evaluate the recorded zero, zero, one, one trigger sequence."""
    return EvaluationRecipe(
        original_program(),
        tuple((COUPON_NAME, h) for h in (2, 3, 4, 5)),
        tuple(original.observation("trigger", h, value)
              for h, value in ((2, 0), (3, 0), (4, 1), (5, 1))),
        5,
    )


def finite_recipe(program):
    """Request only the declared height-four coupon."""
    return EvaluationRecipe(program, ((COUPON_NAME, COUPON_HEIGHT),), (), COUPON_HEIGHT)


def evaluate(recipe):
    """Resolve the recipe in a fresh ledger and return the actual evaluator."""
    if type(recipe) is not EvaluationRecipe:
        raise TypeError("Supply an EvaluationRecipe.")
    evaluator = ev.Evaluator(recipe.program, ledger=ent.EntitlementLedger())
    for name, height in recipe.requests:
        evaluator.request(name, height, context_id=recipe.context_id)
    for observation in recipe.observations:
        evaluator.offer(observation, context_id=recipe.context_id)
    report = evaluator.run(now=recipe.now, context_id=recipe.context_id)
    if report["status"] != "Resolved":
        raise ev.Invalid("FixtureDidNotResolve")
    return evaluator

