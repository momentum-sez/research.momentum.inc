"""The pinned P09 adoption body joins the physical source transaction.

Only connection ownership and final commit ownership change. The pinned root
validation, canonical constructor, MAC writer, and state fence stay intact.
"""
from durable_physical import cs
from copy import deepcopy

dp, require, ERROR = cs.dp, cs.require, cs.ERROR
verified, digest, units, duty = cs.verified, cs.digest, cs.units, cs.duty
RELATION = cs.RELATION


class TransactionAdoption(cs.CarriageStore):
    @classmethod
    def adopt(cls, path, key, envelope, policy, *, source, fault_at=None):
        # The old client performs schema-one validation, not a guessed reader.
        old=source
        with old._connection() as db:
            db.execute('BEGIN IMMEDIATE'); prior=old._load(db)
            p=verified(envelope,policy)
            require(set(p)=={'kind','relation','authority_epoch','authority_policy','base','roots'},'AdoptionShape')
            require(p['kind']=='Adopt' and p['base']==digest(prior),'StaleAdoptionBase')
            dp.fault('before_action',fault_at)
            state=deepcopy(prior); ledger=dp.ledger_load(state['ledger'])
            roots={}; seen=set(); asset_quanta={}
            for spec in p['roots']:
                require(set(spec)=={'root','origin','instance','due','quantum','unit','op_binding'},'RootBindingShape')
                root=spec['root']; due_id=spec['due']
                require(root==duty.economic_id(*spec['origin']) and root not in roots and due_id not in seen,'DuplicateEconomicDuty')
                require(due_id in ledger._dues and spec['instance'] in state['instances'],'UnknownResolvedDuty')
                due=ledger._dues[due_id]; binding=ledger._bindings[due_id.core]
                instance=state['instances'][spec['instance']]
                require(binding.program_digest==instance['program'],'OriginalProgramBindingMismatch')
                require(due_id.act=='resolution','ExplicitCorrectionCarriageRequired')
                count=units(due.amount,spec['quantum']); require(count>0,'PositiveCarriedDuty')
                require(type(spec['unit']) is str and spec['unit'],'NamedCanonicalUnit')
                if due.asset in asset_quanta:
                    require(asset_quanta[due.asset]==(spec['quantum'],spec['unit']),'OneCanonicalAssetQuantum')
                asset_quanta[due.asset]=(spec['quantum'],spec['unit'])
                roots[root]={**deepcopy(spec),'program':instance['program'],'context':instance['context'],
                    'binding':binding,'original_due':due,'quantity':count}
                seen.add(due_id)
            require(roots,'NonemptyCarriageScope')
            state['schema']=2
            state['carriage']={'policy':deepcopy(policy),'roots':roots,'asset_quanta':asset_quanta,
                'source_state_sha256':digest(prior),'source_revision':prior['revision'],
                'allocation_cells':{},'restored_cells':{},'physical_cells':{},
                'representations':{},'active':'original','receipts':{},'canonical':None}
            cls._initialize(state,ledger)
            state['carriage']['representations']['original']={'rows':{r:[[r,0,x['quantity']]] for r,x in roots.items()},'outputs':(), 'program':None}
            state['carriage']['canonical']['rows']=deepcopy(state['carriage']['representations']['original']['rows'])
            dp.fault('after_action',fault_at)
            # Use the pinned writer for the real CAS, MAC and size check.
            successor=object.__new__(cls)
            successor.__dict__.update(old.__dict__)
            dp.DurableEvaluator._write(successor,db,state,prior['revision'])
            dp.fault('after_write',fault_at);dp.fault('before_commit',fault_at)
            # The enclosing physical transaction commits both records.
        return state

