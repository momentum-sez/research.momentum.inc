from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest

from durable_physical import DurablePhysicalBook, pf, cs, ent, Rejected, digest, wire

FIXTURE = pf.REFERENCE if hasattr(pf, "REFERENCE") else Path(pf.__file__).with_name("test_performance.py")
if hashlib.sha256(FIXTURE.read_bytes()).hexdigest() != "8b231bd495ee638bf5675f9cbc264b0f21c8ed4ad10fe5e3eae4b83521164adc":
    raise RuntimeError("ChangedPhysicalFixture")
sys.modules["performance"] = pf
spec = importlib.util.spec_from_file_location("p14_physical_fixtures", FIXTURE)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
AUTH, KEYS, STORE_KEY, NOW = fixture.AUTH, fixture.KEYS, fixture.STORE_KEY, fixture.NOW
contract, request, fact = fixture.contract, fixture.request, fixture.fact
ADMISSION = pf.public_hex(AUTH.public_key())
POLICY = {"key": ADMISSION, "epoch": 0, "name": "synthetic-carriage-authority"}
HERE = Path(__file__).resolve().parent


def reopen(path):
    return DurablePhysicalBook(path, STORE_KEY, ADMISSION)


def credit(identity, amount, recipient="seller"):
    occurrence = ent.OccurrenceKey("synthetic-bank", "RecipientCredit", identity)
    report = ent.CreditReport("report:" + identity, occurrence,
        ent.Credit(occurrence, recipient, "USD", F(amount), "booked"), "synthetic-bank", "sale-right")
    return occurrence, report


class DurablePhysicalTests(unittest.TestCase):
    def setUp(self):
        work = HERE / "work"
        work.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="physical-", dir=work)
        self.path = Path(self.temp.name) / "physical.sqlite"
        self.book = reopen(self.path)
        self.contract = contract()
        self.book.register("register-sale", pf.signed(AUTH, self.contract))

    def tearDown(self):
        self.temp.cleanup()

    def accept(self, command="accept", **kwargs):
        return self.book.submit(command, "sale", request(self.contract, **kwargs), NOW)

    def test_partial_acceptance_survives_restart_with_exact_due_and_replay(self):
        result = self.accept()
        before = self.book.snapshot()
        self.book = reopen(self.path)
        after = self.book.snapshot()
        self.assertEqual(after["source"], before["source"])
        self.assertEqual(after["ledger"], before["ledger"])
        self.assertEqual(after["book"].ledger.outstanding(result["due"]), 400)
        self.assertEqual(after["book"].balance("sale")["remaining_performance"], 60)
        self.assertEqual(self.accept(), result)
        self.assertEqual(self.book.submit("another-command", "sale", request(self.contract), NOW), result)
        self.assertEqual(len(self.book.snapshot()["book"].ledger.dues()), 1)

    def test_dispute_and_assay_head_survive_restart(self):
        result = self.accept(quality=F(9, 10), serial=2)
        self.assertEqual(result["status"], "Disputed")
        self.book = reopen(self.path)
        self.assertEqual(self.book.snapshot()["book"].balance("sale")["disputed_offered_quantity"], 40)
        with self.assertRaisesRegex(Rejected, "StaleAssay"):
            self.accept("old-good", act="old-good", serial=1)
        self.accept("cure", act="cure", stop=F(10), serial=3)
        self.assertEqual(self.book.snapshot()["book"].balance("sale")["disputed_offered_quantity"], 30)

    def test_invalid_document_rolls_back_source_and_actual_ledger(self):
        before = self.book.snapshot()
        invalid = request(self.contract, quality=F(9, 10), serial=4)
        invalid["documents"]["title"]["signature"] = "00" * 64
        payload = invalid["acceptance"]["payload"]
        payload["evidence"] = digest({k: v for k, v in invalid.items() if k != "acceptance"})
        invalid["acceptance"] = pf.signed(KEYS["acceptance"], payload)
        with self.assertRaisesRegex(Rejected, "Authentication"):
            self.book.submit("bad", "sale", invalid, NOW)
        after = reopen(self.path).snapshot()
        self.assertEqual((after["source"], after["ledger"]), (before["source"], before["ledger"]))

    def test_old_source_head_and_two_workers_cannot_allocate_same_performance(self):
        stale = self.book.head()
        other = reopen(self.path)
        def run(pair):
            writer, identity = pair
            try:
                return writer.submit(identity, "sale", request(self.contract, act=identity), NOW)["status"]
            except Rejected as error:
                return str(error)
        with ThreadPoolExecutor(max_workers=2) as pool:
            answers = list(pool.map(run, ((self.book, "worker-a"), (other, "worker-b"))))
        self.assertCountEqual(answers, ["Earned", "PerformanceAlreadyAllocated"])
        with self.assertRaisesRegex(Rejected, "StalePhysicalSource"):
            self.book.submit("later", "sale", request(self.contract, act="later", start=F(40), stop=F(50)), NOW, expected_source=stale)

    def test_two_disjoint_workers_preserve_both_partial_entitlements(self):
        other = reopen(self.path)
        def run(item):
            writer, identity, start, stop = item
            return writer.submit(identity, "sale", request(self.contract, act=identity, start=start, stop=stop), NOW)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(run, ((self.book, "first", F(0), F(40)), (other, "second", F(40), F(70)))))
        self.assertEqual(sum(x["earned"] for x in results), 700)
        self.assertEqual(self.book.snapshot()["book"].balance("sale")["remaining_performance"], 30)

    def test_unpaid_handover_fences_reopened_and_cached_source_writers(self):
        result = self.accept()
        old = cs.dp.DurableEvaluator(self.path, STORE_KEY)
        p = pf.program(self.contract)
        handle = old.handle("sale", p)
        before = self.book.snapshot()["ledger"]
        receipt = self.book.handover(AUTH, POLICY)
        reopened = reopen(self.path)
        self.assertTrue(reopened.snapshot()["source"]["closed"])
        self.assertEqual(reopened.snapshot()["ledger"], before)
        self.assertEqual(reopened.handover(AUTH, POLICY), receipt)
        self.assertEqual(reopened.submit("accept", "sale", request(self.contract), NOW), result)
        for writer in (self.book, reopened):
            with self.assertRaisesRegex(Rejected, "ClosedCohort"):
                writer.submit("later", "sale", request(self.contract, act="later", start=F(40), stop=F(50)), NOW)
        with self.assertRaisesRegex(cs.ERROR, "StoreRevisionMismatch"):
            old.apply(handle, p, "stale-source-request", "evaluator", "request", "earned", 2)
        with self.assertRaisesRegex(cs.ERROR, "StoreRevisionMismatch"):
            cs.dp.DurableEvaluator(self.path, STORE_KEY)

    def test_paid_and_corrected_history_survives_handover_without_new_original_due(self):
        accepted = self.accept()
        occurrence, report = credit("paid-credit", 400)
        self.book.ledger("credit", "sale", "record_credit", report)
        self.book.ledger("pay", "sale", "allocate", "payment", occurrence, accepted["due"], F(400), "synthetic-payment-rule")
        correction = fact(self.contract, "correction", "adjustment", economic=accepted["economic"],
            expected_head="resolution", target=F(100), basis="synthetic-quality-decision")
        changed = self.book.correct("correct", accepted["economic"], correction, NOW)
        self.assertEqual(changed.due.amount, 300)
        before = reopen(self.path).snapshot()["ledger"]
        self.book.handover(AUTH, POLICY)
        carried = self.book.carriage()
        self.assertEqual(carried.snapshot()["ledger"], before)
        ledger = cs.dp.ledger_load(before)
        self.assertEqual(ledger.outstanding(accepted["due"]), 0)
        self.assertEqual(ledger.outstanding(changed.due.origin), 300)
        self.assertEqual(len(ledger.dues()), 2)
        root = next(iter(carried.snapshot()["carriage"]["roots"]))
        self.assertEqual(carried.snapshot()["carriage"]["canonical"]["journal"]["duties"][root]["labels"].count("Payable"), 0)
        refund, report = credit("recovery-credit", 300, recipient="buyer")
        p = pf.program(self.contract)
        answer = carried.apply(carried.handle("sale", p), p, "recovery-credit", "ledger", "record_credit", report)
        self.assertEqual(answer["outcome"]["status"], "Ok")
        answer = carried.apply(carried.handle("sale", p), p, "recovery-allocation", "ledger", "allocate",
            "recovery", refund, changed.due.origin, F(300), "synthetic-recovery-rule")
        self.assertEqual(answer["outcome"]["status"], "Ok")
        self.assertEqual(reopen(self.path).snapshot()["book"].ledger.outstanding(changed.due.origin), 0)

    def test_untracked_ledger_write_does_not_mint_entitlement(self):
        self.accept()
        old = cs.dp.DurableEvaluator(self.path, STORE_KEY)
        p = pf.program(self.contract)
        _, report = credit("outside-write", 20)
        old.apply(old.handle("sale", p), p, "outside-write", "ledger", "record_credit", report)
        with self.assertRaisesRegex(Rejected, "UntrackedPhysicalLedgerChange"):
            self.book.submit("later", "sale", request(self.contract, act="later", start=F(40), stop=F(50)), NOW)

    def test_conversion_basis_and_evidence_reuse_survive_restart(self):
        energy = contract("energy", "energy-right", unit="GJ", quantity=F(1000))
        self.book.register("register-energy", pf.signed(AUTH, energy))
        result = self.book.submit("energy-one", "energy", request(energy, act="energy-one", event="energy-cargo", stop=F(2), unit="m3", factor=F(25)), NOW)
        self.assertEqual((result["quantity"], result["earned"]), (F(50), F(50)))
        self.book = reopen(self.path)
        with self.assertRaisesRegex(Rejected, "ConversionRevisionRequired"):
            self.book.submit("energy-two", "energy", request(energy, act="energy-two", event="energy-cargo", start=F(2), stop=F(3), unit="m3", factor=F(100)), NOW)
        handling = contract("handling", "handling-right", total_price=F(50), authority_basis="synthetic-handling-act")
        self.book.register("register-handling", pf.signed(AUTH, handling))
        self.accept()
        self.assertEqual(self.book.submit("handle", "handling", request(handling), NOW)["earned"], F(20))

    def test_joined_adoption_matches_the_pinned_standalone_constructor(self):
        accepted = self.accept()
        occurrence, report = credit("part-payment", 100)
        self.book.ledger("credit", "sale", "record_credit", report)
        self.book.ledger("pay", "sale", "allocate", "payment", occurrence, accepted["due"], F(100), "synthetic-payment-rule")
        comparison = Path(self.temp.name) / "standalone.sqlite"
        import sqlite3
        with self.book.io._connection() as source:
            with sqlite3.connect(comparison) as destination:
                source.backup(destination)
        old = cs.dp.DurableEvaluator(comparison, STORE_KEY)
        with old._connection() as db:
            db.execute("BEGIN")
            state = old._load(db)
        roots = [cs.root_spec("sale", accepted["due"], ["physical-performance", "sale-right", accepted["economic"]], quantum=F(1), unit="USD")]
        envelope = cs.signed(AUTH, {"kind": "Adopt", "relation": cs.RELATION,
            "authority_epoch": 0, "authority_policy": digest(POLICY), "base": digest(state), "roots": roots})
        expected = cs.CarriageStore.adopt(comparison, STORE_KEY, envelope, POLICY).snapshot()
        self.book.handover(AUTH, POLICY)
        self.assertEqual(self.book.carriage().snapshot(), expected)

    def test_handover_and_later_intake_have_one_serial_outcome(self):
        self.accept()
        other = reopen(self.path)
        ready = threading.Barrier(2)
        def intake():
            ready.wait(10)
            try:
                return other.submit("second", "sale", request(self.contract, act="second", start=F(40), stop=F(50)), NOW)["status"]
            except Rejected as error:
                return str(error)
        def close():
            ready.wait(10)
            return self.book.handover(AUTH, POLICY)
        with ThreadPoolExecutor(max_workers=2) as pool:
            accepted = pool.submit(intake)
            closed = pool.submit(close)
            outcome = accepted.result(10)
            closed.result(10)
        snapshot = reopen(self.path).snapshot()
        self.assertTrue(snapshot["source"]["closed"])
        self.assertIn(outcome, ("Earned", "ClosedCohort"))
        self.assertEqual(len(snapshot["book"].ledger.dues()), 2 if outcome == "Earned" else 1)

    def test_separate_processes_cannot_reuse_one_physical_interval(self):
        children = [subprocess.Popen([sys.executable, "-B", *(["-O"] if sys.flags.optimize else []),
            str(HERE / "worker.py"), str(self.path), "race", identity], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            for identity in ("process-one", "process-two")]
        answers = []
        for child in children:
            stdout, stderr = child.communicate(timeout=15)
            self.assertEqual(child.returncode, 0, stderr.decode())
            answers.append(stdout.decode().strip())
        self.assertCountEqual(answers, ["Earned", "PerformanceAlreadyAllocated"])
        self.assertEqual(len(reopen(self.path).snapshot()["book"].ledger.dues()), 1)

    def test_source_authentication_detects_a_forged_fence(self):
        self.accept()
        self.book.handover(AUTH, POLICY)
        with self.book.io._connection() as db:
            db.execute("UPDATE physical_source SET body=? WHERE id=1", (b'{}',))
        with self.assertRaisesRegex(Rejected, "PhysicalSourceAuthentication"):
            reopen(self.path)

    def test_caller_mutation_cannot_change_the_committed_source_event(self):
        offered = request(self.contract)
        entered, release = threading.Event(), threading.Event()
        materialize = self.book._materialize
        def paused(*args, **kwargs):
            entered.set()
            self.assertTrue(release.wait(10))
            return materialize(*args, **kwargs)
        self.book._materialize = paused
        with ThreadPoolExecutor(max_workers=1) as pool:
            pending = pool.submit(self.book.submit, "freeze", "sale", offered, NOW)
            self.assertTrue(entered.wait(10))
            offered["measurement"]["payload"]["quantity"] = F(200)
            release.set()
            accepted = pending.result(10)
        stored = reopen(self.path).snapshot()
        self.assertEqual(stored["book"].ledger.outstanding(accepted["due"]), 400)
        saved = stored["source"]["events"][-1]["args"][1]
        self.assertEqual(saved["measurement"]["payload"]["quantity"], F(100))

    def test_intake_process_termination_is_atomic_and_exactly_replayable(self):
        before = self.book.snapshot()
        for point in ("before_action", "after_action", "after_write", "before_commit", "after_commit"):
            with self.subTest(point=point):
                result = subprocess.run([sys.executable, "-B", *(["-O"] if sys.flags.optimize else []), str(HERE / "worker.py"), str(self.path), "submit", point], capture_output=True)
                self.assertEqual(result.returncode, 77, result.stderr.decode())
                after = reopen(self.path).snapshot()
                if point != "after_commit":
                    self.assertEqual((after["source"], after["ledger"]), (before["source"], before["ledger"]))
                else:
                    self.assertEqual(len(after["book"].ledger.dues()), 1)
                    self.assertEqual(self.accept(), self.accept())

    def test_handover_process_termination_keeps_fence_and_p09_state_atomic(self):
        self.accept()
        before = self.book.snapshot()
        for point in ("before_action", "after_action", "after_write", "after_fence", "before_commit", "after_commit"):
            with self.subTest(point=point):
                result = subprocess.run([sys.executable, "-B", *(["-O"] if sys.flags.optimize else []), str(HERE / "worker.py"), str(self.path), "handover", point], capture_output=True)
                self.assertEqual(result.returncode, 77, result.stderr.decode())
                after = reopen(self.path).snapshot()
                self.assertEqual(after["ledger"], before["ledger"])
                if point != "after_commit":
                    self.assertFalse(after["source"]["closed"])
                    self.assertEqual(after["source"], before["source"])
                else:
                    self.assertTrue(after["source"]["closed"])
                    self.assertEqual(self.book.handover(AUTH, POLICY), after["source"]["handover"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
