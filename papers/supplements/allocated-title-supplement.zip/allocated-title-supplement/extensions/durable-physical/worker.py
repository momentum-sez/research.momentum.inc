"""Terminate a real worker at a named durable transition."""
from pathlib import Path
import sys
from test_durable_physical import reopen, request, contract, NOW, AUTH, POLICY
from durable_physical import Rejected

path, method, point = sys.argv[1:]
book = reopen(Path(path))
if method == "submit":
    book.submit("accept", "sale", request(contract()), NOW, fault_at=point)
elif method == "handover":
    book.handover(AUTH, POLICY, fault_at=point)
elif method == "race":
    try:
        print(book.submit(point, "sale", request(contract(), act=point), NOW)["status"])
    except Rejected as error:
        print(str(error))
else:
    raise RuntimeError("UnknownWorkerMethod")
