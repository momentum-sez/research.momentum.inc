"""Durable physical performance and atomic carriage on one SQLite authority."""
from contextlib import contextmanager
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import hmac
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
REFERENCE = ROOT / "models/physical-performance/reference/performance.py"
EXPECTED = "2f276a4c95cd9df337dc4debbf871c3be4ec96d0f801eb0a9f38e93af2501d3f"
if hashlib.sha256(REFERENCE.read_bytes()).hexdigest() != EXPECTED:
    raise RuntimeError("ChangedPhysicalPerformanceDependency")
spec = importlib.util.spec_from_file_location("p14_durable_physical_reference", REFERENCE)
pf = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = pf
spec.loader.exec_module(pf)
cs, ev, ent = pf.cs, pf.ev, pf.ent
digest, wire, require, Rejected = pf.digest, pf.wire, pf.require, pf.Rejected


class BorrowedConnection:
    def __init__(self, db):
        self.db = db

    def execute(self, statement, *args):
        if statement in ("BEGIN", "BEGIN IMMEDIATE"):
            require(self.db.in_transaction, "MissingPhysicalTransaction")
            return self.db.execute("SELECT 1")
        return self.db.execute(statement, *args)

    def commit(self):
        require(self.db.in_transaction, "MissingPhysicalTransaction")


class JoinedEvaluator(cs.dp.DurableEvaluator):
    @contextmanager
    def _connection(self):
        yield BorrowedConnection(self.borrowed)


def joined(io, db):
    store = object.__new__(JoinedEvaluator)
    store.__dict__.update(io.__dict__)
    store.borrowed = db
    return store


def replay(record):
    book = pf.PhysicalBook(record["admission_key"])
    for event in record["events"]:
        method, args, kwargs = event["method"], event["args"], event["kwargs"]
        if method == "ledger":
            result = getattr(book.ledger, args[1])(*args[2], **kwargs)
        else:
            require(method in {"register", "submit", "correct"}, "UnknownPhysicalEvent")
            result = getattr(book, method)(*args, **kwargs)
        require(digest(result) == event["result"], "PhysicalReplayMismatch")
    return book


class DurablePhysicalBook:
    """Each method reloads the source under the shared SQLite write lock."""
    def __init__(self, path, key, admission_key):
        require(type(key) is bytes and len(key) >= 32, "StoreKeyTooShort")
        self.path, self.key = Path(path), key
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.io = object.__new__(cs.dp.DurableEvaluator)
        self.io.path, self.io.key = self.path, key
        self.io.max_snapshot_bytes = 32_000_000
        self.io.max_command_bytes = 4_000_000
        with self.io._connection() as db:
            db.execute("CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, body BLOB NOT NULL, mac TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS physical_source (id INTEGER PRIMARY KEY CHECK(id=1), body BLOB NOT NULL, mac TEXT NOT NULL)")
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM state WHERE id=1").fetchone() is None:
                require(db.execute("SELECT 1 FROM physical_source WHERE id=1").fetchone() is None, "MissingPhysicalLedger")
                state = {"schema": 1, "revision": 0, "ledger": cs.dp.ledger_dump(ent.EntitlementLedger()),
                         "heads": {}, "instances": {}, "commands": {}}
                body, mac = self.io._seal(state)
                db.execute("INSERT INTO state VALUES(1,0,?,?)", (body, mac))
                self._save(db, {"version": 1, "admission_key": admission_key, "events": (),
                               "commands": {}, "revision": 0, "closed": False, "handover": None})
            record = self._load(db)
            require(record["admission_key"] == admission_key, "PhysicalAdmissionKeyConflict")
            self._state(db, record)
            db.commit()

    def _load(self, db):
        row = db.execute("SELECT body,mac FROM physical_source WHERE id=1").fetchone()
        require(row is not None, "ExistingPhysicalSourceRequired")
        body, mac = row
        require(len(body) <= 32_000_000 and hmac.compare_digest(
            mac, hmac.digest(self.key, b"P14-physical-source/1\0" + body, "sha256").hex()),
            "PhysicalSourceAuthentication")
        record = cs.decode(cs.dp.strict_json(body))
        require(record["version"] == 1, "PhysicalSourceVersion")
        return record

    def _save(self, db, record):
        body = wire(record)
        require(len(body) <= 32_000_000, "PhysicalSourceSizeLimit")
        mac = hmac.digest(self.key, b"P14-physical-source/1\0" + body, "sha256").hex()
        db.execute("INSERT INTO physical_source VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,mac=excluded.mac", (body, mac))

    def _state(self, db, record):
        if record["closed"]:
            store = object.__new__(cs.CarriageStore)
            store.__dict__.update(self.io.__dict__)
            state = store._load(db)
            require(state["carriage"]["policy"] == record["handover"]["policy"], "PhysicalHandoverPolicyChanged")
            require(digest(state["carriage"]["roots"]) == record["handover"]["roots"], "PhysicalHandoverRootsChanged")
            return state
        return self.io._load(db)

    @staticmethod
    def _correspondence(book, state):
        require(cs.dp.ledger_dump(book.ledger) == state["ledger"], "UntrackedPhysicalLedgerChange")

    def snapshot(self):
        with self.io._connection() as db:
            db.execute("BEGIN")
            record = self._load(db)
            state = self._state(db, record)
            book = replay(record)
            if record["closed"]:
                book.ledger = cs.dp.ledger_load(state["ledger"])
                book.closed = True
            else:
                self._correspondence(book, state)
            return {"source": deepcopy(record), "ledger": deepcopy(state["ledger"]),
                    "book": book, "state_revision": state["revision"]}

    def head(self):
        with self.io._connection() as db:
            db.execute("BEGIN")
            return digest(self._load(db))

    def _operation(self, command, method, args, kwargs, *, expected_source=None, fault_at=None):
        pf.named(command)
        require(method in {"register", "submit", "correct", "ledger"}, "UnknownPhysicalOperation")
        require(fault_at in (None, "before_action", "after_action", "after_write", "before_commit", "after_commit"), "UnknownFaultPoint")
        request = deepcopy((method, args, kwargs))
        method, args, kwargs = request
        with self.io._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            record = self._load(db)
            state = self._state(db, record)
            prior = record["commands"].get(command)
            if prior is not None:
                require(prior["request"] == digest(request), "PhysicalCommandConflict")
                return deepcopy(prior["value"])
            require(not record["closed"], "ClosedCohort")
            require(expected_source is None or expected_source == digest(record), "StalePhysicalSource")
            book = replay(record)
            self._correspondence(book, state)
            cs.dp.fault("before_action", fault_at)
            if method == "ledger":
                require(args[1] in cs.dp.LEDGER_ACTIONS - {"correct_target"}, "PhysicalLedgerMethod")
                result = getattr(book.ledger, args[1])(*args[2], **kwargs)
            else:
                result = getattr(book, method)(*args, **kwargs)
            cs.dp.fault("after_action", fault_at)
            store = joined(self.io, db)
            self._materialize(store, book, command, method, args, kwargs, result)
            self._correspondence(book, store._load(db))
            record["events"] += ({"method": method, "args": deepcopy(args), "kwargs": deepcopy(kwargs),
                                   "result": digest(result)},)
            record["commands"][command] = {"request": digest(request), "value": deepcopy(result)}
            record["revision"] += 1
            self._save(db, record)
            cs.dp.fault("after_write", fault_at)
            cs.dp.fault("before_commit", fault_at)
            db.commit()
            cs.dp.fault("after_commit", fault_at)
            return deepcopy(result)

    @staticmethod
    def _materialize(store, book, command, method, args, kwargs, result):
        def apply(instance, action, service, operation, *values, **options):
            program = pf.program(book.contracts[instance])
            answer = store.apply(store.handle(instance, program), program,
                "physical:" + command + ":" + action, service, operation, *values, **options)
            require(answer["outcome"]["status"] == "Ok", "DurablePhysicalOperationRejected")
            return answer["outcome"]["value"]
        if method == "register":
            contract = args[0]["payload"]
            store.create(contract["id"], pf.program(contract))
        elif method == "submit" and result["status"] == "Earned":
            row = book.acceptances[result["economic"]]
            recipe = row["recipe"]
            instance = row["contract"]
            current = cs.dp.ledger_load(store.read(instance, recipe.program)["ledger"])
            if row["binding"].key in current._bindings:
                require(current._bindings[row["binding"].key] == row["binding"], "PhysicalOriginalBindingChanged")
                return
            apply(instance, "request", "evaluator", "request", "earned", row["height"], context_id=recipe.context_id)
            apply(instance, "offer", "evaluator", "offer", recipe.observations[0], context_id=recipe.context_id)
            apply(instance, "run", "evaluator", "run", now=row["height"], context_id=recipe.context_id)
        elif method == "correct":
            row = book.acceptances[args[0]]
            payload = args[1]["payload"]
            correction = ent.TargetCorrection(payload["id"], row["binding"].key, payload["expected_head"],
                                               F(payload["target"]), digest(args[1]))
            actual = apply(row["contract"], "correct", "ledger", "correct_target", correction)
            require(actual == result, "PhysicalCorrectionMismatch")
        elif method == "ledger":
            actual = apply(args[0], "ledger", "ledger", args[1], *args[2], **kwargs)
            require(actual == result, "PhysicalLedgerResultMismatch")

    def register(self, command, envelope, **options):
        return self._operation(command, "register", (envelope,), {}, **options)

    def submit(self, command, contract, request, now, **options):
        return self._operation(command, "submit", (contract, request, now), {}, **options)

    def correct(self, command, economic, envelope, now, **options):
        return self._operation(command, "correct", (economic, envelope, now), {}, **options)

    def ledger(self, command, contract, method, *args, expected_source=None, fault_at=None, **kwargs):
        return self._operation(command, "ledger", (contract, method, args), kwargs,
                               expected_source=expected_source, fault_at=fault_at)

    def handover(self, authority, policy, *, quantum=F(1), expected_source=None, fault_at=None):
        from adoption import TransactionAdoption
        policy = deepcopy(policy)
        require(fault_at in (None, "before_action", "after_action", "after_write", "after_fence", "before_commit", "after_commit"), "UnknownFaultPoint")
        with self.io._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            record = self._load(db)
            state = self._state(db, record)
            if record["closed"]:
                require(record["handover"]["policy"] == policy and record["handover"]["quantum"] == quantum, "PhysicalHandoverConflict")
                return deepcopy(record["handover"])
            require(expected_source is None or expected_source == digest(record), "StalePhysicalSource")
            book = replay(record)
            self._correspondence(book, state)
            require(book.acceptances, "NonemptyPhysicalCohort")
            roots = []
            for economic, row in sorted(book.acceptances.items(), key=lambda item: (item[1]["contract"], item[1]["height"])):
                contract = book.contracts[row["contract"]]
                roots.append(cs.root_spec(row["contract"], row["result"]["due"],
                    ["physical-performance", contract["performance_right"], economic], quantum=quantum, unit=contract["asset"]))
            envelope = cs.signed(authority, {"kind": "Adopt", "relation": cs.RELATION,
                "authority_epoch": policy["epoch"], "authority_policy": digest(policy),
                "base": digest(state), "roots": roots})
            carried = TransactionAdoption.adopt(self.path, self.key, envelope, policy,
                source=joined(self.io, db), fault_at=fault_at)
            require(carried["ledger"] == state["ledger"], "PhysicalHandoverLedgerChanged")
            source_digest = digest(record)
            record["closed"] = True
            record["handover"] = {"policy": deepcopy(policy), "quantum": quantum,
                "source": source_digest, "ledger": digest(state["ledger"]),
                "roots": digest(carried["carriage"]["roots"]), "adoption": digest(envelope)}
            record["revision"] += 1
            self._save(db, record)
            cs.dp.fault("after_fence", fault_at)
            cs.dp.fault("before_commit", fault_at)
            db.commit()
            cs.dp.fault("after_commit", fault_at)
            return deepcopy(record["handover"])

    def carriage(self):
        with self.io._connection() as db:
            db.execute("BEGIN")
            record = self._load(db)
            require(record["closed"], "PhysicalHandoverRequired")
            self._state(db, record)
        return cs.CarriageStore(self.path, self.key)
