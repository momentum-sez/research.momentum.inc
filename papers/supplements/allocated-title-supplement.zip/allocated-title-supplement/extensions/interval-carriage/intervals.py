"""Exact finite interval operations. No operation enumerates interval members.

Spans are half-open integer intervals. Ordered span lists retain selection
order. Set operations sort only their right-hand membership operand.
"""


class InvalidInterval(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidInterval(message)


def extent(span, *, lower=0, upper=None):
    require(type(span) is list and len(span) == 2, 'IntervalShape')
    a, b = span
    require(type(a) is int and type(b) is int, 'IntegerIntervalEndpoints')
    require(lower <= a < b and (upper is None or b <= upper), 'IntervalExtent')
    return a, b


def measure(spans):
    return sum(b - a for a, b in spans)


def coalesce_ordered(spans):
    """Coalesce adjacent sequence entries without permuting their members."""
    result = []
    for span in spans:
        a, b = extent(span)
        if result and result[-1][1] == a:
            result[-1][1] = b
        else:
            result.append([a, b])
    return result


def union(spans, *, reject_overlap=False, lower=0, upper=None):
    result = []
    for a, b in sorted(extent(s, lower=lower, upper=upper) for s in spans):
        if result and a <= result[-1][1]:
            require(not reject_overlap or a == result[-1][1], 'OverlappingIntervals')
            result[-1][1] = max(result[-1][1], b)
        else:
            result.append([a, b])
    return result


def ordered(spans, *, lower=0, upper=None):
    require(type(spans) is list, 'IntervalList')
    union(spans, reject_overlap=True, lower=lower, upper=upper)
    return coalesce_ordered(spans)


def intersect(left, right):
    membership = union(right)
    result = []
    for a, b in left:
        for c, d in membership:
            if d <= a:
                continue
            if c >= b:
                break
            result.append([max(a, c), min(b, d)])
    return coalesce_ordered(result)


def subtract(left, right):
    membership = union(right)
    result = []
    for a, b in left:
        cursor = a
        for c, d in membership:
            if d <= cursor:
                continue
            if c >= b:
                break
            if cursor < c:
                result.append([cursor, min(c, b)])
            cursor = max(cursor, d)
            if cursor >= b:
                break
        if cursor < b:
            result.append([cursor, b])
    return coalesce_ordered(result)


def take(spans, count):
    require(type(count) is int and 0 <= count <= measure(spans), 'IntervalPrefixQuantity')
    selected, remainder = [], []
    for a, b in spans:
        n = min(count, b - a)
        if n:
            selected.append([a, a + n])
        if a + n < b:
            remainder.append([a + n, b])
        count -= n
    return coalesce_ordered(selected), coalesce_ordered(remainder)


def from_indices(indices, *, lower=0, upper=None):
    """Compress an already supplied legacy list, retaining its exact order."""
    require(type(indices) is list, 'IndexList')
    require(all(type(i) is int for i in indices), 'IntegerCellIdentity')
    spans = [[i, i + 1] for i in indices]
    return ordered(spans, lower=lower, upper=upper)


def validate_segments(segments, quantity):
    require(type(quantity) is int and quantity > 0, 'PositiveIntervalQuantity')
    require(type(segments) is list and segments, 'NonemptyLabelSegments')
    cursor = 0
    previous = None
    for segment in segments:
        require(type(segment) is list and len(segment) == 3, 'LabelSegmentShape')
        a, b, label = segment
        extent([a, b], upper=quantity)
        require(a == cursor, 'ExhaustiveLabelSegments')
        require(label in ('Contingent', 'Payable', 'Discharged'), 'DutyPhase')
        require(label != previous, 'CoalescedLabelSegments')
        cursor, previous = b, label
    require(cursor == quantity, 'ExhaustiveLabelSegments')


def phase_spans(segments, label):
    return [[a, b] for a, b, phase in segments if phase == label]


def relabel(segments, selected, old, new):
    selected = union(selected, reject_overlap=True)
    require(measure(intersect(selected, phase_spans(segments, old))) == measure(selected),
            'UnexpectedDutyPhase')
    result = []
    def append(a, b, label):
        if result and result[-1][1] == a and result[-1][2] == label:
            result[-1][1] = b
        else:
            result.append([a, b, label])
    for a, b, label in segments:
        cursor = a
        for c, d in intersect([[a, b]], selected):
            if cursor < c:
                append(cursor, c, label)
            append(c, d, new)
            cursor = d
        if cursor < b:
            append(cursor, b, label)
    return result


def triples(row, duties, *, nonempty=True):
    require(type(row) is list and (row or not nonempty), 'NonemptyDutyIntervals')
    grouped = {}
    result = []
    for item in row:
        require(type(item) is list and len(item) == 3, 'DutyIntervalShape')
        root, a, b = item
        require(root in duties, 'UnknownEconomicDuty')
        extent([a, b], upper=duties[root]['quantity'])
        grouped.setdefault(root, []).append([a, b])
        if result and result[-1][0] == root and result[-1][2] == a:
            result[-1][2] = b
        else:
            result.append([root, a, b])
    for spans in grouped.values():
        union(spans, reject_overlap=True)
    return result


def triple_measure(row):
    return sum(b - a for _, a, b in row)


def triple_take(row, count):
    require(type(count) is int and 0 <= count <= triple_measure(row), 'DutyPrefixQuantity')
    selected = []
    for root, a, b in row:
        n = min(count, b - a)
        if n:
            selected.append([root, a, a + n])
        count -= n
    return selected


def validate_rows(rows, journal):
    require(type(rows) is dict and rows, 'NonemptyFamilyRepresentation')
    duties = journal['duties']
    seen = {root: [] for root in duties}
    projection = {}
    for name, intervals in rows.items():
        require(type(name) is str and name, 'NamedAlias')
        support = triples(intervals, duties)
        terms = duties[support[0][0]]['terms']
        measures = dict.fromkeys(('Contingent', 'Payable', 'Discharged'), 0)
        for root, a, b in support:
            d = duties[root]
            require(d['terms'] == terms, 'HeterogeneousScalarRow')
            validate_segments(d['segments'], d['quantity'])
            seen[root].append([a, b])
            for label in measures:
                measures[label] += measure(intersect([[a, b]], phase_spans(d['segments'], label)))
        projection[name] = {'terms': dict(terms), **measures}
    for root, intervals in seen.items():
        require(union(intervals, reject_overlap=True) == [[0, duties[root]['quantity']]],
                'LostEconomicDutyCells')
    return projection
