"""Original physical admission predicates with explicit evaluator cohort identity."""
from copy import deepcopy
from fractions import Fraction as F
from continuation import pf, cohort_program
require, digest, exact, named, UNITS = pf.require, pf.digest, pf.exact, pf.named, pf.UNITS
pr = pf.pr


class ContinuationFamily(pf.PhysicalBook):
    def recipe(self, contract, height, amount, evidence):
        instance = self.instances[contract["id"]]["instance"]
        p = cohort_program(contract, instance)
        theta = pf.ft.Theta(pf.ft.Group.atom(contract["asset"]), F(1), pf.ev.INSTANCE_DUE)
        declaration = pf.ft.Declaration(evidence, exact(amount), pf.ev.at(theta, height),
            role="input", source="accepted-value", height=height, authority="performance")
        observation = pf.ev.Observation(declaration, p.context_id)
        return pr.EvaluationRecipe(p, (("earned", height),), (observation,), height)

    def submit(self, contract_id, request, now):
        with self.lock:
            require(not self.closed, "ClosedCohort")
            c = self.contracts[contract_id]
            require(set(request) == {"measurement", "assay", "documents", "acceptance", "conversion"}, "RequestShape")
            a = self.fact(c, "acceptance", request["acceptance"], now)
            require(a["evidence"] == digest({k: v for k, v in request.items() if k != "acceptance"}), "EvidenceConjunction")
            act = (contract_id, a["id"])
            if act in self.acts:
                require(self.acts[act][0] == digest(request), "AcceptanceActConflict")
                return deepcopy(self.acts[act][1])
            m = self.fact(c, "measurement", request["measurement"], now)
            for k in ("provider", "book", "event", "point"):
                named(m[k])
            require(m["unit"] in UNITS and exact(m["quantity"]) > 0, "MeasuredQuantity")
            occurrence = self.occurrence(m)
            physical = {k: m[k] for k in ("provider", "book", "event", "quantity", "unit", "point")}
            old = self.measurements.get(occurrence)
            require(old is None or old == physical, "PhysicalMeasurementConflict")
            start, stop = exact(a["start"]), exact(a["stop"])
            require(0 <= start < stop <= m["quantity"], "PhysicalInterval")
            require(a["occurrence"] == occurrence, "AcceptanceOccurrence")
            quality = self.fact(c, "assay", request["assay"], now)
            require(quality["occurrence"] == occurrence, "AssayOccurrence")
            require(quality["metric"] == c["quality_metric"] and quality["basis"] == c["quality_basis"], "QualityBasis")
            q = exact(quality["value"])
            require(type(quality["serial"]) is int and quality["serial"] >= 0, "AssaySerial")
            assay_scope = (occurrence, c["keys"]["assay"], quality["metric"], quality["basis"])
            assay_content = {k: quality[k] for k in ("occurrence", "metric", "basis", "value", "serial")}
            latest = self.assays.get(assay_scope)
            if latest is not None:
                require(quality["serial"] >= latest["serial"], "StaleAssay")
                require(quality["serial"] != latest["serial"] or latest == assay_content, "AssayEquivocation")
            source_dim, source_scale = UNITS[m["unit"]]
            target_dim, target_scale = UNITS[c["unit"]]
            if source_dim == target_dim:
                require(request["conversion"] is None, "UnneededConversion")
                factor = source_scale / target_scale
            else:
                conversion = self.fact(c, "conversion", request["conversion"], now)
                require(conversion["occurrence"] == occurrence and conversion["source"] == m["unit"]
                    and conversion["target"] == c["unit"] and conversion["basis"] == c["terms"], "ConversionBasis")
                factor = exact(conversion["factor"])
                require(factor > 0, "PositiveConversion")
            quantity = (stop - start) * factor
            conversion_domain = (c["performance_right"], occurrence)
            require(self.conversions.get(conversion_domain, factor) == factor, "ConversionRevisionRequired")
            require(set(request["documents"]) == {"title", "delivery"}, "RequiredDocuments")
            reasons = []
            for role, envelope in request["documents"].items():
                doc = self.fact(c, role, envelope, now)
                require(doc["occurrence"] == occurrence and doc["measurement"] == digest(physical), "DocumentOccurrence")
                require(exact(doc["start"]) == start and exact(doc["stop"]) == stop, "DocumentInterval")
                require(type(doc["accepted"]) is bool, "DocumentDecision")
                if not doc["accepted"]:
                    reasons.append(role)
            if not c["quality_min"] <= q <= c["quality_max"]:
                reasons.append("quality")
            if m["point"] != c["delivery_point"]:
                reasons.append("delivery-point")
            require(type(a["accepted"]) is bool, "AcceptanceDecision")
            if not a["accepted"]:
                reasons.append("reserved-acceptance")
            domain = (c["performance_right"], occurrence)
            intervals = self.allocations.get(domain, [])
            require(not any(start < row["stop"] and row["start"] < stop for row in intervals), "PerformanceAlreadyAllocated")
            used = sum((x["quantity"] for rows in self.allocations.values() for x in rows
                        if x["right"] == c["performance_right"]), F(0))
            require(used + quantity <= c["quantity"], "ContractQuantityExceeded")
            economic = digest((c["performance_right"], occurrence, start, stop))
            self.assays[assay_scope] = assay_content
            self.measurements[occurrence] = physical
            self.conversions[conversion_domain] = factor
            if reasons:
                result = {"status": "Disputed", "economic": economic, "quantity": quantity,
                    "unit": c["unit"], "reasons": tuple(reasons), "earned": F(0)}
                self.disputes[economic] = {"request": deepcopy(request), "result": result,
                    "domain": domain, "start": start, "stop": stop, "factor": factor}
            else:
                height = 1 + sum(x["contract"] == contract_id and x.get("cohort") == self.cohort for x in self.acceptances.values())
                require(height <= 128, "FiniteAcceptanceCohort")
                amount = c["total_price"] * quantity / c["quantity"]
                r = self.recipe(c, height, amount, "acceptance:" + digest(request))
                evaluated = pr.evaluate(r)
                require(len(evaluated.ledger._bindings) == 1 and len(evaluated.ledger.dues()) == 1, "OneEarnedEntitlement")
                binding = next(iter(evaluated.ledger._bindings.values()))
                self.ledger.resolve(binding)
                due = next(iter(evaluated.ledger.dues()))
                result = {"status": "Earned", "economic": economic, "quantity": quantity,
                    "unit": c["unit"], "earned": amount, "due": due.origin}
                row = {"right": c["performance_right"], "start": start, "stop": stop,
                    "quantity": quantity, "economic": economic}
                self.allocations.setdefault(domain, []).append(row)
                self.acceptances[economic] = {"request": deepcopy(request), "result": result,
                    "contract": contract_id, "height": height, "recipe": r,
                    "binding": binding, "target": amount, "cohort": self.cohort,
                    "instance": self.instances[contract_id]["instance"]}
                self.disputes.pop(economic, None)
            self.acts[act] = (digest(request), deepcopy(result))
            return deepcopy(result)
