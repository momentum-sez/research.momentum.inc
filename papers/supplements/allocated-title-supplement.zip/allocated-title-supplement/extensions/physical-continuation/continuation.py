"""Successive physical cohorts share one right and one actual interval ledger."""
from contextlib import contextmanager
from copy import deepcopy
from fractions import Fraction as F
import hashlib
import hmac
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
PIN = ROOT / "extensions/interval-physical/interval_physical.py"
if hashlib.sha256(PIN.read_bytes()).hexdigest() != "51f67f3ca32d46d93868f7a678947d6681ad15b1fd9a7dcf1283fa5977d827fd":
    raise RuntimeError("ChangedPhysicalContinuationDependency")
spec = importlib.util.spec_from_file_location("p14_continuation_interval", PIN)
ip = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ip)
pf, cs, ev, ent, iv = ip.pf, ip.cs, ip.ev, ip.ent, ip.iv
digest, wire, require, Rejected = ip.digest, ip.wire, ip.require, ip.Rejected
FIELDS = ("contracts", "rights", "measurements", "assays", "conversions", "allocations",
          "acceptances", "acts", "disputes", "corrections")
LIMIT = 128
FAULTS = (None, "before_action", "after_action", "after_ledger", "after_write", "before_commit", "after_commit")


def cohort_program(contract, instance):
    schedule = ev.sched.Descriptor(LIMIT + 1, 1, F=frozenset(range(1, LIMIT + 1)))
    money = pf.ft.Theta(pf.ft.Group.atom(contract["asset"]), F(1), ev.INSTANCE_DUE)
    context = "physical-continuation:" + digest((digest(contract), instance))
    position = ev.Position(contract["performance_right"], instance, "earned", F(1),
        contract["debtor"], contract["beneficiary"], contract["asset"], context,
        contract["authority_basis"], contract["terms"])
    claim = ev.Claim("earned", schedule, (ev.Case(schedule, ev.Oracle("accepted-value")),),
                     money, (), (position,))
    return ev.Program((claim,), (ev.OracleContract("accepted-value", money, "performance"),), context)


def dump_book(book):
    result = {name: deepcopy(getattr(book, name)) for name in FIELDS if name != "acceptances"}
    result["acceptances"] = {key: {k: deepcopy(v) for k, v in row.items() if k != "recipe"}
                              for key, row in book.acceptances.items()}
    return result


def restore_book(record, ledger, admission_key):
    from physical_family import ContinuationFamily
    book = ContinuationFamily(admission_key)
    for name in FIELDS:
        setattr(book, name, deepcopy(record["physical"][name]))
    book.cohort = record["active"]
    book.instances = record["scope"]
    book.ledger = cs.dp.ledger_load(ledger)
    for row in book.acceptances.values():
        row["target"] = book.ledger._targets[row["binding"].key]
    return book


class JoinedCarriage(cs.CarriageStore):
    @contextmanager
    def _connection(self):
        yield ip.BorrowedConnection(self.borrowed)

    def create_admitted(self, instance, program):
        # The outer signed continuation admits this new cohort instance.
        return cs.dp.DurableEvaluator.create(self, instance, program)


def joined(io, db):
    result = object.__new__(JoinedCarriage)
    result.__dict__.update(io.__dict__)
    result.borrowed = db
    return result


class ContinuationBook:
    """Physical mutations and ledger effects commit under one SQLite write lock."""
    def __init__(self, path, key, admission_key):
        require(type(key) is bytes and len(key) >= 32, "StoreKeyTooShort")
        require(Path(path).is_file(), "ExistingPhysicalSourceRequired")
        self.path, self.key, self.admission_key = Path(path), key, admission_key
        self.io = cs.CarriageStore(path, key)
        self.source_io = object.__new__(ip.DurablePhysicalBook)
        self.source_io.__dict__.update(self.__dict__)
        with self.io._connection() as db:
            db.execute("BEGIN")
            self._load(db)

    def _load(self, db):
        state = self.io._load(db)
        source = self.source_io._load(db)
        require(source["admission_key"] == self.admission_key, "PhysicalAdmissionKeyConflict")
        require(source["closed"], "ClosedPhysicalCohortRequired")
        require(source["handover"]["policy"] == state["carriage"]["policy"], "PhysicalHandoverPolicyChanged")
        exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='physical_continuation'").fetchone()
        row = db.execute("SELECT body,mac FROM physical_continuation WHERE id=1").fetchone() if exists else None
        if row is None:
            require("physical_continuation" not in state["carriage"], "MissingPhysicalContinuation")
            require(digest(state["carriage"]["roots"]) == source["handover"]["roots"], "PhysicalHandoverRootsChanged")
            return source, state, None
        body, mac = row
        require(len(body) <= self.io.max_snapshot_bytes and hmac.compare_digest(mac,
            hmac.digest(self.key, b"P14-continuation/1\0" + body, "sha256").hex()), "ContinuationAuthentication")
        record = cs.decode(cs.dp.strict_json(body))
        require(record["version"] == 1 and record["source"] == digest(source), "ContinuationSourceBinding")
        require(state["carriage"].get("physical_continuation") == digest(record), "StalePhysicalContinuation")
        return source, state, record

    def _save(self, db, state, record):
        body = wire(record)
        require(len(body) <= self.io.max_snapshot_bytes, "ContinuationSizeLimit")
        mac = hmac.digest(self.key, b"P14-continuation/1\0" + body, "sha256").hex()
        db.execute("CREATE TABLE IF NOT EXISTS physical_continuation (id INTEGER PRIMARY KEY CHECK(id=1), body BLOB NOT NULL, mac TEXT NOT NULL)")
        db.execute("INSERT INTO physical_continuation VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,mac=excluded.mac", (body, mac))
        state["carriage"]["physical_continuation"] = digest(record)
        self.io._write(db, state, state["revision"])

    def _proposal(self, source, state, record, contracts, nonce):
        pf.named(nonce)
        require(type(contracts) in (list, tuple) and contracts and len(contracts) == len(set(contracts)), "UniqueContinuationContracts")
        original = ip.replay(source) if record is None else restore_book(record, state["ledger"], self.admission_key)
        sequence = 1 if record is None else record["sequence"] + 1
        predecessor = digest(source) if record is None else digest(record)
        scope = {}
        for identity in sorted(contracts):
            require(identity in original.contracts, "ExistingConstitutingContractRequired")
            c = original.contracts[identity]
            require(c["asset"] in state["carriage"]["asset_quanta"], "ExistingCanonicalAssetRequired")
            instance = "physical-cohort:" + digest((predecessor, sequence, nonce, identity))
            program = cohort_program(c, instance)
            scope[identity] = {"contract": digest(c), "right": c["performance_right"],
                "terms": digest(original.rights[c["performance_right"]]), "instance": instance,
                "program": program.identity, "context": program.context_id,
                "quantum": state["carriage"]["asset_quanta"][c["asset"]]}
        policy = state["carriage"]["policy"]
        return {"kind": "ContinuePhysical", "relation": cs.RELATION,
            "authority_epoch": policy["epoch"], "authority_policy": digest(policy),
            "source": digest(source), "base": digest(state), "predecessor": predecessor,
            "sequence": sequence, "limit": LIMIT, "nonce": nonce, "scope": scope}

    def proposal(self, contracts, nonce):
        with self.io._connection() as db:
            db.execute("BEGIN")
            source, state, record = self._load(db)
            return self._proposal(source, state, record, deepcopy(contracts), nonce)

    def advance(self, physical_signed, carriage_signed, *, fault_at=None):
        require(fault_at in FAULTS, "UnknownFaultPoint")
        physical_signed, carriage_signed = deepcopy((physical_signed, carriage_signed))
        with self.io._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            source, state, record = self._load(db)
            physical = pf.verified(physical_signed, self.admission_key)
            payload = cs.verified(carriage_signed, state["carriage"]["policy"])
            require(physical == payload, "ContinuationAuthoritiesDisagree")
            nonce = payload.get("nonce")
            prior = record["successors"].get(nonce) if record else None
            if prior is not None:
                require(prior["request"] == digest(payload), "ContinuationNonceConflict")
                return deepcopy(prior["token"])
            expected = self._proposal(source, state, record, list(payload.get("scope", {})), nonce)
            require(payload == expected, "StaleOrUnboundContinuation")
            cs.dp.fault("before_action", fault_at)
            if record is None:
                book = ip.replay(source)
                for row in book.acceptances.values():
                    row["instance"] = row["contract"]
                    row["cohort"] = "original"
                record = {"version": 1, "source": digest(source), "revision": 0,
                    "physical": dump_book(book), "commands": deepcopy(source["commands"]),
                    "successors": {}, "history": ()}
            token = digest(payload)
            record.update(active=token, scope=deepcopy(payload["scope"]), sequence=payload["sequence"])
            record["successors"][nonce] = {"request": token, "token": token, "payload": payload,
                                           "physical": physical_signed, "carriage": carriage_signed}
            record["revision"] += 1
            self._save(db, state, record)
            cs.dp.fault("after_action", fault_at)
            cs.dp.fault("after_write", fault_at)
            cs.dp.fault("before_commit", fault_at)
            db.commit()
            cs.dp.fault("after_commit", fault_at)
            return token

    def _operation(self, token, command, method, args, now=None, *, fault_at=None):
        require(fault_at in FAULTS, "UnknownFaultPoint")
        pf.named(command)
        args = deepcopy(args)
        request = (method, args, {})
        with self.io._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            source, state, record = self._load(db)
            commands = record["commands"] if record else source["commands"]
            previous = commands.get(command)
            if previous is not None:
                require(previous["request"] == digest(request), "PhysicalCommandConflict")
                return deepcopy(previous["value"])
            require(record is not None and token == record["active"], "StalePhysicalSuccessor")
            book = restore_book(record, state["ledger"], self.admission_key)
            identity = args[0] if method == "submit" else book.acceptances[args[0]]["contract"]
            require(identity in record["scope"], "PhysicalContinuationScope")
            cs.dp.fault("before_action", fault_at)
            result = getattr(book, method)(*args)
            cs.dp.fault("after_action", fault_at)
            store = joined(self.io, db)
            if method == "submit" and result["status"] == "Earned":
                row = book.acceptances[result["economic"]]
                if row["binding"].key not in cs.dp.ledger_load(state["ledger"])._bindings:
                    self._earn(store, row, command)
            elif method == "correct":
                row = book.acceptances[args[0]]
                contract = book.contracts[row["contract"]]
                program = pf.program(contract) if row["cohort"] == "original" else cohort_program(contract, row["instance"])
                p = args[1]["payload"]
                correction = ent.TargetCorrection(p["id"], row["binding"].key, p["expected_head"], F(p["target"]), digest(args[1]))
                answer = store.apply(store.handle(row["instance"], program), program,
                    "physical-continuation:" + command, "ledger", "correct_target", correction)
                require(answer["outcome"] == {"status": "Ok", "value": result}, "ActualPhysicalCorrectionMismatch")
            current = store._load(db)
            require(current["ledger"] == cs.dp.ledger_dump(book.ledger), "ActualPhysicalLedgerMismatch")
            cs.dp.fault("after_ledger", fault_at)
            record["physical"] = dump_book(book)
            record["commands"][command] = {"request": digest(request), "value": deepcopy(result)}
            record["history"] += ({"command": command, "token": token, "request": request, "result": digest(result)},)
            record["revision"] += 1
            self._save(db, current, record)
            cs.dp.fault("after_write", fault_at)
            cs.dp.fault("before_commit", fault_at)
            db.commit()
            cs.dp.fault("after_commit", fault_at)
            return deepcopy(result)

    @staticmethod
    def _earn(store, row, command):
        recipe = row["recipe"]
        program, instance = recipe.program, row["instance"]
        store.create_admitted(instance, program)
        for suffix, operation, args, kwargs in (
            ("request", "request", ("earned", row["height"]), {"context_id": recipe.context_id}),
            ("offer", "offer", (recipe.observations[0],), {"context_id": recipe.context_id}),
            ("run", "run", (), {"now": row["height"], "context_id": recipe.context_id})):
            answer = store.apply(store.handle(instance, program), program,
                "physical-continuation:" + command + ":" + suffix, "evaluator", operation, *args, **kwargs)
            require(answer["outcome"]["status"] == "Ok", "ActualPhysicalEvaluatorRejected")
        with store._connection() as db:
            state = store._load(db)
            ledger = cs.dp.ledger_load(state["ledger"])
            require(ledger._bindings[row["binding"].key] == row["binding"], "ExactEarnedBindingRequired")
            c = state["carriage"]
            due = ledger._dues[row["result"]["due"]]
            quantum, unit = c["asset_quanta"][due.asset]
            count = cs.units(due.amount, quantum)
            require(count > 0, "PositiveCarriedDuty")
            spec = cs.root_spec(instance, due.origin,
                ["physical-performance", row["binding"].key.issuance, row["result"]["economic"]],
                quantum=quantum, unit=unit)
            root = spec["root"]
            require(root not in c["roots"], "DuplicateEconomicDuty")
            c["roots"][root] = {**spec, "program": program.identity, "context": program.context_id,
                "binding": row["binding"], "original_due": due, "quantity": count}
            terms = {"debtor": due.debtor, "beneficiary": due.creditor, "asset": due.asset, "unit": unit,
                "due": str(due.origin.core.height), "condition": "ResolvedPayoff", "priority": "declared-fungible-equal",
                "governing_right": row["binding"].terms_evidence}
            c["canonical"]["journal"]["duties"][root] = {"origin": spec["origin"], "quantity": count,
                "terms": terms, "segments": [[0, count, "Payable"]]}
            rows = deepcopy(c["canonical"]["rows"])
            require(root not in rows, "PhysicalAliasCollision")
            rows[root] = [[root, 0, count]]
            parent = c["active"]
            representation = "physical-growth:" + digest((parent, root))
            c["representations"][representation] = {"program": None, "rows": rows, "outputs": (),
                "relation": "disjoint-new-earned-duty", "parent": parent, "new_root": root}
            c["active"] = representation
            c["canonical"]["rows"] = rows
            c["canonical"]["binding"] = ["P14-new-earned", representation, c["policy"]["name"]]
            c["canonical"]["revision"] += 1
            store._write(db, state, state["revision"])

    def submit(self, token, command, contract, request, now, **options):
        return self._operation(token, command, "submit", (contract, request, now), **options)

    def correct(self, token, command, economic, envelope, now, **options):
        return self._operation(token, command, "correct", (economic, envelope, now), **options)

    def historical_result(self, command, method, args, kwargs=None):
        """Return a committed source result only for its exact original request."""
        request = deepcopy((method, args, {} if kwargs is None else kwargs))
        with self.io._connection() as db:
            db.execute("BEGIN")
            source, state, record = self._load(db)
            previous = (record["commands"] if record else source["commands"]).get(command)
            require(previous is not None, "UnknownPhysicalCommand")
            require(previous["request"] == digest(request), "PhysicalCommandConflict")
            return deepcopy(previous["value"])

    def snapshot(self):
        with self.io._connection() as db:
            db.execute("BEGIN")
            source, state, record = self._load(db)
            book = restore_book(record, state["ledger"], self.admission_key) if record else ip.replay(source)
            if record is None:
                book.ledger = cs.dp.ledger_load(state["ledger"])
                for row in book.acceptances.values():
                    row["target"] = book.ledger._targets[row["binding"].key]
            return {"source": deepcopy(source), "continuation": deepcopy(record),
                    "state": deepcopy(state), "book": book}

    def carriage(self):
        return cs.CarriageStore(self.path, self.key)
