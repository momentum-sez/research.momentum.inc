"""Process termination and competing physical-writer fixture."""
from fractions import Fraction as F
from pathlib import Path
import sys
from test_continuation import ContinuationBook, KEY, ADMISSION, AUTH, pf, cs, request, NOW

path, operation, fault, command = sys.argv[1:]
book = ContinuationBook(Path(path), KEY, ADMISSION)
try:
    if operation == "advance":
        proposal = book.proposal(["sale"], "crash-next")
        result = book.advance(pf.signed(AUTH, proposal), cs.signed(AUTH, proposal), fault_at=None if fault == "none" else fault)
    else:
        snapshot = book.snapshot()
        c = snapshot["book"].contracts["sale"]
        token = snapshot["continuation"]["active"]
        result = book.submit(token, command, "sale", request(c, act=command, start=F(1), stop=F(2), quantity=F(200)), NOW,
            fault_at=None if fault == "none" else fault)
    print(repr(result))
except (pf.Rejected, cs.ERROR) as error:
    print(type(error).__name__ + ":" + str(error))
    sys.exit(3)
