"""Changed physical continuation routes using actual evaluator and interval ledger."""
from copy import deepcopy
from fractions import Fraction as F
import importlib.util
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

from continuation import ContinuationBook, ip, pf, cs, ent, digest, wire, cohort_program, Rejected

sys.modules["interval_physical"] = ip
sys.path.insert(0, str(Path(ip.__file__).parent))
sys.modules["performance"] = pf
spec = importlib.util.spec_from_file_location("p14_continuation_fixture", Path(pf.__file__).with_name("test_performance.py"))
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
AUTH, KEY, NOW = fixture.AUTH, fixture.STORE_KEY, fixture.NOW
contract, request, fact = fixture.contract, fixture.request, fixture.fact
ADMISSION = pf.public_hex(AUTH.public_key())
POLICY = {"key": ADMISSION, "epoch": 0, "name": "synthetic-carriage-authority"}
HERE = Path(__file__).resolve().parent


def credit(identity, amount, recipient="seller"):
    occurrence = ent.OccurrenceKey("synthetic-bank", "RecipientCredit", identity)
    report = ent.CreditReport("report:" + identity, occurrence,
        ent.Credit(occurrence, recipient, "USD", F(amount), "booked"), "synthetic-bank", "sale-right")
    return occurrence, report


def apply(store, c, command, method, *args):
    p = pf.program(c)
    result = store.apply(store.handle(c["id"], p), p, command, "ledger", method, *args)
    if result["outcome"]["status"] != "Ok":
        raise RuntimeError(result)
    return result["outcome"]["value"]


def advance(book, nonce="next", contracts=("sale",), **options):
    p = book.proposal(list(contracts), nonce)
    return book.advance(pf.signed(AUTH, p), cs.signed(AUTH, p), **options)


def make(path, quantity=200):
    c = contract(quantity=F(quantity), total_price=F(quantity*10))
    old = ip.DurablePhysicalBook(path, KEY, ADMISSION)
    old.register("register", pf.signed(AUTH, c))
    r = request(c, stop=F(1), quantity=F(quantity))
    first = old.submit("original", "sale", r, NOW)
    old.handover(AUTH, POLICY)
    return ContinuationBook(path, KEY, ADMISSION), c, first, r


class ContinuationTests(unittest.TestCase):
    def setUp(self):
        (HERE / "work").mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="continuation-", dir=HERE / "work")
        self.path = Path(self.temp.name) / "source.sqlite"
        self.book, self.c, self.first, self.original = make(self.path)

    def tearDown(self):
        self.temp.cleanup()

    def test_later_acceptance_payment_and_late_original_correction(self):
        before = self.book.snapshot()
        token = advance(self.book)
        second = self.book.submit(token, "second", "sale", request(self.c, act="second", start=F(1), stop=F(2), quantity=F(200)), NOW)
        state = self.book.snapshot()["state"]
        ledger = cs.dp.ledger_load(state["ledger"])
        self.assertEqual(second["earned"], 10)
        self.assertNotEqual(second["due"].core.position_lot, self.first["due"].core.position_lot)
        self.assertEqual(second["due"].core.issuance, self.first["due"].core.issuance)
        self.assertEqual(second["due"].core.height, self.first["due"].core.height)
        for key, value in cs.dp.ledger_load(before["state"]["ledger"])._bindings.items():
            self.assertEqual(ledger._bindings[key], value)
        store = self.book.carriage()
        cash, report = credit("shared", 20)
        apply(store, self.c, "credit", "record_credit", report)
        roots = store.snapshot()["carriage"]["roots"]
        for identity, due in (("first", self.first["due"]), ("second", second["due"])):
            state = store.snapshot()
            root = next(root for root, spec in roots.items() if spec["due"] == due)
            store.allocate_alias(state["carriage"]["active"], root, identity, cash, F(10), "payment-rule", expected_base=digest(state))
        consumed = deepcopy(store.snapshot()["carriage"]["canonical"]["journal"]["credits"])
        correction = self.book.correct(token, "late-original-correction", self.first["economic"],
            fact(self.c, "correction", "late", economic=self.first["economic"], expected_head="resolution", target=F(3), basis="later-assay-decision"), NOW)
        state = self.book.snapshot()["state"]
        ledger = cs.dp.ledger_load(state["ledger"])
        self.assertEqual(correction.due.amount, 7)
        self.assertEqual((correction.due.debtor, correction.due.creditor), ("seller", "buyer"))
        self.assertEqual(ledger.outstanding(self.first["due"]), 0)
        self.assertEqual(ledger.outstanding(correction.due.origin), 7)
        self.assertEqual(state["carriage"]["canonical"]["journal"]["credits"], consumed)
        recovery, recovery_report = credit("actual-refund", 7, "buyer")
        apply(store, self.c, "refund-credit", "record_credit", recovery_report)
        apply(store, self.c, "refund-payment", "allocate", "paid-refund", recovery,
              correction.due.origin, F(7), "recovery-rule")
        state = self.book.snapshot()["state"]
        ledger = cs.dp.ledger_load(state["ledger"])
        self.assertEqual(ledger.outstanding(correction.due.origin), 0)
        self.assertEqual(ledger.outstanding(self.first["due"]), 0)
        self.assertEqual(ledger.outstanding(second["due"]), 0)
        self.assertEqual(self.book.snapshot()["source"], before["source"])
        self.assertEqual(self.book.snapshot()["book"].balance("sale")["accepted_quantity"], 2)
        reloaded = ContinuationBook(self.path, KEY, ADMISSION)
        self.assertEqual(reloaded.snapshot()["state"], state)
        self.assertEqual(reloaded.submit(None, "original", "sale", self.original, NOW), self.first)

    def test_more_than_128_acceptances_keep_one_right_and_distinct_cores(self):
        token = advance(self.book, "cohort-one")
        first_scope = self.book.snapshot()["continuation"]["scope"]["sale"]
        for i in range(1, 129):
            self.book.submit(token, "later:" + str(i), "sale", request(self.c, act="later:" + str(i),
                start=F(i), stop=F(i+1), quantity=F(200)), NOW)
        with self.assertRaisesRegex(Rejected, "FiniteAcceptanceCohort"):
            self.book.submit(token, "overflow", "sale", request(self.c, act="overflow", start=F(129), stop=F(130), quantity=F(200)), NOW)
        token2 = advance(self.book, "cohort-two")
        latest = self.book.submit(token2, "next-cohort", "sale", request(self.c, act="next-cohort", start=F(129), stop=F(130), quantity=F(200)), NOW)
        snap = self.book.snapshot()
        new_scope = snap["continuation"]["scope"]["sale"]
        self.assertNotEqual(first_scope["program"], new_scope["program"])
        self.assertNotEqual(first_scope["context"], new_scope["context"])
        self.assertNotEqual(first_scope["instance"], new_scope["instance"])
        ledger = cs.dp.ledger_load(snap["state"]["ledger"])
        self.assertEqual(len(ledger._bindings), 130)
        self.assertEqual({key.issuance for key in ledger._bindings}, {"sale-right"})
        self.assertEqual(len(snap["book"].rights), 1)
        self.assertEqual(len(snap["book"].contracts), 1)
        self.assertEqual(snap["book"].balance("sale")["accepted_quantity"], 130)
        self.assertEqual(sum(d.amount for d in ledger.dues()), 1300)
        self.assertEqual(len(snap["state"]["carriage"]["roots"]), 130)
        saved = {"acceptances": 130, "rights": 1, "contracts": 1, "cohorts": 3,
            "earned": "1300", "accepted_quantity": "130", "remaining_quantity": "70",
            "ledger_sha256": digest(snap["state"]["ledger"]), "state_bytes": len(wire(snap["state"])),
            "continuation_bytes": len(wire(snap["continuation"])), "latest_due": repr(latest["due"])}
        (HERE / ("workload-optimized.json" if sys.flags.optimize else "workload-normal.json")).write_text(json.dumps(saved, indent=2)+"\n")

    def worker(self, path, operation, point, command):
        return [sys.executable, "-B"] + (["-O"] if sys.flags.optimize else []) + [str(HERE / "worker.py"), str(path), operation, point, command]

    def clone(self, name):
        path = self.path.with_name(name + ".sqlite")
        with self.book.io._connection() as source:
            target = sqlite3.connect(path)
            try:
                source.backup(target)
            finally:
                target.close()
        return path

    def test_crash_rollback_and_committed_replay_join_physical_and_actual_ledger(self):
        evidence = []
        for point in ("after_action", "before_commit", "after_commit"):
            path = self.clone("advance-" + point)
            book = ContinuationBook(path, KEY, ADMISSION)
            before = book.snapshot()
            proposal = book.proposal(["sale"], "crash-next")
            child = subprocess.run(self.worker(path, "advance", point, "unused"), capture_output=True, text=True, timeout=30)
            self.assertEqual(child.returncode, 77, child.stdout + child.stderr)
            after = book.snapshot()
            if point == "after_commit":
                self.assertEqual(after["continuation"]["active"], digest(proposal))
            else:
                self.assertEqual((after["state"], after["continuation"]), (before["state"], None))
            token = book.advance(pf.signed(AUTH, proposal), cs.signed(AUTH, proposal))
            self.assertEqual(token, digest(proposal))
            evidence.append({"operation": "advance", "kill": point, "exit": 77, "replay": "same-successor"})
        token = advance(self.book)
        for point in ("after_action", "after_ledger", "after_write", "before_commit", "after_commit"):
            path = self.clone("submit-" + point)
            book = ContinuationBook(path, KEY, ADMISSION)
            before = book.snapshot()
            child = subprocess.run(self.worker(path, "submit", point, "crash-submit"), capture_output=True, text=True, timeout=30)
            self.assertEqual(child.returncode, 77, child.stdout + child.stderr)
            after = book.snapshot()
            if point != "after_commit":
                self.assertEqual((after["state"], after["continuation"]), (before["state"], before["continuation"]))
            r = request(self.c, act="crash-submit", start=F(1), stop=F(2), quantity=F(200))
            result = book.submit(token, "crash-submit", "sale", r, NOW)
            self.assertEqual(result["earned"], 10)
            self.assertEqual(len(book.snapshot()["book"].acceptances), 2)
            self.assertEqual(len(book.carriage().snapshot()["carriage"]["roots"]), 2)
            self.assertEqual(book.submit(token, "crash-submit", "sale", r, NOW), result)
            if point == "after_commit":
                self.assertEqual(book.snapshot()["state"], after["state"])
            evidence.append({"operation": "submit", "kill": point, "exit": 77, "replay": "one-exact-earned-duty"})
        (HERE / ("crashes-optimized.json" if sys.flags.optimize else "crashes-normal.json")).write_text(json.dumps(evidence, indent=2)+"\n")

    def test_two_processes_cannot_allocate_the_same_later_physical_interval(self):
        advance(self.book)
        children = [subprocess.Popen(self.worker(self.path, "submit", "none", command), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    for command in ("competing-a", "competing-b")]
        outputs = [child.communicate(timeout=30) for child in children]
        self.assertEqual(sorted(child.returncode for child in children), [0, 3], outputs)
        self.assertTrue(any("PerformanceAlreadyAllocated" in stdout for stdout, stderr in outputs), outputs)
        snapshot = self.book.snapshot()
        self.assertEqual(len(snapshot["book"].acceptances), 2)
        self.assertEqual(len(snapshot["state"]["carriage"]["roots"]), 2)
        self.assertEqual(snapshot["book"].balance("sale")["accepted_quantity"], 2)

    def test_read_only_historical_register_and_source_ledger_results(self):
        path = self.path.with_name("historical.sqlite")
        c = contract()
        old = ip.DurablePhysicalBook(path, KEY, ADMISSION)
        signed_contract = pf.signed(AUTH, c)
        registered = old.register("register", signed_contract)
        accepted = old.submit("accept", "sale", request(c), NOW)
        occurrence, report = credit("before-handover", 400)
        recorded = old.ledger("credit", "sale", "record_credit", report)
        old.handover(AUTH, POLICY)
        book = ContinuationBook(path, KEY, ADMISSION)
        token = advance(book)
        book.submit(token, "second", "sale", request(c, act="second", start=F(40), stop=F(50)), NOW)
        before = book.snapshot()
        self.assertEqual(book.historical_result("register", "register", (signed_contract,)), registered)
        self.assertEqual(book.historical_result("credit", "ledger", ("sale", "record_credit", (report,))), recorded)
        with self.assertRaisesRegex(Rejected, "PhysicalCommandConflict"):
            book.historical_result("credit", "ledger", ("sale", "record_credit", (credit("other", 400)[1],)))
        self.assertEqual(book.snapshot()["state"], before["state"])
        self.assertEqual(book.snapshot()["continuation"], before["continuation"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
