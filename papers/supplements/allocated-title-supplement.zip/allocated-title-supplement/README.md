# Allocated Title: accompanying reference programs

Snapshot date: 6 September 2026.

This archive accompanies *Allocated Title*. It contains exact rational lifecycle checks, title-transfer models, durable storage tests, physical-performance models, interval handover, and right continuation.
The fixtures use synthetic authorities and provider records. Their results concern the specified finite reference models and test cases.
Custody, title, measurement, legal authority, provider performance, and settlement finality remain external premises.
The reference models do not establish a compiler or production-provider refinement theorem.

## Reproduce

Use Python 3.10 or later with SQLite support. Python 3.14.6 is the tested interpreter.
Keep the extracted directory structure intact.

```sh
cd allocated-title-supplement
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python reproduce.py
```

The command verifies every shipped file against `MANIFEST.sha256` before execution.
It runs each suite with normal and optimized Python, and writes the command output under `reproduction-results/`.
Each suite uses a separate subprocess. Temporary databases and test output remain within the extracted directory.
The dependency installation requires network access. The reference checks use local computation and synthetic evidence.

| Program or test suite | Cases per mode | Scope |
| --- | ---: | --- |
| `verify_allocated_title.py` | 31 | Rational lifecycle fixtures |
| `models/title-transfer/reference/test_transfers.py` | 20 | Transfer modes and evidence conditions |
| `models/title-transfer/reference/test_durable.py` | 18 | Durable transfer, replay, concurrency, and crash boundaries |
| `models/physical-performance/reference/test_performance.py` | 19 | Physical acceptance and correction |
| `extensions/durable-physical/test_durable_physical.py` | 16 | Durable physical execution and handover |
| `extensions/interval-physical/test_interval_physical.py` | 6 | Exact interval handover |
| `extensions/physical-continuation/test_continuation.py` | 5 | Right continuation and later corrections |

## Source correspondence

`SOURCE-MANIFEST.json` binds each included program to its source digest.
Eight files contain portable dependency locators and corresponding digest bindings.
These edits preserve the computational code, fixture inputs, and test assertions.
The remaining 25 Python files retain their original bytes.
The manuscript contains the mathematical statements and proofs.
These executable checks have the finite scope described above.

## Rights and dependencies

`RIGHTS.txt` states the source licensing status.
`THIRD-PARTY-NOTICES.txt` identifies the installed dependencies and their license files.
The archive includes those notices. It does not include dependency binaries or source distributions.
