"""Finite control from action and observation history.

The contract supplies all hidden states and complete response paths.
This module proves no physical or institutional completeness premise.
"""

from dataclasses import dataclass
from functools import cache
from types import MappingProxyType


class ContractBreach(ValueError):
    """An observation has no path in the admitted contract."""


@dataclass(frozen=True)
class Path:
    states: tuple
    transcript: tuple
    duration: int = 1


class Contract:
    """An immutable, finite transition and observation contract."""

    __slots__ = ("states", "actions", "safe", "goal", "max_duration", "responses", "_sealed")

    def __setattr__(self, name, value):
        if getattr(self, "_sealed", False):
            raise AttributeError("The admitted contract is immutable")
        object.__setattr__(self, name, value)

    def __init__(self, states, actions, safe, goal, responses, max_duration=1):
        self.states = frozenset(states)
        self.actions = frozenset(actions)
        self.safe = frozenset(safe)
        self.goal = frozenset(goal)
        if not self.states or not self.safe <= self.states:
            raise ValueError("The state universe and safe set are inconsistent")
        if not self.goal <= self.safe:
            raise ValueError("Every goal state must be safe")
        if type(max_duration) is not int or max_duration <= 0:
            raise ValueError("The response duration bound must be positive")
        self.max_duration = max_duration
        copied = {}
        for (state, action), paths in responses.items():
            if state not in self.states or action not in self.actions:
                raise ValueError("A response key lies outside the contract")
            paths = tuple(paths)
            for path in paths:
                if not isinstance(path, Path) or len(path.states) < 2:
                    raise ValueError("A response needs at least one transition")
                if not isinstance(path.states, tuple) or not isinstance(path.transcript, tuple):
                    raise ValueError("Response states and transcripts must be immutable tuples")
                if path.states[0] != state:
                    raise ValueError("A response starts at the wrong state")
                if not frozenset(path.states) <= self.states:
                    raise ValueError("A response leaves the state universe")
                if type(path.duration) is not int or not 0 < path.duration <= max_duration:
                    raise ValueError("A response violates the duration bound")
                hash(path.transcript)
            copied[state, action] = paths
        self.responses = MappingProxyType(copied)
        self._sealed = True

    def belief(self, values):
        belief = frozenset(values)
        if not belief or not belief <= self.states:
            raise ValueError("A belief must be nonempty and within the state universe")
        return belief

    def paths(self, state, action):
        return self.responses.get((state, action), ())

    def posteriors(self, belief, action):
        """Use only the declared transcript to group response endpoints."""
        belief = self.belief(belief)
        if action not in self.actions:
            raise ValueError("The action is outside the contract")
        if any(not self.paths(state, action) for state in belief):
            return None
        observations = {}
        for state in belief:
            for path in self.paths(state, action):
                observations.setdefault(path.transcript, set()).add(path.states[-1])
        return {transcript: frozenset(states) for transcript, states in observations.items()}

    def update(self, belief, action, transcript):
        posteriors = self.posteriors(belief, action)
        if posteriors is None:
            raise ContractBreach("The action has no response in a possible world")
        try:
            return posteriors[transcript]
        except KeyError as error:
            raise ContractBreach("The transcript has no admitted response path") from error

    def safe_paths(self, belief, action):
        return all(
            frozenset(path.states) <= self.safe
            for state in belief for path in self.paths(state, action)
        )


class Solver:
    """Compute every winning first action for a finite decision horizon."""

    def __init__(self, contract):
        self.contract = contract

    @staticmethod
    def horizon(value):
        if type(value) is not int or value < 0:
            raise ValueError("The decision horizon must be a nonnegative integer")
        return value

    def winning(self, belief, horizon):
        return self._winning(self.contract.belief(belief), self.horizon(horizon))

    @cache
    def _winning(self, belief, horizon):
        if belief <= self.contract.goal:
            return True
        return bool(self._choices(belief, horizon))

    def choices(self, belief, horizon):
        return self._choices(self.contract.belief(belief), self.horizon(horizon))

    @cache
    def _choices(self, belief, horizon):
        contract = self.contract
        if horizon == 0 or not belief <= contract.safe or belief <= contract.goal:
            return frozenset()
        retained = set()
        for action in contract.actions:
            posteriors = contract.posteriors(belief, action)
            if posteriors is None or not contract.safe_paths(belief, action):
                continue
            if all(self._winning(posterior, horizon - 1) for posterior in posteriors.values()):
                retained.add(action)
        return frozenset(retained)


class Controller:
    """An in-memory policy cursor with no actual-state input."""

    def __init__(self, solver, initial_belief, horizon):
        self.solver = solver
        self.belief = solver.contract.belief(initial_belief)
        self.remaining = solver.horizon(horizon)
        self.history = ()
        if not solver.winning(self.belief, self.remaining):
            raise ValueError("The initial belief has no winning policy at this horizon")

    @property
    def complete(self):
        return self.belief <= self.solver.contract.goal

    @property
    def choices(self):
        return self.solver.choices(self.belief, self.remaining)

    def observe(self, action, transcript):
        if action not in self.choices:
            raise ValueError("The action has no winning continuation at the remaining horizon")
        posterior = self.solver.contract.update(self.belief, action, transcript)
        self.belief = posterior
        self.remaining -= 1
        self.history += ((action, transcript),)
        return self.belief
