# Programmable Institutions: supplementary construction

This supplement contains the finite model of action under incomplete observation described in Section 7.8 of *Programmable Institutions*. It includes the controller, the two-party service example, and their existing tests.

## Requirements and reproduction

Use Python 3.9 or later. The three Python files must remain in the same directory. All other imports use the Python standard library. No package installation, network connection, service account, or external data is required.

Extract `programmable-institutions-supplement.zip`, open a terminal in the extracted `programmable-institutions-supplement` directory, and run:

```sh
python3 -B -E -S -m unittest -v test_belief_controller
python3 -B -E -S -O -m unittest -v test_belief_controller
```

The first command runs the existing tests in normal mode. The second runs the same tests with Python optimization enabled. Each successful command reports `Ran 30 tests` followed by `OK`. Elapsed time can differ. The flags prevent bytecode writes, ignore Python environment settings, and disable automatic loading of site packages.

## Files

- `belief_controller.py` defines finite response paths, an immutable response contract, the belief update, the finite-horizon solver, and the controller's observation history.
- `workflow.py` supplies the two-party service example. One party reserves 80 monetary units, and the other reserves one service slot.
- `test_belief_controller.py` checks the solver and the service example with Python's `unittest` module.

## Model and proof scope

A belief contains every state consistent with the program's action and observation history. A contract lists the finite state and action sets, safe states, permitted goals, and complete response paths. Each path specifies its intermediate states, observed transcript, and duration.

The solver implements the belief update and finite backward recurrence in Equations (E4) and (E5). It retains the first actions that guarantee safety and known completion within the remaining decision rounds. The guarantee quantifies over every response path supplied by the contract. Completion requires every state in the current belief to satisfy the goal.

The service example includes delayed judgment, hidden delegate revocation, guarded refusal, transfer of an unused reservation to the authorized owner, performance, and joint cancellation. The fixture assumes competent signatures, a current owner mandate, and a jointly permitted cancellation rule. Its state transitions simulate the consequences of those premises.

The service fixture uses fixed reservations. It does not implement the paper's general ancestor-budget accounting or affected-rights projections. The supplement covers the observation controller and this fixture.

The tests cover the stated finite semantics. They check hidden-state ambiguity, preservation of observation history, intermediate safety, known completion, retained choices, response counters, and the service example. The existing comparison test checks the solver against exhaustive observation-policy trees for its fixed collection of small finite games.

The mathematical theorem and its proof remain in the paper. Passing these tests does not prove the theorem for every possible contract. The model does not establish the completeness of institutional facts, legal authority, authenticated source services, provider performance, or actual calendar deadlines. The decision horizon counts completed response rounds. A calendar guarantee additionally requires the stated bound on each complete round.
