import itertools
import random
import unittest

from belief_controller import Contract, ContractBreach, Controller, Path, Solver
from workflow import build, safe


def finite(states, actions, edges, goal, unsafe=()):
    return Contract(states, actions, set(states) - set(unsafe), goal, edges)


class BeliefTests(unittest.TestCase):
    def test_goal_cannot_include_unsafe_state(self):
        with self.assertRaisesRegex(ValueError, "goal state must be safe"):
            Contract({"g"}, (), (), {"g"}, {})

    def test_empty_belief_is_not_vacuous_completion(self):
        contract = finite({"g"}, (), {}, {"g"})
        with self.assertRaises(ValueError):
            Solver(contract).winning((), 0)

    def test_completion_requires_every_possible_world(self):
        contract = finite({"g", "pending"}, (), {}, {"g"})
        self.assertFalse(Solver(contract).winning({"g", "pending"}, 0))

    def test_policy_cannot_select_using_hidden_state(self):
        edges = {("x", "a"): (Path(("x", "g"), ("done",)),),
                 ("y", "b"): (Path(("y", "g"), ("done",)),)}
        contract = finite({"x", "y", "g"}, {"a", "b"}, edges, {"g"})
        solver = Solver(contract)
        self.assertTrue(solver.winning({"x"}, 1))
        self.assertTrue(solver.winning({"y"}, 1))
        self.assertFalse(solver.winning({"x", "y"}, 1))

    def test_one_deadlocked_world_rejects_action(self):
        contract = finite({"x", "y", "g"}, {"a"},
                          {("x", "a"): (Path(("x", "g"), ("done",)),)}, {"g"})
        self.assertIsNone(contract.posteriors({"x", "y"}, "a"))
        with self.assertRaises(ContractBreach):
            contract.update({"x", "y"}, "a", ("done",))

    def test_restored_unsafe_intermediate_state_is_rejected(self):
        contract = finite({"x", "bad", "g"}, {"a"},
                          {("x", "a"): (Path(("x", "bad", "g"), ("done",)),)},
                          {"g"}, unsafe={"bad"})
        self.assertFalse(Solver(contract).winning({"x"}, 1))

    def test_unexpected_observation_preserves_cursor(self):
        contract = finite({"x", "g"}, {"a"},
                          {("x", "a"): (Path(("x", "g"), ("done",)),)}, {"g"})
        cursor = Controller(Solver(contract), {"x"}, 1)
        before = cursor.belief, cursor.remaining, cursor.history
        with self.assertRaises(ContractBreach):
            cursor.observe("a", ("fabricated",))
        self.assertEqual(before, (cursor.belief, cursor.remaining, cursor.history))
        self.assertFalse(cursor.complete)

    def test_only_declared_transcript_is_observed(self):
        contract = finite({"x", "hidden-a", "hidden-b", "y", "z", "g"}, {"a"},
                          {("x", "a"): (Path(("x", "hidden-a", "y"), ("pending",)),
                                          Path(("x", "hidden-b", "z"), ("pending",)))}, {"g"})
        self.assertEqual(contract.update({"x"}, "a", ("pending",)), {"y", "z"})

    def test_distinct_observations_refine_belief(self):
        contract = finite({"x", "y", "z"}, {"read"},
                          {("x", "read"): (Path(("x", "y"), ("yes",)),
                                             Path(("x", "z"), ("no",)))}, {"y", "z"})
        self.assertEqual(contract.update({"x"}, "read", ("yes",)), {"y"})

    def test_all_winning_first_actions_are_retained(self):
        edges = {("x", action): (Path(("x", "g"), ("done",)),) for action in ("cost80", "cost90")}
        contract = finite({"x", "g"}, {"cost80", "cost90"}, edges, {"g"})
        self.assertEqual(Solver(contract).choices({"x"}, 1), {"cost80", "cost90"})

    def test_decreasing_horizon_prevents_idle_forever(self):
        edges = {("x", "idle"): (Path(("x", "x"), ("idle",)),),
                 ("x", "finish"): (Path(("x", "g"), ("done",)),)}
        solver = Solver(finite({"x", "g"}, {"idle", "finish"}, edges, {"g"}))
        cursor = Controller(solver, {"x"}, 2)
        self.assertEqual(cursor.choices, {"idle", "finish"})
        cursor.observe("idle", ("idle",))
        self.assertEqual(cursor.choices, {"finish"})
        with self.assertRaises(ValueError):
            cursor.observe("idle", ("idle",))
        cursor.observe("finish", ("done",))
        self.assertTrue(cursor.complete)

    def test_fulfilled_world_can_supply_completion_evidence(self):
        edges = {("g", "refresh"): (Path(("g", "g"), ("complete",)),),
                 ("pending", "refresh"): (Path(("pending", "g"), ("complete",)),)}
        solver = Solver(finite({"pending", "g"}, {"refresh"}, edges, {"g"}))
        cursor = Controller(solver, {"pending", "g"}, 1)
        self.assertFalse(cursor.complete)
        cursor.observe("refresh", ("complete",))
        self.assertTrue(cursor.complete)

    def test_forbidding_refresh_after_fulfillment_can_destroy_known_completion(self):
        edges = {("pending", "refresh"): (Path(("pending", "g"), ("complete",)),)}
        solver = Solver(finite({"pending", "g"}, {"refresh"}, edges, {"g"}))
        self.assertFalse(solver.winning({"pending", "g"}, 1))

    def test_unbounded_stutter_has_no_finite_completion_bound(self):
        edges = {("pending", "service"): (Path(("pending", "pending"), ("pending",)),
                                            Path(("pending", "g"), ("done",)))}
        solver = Solver(finite({"pending", "g"}, {"service"}, edges, {"g"}))
        for horizon in range(12):
            self.assertFalse(solver.winning({"pending"}, horizon))

    def test_response_duration_contract_is_checked(self):
        with self.assertRaisesRegex(ValueError, "duration bound"):
            Contract({"x", "g"}, {"a"}, {"x", "g"}, {"g"},
                     {("x", "a"): (Path(("x", "g"), ("done",), 3),)}, max_duration=2)

    def test_path_origin_is_checked(self):
        with self.assertRaisesRegex(ValueError, "wrong state"):
            finite({"x", "g"}, {"a"}, {("x", "a"): (Path(("g", "g"), ("done",)),)}, {"g"})

    def test_contract_cannot_change_under_cached_solver(self):
        contract = finite({"x", "g"}, (), {}, {"g"})
        solver = Solver(contract)
        self.assertFalse(solver.winning({"x"}, 0))
        with self.assertRaises(AttributeError):
            contract.goal = frozenset({"x"})
        with self.assertRaises(TypeError):
            contract.responses["x", "a"] = ()

    def test_observable_prefix_is_preserved_and_hidden_prefix_is_not_used(self):
        for visible in (True, False):
            left = ("red", "ack") if visible else ("ack",)
            right = ("blue", "ack") if visible else ("ack",)
            edges = {("s", "read"): (Path(("s", "l"), left), Path(("s", "r"), right)),
                     ("l", "left"): (Path(("l", "g"), ("done",)),),
                     ("r", "right"): (Path(("r", "g"), ("done",)),)}
            solver = Solver(finite({"s", "l", "r", "g"}, {"read", "left", "right"}, edges, {"g"}))
            self.assertEqual(solver.winning({"s"}, 2), visible)

    def test_equal_latest_receipt_does_not_erase_earlier_observation(self):
        edges = {("s", "read"): (Path(("s", "l1"), ("left",)), Path(("s", "r1"), ("right",))),
                 ("l1", "ack"): (Path(("l1", "l2"), ("ack",)),),
                 ("r1", "ack"): (Path(("r1", "r2"), ("ack",)),),
                 ("l2", "left"): (Path(("l2", "g"), ("done",)),),
                 ("r2", "right"): (Path(("r2", "g"), ("done",)),)}
        solver = Solver(finite({"s", "l1", "r1", "l2", "r2", "g"},
                               {"read", "ack", "left", "right"}, edges, {"g"}))
        self.assertTrue(solver.winning({"s"}, 3))
        self.assertFalse(solver.winning({"s"}, 2))
        for receipt, action in (("left", "left"), ("right", "right")):
            cursor = Controller(solver, {"s"}, 3)
            cursor.observe("read", (receipt,))
            cursor.observe("ack", ("ack",))
            self.assertEqual(cursor.choices, {action})

    def test_resetting_countdown_destroys_a_fixed_completion_bound(self):
        edges = {("p1", "poll"): (Path(("p1", "p0"), ("pending",)),),
                 ("p0", "poll"): (Path(("p0", "refused"), ("refused",)),),
                 ("refused", "release"): (Path(("refused", "cancelled"), ("released",)),)}
        states = {"p1", "p0", "refused", "cancelled"}
        solver = Solver(finite(states, {"poll", "release"}, edges, {"cancelled"}))
        self.assertTrue(solver.winning({"p1", "p0"}, 3))
        self.assertFalse(solver.winning({"p1", "p0"}, 2))
        edges["p0", "poll"] += (Path(("p0", "p1"), ("pending",)),)
        reset_solver = Solver(finite(states, {"poll", "release"}, edges, {"cancelled"}))
        for horizon in range(12):
            self.assertFalse(reset_solver.winning({"p1", "p0"}, horizon))

    def test_exact_solver_matches_exhaustive_observation_policy_trees(self):
        # The evaluator follows actual worlds through complete policy trees.
        # It does not call the solver, its updater, or its predecessor method.
        observations = ((0,), (1,))
        actions = ("a", "b")
        def policies(depth):
            yield None
            if depth:
                children = tuple(policies(depth - 1))
                for action in actions:
                    for branches in itertools.product(children, repeat=len(observations)):
                        yield action, dict(zip(observations, branches))
        def succeeds(contract, world, policy):
            if world not in contract.safe:
                return False
            if policy is None:
                return world in contract.goal
            action, branches = policy
            paths = contract.paths(world, action)
            return bool(paths) and all(
                all(state in contract.safe for state in path.states)
                and succeeds(contract, path.states[-1], branches[path.transcript])
                for path in paths)
        rng = random.Random(20260905)
        for _ in range(80):
            edges = {}
            for state in range(3):
                for action in actions:
                    edges[state, action] = tuple(
                        Path((state, rng.randrange(3)), observations[rng.randrange(2)])
                        for _ in range(rng.randrange(3)))
            contract = finite(range(3), actions, edges, {2})
            solver = Solver(contract)
            for belief in ({0}, {1}, {0, 1}, {0, 2}):
                for horizon in range(3):
                    winners = [policy for policy in policies(horizon)
                               if all(succeeds(contract, world, policy) for world in belief)]
                    self.assertEqual(solver.winning(belief, horizon), bool(winners))
                    self.assertEqual(solver.choices(belief, horizon),
                                     {policy[0] for policy in winners if policy is not None})


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.contract, cls.initial = build()
        cls.solver = Solver(cls.contract)

    def test_two_useful_initial_orders_are_retained(self):
        self.assertFalse(self.solver.winning(self.initial, 5))
        self.assertEqual(self.solver.choices(self.initial, 6), {"prepare", "service"})
        self.assertEqual(self.solver.choices(self.initial, 7), {"prepare", "service", "idle"})

    def test_delayed_judgment_hidden_revocation_and_owner_completion(self):
        cursor = Controller(self.solver, self.initial, 6)
        cursor.observe("prepare", ("prepared",))
        cursor.observe("service", ("judgment", "pending"))
        cursor.observe("service", ("judgment", "approve"))
        self.assertEqual({state.delegate_live for state in cursor.belief}, {False, True})
        cursor.observe("delegate_attempt", ("local-refusal", "delegate-command"))
        for state in cursor.belief:
            self.assertEqual((state.cash_reserved, state.service_reserved, state.duty), (80, 1, "open"))
        cursor.observe("owner_rebind", ("owner-bound", "delegate-command", "owner-command"))
        cursor.observe("owner_attempt", ("performance", "owner-command", "occurrence-1"))
        self.assertTrue(cursor.complete)
        self.assertEqual(cursor.remaining, 0)
        self.assertTrue(all(state.cash_paid == 80 and state.occurrences == 1 for state in cursor.belief))

    def test_judgment_refusal_is_not_delivery(self):
        contract, initial = build(permit_cancellation=False)
        for horizon in range(10):
            self.assertFalse(Solver(contract).winning(initial, horizon))

    def test_adverse_judgment_uses_explicit_joint_discharge(self):
        cursor = Controller(self.solver, self.initial, 6)
        cursor.observe("service", ("judgment", "refuse"))
        self.assertFalse(cursor.complete)
        cursor.observe("cancel", ("joint-cancellation", "cash-and-slot-released"))
        self.assertTrue(cursor.complete)
        self.assertTrue(all(state.duty == "discharged" and state.cash_paid == 0 for state in cursor.belief))

    def test_opportunity_counter_never_resets(self):
        for (state, action), paths in self.contract.responses.items():
            for path in paths:
                end = path.states[-1]
                self.assertLessEqual(end.remaining_opportunities, state.remaining_opportunities)
                if action == "service" and end.judgment == "pending":
                    self.assertLess(end.remaining_opportunities, state.remaining_opportunities)

    def test_expiry_forces_answer_or_refusal_not_approval(self):
        for state in self.initial:
            if state.remaining_opportunities == 0:
                outcomes = {path.transcript for path in self.contract.paths(state, "service")}
                self.assertEqual(outcomes, {("judgment", "approve"), ("judgment", "refuse")})

    def test_every_fixture_path_preserves_authority_and_resources(self):
        for paths in self.contract.responses.values():
            for path in paths:
                self.assertTrue(all(safe(state) for state in path.states))
                for state in path.states:
                    if state.performer == "delegate":
                        self.assertTrue(state.delegate_live)

    def test_reservation_transfer_requires_known_refusal(self):
        for state in self.contract.states:
            if state.stage != "delegate-refused":
                self.assertFalse(self.contract.paths(state, "owner_rebind"))
            if state.stage != "owner-bound":
                self.assertFalse(self.contract.paths(state, "owner_attempt"))

    def test_actual_state_remains_in_every_reachable_posterior(self):
        seen = set()
        def visit(belief, horizon):
            if (belief, horizon) in seen:
                return
            seen.add((belief, horizon))
            for action in self.solver.choices(belief, horizon):
                for state in belief:
                    for path in self.contract.paths(state, action):
                        posterior = self.contract.update(belief, action, path.transcript)
                        self.assertIn(path.states[-1], posterior)
                        self.assertTrue(self.solver.winning(posterior, horizon - 1))
                        visit(posterior, horizon - 1)
        visit(self.initial, 7)
        self.assertGreater(len(seen), 20)


if __name__ == "__main__":
    unittest.main()
