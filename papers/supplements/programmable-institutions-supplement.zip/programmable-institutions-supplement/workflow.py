"""Two-party performance with delayed judgment and hidden revocation.

The fixture assumes competent signatures, one current owner mandate,
and a jointly permitted cancellation rule. It simulates their effects.
"""

from collections import deque
from dataclasses import dataclass, replace

from belief_controller import Contract, Path


@dataclass(frozen=True)
class State:
    judgment: str = "pending"
    remaining_opportunities: int = 1
    delegate_live: bool = True
    prepared: bool = False
    stage: str = "active"
    reservation_command: str = "delegate-command"
    cash_reserved: int = 80
    service_reserved: int = 1
    cash_paid: int = 0
    occurrences: int = 0
    duty: str = "open"
    performer: str = ""


ACTIONS = frozenset({"service", "prepare", "delegate_attempt", "owner_rebind",
                     "owner_attempt", "cancel", "idle"})


def authorities(state):
    """The environment may revoke the delegate before the next effect."""
    return (True, False) if state.delegate_live else (False,)


def fulfilled(state, performer):
    return replace(state, stage="delivered", cash_reserved=0, service_reserved=0,
                   cash_paid=80, occurrences=1, duty="fulfilled", performer=performer)


def responses(state, action):
    if state.stage in {"delivered", "cancelled"}:
        return ()
    if action == "idle":
        return (Path((state, state), ("idle",)),)
    if action == "service" and state.stage == "active":
        results = []
        if state.judgment == "pending":
            judgments = ("approve", "refuse")
            if state.remaining_opportunities > 0:
                judgments += ("pending",)
        else:
            judgments = (state.judgment,)
        for judgment in judgments:
            for live in authorities(state):
                remaining = max(0, state.remaining_opportunities - 1)
                end = replace(state, judgment=judgment,
                              remaining_opportunities=remaining, delegate_live=live)
                results.append(Path((state, end), ("judgment", judgment)))
        return tuple(results)
    if action == "prepare" and state.stage == "active" and not state.prepared:
        return tuple(Path((state, replace(state, prepared=True, delegate_live=live)),
                          ("prepared",)) for live in authorities(state))
    if action == "delegate_attempt" and state.stage == "active" and state.prepared and state.judgment == "approve":
        results = []
        for live in authorities(state):
            guarded = replace(state, delegate_live=live)
            if live:
                results.append(Path((state, guarded, fulfilled(guarded, "delegate")),
                                    ("performance", "delegate-command", "occurrence-1")))
            else:
                refused = replace(guarded, stage="delegate-refused")
                results.append(Path((state, guarded, refused),
                                    ("local-refusal", "delegate-command")))
        return tuple(results)
    if action == "owner_rebind" and state.stage == "delegate-refused":
        rebound = replace(state, stage="owner-bound", reservation_command="owner-command")
        return (Path((state, rebound), ("owner-bound", "delegate-command", "owner-command")),)
    if action == "owner_attempt" and state.stage == "owner-bound" and state.prepared and state.judgment == "approve":
        return (Path((state, fulfilled(state, "owner")),
                     ("performance", "owner-command", "occurrence-1")),)
    if action == "cancel" and state.judgment == "refuse":
        cancelled = replace(state, stage="cancelled", cash_reserved=0, service_reserved=0,
                            reservation_command="", duty="discharged")
        return (Path((state, cancelled), ("joint-cancellation", "cash-and-slot-released")),)
    return ()


def safe(state):
    if state.cash_reserved + state.cash_paid > 80 or state.occurrences > 1:
        return False
    if state.duty == "open" and (state.cash_reserved, state.service_reserved) != (80, 1):
        return False
    if state.stage == "delivered":
        return (state.cash_paid == 80 and state.occurrences == 1 and state.duty == "fulfilled"
                and (state.performer != "delegate" or state.delegate_live))
    if state.stage == "cancelled":
        return (state.cash_reserved == state.service_reserved == state.cash_paid == state.occurrences == 0
                and state.duty == "discharged")
    if state.stage == "owner-bound":
        return state.reservation_command == "owner-command"
    return state.reservation_command == "delegate-command"


def build(permit_cancellation=True):
    initial = frozenset(State(remaining_opportunities=count, delegate_live=live)
                        for count in (0, 1) for live in (False, True))
    states = set(initial)
    pending = deque(initial)
    edges = {}
    while pending:
        state = pending.popleft()
        for action in ACTIONS:
            paths = responses(state, action)
            edges[state, action] = paths
            for path in paths:
                for target in path.states:
                    if target not in states:
                        states.add(target)
                        pending.append(target)
    goal = {state for state in states if state.stage == "delivered"
            or permit_cancellation and state.stage == "cancelled"}
    contract = Contract(states, ACTIONS, {state for state in states if safe(state)}, goal, edges)
    return contract, initial
