# Exact linear disclosure and source grants

This supplement contains the finite disclosure checker described in The Sovereign Jurisdiction Network. It supplies the checker, behavioral tests, and a SHA-256 manifest for the packaged files.

## Reproduce

Use Python 3.9 or later on a Unix-like system. Both files use only the standard library. Extract the archive and run these commands inside its directory:

```sh
PYTHONOPTIMIZE= python3 -B disclosure_composition_checker.py
PYTHONOPTIMIZE= python3 -B -O disclosure_composition_checker.py
PYTHONOPTIMIZE= python3 -B -m unittest -v test_disclosure_composition_checker
PYTHONOPTIMIZE= python3 -B -O -m unittest -v test_disclosure_composition_checker
```

Each command clears inherited optimization settings. Both CLI runs must complete successfully, and both unittest runs must finish with `OK`. The tests include deliberately broken implementations; the corresponding behavioral checks must detect those changes. These copies remain separate from the packaged source.

On a system with `shasum`, verify the files with:

```sh
shasum -a 256 -c SHA256SUMS
```

The manifest covers each packaged file except itself. Keep fresh logs outside the manifest.

## Exact disclosure model

Rows contain rational coefficients represented by integers, `Fraction` values, or rational strings. The first proposed row determines the positive source width. Every history, proposed, and protected row must have that width. A nonempty, well-formed proposal with no protected targets is admissible.

The history contains observations available to one fixed recipient coalition for one fixed source snapshot, including its declared linear auxiliary knowledge. The source vector ranges over unrestricted rational space. Queries are public and independent of private source values. Observations are exact and noiseless.

The checker refuses a proposed release when any protected row belongs to the span of the accumulated history and proposed rows. Otherwise, the observations leave each protected value undetermined in this model. Useful aggregates and linear combinations of earlier observations can remain admissible. The pairwise-sum example permits the first two sums and refuses the third, which reconstructs all three source values.

## Source-grant model

Each retained source requires a current grant for the requested act, purpose, and audience. The requested retention deadline must lie within every selected source grant's bounds and cannot precede use time. With no retained sources, retention has no source-imposed upper bound. An alternative applicable grant can satisfy a source's requirement. Computation and model training require their respective grants.

The inputs are already normalized source identities, grants, and operation classifications. The checker does not authenticate an instrument, decide its legal meaning, fetch revocations, establish parent-artifact availability, or stop a caller from supplying a false operation class.

## Construction obligations

These functions have no durable store. A host must supply complete coalition and snapshot histories and enforce the paper's atomic admission rule before releasing values. The code does not establish coordination between separate stores, deletion from recipient memory, provider behavior, or the truth of supplied authority records.

The row-span result does not extend to hidden auxiliary knowledge, restricted source domains, noisy or nonlinear observations, private query selection, or general statistical privacy. Those cases require their own models and proofs.
