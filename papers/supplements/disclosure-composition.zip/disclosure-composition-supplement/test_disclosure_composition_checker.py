"""Regressions for the fixed-snapshot exact rational disclosure model.

These tests establish finite arithmetic and source-grant behavior. They do not
supply instrument authentication, coalition knowledge, or a durable store.
Run with python3 -m unittest discover -s papers -p test_disclosure_composition_checker.py.
"""

from dataclasses import replace
from fractions import Fraction
from itertools import combinations, permutations, product
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

import disclosure_composition_checker as checker


PAIR_AB = (1, 1, 0)
PAIR_BC = (0, 1, 1)
PAIR_AC = (1, 0, 1)
COORDINATES = ((1, 0, 0), (0, 1, 0), (0, 0, 1))


def grant(source="a", **changes):
    return replace(checker.Grant(source, frozenset({"compute"}), "research", "team",
                                 0, 10, 0, 10), **changes)


def permitted(lineage, grants, **changes):
    request = dict(act="compute", purpose="research", audience="team", at=2, retain_until=5)
    request.update(changes)
    return checker.admit_action(lineage, grants, **request)


def minor_rank(rows, width):
    """Independent small-matrix oracle using determinants, not elimination."""
    for size in range(min(len(rows), width), 0, -1):
        for selected_rows in combinations(rows, size):
            for columns in combinations(range(width), size):
                determinant = Fraction(0)
                for order in permutations(range(size)):
                    inversions = sum(order[i] > order[j]
                                     for i in range(size) for j in range(i + 1, size))
                    term = Fraction((-1) ** inversions)
                    for i, j in enumerate(order):
                        term *= Fraction(selected_rows[i][columns[j]])
                    determinant += term
                if determinant:
                    return size
    return 0


class LinearDisclosureTests(unittest.TestCase):
    def test_useful_pairwise_aggregates_are_admitted(self):
        self.assertTrue(checker.admit_release([], [PAIR_AB], COORDINATES))
        self.assertTrue(checker.admit_release([PAIR_AB], [PAIR_BC], COORDINATES))
        self.assertTrue(checker.admit_release([], [PAIR_AB, PAIR_BC], COORDINATES))

    def test_third_sum_reconstructs_and_is_refused(self):
        self.assertFalse(checker.admit_release([PAIR_AB, PAIR_BC], [PAIR_AC], COORDINATES))
        self.assertFalse(checker.admit_release([], [PAIR_AB, PAIR_BC, PAIR_AC], COORDINATES))
        # A = (AB + AC - BC)/2 is a direct reconstruction witness.
        coefficients = (Fraction(1, 2), Fraction(-1, 2), Fraction(1, 2))
        recovered = tuple(sum(c * row[i] for c, row in zip(coefficients, (PAIR_AB, PAIR_BC, PAIR_AC)))
                          for i in range(3))
        self.assertEqual(recovered, COORDINATES[0])

    def test_scaled_replayed_and_fractional_combinations_add_no_information(self):
        history = [PAIR_AB, PAIR_BC]
        for proposed in ((2, 2, 0), PAIR_AB, (Fraction(1, 3), 1, Fraction(2, 3)), (0, 0, 0)):
            with self.subTest(proposed=proposed):
                self.assertTrue(checker.admit_release(history, [proposed], COORDINATES))

    def test_null_direction_certifies_all_coordinates_remain_undetermined(self):
        history = [PAIR_AB, PAIR_BC]
        direction = (1, -1, 1)
        self.assertEqual([sum(x * y for x, y in zip(row, direction)) for row in history], [0, 0])
        for target in COORDINATES:
            self.assertNotEqual(sum(x * y for x, y in zip(target, direction)), 0)
            self.assertFalse(checker.identifies(history, target))

    def test_auxiliary_history_and_each_protected_target_are_used(self):
        self.assertTrue(checker.admit_release([], [PAIR_AB], [COORDINATES[0]]))
        self.assertFalse(checker.admit_release([COORDINATES[1]], [PAIR_AB], [COORDINATES[0]]))
        # The first target is undetermined; the second is reconstructed.
        self.assertFalse(checker.admit_release([], [(1, 0)], [(0, 1), (1, 0)]))
        self.assertFalse(checker.admit_release([], [(1, 1)], [(0, 0)]))

    def test_mean_is_useful_while_saturated_observations_reconstruct(self):
        mean = (Fraction(1, 3),) * 3
        self.assertTrue(checker.admit_release([], [mean], COORDINATES))
        self.assertFalse(checker.admit_release([], COORDINATES, COORDINATES))

    def test_near_equal_rational_rows_remain_independent(self):
        epsilon = Fraction(1, 10**80)
        history = [(1, 1)]
        proposed = [(1, 1 + epsilon)]
        self.assertEqual(float(1 + epsilon), 1.0)  # A float conversion would erase the distinction.
        self.assertEqual(checker.rank([*history, *proposed], 2), 2)
        self.assertFalse(checker.admit_release(history, proposed, [(1, 0), (0, 1)]))

    def test_fraction_strings_are_exact_and_inputs_are_not_modified(self):
        rows = [["1/3", "1/7"], ["2/3", "2/7"]]
        original = [row[:] for row in rows]
        self.assertEqual(checker.rank(rows, 2), 1)
        self.assertTrue(checker.identifies(rows, ("1", "3/7")))
        self.assertEqual(rows, original)

    def test_small_binary_ranks_match_determinant_oracle(self):
        possible_rows = tuple(product((0, 1), repeat=3))
        for rows in product(possible_rows, repeat=2):
            with self.subTest(rows=rows):
                expected = minor_rank(rows, 3)
                self.assertEqual(checker.rank(rows, 3), expected)
                for target in COORDINATES:
                    self.assertEqual(checker.identifies(rows, target),
                                     minor_rank((*rows, target), 3) == expected)

    def test_empty_and_zero_observations_have_zero_rank(self):
        self.assertEqual(checker.rank([], 3), 0)
        self.assertEqual(checker.rank([(0, 0, 0)], 3), 0)
        self.assertFalse(checker.identifies([], (1, 0, 0)))
        self.assertTrue(checker.identifies([], (0, 0, 0)))

    def test_empty_protection_is_vacuous_for_valid_positive_width(self):
        self.assertTrue(checker.admit_release([], [(1,)], []))
        self.assertTrue(checker.admit_release([(1, 2)], [(3, 4)], []))

    def test_all_release_rows_have_positive_common_width(self):
        cases = (
            ([], [], []), ([], [()], []),
            ([], [(1,), (1, 2)], []), ([(1, 2)], [(1,)], []),
            ([], [(1,)], [(1,), (1, 2)]),
            ([], [(1, 2)], [(1, 2), (1,)]),
        )
        for history, proposed, protected in cases:
            with self.subTest(history=history, proposed=proposed, protected=protected):
                with self.assertRaises(ValueError):
                    checker.admit_release(history, proposed, protected)

    def test_invalid_rational_tail_is_not_skipped_after_refusal(self):
        with self.assertRaises(ValueError):
            checker.admit_release([], [(1,)], [(1,), ("not-a-rational",)])


class GrantTests(unittest.TestCase):
    def test_current_computation_grant_allows_its_named_use(self):
        self.assertTrue(permitted(["a"], [grant()]))

    def test_compute_train_disclose_and_commercial_rights_stay_distinct(self):
        compute = grant()
        for act in ("train", "disclose", "commercial"):
            with self.subTest(act=act):
                self.assertFalse(permitted(["a"], [compute], act=act))
        train = grant(acts=frozenset({"train"}), purpose="model")
        self.assertTrue(permitted(["a"], [compute, train], act="train", purpose="model"))
        self.assertFalse(permitted(["a"], [compute, train], act="train", purpose="research"))
        self.assertFalse(permitted(["a"], [train], act="compute", purpose="model"))
        self.assertFalse(permitted(["a"], [compute, train], act="disclose", purpose="model"))

    def test_every_lineage_source_requires_its_own_grant(self):
        self.assertFalse(permitted(["a", "b"], [grant("a")]))
        self.assertTrue(permitted(["a", "b"], [grant("a"), grant("b")]))
        for missing in ("a", "b", "c"):
            with self.subTest(missing=missing):
                grants = [grant(source) for source in ("a", "b", "c") if source != missing]
                self.assertFalse(permitted(["a", "b", "c"], grants))

    def test_duplicate_lineage_and_extra_unrelated_grants_do_not_expand_rights(self):
        self.assertTrue(permitted(["a", "a"], [grant("a")]))
        self.assertFalse(permitted(["a", "b", "a"], [grant("a"), grant("unrelated")]))
        self.assertTrue(permitted(iter(["a", "b"]), iter([grant("b"), grant("a")])))

    def test_one_complete_grant_is_needed_not_pieces_of_incompatible_grants(self):
        wrong_purpose = grant(purpose="unrelated")
        wrong_act = grant(acts=frozenset({"train"}))
        self.assertFalse(permitted(["a"], [wrong_purpose, wrong_act]))
        for grants in ([wrong_purpose, grant()], [grant(), wrong_purpose]):
            self.assertTrue(permitted(["a"], grants))

    def test_purpose_and_audience_are_exact(self):
        self.assertFalse(permitted(["a"], [grant()], purpose="model"))
        self.assertFalse(permitted(["a"], [grant()], audience="public"))

    def test_validity_interval_is_inclusive_and_current(self):
        for time, expected in ((-1, False), (0, True), (10, True), (11, False)):
            with self.subTest(time=time):
                self.assertEqual(permitted(["a"], [grant(retain_until=20)],
                                           at=time, retain_until=max(time, 5)), expected)

    def test_retention_respects_use_time_lower_and_upper_bounds(self):
        bounded = grant(retain_from=4, retain_until=8)
        for time, deadline, expected in ((2, 3, False), (2, 4, True), (2, 8, True),
                                          (2, 9, False), (7, 6, False), (7, 7, True)):
            with self.subTest(time=time, deadline=deadline):
                self.assertEqual(permitted(["a"], [bounded], at=time, retain_until=deadline), expected)
        self.assertFalse(permitted(["a"], [grant()], retain_until=50))

    def test_multisource_retention_intersection_preserves_all_bounds(self):
        grants = [grant("a", retain_from=4, retain_until=9),
                  grant("b", retain_from=6, retain_until=8)]
        for deadline, expected in ((5, False), (6, True), (8, True), (9, False)):
            with self.subTest(deadline=deadline):
                self.assertEqual(permitted(["a", "b"], grants, retain_until=deadline), expected)
        disjoint = [grant("a", retain_until=4), grant("b", retain_from=6)]
        self.assertFalse(permitted(["a", "b"], disjoint, retain_until=5))

    def test_empty_lineage_has_only_retention_time_requirement(self):
        for deadline, expected in ((2, False), (5, True), (8, True), (10**30, True)):
            with self.subTest(deadline=deadline):
                self.assertEqual(permitted([], [], at=5, retain_until=deadline), expected)


class SelfTestTests(unittest.TestCase):
    def test_self_test_executes_both_admission_functions(self):
        with patch.object(checker, "admit_release", wraps=checker.admit_release) as releases:
            with patch.object(checker, "admit_action", wraps=checker.admit_action) as actions:
                self.assertEqual(checker.self_test(), 13)
                self.assertEqual(releases.call_count, 4)
                self.assertEqual(actions.call_count, 9)

    def test_self_test_rejects_always_allow_and_always_refuse(self):
        for function in ("admit_release", "admit_action"):
            for outcome in (True, False):
                with self.subTest(function=function, outcome=outcome):
                    with patch.object(checker, function, return_value=outcome):
                        with self.assertRaises(AssertionError):
                            checker.self_test()

    def test_cli_and_call_counts_survive_python_optimization(self):
        path = Path(checker.__file__).resolve()
        instrument = r'''
import json, sys
from unittest.mock import patch
sys.path.insert(0, sys.argv[1])
import disclosure_composition_checker as checker
with patch.object(checker, "admit_release", wraps=checker.admit_release) as release:
    with patch.object(checker, "admit_action", wraps=checker.admit_action) as action:
        count = checker.self_test()
        print(json.dumps([count, release.call_count, action.call_count]))
'''
        for optimized in (False, True):
            with self.subTest(optimized=optimized):
                command = [sys.executable] + (["-O"] if optimized else [])
                result = subprocess.run(command + [str(path)], capture_output=True, text=True, timeout=20)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn("13 admission checks passed", result.stdout)
                counted = subprocess.run(command + ["-c", instrument, str(path.parent)],
                                         capture_output=True, text=True, timeout=20)
                self.assertEqual(counted.returncode, 0, counted.stderr)
                self.assertEqual(json.loads(counted.stdout), [13, 4, 9])


class MutationTests(unittest.TestCase):
    def test_independent_semantic_mutations_are_detected(self):
        release_guard = "return not any(identifies(combined, target) for target in protected)"
        grant_start = "    by_source: dict[str, list[Grant]] = {}"
        mutations = (
            ("    if retain_until < at:\n        return False\n", "",
             "GrantTests.test_empty_lineage_has_only_retention_time_requirement", True),
            (release_guard, "return True", "LinearDisclosureTests.test_third_sum_reconstructs_and_is_refused", True),
            (release_guard, "return False", "LinearDisclosureTests.test_useful_pairwise_aggregates_are_admitted", True),
            (grant_start, "    return True\n" + grant_start,
             "GrantTests.test_compute_train_disclose_and_commercial_rights_stay_distinct", True),
            (grant_start, "    return False\n" + grant_start,
             "GrantTests.test_current_computation_grant_allows_its_named_use", True),
            ("for source in set(lineage):", "for source in tuple(lineage)[:1]:",
             "GrantTests.test_every_lineage_source_requires_its_own_grant", True),
            ("and max(at, grant.retain_from) <= retain_until <= grant.retain_until", "and True",
             "GrantTests.test_retention_respects_use_time_lower_and_upper_bounds", True),
            ("return value if isinstance(value, Fraction) else Fraction(value)", "return Fraction(float(value))",
             "LinearDisclosureTests.test_near_equal_rational_rows_remain_independent", True),
            ("combined = _matrix([*history, *proposed], width)\n    protected = _matrix(protected, width)",
             "combined = [*history, *proposed]",
             "LinearDisclosureTests.test_all_release_rows_have_positive_common_width", False),
        )
        runner = r'''
import pathlib, sys, types, unittest
folder, old, new, target, self_test_must_fail = sys.argv[1:]
path = pathlib.Path(folder) / "disclosure_composition_checker.py"
source = path.read_text()
if source.count(old) != 1:
    raise RuntimeError("mutation anchor is not unique")
module = types.ModuleType("disclosure_composition_checker")
module.__file__ = str(path)
sys.modules[module.__name__] = module
exec(compile(source.replace(old, new), str(path), "exec"), module.__dict__)
if self_test_must_fail == "True":
    try:
        module.self_test()
    except AssertionError:
        pass
    else:
        raise RuntimeError("mutant survived CLI self-test")
sys.path.insert(0, folder)
suite = unittest.defaultTestLoader.loadTestsFromName("test_disclosure_composition_checker." + target)
result = unittest.TextTestRunner().run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
'''
        for old, new, target, self_test_must_fail in mutations:
            with self.subTest(target=target):
                command = [sys.executable] + ([] if __debug__ else ["-O"])
                result = subprocess.run(command + ["-c", runner, str(Path(__file__).parent),
                                        old, new, target, str(self_test_must_fail)],
                                        capture_output=True, text=True, timeout=20)
                self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
                self.assertIn("FAILED (failures=", result.stderr)
                self.assertNotIn("ERROR:", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
