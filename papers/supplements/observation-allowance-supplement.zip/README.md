# Finite allowances and resource menus

This standalone supplement accompanies the observation-allowance construction in
*Op: Compliance-Carrying Operations*.

It uses exact rational arithmetic to check finite policy envelopes, the least
allowance on each observation fiber, and the capacity criterion for independent
policies. Its request tables realize declared lifetime demand. A serialized
reference machine issues a condition-selected 100-unit liability from a shared
100-unit allowance and retains consumed quantities through discharge.

The resource-menu construction gives an optimal cover for two execution groups
with integral requests in distinct resource coordinates. Real slack uses its
integer floor. The tests compare small cases with an independent set-cover
search over every nonempty local menu.

## Run

Python 3.9 or later is required. The supplement uses only the standard library.
Run these commands from the extracted directory:

```sh
python3 verify_observation_allowance.py
python3 -O verify_observation_allowance.py
python3 -m unittest discover -s . -p test_verify_observation_allowance.py -v
python3 -O -m unittest discover -s . -p test_verify_observation_allowance.py -v
```

Both checker commands return identical JSON with status `passed` and 19 checks.
The report gives joint allowance 100, separate allowances 100 and 100, and total
separate allowance 200. It constructs the applicable 100-unit request in each
world and retains discharged quantity 100. Resource-menu counts are nine for
capacity (4,4) with slack (1,1), and three for capacity 2 with slack 1/2.
Both unittest commands run 31 tests and finish with `OK`. Every command exits zero.
`PROFILE.json` records the complete expected checker report and checked version.

## Exact scope

The allowance model has finite world and policy tables. Its request realization
uses additive, nonreplenishing lifetime quantities. The state machine has one
shared reservation authority, one risk scope, one asset, and one fixed cap epoch.
Evidence identifiers refer to supplied admission fixtures. Reclassification and
discharge enter as admitted accounting events.

These checks do not establish evidence truth, legal authority, provider behavior,
bytecode extraction, durable storage, or concurrent and distributed refinement.
The resource-menu theorem concerns two groups and actual eligible added capacity.
Its label count starts after compatible selection. Selection protocols, privacy,
and permission to use the resources require separate contracts and evidence.

## Members and hashes

- `verify_observation_allowance.py`: exact checker and finite reference transitions.
- `test_verify_observation_allowance.py`: arithmetic, support, binding, and admission tests.
- `PROFILE.json`: scope, interpreter requirements, commands, and expected results.
- `SHA256SUMS`: SHA-256 for each other archive member. It excludes itself.

The archive has fixed member order, timestamps, and permissions. It contains no
paper or PDF hash. All evidence fixtures use synthetic identifiers and requests.
