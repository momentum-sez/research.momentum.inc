"""Finite arithmetic and admission regressions for Op's observable allowances.

Run with python3 -m unittest discover -s papers -p test_verify_observation_allowance.py.
The evidence fixtures are model inputs. These tests do not establish external
truth, provider behavior, durable storage, or concurrent implementation.
"""

from dataclasses import replace
from fractions import Fraction
from itertools import permutations, product
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

import verify_observation_allowance as checker


def measurable(values, observations):
    return all(observations[i] != observations[j] or values[i] == values[j]
               for i in range(len(values)) for j in range(len(values)))


def machine_for(profile, extra_evidence=()):
    return checker.AllowanceMachine(profile.scope, profile.asset, profile.epoch, profile.capacity,
                                    checker.evidence_fixtures(profile) + tuple(extra_evidence))


def owner_machine():
    profile = checker.complementary_profile()
    machine = machine_for(profile)
    receipt = machine.issue(profile, "owner", "owner:blind")
    machine.select(receipt.owner, "conditional-pair")
    return profile, machine, receipt.owner


def arbitrary_menu_optimum(capacity, slack):
    """Small independent set-cover oracle over every nonempty local menu."""
    points = tuple(product(*(range(b + 1) for b in capacity)))
    feasible = tuple((x, y) for x, y in product(points, repeat=2)
                     if all(a + b <= cap for a, b, cap in zip(x, y, capacity)))
    subsets = tuple(tuple(p for i, p in enumerate(points) if mask & (1 << i))
                    for mask in range(1, 1 << len(points)))
    covers = set()
    for left, right in product(subsets, repeat=2):
        if all(all(a + b <= cap + extra for a, b, cap, extra in zip(x, y, capacity, slack))
               for x, y in product(left, right)):
            covers.add(sum(1 << i for i, (x, y) in enumerate(feasible) if x in left and y in right))
    target = (1 << len(feasible)) - 1
    reached = {0}
    for count in range(1, len(feasible) + 1):
        reached = {state | cover for state in reached for cover in covers}
        if target in reached:
            return count
    raise AssertionError("singleton menus should cover every original feasible pair")


class ResourceMenuTests(unittest.TestCase):
    def test_cover_formula_matches_arbitrary_menu_search_in_small_domains(self):
        for capacity, slack in (((2,), (0,)), ((2,), (Fraction(1, 2),)), ((2,), (1,)),
                                ((1, 1), (0, 0)), ((1, 1), (1, 0))):
            with self.subTest(capacity=capacity, slack=slack):
                optimum = arbitrary_menu_optimum(capacity, slack)
                self.assertEqual(checker.check_resource_menu_certificate(capacity, slack), optimum)

    def test_nine_cell_construction_has_nine_incompatible_boundary_pairs(self):
        self.assertEqual(checker.check_resource_menu_certificate((4, 4), (1, 1)), 9)
        self.assertEqual(len(checker.resource_menu_boundary((4, 4), (1, 1))), 9)
        self.assertEqual(len(checker.resource_menu_cover((4, 4), (1, 1))), 9)
        menus = checker.resource_menu_cover((4, 4), (1, 1))
        self.assertFalse(any(menu.contains((Fraction(1, 2), 0), (0, 0)) for menu in menus))

    def test_integral_and_real_slack_edges_retain_the_original_menu_range(self):
        self.assertEqual([checker.resource_menu_count((100,), (delta,)) for delta in (0, 4, 9, 100)],
                         [101, 21, 11, 1])
        self.assertEqual(checker.check_resource_menu_certificate((0, 0), (0, "1/2")), 1)
        self.assertEqual(checker.check_resource_menu_certificate((2,), ("1/2",)), 3)
        self.assertEqual(checker.check_resource_menu_certificate((2,), (2,)), 1)

    def test_malformed_resource_domains_and_incorrect_certificates_fail(self):
        for capacity, slack in (((), ()), ((-1,), (0,)), ((True,), (0,)),
                                ((2,), (0, 0)), ((2,), (-1,)), ((2,), (0.5,))):
            with self.assertRaises(ValueError):
                checker.resource_menu_cover(capacity, slack)
        with patch.object(checker, "resource_menu_boundary", return_value=(((0,), (2,)),)):
            with self.assertRaisesRegex(AssertionError, "certificate sizes"):
                checker.check_resource_menu_certificate((2,), (0,))


class EnvelopeTests(unittest.TestCase):
    def test_product_maximum_matches_sum_of_marginal_maxima_exhaustively(self):
        rows = tuple(product(range(2), repeat=2))
        for choices in product(rows, repeat=4):
            families = (choices[:2], choices[2:])
            marginal = tuple(checker.policy_envelope(family) for family in families)
            summed = tuple(sum(column) for column in zip(*marginal))
            direct = checker.joint_envelope(families)
            self.assertEqual(summed, direct)
            for capacities in product(range(3), repeat=2):
                every_tuple_safe = all(
                    all(sum(plan[w] for plan in selected) <= capacities[w] for w in range(2))
                    for selected in product(*families))
                self.assertEqual(all(u <= c for u, c in zip(summed, capacities)), every_tuple_safe)

    def test_policy_envelope_is_least_even_with_nonmaximizing_policies(self):
        families = ((0, 3, 1), (2, 0, 1), (1, 1, 1))
        envelope = checker.policy_envelope(families)
        self.assertEqual(envelope, (2, 3, 1))
        for candidate in product(range(4), repeat=3):
            bounds_every_policy = all(all(d <= b for d, b in zip(row, candidate)) for row in families)
            self.assertEqual(bounds_every_policy, all(u <= b for u, b in zip(envelope, candidate)))

    def test_coupled_support_is_not_replaced_by_its_cartesian_completion(self):
        families = (((0,), (100,)), ((0,), (100,)))
        permitted = (((0, 1), (1, 0)),)
        self.assertEqual(checker.joint_envelope(families, permitted), (100,))
        self.assertEqual(checker.joint_envelope(families), (200,))

    def test_closure_and_leastness_on_all_three_world_partitions(self):
        partitions = (("a", "a", "a"), ("a", "a", "b"), ("a", "b", "a"),
                      ("a", "b", "b"), ("a", "b", "c"))
        vectors = tuple(product(range(3), repeat=3))
        for observations, values in product(partitions, vectors):
            envelope = checker.observable_envelope(values, observations)
            self.assertTrue(measurable(envelope, observations))
            self.assertTrue(all(f <= u for f, u in zip(values, envelope)))
            self.assertEqual(checker.observable_envelope(envelope, observations), envelope)
            self.assertEqual(envelope == values, measurable(values, observations))
            for candidate in vectors:
                if measurable(candidate, observations) and all(f <= b for f, b in zip(values, candidate)):
                    self.assertTrue(all(u <= b for u, b in zip(envelope, candidate)))
                if all(f <= h for f, h in zip(values, candidate)):
                    upper = checker.observable_envelope(candidate, observations)
                    self.assertTrue(all(u <= v for u, v in zip(envelope, upper)))

    def test_refining_observations_cannot_increase_the_least_allowance(self):
        values = (1, 4, 2, 3)
        coarse = checker.observable_envelope(values, ("a", "a", "a", "a"))
        middle = checker.observable_envelope(values, ("a", "a", "b", "b"))
        fine = checker.observable_envelope(values, ("a", "b", "c", "d"))
        self.assertEqual(coarse, (4, 4, 4, 4))
        self.assertEqual(middle, (4, 4, 3, 3))
        self.assertEqual(fine, values)
        self.assertTrue(all(f <= m <= c for f, m, c in zip(fine, middle, coarse)))

    def test_measurable_allowance_existence_iff_by_independent_search(self):
        vectors = tuple(product(range(2), repeat=2))
        partitions = (("a", "a"), ("a", "b"))
        for first, second, o1, o2 in product(vectors, vectors, partitions, partitions):
            u1 = checker.observable_envelope(first, o1)
            u2 = checker.observable_envelope(second, o2)
            candidates = [(b1, b2) for b1, b2 in product(vectors, repeat=2)
                          if measurable(b1, o1) and measurable(b2, o2)
                          and all(d <= b for d, b in zip(first, b1))
                          and all(d <= b for d, b in zip(second, b2))]
            for capacities in product(range(3), repeat=2):
                exists = any(all(b1[w] + b2[w] <= capacities[w] for w in range(2))
                             for b1, b2 in candidates)
                self.assertEqual(exists, all(u1[w] + u2[w] <= capacities[w] for w in range(2)))

    def test_joint_equality_requires_a_common_maximizing_world(self):
        for first, second in product(product(range(3), repeat=3), repeat=2):
            joint = max(a + b for a, b in zip(first, second))
            separate = max(first) + max(second)
            common = any(a == max(first) and b == max(second) for a, b in zip(first, second))
            self.assertLessEqual(joint, separate)
            self.assertEqual(joint == separate, common)

    def test_near_equal_rationals_do_not_collapse_to_a_float(self):
        epsilon = Fraction(1, 10**80)
        envelope = checker.observable_envelope((1, 1 + epsilon), ("blind", "blind"))
        self.assertEqual(envelope, (1 + epsilon, 1 + epsilon))
        self.assertGreater(sum(envelope), 2)

    def test_invalid_finite_domains_and_inexact_quantities_are_rejected(self):
        for call in (lambda: checker.policy_envelope(()),
                     lambda: checker.policy_envelope(((),)),
                     lambda: checker.policy_envelope(((1,), (1, 2))),
                     lambda: checker.observable_envelope((1, 2), ("a",)),
                     lambda: checker.joint_envelope(()),
                     lambda: checker.joint_envelope((((1,),),), ((),)),
                     lambda: checker.joint_envelope((((1,),),), (((1,),),)),
                     lambda: checker.quantity(0.5), lambda: checker.quantity(True),
                     lambda: checker.quantity(-1)):
            with self.assertRaises(ValueError):
                call()


class ProfileTests(unittest.TestCase):
    def test_request_support_must_realize_every_demand_entry(self):
        profile = checker.complementary_profile()
        actor = profile.actors[0]
        policy = actor.policies[0]
        for demands in ((99, 100), (101, 100), (100,)):
            with self.subTest(demands=demands), self.assertRaisesRegex(ValueError, "demand"):
                replace(profile, actors=(replace(actor, policies=(replace(policy, demands=demands),)),))
        bad_row = replace(policy.occurrences[0], worlds=frozenset({"unknown"}))
        with self.assertRaisesRegex(ValueError, "unknown world"):
            replace(profile, actors=(replace(actor, policies=(replace(policy, occurrences=(bad_row,)),)),))

    def test_digest_binds_every_semantic_component(self):
        profile = checker.complementary_profile()
        actor = profile.actors[0]
        policy = actor.policies[0]
        changes = (replace(profile, scope="other-risk"), replace(profile, asset="other-unit"),
                   replace(profile, epoch=2), replace(profile, lifetime="other-lifetime"),
                   replace(profile, capacity=200), replace(profile, evidence_contract="other-contract"),
                   replace(profile, actors=(replace(actor, observations=("0", "1")),)),
                   replace(profile, actors=(replace(actor, policies=(replace(policy, name="other"),)),)),
                   replace(profile, actors=(replace(actor, policies=(replace(
                       policy, occurrences=(replace(policy.occurrences[0], request=b"another recipient"),
                                            policy.occurrences[1])),)),)))
        self.assertEqual(len({p.digest() for p in changes} | {profile.digest()}), len(changes) + 1)

    def test_conflicting_occurrence_identity_is_rejected(self):
        profile = checker.complementary_profile(separate=True)
        first, second = profile.actors
        policy = second.policies[0]
        conflict = replace(policy.occurrences[0], name=first.policies[0].occurrences[0].name)
        with self.assertRaisesRegex(ValueError, "conflicting owner"):
            replace(profile, actors=(first, replace(second, policies=(replace(
                policy, occurrences=(conflict,)),))))


class ConditionalOwnerTests(unittest.TestCase):
    def test_separate_blind_grants_need_200_and_share_one_aggregate_guard(self):
        for capacity, second_succeeds in ((100, False), (200, True)):
            profile = checker.complementary_profile(separate=True, capacity=capacity)
            machine = machine_for(profile)
            first = machine.issue(profile, "actor-0", "actor-0:blind")
            self.assertEqual(first.amount, 100)
            if second_succeeds:
                self.assertEqual(machine.issue(profile, "actor-1", "actor-1:blind").amount, 100)
                self.assertEqual(machine.reserved, 200)
            else:
                with self.assertRaisesRegex(ValueError, "aggregate"):
                    machine.issue(profile, "actor-1", "actor-1:blind")
                self.assertEqual(machine.reserved, 100)
                self.assertEqual(len(machine.grants), 1)
            machine.check_invariants()

    def test_owner_constructs_the_correct_liability_in_both_worlds(self):
        for world in (0, 1):
            profile, machine, owner = owner_machine()
            occurrence = profile.actors[0].policies[0].occurrences[world]
            record = machine.prepare(owner, occurrence.name, f"c{world}", occurrence.request, f"owner:{world}")
            grant = machine.grants[owner]
            self.assertEqual((grant.free, grant.pending, machine.reserved), (0, 100, 100))
            self.assertEqual((record.worlds, record.occurrence), (frozenset({str(world)}), f"duty-{world}"))
            self.assertEqual(record.profile, grant.receipt.profile)
            self.assertEqual(len(machine.outbox), 1)
            machine.check_invariants()

    def test_blind_evidence_cannot_issue_either_conditional_request(self):
        profile, machine, owner = owner_machine()
        for occurrence in profile.actors[0].policies[0].occurrences:
            with self.assertRaisesRegex(ValueError, "condition evidence"):
                machine.prepare(owner, occurrence.name, occurrence.name, occurrence.request, "owner:blind")
        self.assertEqual(len(machine.outbox), 0)
        self.assertEqual(machine.grants[owner].free, 100)
        machine.check_invariants()

    def test_initial_evidence_cannot_omit_an_indistinguishable_world(self):
        profile = checker.complementary_profile()
        machine = machine_for(profile)
        with self.assertRaisesRegex(ValueError, "indistinguishable"):
            machine.issue(profile, "owner", "owner:0")
        self.assertEqual(machine.reserved, 0)

    def test_retries_return_the_existing_owner_and_outbox(self):
        profile, machine, owner = owner_machine()
        receipt = machine.grants[owner].receipt
        self.assertEqual(machine.issue(profile, "owner", "owner:blind"), receipt)
        row = profile.actors[0].policies[0].occurrences[0]
        record = machine.prepare(owner, row.name, "command", row.request, "owner:0")
        version = machine.version
        self.assertIs(machine.prepare(owner, row.name, "command", row.request, "owner:0"), record)
        self.assertEqual(machine.version, version)
        with self.assertRaisesRegex(ValueError, "conflicting request"):
            machine.prepare(owner, row.name, "command", b"changed bytes", "owner:0")
        with self.assertRaisesRegex(ValueError, "already issued"):
            machine.prepare(owner, row.name, "fresh-command", row.request, "owner:0")
        machine.check_invariants()

    def test_changed_profile_cannot_reissue_the_same_owner_lifetime(self):
        profile, machine, owner = owner_machine()
        actor = profile.actors[0]
        changed = replace(profile, actors=(replace(actor, observations=("0", "1")),))
        fixture = checker.Evidence("changed", changed.digest(), "owner", frozenset({"0"}))
        machine.evidence[fixture.name] = fixture
        with self.assertRaisesRegex(ValueError, "owner lifetime"):
            machine.issue(changed, "owner", fixture.name)
        self.assertEqual(len(machine.grants), 1)
        self.assertEqual(machine.grants[owner].free, 100)

    def test_foreign_profile_actor_and_unknown_evidence_cannot_authorize(self):
        profile = checker.complementary_profile()
        wrong_profile = checker.Evidence("wrong-profile", "unrelated", "owner", frozenset({"0"}))
        wrong_actor = checker.Evidence("wrong-actor", profile.digest(), "other", frozenset({"0"}))
        empty = checker.Evidence("empty", profile.digest(), "owner", frozenset())
        outside = checker.Evidence("outside", profile.digest(), "owner", frozenset({"unknown"}))
        machine = machine_for(profile, (wrong_profile, wrong_actor, empty, outside))
        owner = machine.issue(profile, "owner", "owner:blind").owner
        machine.select(owner, "conditional-pair")
        row = profile.actors[0].policies[0].occurrences[0]
        for fixture in ("wrong-profile", "wrong-actor", "empty", "outside", "absent"):
            with self.subTest(fixture=fixture), self.assertRaises(ValueError):
                machine.prepare(owner, row.name, fixture, row.request, fixture)
        self.assertEqual(machine.grants[owner].free, 100)
        self.assertEqual(len(machine.outbox), 0)

    def test_scope_asset_capacity_and_epoch_are_checked_at_issuance(self):
        profile = checker.complementary_profile()
        for changed in (replace(profile, scope="other"), replace(profile, asset="other"),
                        replace(profile, capacity=200), replace(profile, epoch=2)):
            with self.subTest(profile=changed.digest()), self.assertRaisesRegex(ValueError, "wrong scope"):
                machine_for(profile).issue(changed, "owner", "owner:blind")

    def test_partial_outcomes_and_discharge_do_not_recycle_the_allowance(self):
        profile, machine, owner = owner_machine()
        row = profile.actors[0].policies[0].occurrences[0]
        machine.prepare(owner, row.name, "command", row.request, "owner:0")
        machine.reclassify(owner, 60)
        grant = machine.grants[owner]
        self.assertEqual((grant.pending, grant.recognized, machine.reserved), (40, 60, 100))
        with self.assertRaisesRegex(ValueError, "pending"):
            machine.reclassify(owner, 41)
        with self.assertRaisesRegex(ValueError, "recognized"):
            machine.discharge(owner, 61)
        machine.reclassify(owner, 40)
        machine.discharge(owner, 100)
        self.assertEqual((grant.free, grant.discharged, machine.reserved), (0, 100, 0))
        with self.assertRaisesRegex(ValueError, "already issued"):
            machine.prepare(owner, row.name, "new-key-after-discharge", row.request, "owner:0")
        self.assertEqual(machine.issue(profile, "owner", "owner:blind").amount, 100)
        self.assertEqual(grant.free, 0)
        machine.check_invariants()

    def test_conflicting_world_evidence_preserves_reservations_and_blocks_fresh_issuance(self):
        profile, machine, owner = owner_machine()
        first, second = profile.actors[0].policies[0].occurrences
        machine.prepare(owner, first.name, "first", first.request, "owner:0")
        with self.assertRaisesRegex(ValueError, "empty world intersection"):
            machine.prepare(owner, second.name, "second", second.request, "owner:1")
        self.assertTrue(machine.grants[owner].blocked)
        self.assertEqual(machine.grants[owner].worlds, frozenset({"0"}))
        with self.assertRaisesRegex(ValueError, "blocks fresh issuance"):
            machine.prepare(owner, first.name, "third", first.request, "owner:0")
        self.assertEqual(machine.reserved, 100)
        machine.check_invariants()

    def test_fresh_lifetime_cannot_ignore_prior_active_liability(self):
        profile, machine, owner = owner_machine()
        row = profile.actors[0].policies[0].occurrences[0]
        machine.prepare(owner, row.name, "old", row.request, "owner:0")
        fresh = replace(profile, lifetime="next-lifetime")
        proof = checker.Evidence("fresh", fresh.digest(), "owner", frozenset(fresh.worlds))
        machine.evidence[proof.name] = proof
        with self.assertRaisesRegex(ValueError, "aggregate"):
            machine.issue(fresh, "owner", "fresh")
        self.assertEqual(machine.reserved, 100)

    def test_policy_selection_cannot_mix_two_supported_programs(self):
        profile = checker.complementary_profile()
        actor = profile.actors[0]
        first = actor.policies[0]
        alternate = replace(first, name="alternate")
        profile = replace(profile, actors=(replace(actor, policies=(first, alternate)),))
        machine = machine_for(profile)
        owner = machine.issue(profile, "owner", "owner:blind").owner
        row = first.occurrences[0]
        with self.assertRaisesRegex(ValueError, "must be selected"):
            machine.prepare(owner, row.name, "none", row.request, "owner:0")
        with self.assertRaisesRegex(ValueError, "outside"):
            machine.select(owner, "unknown")
        machine.select(owner, first.name)
        with self.assertRaisesRegex(ValueError, "cannot change"):
            machine.select(owner, alternate.name)

    def test_all_supported_occurrences_can_be_issued_in_every_order(self):
        rows = tuple(checker.Occurrence(str(q), frozenset({"0"}), Fraction(q), str(q).encode())
                     for q in (20, 30, 40))
        actor = checker.Actor("owner", ("known",), (checker.Policy("all", (90,), rows),))
        profile = checker.Profile("risk", "unit", 1, "one-lifetime", ("0",), Fraction(90), (actor,))
        proof = checker.Evidence("known", profile.digest(), "owner", frozenset({"0"}))
        for order in permutations(rows):
            machine = checker.AllowanceMachine("risk", "unit", 1, 90, (proof,))
            owner = machine.issue(profile, "owner", "known").owner
            machine.select(owner, "all")
            for row in order:
                machine.prepare(owner, row.name, row.name, row.request, "known")
                machine.reclassify(owner, row.amount)
                machine.discharge(owner, row.amount)
                machine.check_invariants()
            self.assertEqual((machine.grants[owner].free, machine.grants[owner].discharged), (0, 90))
            self.assertEqual(len(machine.outbox), 3)


class ExecutableTests(unittest.TestCase):
    def test_cli_has_identical_results_with_and_without_optimization(self):
        script = Path(checker.__file__).resolve()
        outputs = []
        for flags in ((), ("-O",)):
            result = subprocess.run((sys.executable, *flags, str(script)), capture_output=True,
                                    text=True, check=True)
            outputs.append(json.loads(result.stdout))
        self.assertEqual(outputs[0], outputs[1])
        self.assertEqual(outputs[0]["status"], "passed")
        self.assertEqual(outputs[0]["joint_allowance"], "100")
        self.assertEqual(outputs[0]["separate_total"], "200")
        self.assertEqual(set(outputs[0]["conditional_owner_traces"]), {"0", "1"})

    def test_self_test_detects_a_broken_observation_maximum(self):
        with patch.object(checker, "observable_envelope", side_effect=lambda values, observations: tuple(values)):
            with self.assertRaisesRegex(AssertionError, "least blind allowances"):
                checker.self_test()


if __name__ == "__main__":
    unittest.main()
