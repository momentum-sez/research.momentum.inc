#!/usr/bin/env python3
"""Exact finite checks for Op's observable allowances and conditional owner.

The transition model uses one risk scope, one asset, and a fixed capacity epoch.
Evidence identifiers resolve through supplied admission fixtures. This model
does not implement signatures, storage transactions, providers, or bytecode.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
from math import prod
from typing import Iterable, Sequence, Union


Number = Union[int, str, Fraction]
Vector = tuple[Fraction, ...]


def quantity(value: Number) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (int, str, Fraction)):
        raise ValueError("quantity must be an exact integer or rational")
    result = Fraction(value)
    if result < 0:
        raise ValueError("quantity must be nonnegative")
    return result


def vector(values: Iterable[Number]) -> Vector:
    result = tuple(quantity(value) for value in values)
    if not result:
        raise ValueError("world set must be nonempty")
    return result


def policy_envelope(policies: Sequence[Sequence[Number]]) -> Vector:
    rows = tuple(vector(row) for row in policies)
    if not rows or any(len(row) != len(rows[0]) for row in rows):
        raise ValueError("policy family must be nonempty with one demand per world")
    return tuple(max(column) for column in zip(*rows))


def observable_envelope(values: Sequence[Number], observations: Sequence[str]) -> Vector:
    values = vector(values)
    if len(values) != len(observations):
        raise ValueError("observation table must cover every world")
    maxima: dict[str, Fraction] = {}
    for value, observation in zip(values, observations):
        maxima[observation] = max(value, maxima.get(observation, Fraction(0)))
    return tuple(maxima[observation] for observation in observations)


def joint_envelope(
    families: Sequence[Sequence[Sequence[Number]]],
    support: Sequence[Sequence[tuple[int, ...]]] | None = None,
) -> Vector:
    """Enumerate permitted policy tuples directly, including coupled support."""
    rows = tuple(tuple(vector(row) for row in family) for family in families)
    if not rows or any(not family for family in rows):
        raise ValueError("actor and policy sets must be nonempty")
    width = len(rows[0][0])
    if any(len(row) != width for family in rows for row in family):
        raise ValueError("policy tables must use the same world set")
    all_choices = tuple(product(*(range(len(family)) for family in rows)))
    permitted = tuple(support) if support is not None else (all_choices,) * width
    if len(permitted) != width or any(not choices for choices in permitted):
        raise ValueError("joint support must be nonempty in every world")
    totals = []
    for world, choices in enumerate(permitted):
        for choice in choices:
            if (len(choice) != len(rows)
                    or any(type(p) is not int or not 0 <= p < len(rows[i])
                           for i, p in enumerate(choice))):
                raise ValueError("joint support contains an unknown policy tuple")
        totals.append(max(sum((rows[i][p][world] for i, p in enumerate(choice)), Fraction(0))
                          for choice in choices))
    return tuple(totals)


def _menu_domain(capacity: Sequence[int], slack: Sequence[Number]) -> tuple[tuple[int, ...], Vector]:
    capacity, slack = tuple(capacity), vector(slack)
    if (not capacity or len(capacity) != len(slack)
            or any(type(b) is not int or b < 0 for b in capacity)):
        raise ValueError("menu capacities must be nonnegative integers with matching slack dimensions")
    return capacity, slack


@dataclass(frozen=True)
class ResourceMenu:
    left: tuple[int, ...]
    right: tuple[int, ...]

    def contains(self, x: tuple[int, ...], y: tuple[int, ...]) -> bool:
        return (len(x) == len(y) == len(self.left) == len(self.right)
                and all(type(value) is int and 0 <= value <= cap for value, cap in zip(x, self.left))
                and all(type(value) is int and 0 <= value <= cap for value, cap in zip(y, self.right)))


def resource_menu_count(capacity: Sequence[int], slack: Sequence[Number]) -> int:
    capacity, slack = _menu_domain(capacity, slack)
    return prod(b // (delta.numerator // delta.denominator + 1) + 1
                for b, delta in zip(capacity, slack))


def resource_menu_cover(capacity: Sequence[int], slack: Sequence[Number]) -> tuple[ResourceMenu, ...]:
    capacity, slack = _menu_domain(capacity, slack)
    steps = tuple(delta.numerator // delta.denominator + 1 for delta in slack)
    starts = product(*(range(0, b + 1, step) for b, step in zip(capacity, steps)))
    return tuple(ResourceMenu(tuple(min(a + step - 1, b) for a, step, b in zip(start, steps, capacity)),
                              tuple(b - a for a, b in zip(start, capacity))) for start in starts)


def resource_menu_boundary(capacity: Sequence[int], slack: Sequence[Number]) -> tuple:
    capacity, slack = _menu_domain(capacity, slack)
    grid = product(*(range(0, b + 1, delta.numerator // delta.denominator + 1)
                     for b, delta in zip(capacity, slack)))
    return tuple((u, tuple(b - value for b, value in zip(capacity, u))) for u in grid)


def check_resource_menu_certificate(capacity: Sequence[int], slack: Sequence[Number]) -> int:
    """Verify an explicit cover and pairwise incompatible lower witnesses."""
    capacity, slack = _menu_domain(capacity, slack)
    menus = resource_menu_cover(capacity, slack)
    boundary = resource_menu_boundary(capacity, slack)
    count = resource_menu_count(capacity, slack)
    if len(menus) != len(boundary) or len(menus) != count:
        raise AssertionError("menu count and certificate sizes disagree")
    for menu in menus:
        if (len(menu.left) != len(capacity) or len(menu.right) != len(capacity)
                or any(type(value) is not int or not 0 <= value <= b
                       for limits in (menu.left, menu.right) for value, b in zip(limits, capacity))):
            raise AssertionError("menu contains a value outside the integral request domain")
        if any(left + right > b + delta
               for left, right, b, delta in zip(menu.left, menu.right, capacity, slack)):
            raise AssertionError("menu permits an unsafe independent choice")
    points = tuple(product(*(range(b + 1) for b in capacity)))
    for x, y in product(points, repeat=2):
        if all(a + b <= cap for a, b, cap in zip(x, y, capacity)):
            if not any(menu.contains(x, y) for menu in menus):
                raise AssertionError("an originally feasible pair has no label")
    for index, (u, complement_u) in enumerate(boundary):
        if (u not in points or complement_u not in points
                or tuple(a + b for a, b in zip(u, complement_u)) != capacity):
            raise AssertionError("lower witness is not an original boundary pair")
        for v, complement_v in boundary[index + 1:]:
            crossed_excess = any(x + y > b + delta
                                for x, y, b, delta in zip(v, complement_u, capacity, slack))
            reverse_excess = any(x + y > b + delta
                                for x, y, b, delta in zip(u, complement_v, capacity, slack))
            if not crossed_excess and not reverse_excess:
                raise AssertionError("two lower witnesses can share a safe menu")
    return count


@dataclass(frozen=True)
class Occurrence:
    name: str
    worlds: frozenset[str]
    amount: Fraction
    request: bytes

    def __post_init__(self) -> None:
        object.__setattr__(self, "worlds", frozenset(self.worlds))
        object.__setattr__(self, "amount", quantity(self.amount))
        if not self.name or not self.worlds or not self.amount:
            raise ValueError("occurrence must have identity, support, and positive quantity")
        if not isinstance(self.request, bytes) or not self.request:
            raise ValueError("occurrence must bind exact request bytes")


@dataclass(frozen=True)
class Policy:
    name: str
    demands: Vector
    occurrences: tuple[Occurrence, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "demands", vector(self.demands))
        object.__setattr__(self, "occurrences", tuple(self.occurrences))
        if not self.name or len({r.name for r in self.occurrences}) != len(self.occurrences):
            raise ValueError("policy identity and occurrence identities must be unique")


@dataclass(frozen=True)
class Actor:
    name: str
    observations: tuple[str, ...]
    policies: tuple[Policy, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "observations", tuple(self.observations))
        object.__setattr__(self, "policies", tuple(self.policies))
        if (not self.name or not self.policies
                or len({p.name for p in self.policies}) != len(self.policies)):
            raise ValueError("actor must have a nonempty set of named policies")


@dataclass(frozen=True)
class Profile:
    scope: str
    asset: str
    epoch: int
    lifetime: str
    worlds: tuple[str, ...]
    capacity: Fraction
    actors: tuple[Actor, ...]
    evidence_contract: str = "admitted finite evidence fixtures"

    def __post_init__(self) -> None:
        object.__setattr__(self, "worlds", tuple(self.worlds))
        object.__setattr__(self, "actors", tuple(self.actors))
        object.__setattr__(self, "capacity", quantity(self.capacity))
        if (not all((self.scope, self.asset, self.lifetime, self.evidence_contract))
                or type(self.epoch) is not int or self.epoch < 0):
            raise ValueError("profile must bind scope, asset, epoch, lifetime, and evidence contract")
        if (not self.worlds or any(not isinstance(w, str) or not w for w in self.worlds)
                or len(set(self.worlds)) != len(self.worlds)):
            raise ValueError("world identifiers must be nonempty and unique")
        if not self.actors or len({actor.name for actor in self.actors}) != len(self.actors):
            raise ValueError("actor identifiers must be nonempty and unique")
        occurrences: dict[str, tuple[str, Occurrence]] = {}
        for actor in self.actors:
            if (len(actor.observations) != len(self.worlds)
                    or any(not isinstance(z, str) or not z for z in actor.observations)):
                raise ValueError("observation table must cover every world")
            for policy in actor.policies:
                if len(policy.demands) != len(self.worlds):
                    raise ValueError("demand table must cover every world")
                for occurrence in policy.occurrences:
                    if not occurrence.worlds <= set(self.worlds):
                        raise ValueError("occurrence support contains an unknown world")
                    binding = (actor.name, occurrence)
                    if occurrences.get(occurrence.name, binding) != binding:
                        raise ValueError("occurrence identity has conflicting owner or request")
                    occurrences[occurrence.name] = binding
                realized = tuple(sum((r.amount for r in policy.occurrences if w in r.worlds),
                                     Fraction(0)) for w in self.worlds)
                if realized != policy.demands:
                    raise ValueError("request support does not realize the declared demand table")

    def digest(self) -> str:
        body = [self.scope, self.asset, self.epoch, self.lifetime, self.worlds,
                str(self.capacity), self.evidence_contract,
                [[a.name, a.observations,
                  [[p.name, list(map(str, p.demands)),
                    [[r.name, sorted(r.worlds), str(r.amount), r.request.hex()]
                     for r in p.occurrences]] for p in a.policies]] for a in self.actors]]
        return sha256(json.dumps(body, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class Evidence:
    name: str
    profile: str
    actor: str
    worlds: frozenset[str]

    def __post_init__(self) -> None:
        object.__setattr__(self, "worlds", frozenset(self.worlds))
        if not all((self.name, self.profile, self.actor)):
            raise ValueError("evidence must bind its identifier, profile, and actor")


@dataclass(frozen=True)
class AllowanceReceipt:
    owner: tuple[str, str]
    profile: str
    evidence: str
    observation: str
    amount: Fraction
    version: int


@dataclass(frozen=True)
class Outbox:
    owner: tuple[str, str]
    profile: str
    policy: str
    occurrence: str
    command: str
    request: bytes
    amount: Fraction
    worlds: frozenset[str]
    evidence: str


@dataclass
class Grant:
    profile: Profile
    actor: Actor
    receipt: AllowanceReceipt
    worlds: frozenset[str]
    free: Fraction
    pending: Fraction = Fraction(0)
    recognized: Fraction = Fraction(0)
    discharged: Fraction = Fraction(0)
    selected: str | None = None
    blocked: bool = False
    issued: dict[str, str] = field(default_factory=dict)


class AllowanceMachine:
    """Serialized finite reference transitions, with no external side effects."""

    def __init__(self, scope: str, asset: str, epoch: int, capacity: Number,
                 admitted_evidence: Sequence[Evidence]) -> None:
        self.scope, self.asset, self.epoch = scope, asset, epoch
        self.capacity = quantity(capacity)
        self.evidence = {e.name: e for e in admitted_evidence}
        if len(self.evidence) != len(admitted_evidence):
            raise ValueError("admitted evidence identifiers must be unique")
        self.grants: dict[tuple[str, str], Grant] = {}
        self.outbox: dict[str, Outbox] = {}
        self.spent: dict[tuple[str, str], str] = {}
        self.version = 0

    @property
    def reserved(self) -> Fraction:
        return sum((g.free + g.pending + g.recognized for g in self.grants.values()), Fraction(0))

    def _evidence(self, name: str, profile: Profile, actor: Actor) -> Evidence:
        evidence = self.evidence.get(name)
        if evidence is None:
            raise ValueError("evidence has no admitted fixture")
        if evidence.profile != profile.digest() or evidence.actor != actor.name:
            raise ValueError("evidence has the wrong profile or actor binding")
        if not evidence.worlds or not evidence.worlds <= set(profile.worlds):
            raise ValueError("evidence support must be nonempty and inside the profile")
        return evidence

    def issue(self, profile: Profile, actor_name: str, evidence_name: str) -> AllowanceReceipt:
        if (profile.scope, profile.asset, profile.epoch, profile.capacity) != (
                self.scope, self.asset, self.epoch, self.capacity):
            raise ValueError("profile has the wrong scope, asset, capacity, or epoch")
        actor = next((a for a in profile.actors if a.name == actor_name), None)
        if actor is None:
            raise ValueError("actor is outside the profile")
        evidence = self._evidence(evidence_name, profile, actor)
        observations = {actor.observations[profile.worlds.index(w)] for w in evidence.worlds}
        if len(observations) != 1:
            raise ValueError("issuance evidence is not one observation fiber")
        observation = next(iter(observations))
        fibre = frozenset(w for w, z in zip(profile.worlds, actor.observations) if z == observation)
        if evidence.worlds != fibre:
            raise ValueError("issuance evidence omits an indistinguishable world")
        owner = (profile.lifetime, actor.name)
        if owner in self.grants:
            receipt = self.grants[owner].receipt
            if (receipt.profile, receipt.evidence) != (profile.digest(), evidence_name):
                raise ValueError("owner lifetime already has a different allowance")
            return receipt
        amount = max(p.demands[profile.worlds.index(w)] for p in actor.policies for w in fibre)
        if self.reserved + amount > self.capacity:
            raise ValueError("aggregate reservation exceeds capacity")
        receipt = AllowanceReceipt(owner, profile.digest(), evidence_name, observation, amount,
                                   self.version + 1)
        self.grants[owner] = Grant(profile, actor, receipt, fibre, amount)
        self.version += 1
        return receipt

    def select(self, owner: tuple[str, str], policy: str) -> None:
        grant = self.grants[owner]
        if policy not in {p.name for p in grant.actor.policies}:
            raise ValueError("policy is outside the admitted family")
        if grant.selected is not None and grant.selected != policy:
            raise ValueError("selected policy cannot change within the lifetime")
        grant.selected = policy

    def prepare(self, owner: tuple[str, str], occurrence_name: str, command: str,
                request: bytes, evidence_name: str) -> Outbox:
        if not isinstance(command, str) or not command:
            raise ValueError("command identifier must be nonempty")
        grant = self.grants[owner]
        if command in self.outbox:
            old = self.outbox[command]
            if (old.owner, old.occurrence, old.request) != (owner, occurrence_name, request):
                raise ValueError("command key has conflicting request bytes or identity")
            return old
        if grant.blocked:
            raise ValueError("conflicting evidence blocks fresh issuance")
        policy = next((p for p in grant.actor.policies if p.name == grant.selected), None)
        if policy is None:
            raise ValueError("one supported policy must be selected")
        occurrence = next((r for r in policy.occurrences if r.name == occurrence_name), None)
        if occurrence is None or occurrence.request != request:
            raise ValueError("request is outside the selected policy support")
        evidence = self._evidence(evidence_name, grant.profile, grant.actor)
        worlds = grant.worlds & evidence.worlds
        if not worlds:
            grant.blocked = True
            raise ValueError("conflicting evidence has an empty world intersection")
        if not worlds <= occurrence.worlds:
            raise ValueError("condition evidence does not authorize this occurrence")
        occurrence_key = (grant.profile.lifetime, occurrence.name)
        if occurrence_key in self.spent:
            raise ValueError("occurrence was already issued in this lifetime")
        if occurrence.amount > grant.free:
            raise ValueError("request exceeds remaining lifetime allowance")
        record = Outbox(owner, grant.profile.digest(), policy.name, occurrence.name, command,
                        request, occurrence.amount, worlds, evidence_name)
        # These mutations are one transition of this serialized reference model.
        grant.worlds = worlds
        grant.free -= occurrence.amount
        grant.pending += occurrence.amount
        grant.issued[occurrence.name] = command
        self.spent[occurrence_key] = command
        self.outbox[command] = record
        self.version += 1
        return record

    def reclassify(self, owner: tuple[str, str], amount: Number) -> None:
        """Apply an admitted aggregate outcome to the reference accounting."""
        grant = self.grants[owner]
        amount = quantity(amount)
        if amount > grant.pending:
            raise ValueError("reclassification exceeds pending exposure")
        grant.pending -= amount
        grant.recognized += amount

    def discharge(self, owner: tuple[str, str], amount: Number) -> None:
        """Apply admitted discharge to recognized exposure, retaining issuance."""
        grant = self.grants[owner]
        amount = quantity(amount)
        if amount > grant.recognized:
            raise ValueError("discharge exceeds recognized exposure")
        grant.recognized -= amount
        grant.discharged += amount

    def check_invariants(self) -> None:
        if self.reserved > self.capacity:
            raise AssertionError("global reservation cap")
        for owner, grant in self.grants.items():
            components = (grant.free, grant.pending, grant.recognized, grant.discharged)
            if min(components) < 0 or sum(components) != grant.receipt.amount:
                raise AssertionError("allowance conservation")
            children = [record for record in self.outbox.values() if record.owner == owner]
            if sum((r.amount for r in children), Fraction(0)) != sum(components[1:]):
                raise AssertionError("issued quantities and retained exposure disagree")
            if len(children) != len(grant.issued):
                raise AssertionError("occurrence issuance is not unique")
            if children:
                policy = next(p for p in grant.actor.policies if p.name == grant.selected)
                issued = sum((r.amount for r in children), Fraction(0))
                for world in grant.worlds:
                    if issued > policy.demands[grant.profile.worlds.index(world)]:
                        raise AssertionError("issued quantity exceeds supported policy demand")


def complementary_profile(*, separate: bool = False, capacity: Number = 100) -> Profile:
    first = Occurrence("duty-0", frozenset({"0"}), Fraction(100), b"pay recipient-0 100 units")
    second = Occurrence("duty-1", frozenset({"1"}), Fraction(100), b"pay recipient-1 100 units")
    if separate:
        actors = (Actor("actor-0", ("blind", "blind"),
                        (Policy("first", vector((100, 0)), (first,)),)),
                  Actor("actor-1", ("blind", "blind"),
                        (Policy("second", vector((0, 100)), (second,)),)))
    else:
        actors = (Actor("owner", ("blind", "blind"),
                        (Policy("conditional-pair", vector((100, 100)), (first, second)),)),)
    return Profile("shared-risk", "unit", 1, "conditional-duty-lifetime", ("0", "1"),
                   quantity(capacity), actors)


def evidence_fixtures(profile: Profile) -> tuple[Evidence, ...]:
    return tuple(Evidence(f"{actor.name}:{label}", profile.digest(), actor.name, frozenset(worlds))
                 for actor in profile.actors
                 for label, worlds in (("blind", profile.worlds), ("0", ("0",)), ("1", ("1",))))


def self_test() -> dict:
    """Check positive and adverse calculations without optimization-sensitive asserts."""
    checks = 0

    def require(condition: bool, label: str) -> None:
        nonlocal checks
        if not condition:
            raise AssertionError(label)
        checks += 1

    def reject(call, expected: str) -> None:
        try:
            call()
        except ValueError as error:
            require(expected in str(error), "wrong rejection reason")
        else:
            raise AssertionError("an adverse case was admitted")

    families = (((100, 0),), ((0, 100),))
    local = tuple(observable_envelope(policy_envelope(family), ("blind", "blind"))
                  for family in families)
    joint = joint_envelope(families)
    require(joint == (100, 100), "complementary joint demand")
    require(local == ((100, 100), (100, 100)), "least blind allowances")
    require(sum(row[0] for row in local) == 200, "independent unconditional total")
    coupled = joint_envelope((((0,), (100,)), ((0,), (100,))), (((0, 1), (1, 0)),))
    require(coupled == (100,), "coupled support maximum")
    require(joint_envelope((((0,), (100,)), ((0,), (100,)))) == (200,),
            "independent product contains the adverse tuple")
    require(check_resource_menu_certificate((4, 4), (1, 1)) == 9,
            "two-resource optimal menu certificate")
    require(check_resource_menu_certificate((2,), ("1/2",)) == 3,
            "real slack must be floored for integral requests")
    profile = complementary_profile()
    traces = {}
    for world in profile.worlds:
        machine = AllowanceMachine(profile.scope, profile.asset, profile.epoch, profile.capacity,
                                   evidence_fixtures(profile))
        receipt = machine.issue(profile, "owner", "owner:blind")
        machine.select(receipt.owner, "conditional-pair")
        occurrence = profile.actors[0].policies[0].occurrences[int(world)]
        reject(lambda: machine.prepare(receipt.owner, occurrence.name, "blind-request",
                                       occurrence.request, "owner:blind"), "condition evidence")
        record = machine.prepare(receipt.owner, occurrence.name, f"command-{world}",
                                 occurrence.request, f"owner:{world}")
        require(record.amount == 100 and machine.reserved == 100, "positive conditional issuance")
        require(machine.prepare(receipt.owner, occurrence.name, f"command-{world}",
                                occurrence.request, f"owner:{world}") == record, "identical retry")
        machine.reclassify(receipt.owner, 60)
        machine.check_invariants()
        grant = machine.grants[receipt.owner]
        require((grant.free, grant.pending, grant.recognized, grant.discharged) == (0, 40, 60, 0),
                "partial outcome preserves 100")
        machine.reclassify(receipt.owner, 40)
        machine.discharge(receipt.owner, 100)
        machine.check_invariants()
        require(grant.free == 0 and grant.discharged == 100 and len(machine.outbox) == 1,
                "discharge retains consumed lifetime allowance")
        reject(lambda: machine.prepare(receipt.owner, occurrence.name, "fresh-key",
                                       occurrence.request, f"owner:{world}"), "already issued")
        traces[world] = {"issued": record.occurrence, "amount": str(record.amount),
                         "retained_discharged": str(grant.discharged)}
    return {"checks": checks, "joint_allowance": str(max(joint)),
            "separate_allowances": [str(row[0]) for row in local], "separate_total": "200",
            "resource_menu_counts": {"B=(4,4),slack=(1,1)": 9, "B=2,slack=1/2": 3},
            "conditional_owner_traces": traces, "status": "passed"}


if __name__ == "__main__":
    print(json.dumps(self_test(), sort_keys=True, indent=2))
