"""Behavioral regressions for the admitted finite SJN corridor model.

Run from this directory with ``python3 -m unittest -v test_sjn_corridor_checker``.
These tests use externally supplied assessments as fixtures, not cryptographic
or institutional verification. unittest assertions remain active under -O.
"""

from dataclasses import FrozenInstanceError, replace
import hashlib
from pathlib import Path
import subprocess
import sys
import unittest

from sjn_corridor_checker import (
    AuthorityUse, CarryMap, CorridorPolicy, CurrentAnswer, DependencyAssessment,
    DutyEvidence, EffectRecord, EffectSpec, EvaluationInput, EvidenceRequirement,
    Grade, HistoryAssessment, HistoryStatus, Interval, Marker, ObligationBody,
    RequestContext, RetainedBytes, SourceCell, TraversalLog, VenueAssessment,
    VenueScope, Verdict, canonical_bytes, digest, duty_states, evaluate,
    same_sovereign_structure, venue_order_status,
)


IDENTITY = tuple((g, g) for g in Grade)
DISCOUNT = ((Grade.NONCOMPLIANT, Grade.NONCOMPLIANT),
            (Grade.PENDING, Grade.PENDING), (Grade.COMPLIANT, Grade.PENDING))


def source(cell_id="north-identity", grade=Grade.COMPLIANT, marker=None, **changes):
    payload = ("signed source bytes for " + cell_id).encode()
    cell = SourceCell(cell_id, "north-registry", "north", "identity", "company-1",
                      "branch", "source-act-17", "identity-v2", "north-statute",
                      "identity-scope", Interval(0, 20), "registered company",
                      grade, marker, ("authority-root", "source-root"),
                      hashlib.sha256(payload).hexdigest(), len(payload))
    return replace(cell, **changes), payload


def fixture():
    request = RequestContext("licence-request-7", "company-1", "branch",
                             (("licensing", "v1"), ("identity", "v2")))
    effect = EffectSpec("licence-effect-7", "licence-issued", request,
                        "licence-instrument", "south-registry")
    fresh = ObligationBody("fresh-identity", "fresh", "identity", "answer licensing question",
                           "south-registry", "company-1", "south", effect, request,
                           "licensing-rule", 10, "local", ("licensing-office",),
                           "local-answer-admission", "licensing-answer")
    report = ObligationBody("report-7", "continuing", "reporting", "file issuance report",
                            "reporting-office", "public-register", "south", effect, request,
                            "reporting-rule", 9, "post-effect", ("reporting-office",),
                            "admit-report-trigger", "report-received")
    policy = CorridorPolicy(
        "corridor-v1", "north", "south", request,
        (CarryMap("identity", "identity", "identity-scope", IDENTITY),),
        ("identity",), ("identity", "tax"),
        (("identity", "south-registry"), ("tax", "tax-office")),
        (("identity", "licensing-rule"), ("tax", "tax-rule")),
        ("source-permitted",), ("fee-paid",),
        (EvidenceRequirement("identity-proof", "act", "identity", Grade.COMPLIANT),),
        (AuthorityUse("corridor-authority", "corridor-instrument", "import", Interval(0, 10)),
         AuthorityUse("south-registry", "licence-instrument", "act", Interval(0, 10))),
        Interval(0, 10), (("authority-head", "a1"), ("sanctions-head", "s1")),
        "complete-authority-and-sanctions-v1", (effect,), (fresh, report),
        VenueScope("venue-1", "book-1", "protocol-1", "epoch-1", ("v1", "v2")),
    )
    cell, payload = source()
    dependencies = DependencyAssessment(policy.sovereign_digest(), request, 5, 5,
                                         ("authority-head", "sanctions-head"),
                                         policy.currentness_rule, policy.current_dependencies,
                                         Verdict.PASS)
    answers = (
        CurrentAnswer("source-permitted", "corridor-authority", request, "import", 5, 5, Verdict.PASS,
                      policy.sovereign_digest(), "corridor-instrument", digest((cell,))),
        CurrentAnswer("fee-paid", "south-registry", request, "act", 5, 5, Verdict.PASS,
                      policy.sovereign_digest(), "licence-instrument", digest((cell,))),
        CurrentAnswer("identity", "south-registry", request, "local", 5, 5, Verdict.PASS,
                      policy.sovereign_digest(), "licensing-rule", digest((cell,))),
        CurrentAnswer("tax", "tax-office", request, "local", 5, 5, Verdict.PASS,
                      policy.sovereign_digest(), "tax-rule", digest((cell,))),
        CurrentAnswer("act-authority", "south-registry", request, "operational", 5, 5, Verdict.PASS,
                      policy.sovereign_digest(), "licence-instrument", digest((cell,))),
    )
    inputs = EvaluationInput(request, 5, 5, (cell,), (RetainedBytes(cell.cell_id, payload),),
                             (HistoryAssessment(cell, payload, 5, HistoryStatus.VERIFIED),),
                             dependencies, answers)
    return policy, inputs


def assess(policy, inputs, *, renew_answers=True):
    """Fixture issuer supplies a new explicitly bound assessment after amendment."""
    updated = replace(inputs, dependencies=replace(inputs.dependencies,
                   policy_digest=policy.sovereign_digest(), request=inputs.request,
                   use_time=inputs.use_time, cutoff=inputs.cutoff,
                   scope=tuple(name for name, _ in policy.current_dependencies),
                   currentness_rule=policy.currentness_rule))
    if renew_answers:
        updated = replace(updated, answers=tuple(replace(a, policy_digest=policy.sovereign_digest())
                                                for a in updated.answers))
    return updated


def answer(inputs, name, verdict=None, **changes):
    return replace(inputs, answers=tuple(
        replace(a, **dict(changes, **({"verdict": verdict} if verdict is not None else {})))
        if a.name == name else a for a in inputs.answers))


def without_answer(inputs, name):
    return replace(inputs, answers=tuple(a for a in inputs.answers if a.name != name))


def with_sources(inputs, *pairs):
    updated = replace(inputs, cells=tuple(c for c, _ in pairs),
                   retained=tuple(RetainedBytes(c.cell_id, data) for c, data in pairs),
                   histories=tuple(HistoryAssessment(c, data, inputs.cutoff, HistoryStatus.VERIFIED)
                                   for c, data in pairs))
    return replace(updated, answers=tuple(replace(a, evidence_digest=digest(updated.cells))
                                          for a in updated.answers))


def duty_evidence(policy, kind, *, at=5, admission=Verdict.PASS, verdict=Verdict.PASS):
    body = next(o for o in policy.obligations if o.role == "continuing")
    return DutyEvidence(kind + "-7", kind, body.obligation_id, digest(body), body.trigger.effect_id,
                        body.request, body.instrument, body.owner,
                        body.activation_rule if kind == "activation" else body.completion_rule,
                        at, admission, verdict)


class CorridorTests(unittest.TestCase):
    def setUp(self):
        self.policy, self.inputs = fixture()

    def test_positive_admissible_use_retains_original_record(self):
        receipt = TraversalLog().deliver("traversal-1", self.policy, self.inputs)
        result = receipt.result
        self.assertEqual(result.import_decision.verdict, Verdict.PASS)
        self.assertEqual(result.act_decision.verdict, Verdict.PASS)
        self.assertEqual(result.admitted_cell_ids, ("north-identity",))
        self.assertEqual(receipt.source_cells, self.inputs.cells)
        self.assertEqual(receipt.ordered_policies, (self.policy,))
        self.assertEqual(receipt.obligations, self.policy.obligations)
        self.assertEqual(result.effect_plan, self.policy.effect_plan)
        self.assertIsNone(result.duties[0].incurred_at)
        self.assertEqual(result.duties[0].activation, "Conditional")

    def test_public_result_and_receipt_retain_complete_assessment_input(self):
        result = evaluate(self.policy, self.inputs)
        receipt = TraversalLog().deliver("retained-witness", self.policy, self.inputs)
        for retained in (result.retained_input, receipt.result.retained_input):
            self.assertEqual(retained, self.inputs)
            self.assertEqual(retained.request, self.inputs.request)
            self.assertEqual((retained.use_time, retained.cutoff), (5, 5))
            self.assertEqual(retained.retained, self.inputs.retained)
            self.assertEqual(retained.histories, self.inputs.histories)
            self.assertEqual(retained.dependencies, self.inputs.dependencies)
            self.assertEqual(retained.answers, self.inputs.answers)
            with self.assertRaises(FrozenInstanceError):
                retained.cutoff = 6
        payload_encoding = self.inputs.retained[0].payload.hex().encode("ascii")
        self.assertIn(payload_encoding, canonical_bytes(result))
        self.assertIn(payload_encoding, canonical_bytes(receipt))

    def test_fully_rebound_time_and_cutoff_produce_distinct_public_witnesses(self):
        initial = evaluate(self.policy, self.inputs)
        receipt = TraversalLog().deliver("same-traversal", self.policy, self.inputs)
        for time, cutoff in ((6, 5), (5, 6), (6, 6)):
            with self.subTest(time=time, cutoff=cutoff):
                rebound = replace(self.inputs, use_time=time, cutoff=cutoff,
                    histories=tuple(replace(h, cutoff=cutoff) for h in self.inputs.histories),
                    dependencies=replace(self.inputs.dependencies, use_time=time, cutoff=cutoff),
                    answers=tuple(replace(a, use_time=time, cutoff=cutoff) for a in self.inputs.answers))
                result = evaluate(self.policy, rebound)
                later_receipt = TraversalLog().deliver("same-traversal", self.policy, rebound)
                self.assertEqual(result.import_decision.verdict, Verdict.PASS)
                self.assertEqual(result.act_decision.verdict, Verdict.PASS)
                self.assertEqual(initial.import_decision, result.import_decision)
                self.assertEqual(initial.treatments, result.treatments)
                self.assertNotEqual(initial, result)
                self.assertNotEqual(receipt, later_receipt)
                self.assertNotEqual(canonical_bytes(receipt), canonical_bytes(later_receipt))
                self.assertEqual(result.retained_input, rebound)

    def test_declared_grade_map_changes_treatment_and_named_threshold(self):
        discounted = replace(self.policy, carry=(replace(self.policy.carry[0], mapping=DISCOUNT),))
        before = evaluate(self.policy, self.inputs)
        after = evaluate(discounted, assess(discounted, self.inputs))
        self.assertEqual(before.act_decision.verdict, Verdict.PASS)
        self.assertEqual(after.treatments[0].grade, Grade.PENDING)
        self.assertEqual(after.import_decision.verdict, Verdict.PASS)
        self.assertEqual(after.act_decision.verdict, Verdict.REFUSED)
        self.assertIn("act:identity-proof:grade:Pending", after.act_decision.reasons)
        self.assertEqual(self.inputs.cells[0].grade, Grade.COMPLIANT)

    def test_all_sources_and_applicability_markers_survive_one_target(self):
        inputs = with_sources(self.inputs,
            source("c1", Grade.COMPLIANT), source("c2", Grade.NONCOMPLIANT, authority="other-authority"),
            source("c3", None, Marker.NOT_APPLICABLE), source("c4", None, Marker.EXEMPT))
        receipt = TraversalLog().deliver("multi", self.policy, inputs)
        self.assertEqual(len(receipt.source_cells), 4)
        self.assertEqual(len(receipt.result.treatments), 4)
        self.assertEqual(receipt.result.admitted_cell_ids, ("c1", "c2", "c3", "c4"))
        summary = receipt.result.summaries[0]
        self.assertEqual(summary.grade, Grade.NONCOMPLIANT)
        self.assertEqual(set(summary.markers), {Marker.NOT_APPLICABLE, Marker.EXEMPT})
        self.assertEqual(receipt.result.act_decision.verdict, Verdict.REFUSED)
        reversed_inputs = replace(inputs, cells=inputs.cells[::-1], retained=inputs.retained[::-1],
                                  histories=inputs.histories[::-1])
        self.assertEqual(evaluate(self.policy, inputs), evaluate(self.policy, reversed_inputs))

    def test_marker_only_summary_does_not_create_compliant_observation(self):
        inputs = with_sources(self.inputs, source("exempt", None, Marker.EXEMPT))
        result = evaluate(self.policy, inputs)
        self.assertEqual(result.import_decision.verdict, Verdict.PASS)
        self.assertIsNone(result.summaries[0].grade)
        self.assertEqual(result.summaries[0].markers, (Marker.EXEMPT,))
        self.assertEqual(result.act_decision.verdict, Verdict.PENDING)

    def test_carry_is_permission_not_a_requirement_for_every_domain(self):
        optional = CarryMap("optional", "optional", "optional-scope", IDENTITY)
        policy = replace(self.policy, carry=self.policy.carry + (optional,))
        result = evaluate(policy, assess(policy, self.inputs))
        self.assertEqual(result.import_decision.verdict, Verdict.PASS)
        self.assertEqual(result.act_decision.verdict, Verdict.PASS)

    def test_named_import_evidence_requirement_can_require_absent_domain(self):
        required = EvidenceRequirement("tax-file", "import", "tax", Grade.COMPLIANT)
        policy = replace(self.policy, evidence_requirements=self.policy.evidence_requirements + (required,))
        result = evaluate(policy, assess(policy, self.inputs))
        self.assertEqual(result.import_decision.verdict, Verdict.PENDING)
        self.assertIn("import:tax-file:missing-applicable-evidence", result.import_decision.reasons)
        self.assertEqual(result.admitted_cell_ids, ())

    def test_uncarried_cell_is_preserved_but_is_not_imported(self):
        extra, data = source("unselected", domain="outside-carry")
        inputs = with_sources(self.inputs, (self.inputs.cells[0], self.inputs.retained[0].payload), (extra, data))
        inputs = replace(inputs, retained=tuple(r for r in inputs.retained if r.cell_id != extra.cell_id))
        receipt = TraversalLog().deliver("excluded", self.policy, inputs)
        self.assertEqual(len(receipt.source_cells), 2)
        self.assertEqual(receipt.result.import_decision.verdict, Verdict.PASS)
        self.assertEqual(receipt.result.admitted_cell_ids, ("north-identity",))

    def test_fresh_pending_can_receive_evidence_before_destination_answer(self):
        pending = answer(self.inputs, "identity", Verdict.PENDING)
        initial = evaluate(self.policy, pending)
        resolved = evaluate(self.policy, answer(pending, "identity", Verdict.PASS))
        self.assertEqual(initial.import_decision.verdict, Verdict.PASS)
        self.assertEqual(dict(initial.fresh_decisions)["identity"].verdict, Verdict.PENDING)
        self.assertEqual(initial.act_decision.verdict, Verdict.PENDING)
        self.assertEqual(resolved.act_decision.verdict, Verdict.PASS)
        self.assertEqual(initial.treatments, resolved.treatments)
        self.assertEqual(initial.duties, resolved.duties)

    def test_current_local_refusal_dominates_compliant_import(self):
        result = evaluate(self.policy, answer(self.inputs, "identity", Verdict.REFUSED))
        self.assertEqual(result.import_decision.verdict, Verdict.PASS)
        self.assertEqual(result.act_decision.verdict, Verdict.REFUSED)
        self.assertEqual(result.effect_plan, ())

    def test_act_checks_A_domains_outside_fresh_set(self):
        self.assertNotIn("tax", self.policy.fresh)
        for verdict in (Verdict.PENDING, Verdict.REFUSED):
            with self.subTest(verdict=verdict):
                result = evaluate(self.policy, answer(self.inputs, "tax", verdict))
                self.assertEqual(result.import_decision.verdict, Verdict.PASS)
                self.assertEqual(result.act_decision.verdict, verdict)
        result = evaluate(self.policy, without_answer(self.inputs, "tax"))
        self.assertEqual(result.act_decision.verdict, Verdict.PENDING)

    def test_fresh_is_not_substituted_for_actual_act_domain_set(self):
        policy = replace(self.policy, act_domains=("tax",))
        result = evaluate(policy, assess(policy, answer(self.inputs, "identity", Verdict.PENDING)))
        self.assertEqual(dict(result.fresh_decisions)["identity"].verdict, Verdict.PENDING)
        self.assertEqual(result.act_decision.verdict, Verdict.PASS)

    def test_missing_import_prerequisite_does_not_default_to_permission(self):
        result = evaluate(self.policy, without_answer(self.inputs, "source-permitted"))
        self.assertEqual(result.import_decision.verdict, Verdict.PENDING)
        self.assertIn("import:source-permitted:missing-answer", result.import_decision.reasons)

    def test_resolved_false_import_prerequisite_refuses(self):
        result = evaluate(self.policy, answer(self.inputs, "source-permitted", Verdict.REFUSED))
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        self.assertEqual(result.admitted_cell_ids, ())

    def test_act_prerequisite_and_operational_authority_do_not_block_import(self):
        for name in ("fee-paid", "act-authority"):
            with self.subTest(name=name):
                result = evaluate(self.policy, without_answer(self.inputs, name))
                self.assertEqual(result.import_decision.verdict, Verdict.PASS)
                self.assertEqual(result.act_decision.verdict, Verdict.PENDING)
        result = evaluate(self.policy, answer(self.inputs, "act-authority", Verdict.REFUSED))
        self.assertEqual(result.act_decision.verdict, Verdict.REFUSED)

    def test_available_bytes_without_external_history_remain_unresolved(self):
        result = evaluate(self.policy, replace(self.inputs, histories=()))
        self.assertEqual(result.treatments[0].bytes_status, "Available")
        self.assertEqual(result.treatments[0].history_status, HistoryStatus.UNRESOLVED)
        self.assertEqual(result.import_decision.verdict, Verdict.PENDING)

    def test_history_assessment_binds_exact_bytes_cell_and_cutoff(self):
        original = self.inputs.histories[0]
        changed = (
            replace(original, source_bytes=b"different signed payload"),
            replace(original, cell=replace(original.cell, source_act="another-act")),
            replace(original, cutoff=4),
        )
        for historical in changed:
            with self.subTest(history=historical):
                result = evaluate(self.policy, replace(self.inputs, histories=(historical,)))
                self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
                self.assertEqual(result.treatments[0].history_status, HistoryStatus.UNRESOLVED)

    def test_external_refuted_history_is_not_overridden_by_available_bytes(self):
        inputs = replace(self.inputs, histories=(replace(self.inputs.histories[0], status=HistoryStatus.REFUTED),))
        result = evaluate(self.policy, inputs)
        self.assertEqual(result.treatments[0].history_status, HistoryStatus.REFUTED)
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)

    def test_missing_and_corrupt_bytes_do_not_verify_history(self):
        for payload, byte_status, verdict in ((None, "Missing", Verdict.PENDING),
                                               (b"wrong", "Corrupt", Verdict.REFUSED)):
            with self.subTest(status=byte_status):
                inputs = replace(self.inputs, retained=(RetainedBytes("north-identity", payload),))
                result = evaluate(self.policy, inputs)
                self.assertEqual(result.treatments[0].bytes_status, byte_status)
                self.assertEqual(result.treatments[0].history_status, HistoryStatus.UNRESOLVED)
                self.assertEqual(result.import_decision.verdict, verdict)

    def test_source_length_mismatch_refuses_even_with_same_bytes_and_digest(self):
        original = self.inputs.cells[0]
        wrong_length = replace(original, evidence_length=original.evidence_length + 1)
        inputs = with_sources(self.inputs, (wrong_length, self.inputs.retained[0].payload))
        self.assertEqual(wrong_length.evidence_sha256, original.evidence_sha256)
        self.assertEqual(inputs.retained, self.inputs.retained)
        result = evaluate(self.policy, inputs)
        self.assertEqual(result.treatments[0].bytes_status, "Corrupt")
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        self.assertIn("cell:north-identity:corrupt-bytes", result.import_decision.reasons)
        self.assertFalse(any("binding-mismatch" in reason for reason in result.import_decision.reasons))

    def test_policy_expiry_preserves_authenticated_history(self):
        policy = replace(self.policy, interval=Interval(0, 4))
        result = evaluate(policy, assess(policy, self.inputs))
        self.assertEqual(result.treatments[0].history_status, HistoryStatus.VERIFIED)
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        self.assertIn("policy:expired-use-interval", result.import_decision.reasons)

    def test_source_expiry_preserves_authenticated_history(self):
        cell, payload = source(interval=Interval(0, 4))
        result = evaluate(self.policy, with_sources(self.inputs, (cell, payload)))
        self.assertEqual(result.treatments[0].history_status, HistoryStatus.VERIFIED)
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        self.assertIn("cell:north-identity:expired-source-interval", result.import_decision.reasons)

    def test_authority_use_expiry_is_stage_specific(self):
        for stage in ("import", "act"):
            with self.subTest(stage=stage):
                policy = replace(self.policy, authority_uses=tuple(
                    replace(a, interval=Interval(0, 4)) if a.stage == stage else a
                    for a in self.policy.authority_uses))
                result = evaluate(policy, assess(policy, self.inputs))
                self.assertEqual(result.act_decision.verdict, Verdict.REFUSED)
                self.assertEqual(result.import_decision.verdict,
                                 Verdict.REFUSED if stage == "import" else Verdict.PASS)
                self.assertEqual(result.treatments[0].history_status, HistoryStatus.VERIFIED)

    def test_exact_request_binding_includes_act_and_rule_versions(self):
        for request in (replace(self.inputs.request, act="other-request"),
                        replace(self.inputs.request, rules=(("identity", "v3"), ("licensing", "v1")))):
            with self.subTest(request=request):
                result = evaluate(self.policy, replace(self.inputs, request=request))
                self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
                self.assertIn("request:policy-context-mismatch", result.import_decision.reasons)

    def test_original_source_scope_and_purpose_are_enforced(self):
        for change in ({"scope": "different-scope"}, {"purpose": "unrelated-purpose"}):
            with self.subTest(change=change):
                result = evaluate(self.policy, with_sources(self.inputs, source(**change)))
                self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)

    def test_source_jurisdiction_mismatch_refuses_freshly_bound_records(self):
        inputs = with_sources(self.inputs, source(jurisdiction="outside-source-jurisdiction"))
        result = evaluate(self.policy, inputs)
        self.assertEqual(result.treatments[0].bytes_status, "Available")
        self.assertEqual(result.treatments[0].history_status, HistoryStatus.VERIFIED)
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        self.assertIn("cell:north-identity:context-mismatch", result.import_decision.reasons)
        self.assertFalse(any("binding-mismatch" in reason for reason in result.import_decision.reasons))

    def test_local_answer_cannot_be_reused_for_other_request_or_authority(self):
        for changes in ({"request": replace(self.inputs.request, act="other")},
                        {"authority": "foreign-registry"}, {"use_time": 4}, {"cutoff": 4}):
            with self.subTest(changes=changes):
                result = evaluate(self.policy, answer(self.inputs, "identity", **changes))
                self.assertEqual(result.import_decision.verdict, Verdict.PASS)
                self.assertEqual(result.act_decision.verdict, Verdict.REFUSED)

    def test_current_answer_cannot_replay_under_new_policy_instrument_or_evidence(self):
        amended = replace(self.policy, policy_id="corridor-v2")
        result = evaluate(amended, assess(amended, self.inputs, renew_answers=False))
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        self.assertIn("import:source-permitted:binding-mismatch", result.import_decision.reasons)
        for changes in ({"instrument": "other-instrument"}, {"evidence_digest": "other-evidence"},
                        {"policy_digest": "other-policy"}):
            with self.subTest(changes=changes):
                result = evaluate(self.policy, answer(self.inputs, "identity", **changes))
                self.assertEqual(result.import_decision.verdict, Verdict.PASS)
                self.assertEqual(result.act_decision.verdict, Verdict.REFUSED)

    def test_missing_or_incomplete_currentness_assessment_is_pending(self):
        for dependencies in (None, replace(self.inputs.dependencies, completeness=Verdict.PENDING)):
            with self.subTest(dependencies=dependencies):
                result = evaluate(self.policy, replace(self.inputs, dependencies=dependencies))
                self.assertEqual(result.import_decision.verdict, Verdict.PENDING)

    def test_all_currentness_reasons_aggregate_refusal_before_pending(self):
        dependencies = replace(self.inputs.dependencies, observed=(("authority-head", "changed"),),
                               completeness=Verdict.PENDING)
        inputs = replace(without_answer(self.inputs, "source-permitted"), dependencies=dependencies)
        result = evaluate(self.policy, inputs)
        self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
        for reason in ("dependency:authority-head:changed", "dependency:sanctions-head:missing",
                       "dependencies:completeness:Pending", "import:source-permitted:missing-answer"):
            self.assertIn(reason, result.import_decision.reasons)
        self.assertEqual(result.import_decision.reasons, tuple(sorted(result.import_decision.reasons)))
        reversed_policy = replace(self.policy, current_dependencies=self.policy.current_dependencies[::-1])
        self.assertEqual(evaluate(reversed_policy, inputs), result)

    def test_completeness_is_bound_to_scope_rule_cutoff_policy_and_context(self):
        for changes in ({"scope": ("authority-head",)}, {"currentness_rule": "other-rule"},
                        {"cutoff": 4}, {"policy_digest": "other-policy"},
                        {"request": replace(self.inputs.request, act="other")}):
            with self.subTest(changes=changes):
                dependencies = replace(self.inputs.dependencies, **changes)
                result = evaluate(self.policy, replace(self.inputs, dependencies=dependencies))
                self.assertEqual(result.import_decision.verdict, Verdict.REFUSED)
                self.assertIn("dependencies:binding-mismatch", result.import_decision.reasons)

    def test_conditional_duty_requires_an_admitted_effect_not_permission(self):
        for effects in ((), (EffectRecord(self.policy.effect_plan[0], 4, Verdict.PENDING),),
                        (EffectRecord(self.policy.effect_plan[0], 6, Verdict.PASS),)):
            with self.subTest(effects=effects):
                result = evaluate(self.policy, replace(self.inputs, effects=effects))
                self.assertEqual(result.act_decision.verdict, Verdict.PASS)
                self.assertIsNone(result.duties[0].incurred_at)
                self.assertEqual(result.duties[0].activation, "Conditional")

    def test_real_effect_incurs_duty_while_activation_is_awaiting(self):
        effect = EffectRecord(self.policy.effect_plan[0], 4, Verdict.PASS)
        inputs = replace(answer(self.inputs, "identity", Verdict.PENDING), effects=(effect,))
        result = evaluate(self.policy, inputs)
        self.assertEqual(result.act_decision.verdict, Verdict.PENDING)
        state = result.duties[0]
        self.assertEqual(state.incurred_at, 4)
        self.assertEqual(state.activation, "Awaiting")
        self.assertEqual(state.completion, "Outstanding")
        self.assertEqual(state.body.owner, "reporting-office")
        self.assertEqual(state.body.trigger.authority, "south-registry")
        self.assertEqual(state.body.beneficiary, "public-register")

    def test_activation_does_not_complete_duty(self):
        effect = EffectRecord(self.policy.effect_plan[0], 4, Verdict.PASS)
        activation = duty_evidence(self.policy, "activation")
        inputs = replace(self.inputs, effects=(effect,), duty_evidence=(activation,))
        state = evaluate(self.policy, inputs).duties[0]
        self.assertEqual(state.activation, "Admitted")
        self.assertEqual(state.completion, "Outstanding")
        self.assertEqual(evaluate(self.policy, inputs).act_decision.verdict, Verdict.PASS)

    def test_completion_needs_admitted_positive_named_evidence_and_activation(self):
        effect = EffectRecord(self.policy.effect_plan[0], 4, Verdict.PASS)
        activation = duty_evidence(self.policy, "activation")
        completion = duty_evidence(self.policy, "completion")
        cases = (
            ((completion,), "Outstanding"),
            ((activation, replace(completion, admission=Verdict.PENDING)), "Outstanding"),
            ((activation, replace(completion, answer=Verdict.REFUSED)), "Outstanding"),
            ((activation, completion), "Satisfied"),
        )
        for evidence, expected in cases:
            with self.subTest(evidence=evidence):
                state = evaluate(self.policy, replace(self.inputs, effects=(effect,), duty_evidence=evidence)).duties[0]
                self.assertEqual(state.completion, expected)

    def test_completion_date_and_original_deadline_are_preserved(self):
        body = self.policy.obligations[1]
        effect = EffectRecord(body.trigger, 4, Verdict.PASS)
        activation = duty_evidence(self.policy, "activation")
        early = duty_evidence(self.policy, "completion", at=3)
        state = duty_states((body,), (effect,), (activation, early), 11)[0]
        self.assertEqual(state.completion, "Outstanding")
        self.assertTrue(state.overdue)
        late = duty_evidence(self.policy, "completion", at=10)
        state = duty_states((body,), (effect,), (activation, late), 11)[0]
        self.assertEqual(state.completion, "Satisfied")
        self.assertEqual(state.completed_at, 10)
        self.assertTrue(state.deadline_missed)
        self.assertFalse(state.overdue)
        state = duty_states((body,), (effect,), (), 11)[0]
        self.assertEqual(state.activation, "Awaiting")
        self.assertTrue(state.overdue)

    def test_completion_before_activation_waits_for_admission_and_query_time(self):
        body = self.policy.obligations[1]
        effect = EffectRecord(body.trigger, 4, Verdict.PASS)
        completion = duty_evidence(self.policy, "completion", at=5)
        activation = duty_evidence(self.policy, "activation", at=6)
        before = duty_states((body,), (effect,), (activation, completion), 5)[0]
        after = duty_states((body,), (effect,), (activation, completion), 6)[0]
        self.assertEqual(before.activation, "Awaiting")
        self.assertEqual(before.completion, "Outstanding")
        self.assertEqual(after.completion, "Satisfied")
        self.assertEqual(after.completed_at, 5)
        self.assertFalse(after.deadline_missed)

    def test_duty_evidence_binds_entire_original_body(self):
        original = self.policy.obligations[1]
        evidence = duty_evidence(self.policy, "completion")
        for changes in ({"beneficiary": "other"}, {"deadline": 12},
                        {"clause": "different performance"}, {"disclosure": ("another-reader",)},
                        {"stage": "other-stage"}):
            with self.subTest(changes=changes):
                changed = replace(original, **changes)
                with self.assertRaisesRegex(ValueError, "body digest"):
                    duty_states((changed,), (), (evidence,), 5)

    def test_wrong_duty_evidence_or_effect_binding_is_rejected(self):
        effect = EffectRecord(self.policy.effect_plan[0], 4, Verdict.PASS)
        completion = duty_evidence(self.policy, "completion")
        for changes in ({"owner": "other-office"}, {"rule": "other-rule"},
                        {"effect_id": "other-trigger"}, {"instrument": "other-instrument"},
                        {"request": replace(self.inputs.request, act="other")},
                        {"obligation_id": "other-duty"}):
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    evaluate(self.policy, replace(self.inputs, effects=(effect,),
                             duty_evidence=(replace(completion, **changes),)))
        with self.assertRaises(ValueError):
            evaluate(self.policy, replace(self.inputs, effects=(replace(effect,
                effect=replace(effect.effect, authority="wrong-authority")),)))

    def test_traversal_exact_replay_is_idempotent_and_new_traversal_reuses_policy(self):
        log = TraversalLog()
        original = log.deliver("t1", self.policy, self.inputs)
        self.assertIs(log.deliver("t1", self.policy, self.inputs), original)
        again = log.deliver("t2", self.policy, self.inputs)
        self.assertEqual(again.obligations, original.obligations)
        self.assertEqual(again.source_cells, original.source_cells)
        with self.assertRaises(ValueError):
            log.deliver("t1", self.policy, answer(self.inputs, "tax", Verdict.PENDING))

    def test_conflicting_immutable_source_body_rejected_across_traversals(self):
        log = TraversalLog()
        log.deliver("t1", self.policy, self.inputs)
        cell = self.inputs.cells[0]
        with self.assertRaises(ValueError):
            replace(self.inputs, cells=(cell, replace(cell, authority="other")))
        exact_duplicate = replace(self.inputs, cells=(cell, cell))
        self.assertEqual(exact_duplicate.cells, (cell,))
        changed = with_sources(self.inputs, (replace(cell, authority="other"), self.inputs.retained[0].payload))
        with self.assertRaises(ValueError):
            log.deliver("t2", self.policy, changed)

    def test_conflicting_duty_body_cannot_reuse_identity(self):
        log = TraversalLog()
        log.deliver("t1", self.policy, self.inputs)
        original = self.policy.obligations[1]
        for changes in ({"beneficiary": "other"}, {"deadline": 12}, {"owner": "other"},
                        {"instrument": "other"}, {"completion_rule": "other"}):
            with self.subTest(changes=changes):
                changed = replace(original, **changes)
                policy = replace(self.policy, obligations=(self.policy.obligations[0], changed))
                with self.assertRaises(ValueError):
                    log.deliver("changed", policy, assess(policy, self.inputs))
                with self.assertRaises(ValueError):
                    duty_states((original, changed), (), (), 5)

    def test_unordered_fields_canonicalize_but_obligation_order_is_preserved(self):
        policy = replace(self.policy, act_domains=self.policy.act_domains[::-1],
                         authority_uses=self.policy.authority_uses[::-1],
                         current_dependencies=self.policy.current_dependencies[::-1],
                         local_authorities=self.policy.local_authorities[::-1],
                         local_instruments=self.policy.local_instruments[::-1],
                         carry=(replace(self.policy.carry[0], mapping=IDENTITY[::-1]),),
                         request=replace(self.policy.request, rules=self.policy.request.rules[::-1]),
                         venue=replace(self.policy.venue, validators=self.policy.venue.validators[::-1]))
        self.assertEqual(canonical_bytes(policy), canonical_bytes(self.policy))
        self.assertTrue(same_sovereign_structure(policy, self.policy))
        reordered = replace(policy, obligations=policy.obligations[::-1])
        self.assertFalse(same_sovereign_structure(reordered, policy))

    def test_structural_comparison_retains_operational_and_duty_fields(self):
        variants = (
            replace(self.policy, interval=Interval(0, 4)),
            replace(self.policy, act_domains=("identity",),
                    local_authorities=(("identity", "south-registry"),),
                    local_instruments=(("identity", "licensing-rule"),)),
            replace(self.policy, current_dependencies=(("authority-head", "a2"), ("sanctions-head", "s1"))),
            replace(self.policy, carry=(replace(self.policy.carry[0], mapping=DISCOUNT),)),
            replace(self.policy, obligations=(self.policy.obligations[0], replace(self.policy.obligations[1], deadline=8))),
        )
        for variant in variants:
            with self.subTest(variant=variant):
                self.assertFalse(same_sovereign_structure(self.policy, variant))

    def test_venue_change_preserves_sovereign_outputs_only_with_other_inputs_fixed(self):
        changed_venue = replace(self.policy.venue, validators=("v3", "v4"))
        changed = replace(self.policy, venue=changed_venue)
        self.assertTrue(same_sovereign_structure(self.policy, changed))
        self.assertNotEqual(digest(self.policy), digest(changed))
        self.assertEqual(evaluate(self.policy, self.inputs), evaluate(changed, self.inputs))
        # The statement is conditional: an independently changed feed still matters.
        unavailable = replace(self.inputs, dependencies=replace(self.inputs.dependencies, completeness=Verdict.PENDING))
        self.assertEqual(evaluate(changed, unavailable).import_decision.verdict, Verdict.PENDING)

    def test_venue_scope_assessment_is_separate_and_cannot_grant_local_permission(self):
        scope = self.policy.venue
        assessment = VenueAssessment(scope, "t1", "ordered-record-digest", Verdict.PASS)
        self.assertEqual(venue_order_status(scope, "t1", "ordered-record-digest", assessment).verdict, Verdict.PASS)
        for changed_scope, request, payload in ((replace(scope, book_id="other"), "t1", "ordered-record-digest"),
                                                (replace(scope, epoch="epoch-2"), "t1", "ordered-record-digest"),
                                                (scope, "other", "ordered-record-digest"),
                                                (scope, "t1", "other")):
            self.assertEqual(venue_order_status(changed_scope, request, payload, assessment).verdict, Verdict.REFUSED)
        self.assertEqual(venue_order_status(scope, "t1", "ordered-record-digest", None).verdict, Verdict.PENDING)
        result = evaluate(self.policy, answer(self.inputs, "identity", Verdict.REFUSED))
        self.assertEqual(result.act_decision.verdict, Verdict.REFUSED)
        self.assertIsNone(result.duties[0].incurred_at)

    def test_invalid_grade_vocabulary_totality_duplicates_and_order_are_rejected(self):
        invalid = (
            (("NonCompliant", Grade.NONCOMPLIANT),) + IDENTITY[1:],
            IDENTITY + (IDENTITY[0],), IDENTITY[:-1],
            ((Grade.NONCOMPLIANT, Grade.PENDING),) + IDENTITY[1:],
            ((Grade.NONCOMPLIANT, Grade.NONCOMPLIANT), (Grade.PENDING, Grade.COMPLIANT), IDENTITY[2]),
            ((Grade.NONCOMPLIANT, Grade.NONCOMPLIANT), IDENTITY[1], (Grade.COMPLIANT, Grade.NONCOMPLIANT)),
            ((Grade.NONCOMPLIANT,),),
        )
        for mapping in invalid:
            with self.subTest(mapping=mapping):
                with self.assertRaises(ValueError):
                    CarryMap("identity", "identity", "identity-scope", mapping)
        for changes in ({"grade": "Compliant"}, {"marker": Marker.EXEMPT},
                        {"grade": None, "marker": "Exempt"}, {"grade": None}):
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    replace(self.inputs.cells[0], **changes)

    def test_duplicate_and_unknown_declarations_are_rejected(self):
        invalid_policy = (
            {"current_dependencies": (("head", "a"), ("head", "a"))},
            {"fresh": ("identity", "identity")},
            {"carry": self.policy.carry * 2},
            {"import_prerequisites": ("source-permitted", "source-permitted")},
            {"obligations": self.policy.obligations * 2},
            {"fresh": ()}, {"authority_uses": self.policy.authority_uses[:1]},
        )
        for changes in invalid_policy:
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    replace(self.policy, **changes)
        with self.assertRaises(ValueError):
            replace(self.inputs, answers=self.inputs.answers * 2)
        with self.assertRaises(ValueError):
            evaluate(self.policy, replace(self.inputs, answers=self.inputs.answers + (
                replace(self.inputs.answers[0], name="not-declared"),)))
        with self.assertRaises(ValueError):
            replace(self.inputs, retained=(RetainedBytes("unknown-cell", b"anything"),))

    def test_frozen_records_and_interval_validation_remain_active(self):
        with self.assertRaises(FrozenInstanceError):
            self.inputs.cells[0].authority = "other"
        for args in ((3, 2), (True, 5), (0, 5.5)):
            with self.subTest(args=args):
                with self.assertRaises(ValueError):
                    Interval(*args)


class MutationSensitivityTests(unittest.TestCase):
    def test_independent_semantic_mutations_are_detected(self):
        """Run selected regressions against isolated, deliberately broken copies.

        Each mutation must reach an assertion failure, not an import or syntax
        error. No source file is changed. The child inherits optimization mode.
        """
        mutants = (
            ("len(payload) != cell.evidence_length", "False",
             "test_source_length_mismatch_refuses_even_with_same_bytes_and_digest"),
            ("cell.subject, cell.purpose, cell.jurisdiction",
             "cell.subject, cell.purpose, policy.source",
             "test_source_jurisdiction_mismatch_refuses_freshly_bound_records"),
            ("return dict(self.mapping)[grade]", "return grade",
             "test_declared_grade_map_changes_treatment_and_named_threshold"),
            ("min((t.grade for t in usable", "max((t.grade for t in usable",
             "test_all_sources_and_applicability_markers_survive_one_target"),
            ('for name in getattr(policy, stage + "_prerequisites"):', 'for name in ():',
             "test_missing_import_prerequisite_does_not_default_to_permission"),
            ("history = HistoryStatus.UNRESOLVED", "history = HistoryStatus.VERIFIED",
             "test_available_bytes_without_external_history_remain_unresolved"),
            ("locals_by_domain[domain] for domain in policy.act_domains",
             "locals_by_domain[domain] for domain in policy.fresh",
             "test_act_checks_A_domains_outside_fresh_set"),
            ("if not use.interval.contains(inputs.use_time):", "if False:",
             "test_authority_use_expiry_is_stage_specific"),
            ("_need(item.body_digest == digest(body),", "_need(True,",
             "test_duty_evidence_binds_entire_original_body"),
            ("policy.sovereign_digest(), instrument, digest(inputs.cells)):",
             "answer.policy_digest, instrument, digest(inputs.cells)):",
             "test_current_answer_cannot_replay_under_new_policy_instrument_or_evidence"),
            ("current = _current(policy, inputs)",
             'current = _current(policy, inputs) if "v3" not in policy.venue.validators else _decision(Verdict.REFUSED, "venue-leak")',
             "test_venue_change_preserves_sovereign_outputs_only_with_other_inputs_fixed"),
        )
        runner = r'''
import pathlib, sys, types, unittest
directory, old, new, test = sys.argv[1:]
path = pathlib.Path(directory) / "sjn_corridor_checker.py"
source = path.read_text()
if source.count(old) != 1:
    raise RuntimeError("mutation anchor is not unique")
module = types.ModuleType("sjn_corridor_checker")
module.__file__ = str(path)
sys.modules[module.__name__] = module
exec(compile(source.replace(old, new), str(path), "exec"), module.__dict__)
sys.path.insert(0, directory)
suite = unittest.defaultTestLoader.loadTestsFromName("test_sjn_corridor_checker.CorridorTests." + test)
result = unittest.TextTestRunner().run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
'''
        for old, new, test in mutants:
            with self.subTest(mutation=test):
                command = [sys.executable] + ([] if __debug__ else ["-O"])
                command += ["-c", runner, str(Path(__file__).parent), old, new, test]
                result = subprocess.run(command, capture_output=True, text=True, timeout=20)
                self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
                self.assertIn("FAILED (failures=", result.stderr)
                self.assertNotIn("ERROR:", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
