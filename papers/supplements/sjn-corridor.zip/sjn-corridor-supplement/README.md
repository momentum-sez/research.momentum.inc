# The Sovereign Jurisdiction Network: finite corridor supplement

This supplement contains the finite checker described in the paper's recognition-boundary section. It includes its behavioral tests and a file checksum manifest.

## Reproduce

Use Python 3.9 or later on a Unix-like system. The checker and tests use only the standard library. Extract the archive and run these commands inside its directory:

```sh
PYTHONOPTIMIZE= python3 -B -m unittest -v test_sjn_corridor_checker
PYTHONOPTIMIZE= python3 -B -O -m unittest -v test_sjn_corridor_checker
```

Both commands clear inherited optimization settings and must finish with `OK`. The optimized run keeps the unittest assertions active. The mutation test runs selected regressions against deliberately broken copies in memory. Each such copy must fail a behavioral assertion. The test does not modify the packaged source.

On a system with `shasum`, check the packaged files with:

```sh
shasum -a 256 -c SHA256SUMS
```

The manifest covers every packaged file except itself. Fresh logs are separate outputs and are not part of the manifest.

## Model and evidence

`sjn_corridor_checker.py` defines immutable records for one corridor edge. Its source cells preserve authority, jurisdiction, domain, subject, purpose, rule, scope, original interval, source value, derivation roots, and the expected evidence digest and length. Separate retained-byte records supply the payloads. Applicable grades are NonCompliant, Pending, and Compliant. NotApplicable and Exempt remain separate markers. A declared monotone, bottom-preserving, deflationary map translates an applicable grade. Multiple sources remain distinct when their grades enter one summary.

Carrying permits evidence reuse. Named prerequisites determine which evidence is required. Fresh local questions and the domains required for an act are separate sets. Import, local evaluation, and act admission have separate results. A missing answer stays pending. A refuted required premise takes precedence while all reasons remain recorded.

Fixtures supply historical assessments, current answers, dependency completeness assessments, effects, and duty evidence. The checker binds these inputs to their declared contexts. Available bytes alone do not establish historical verification. A current answer binds its policy, instrument, source package, request, time, and evidence cutoff.

Permission does not create an effect. An admitted effect can incur a duty while activation remains awaiting admission. Completion requires the named positive admitted evidence and activation. Late completion can satisfy a duty while the result retains its missed deadline. Exact traversal retries return the original receipt. A conflicting immutable source or duty body cannot reuse an admitted identifier.

The venue assessment names a book, protocol, epoch, and validator set. Changing only that scope leaves the fixed sovereign evaluation unchanged. A changed required external fact can change permission through its separately admitted evidence.

`test_sjn_corridor_checker.py` supplies synthetic positive and negative witnesses. It includes useful evidence reuse and an admitted act, invalid bindings, missing evidence, source aggregation, lifecycle timing, replay, and venue separation.

## Limits

This is a finite single-edge model with an in-memory traversal log. Its inputs are already normalized institutional assessments. It does not authenticate signatures, legal instruments, authority, actual feed completeness, provider performance, or durable database transactions. Structural equality does not establish full route-machine equivalence. Live-record normalization, adapter refinement, authoritative evidence acquisition, and enforcement at durable commitment remain separate construction obligations.
