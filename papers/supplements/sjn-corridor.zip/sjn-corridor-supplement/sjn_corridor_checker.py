#!/usr/bin/env python3
"""Finite single-edge witness for SJN sections 2.2 and 4.1.

Inputs are already normalized, admitted institutional records. This module
checks their finite bindings and separation; it does not authenticate law,
signatures, provider occurrences, feed completeness, or database transactions.
External assessments are explicit inputs, not conclusions drawn from hashes.
The vocabulary and integers below are a model, not a live-record wire format.

Carrying permits supplied evidence; named prerequisites determine requirements.
Fresh questions, A_v(q), and post-effect duties are separate. Exact structural
comparison is not the finite-machine behavioral equivalence of section 4.2.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
import hashlib
import json
from typing import Iterable


class Verdict(str, Enum):
    PASS = "Pass"
    PENDING = "Pending"
    REFUSED = "Refused"


class Grade(str, Enum):
    NONCOMPLIANT = "NonCompliant"
    PENDING = "Pending"
    COMPLIANT = "Compliant"


class Marker(str, Enum):
    NOT_APPLICABLE = "NotApplicable"
    EXEMPT = "Exempt"


class HistoryStatus(str, Enum):
    VERIFIED = "Verified"
    UNRESOLVED = "Unresolved"
    REFUTED = "Refuted"


GRADES = tuple(Grade)
RANK = {grade: rank for rank, grade in enumerate(GRADES)}
PRECEDENCE = {Verdict.PASS: 0, Verdict.PENDING: 1, Verdict.REFUSED: 2}


def _need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _text(*values: str) -> None:
    _need(all(isinstance(v, str) and v.strip() == v and v for v in values),
          "identifiers must be nonempty strings without surrounding whitespace")


def _context_time(request, *times) -> None:
    _need(isinstance(request, RequestContext) and all(type(t) is int for t in times),
          "malformed request/time binding")


def _unique(items: Iterable, key=lambda x: x) -> tuple:
    result = {}
    for item in items:
        identity = key(item)
        _need(identity not in result, f"duplicate identifier: {identity}")
        result[identity] = item
    return tuple(result[k] for k in sorted(result))


def _compatible(items: Iterable, key) -> tuple:
    """Compatible union: exact repetitions retain one immutable body."""
    result = {}
    for item in items:
        identity = key(item)
        _need(identity not in result or result[identity] == item,
              f"conflicting immutable body: {identity}")
        result[identity] = item
    return tuple(result[k] for k in sorted(result))


def _pairs(items: Iterable[tuple[str, str]]) -> tuple[tuple[str, str], ...]:
    items = tuple(tuple(item) for item in items)
    for item in items:
        _need(len(item) == 2, "expected name/value pair")
        _text(*item)
    return _unique(items, lambda x: x[0])


def _set_field(obj, field: str, key=lambda x: x) -> None:
    object.__setattr__(obj, field, _unique(getattr(obj, field), key))


def _jsonable(value):
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, bytes):
        return {"bytes_hex": value.hex()}
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def canonical_bytes(value) -> bytes:
    """Exact encoding of these normalized dataclasses; no semantic inference."""
    return json.dumps(_jsonable(value), sort_keys=True,
                      separators=(",", ":"), ensure_ascii=True).encode("ascii")


def digest(value) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


@dataclass(frozen=True)
class Decision:
    verdict: Verdict
    reasons: tuple[str, ...] = ()

    def __post_init__(self):
        _need(isinstance(self.verdict, Verdict), "unknown verdict")
        object.__setattr__(self, "reasons", tuple(sorted(set(self.reasons))))


def _decision(verdict: Verdict, reason: str) -> Decision:
    return Decision(verdict, (reason,))


def _combine(parts: Iterable[Decision]) -> Decision:
    parts = tuple(parts)
    return Decision(max((p.verdict for p in parts), key=PRECEDENCE.get,
                        default=Verdict.PASS),
                    tuple(reason for p in parts for reason in p.reasons))


@dataclass(frozen=True)
class Interval:
    start: int
    end: int

    def __post_init__(self):
        _need(type(self.start) is int and type(self.end) is int
              and self.start <= self.end, "malformed closed interval")

    def contains(self, time: int) -> bool:
        return self.start <= time <= self.end


@dataclass(frozen=True)
class RequestContext:
    act: str
    subject: str
    purpose: str
    rules: tuple[tuple[str, str], ...]

    def __post_init__(self):
        _text(self.act, self.subject, self.purpose)
        object.__setattr__(self, "rules", _pairs(self.rules))


@dataclass(frozen=True)
class SourceCell:
    cell_id: str
    authority: str
    jurisdiction: str
    domain: str
    subject: str
    purpose: str
    source_act: str
    rule: str
    instrument: str
    scope: str
    interval: Interval
    source_value: str
    grade: Grade | None
    marker: Marker | None
    derivation_roots: tuple[str, ...]
    evidence_sha256: str
    evidence_length: int

    def __post_init__(self):
        _text(self.cell_id, self.authority, self.jurisdiction, self.domain,
              self.subject, self.purpose, self.source_act, self.rule,
              self.instrument, self.scope, self.source_value)
        _need((isinstance(self.grade, Grade) and self.marker is None)
              or (self.grade is None and isinstance(self.marker, Marker)),
              "cell must have one known applicable grade or applicability marker")
        _need(isinstance(self.interval, Interval), "missing source interval")
        _set_field(self, "derivation_roots")
        _text(*self.derivation_roots)
        _need(len(self.evidence_sha256) == 64
              and all(c in "0123456789abcdef" for c in self.evidence_sha256),
              "malformed source digest")
        _need(type(self.evidence_length) is int and self.evidence_length >= 0,
              "malformed evidence length")


@dataclass(frozen=True)
class CarryMap:
    source_domain: str
    target_domain: str
    source_scope: str
    mapping: tuple[tuple[Grade, Grade], ...]

    def __post_init__(self):
        _text(self.source_domain, self.target_domain, self.source_scope)
        pairs = tuple(tuple(pair) for pair in self.mapping)
        _need(all(len(p) == 2 and all(isinstance(g, Grade) for g in p)
                  for p in pairs), "unknown or malformed grade map entry")
        pairs = _unique(pairs, lambda p: p[0])
        table = dict(pairs)
        _need(set(table) == set(GRADES), "grade map must be total")
        mapped = [RANK[table[g]] for g in GRADES]
        _need(mapped[0] == 0 and mapped == sorted(mapped)
              and all(out <= rank for rank, out in enumerate(mapped)),
              "map must be monotone, bottom-preserving and deflationary")
        object.__setattr__(self, "mapping", pairs)

    def apply(self, grade: Grade) -> Grade:
        _need(isinstance(grade, Grade), "unknown input grade")
        return dict(self.mapping)[grade]


@dataclass(frozen=True)
class EvidenceRequirement:
    name: str
    stage: str
    target_domain: str
    minimum: Grade

    def __post_init__(self):
        _text(self.name, self.target_domain)
        _need(self.stage in ("import", "act"), "unknown prerequisite stage")
        _need(isinstance(self.minimum, Grade), "unknown evidence threshold")


@dataclass(frozen=True)
class AuthorityUse:
    authority: str
    instrument: str
    stage: str
    interval: Interval

    def __post_init__(self):
        _text(self.authority, self.instrument)
        _need(self.stage in ("import", "act"), "unknown authority-use stage")
        _need(isinstance(self.interval, Interval), "missing authority-use interval")


@dataclass(frozen=True)
class EffectSpec:
    effect_id: str
    kind: str
    request: RequestContext
    instrument: str
    authority: str

    def __post_init__(self):
        _text(self.effect_id, self.kind, self.instrument, self.authority)
        _context_time(self.request)


@dataclass(frozen=True)
class ObligationBody:
    obligation_id: str
    role: str
    domain: str
    clause: str
    owner: str
    beneficiary: str
    destination: str
    trigger: EffectSpec
    request: RequestContext
    instrument: str
    deadline: int
    stage: str
    disclosure: tuple[str, ...]
    activation_rule: str
    completion_rule: str

    def __post_init__(self):
        _text(self.obligation_id, self.domain, self.clause, self.owner,
              self.beneficiary, self.destination, self.instrument, self.stage,
              self.activation_rule, self.completion_rule)
        _need(self.role in ("fresh", "continuing"), "unknown obligation role")
        _context_time(self.request, self.deadline)
        _need(isinstance(self.trigger, EffectSpec) and self.trigger.request == self.request,
              "malformed obligation trigger")
        _set_field(self, "disclosure")
        _text(*self.disclosure)


@dataclass(frozen=True)
class VenueScope:
    venue_id: str
    book_id: str
    protocol: str
    epoch: str
    validators: tuple[str, ...]

    def __post_init__(self):
        _text(self.venue_id, self.book_id, self.protocol, self.epoch)
        _set_field(self, "validators")
        _text(*self.validators)
        _need(bool(self.validators), "empty venue roster")


@dataclass(frozen=True)
class CorridorPolicy:
    policy_id: str
    source: str
    destination: str
    request: RequestContext
    carry: tuple[CarryMap, ...]
    fresh: tuple[str, ...]
    act_domains: tuple[str, ...]
    local_authorities: tuple[tuple[str, str], ...]
    local_instruments: tuple[tuple[str, str], ...]
    import_prerequisites: tuple[str, ...]
    act_prerequisites: tuple[str, ...]
    evidence_requirements: tuple[EvidenceRequirement, ...]
    authority_uses: tuple[AuthorityUse, ...]
    interval: Interval
    current_dependencies: tuple[tuple[str, str], ...]
    currentness_rule: str
    effect_plan: tuple[EffectSpec, ...]
    obligations: tuple[ObligationBody, ...]
    venue: VenueScope | None = None

    def __post_init__(self):
        _text(self.policy_id, self.source, self.destination, self.currentness_rule)
        _need(isinstance(self.request, RequestContext)
              and isinstance(self.interval, Interval), "malformed policy context/interval")
        _set_field(self, "carry", lambda m: m.source_domain)
        for field in ("fresh", "act_domains", "import_prerequisites", "act_prerequisites"):
            _set_field(self, field)
            _text(*getattr(self, field))
        object.__setattr__(self, "local_authorities", _pairs(self.local_authorities))
        object.__setattr__(self, "local_instruments", _pairs(self.local_instruments))
        object.__setattr__(self, "current_dependencies", _pairs(self.current_dependencies))
        _set_field(self, "evidence_requirements", lambda r: r.name)
        _set_field(self, "authority_uses", lambda a: a.stage)
        _set_field(self, "effect_plan", lambda e: e.effect_id)
        _need(all(e.request == self.request for e in self.effect_plan),
              "effect plan has wrong request")
        _need({a.stage for a in self.authority_uses} == {"import", "act"},
              "both authority-use stages must be explicit")
        _need(set(dict(self.local_authorities)) == set(self.fresh) | set(self.act_domains),
              "local authority declarations must cover exactly F and A_v(q)")
        _need(set(dict(self.local_instruments)) == set(dict(self.local_authorities)),
              "each local question must name its governing instrument")
        all_gates = self.import_prerequisites + self.act_prerequisites + tuple(
            r.name for r in self.evidence_requirements)
        _unique(all_gates)
        # Clause order is significant; do not sort this collection.
        bodies = tuple(self.obligations)
        _compatible(bodies, lambda o: o.obligation_id)
        _need(len({o.obligation_id for o in bodies}) == len(bodies),
              "duplicate obligation in policy")
        object.__setattr__(self, "obligations", bodies)
        _need({o.domain for o in bodies if o.role == "fresh"} == set(self.fresh),
              "fresh set must equal local-evaluation clause projection")
        for body in bodies:
            _need(body.request == self.request and body.destination == self.destination,
                  "obligation request/destination differs from policy")
            if body.role == "fresh":
                _need((body.owner, body.instrument) == (
                      dict(self.local_authorities)[body.domain],
                      dict(self.local_instruments)[body.domain]),
                      "fresh clause has wrong local authority/instrument")
            else:
                _need(body.trigger in self.effect_plan, "duty trigger is absent from effect plan")

    def sovereign_record(self) -> dict:
        record = asdict(self)
        record.pop("venue")
        return record

    def sovereign_digest(self) -> str:
        return digest(self.sovereign_record())


def same_sovereign_structure(left: CorridorPolicy, right: CorridorPolicy) -> bool:
    """Canonical field equality, not route substitutability."""
    return canonical_bytes(left.sovereign_record()) == canonical_bytes(right.sovereign_record())


@dataclass(frozen=True)
class RetainedBytes:
    cell_id: str
    payload: bytes | None

    def __post_init__(self):
        _text(self.cell_id)
        _need(self.payload is None or isinstance(self.payload, bytes), "payload must be bytes")


@dataclass(frozen=True)
class HistoryAssessment:
    cell: SourceCell
    source_bytes: bytes
    cutoff: int
    status: HistoryStatus

    def __post_init__(self):
        _need(isinstance(self.cell, SourceCell) and isinstance(self.source_bytes, bytes)
              and type(self.cutoff) is int and isinstance(self.status, HistoryStatus),
              "malformed external historical assessment")


@dataclass(frozen=True)
class DependencyAssessment:
    policy_digest: str
    request: RequestContext
    use_time: int
    cutoff: int
    scope: tuple[str, ...]
    currentness_rule: str
    observed: tuple[tuple[str, str], ...]
    completeness: Verdict

    def __post_init__(self):
        _set_field(self, "scope")
        _text(self.policy_digest, self.currentness_rule, *self.scope)
        _context_time(self.request, self.use_time, self.cutoff)
        object.__setattr__(self, "observed", _pairs(self.observed))
        _need(isinstance(self.completeness, Verdict), "unknown completeness assessment")


@dataclass(frozen=True)
class CurrentAnswer:
    name: str
    authority: str
    request: RequestContext
    stage: str
    use_time: int
    cutoff: int
    verdict: Verdict
    policy_digest: str
    instrument: str
    evidence_digest: str

    def __post_init__(self):
        _text(self.name, self.authority, self.policy_digest, self.instrument, self.evidence_digest)
        _context_time(self.request, self.use_time, self.cutoff)
        _need(self.stage in ("import", "act", "local", "operational"), "unknown answer stage")
        _need(isinstance(self.verdict, Verdict), "unknown current answer")


@dataclass(frozen=True)
class EffectRecord:
    effect: EffectSpec
    occurred_at: int
    admission: Verdict

    def __post_init__(self):
        _need(isinstance(self.effect, EffectSpec) and type(self.occurred_at) is int
              and isinstance(self.admission, Verdict),
              "malformed effect assessment")


@dataclass(frozen=True)
class DutyEvidence:
    evidence_id: str
    kind: str
    obligation_id: str
    body_digest: str
    effect_id: str
    request: RequestContext
    instrument: str
    owner: str
    rule: str
    recorded_at: int
    admission: Verdict
    answer: Verdict

    def __post_init__(self):
        _text(self.evidence_id, self.obligation_id, self.body_digest, self.effect_id, self.instrument,
              self.owner, self.rule)
        _need(self.kind in ("activation", "completion"), "unknown duty evidence kind")
        _context_time(self.request, self.recorded_at)
        _need(isinstance(self.admission, Verdict) and isinstance(self.answer, Verdict),
              "malformed duty evidence assessment")


@dataclass(frozen=True)
class EvaluationInput:
    request: RequestContext
    use_time: int
    cutoff: int
    cells: tuple[SourceCell, ...]
    retained: tuple[RetainedBytes, ...]
    histories: tuple[HistoryAssessment, ...]
    dependencies: DependencyAssessment | None
    answers: tuple[CurrentAnswer, ...]
    effects: tuple[EffectRecord, ...] = ()
    duty_evidence: tuple[DutyEvidence, ...] = ()

    def __post_init__(self):
        _need(isinstance(self.request, RequestContext) and type(self.use_time) is int
              and type(self.cutoff) is int, "malformed evaluation context/time")
        object.__setattr__(self, "cells", _compatible(self.cells, lambda c: c.cell_id))
        for field, key in (("retained", lambda x: x.cell_id),
                           ("histories", lambda x: x.cell.cell_id),
                           ("answers", lambda x: (x.stage, x.name)),
                           ("effects", lambda x: x.effect.effect_id),
                           ("duty_evidence", lambda x: x.evidence_id)):
            _set_field(self, field, key)
        ids = {c.cell_id for c in self.cells}
        _need({r.cell_id for r in self.retained} <= ids
              and {h.cell.cell_id for h in self.histories} <= ids,
              "evidence names unknown source cell")


@dataclass(frozen=True)
class CellTreatment:
    cell_id: str
    target_domain: str | None
    grade: Grade | None
    marker: Marker | None
    bytes_status: str
    history_status: HistoryStatus
    eligibility: Decision  # Source check; import_decision applies the stage gates.


@dataclass(frozen=True)
class GradeSummary:
    domain: str
    grade: Grade | None  # None is empty-fold top, never a compliant observation.
    markers: tuple[Marker, ...]


@dataclass(frozen=True)
class DutyState:
    body: ObligationBody
    incurred_at: int | None
    activation: str
    completion: str
    completed_at: int | None
    deadline_missed: bool
    overdue: bool


@dataclass(frozen=True)
class SovereignResult:
    """Public outcome with the exact retained evidence and assessment context."""

    retained_input: EvaluationInput
    treatments: tuple[CellTreatment, ...]
    admitted_cell_ids: tuple[str, ...]
    summaries: tuple[GradeSummary, ...]
    import_decision: Decision
    fresh_decisions: tuple[tuple[str, Decision], ...]
    act_decision: Decision
    effect_plan: tuple[EffectSpec, ...]
    duties: tuple[DutyState, ...]


def _answer(policy, inputs, name, stage, authority, instrument) -> Decision:
    answers = {(a.stage, a.name): a for a in inputs.answers}
    answer = answers.get((stage, name))
    label = f"{stage}:{name}"
    if answer is None:
        return _decision(Verdict.PENDING, f"{label}:missing-answer")
    # The source-cell package binds every expected evidence digest and byte
    # length. Retrieval and historical verification remain separate checks.
    if (answer.authority, answer.request, answer.use_time, answer.cutoff,
            answer.policy_digest, answer.instrument, answer.evidence_digest) != (
            authority, inputs.request, inputs.use_time, inputs.cutoff,
            policy.sovereign_digest(), instrument, digest(inputs.cells)):
        return _decision(Verdict.REFUSED, f"{label}:binding-mismatch")
    return _decision(answer.verdict, f"{label}:{answer.verdict.value}")


def _current(policy, inputs) -> Decision:
    parts = []
    if inputs.request != policy.request:
        parts.append(_decision(Verdict.REFUSED, "request:policy-context-mismatch"))
    if not policy.interval.contains(inputs.use_time):
        parts.append(_decision(Verdict.REFUSED, "policy:expired-use-interval"))
    assessment = inputs.dependencies
    if assessment is None:
        parts.append(_decision(Verdict.PENDING, "dependencies:missing-assessment"))
    else:
        if (assessment.policy_digest, assessment.request, assessment.use_time,
                assessment.cutoff, assessment.scope, assessment.currentness_rule) != (
                policy.sovereign_digest(), inputs.request, inputs.use_time,
                inputs.cutoff, tuple(name for name, _ in policy.current_dependencies),
                policy.currentness_rule):
            parts.append(_decision(Verdict.REFUSED, "dependencies:binding-mismatch"))
        parts.append(_decision(assessment.completeness, "dependencies:completeness:"
                               + assessment.completeness.value))
        observed = dict(assessment.observed)
        for name, expected in policy.current_dependencies:
            if name not in observed:
                parts.append(_decision(Verdict.PENDING, f"dependency:{name}:missing"))
            elif observed[name] != expected:
                parts.append(_decision(Verdict.REFUSED, f"dependency:{name}:changed"))
    return _combine(parts)


def _treatment(policy, inputs, cell) -> CellTreatment:
    carried = {m.source_domain: m for m in policy.carry}.get(cell.domain)
    payload = {r.cell_id: r.payload for r in inputs.retained}.get(cell.cell_id)
    assessment = {h.cell.cell_id: h for h in inputs.histories}.get(cell.cell_id)
    parts = []
    if payload is None:
        byte_status = "Missing"
        parts.append(_decision(Verdict.PENDING, f"cell:{cell.cell_id}:missing-bytes"))
    elif (len(payload) != cell.evidence_length
          or hashlib.sha256(payload).hexdigest() != cell.evidence_sha256):
        byte_status = "Corrupt"
        parts.append(_decision(Verdict.REFUSED, f"cell:{cell.cell_id}:corrupt-bytes"))
    else:
        byte_status = "Available"
    history = HistoryStatus.UNRESOLVED
    if byte_status == "Available" and assessment is not None:
        if (assessment.cell, assessment.source_bytes, assessment.cutoff) != (
                cell, payload, inputs.cutoff):
            parts.append(_decision(Verdict.REFUSED, f"cell:{cell.cell_id}:history-binding-mismatch"))
        else:
            history = assessment.status
    history_verdict = {HistoryStatus.VERIFIED: Verdict.PASS,
                       HistoryStatus.UNRESOLVED: Verdict.PENDING,
                       HistoryStatus.REFUTED: Verdict.REFUSED}[history]
    parts.append(_decision(history_verdict, f"cell:{cell.cell_id}:history:{history.value}"))
    if not cell.interval.contains(inputs.use_time):
        parts.append(_decision(Verdict.REFUSED, f"cell:{cell.cell_id}:expired-source-interval"))
    if (cell.subject, cell.purpose, cell.jurisdiction) != (
            inputs.request.subject, inputs.request.purpose, policy.source):
        parts.append(_decision(Verdict.REFUSED, f"cell:{cell.cell_id}:context-mismatch"))
    if carried is not None and cell.scope != carried.source_scope:
        parts.append(_decision(Verdict.REFUSED, f"cell:{cell.cell_id}:scope-mismatch"))
    return CellTreatment(cell.cell_id, carried.target_domain if carried else None,
                         carried.apply(cell.grade) if carried and cell.grade else None,
                         cell.marker, byte_status, history, _combine(parts))


def _summarize(treatments) -> tuple[GradeSummary, ...]:
    domains = sorted({t.target_domain for t in treatments if t.target_domain is not None})
    result = []
    for domain in domains:
        usable = [t for t in treatments if t.target_domain == domain
                  and t.eligibility.verdict == Verdict.PASS]
        result.append(GradeSummary(domain,
                      min((t.grade for t in usable if t.grade is not None),
                          key=RANK.get, default=None),
                      tuple(sorted({t.marker for t in usable if t.marker is not None}))))
    return tuple(result)


def _evidence_gate(requirement, summaries) -> Decision:
    summary = {s.domain: s for s in summaries}.get(requirement.target_domain)
    label = f"{requirement.stage}:{requirement.name}"
    if summary is None or summary.grade is None:
        return _decision(Verdict.PENDING, f"{label}:missing-applicable-evidence")
    verdict = Verdict.PASS if RANK[summary.grade] >= RANK[requirement.minimum] else Verdict.REFUSED
    return _decision(verdict, f"{label}:grade:{summary.grade.value}")


def duty_states(bodies, effects, evidence, time) -> tuple[DutyState, ...]:
    """Project external admitted events; permission does not create an event."""
    bodies = _compatible(bodies, lambda o: o.obligation_id)
    effects = _unique(effects, lambda e: e.effect.effect_id)
    evidence = _unique(evidence, lambda e: e.evidence_id)
    body_map = {o.obligation_id: o for o in bodies}
    effect_map = {e.effect.effect_id: e for e in effects}
    for item in evidence:
        _need(item.obligation_id in body_map, "duty evidence names unknown obligation")
        body = body_map[item.obligation_id]
        _need(body.role == "continuing", "duty evidence names a local-evaluation clause")
        _need(item.body_digest == digest(body), "duty evidence has wrong immutable body digest")
        _need((item.effect_id, item.request, item.instrument, item.owner) == (
            body.trigger.effect_id, body.request, body.instrument, body.owner),
            "duty evidence binding mismatch")
        expected_rule = body.activation_rule if item.kind == "activation" else body.completion_rule
        _need(item.rule == expected_rule, "duty evidence names wrong rule")
    states = []
    for body in bodies:
        if body.role != "continuing":
            continue
        effect = effect_map.get(body.trigger.effect_id)
        if effect is not None:
            _need(effect.effect == body.trigger, "effect binding mismatch")
        if effect is None or effect.admission != Verdict.PASS or effect.occurred_at > time:
            states.append(DutyState(body, None, "Conditional", "Conditional", None, False, False))
            continue
        items = [e for e in evidence if e.obligation_id == body.obligation_id
                 and e.admission == Verdict.PASS and e.answer == Verdict.PASS
                 and effect.occurred_at <= e.recorded_at <= time]
        active = any(e.kind == "activation" for e in items)
        # An admitted positive answer is interpreted under the named completion
        # rule. Late performance may discharge a duty; retain its lateness.
        completed_at = min((e.recorded_at for e in items if e.kind == "completion"),
                           default=None) if active else None
        completed = completed_at is not None
        states.append(DutyState(body, effect.occurred_at,
                               "Admitted" if active else "Awaiting",
                               "Satisfied" if completed else "Outstanding",
                               completed_at,
                               (completed_at if completed else time) > body.deadline,
                               time > body.deadline and not completed))
    return tuple(states)


def evaluate(policy: CorridorPolicy, inputs: EvaluationInput) -> SovereignResult:
    """Pure sovereign evaluation. Venue state is deliberately not an input."""
    uses = {a.stage: a for a in policy.authority_uses}
    allowed_answers = ({("import", name) for name in policy.import_prerequisites}
                       | {("act", name) for name in policy.act_prerequisites}
                       | {("local", name) for name in dict(policy.local_authorities)}
                       | {("operational", "act-authority")})
    _need({(a.stage, a.name) for a in inputs.answers} <= allowed_answers,
          "answer names unknown prerequisite or local question")
    current = _current(policy, inputs)
    treatments = tuple(_treatment(policy, inputs, cell) for cell in inputs.cells)
    candidate_summaries = _summarize(treatments)

    def stage_parts(stage):
        use = uses[stage]
        parts = [current]
        if not use.interval.contains(inputs.use_time):
            parts.append(_decision(Verdict.REFUSED, f"{stage}:expired-authority-use-interval"))
        for name in getattr(policy, stage + "_prerequisites"):
            parts.append(_answer(policy, inputs, name, stage, use.authority, use.instrument))
        return parts

    import_parts = stage_parts("import")
    import_parts.extend(t.eligibility for t in treatments if t.target_domain is not None)
    import_parts.extend(_evidence_gate(r, candidate_summaries)
                        for r in policy.evidence_requirements if r.stage == "import")
    imported = _combine(import_parts)
    summaries = candidate_summaries if imported.verdict == Verdict.PASS else ()
    locals_by_domain = {domain: _answer(policy, inputs, domain, "local", authority,
                                       dict(policy.local_instruments)[domain])
                        for domain, authority in policy.local_authorities}
    act_parts = stage_parts("act")
    act_parts.extend(locals_by_domain[domain] for domain in policy.act_domains)
    act_parts.append(_answer(policy, inputs, "act-authority", "operational",
                             uses["act"].authority, uses["act"].instrument))
    for requirement in policy.evidence_requirements:
        if requirement.stage == "act":
            act_parts.append(imported)
            act_parts.append(_evidence_gate(requirement, summaries))
    act = _combine(act_parts)
    effect_plan = policy.effect_plan if act.verdict == Verdict.PASS else ()
    admitted = tuple(t.cell_id for t in treatments if t.target_domain is not None) if imported.verdict == Verdict.PASS else ()
    return SovereignResult(inputs, treatments, admitted, summaries, imported,
                           tuple((d, locals_by_domain[d]) for d in policy.fresh), act,
                           effect_plan, duty_states(policy.obligations, inputs.effects,
                                                    inputs.duty_evidence, inputs.use_time))


@dataclass(frozen=True)
class ImportReceipt:
    traversal_id: str
    ordered_policies: tuple[CorridorPolicy, ...]
    source_cells: tuple[SourceCell, ...]
    obligations: tuple[ObligationBody, ...]
    result: SovereignResult


class TraversalLog:
    """In-memory exact-replay witness; supplies no durability/transaction proof."""

    def __init__(self):
        self._records = {}
        self._cells = {}
        self._obligations = {}

    def deliver(self, traversal_id: str, policy: CorridorPolicy,
                inputs: EvaluationInput) -> ImportReceipt:
        _text(traversal_id)
        encoded = canonical_bytes((policy, inputs))
        if traversal_id in self._records:
            previous, receipt = self._records[traversal_id]
            _need(previous == encoded, "traversal replay has changed inputs")
            return receipt
        _compatible(tuple(self._cells.values()) + inputs.cells, lambda c: c.cell_id)
        _compatible(tuple(self._obligations.values()) + policy.obligations,
                    lambda o: o.obligation_id)
        result = evaluate(policy, inputs)
        receipt = ImportReceipt(traversal_id, (policy,), inputs.cells, policy.obligations, result)
        # Failed observations are replayable, but do not admit immutable bodies.
        if result.import_decision.verdict == Verdict.PASS:
            self._cells.update((c.cell_id, c) for c in inputs.cells)
            self._obligations.update((o.obligation_id, o) for o in policy.obligations)
        self._records[traversal_id] = (encoded, receipt)
        return receipt


@dataclass(frozen=True)
class VenueAssessment:
    scope: VenueScope
    request_id: str
    ordered_digest: str
    verdict: Verdict

    def __post_init__(self):
        _text(self.request_id, self.ordered_digest)
        _need(isinstance(self.scope, VenueScope) and isinstance(self.verdict, Verdict),
              "malformed external venue assessment")


def venue_order_status(scope: VenueScope, request_id: str, ordered_digest: str,
                       assessment: VenueAssessment | None) -> Decision:
    """Consume a supplied scope/order assessment; do not verify a certificate."""
    if assessment is None:
        return _decision(Verdict.PENDING, "venue:missing-assessment")
    if (assessment.scope, assessment.request_id, assessment.ordered_digest) != (
            scope, request_id, ordered_digest):
        return _decision(Verdict.REFUSED, "venue:scope-or-order-binding-mismatch")
    return _decision(assessment.verdict, "venue:external-assessment:" + assessment.verdict.value)


if __name__ == "__main__":
    import unittest
    unittest.main(module="test_sjn_corridor_checker", verbosity=2)
