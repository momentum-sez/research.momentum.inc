#!/usr/bin/env python3
"""Bounded lossless checker for the P02 evidence/obligation boundary.

This is a reference checker for finite JSON frames. It validates the complete
schema, cross references, context binding, canonicalizes semantically unordered
collections, and checks a producer/consumer round trip. It does not verify
signatures, legal adoption, an evaluator implementation, or unbounded rules.
No external packages are required; failures are explicit and remain failures
under ``python -O``.
"""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import sys
from typing import Any

SCHEMA = "p02.boundary.v1"
APPLICABILITY = {"App", "NA", "E"}
DECISIONS = {"Permit", "Refuse", "Await"}


class FrameError(ValueError):
    """The supplied boundary frame is incomplete or inconsistent."""


def _keys(obj: Any, required: set[str], optional: set[str], where: str) -> None:
    if not isinstance(obj, dict):
        raise FrameError(f"{where}: expected object")
    actual = set(obj)
    missing = required - actual
    unknown = actual - required - optional
    if missing:
        raise FrameError(f"{where}: missing {sorted(missing)}")
    if unknown:
        raise FrameError(f"{where}: unknown {sorted(unknown)}")


def _strings(value: Any, where: str, *, nonempty: bool = True) -> None:
    if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
        raise FrameError(f"{where}: expected string list")
    if nonempty and not value:
        raise FrameError(f"{where}: empty list")


def _context(ctx: Any, request: dict[str, str], where: str) -> None:
    _keys(ctx, {"request_id", "authority_snapshot", "rule_windows"}, set(), where)
    if ctx["request_id"] != request["id"]:
        raise FrameError(f"{where}: request binding mismatch")
    for i, window in enumerate(ctx["rule_windows"]):
        p = f"{where}.rule_windows[{i}]"
        _keys(window, {"authority", "version", "not_before", "not_after"}, set(), p)
        if window["not_before"] >= window["not_after"]:
            raise FrameError(f"{p}: invalid interval")


def validate(frame: Any) -> dict[str, Any]:
    """Validate one complete frame and return a deep copy for canonicalization."""
    _keys(frame, {"schema", "request", "context", "cells", "corridors",
                  "obligations", "decision", "history"}, set(), "frame")
    if frame["schema"] != SCHEMA:
        raise FrameError("frame: unsupported schema")
    request = frame["request"]
    _keys(request, {"id", "act", "subject", "purpose", "use_time"}, set(), "request")
    if any(not isinstance(request[k], str) or not request[k] for k in request):
        raise FrameError("request: all fields must be nonempty strings")
    _context(frame["context"], request, "context")
    context_snapshots = {frame["context"]["authority_snapshot"]}
    rule_versions = {w["version"] for w in frame["context"]["rule_windows"]}

    cells = frame["cells"]
    if not isinstance(cells, list):
        raise FrameError("cells: expected list")
    cell_ids: set[str] = set()
    for i, cell in enumerate(cells):
        p = f"cells[{i}]"
        _keys(cell, {"id", "issuer", "jurisdiction", "domain", "applicability",
                     "rule_version", "issue_anchor", "valid_from", "valid_until",
                     "derivation_roots", "request_id", "act", "subject", "purpose"},
              {"grade", "exemption_authority", "exemption_scope"}, p)
        cid = cell["id"]
        if not isinstance(cid, str) or not cid or cid in cell_ids:
            raise FrameError(f"{p}: duplicate or empty id")
        cell_ids.add(cid)
        for k in ("issuer", "jurisdiction", "domain", "rule_version", "issue_anchor",
                  "valid_from", "valid_until", "request_id", "act", "subject", "purpose"):
            if not isinstance(cell[k], str) or not cell[k]:
                raise FrameError(f"{p}.{k}: expected nonempty string")
        if cell["valid_from"] >= cell["valid_until"]:
            raise FrameError(f"{p}: invalid validity interval")
        if cell["rule_version"] not in rule_versions:
            raise FrameError(f"{p}: rule version is outside the frame context")
        if cell["request_id"] != request["id"] or cell["act"] != request["act"] \
                or cell["subject"] != request["subject"] or cell["purpose"] != request["purpose"]:
            raise FrameError(f"{p}: request context mismatch")
        if cell["applicability"] not in APPLICABILITY:
            raise FrameError(f"{p}: invalid applicability")
        if not isinstance(cell["derivation_roots"], list) or \
                any(not isinstance(x, str) or not x for x in cell["derivation_roots"]):
            raise FrameError(f"{p}.derivation_roots: expected string list")
        app = cell["applicability"]
        if app == "App":
            if "grade" not in cell or not isinstance(cell["grade"], str) or not cell["grade"]:
                raise FrameError(f"{p}: applicable cell needs grade")
            if "exemption_authority" in cell or "exemption_scope" in cell:
                raise FrameError(f"{p}: applicable cell cannot carry exemption fields")
        elif app == "NA":
            if "grade" in cell or "exemption_authority" in cell or "exemption_scope" in cell:
                raise FrameError(f"{p}: not-applicable cell has incompatible fields")
        else:
            if "grade" in cell or not isinstance(cell.get("exemption_authority"), str) \
                    or not cell["exemption_authority"] or not isinstance(cell.get("exemption_scope"), str) \
                    or not cell["exemption_scope"]:
                raise FrameError(f"{p}: exempt cell needs authority and scope")

    corridors = frame["corridors"]
    if not isinstance(corridors, list):
        raise FrameError("corridors: expected ordered list")
    edge_ids: set[str] = set()
    obligation_refs: set[str] = set()
    for i, edge in enumerate(corridors):
        p = f"corridors[{i}]"
        _keys(edge, {"id", "source", "destination", "context", "carrying_domains",
                     "maps", "fresh_obligations", "clauses"}, set(), p)
        if not isinstance(edge["id"], str) or not edge["id"] or edge["id"] in edge_ids:
            raise FrameError(f"{p}: duplicate or empty id")
        edge_ids.add(edge["id"])
        if not isinstance(edge["source"], str) or not isinstance(edge["destination"], str) \
                or not edge["source"] or not edge["destination"] or edge["source"] == edge["destination"]:
            raise FrameError(f"{p}: invalid endpoints")
        _context(edge["context"], request, f"{p}.context")
        context_snapshots.add(edge["context"]["authority_snapshot"])
        rule_versions.update(w["version"] for w in edge["context"]["rule_windows"])
        _strings(edge["carrying_domains"], f"{p}.carrying_domains", nonempty=False)
        if len(set(edge["carrying_domains"])) != len(edge["carrying_domains"]):
            raise FrameError(f"{p}.carrying_domains: duplicates")
        if not isinstance(edge["maps"], dict):
            raise FrameError(f"{p}.maps: expected object")
        if set(edge["maps"]) != set(edge["carrying_domains"]):
            raise FrameError(f"{p}.maps: must cover exactly carrying domains")
        for domain, mapping in edge["maps"].items():
            if not isinstance(mapping, dict) or not mapping or any(not isinstance(k, str) or not isinstance(v, str)
                                                                   for k, v in mapping.items()):
                raise FrameError(f"{p}.maps[{domain}]: expected finite string map")
        _strings(edge["fresh_obligations"], f"{p}.fresh_obligations", nonempty=False)
        for oid in edge["fresh_obligations"]:
            if oid in obligation_refs:
                raise FrameError(f"{p}: obligation referenced by multiple edges")
            obligation_refs.add(oid)
        if not isinstance(edge["clauses"], list):
            raise FrameError(f"{p}.clauses: expected list")
        clause_ids: set[str] = set()
        for j, clause in enumerate(edge["clauses"]):
            cp = f"{p}.clauses[{j}]"
            _keys(clause, {"id", "authority", "domain", "scope", "instrument"}, set(), cp)
            if not isinstance(clause["id"], str) or not clause["id"] or clause["id"] in clause_ids:
                raise FrameError(f"{cp}: duplicate or empty id")
            clause_ids.add(clause["id"])
            if any(not isinstance(clause[k], str) or not clause[k]
                   for k in ("authority", "domain", "scope", "instrument")):
                raise FrameError(f"{cp}: empty clause field")

    obligations = frame["obligations"]
    if not isinstance(obligations, list):
        raise FrameError("obligations: expected list")
    obligation_ids: set[str] = set()
    for i, obligation in enumerate(obligations):
        p = f"obligations[{i}]"
        _keys(obligation, {"id", "owner", "beneficiary", "unit", "quantity", "trigger",
                           "deadline", "status", "request_id", "context_snapshot"}, set(), p)
        oid = obligation["id"]
        if not isinstance(oid, str) or not oid or oid in obligation_ids:
            raise FrameError(f"{p}: duplicate or empty id")
        obligation_ids.add(oid)
        if any(not isinstance(obligation[k], str) or not obligation[k]
               for k in ("owner", "beneficiary", "unit", "quantity", "trigger", "deadline", "status", "request_id", "context_snapshot")):
            raise FrameError(f"{p}: empty field")
        if obligation["request_id"] != request["id"]:
            raise FrameError(f"{p}: request context mismatch")
        if obligation["context_snapshot"] not in context_snapshots:
            raise FrameError(f"{p}: unknown context snapshot")
    if not obligation_refs <= obligation_ids:
        raise FrameError(f"obligations: dangling corridor reference {sorted(obligation_refs - obligation_ids)}")

    decision = frame["decision"]
    if decision is not None:
        _keys(decision, {"authority", "value", "supporting_cells", "guards"}, set(), "decision")
        if not isinstance(decision["authority"], str) or not decision["authority"] \
                or decision["value"] not in DECISIONS:
            raise FrameError("decision: invalid authority or value")
        _strings(decision["supporting_cells"], "decision.supporting_cells", nonempty=False)
        _strings(decision["guards"], "decision.guards", nonempty=False)
        if not set(decision["supporting_cells"]) <= cell_ids:
            raise FrameError("decision: dangling supporting cell")
    history = frame["history"]
    _keys(history, {"prefix", "commitment"}, set(), "history")
    if any(not isinstance(history[k], str) or not history[k] for k in history):
        raise FrameError("history: empty field")
    return deepcopy(frame)


def canonical(frame: Any) -> dict[str, Any]:
    """Validate and normalize a frame for exact producer/consumer comparison."""
    f = validate(frame)
    f["cells"] = sorted(f["cells"], key=lambda x: x["id"])
    for cell in f["cells"]:
        cell["derivation_roots"] = sorted(cell["derivation_roots"])
    f["obligations"] = sorted(f["obligations"], key=lambda x: x["id"])
    contexts = [f["context"]] + [edge["context"] for edge in f["corridors"]]
    for context in contexts:
        context["rule_windows"] = sorted(
            context["rule_windows"],
            key=lambda x: (x["authority"], x["version"], x["not_before"], x["not_after"]),
        )
    for edge in f["corridors"]:
        edge["carrying_domains"] = sorted(edge["carrying_domains"])
        edge["fresh_obligations"] = sorted(edge["fresh_obligations"])
        edge["clauses"] = sorted(edge["clauses"], key=lambda x: x["id"])
    if f["decision"] is not None:
        f["decision"]["supporting_cells"] = sorted(f["decision"]["supporting_cells"])
        f["decision"]["guards"] = sorted(f["decision"]["guards"])
    return f


def encode(frame: Any) -> str:
    """Encode a valid frame in deterministic JSON."""
    return json.dumps(canonical(frame), ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def decode(payload: str) -> dict[str, Any]:
    try:
        parsed = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise FrameError(f"invalid JSON: {exc.msg}") from exc
    return canonical(parsed)


def round_trip(frame: Any) -> bool:
    """Check producer encoding and consumer decoding agree exactly."""
    return decode(encode(frame)) == canonical(frame)


def equivalent(expected: Any, payload: str) -> bool:
    """Check that a consumer's frame is exactly the producer's frame."""
    return decode(payload) == canonical(expected)


def compose(left: Any, right: Any) -> dict[str, Any]:
    """Compose two adjacent finite route frames, rejecting identity conflicts."""
    a, b = canonical(left), canonical(right)
    if a["request"] != b["request"]:
        raise FrameError("compose: request mismatch")
    if a["corridors"] and b["corridors"] and a["corridors"][-1]["destination"] != b["corridors"][0]["source"]:
        raise FrameError("compose: endpoint mismatch")
    by_cell = {x["id"]: x for x in a["cells"]}
    for cell in b["cells"]:
        if cell["id"] in by_cell and by_cell[cell["id"]] != cell:
            raise FrameError(f"compose: conflicting cell {cell['id']}")
        by_cell[cell["id"]] = cell
    by_obligation = {x["id"]: x for x in a["obligations"]}
    for obligation in b["obligations"]:
        if obligation["id"] in by_obligation and by_obligation[obligation["id"]] != obligation:
            raise FrameError(f"compose: conflicting obligation {obligation['id']}")
        by_obligation[obligation["id"]] = obligation
    out = deepcopy(a)
    out["cells"] = list(by_cell.values())
    out["obligations"] = list(by_obligation.values())
    out["corridors"] = a["corridors"] + b["corridors"]
    out["history"] = b["history"]
    out["decision"] = b["decision"] if b["decision"] is not None else a["decision"]
    return canonical(out)


def fixture() -> dict[str, Any]:
    """A positive frame exercising all fields in the bounded checker."""
    request = {"id": "req-1", "act": "license-transfer", "subject": "entity-1",
               "purpose": "settlement", "use_time": "2026-09-06T00:00:00Z"}
    context = {"request_id": "req-1", "authority_snapshot": "snap-A-1",
               "rule_windows": [{"authority": "A", "version": "rule-7", "not_before": "2026-01-01",
                                  "not_after": "2027-01-01"}]}
    cells = [
        {"id": "cell-app", "issuer": "A", "jurisdiction": "A", "domain": "Licensing",
         "applicability": "App", "grade": "C", "rule_version": "rule-7", "issue_anchor": "A:ev:1",
         "valid_from": "2026-01-01", "valid_until": "2026-12-31", "derivation_roots": ["root-1"],
         "request_id": "req-1", "act": "license-transfer", "subject": "entity-1", "purpose": "settlement"},
        {"id": "cell-na", "issuer": "A", "jurisdiction": "A", "domain": "Tax", "applicability": "NA",
         "rule_version": "rule-7", "issue_anchor": "A:ev:2", "valid_from": "2026-01-01", "valid_until": "2026-12-31",
         "derivation_roots": ["root-2"], "request_id": "req-1", "act": "license-transfer", "subject": "entity-1", "purpose": "settlement"},
        {"id": "cell-ex", "issuer": "A", "jurisdiction": "A", "domain": "Insurance", "applicability": "E",
         "rule_version": "rule-7", "issue_anchor": "A:ev:3", "valid_from": "2026-01-01", "valid_until": "2026-12-31",
         "derivation_roots": ["root-3"], "request_id": "req-1", "act": "license-transfer", "subject": "entity-1", "purpose": "settlement",
         "exemption_authority": "A-tribunal", "exemption_scope": "insurance:transfer"},
    ]
    edge = {"id": "edge-A-B", "source": "A", "destination": "B", "context":
            {"request_id": "req-1", "authority_snapshot": "snap-B-1", "rule_windows":
             [{"authority": "B", "version": "rule-9", "not_before": "2026-01-01", "not_after": "2027-01-01"}]},
            "carrying_domains": ["Licensing"], "maps": {"Licensing": {"C": "P", "P": "N", "N": "N"}},
            "fresh_obligations": ["obl-report"],
            "clauses": [{"id": "clause-local", "authority": "B", "domain": "Licensing",
                         "scope": "license:transfer", "instrument": "B-instrument-1"}]}
    obligation = {"id": "obl-report", "owner": "B", "beneficiary": "entity-1", "unit": "report",
                  "quantity": "1", "trigger": "license-issued", "deadline": "2026-10-01",
                  "status": "outstanding", "request_id": "req-1", "context_snapshot": "snap-B-1"}
    return {"schema": SCHEMA, "request": request, "context": context, "cells": cells,
            "corridors": [edge], "obligations": [obligation],
            "decision": {"authority": "B", "value": "Await", "supporting_cells": ["cell-app"],
                          "guards": ["revocation:cell-app"]},
            "history": {"prefix": "hist-0", "commitment": "commit-0"}}


def run_self_test() -> dict[str, Any]:
    base = fixture()
    checks: dict[str, bool] = {"positive_round_trip": round_trip(base)}
    if not checks["positive_round_trip"]:
        raise FrameError("positive round trip failed")
    mutations = {
        "missing_applicability_provenance": (lambda f: f["cells"][1].pop("applicability")),
        "changed_rule_version": (lambda f: f["cells"][0].__setitem__("rule_version", "rule-8")),
        "changed_exemption_scope": (lambda f: f["cells"][2].__setitem__("exemption_scope", "other")),
        "changed_obligation_beneficiary": (lambda f: f["obligations"][0].__setitem__("beneficiary", "other")),
        "dropped_obligation": (lambda f: f["obligations"].clear()),
    }
    for name, mutate in mutations.items():
        altered = deepcopy(base)
        mutate(altered)
        try:
            same = equivalent(base, encode(altered))
        except FrameError:
            checks[name] = True
        else:
            checks[name] = not same
    # An unordered collection has one encoding, but changed validity stays visible.
    windows = deepcopy(base)
    contexts = [windows["context"], windows["corridors"][0]["context"]]
    for context in contexts:
        extra = dict(context["rule_windows"][0], version="another-rule")
        context["rule_windows"].append(extra)
    reordered = deepcopy(windows)
    for context in [reordered["context"], reordered["corridors"][0]["context"]]:
        context["rule_windows"].reverse()
    checks["rule_window_permutation"] = encode(windows) == encode(reordered)
    changed_window = deepcopy(windows)
    changed_window["corridors"][0]["context"]["rule_windows"][1]["not_after"] = "2027-02-01"
    checks["changed_rule_window"] = encode(windows) != encode(changed_window)
    # Associativity check over three adjacent edges with equal source records.
    second, third = deepcopy(base), deepcopy(base)
    second["corridors"][0]["id"] = "edge-B-C"
    second["corridors"][0]["source"], second["corridors"][0]["destination"] = "B", "C"
    second["corridors"][0]["fresh_obligations"] = []
    third["corridors"][0]["id"] = "edge-C-D"
    third["corridors"][0]["source"], third["corridors"][0]["destination"] = "C", "D"
    third["corridors"][0]["fresh_obligations"] = []
    left = compose(compose(base, second), third)
    right = compose(base, compose(second, third))
    checks["associative_route_composition"] = encode(left) == encode(right)
    if not all(checks.values()):
        raise FrameError(f"self-test failure: {checks}")
    return {"schema": SCHEMA, "passed": True, "checks": checks}


def main(argv: list[str]) -> int:
    if len(argv) == 1:
        result = run_self_test()
    elif len(argv) == 2:
        path = Path(argv[1])
        result = {"schema": SCHEMA, "passed": round_trip(json.loads(path.read_text()))}
    else:
        print(f"usage: {argv[0]} [FRAME.json]", file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
