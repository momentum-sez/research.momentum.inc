"""Finite evidence-planning algorithms for the declared synthetic instances."""

from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
import math
import time


class InvalidPlan(ValueError):
    """The selected records do not establish feasibility."""


def require(condition, message):
    if not condition:
        raise InvalidPlan(message)


@dataclass(frozen=True)
class Offer:
    name: str
    cost: int
    coverage: int
    available: bool = True
    support_version: str = "original"


@dataclass(frozen=True)
class CoverageInstance:
    name: str
    required: int
    offers: tuple[Offer, ...]
    baseline: int = 0
    guard_key: str = "fixed-local-permit"


@dataclass
class Result:
    status: str
    cost: int | None = None
    selected: tuple[str, ...] = ()
    derivations: tuple[str, ...] = ()
    exact_lower_bound: int = 0
    evaluations: int = 0
    details: dict = field(default_factory=dict)


class Budget:
    """Count work before performing it. Time is a secondary stopping rule."""

    def __init__(self, evaluations=None, seconds=None):
        require(evaluations is None or evaluations >= 0, "negative work limit")
        require(seconds is None or seconds >= 0, "negative time limit")
        self.limit = evaluations
        self.deadline = None if seconds is None else time.perf_counter() + seconds
        self.used = 0

    def take(self):
        if self.limit is not None and self.used >= self.limit:
            return False
        if self.deadline is not None and time.perf_counter() >= self.deadline:
            return False
        self.used += 1
        return True


def validate_coverage(instance):
    require(type(instance.required) is int and instance.required >= 0, "invalid target")
    require(instance.required & (instance.required + 1) == 0, "target bits must be contiguous")
    require(type(instance.baseline) is int and instance.baseline >= 0, "invalid baseline")
    require(len({o.name for o in instance.offers}) == len(instance.offers), "duplicate offer name")
    for offer in instance.offers:
        require(type(offer.cost) is int and offer.cost >= 0, "cost must be a nonnegative integer")
        require(type(offer.coverage) is int and offer.coverage >= 0, "invalid coverage")


def verify_coverage(instance, selected, claimed_cost=None):
    """Reconstruct coverage and cost from the selected offer identifiers."""
    validate_coverage(instance)
    require(len(set(selected)) == len(selected), "repeated purchase")
    offers = {offer.name: offer for offer in instance.offers}
    coverage = instance.baseline
    cost = 0
    for name in selected:
        require(name in offers, "unknown offer")
        offer = offers[name]
        require(offer.available, "unavailable offer")
        coverage |= offer.coverage
        cost += offer.cost
    require(coverage & instance.required == instance.required, "uncovered requirement")
    require(claimed_cost is None or claimed_cost == cost, "incorrect cost")
    return cost


def coverage_dp(instance, *, budget=None, max_states=1 << 20):
    """Find an exact shortest path through strictly increasing coverage masks."""
    validate_coverage(instance)
    budget = budget or Budget()
    count = instance.required + 1
    if count > max_states:
        return Result("unknown", details={"reason": "state limit", "required_states": count})
    costs = [None] * count
    previous = [None] * count
    start = instance.baseline & instance.required
    costs[start] = 0
    complete = True
    for mask in range(start, count):
        if costs[mask] is None:
            continue
        for index, offer in enumerate(instance.offers):
            if not budget.take():
                complete = False
                break
            if not offer.available:
                continue
            next_mask = mask | (offer.coverage & instance.required)
            if next_mask == mask:
                continue
            candidate = costs[mask] + offer.cost
            if costs[next_mask] is None or candidate < costs[next_mask]:
                costs[next_mask] = candidate
                previous[next_mask] = (mask, index)
        if not complete:
            break
    target_cost = costs[instance.required]
    if target_cost is None:
        return Result("infeasible" if complete else "unknown", evaluations=budget.used)
    selected = []
    cursor = instance.required
    while cursor != start:
        parent, index = previous[cursor]
        selected.append(instance.offers[index].name)
        cursor = parent
    selected = tuple(reversed(selected))
    verify_coverage(instance, selected, target_cost)
    return Result("optimal" if complete else "feasible_incomplete", target_cost, selected,
                  exact_lower_bound=target_cost if complete else 0, evaluations=budget.used)


def greedy(instance):
    """Use exact rational ratios. This method does not certify optimality."""
    validate_coverage(instance)
    mask = instance.baseline & instance.required
    selected = []
    evaluations = 0
    while mask != instance.required:
        candidates = []
        for index, offer in enumerate(instance.offers):
            evaluations += 1
            gain = (offer.coverage & instance.required & ~mask).bit_count()
            if offer.available and gain:
                candidates.append((Fraction(offer.cost, gain), offer.cost, index))
        if not candidates:
            # In the independent model, an uncovered bit with no offer is conclusive.
            return Result("infeasible", evaluations=evaluations)
        _, _, index = min(candidates)
        offer = instance.offers[index]
        selected.append(offer.name)
        mask |= offer.coverage & instance.required
    chosen = tuple(selected)
    cost = verify_coverage(instance, chosen)
    return Result("feasible_heuristic", cost, chosen, evaluations=evaluations)


@dataclass
class PrefixCache:
    instance: CoverageInstance
    layers: list[dict[int, tuple[int, tuple[str, ...]]]]


def prefix_dp(instance, cache=None):
    """Reuse unchanged offer-prefix layers, including exact selected purchases."""
    validate_coverage(instance)
    common = 0
    same_basis = cache is not None and (
        instance.required, instance.baseline, instance.guard_key
    ) == (cache.instance.required, cache.instance.baseline, cache.instance.guard_key)
    if same_basis:
        for old, new in zip(cache.instance.offers, instance.offers):
            if old != new:
                break
            common += 1
        layers = cache.layers[:common + 1]
    else:
        layers = [{instance.baseline & instance.required: (0, ())}]
    evaluations = 0
    for offer in instance.offers[common:]:
        layer = dict(layers[-1])
        for mask, (cost, names) in layers[-1].items():
            evaluations += 1
            if not offer.available:
                continue
            next_mask = mask | (offer.coverage & instance.required)
            candidate = (cost + offer.cost, names + (offer.name,))
            if next_mask not in layer or candidate[0] < layer[next_mask][0]:
                layer[next_mask] = candidate
        layers.append(layer)
    details = {"reused_offer_layers": common,
               "recomputed_offer_layers": len(instance.offers) - common,
               "stored_entries": sum(len(layer) for layer in layers)}
    entry = layers[-1].get(instance.required)
    if entry is None:
        result = Result("infeasible", evaluations=evaluations, details=details)
    else:
        cost, selected = entry
        verify_coverage(instance, selected, cost)
        result = Result("optimal", cost, selected, exact_lower_bound=cost,
                        evaluations=evaluations, details=details)
    return result, PrefixCache(instance, layers)


def milp_coverage(instance, *, seconds=5.0, node_limit=None):
    """Validate the integer incumbent without treating numerical bounds as proof."""
    validate_coverage(instance)
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp

    if instance.required & ~instance.baseline == 0:
        return Result("optimal", 0, exact_lower_bound=0)
    if not instance.offers:
        return Result("infeasible")
    require(all(o.cost <= 2 ** 53 for o in instance.offers), "MILP coefficient exceeds exact float integer range")
    bits = [1 << i for i in range(instance.required.bit_length())
            if not (instance.baseline & (1 << i))]
    matrix = np.array([[int(bool(o.coverage & bit)) for o in instance.offers]
                       for bit in bits], dtype=float)
    options = {"time_limit": seconds, "mip_rel_gap": 0.0, "disp": False}
    if node_limit is not None:
        options["node_limit"] = node_limit
    raw = milp(np.array([o.cost for o in instance.offers], dtype=float),
               integrality=np.ones(len(instance.offers)),
               bounds=Bounds(np.zeros(len(instance.offers)),
                             np.array([int(o.available) for o in instance.offers])),
               constraints=LinearConstraint(matrix, np.ones(len(bits)), np.full(len(bits), np.inf)),
               options=options)
    def finite_number(value):
        return float(value) if value is not None and math.isfinite(float(value)) else None
    details = {"solver_status": int(raw.status), "solver_message": str(raw.message),
               "solver_reported_objective": finite_number(raw.fun),
               "solver_reported_dual_bound": finite_number(getattr(raw, "mip_dual_bound", None)),
               "solver_reported_gap": finite_number(getattr(raw, "mip_gap", None)),
               "solver_nodes": int(getattr(raw, "mip_node_count", 0) or 0),
               "optimality_certificate": "none from floating-point solver"}
    if raw.x is None:
        return Result("unknown", details=details)
    require(all(math.isfinite(float(v)) and abs(float(v) - round(float(v))) <= 1e-6
                and round(float(v)) in (0, 1) for v in raw.x), "nonbinary solver candidate")
    selected = tuple(o.name for o, value in zip(instance.offers, raw.x) if round(float(value)) == 1)
    cost = verify_coverage(instance, selected)
    return Result("feasible_solver", cost, selected, details=details)


@dataclass(frozen=True)
class Acquisition:
    name: str
    cost: int
    duties: int = 0
    available: bool = True


@dataclass(frozen=True)
class Witness:
    name: str
    acquisition: str
    grade: int
    current: bool = True


@dataclass(frozen=True)
class Route:
    name: str
    acquisition: str
    table: tuple[int, ...]
    duties: int = 0
    current: bool = True


@dataclass(frozen=True)
class Derivation:
    name: str
    expression: tuple


@dataclass(frozen=True)
class SemanticInstance:
    name: str
    target: int
    acquisitions: tuple[Acquisition, ...]
    witnesses: tuple[Witness, ...]
    routes: tuple[Route, ...]
    derivations: tuple[Derivation, ...]
    conflicts: tuple[tuple[str, str], ...] = ()
    minimum_origins: int = 0
    local_decision: str = "Permit"
    local_cap: int = 3


def verify_semantic(instance, selected, derivations, claimed_cost=None):
    """Check every selected derivation and its exact original support."""
    acquisitions = {a.name: a for a in instance.acquisitions}
    witnesses = {w.name: w for w in instance.witnesses}
    routes = {r.name: r for r in instance.routes}
    catalogue = {d.name: d for d in instance.derivations}
    require(len(acquisitions) == len(instance.acquisitions), "duplicate acquisition")
    require(len(witnesses) == len(instance.witnesses), "duplicate origin")
    require(len(routes) == len(instance.routes), "duplicate route")
    require(len(catalogue) == len(instance.derivations), "duplicate derivation")
    require(len(set(selected)) == len(selected), "repeated acquisition")
    require(len(set(derivations)) == len(derivations), "repeated derivation")
    require(instance.local_decision == "Permit", "local decision is not Permit")
    purchased = set(selected)
    duties = instance.target
    cost = 0
    for name in selected:
        require(name in acquisitions, "unknown acquisition")
        item = acquisitions[name]
        require(type(item.cost) is int and item.cost >= 0, "invalid acquisition cost")
        require(item.available, "unavailable acquisition")
        cost += item.cost
        duties |= item.duties

    def derive(expression):
        kind = expression[0]
        if kind == "leaf":
            require(expression[1] in witnesses, "unknown original witness")
            witness = witnesses[expression[1]]
            require(witness.acquisition in purchased, "missing original purchase")
            require(witness.current, "stale original witness")
            return witness.grade, frozenset((witness.name,)), 0
        if kind == "join":
            left, origins_l, duties_l = derive(expression[1])
            right, origins_r, duties_r = derive(expression[2])
            return left | right, origins_l | origins_r, duties_l | duties_r
        if kind == "transport":
            require(expression[1] in routes, "unknown route")
            route = routes[expression[1]]
            require(route.current, "stale route")
            require(route.acquisition in purchased, "missing transport purchase")
            grade, origins, needed = derive(expression[2])
            require(0 <= grade < len(route.table), "grade outside route table")
            return route.table[grade], origins, needed | route.duties
        raise InvalidPlan("unknown derivation operation")

    grade = 0
    origins = frozenset()
    for name in derivations:
        require(name in catalogue, "unknown derivation")
        derived, leaves, needed = derive(catalogue[name].expression)
        grade |= derived
        origins |= leaves
        duties |= needed
    require(all(not ({left, right} <= origins) for left, right in instance.conflicts), "incompatible original support")
    require(len(origins) >= instance.minimum_origins, "insufficient distinct origins")
    require((grade & instance.local_cap) & duties == duties, "unmet grade or induced duty")
    require(claimed_cost is None or claimed_cost == cost, "incorrect semantic cost")
    return cost


def semantic_search(instance, *, budget=None, seed=None):
    """Enumerate all acquisition and derivation subsets in the finite catalogue."""
    budget = budget or Budget()
    best = None
    if seed is not None:
        selected, derivations = seed
        best = (verify_semantic(instance, selected, derivations), tuple(selected), tuple(derivations))
    size_a = len(instance.acquisitions)
    size_d = len(instance.derivations)
    complete = True
    for mask in range(1 << (size_a + size_d)):
        if not budget.take():
            complete = False
            break
        selected = tuple(a.name for i, a in enumerate(instance.acquisitions) if mask & (1 << i))
        derivations = tuple(d.name for i, d in enumerate(instance.derivations) if mask & (1 << (size_a + i)))
        try:
            cost = verify_semantic(instance, selected, derivations)
        except InvalidPlan:
            continue
        if best is None or cost < best[0]:
            best = (cost, selected, derivations)
    if best is None:
        return Result("infeasible" if complete else "unknown", evaluations=budget.used)
    cost, selected, derivations = best
    verify_semantic(instance, selected, derivations, cost)
    return Result("optimal" if complete else "feasible_incomplete", cost, selected, derivations,
                  exact_lower_bound=cost if complete else 0, evaluations=budget.used,
                  details={"catalogue_pairs": 1 << (size_a + size_d)})
