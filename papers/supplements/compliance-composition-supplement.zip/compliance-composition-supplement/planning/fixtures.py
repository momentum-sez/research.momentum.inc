"""Declared synthetic offers and evidence records. These are not legal facts."""

from dataclasses import replace
import random

from planning import (Acquisition, CoverageInstance, Derivation, Offer, Route,
                      SemanticInstance, Witness)


def coverage_cases():
    cases = [
        CoverageInstance("recognition_complement", 3, (
            Offer("recognized-a", 3, 1), Offer("recognized-b", 4, 2), Offer("full", 9, 3))),
        CoverageInstance("greedy_gap", 7, (
            Offer("tempting-pair", 3, 3), Offer("complete", 5, 7), Offer("last", 3, 4))),
        CoverageInstance("uncovered", 3, (Offer("only-a", 1, 1),)),
        CoverageInstance("existing_and_free", 7, (
            Offer("free-b", 0, 2), Offer("c", 2, 4)), baseline=1),
    ]
    for domains, count, seed in ((6, 12, 7), (9, 18, 19), (12, 24, 31)):
        rng = random.Random(seed)
        offers = []
        for index in range(count - domains):
            mask = sum(1 << bit for bit in range(domains) if rng.random() < 0.35)
            offers.append(Offer(f"random-{index}", rng.randint(1, 15), mask))
        offers.extend(Offer(f"single-{bit}", rng.randint(8, 20), 1 << bit)
                      for bit in range(domains))
        cases.append(CoverageInstance(f"seed{seed}_d{domains}_m{count}", (1 << domains) - 1, tuple(offers)))
    return cases


def semantic_cases():
    leaf_a = ("leaf", "origin-a")
    leaf_b = ("leaf", "origin-b")
    direct = SemanticInstance("joint_transport", 3,
        (Acquisition("buy-a", 1), Acquisition("buy-b", 1), Acquisition("route", 1)),
        (Witness("origin-a", "buy-a", 1), Witness("origin-b", "buy-b", 2)),
        (Route("nonjoin", "route", (0, 0, 0, 3)),),
        (Derivation("joint", ("transport", "nonjoin", ("join", leaf_a, leaf_b))),
         Derivation("separate-a", ("transport", "nonjoin", leaf_a)),
         Derivation("separate-b", ("transport", "nonjoin", leaf_b))))
    conflict = SemanticInstance("conflicting_support", 3,
        (Acquisition("buy-a", 1), Acquisition("buy-b", 1), Acquisition("buy-full", 5)),
        (Witness("origin-a", "buy-a", 1), Witness("origin-b", "buy-b", 2),
         Witness("origin-full", "buy-full", 3)), (),
        (Derivation("a", leaf_a), Derivation("b", leaf_b), Derivation("full", ("leaf", "origin-full"))),
        conflicts=(("origin-a", "origin-b"),))
    duplicate = SemanticInstance("duplicate_origins", 1,
        (Acquisition("buy-a", 1), Acquisition("route-1", 0), Acquisition("route-2", 0),
         Acquisition("buy-b", 4)),
        (Witness("origin-a", "buy-a", 1), Witness("origin-b", "buy-b", 1)),
        (Route("identity-1", "route-1", (0, 1, 2, 3)), Route("identity-2", "route-2", (0, 1, 2, 3))),
        (Derivation("path-1", ("transport", "identity-1", leaf_a)),
         Derivation("path-2", ("transport", "identity-2", leaf_a)), Derivation("independent", leaf_b)),
        minimum_origins=2)
    duties = SemanticInstance("induced_duties", 1,
        (Acquisition("harbor", 1, duties=2), Acquisition("duty-b", 4), Acquisition("direct", 3)),
        (Witness("origin-a", "harbor", 1), Witness("origin-b", "duty-b", 2),
         Witness("direct-a", "direct", 1)), (),
        (Derivation("harbor-a", leaf_a), Derivation("duty-b", leaf_b),
         Derivation("direct-a", ("leaf", "direct-a"))))
    return [
        (direct, 3),
        (replace(direct, name="atomic_transport_only", derivations=direct.derivations[1:]), None),
        (conflict, 5),
        (duplicate, 5),
        (replace(duplicate, name="duplicate_only", derivations=duplicate.derivations[:2]), None),
        (replace(conflict, name="local_refuse", local_decision="Refuse"), None),
        (replace(conflict, name="local_await", local_decision="Await"), None),
        (replace(conflict, name="local_cap", local_cap=1), None),
        (duties, 3),
        (replace(direct, name="revoked_origin", witnesses=(replace(direct.witnesses[0], current=False),
                                                         direct.witnesses[1])), None),
    ]


def update_sequence():
    initial = next(i for i in coverage_cases() if i.name == "seed19_d9_m18")
    # A late, cheap complete offer makes the affected suffix measurable.
    initial = replace(initial, name="update_initial", offers=initial.offers + (Offer("late-complete", 7, initial.required),))
    revoked = replace(initial, name="update_revocation", offers=initial.offers[:-1] + (
        replace(initial.offers[-1], available=False, support_version="revoked"),))
    cheaper = replace(revoked, name="update_cheaper_offer", offers=revoked.offers + (
        Offer("new-complete", 2, initial.required),))
    return [initial, revoked, cheaper]
