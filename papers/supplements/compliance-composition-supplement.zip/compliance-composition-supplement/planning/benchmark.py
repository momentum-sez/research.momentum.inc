"""Run the fixed planning cases in fresh processes and record measured results."""

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import platform
import resource
import statistics
import subprocess
import sys
import time
import tracemalloc

from fixtures import coverage_cases, semantic_cases, update_sequence
from planning import (Budget, coverage_dp, greedy, milp_coverage, prefix_dp,
                      require, semantic_search, verify_coverage, verify_semantic)


ROOT = Path(__file__).resolve().parent


def digest(value):
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def worker(spec):
    group, index, method = spec["group"], spec["index"], spec["method"]
    # Imports and cache construction occur before the measured interval.
    if method == "milp":
        import scipy.optimize
    if group == "coverage":
        instance = coverage_cases()[index]
        functions = {"exact_dp": coverage_dp, "greedy": greedy, "milp": milp_coverage,
                     "prefix_full": lambda item: prefix_dp(item)[0]}
        operation = lambda: functions[method](instance)
    elif group == "semantic":
        instance = semantic_cases()[index][0]
        operation = lambda: semantic_search(instance)
    elif group == "resource":
        instance = semantic_cases()[0][0]
        limit = 0 if index == 0 else 16
        operation = lambda: semantic_search(instance, budget=Budget(evaluations=limit))
    else:
        sequence = update_sequence()
        instance = sequence[index]
        cache = None
        if method == "prefix_incremental":
            for earlier in sequence[:index]:
                _, cache = prefix_dp(earlier, cache)
        operation = lambda: prefix_dp(instance, cache)[0]
    rss_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    start = time.perf_counter_ns()
    result = operation()
    elapsed = (time.perf_counter_ns() - start) / 1e9
    # A separate measured call avoids tracemalloc distortion of the timing.
    tracemalloc.start()
    memory_result = operation()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    require((result.status, result.cost, result.selected, result.derivations) ==
            (memory_result.status, memory_result.cost, memory_result.selected, memory_result.derivations),
            "timing and memory runs disagree")
    if result.cost is not None:
        if group in ("semantic", "resource"):
            verify_semantic(instance, result.selected, result.derivations, result.cost)
        else:
            verify_coverage(instance, result.selected, result.cost)
    rss_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    rss_scale = 1 if sys.platform == "darwin" else 1024
    return {"group": group, "case": instance.name, "method": method,
            "instance_sha256": digest(asdict(instance)), "result": asdict(result),
            "elapsed_seconds": elapsed, "peak_python_allocation_bytes": peak,
            "peak_process_rss_bytes": rss_after * rss_scale,
            "process_rss_highwater_before_bytes": rss_before * rss_scale,
            "incumbent_exactly_checked": result.cost is not None}


def run_sample(spec):
    command = [sys.executable, "-B", str(Path(__file__).resolve()), "--worker", json.dumps(spec)]
    output = subprocess.run(command, text=True, capture_output=True, check=True, timeout=30)
    require(not output.stderr.strip(), "worker wrote unexpected stderr: " + output.stderr)
    return json.loads(output.stdout)


def run_benchmark():
    import scipy
    specs = [{"group": "coverage", "index": index, "method": method}
             for index in range(len(coverage_cases()))
             for method in ("exact_dp", "prefix_full", "greedy", "milp")]
    specs += [{"group": "semantic", "index": index, "method": "exact_search"}
              for index in range(len(semantic_cases()))]
    specs += [{"group": "resource", "index": index, "method": "bounded_search"}
              for index in range(2)]
    specs += [{"group": "update", "index": index, "method": method}
              for index in (1, 2) for method in ("prefix_full", "prefix_incremental")]
    rows = []
    for spec in specs:
        samples = [run_sample(spec) for _ in range(3)]
        row = samples[0]
        require(all((sample["result"], sample["instance_sha256"]) ==
                    (row["result"], row["instance_sha256"]) for sample in samples),
                "repeated runs disagree")
        row["samples"] = [{k: sample[k] for k in (
            "elapsed_seconds", "peak_python_allocation_bytes", "peak_process_rss_bytes",
            "process_rss_highwater_before_bytes")} for sample in samples]
        row["elapsed_seconds"] = statistics.median(s["elapsed_seconds"] for s in samples)
        row["peak_python_allocation_bytes"] = max(s["peak_python_allocation_bytes"] for s in samples)
        row["peak_process_rss_bytes"] = max(s["peak_process_rss_bytes"] for s in samples)
        rows.append(row)
        print(f"{row['group']} {row['case']} {row['method']}: {row['result']['status']} {row['result']['cost']}", flush=True)
    exact = {row["case"]: row["result"]["cost"] for row in rows
             if row["group"] == "coverage" and row["method"] == "exact_dp"}
    for row in rows:
        if row["group"] == "coverage":
            optimum = exact[row["case"]]
        elif row["group"] == "update":
            optimum = next(other["result"]["cost"] for other in rows
                           if other["group"] == "update" and other["case"] == row["case"]
                           and other["method"] == "prefix_full")
        elif row["group"] == "semantic":
            optimum = next(expected for instance, expected in semantic_cases() if instance.name == row["case"])
            require(row["result"]["cost"] == optimum, "semantic fixture result differs")
        else:
            optimum = 3
        row["reference_optimum"] = optimum
        cost = row["result"]["cost"]
        row["absolute_optimum_gap"] = cost - optimum if cost is not None and optimum is not None else None
        row["relative_optimum_gap"] = ((cost - optimum) / optimum if optimum else 0.0
            ) if cost is not None and optimum is not None else None
        row["matches_exact_reference"] = (cost == optimum if optimum is not None
                                           else row["result"]["status"] == "infeasible")
    report = {"python": sys.version, "platform": platform.platform(), "scipy": scipy.__version__,
              "repetitions": 3, "rows": rows,
              "measurement": "Median timed call in three fresh processes. Separate second call records Python allocations. Process RSS includes imports and both calls.",
              "source_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in sorted(ROOT.glob("*.py"))}}
    (ROOT / "benchmark_results.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    columns = ["group", "case", "method", "status", "cost", "reference_optimum", "absolute_optimum_gap",
               "elapsed_seconds", "peak_python_allocation_bytes", "peak_process_rss_bytes", "evaluations",
               "reused_offer_layers", "recomputed_offer_layers"]
    import csv
    with (ROOT / "benchmark_results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            values = {name: row.get(name) for name in columns}
            values.update({"status": row["result"]["status"], "cost": row["result"]["cost"],
                           "evaluations": row["result"]["evaluations"],
                           "reused_offer_layers": row["result"]["details"].get("reused_offer_layers"),
                           "recomputed_offer_layers": row["result"]["details"].get("recomputed_offer_layers")})
            writer.writerow(values)
    write_summary(report)


def write_summary(report):
    rows = report["rows"]
    lines = ["Synthetic evidence-planning benchmark", "",
             f"Python {platform.python_version()}; SciPy {report['scipy']}; {report['platform']}.",
             "Three fresh-process samples per row. The table reports median elapsed time.",
             "Time excludes module imports and prior incremental cache construction.",
             "Python allocation peaks exclude native solver allocations.",
             "Process RSS includes imports, timing, and memory calls. It is an absolute process high-water mark.",
             "Cached prefixes remain resident in incremental process RSS.",
             "Every incumbent passes an independent exact integer feasibility and cost check.",
             "Numerical solver status and dual bounds remain separate from exact reference results.", "",
             "case | method | status | cost | exact gap | median ms | Python peak bytes | process RSS bytes"]
    for row in rows:
        lines.append(f"{row['case']} | {row['method']} | {row['result']['status']} | {row['result']['cost']} | "
                     f"{row['absolute_optimum_gap']} | {row['elapsed_seconds'] * 1000:.3f} | "
                     f"{row['peak_python_allocation_bytes']} | {row['peak_process_rss_bytes']}")
    lines += ["", "Incremental comparisons:"]
    for name in ("update_revocation", "update_cheaper_offer"):
        full = next(r for r in rows if r["group"] == "update" and r["case"] == name and r["method"] == "prefix_full")
        incremental = next(r for r in rows if r["group"] == "update" and r["case"] == name and r["method"] == "prefix_incremental")
        details = incremental["result"]["details"]
        lines.append(f"{name}: full {full['result']['evaluations']} transitions; incremental "
                     f"{incremental['result']['evaluations']} transitions; reused {details['reused_offer_layers']} offer layers; "
                     f"recomputed {details['recomputed_offer_layers']} layer; full {full['elapsed_seconds'] * 1000:.3f} ms; "
                     f"incremental {incremental['elapsed_seconds'] * 1000:.3f} ms.")
    lines += ["", "Manuscript paragraph:",
              "The deterministic synthetic set contains seven coverage instances and ten semantic fixtures. "
              "Exact dynamic programming supplies coverage optima. Finite enumeration checks the semantic fixtures. "
              "All returned incumbents pass exact integer feasibility and cost checks. "
              "The integer-programming incumbents match the dynamic-programming reference costs. "
              "The constructed greedy example costs 6 against an optimum of 5. "
              "The joint-transport fixture reaches its target at cost 3, while its separate-transport catalogue is infeasible. "
              "Revocation and a cheaper new offer preserve agreement between incremental and complete recomputation. "
              "A zero-work limit returns Unknown. A 16-pair limit returns Feasible-incomplete after finding a checked incumbent. "
              "These measurements concern the declared finite instances and provide no deployment performance claim.", ""]
    (ROOT / "benchmark_report.txt").write_text("\n".join(lines))


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--worker":
        print(json.dumps(worker(json.loads(sys.argv[2])), sort_keys=True))
    else:
        run_benchmark()
