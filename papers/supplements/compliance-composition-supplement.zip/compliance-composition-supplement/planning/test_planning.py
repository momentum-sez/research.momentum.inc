"""Check planning claims against independent finite enumeration and bad plans."""

from dataclasses import replace
import ast
from pathlib import Path
import random
import unittest

from fixtures import coverage_cases, semantic_cases, update_sequence
from planning import (Budget, CoverageInstance, InvalidPlan, Offer, coverage_dp,
                      greedy, milp_coverage, prefix_dp, semantic_search,
                      verify_coverage, verify_semantic)


def enumerate_coverage(instance):
    best = None
    for mask in range(1 << len(instance.offers)):
        names = tuple(o.name for i, o in enumerate(instance.offers) if mask & (1 << i))
        try:
            cost = verify_coverage(instance, names)
        except InvalidPlan:
            continue
        best = cost if best is None else min(best, cost)
    return best


class PlanningTests(unittest.TestCase):
    def test_no_optimization_sensitive_assertions(self):
        for name in ("planning.py", "fixtures.py", "benchmark.py"):
            tree = ast.parse(Path(__file__).with_name(name).read_text())
            self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)), name)

    def test_dp_matches_independent_enumeration(self):
        rng = random.Random(20260905)
        for case in range(40):
            required = (1 << rng.randint(1, 5)) - 1
            instance = CoverageInstance(str(case), required, tuple(
                Offer(str(i), rng.randint(0, 12), rng.randint(0, required), rng.random() > 0.1)
                for i in range(rng.randint(0, 9))), baseline=rng.randint(0, required))
            expected = enumerate_coverage(instance)
            actual = coverage_dp(instance)
            self.assertEqual(actual.cost, expected, case)
            self.assertEqual(actual.status, "optimal" if expected is not None else "infeasible")
            if actual.cost is not None:
                self.assertEqual(verify_coverage(instance, actual.selected, actual.cost), expected)

    def test_greedy_has_a_measured_gap(self):
        instance = next(i for i in coverage_cases() if i.name == "greedy_gap")
        self.assertEqual(coverage_dp(instance).cost, 5)
        self.assertEqual(greedy(instance).cost, 6)
        self.assertEqual(greedy(instance).status, "feasible_heuristic")

    def test_semantic_fixture_optima(self):
        for instance, expected in semantic_cases():
            with self.subTest(instance=instance.name):
                actual = semantic_search(instance)
                self.assertEqual(actual.cost, expected)
                self.assertEqual(actual.status, "optimal" if expected is not None else "infeasible")
                if expected is not None:
                    self.assertEqual(verify_semantic(instance, actual.selected, actual.derivations, actual.cost), expected)

    def test_semantic_checker_rejects_specific_invalid_incumbents(self):
        fixtures = {i.name: i for i, _ in semantic_cases()}
        bad = [
            ("joint_transport", ("buy-a", "buy-b", "route"), ("separate-a", "separate-b")),
            ("conflicting_support", ("buy-a", "buy-b"), ("a", "b")),
            ("duplicate_origins", ("buy-a", "route-1", "route-2"), ("path-1", "path-2")),
            ("local_refuse", ("buy-full",), ("full",)),
            ("local_cap", ("buy-full",), ("full",)),
            ("induced_duties", ("harbor",), ("harbor-a",)),
            ("revoked_origin", ("buy-a", "buy-b", "route"), ("joint",)),
        ]
        for name, selected, derivations in bad:
            with self.subTest(instance=name), self.assertRaises(InvalidPlan):
                verify_semantic(fixtures[name], selected, derivations)

    def test_shared_purchase_paid_once(self):
        instance = next(i for i, _ in semantic_cases() if i.name == "duplicate_origins")
        self.assertEqual(verify_semantic(instance, ("buy-a", "route-1", "route-2", "buy-b"),
                                         ("path-1", "path-2", "independent")), 5)
        with self.assertRaises(InvalidPlan):
            verify_semantic(instance, ("buy-a", "route-1", "buy-b"), ("path-1", "independent"), 4)

    def test_resource_limits_do_not_claim_infeasibility(self):
        instance = semantic_cases()[0][0]
        unknown = semantic_search(instance, budget=Budget(evaluations=0))
        incomplete = semantic_search(instance, budget=Budget(evaluations=0),
            seed=(("buy-a", "buy-b", "route"), ("joint",)))
        self.assertEqual((unknown.status, unknown.cost, unknown.evaluations), ("unknown", None, 0))
        self.assertEqual((incomplete.status, incomplete.cost, incomplete.exact_lower_bound),
                         ("feasible_incomplete", 3, 0))
        found = semantic_search(instance, budget=Budget(evaluations=16))
        self.assertEqual((found.status, found.cost, found.evaluations, found.exact_lower_bound),
                         ("feasible_incomplete", 3, 16, 0))
        self.assertEqual(semantic_search(instance, budget=Budget(seconds=0)).status, "unknown")
        self.assertEqual(coverage_dp(coverage_cases()[0], budget=Budget(evaluations=0)).status, "unknown")
        self.assertEqual(coverage_dp(coverage_cases()[0], max_states=1).status, "unknown")
        with self.assertRaises(InvalidPlan):
            semantic_search(instance, budget=Budget(evaluations=0), seed=(("buy-a",), ("joint",)))

    def test_incremental_reuses_only_unchanged_prefix(self):
        cache = None
        results = []
        for instance in update_sequence():
            result, cache = prefix_dp(instance, cache)
            full, _ = prefix_dp(instance)
            self.assertEqual(result.cost, full.cost)
            self.assertEqual(result.cost, coverage_dp(instance).cost)
            results.append(result)
        self.assertEqual(results[0].cost, 7)
        self.assertGreater(results[1].cost, 7)
        self.assertEqual(results[2].cost, 2)
        self.assertEqual(results[1].details["recomputed_offer_layers"], 1)
        self.assertEqual(results[2].details["recomputed_offer_layers"], 1)
        self.assertGreater(results[2].details["reused_offer_layers"], 0)
        changed_guard = replace(cache.instance, guard_key="changed-local-context")
        result, _ = prefix_dp(changed_guard, cache)
        self.assertEqual(result.details["reused_offer_layers"], 0)

    def test_prefix_handles_cost_change_deletion_and_target_change(self):
        initial = coverage_cases()[0]
        _, cache = prefix_dp(initial)
        for updated in (replace(initial, offers=initial.offers[1:]),
                        replace(initial, offers=(replace(initial.offers[0], cost=1),) + initial.offers[1:]),
                        replace(initial, required=1)):
            actual, _ = prefix_dp(updated, cache)
            self.assertEqual(actual.cost, enumerate_coverage(updated))
            self.assertEqual(actual.details["reused_offer_layers"], 0)

    def test_solver_incumbents_match_exact_dp_without_solver_certification(self):
        for instance in coverage_cases():
            with self.subTest(instance=instance.name):
                actual = milp_coverage(instance)
                exact = coverage_dp(instance)
                self.assertEqual(actual.cost, exact.cost)
                if actual.cost is not None:
                    self.assertEqual(verify_coverage(instance, actual.selected, actual.cost), exact.cost)
                    self.assertEqual(actual.status, "feasible_solver")
                    self.assertEqual(actual.exact_lower_bound, 0)
                else:
                    self.assertEqual(actual.status, "unknown")

    def test_exact_checker_rejects_duplicate_unavailable_and_wrong_cost(self):
        instance = coverage_cases()[0]
        for names, cost in ((("full", "full"), 18), (("full",), 8), (("unknown",), 9)):
            with self.assertRaises(InvalidPlan):
                verify_coverage(instance, names, cost)
        unavailable = replace(instance, offers=(replace(instance.offers[2], available=False),))
        with self.assertRaises(InvalidPlan):
            verify_coverage(unavailable, ("full",))


if __name__ == "__main__":
    unittest.main(verbosity=2)
