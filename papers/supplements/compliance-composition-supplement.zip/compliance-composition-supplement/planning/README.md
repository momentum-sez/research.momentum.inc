# Finite evidence planning

This directory contains synthetic planning fixtures and a reproducible benchmark.
It contains no live authority records or legal determinations.

Run from this directory:

```sh
PLANNING_PYTHON=/opt/homebrew/opt/python@3.14/bin/python3.14
PYTHONDONTWRITEBYTECODE=1 "$PLANNING_PYTHON" -B -m unittest -v test_planning
PYTHONDONTWRITEBYTECODE=1 "$PLANNING_PYTHON" -B -O -m unittest -v test_planning
PYTHONDONTWRITEBYTECODE=1 "$PLANNING_PYTHON" -B benchmark.py
```

The installed runtime provides Python 3.14.6 and SciPy 1.17.1. No package installation is required in that runtime.
The explicit interpreter matters. The shell resolves `python3` differently in this directory and the repository root.
SciPy is required for the integer-programming tests and benchmark rows. Missing SciPy causes a visible failure.

`planning.py` implements exact coverage search, weighted greedy selection, offer-prefix dynamic programming, and finite semantic search.
It also calls ordinary binary integer programming through `scipy.optimize.milp`.
`fixtures.py` defines the complete finite catalogues and deterministic coverage generators.
`test_planning.py` compares exact coverage results against independent subset enumeration and rejects specific invalid plans.
`benchmark.py` writes JSON, CSV, and a plain-text report inside this directory.

The coverage methods apply to independently payable, jointly admissible offers with fixed requirements and current local permission.
They do not encode arbitrary authority predicates.
The semantic fixtures retain original support, explicit transport expressions, purchase prerequisites, conflicts, local decisions, and induced duties.
Their grades use a Boolean lattice. A transport acts on the entire supplied expression.
The exact semantic search enumerates acquisition and derivation subsets from the declared finite catalogue.
Its result concerns that catalogue and its fixed synthetic context.

Every cost is a nonnegative integer. The verifiers reconstruct costs from purchase identifiers.
Repeated transport retains the original witness identifier. Shared acquisitions incur one charge.
The semantic fixtures treat an unresolved local decision as lacking executable feasibility.
The search does not generate a conditional legal permission.

An incomplete exact search reports `unknown` or `feasible_incomplete`.
Its exact lower bound is zero. An exhaustive optimum reports its exact cost as the lower bound.
Greedy reports `feasible_heuristic` and makes no exact optimality claim.
MILP reports `feasible_solver` only after exact incumbent validation.
Its floating-point status, objective, dual bound, and gap are recorded separately.
A numerical infeasibility status alone remains `unknown` in the wrapper.
The benchmark compares solver results with independent exact reference results.

The prefix cache stores all offer-prefix layers for these small cases.
This trades additional memory for suffix recomputation.
An offer's price, availability, or support version changes its cache identity.
A changed target, baseline, or relevant local guard invalidates all prefix layers.
New offers extend the cache. Revocation recomputes the affected suffix.

Timing uses three fresh processes per row and excludes imports and prior cache construction.
A separate second call measures peak Python allocations without distorting the timed call.
Process peak RSS includes imports, existing caches, timing, and allocation-measurement calls.
Python allocation peaks exclude native solver memory.
Measurements depend on the recorded machine and concurrent workload.

The primary API reference is the [SciPy MILP documentation](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html).
The implementation also checks the installed function signature and documentation.
SciPy converts model arrays to double precision. The wrapper therefore validates returned purchase selections with integer arithmetic.
