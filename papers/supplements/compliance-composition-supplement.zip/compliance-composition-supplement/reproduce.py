"""Reproduce the packaged finite evidence in a new local output directory."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest(root):
    entries = []
    for line in (root / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = (root / name).resolve()
        if not path.is_relative_to(root) or sha256(path) != expected:
            raise RuntimeError("Manifest mismatch: " + name)
        entries.append({"path": name, "sha256": expected})
    return entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="fresh-reproduction")
    parser.add_argument("--coqc", default="coqc")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    output = (root / args.output).resolve()
    if output.parent != root or output.exists():
        parser.error("Output must be a new direct child of the extracted supplement directory.")
    manifest = verify_manifest(root)
    output.mkdir(parents=True)
    logs = output / "logs"
    logs.mkdir()
    shutil.copytree(root / "scripts", output / "scripts")
    shutil.copytree(root / "planning", output / "planning")
    shutil.copytree(root / "proofs", output / "proofs")
    shutil.copy2(root / "assumptions.v", output / "proofs" / "assumptions.v")
    record = {
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Fresh extraction reproduction of the packaged finite evidence.",
        "historical_measurements_preserved": True,
        "historical_timing_comparison": "Excluded; fresh timings are environment-dependent measurements.",
        "interpreter": sys.executable,
        "interpreter_sha256": sha256(Path(sys.executable)),
        "coqc_resolved": shutil.which(args.coqc),
        "coqc_sha256": sha256(Path(shutil.which(args.coqc))) if shutil.which(args.coqc) else None,
        "python": sys.version,
        "platform": platform.platform(),
        "manifest_sha256": sha256(root / "SHA256SUMS"),
        "verified_members": manifest,
        "commands": [],
        "status": "incomplete",
    }
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    environment.pop("PYTHONOPTIMIZE", None)

    def run(name, command, cwd):
        start = time.monotonic()
        returncode = None
        error = None
        try:
            result = subprocess.run(command, cwd=cwd, env=environment,
                                    text=True, capture_output=True, timeout=300)
            returncode, out, err = result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired as exception:
            out = exception.stdout or ""
            err = exception.stderr or ""
            out = out.decode(errors="replace") if isinstance(out, bytes) else out
            err = err.decode(errors="replace") if isinstance(err, bytes) else err
            error = "Command exceeded 300 seconds."
        except OSError as exception:
            out, err, error = "", "", str(exception)
        stdout = logs / (name + ".stdout.txt")
        stderr = logs / (name + ".stderr.txt")
        stdout.write_text(out)
        stderr.write_text(err + ("\n" + error + "\n" if error else ""))
        record["commands"].append({
            "name": name, "command": command, "cwd": str(cwd.relative_to(root)),
            "returncode": returncode, "execution_error": error,
            "elapsed_seconds": time.monotonic() - start,
            "stdout": str(stdout.relative_to(output)), "stdout_sha256": sha256(stdout),
            "stderr": str(stderr.relative_to(output)), "stderr_sha256": sha256(stderr),
        })
        print(name + ": " + (error or str(returncode)), flush=True)
        if error or returncode != 0:
            raise RuntimeError(name + " failed; inspect its recorded output.")

    try:
        planning = output / "planning"
        proofs = output / "proofs"
        run("boundary-checks", [sys.executable, "-B", "p02-interface-check.py"], output / "scripts")
        run("boundary-checks-optimized", [sys.executable, "-B", "-O", "p02-interface-check.py"], output / "scripts")
        run("python-scipy", [sys.executable, "-B", "-c",
            "import sys, scipy; print(sys.version); print(scipy.__version__)"], planning)
        run("coqc-version", [args.coqc, "--version"], proofs)
        run("tests", [sys.executable, "-B", "-m", "unittest", "-v", "test_planning"], planning)
        run("tests-optimized", [sys.executable, "-B", "-O", "-m", "unittest", "-v", "test_planning"], planning)
        run("benchmark", [sys.executable, "-B", "benchmark.py"], planning)
        for name in ("Lex/VerdictHeyting.v", "Lex/TensorAlignment.v", "CorridorMonotone.v", "assumptions.v"):
            run("coqc-" + name.replace("/", "-"),
                [args.coqc, "-Q", "Lex", "Lex", name], proofs)
        historic = json.loads((root / "planning/benchmark_results.json").read_text())
        fresh = json.loads((planning / "benchmark_results.json").read_text())
        fields = ("group", "case", "method", "instance_sha256", "reference_optimum",
                  "absolute_optimum_gap", "matches_exact_reference", "incumbent_exactly_checked")
        if len(historic["rows"]) != len(fresh["rows"]):
            raise RuntimeError("Fresh benchmark row count differs.")
        comparisons = []
        for old, new in zip(historic["rows"], fresh["rows"]):
            for field in fields:
                if old[field] != new[field]:
                    raise RuntimeError("Fresh benchmark differs: " + old["case"] + "/" + field)
            for field in ("status", "cost", "exact_lower_bound"):
                if old["result"][field] != new["result"][field]:
                    raise RuntimeError("Fresh result differs: " + old["case"] + "/" + field)
            comparisons.append({"case": old["case"], "method": old["method"],
                                "status": new["result"]["status"], "cost": new["result"]["cost"]})
        if historic["source_sha256"] != fresh["source_sha256"]:
            raise RuntimeError("Benchmark source identities differ.")
        record["benchmark_comparison"] = {"rows": len(comparisons),
            "fresh_samples": sum(len(row["samples"]) for row in fresh["rows"]),
            "incumbent_rows": sum(row["incumbent_exactly_checked"] for row in fresh["rows"]),
            "compared_fields": list(fields) + ["result.status", "result.cost", "result.exact_lower_bound"],
            "rows_compared": comparisons}
        verify_manifest(root)
        record["packaged_inputs_unchanged_after_execution"] = True
        record["status"] = "pass"
    except Exception as error:
        record["status"] = "fail"
        record["error"] = str(error)
        raise
    finally:
        record["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        record["outputs"] = [{"path": str(path.relative_to(output)), "sha256": sha256(path)}
                             for path in sorted(output.rglob("*")) if path.is_file()]
        (output / "REPRODUCTION.json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
