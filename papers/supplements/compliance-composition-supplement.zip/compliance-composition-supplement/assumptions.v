Require Import Lex.TensorAlignment.
Require CorridorMonotone.

Set Printing Width 100.

Goal True.
  idtac "=== Five-element chain ===".
Abort.
Check VerdictHeyting.verdict_is_heyting.
Print Assumptions VerdictHeyting.verdict_is_heyting.

Goal True.
  idtac "=== Applicable fragments, mixed-axis records, and impossibility ===".
Abort.
Check lex_meet_preserves_applicable_fragment.
Print Assumptions lex_meet_preserves_applicable_fragment.
Check lex_meet_loses_provenance_on_mixed_axis.
Print Assumptions lex_meet_loses_provenance_on_mixed_axis.
Check lex_meet_loses_provenance_exempt_vs_pending.
Print Assumptions lex_meet_loses_provenance_exempt_vs_pending.
Check tensor_meet_all_applicable_fragment.
Print Assumptions tensor_meet_all_applicable_fragment.
Check tensor_meet_all_binary_agrees.
Print Assumptions tensor_meet_all_binary_agrees.
Check tensor_meet_all_three_way_provenance.
Print Assumptions tensor_meet_all_three_way_provenance.
Check tensor_meet_all_reports_three_axes.
Print Assumptions tensor_meet_all_reports_three_axes.
Check tensor_meet_all_flags_exact.
Print Assumptions tensor_meet_all_flags_exact.
Check no_total_tensor_factor_meet_preserves_signal_and_orthogonality.
Print Assumptions no_total_tensor_factor_meet_preserves_signal_and_orthogonality.

Goal True.
  idtac "=== Normalized snapshot equality checker ===".
Abort.
Check CorridorMonotone.route_coherence_checker_sound.
Print Assumptions CorridorMonotone.route_coherence_checker_sound.
Check CorridorMonotone.route_coherence_checker_complete.
Print Assumptions CorridorMonotone.route_coherence_checker_complete.
Check CorridorMonotone.route_coherence_checker_false_obstruction.
Print Assumptions CorridorMonotone.route_coherence_checker_false_obstruction.
Check CorridorMonotone.route_coherence_decidable.
Print Assumptions CorridorMonotone.route_coherence_decidable.

Goal True.
  idtac "=== Conditional corridor histories ===".
Abort.
Module HistoryAudit (R : CorridorMonotone.RuleExtension).
  Module H := CorridorMonotone.CorridorMonotone R.
  Check H.kappa_monotone.
  Print Assumptions H.kappa_monotone.
  Check H.kappa_multi_monotone.
  Print Assumptions H.kappa_multi_monotone.
End HistoryAudit.
