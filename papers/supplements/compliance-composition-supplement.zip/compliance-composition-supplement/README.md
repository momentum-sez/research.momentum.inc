# How Compliance Composes: finite evidence supplement

This archive contains the boundary checker, benchmark, and proof sources cited in *How Compliance Composes*.
`SHA256SUMS` binds every packaged file except the manifest itself.
The manuscript supplies the archive digest.
`ORIGINALS.json` records the origin, size, and digest of every preserved input.

## Contents and scope

`scripts/p02-interface-check.py` checks the finite boundary frame.
Its nine self-checks cover lossless round-trip, applicability, obligation identity, rule windows, and three-segment composition.
The checker uses only the Python standard library.
Its canonical encoding treats rule-window order as irrelevant while preserving every window value.
It does not authenticate a legal instrument, source signature, or adopted rule.

`planning/` preserves four Python sources, the original README, the original checksums, and four output records without byte changes.
The output records are `benchmark_results.json`, `benchmark_results.csv`, `benchmark_report.txt`, and `verification_results.json`.
The original README records the original machine's interpreter path.
Use the portable commands below for a new run.
The preserved README also mentions signature and documentation checks.
The supplied Python files contain no such checks.

The benchmark contains seven coverage instances and ten semantic fixtures.
Its 44 rows contain 132 timed samples and 33 incumbent-bearing rows.
For `seed31_d12_m24`, coverage DP, prefix DP, greedy selection, and integer programming cost 33, 33, 35, and 33.
The historical median times are 9.845, 3.241, 0.081, and 8.929 milliseconds, respectively.
The historical output records Python 3.14.6, SciPy 1.17.1, and macOS 26.2.
It does not record its wall-clock execution date.

These are measurements of fixed synthetic instances.
They exclude imports and prior incremental cache construction from elapsed time.
Python allocation peaks exclude native solver memory.
Process RSS includes imports, existing caches, and measurement calls.
Fresh timings depend on the machine and concurrent workload.
The archive establishes no deployment performance or legal authority.

`proofs/Lex/VerdictHeyting.v` formalizes a chosen five-element Heyting chain.
`proofs/Lex/TensorAlignment.v` contains the applicable-fragment results, mixed-axis records, provenance witnesses, and finite impossibility core.
Its impossibility theorem concerns `preserves_app_signal_on_notapp` and `keeps_notapp_orthogonal_to_app`.
The tensor module imports `Lex.VerdictHeyting`.
`proofs/CorridorMonotone.v` contains normalized snapshot equality checks and a separate conditional history module.

The four snapshot checker results concern equality of carried cells, fresh evaluation domains, and instrument clauses.
They require no assumptions from the history interface.
The `RuleExtension` interface declares two parameters: `V` and `rule_step`.
It also declares the axiom `rule_step_extends`.
The `kappa_monotone` and `kappa_multi_monotone` results depend on that extension premise.
`assumptions.v` requests the named results' actual assumptions, including the conditional history results.

The only additional proof imports are standard-library modules:
`Coq.Arith.PeanoNat`, `Coq.Lists.List`, `Coq.Bool.Bool`, and `Coq.micromega.Lia`.
Install the standard library supplied with the proof checker.
The included repository licenses cover the copied Lex and Op source files.
Preserved source comments retain their original terminology and dates.

## Reproduce from an extraction

Use a Unix-like system with Python, SciPy, and `coqc` available.
The benchmark uses Python's `resource` module and SciPy's `optimize.milp`.
The checked environment uses Python 3.14.6, SciPy 1.17.1, and Rocq 9.1.1 with OCaml 5.4.1.
Other environments need their own execution check.
No network access or repository checkout is required once these dependencies are installed.

Extract the archive into a new directory.
From its `compliance-composition-supplement` directory, run:

```sh
python3 -B reproduce.py --output fresh-reproduction
```

Select an installed interpreter that provides SciPy if `python3` does not.
Use `--coqc /path/to/coqc` when the checker is outside `PATH`.
The output directory must be new and directly inside the extracted supplement directory.

The command verifies the manifest and copies the original inputs into the output directory.
It runs the nine boundary checks and eleven planning tests with and without Python optimization.
It generates fresh benchmark records in that copy.
It then compiles the three proof modules and records the named assumptions.
Every command has separate output, exit status, elapsed time, and hashes in `fresh-reproduction/REPRODUCTION.json`.
A failure returns a nonzero status and remains visible in that record.

The reproduction compares instance identities, statuses, costs, lower bounds, and exact-reference results with the historical benchmark.
It does not require identical timings, memory readings, or solver internals.
Original records in `planning/` remain unchanged.
The archive's `SHA256SUMS` covers packaged inputs, not the subsequently created output directory.

## Limits

The proof files concern their finite definitions and named premises.
They do not prove normalization from adopted instruments or refinement of an actual production evaluator.
The benchmark concerns its declared catalogues, costs, constraints, and local decisions.
It does not establish facts about live instruments, providers, or institutions.
