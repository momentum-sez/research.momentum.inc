#!/usr/bin/env python3
"""Finite executable checks for the constructions in Event-Collect BFT."""

from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from fractions import Fraction
from hashlib import sha256
from itertools import combinations, product
import json
from typing import Any


def require(condition: bool, message: str = "verification condition failed") -> None:
    """Raise in normal and optimized Python when a verification condition fails."""
    if not condition:
        raise AssertionError(message)


def powerset_of_size(n: int, k: int):
    return combinations(range(n), k)


def canonical(value: Any) -> Any:
    if is_dataclass(value):
        return canonical(asdict(value))
    if isinstance(value, dict):
        return {str(key): canonical(value[key]) for key in sorted(value, key=str)}
    if isinstance(value, (list, tuple)):
        return [canonical(item) for item in value]
    return value


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        canonical(value), sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("ascii")


def canonical_hash(value: Any) -> str:
    return sha256(canonical_bytes(value)).hexdigest()


def check_quorums() -> int:
    cases = 0
    for n in range(1, 501):
        f = (n - 1) // 3
        q = n - f
        require(q == 2 * n // 3 + 1)
        require(n >= 3 * f + 1)
        require(2 * q - n == n - 2 * f >= f + 1)
        require(q - f == n - 2 * f >= f + 1)
        cases += 1

    for n in range(1, 10):
        f = (n - 1) // 3
        q = n - f
        quorums = list(powerset_of_size(n, q))
        for left in quorums:
            for right in quorums:
                require(len(set(left) & set(right)) >= f + 1)
                cases += 1
    return cases


def check_corroboration_thresholds() -> int:
    cases = 0
    for n in range(1, 40):
        for t in range((n - 1) // 3 + 1):
            lower = (n + t) // 2 + 1
            upper = n - t
            require(lower <= upper)
            for theta in range(lower, upper + 1):
                require(2 * theta - n > t)
                require(theta <= n - t)
                cases += 1
                if n <= 9:
                    certs = list(powerset_of_size(n, theta))
                    for left in certs:
                        for right in certs:
                            require(len(set(left) & set(right)) > t)
                            cases += 1
    return cases


def check_bond_floor() -> int:
    cases = 0
    alphas = [Fraction(1, 10), Fraction(1, 3), Fraction(1, 2), Fraction(1)]
    ps = [Fraction(51, 100), Fraction(3, 5), Fraction(3, 4), Fraction(1)]
    betas = [Fraction(0), Fraction(1, 5), Fraction(1, 2), Fraction(1)]
    values = [Fraction(0), Fraction(1), Fraction(7), Fraction(31)]

    for alpha, p, beta, reward, extraction, repair in product(
        alphas, ps, betas, values, values, values
    ):
        first = (1 - p) * reward / (2 * p - 1)
        second = (extraction + repair - alpha * p * reward) / (
            alpha * (2 * p - 1)
        )
        bond = max(first, second)
        truthful = reward + beta * ((2 * p - 1) * bond - (1 - p) * reward)
        false_upper = (
            extraction
            + repair
            + (1 - alpha * p) * reward
            - alpha * (2 * p - 1) * bond
        )
        require(truthful >= reward >= 0)
        require(false_upper <= reward)
        larger = bond + Fraction(1, 1000)
        require(extraction + repair + (1 - alpha * p) * reward - alpha * (2 * p - 1) * larger < reward)
        cases += 1
    return cases


@dataclass(frozen=True)
class EventLabel:
    event_id: str
    status: str
    detail: str
    evidence_hash: str


@dataclass(frozen=True)
class Evidence:
    leg_id: str
    adapter: str
    result: str
    producer: str
    observed_at: int
    payload_hash: str
    authenticated: bool = True


@dataclass(frozen=True)
class Instruction:
    identifier: str
    occurrence: str
    legs: tuple[tuple[str, str, str, int, str], ...]
    event_id: str | None = None
    authenticated: bool = True
    semantically_valid: bool = True
    clearable: bool = True


@dataclass(frozen=True)
class Receipt:
    occurrence: str
    status: str
    clearing: tuple[Any, ...]
    transfer: tuple[Any, ...]


@dataclass
class State:
    balances: dict[str, int]
    events: dict[str, EventLabel]
    receipts: dict[str, Receipt]
    uses: dict[str, str]

    def copy(self) -> "State":
        return State(
            self.balances.copy(),
            self.events.copy(),
            self.receipts.copy(),
            self.uses.copy(),
        )


NOT_EVALUATED = ("not-evaluated",)
NO_TRANSFER = ("no-transfer",)


def make_receipt(
    instruction: Instruction,
    status: str,
    clearing: tuple[Any, ...],
    transfer: tuple[Any, ...],
) -> Receipt:
    receipt = Receipt(instruction.occurrence, status, clearing, transfer)
    require(receipt.occurrence)
    require(receipt.status)
    require(receipt.clearing)
    require(receipt.transfer)
    return receipt


def validate_event_package(
    candidate_ids: tuple[str, ...], labels: tuple[EventLabel, ...]
) -> None:
    require(candidate_ids == tuple(sorted(set(candidate_ids))))
    require(tuple((label.event_id for label in labels)) == candidate_ids)
    for label in labels:
        require(label.status in {'accepted', 'deferred'})
        require(label.detail)
        require(label.evidence_hash)


def validate_terminal_evidence(
    instruction: Instruction, evidence: tuple[Evidence, ...]
) -> tuple[bool, str]:
    leg_ids = tuple(leg[0] for leg in instruction.legs)
    evidence_ids = tuple(item.leg_id for item in evidence)
    if evidence_ids != tuple(sorted(leg_ids)) or len(set(evidence_ids)) != len(leg_ids):
        return False, "noncanonical-evidence-domain"
    by_leg = {item.leg_id: item for item in evidence}
    for leg_id, _source, _target, _amount, adapter in instruction.legs:
        item = by_leg.get(leg_id)
        if item is None or item.adapter != adapter:
            return False, "wrong-adapter"
        if not item.authenticated or not item.producer or not item.payload_hash:
            return False, "unauthenticated-evidence"
        if item.result not in {"applied", "failed"}:
            return False, "nonterminal-evidence"
        if item.result != "applied":
            return False, "external-transfer-failed"
    return True, "ok"


def validate_evidence_envelope(
    instruction: Instruction, evidence: tuple[Evidence, ...]
) -> None:
    """Check the canonical authenticated envelope without requiring success."""
    leg_ids = tuple(leg[0] for leg in instruction.legs)
    evidence_ids = tuple(item.leg_id for item in evidence)
    require(evidence_ids == tuple(sorted(leg_ids)))
    require(len(set(evidence_ids)) == len(leg_ids))
    by_leg = {item.leg_id: item for item in evidence}
    for leg_id, _source, _target, _amount, adapter in instruction.legs:
        item = by_leg[leg_id]
        require(item.adapter == adapter)
        require(item.authenticated and item.producer and item.payload_hash)
        require(item.result in {'applied', 'failed'})


def step(
    state: State,
    labels: dict[str, EventLabel],
    instruction: Instruction,
    evidence: tuple[Evidence, ...],
) -> State:
    out = state.copy()
    require(instruction.occurrence not in out.receipts)

    if not instruction.authenticated:
        out.receipts[instruction.occurrence] = make_receipt(
            instruction, "rejected-auth", NOT_EVALUATED, NO_TRANSFER
        )
        return out

    if instruction.identifier in out.uses:
        out.receipts[instruction.occurrence] = make_receipt(
            instruction,
            "rejected-replay",
            NOT_EVALUATED,
            ("no-transfer", out.uses[instruction.identifier]),
        )
        return out

    out.uses[instruction.identifier] = instruction.occurrence
    if not instruction.semantically_valid:
        out.receipts[instruction.occurrence] = make_receipt(
            instruction, "rejected-semantic", NOT_EVALUATED, NO_TRANSFER
        )
        return out

    if instruction.event_id is not None:
        label = labels.get(instruction.event_id) or out.events.get(instruction.event_id)
        if label is None:
            out.receipts[instruction.occurrence] = make_receipt(
                instruction, "rejected-semantic", NOT_EVALUATED, NO_TRANSFER
            )
            return out
        if label.status == "deferred":
            out.receipts[instruction.occurrence] = make_receipt(
                instruction,
                "deferred",
                ("deferred", instruction.event_id),
                NO_TRANSFER,
            )
            return out

    if not instruction.clearable:
        out.receipts[instruction.occurrence] = make_receipt(
            instruction, "rejected-clearing", ("rejected", "invalid"), NO_TRANSFER
        )
        return out

    group = instruction.legs
    evidence_hash = canonical_hash(evidence)
    evidence_ok, evidence_reason = validate_terminal_evidence(instruction, evidence)
    proposed = out.balances.copy()
    for _leg_id, source, target, amount, _adapter in group:
        if amount < 0:
            evidence_ok, evidence_reason = False, "negative-transfer"
            break
        proposed[source] = proposed.get(source, 0) - amount
        proposed[target] = proposed.get(target, 0) + amount
    if any(value < 0 for value in proposed.values()):
        evidence_ok, evidence_reason = False, "insufficient-balance"

    if not evidence_ok:
        out.receipts[instruction.occurrence] = make_receipt(
            instruction,
            "rejected-settlement",
            ("cleared", group),
            ("failed", evidence_reason, evidence_hash),
        )
        return out

    out.balances = proposed
    out.receipts[instruction.occurrence] = make_receipt(
        instruction,
        "success",
        ("cleared", group),
        ("applied", group, evidence_hash),
    )
    return out


def block(
    parent_root: str,
    witness_hash: str,
    state: State,
    candidate_ids: tuple[str, ...],
    labels: tuple[EventLabel, ...],
    instructions: tuple[Instruction, ...],
    evidence_vector: tuple[tuple[Evidence, ...], ...],
    next_witness_hash: str,
) -> tuple[State, str]:
    validate_event_package(candidate_ids, labels)
    require(len(instructions) == len(evidence_vector))
    require(len({instruction.occurrence for instruction in instructions}) == len(instructions))
    out = state.copy()
    for label in labels:
        out.events[label.event_id] = label
    label_map = {label.event_id: label for label in labels}
    for instruction, evidence in zip(instructions, evidence_vector):
        out = step(out, label_map, instruction, evidence)
        receipt = out.receipts[instruction.occurrence]
        if receipt.clearing[0] == "cleared":
            validate_evidence_envelope(instruction, evidence)
        else:
            require(evidence == ())
    root = canonical_hash(
        {
            "parent_root": parent_root,
            "witness_hash": witness_hash,
            "event_package": labels,
            "evidence_vector": evidence_vector,
            "receipts": tuple(out.receipts[key] for key in sorted(out.receipts)),
            "state": out,
            "next_witness_hash": next_witness_hash,
        }
    )
    return out, root


def normalized(state: State) -> bytes:
    return canonical_bytes(state)


def applied_evidence(legs: tuple[tuple[str, str, str, int, str], ...]) -> tuple[Evidence, ...]:
    return tuple(
        Evidence(leg_id, adapter, "applied", "bank-a", 100, f"hash-{leg_id}")
        for leg_id, _source, _target, _amount, adapter in sorted(legs)
    )


def check_event_atomic_construction() -> int:
    cases = 0
    accepted = EventLabel("e", "accepted", "yes", "event-proof")
    deferred = EventLabel("e", "deferred", "source-timeout", "negative-witness")
    legs = (("leg-1", "alice", "bob", 7, "cash"),)
    instruction = Instruction("k", "w", legs, event_id="e")
    evidence = applied_evidence(legs)
    initial = State({"alice": 10, "bob": 0}, {}, {}, {})

    first, root_a = block(
        "parent", "witness", initial, ("e",), (accepted,), (instruction,), (evidence,), "next"
    )
    second, root_b = block(
        "parent", "witness", initial, ("e",), (accepted,), (instruction,), (evidence,), "next"
    )
    require(root_a == root_b)
    require(normalized(first) == normalized(second))
    require(first.balances == {'alice': 3, 'bob': 7})
    require(first.receipts['w'].clearing == ('cleared', legs))
    require(first.receipts['w'].transfer[0] == 'applied')
    cases += 1

    changed = (Evidence("leg-1", "cash", "applied", "bank-a", 100, "other-hash"),)
    _changed_state, root_changed = block(
        "parent", "witness", initial, ("e",), (accepted,), (instruction,), (changed,), "next"
    )
    require(root_changed != root_a)
    cases += 1

    deferred_state, _ = block(
        "parent", "witness", initial, ("e",), (deferred,), (instruction,), ((),), "next"
    )
    require(deferred_state.balances == initial.balances)
    require(deferred_state.receipts['w'] == Receipt('w', 'deferred', ('deferred', 'e'), NO_TRANSFER))
    cases += 1

    event_free = Instruction("free", "wf", legs)
    event_free_state, _ = block(
        "parent", "witness", initial, (), (), (event_free,), (evidence,), "next"
    )
    require(event_free_state.receipts['wf'].status == 'success')
    cases += 1

    bad_external = (Evidence("leg-1", "cash", "failed", "bank-a", 100, "failure"),)
    failed, _ = block(
        "parent", "witness", initial, ("e",), (accepted,), (instruction,), (bad_external,), "next"
    )
    require(failed.balances == initial.balances)
    require(failed.receipts['w'].clearing == ('cleared', legs))
    require(failed.receipts['w'].transfer[0] == 'failed')
    cases += 1

    try:
        block(
            "parent", "witness", initial, ("e",), (deferred,),
            (instruction,), (evidence,), "next"
        )
    except AssertionError:
        cases += 1
    else:
        raise AssertionError("nonempty evidence was accepted for a no-transfer branch")

    try:
        block(
            "parent", "witness", initial, ("e",), (accepted,),
            (instruction,), ((),), "next"
        )
    except AssertionError:
        cases += 1
    else:
        raise AssertionError("a transfer branch was admitted without its evidence domain")

    for bad_candidates, bad_labels in (
        (("e",), ()),
        (("e",), (accepted, accepted)),
        (("e", "extra"), (accepted,)),
        (("e", "e"), (accepted, accepted)),
    ):
        try:
            validate_event_package(bad_candidates, bad_labels)
        except AssertionError:
            cases += 1
        else:
            raise AssertionError("invalid event package was accepted")
    return cases


def check_complete_receipt_variants() -> int:
    cases = 0
    initial = State({"a": 2, "b": 0}, {}, {}, {})
    accepted = {"e": EventLabel("e", "accepted", "yes", "event-proof")}
    deferred = {"e": EventLabel("e", "deferred", "wait", "negative-witness")}
    legs = (("l", "a", "b", 1, "cash"),)
    evidence = applied_evidence(legs)

    variants = (
        (Instruction("auth", "wa", legs, authenticated=False), accepted, (), "rejected-auth"),
        (Instruction("semantic", "ws", legs, semantically_valid=False), accepted, (), "rejected-semantic"),
        (Instruction("defer", "wd", legs, event_id="e"), deferred, (), "deferred"),
        (Instruction("clear", "wc", legs, clearable=False), accepted, (), "rejected-clearing"),
        (Instruction("evidence", "we", legs), accepted, (), "rejected-settlement"),
        (Instruction("success", "wx", legs), accepted, evidence, "success"),
    )
    for instruction, labels, evidence_input, expected in variants:
        result = step(initial, labels, instruction, evidence_input)
        receipt = result.receipts[instruction.occurrence]
        require(receipt.status == expected)
        require(receipt.clearing and receipt.transfer)
        cases += 1

    once = step(initial, accepted, Instruction("dup", "w1", legs), evidence)
    twice = step(once, accepted, Instruction("dup", "w2", legs), evidence)
    require(twice.balances == once.balances)
    require(twice.receipts['w2'].status == 'rejected-replay')
    require(twice.receipts['w2'].transfer == ('no-transfer', 'w1'))
    cases += 1

    forged = step(initial, accepted, Instruction("same", "bad", legs, authenticated=False), ())
    require('same' not in forged.uses)
    valid = step(forged, accepted, Instruction("same", "good", legs), evidence)
    require(valid.receipts['good'].status == 'success')
    cases += 1
    return cases


def check_atomicity_and_disjoint_commutation() -> int:
    cases = 0
    labels: dict[str, EventLabel] = {}
    insufficient_legs = (("li", "a", "b", 3, "cash"),)
    initial = State({"a": 2, "b": 0}, {}, {}, {})
    failed = step(
        initial,
        labels,
        Instruction("k0", "w0", insufficient_legs),
        applied_evidence(insufficient_legs),
    )
    require(failed.balances == initial.balances)
    require(failed.receipts['w0'].status == 'rejected-settlement')
    cases += 1

    deltas = [0, 1, 2, 3]
    for a0, b0, c0, d0, da, dc in product(range(4), range(4), range(4), range(4), deltas, deltas):
        base = State({"a": a0, "b": b0, "c": c0, "d": d0}, {}, {}, {})
        xlegs = (("lx", "a", "b", da, "cash"),)
        ylegs = (("ly", "c", "d", dc, "cash"),)
        x = Instruction("kx", "wx", xlegs)
        y = Instruction("ky", "wy", ylegs)
        xy = step(step(base, labels, x, applied_evidence(xlegs)), labels, y, applied_evidence(ylegs))
        yx = step(step(base, labels, y, applied_evidence(ylegs)), labels, x, applied_evidence(xlegs))
        require(normalized(xy) == normalized(yx))
        cases += 1
    return cases


def check_five_round_causal_cuts() -> int:
    properties = {
        "D1": ("proposal", "materialization-vote"),
        "D2": ("materialization-vote", "lock-vote"),
        "D3": ("lock-vote", "share"),
        "D4": ("share", "ledger-confirmation-vote"),
    }
    nodes = (
        "proposal",
        "materialization-vote",
        "lock-vote",
        "share",
        "ledger-confirmation-vote",
    )

    def satisfies(assignment: dict[str, int]) -> bool:
        return all(assignment[left] < assignment[right] for left, right in properties.values())

    valid_four_round_schedules = 0
    for rounds in product(range(1, 5), repeat=len(nodes)):
        valid_four_round_schedules += satisfies(dict(zip(nodes, rounds)))
    require(valid_four_round_schedules == 0)
    tight = dict(zip(nodes, range(1, 6)))
    require(satisfies(tight))
    require(max(tight.values()) == 5)
    return 4 ** len(nodes) + 1


def successful_capacity(
    instruction: Fraction,
    custody: Fraction,
    decryption: Fraction,
    execution: Fraction,
    persistence: Fraction,
    block_capacity: Fraction,
    confirmation_time: Fraction,
) -> Fraction:
    return min(
        instruction,
        custody,
        decryption,
        execution,
        persistence,
        block_capacity / confirmation_time,
    )


def check_throughput_and_security_units() -> int:
    cases = 0
    overall = successful_capacity(
        Fraction(100), Fraction(90), Fraction(80), Fraction(70), Fraction(60), Fraction(50), Fraction(1)
    )
    require(overall == 50)
    require(min(overall, Fraction(7)) == 7)
    require(successful_capacity(Fraction(100), Fraction(90), Fraction(80), Fraction(70), Fraction(60), Fraction(50), Fraction(1)) == overall)
    cases += 3

    positions = (
        (Fraction(5), Fraction(2)),
        (Fraction(7), Fraction(3, 2)),
        (Fraction(11), Fraction(1, 4)),
    )
    converted = sum(amount * pinned_price for amount, pinned_price in positions)
    require(converted == Fraction(93, 4))
    security_budget = Fraction(30)
    gamma = Fraction(5, 4)
    require(security_budget >= gamma * converted)
    cases += 2
    return cases


def main() -> None:
    results = {
        "quorum_arithmetic_and_intersections": check_quorums(),
        "corroboration_thresholds_and_intersections": check_corroboration_thresholds(),
        "bond_payoff_inequalities": check_bond_floor(),
        "event_atomic_evidence_and_roots": check_event_atomic_construction(),
        "complete_receipt_variants": check_complete_receipt_variants(),
        "atomicity_and_disjoint_commutation": check_atomicity_and_disjoint_commutation(),
        "five_round_causal_cuts": check_five_round_causal_cuts(),
        "throughput_and_security_units": check_throughput_and_security_units(),
    }
    for name, cases in results.items():
        print(f"PASS {name}: {cases} cases")
    print(f"PASS total: {sum(results.values())} cases")


if __name__ == "__main__":
    main()
