"""Apply one supplied envelope in a separate process.

With both barrier paths, the worker writes ``ready`` and waits at most 20 seconds
for ``go`` before applying. Ledger fault points terminate with exit code 77.
"""
import argparse
import json
from pathlib import Path
import time

from ledger import Ledger
from model import Policy, Rejected, Stale


FAULT_POINTS = (
    "before_begin",
    "after_read",
    "after_slices",
    "after_write",
    "before_commit",
    "after_commit",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, required=True)
    parser.add_argument("--policy", type=Path, required=True)
    parser.add_argument("--envelope", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--crash", choices=FAULT_POINTS)
    parser.add_argument("--ready", type=Path)
    parser.add_argument("--go", type=Path)
    args = parser.parse_args()
    if (args.ready is None) != (args.go is None):
        parser.error("--ready and --go must be supplied together")

    policy = Policy(**json.loads(args.policy.read_text(encoding="utf-8")))
    ledger = Ledger(args.db, policy)
    envelope = json.loads(args.envelope.read_text(encoding="utf-8"))
    if args.ready is not None:
        deadline = time.monotonic() + 20.0
        args.ready.write_text("ready\n", encoding="utf-8")
        while not args.go.exists():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("race barrier did not open within 20 seconds")
            time.sleep(min(0.01, remaining))

    try:
        receipt = ledger.apply(envelope, crash=args.crash)
    except Stale as error:
        result = {"status": "stale", "error": str(error)}
        exit_code = 2
    except Rejected as error:
        result = {"status": "rejected", "error": str(error)}
        exit_code = 3
    else:
        result = {"status": "applied", "receipt": receipt}
        exit_code = 0
    args.output.write_text(
        json.dumps(result, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
