"""Pure transitions for one admitted allocation ledger.

The admitted custodian records facts and compatibility under the supplied scope.
Its signature is not a provider-finality proof or an institutional mandate.
"""
from copy import deepcopy
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import re
import sys
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

CHECKER_SHA256 = "eddd81fd533185b68808f3b333981d92a49ae0135bb365385cb81e84bcb3abd3"
_file = Path(__file__).with_name("allocation.py")
if sha256(_file.read_bytes()).hexdigest() != CHECKER_SHA256:
    raise RuntimeError("Certified allocation dependency changed")
_spec = importlib.util.spec_from_file_location("p10_certified_allocation", _file)
allocator = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = allocator
_spec.loader.exec_module(allocator)


class Rejected(ValueError):
    pass


class Stale(Rejected):
    pass


def require(condition, message):
    if not condition:
        raise Rejected(message)


def canonical(value):
    def valid(x):
        require(x is None or type(x) in (str, int, bool, list, dict), "wire type")
        if type(x) is int:
            require(x.bit_length() <= 256, "wire integer bound")
        if type(x) is list:
            for child in x:
                valid(child)
        if type(x) is dict:
            require(all(type(k) is str for k in x), "wire keys")
            for child in x.values():
                valid(child)
    valid(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(value):
    return sha256(canonical(value)).hexdigest()


def ident(value):
    try:
        return allocator.identifier(value)
    except ValueError as e:
        raise Rejected(str(e)) from e


def quantity(value):
    value = allocator.amount(value)
    return [str(value.numerator), str(value.denominator)]


def number(value):
    require(type(value) is list and len(value) == 2 and
            all(type(x) is str and re.fullmatch(r"0|[1-9][0-9]*", x) for x in value),
            "exact quantity encoding")
    require(int(value[1]) > 0, "zero denominator")
    result = Fraction(int(value[0]), int(value[1]))
    require(quantity(result) == value, "noncanonical quantity")
    return result


def economic_id(origin):
    require(type(origin) is list and len(origin) == 3, "duty origin")
    for value in origin:
        ident(value)
    # Byte-identical to P09 for this shared ASCII identifier domain.
    return digest(["economic-duty", *origin])


@dataclass(frozen=True)
class Policy:
    ledger: str
    asset: str
    unit: str
    custodian_key: str
    authority_evidence: str

    def record(self):
        for x in (self.ledger, self.asset, self.unit, self.authority_evidence):
            ident(x)
        require(type(self.custodian_key) is str and
                re.fullmatch(r"[0-9a-f]{64}", self.custodian_key), "public key")
        return {"ledger": self.ledger, "asset": self.asset, "unit": self.unit,
                "custodian_key": self.custodian_key,
                "authority_evidence": self.authority_evidence,
                "scope": "one-admitted-divisible-allocation-ledger-v1"}


def genesis(policy):
    return {"policy": policy.record(), "revision": 0,
            "authority": {"enabled": True, "epoch": 0,
                          "evidence": policy.authority_evidence},
            "occurrences": {}, "duties": {}, "slices": {},
            "compatibility": None, "consumed": {}, "actions": {}}


def signed(private_key, payload):
    canonical(payload)
    return {"payload": deepcopy(payload), "signature": private_key.sign(canonical(payload)).hex()}


def authenticate(policy, envelope):
    require(type(envelope) is dict and set(envelope) == {"payload", "signature"}, "act shape")
    payload = envelope["payload"]
    require(type(payload) is dict and set(payload) ==
            {"domain", "ledger", "revision", "base", "op", "data"}, "act payload")
    require(type(payload["revision"]) is int and 0 <= payload["revision"] < 2**256,
            "act revision")
    require(type(payload["base"]) is str and re.fullmatch(r"[0-9a-f]{64}", payload["base"]),
            "act predecessor")
    require(type(payload["op"]) is str and type(payload["data"]) is dict, "act operation")
    require(type(envelope["signature"]) is str and
            re.fullmatch(r"[0-9a-f]{128}", envelope["signature"]), "signature encoding")
    require(payload["domain"] == "P10-admitted-state-act-v1" and
            payload["ledger"] == policy.ledger, "act scope")
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(policy.custodian_key)).verify(
            bytes.fromhex(envelope["signature"]), canonical(payload))
    except Exception as e:
        raise Rejected("act signature") from e
    return deepcopy(payload)


def state_root(state):
    return digest(["P10-allocation-state-v1", state])


def semantic_root(state):
    # This admitted pair relation is invariant under capacity consumption only.
    # Changed terms, occurrence identity, rule binding, or authority needs renewal.
    return digest(["P10-fixed-terms-capacity-only-v1", state["policy"],
                   state["authority"], state["occurrences"], state["duties"]])


def extent(piece):
    start, end = number(piece["start"]), number(piece["end"])
    require(start < end, "positive slice extent")
    return start, end


def used(state, occurrence):
    return sorted(((*extent(piece), sid) for sid, piece in state["slices"].items()
                   if piece["occurrence"] == occurrence), key=lambda x: (x[0], x[1], x[2]))


def effective(state, duty):
    return sum((number(p["end"]) - number(p["start"])
                for p in state["slices"].values()
                if p["duty"] == duty and p["kind"] == "fixed"), Fraction(0))


def free_intervals(state, occurrence):
    stop = number(state["occurrences"][occurrence]["quantity"])
    cursor = Fraction(0)
    result = []
    for start, end, _ in used(state, occurrence):
        require(cursor <= start < end <= stop, "overlapping or out-of-root physical slices")
        if cursor < start:
            result.append((cursor, start))
        cursor = end
    if cursor < stop:
        result.append((cursor, stop))
    return result


def add_slice(state, occurrence, duty, start, end, kind, evidence, binding):
    require(occurrence in state["occurrences"] and duty in state["duties"], "slice endpoint")
    require(kind in ("fixed", "hold"), "slice kind")
    credit, obligation = state["occurrences"][occurrence], state["duties"][duty]
    require(credit["beneficiary"] == obligation["beneficiary"] and credit["estate"] == obligation["estate"],
            "slice beneficiary or estate mismatch")
    ident(evidence)
    require(start < end, "positive slice extent")
    require(any(a <= start < end <= b for a, b in free_intervals(state, occurrence)),
            "physical interval already owned or unavailable")
    if kind == "fixed":
        require(effective(state, duty) + end - start <= number(state["duties"][duty]["required"]),
                "duty overperformance")
    sid = digest(["physical-slice-v1", occurrence, quantity(start), quantity(end)])
    require(sid not in state["slices"], "physical slice reused")
    state["slices"][sid] = {"occurrence": occurrence, "duty": duty,
                           "start": quantity(start), "end": quantity(end),
                           "kind": kind, "evidence": evidence, "binding": binding}
    return sid


def invariant(state, policy):
    require(state["policy"] == policy.record(), "ledger policy changed")
    require(type(state["revision"]) is int and state["revision"] >= 0, "ledger revision")
    identities = set()
    for root, row in state["occurrences"].items():
        ident(root)
        require(row["physical"]["asset"] == policy.asset and row["physical"]["unit"] == policy.unit,
                "physical unit")
        identity = digest(["provider-occurrence", row["physical"]])
        require(identity not in identities, "physical occurrence alias")
        identities.add(identity)
        free_intervals(state, root)
    for duty, row in state["duties"].items():
        require(economic_id(row["origin"]) == duty, "economic duty identity")
        require(effective(state, duty) <= number(row["required"]), "duty conservation")
    for sid, piece in state["slices"].items():
        require(piece["occurrence"] in state["occurrences"] and piece["duty"] in state["duties"],
                "unknown slice owner")
        require(sid == digest(["physical-slice-v1", piece["occurrence"],
                               piece["start"], piece["end"]]), "physical slice identity")
        require(piece["kind"] in ("fixed", "hold"), "slice class")
    return True


def batch_for(state):
    relation = state["compatibility"]
    require(state["authority"]["enabled"], "allocation authority disabled")
    require(relation is not None and relation["semantic_root"] == semantic_root(state),
            "compatibility is not current")
    supplies = []
    for root, row in sorted(state["occurrences"].items()):
        fixed, held = {}, Fraction(0)
        for piece in state["slices"].values():
            if piece["occurrence"] != root:
                continue
            size = number(piece["end"]) - number(piece["start"])
            if piece["kind"] == "hold":
                held += size
            else:
                fixed[piece["duty"]] = fixed.get(piece["duty"], Fraction(0)) + size
        supplies.append(allocator.Supply(root, number(row["quantity"]), tuple(sorted(fixed.items())), held))
    demands = tuple(allocator.Demand(duty, number(row["required"]), effective(state, duty))
                    for duty, row in sorted(state["duties"].items()))
    batch = allocator.Batch(state_root(state), digest([state["policy"]["asset"], state["policy"]["unit"]]),
                            digest(relation), tuple(supplies), demands,
                            tuple(tuple(p) for p in relation["edges"]))
    batch.normalized()
    return batch


def certificate_record(certificate):
    return {"batch_hash": certificate.batch_hash,
            "allocation": [[i, j, quantity(v)] for i, j, v in certificate.allocation],
            "value": quantity(certificate.value),
            "maximum_cut": [list(v) for v in certificate.maximum_cut],
            "lexical_cuts": [[list(v) for v in cut] for cut in certificate.lexical_cuts]}


def certificate_from(record):
    require(type(record) is dict and set(record) ==
            {"batch_hash", "allocation", "value", "maximum_cut", "lexical_cuts"}, "certificate shape")
    require(type(record["batch_hash"]) is str and re.fullmatch(r"[0-9a-f]{64}", record["batch_hash"]),
            "certificate batch hash")
    require(all(type(record[k]) is list for k in ("allocation", "maximum_cut", "lexical_cuts")),
            "certificate collections")
    require(all(type(row) is list and len(row) == 3 and
                type(row[0]) is str and type(row[1]) is str for row in record["allocation"]),
            "certificate allocation rows")
    def vertex(v):
        return type(v) is list and len(v) == 2 and all(type(x) is str for x in v)
    require(all(vertex(v) for v in record["maximum_cut"]) and
            all(type(cut) is list and all(vertex(v) for v in cut) for cut in record["lexical_cuts"]),
            "certificate vertex cuts")
    try:
        return allocator.Certificate(record["batch_hash"],
               tuple((i, j, number(v)) for i, j, v in record["allocation"]), number(record["value"]),
               tuple(tuple(v) for v in record["maximum_cut"]),
               tuple(tuple(tuple(v) for v in cut) for cut in record["lexical_cuts"]))
    except (TypeError, ValueError) as e:
        raise Rejected("certificate encoding") from e


def batch_id(state, closure, batch_hash):
    ident(closure)
    return digest(["P10-closed-batch-v1", state["policy"]["ledger"], closure,
                   state["revision"], state_root(state), batch_hash])


def prepare(state, closure):
    batch = batch_for(state)
    certificate = allocator.solve(batch)
    return {"closure": closure, "batch_id": batch_id(state, closure, certificate.batch_hash),
            "certificate": certificate_record(certificate)}


def act_payload(state, op, data):
    return {"domain": "P10-admitted-state-act-v1", "ledger": state["policy"]["ledger"],
            "revision": state["revision"], "base": state_root(state),
            "op": op, "data": deepcopy(data)}


def transition(state, policy, envelope):
    payload = authenticate(policy, envelope)
    action_id = digest(["P10-state-act", payload])
    if action_id in state["actions"]:
        return None, {"replay_sequence": state["actions"][action_id]}
    data, op = payload["data"], payload["op"]
    if op == "apply":
        require(type(data) is dict and set(data) == {"closure", "batch_id", "certificate"}, "proposal shape")
        bid = ident(data["batch_id"])
        if bid in state["consumed"]:
            previous = state["consumed"][bid]
            require(previous["request"] == action_id, "consumed batch request conflict")
            return None, {"replay_sequence": previous["sequence"]}
    if payload["revision"] != state["revision"] or payload["base"] != state_root(state):
        raise Stale("predecessor changed")
    nxt = deepcopy(state)
    result = {"op": op}
    if op == "occurrence":
        require(type(data) is dict and set(data) ==
                {"root", "physical", "quantity", "beneficiary", "estate", "evidence", "contract"},
                "occurrence shape")
        root = ident(data["root"])
        require(root not in state["occurrences"], "canonical occurrence already exists")
        physical = data["physical"]
        require(type(physical) is dict and set(physical) ==
                {"provider", "account", "asset", "unit", "namespace", "epoch", "reference"},
                "physical identity shape")
        for value in physical.values():
            ident(value)
        for key in ("beneficiary", "estate", "evidence", "contract"):
            ident(data[key])
        require(physical["asset"] == policy.asset and physical["unit"] == policy.unit, "occurrence unit")
        require(number(data["quantity"]) > 0, "positive occurrence quantity")
        require(all(row["physical"] != physical for row in state["occurrences"].values()),
                "provider occurrence already has a canonical root")
        nxt["occurrences"][root] = {k: deepcopy(v) for k, v in data.items() if k != "root"}
    elif op == "duty":
        require(type(data) is dict and set(data) ==
                {"origin", "required", "beneficiary", "debtor", "estate", "binding", "evidence"},
                "duty shape")
        duty = economic_id(data["origin"])
        require(duty not in state["duties"], "economic duty already exists")
        require(number(data["required"]) > 0, "positive duty quantity")
        for key in ("beneficiary", "debtor", "estate", "binding", "evidence"):
            ident(data[key])
        nxt["duties"][duty] = deepcopy(data)
        result["duty"] = duty
    elif op == "rebind":
        require(type(data) is dict and set(data) == {"duty", "binding", "evidence"}, "rebind shape")
        ident(data["duty"])
        require(data["duty"] in state["duties"], "unknown economic duty")
        ident(data["binding"]); ident(data["evidence"])
        nxt["duties"][data["duty"]]["binding"] = data["binding"]
        nxt["duties"][data["duty"]]["evidence"] = data["evidence"]
    elif op == "slice":
        require(type(data) is dict and set(data) ==
                {"occurrence", "duty", "start", "end", "kind", "evidence", "binding"}, "slice shape")
        ident(data["binding"]); ident(data["occurrence"]); ident(data["duty"])
        sid = add_slice(nxt, data["occurrence"], data["duty"], number(data["start"]),
                        number(data["end"]), data["kind"], data["evidence"], data["binding"])
        result["slices"] = [sid]
    elif op == "compatibility":
        require(type(data) is dict and set(data) == {"semantic_root", "edges", "evidence", "contract"},
                "compatibility shape")
        require(data["semantic_root"] == semantic_root(state), "compatibility terms changed")
        require(data["contract"] == "fixed-terms-capacity-only-v1", "compatibility contract")
        ident(data["evidence"])
        pairs = data["edges"]
        require(type(pairs) is list and all(type(x) is list and len(x) == 2 for x in pairs), "pair shape")
        for pair in pairs:
            for endpoint in pair:
                ident(endpoint)
        require(pairs == sorted(pairs) and len({tuple(x) for x in pairs}) == len(pairs), "canonical pairs")
        for occurrence, duty in pairs:
            require(occurrence in state["occurrences"] and duty in state["duties"], "compatible endpoint")
            credit, obligation = state["occurrences"][occurrence], state["duties"][duty]
            require(credit["beneficiary"] == obligation["beneficiary"] and credit["estate"] == obligation["estate"],
                    "beneficiary or estate mismatch")
        nxt["compatibility"] = {**deepcopy(data), "revision": state["revision"] + 1}
    elif op == "authority":
        require(type(data) is dict and set(data) == {"enabled", "evidence"} and
                type(data["enabled"]) is bool, "authority shape")
        ident(data["evidence"])
        nxt["authority"] = {"enabled": data["enabled"], "epoch": state["authority"]["epoch"] + 1,
                            "evidence": data["evidence"]}
    elif op == "apply":
        batch = batch_for(state)
        certificate = certificate_from(data["certificate"])
        require(data["batch_id"] == batch_id(state, data["closure"], batch.normalized()[3]),
                "closed batch identity")
        require(allocator.verify(batch, certificate), "allocation certificate rejected")
        allocated = []
        for occurrence, duty, wanted in certificate.allocation:
            remaining = wanted
            for start, stop in free_intervals(nxt, occurrence):
                if remaining == 0:
                    break
                length = min(remaining, stop - start)
                allocated.append(add_slice(nxt, occurrence, duty, start, start + length, "fixed",
                                           data["batch_id"], nxt["duties"][duty]["binding"]))
                remaining -= length
            require(remaining == 0, "certified allocation unavailable")
        nxt["consumed"][data["batch_id"]] = {"request": action_id, "sequence": state["revision"] + 1}
        result.update({"batch_id": data["batch_id"], "batch_hash": certificate.batch_hash,
                       "value": quantity(certificate.value), "slices": allocated})
    else:
        raise Rejected("unknown act")
    nxt["revision"] += 1
    nxt["actions"][action_id] = nxt["revision"]
    invariant(nxt, policy)
    result.update({"sequence": nxt["revision"], "request": action_id,
                   "parent": state_root(state), "root": state_root(nxt)})
    return nxt, result
