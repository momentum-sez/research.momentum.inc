"""Persisted allocation tests with admitted Ed25519 acts and real processes."""
from copy import deepcopy
from dataclasses import asdict, replace
from fractions import Fraction
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import time
import unittest
from unittest.mock import patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

import ledger
import model


KEY = Ed25519PrivateKey.from_private_bytes(bytes(range(32)))
OTHER_KEY = Ed25519PrivateKey.from_private_bytes(bytes(reversed(range(32))))
PUBLIC = KEY.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()
POLICY = model.Policy("test-ledger", "USD", "cent", PUBLIC, "test-mandate:1")
WORKER = Path(__file__).with_name("race_worker.py")


def wire_number(value):
    """Decode fixture quantities without the implementation decoder."""
    return Fraction(int(value[0]), int(value[1]))


class DurableAllocationTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory(prefix="p10-durable-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.policy_file = self.root / "policy.json"
        self.policy_file.write_text(json.dumps(asdict(POLICY)))

    def create(self, name="state"):
        return ledger.Ledger.create(self.root / (name + ".sqlite"), POLICY)

    def admit(self, book, operation, data):
        return book.apply(model.signed(KEY, book.payload(operation, data)))

    def duty(self, book, suffix, required=1, beneficiary="creditor:one", estate="estate:one"):
        data = {"origin": ["agreement:" + suffix, "leg:" + suffix, "debtor:one"],
                "required": model.quantity(required), "beneficiary": beneficiary,
                "debtor": "debtor:one", "estate": estate, "binding": "rule:one",
                "evidence": "duty-evidence:" + suffix}
        receipt = self.admit(book, "duty", data)
        return receipt["duty"]

    def occurrence(self, book, root, quantity=1, reference=None,
                   beneficiary="creditor:one", estate="estate:one"):
        data = {"root": root, "physical": {"provider": "test-provider", "account": "test-account",
                "asset": "USD", "unit": "cent", "namespace": "test-payments", "epoch": "epoch:1",
                "reference": reference or ("physical:" + root)},
                "quantity": model.quantity(quantity), "beneficiary": beneficiary,
                "estate": estate, "evidence": "occurrence-evidence:" + root,
                "contract": "test-provider-contract:1"}
        return self.admit(book, "occurrence", data)

    def compatibility(self, book, edges):
        return self.admit(book, "compatibility", {
            "semantic_root": model.semantic_root(book.snapshot()),
            "edges": sorted([list(pair) for pair in edges]),
            "evidence": "test-compatible:1", "contract": "fixed-terms-capacity-only-v1"})

    def fixture(self, name="state", quantities=(1, 1), requirements=(1, 1)):
        book = self.create(name)
        duties = sorted([self.duty(book, "a", requirements[0]), self.duty(book, "b", requirements[1])])
        self.occurrence(book, "a", quantities[0])
        self.occurrence(book, "b", quantities[1])
        edges = [("a", duties[0]), ("a", duties[1]), ("b", duties[0])]
        self.compatibility(book, edges)
        return book, duties, edges

    def allocation(self, book, closure="closure:one"):
        return model.signed(KEY, book.prepare(closure))

    def slice(self, book, occurrence, duty, start, end, kind="fixed"):
        return self.admit(book, "slice", {
            "occurrence": occurrence, "duty": duty, "start": model.quantity(start),
            "end": model.quantity(end), "kind": kind,
            "evidence": "test-slice-evidence", "binding": "rule:one"})

    def independent_total(self, state):
        total = Fraction(0)
        effective = {duty: Fraction(0) for duty in state["duties"]}
        for root, occurrence in state["occurrences"].items():
            parts = sorted((wire_number(row["start"]), wire_number(row["end"]), row)
                           for row in state["slices"].values() if row["occurrence"] == root)
            cursor = Fraction(0)
            for start, end, row in parts:
                self.assertLessEqual(cursor, start)
                self.assertLess(start, end)
                self.assertLessEqual(end, wire_number(occurrence["quantity"]))
                cursor = end
                if row["kind"] == "fixed":
                    total += end - start
                    effective[row["duty"]] += end - start
        for duty, quantity in effective.items():
            self.assertLessEqual(quantity, wire_number(state["duties"][duty]["required"]))
        return total, effective

    def reject_unchanged(self, book, envelope, exception=model.Rejected):
        before = book.export()
        with self.assertRaises(exception):
            book.apply(envelope)
        self.assertEqual(book.export(), before)

    def worker_command(self, book, envelope, label, crash=None, barrier=None):
        envelope_file = self.root / (label + "-envelope.json")
        output = self.root / (label + "-output.json")
        envelope_file.write_text(json.dumps(envelope))
        flags = [] if __debug__ else ["-O"]
        command = [sys.executable, *flags, str(WORKER), "--db", str(book.path),
                   "--policy", str(self.policy_file), "--envelope", str(envelope_file), "--output", str(output)]
        if crash:
            command.extend(["--crash", crash])
        if barrier:
            command.extend(["--ready", str(barrier[0]), "--go", str(barrier[1])])
        return command, output

    def race(self, book, envelopes, label):
        go = self.root / (label + "-go")
        processes = []
        ready_paths = []
        try:
            for i, envelope in enumerate(envelopes):
                ready = self.root / (label + "-ready-" + str(i))
                ready_paths.append(ready)
                command, output = self.worker_command(book, envelope, label + str(i), barrier=(ready, go))
                processes.append((subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True), output))
            deadline = time.monotonic() + 20
            while not all(path.exists() for path in ready_paths):
                self.assertTrue(all(process.poll() is None for process, _ in processes), "Race worker exited before barrier")
                self.assertLess(time.monotonic(), deadline, "Race readiness timed out")
                time.sleep(0.01)
            go.write_text("go\n")
            results = []
            for process, output in processes:
                stdout, stderr = process.communicate(timeout=30)
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")
                result = json.loads(output.read_text())
                results.append((process.returncode, result))
                print("PROCESS_EVIDENCE " + json.dumps({"case": label, "pid": process.pid,
                      "exit_code": process.returncode, "status": result["status"]}), flush=True)
            self.assertEqual(len({p.pid for p, _ in processes}), len(envelopes))
            return results
        finally:
            for process, _ in processes:
                if process.poll() is None:
                    process.kill()
                    process.communicate()

    def test_signed_useful_two_credit_two_duty_allocation_persists(self):
        book, duties, _ = self.fixture()
        proposal = self.allocation(book)
        before = book.snapshot()
        receipt = book.apply(proposal)
        self.assertEqual(wire_number(receipt["value"]), 2)
        self.assertEqual(len(receipt["slices"]), 2)
        reopened = ledger.Ledger(book.path, POLICY)
        total, effective = self.independent_total(reopened.snapshot())
        self.assertEqual(total, 2)
        self.assertEqual(effective, {duties[0]: 1, duties[1]: 1})
        owners = {(p["occurrence"], p["duty"]) for p in reopened.snapshot()["slices"].values()}
        self.assertEqual(owners, {("a", duties[1]), ("b", duties[0])})
        self.assertEqual(reopened.snapshot()["revision"], before["revision"] + 1)
        evidence_dir = os.environ.get("P10_DURABLE_EVIDENCE_DIR")
        if evidence_dir:
            destination = Path(evidence_dir)
            destination.mkdir(parents=True, exist_ok=True)
            shutil.copy2(book.path, destination / "useful-allocation.sqlite")
            shutil.copy2(self.policy_file, destination / "policy.json")
            (destination / "journal.json").write_text(json.dumps(reopened.export(), sort_keys=True, indent=2) + "\n")
            (destination / "state.json").write_text(json.dumps(reopened.snapshot(), sort_keys=True, indent=2) + "\n")
            (destination / "allocation-receipt.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
            copied = ledger.Ledger(destination / "useful-allocation.sqlite", POLICY)
            self.assertEqual(copied.snapshot(), reopened.snapshot())

    def test_wrong_signature_domain_ledger_and_changed_payload_are_rejected(self):
        book, _, _ = self.fixture()
        payload = book.prepare("closure:authentication")
        wrong_domain = {**payload, "domain": "different-protocol"}
        wrong_ledger = {**payload, "ledger": "another-ledger"}
        altered = model.signed(KEY, payload)
        altered["payload"]["data"]["closure"] = "altered-without-signature"
        for envelope in (model.signed(OTHER_KEY, payload), model.signed(KEY, wrong_domain),
                         model.signed(KEY, wrong_ledger), altered):
            self.reject_unchanged(book, envelope)
        with self.assertRaises(model.Rejected):
            ledger.Ledger(book.path, replace(POLICY, unit="EUR-cent")).snapshot()

    def test_rebind_invalidates_pending_semantics_until_fresh_admission(self):
        book, duties, edges = self.fixture()
        pending = self.allocation(book)
        self.admit(book, "rebind", {"duty": duties[0], "binding": "rule:two", "evidence": "rule-change:2"})
        self.reject_unchanged(book, pending, model.Stale)
        with self.assertRaisesRegex(model.Rejected, "compatibility is not current"):
            book.prepare("closure:stale-terms")
        self.compatibility(book, edges)
        receipt = book.apply(self.allocation(book, "closure:new-terms"))
        self.assertEqual(wire_number(receipt["value"]), 2)
        self.assertEqual(set(book.snapshot()["duties"]), set(duties))

    def test_authority_change_requires_current_permission_and_compatibility(self):
        book, _, edges = self.fixture()
        pending = self.allocation(book)
        self.admit(book, "authority", {"enabled": False, "evidence": "authority:revoked"})
        self.reject_unchanged(book, pending, model.Stale)
        with self.assertRaisesRegex(model.Rejected, "authority disabled"):
            book.prepare("closure:disabled")
        self.admit(book, "authority", {"enabled": True, "evidence": "authority:renewed"})
        with self.assertRaisesRegex(model.Rejected, "compatibility is not current"):
            book.prepare("closure:old-compatibility")
        self.compatibility(book, edges)
        self.assertEqual(wire_number(book.apply(self.allocation(book))["value"]), 2)

    def test_fixed_holds_fractional_intervals_and_overlap_rejection(self):
        book, duties, _ = self.fixture(quantities=(3, 2), requirements=(3, 3))
        self.slice(book, "a", duties[0], 0, Fraction(1, 2))
        self.slice(book, "a", duties[0], Fraction(1, 2), Fraction(3, 2), "hold")
        self.slice(book, "b", duties[1], 0, 1)
        before = deepcopy(book.snapshot()["slices"])
        for kind in ("fixed", "hold"):
            envelope = model.signed(KEY, book.payload("slice", {
                "occurrence": "a", "duty": duties[1], "start": model.quantity(Fraction(1, 4)),
                "end": model.quantity(Fraction(3, 4)), "kind": kind,
                "evidence": "overlap-attempt", "binding": "rule:one"}))
            self.reject_unchanged(book, envelope)
        receipt = book.apply(self.allocation(book))
        self.assertEqual(wire_number(receipt["value"]), Fraction(5, 2))
        after = book.snapshot()
        self.assertEqual({sid: after["slices"][sid] for sid in before}, before)
        self.assertEqual(self.independent_total(after)[0], 4)
        self.assertEqual(sum(wire_number(p["end"]) - wire_number(p["start"])
                             for p in after["slices"].values() if p["kind"] == "hold"), 1)

    def test_physical_root_alias_and_duplicate_economic_origin_are_rejected(self):
        book, duties, _ = self.fixture()
        state = book.snapshot()
        alias = {"root": "renamed-physical-root", **deepcopy(state["occurrences"]["a"])}
        self.reject_unchanged(book, model.signed(KEY, book.payload("occurrence", alias)))
        duplicate = {**deepcopy(state["duties"][duties[0]]), "required": model.quantity(100)}
        self.reject_unchanged(book, model.signed(KEY, book.payload("duty", duplicate)))

    def test_admitted_exact_rationals_remain_closed_under_allocation_sum(self):
        book = self.create("large-denominator")
        duty = self.duty(book, "rational", required=1)
        amounts = (Fraction(1, 2 ** 100), Fraction(1, 3 ** 63), Fraction(1, 5 ** 43))
        roots = ("rational:a", "rational:b", "rational:c")
        for root, quantity in zip(roots, amounts):
            self.occurrence(book, root, quantity)
        self.compatibility(book, [(root, duty) for root in roots])
        expected = sum(amounts, Fraction(0))
        self.assertGreater(expected.denominator.bit_length(), 256)
        receipt = book.apply(self.allocation(book, "closure:large-denominator"))
        self.assertEqual(wire_number(receipt["value"]), expected)
        state = book.snapshot()
        self.assertEqual(self.independent_total(state)[0], expected)
        self.assertEqual(len(state["slices"]), 3)
        actual = {piece["occurrence"]: (wire_number(piece["start"]), wire_number(piece["end"]))
                  for piece in state["slices"].values()}
        self.assertEqual(actual, {root: (0, quantity) for root, quantity in zip(roots, amounts)})
        restored, _ = ledger.replay(book.export(), POLICY)
        self.assertEqual(restored, state)

    def test_fixed_and_held_slices_preserve_beneficiary_and_estate(self):
        book = self.create("slice-terms")
        wrong_beneficiary = self.duty(book, "other-beneficiary", beneficiary="creditor:two")
        wrong_estate = self.duty(book, "other-estate", estate="estate:two")
        self.occurrence(book, "terms-root")
        for duty in (wrong_beneficiary, wrong_estate):
            for kind in ("fixed", "hold"):
                payload = book.payload("slice", {"occurrence": "terms-root", "duty": duty,
                    "start": model.quantity(0), "end": model.quantity(1), "kind": kind,
                    "evidence": "invalid-slice-terms", "binding": "rule:one"})
                self.reject_unchanged(book, model.signed(KEY, payload))

    def test_same_batch_identity_with_changed_request_is_rejected(self):
        book, _, _ = self.fixture()
        proposal = self.allocation(book)
        first = book.apply(proposal)
        self.assertEqual(book.apply(proposal), first)
        changed = deepcopy(proposal["payload"])
        changed["data"]["certificate"]["value"] = model.quantity(0)
        self.reject_unchanged(book, model.signed(KEY, changed))
        self.assertEqual(len(book.snapshot()["consumed"]), 1)

    def test_signed_malformed_wire_shapes_fail_without_state_changes(self):
        empty = self.create("empty-schema")
        payload = empty.payload("authority", {"enabled": True, "evidence": "schema:test"})
        payload["revision"] = False
        self.reject_unchanged(empty, model.signed(KEY, payload))
        book, duties, _ = self.fixture()
        for bad_id in ([], {}):
            invalid = book.prepare("closure:bad-id")
            invalid["data"]["batch_id"] = bad_id
            self.reject_unchanged(book, model.signed(KEY, invalid))
        for bad_edges in ([[["a"], duties[0]]], [["a", [duties[0]]]],
                          [["a", duties[0], "extra"]], {"a": duties[0]}):
            payload = book.payload("compatibility", {
                "semantic_root": model.semantic_root(book.snapshot()), "edges": bad_edges,
                "evidence": "schema:compatibility", "contract": "fixed-terms-capacity-only-v1"})
            self.reject_unchanged(book, model.signed(KEY, payload))
        book.apply(self.allocation(book, "closure:full-before-schema"))
        zero = book.prepare("closure:zero-schema")
        self.assertEqual(wire_number(zero["data"]["certificate"]["value"]), 0)
        zero["data"]["certificate"]["allocation"] = {}
        self.reject_unchanged(book, model.signed(KEY, zero))

    def test_zero_allocation_is_consumed_once_and_replays_exactly(self):
        book, _, _ = self.fixture()
        book.apply(self.allocation(book, "closure:full"))
        before = book.snapshot()
        empty = self.allocation(book, "closure:empty")
        receipt = book.apply(empty)
        self.assertEqual(wire_number(receipt["value"]), 0)
        self.assertEqual(receipt["slices"], [])
        after = book.snapshot()
        self.assertEqual(after["slices"], before["slices"])
        self.assertEqual(after["revision"], before["revision"] + 1)
        self.assertEqual(len(after["consumed"]), 2)
        self.assertEqual(book.apply(empty), receipt)
        self.assertEqual(book.snapshot(), after)

    def test_all_six_real_process_crashes_preserve_atomic_recovery(self):
        points = ("before_begin", "after_read", "after_slices", "after_write", "before_commit", "after_commit")
        for point in points:
            with self.subTest(point=point):
                book, _, _ = self.fixture("crash-" + point)
                proposal = self.allocation(book)
                before = book.export()
                command, output = self.worker_command(book, proposal, point, crash=point)
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                stdout, stderr = process.communicate(timeout=30)
                self.assertEqual(process.returncode, 77, stderr)
                self.assertEqual(stdout, "")
                self.assertEqual(stderr, "")
                self.assertFalse(output.exists())
                reopened = ledger.Ledger(book.path, POLICY)
                current = reopened.snapshot()
                committed = point == "after_commit"
                self.assertEqual(current["revision"], before["revision"] + int(committed))
                self.assertEqual(self.independent_total(current)[0], 2 if committed else 0)
                if not committed:
                    self.assertEqual(reopened.export(), before)
                receipt = reopened.apply(proposal)
                self.assertEqual(wire_number(receipt["value"]), 2)
                recovered = reopened.snapshot()
                self.assertEqual(recovered["revision"], before["revision"] + 1)
                self.assertEqual(len(recovered["consumed"]), 1)
                self.assertEqual(self.independent_total(recovered)[0], 2)
                self.assertEqual(reopened.apply(proposal), receipt)
                self.assertEqual(reopened.snapshot(), recovered)
                print("PROCESS_EVIDENCE " + json.dumps({"case": "crash", "point": point,
                      "pid": process.pid, "exit_code": process.returncode,
                      "committed_before_recovery": committed,
                      "recovered_revision": recovered["revision"], "fixed_quantity": "2"}), flush=True)

    def test_real_same_closure_process_race_returns_one_receipt(self):
        book, _, _ = self.fixture()
        before = book.snapshot()
        proposal = self.allocation(book)
        results = self.race(book, [proposal, proposal], "same-closure")
        self.assertEqual([code for code, _ in results], [0, 0])
        self.assertEqual(results[0][1]["receipt"], results[1][1]["receipt"])
        after = book.snapshot()
        self.assertEqual(after["revision"], before["revision"] + 1)
        self.assertEqual(len(after["consumed"]), 1)
        self.assertEqual(self.independent_total(after)[0], 2)

    def test_real_different_closure_race_serializes_shared_physical_credit(self):
        book, _, _ = self.fixture()
        before = book.snapshot()
        results = self.race(book, [self.allocation(book, "closure:left"),
                                  self.allocation(book, "closure:right")], "different-closures")
        self.assertEqual(sorted(code for code, _ in results), [0, 2])
        after = book.snapshot()
        self.assertEqual(after["revision"], before["revision"] + 1)
        self.assertEqual(len(after["consumed"]), 1)
        self.assertEqual(self.independent_total(after)[0], 2)
        resumed = book.apply(self.allocation(book, "closure:resumed"))
        self.assertEqual(wire_number(resumed["value"]), 0)
        self.assertEqual(self.independent_total(book.snapshot())[0], 2)

    def test_pure_journal_replay_is_deterministic_without_database_or_optimizer(self):
        book, _, _ = self.fixture()
        first = book.apply(self.allocation(book, "closure:one"))
        book.apply(self.allocation(book, "closure:zero"))
        exported = book.export()
        expected = book.snapshot()
        with patch.object(ledger, "connect", side_effect=RuntimeError("Database access during replay")), \
             patch.object(model.allocator, "solve", side_effect=RuntimeError("Optimizer access during replay")):
            restored, receipts = ledger.replay(exported, POLICY)
            again, again_receipts = ledger.replay(deepcopy(exported), POLICY)
        self.assertEqual(restored, expected)
        self.assertEqual(again, expected)
        self.assertEqual(again_receipts, receipts)
        self.assertIn(first, receipts)
        self.assertEqual(len(receipts), expected["revision"])
        corrupted = deepcopy(exported)
        corrupted["events"][0]["payload"]["data"]["required"] = model.quantity(999)
        with self.assertRaises(model.Rejected):
            ledger.replay(corrupted, POLICY)

    def test_p09_ascii_economic_identity_and_remaining_whole_quanta(self):
        book = self.create()
        duty = self.duty(book, "p09", required=100)
        origin = book.snapshot()["duties"][duty]["origin"]
        canonical = json.dumps(["economic-duty", *origin], sort_keys=True,
                               separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        self.assertEqual(duty, sha256(canonical).hexdigest())
        self.occurrence(book, "physical-root", 100)
        self.slice(book, "physical-root", duty, 0, 60)
        self.compatibility(book, [("physical-root", duty)])
        receipt = book.apply(self.allocation(book, "closure:p09"))
        self.assertEqual(wire_number(receipt["value"]), 40)
        pieces = book.snapshot()["slices"]
        self.assertEqual([(wire_number(pieces[s]["start"]), wire_number(pieces[s]["end"]))
                          for s in receipt["slices"]], [(Fraction(60), Fraction(100))])
        self.assertEqual(self.independent_total(book.snapshot())[0], 100)
        overlap = model.signed(KEY, book.payload("slice", {
            "occurrence": "physical-root", "duty": duty, "start": model.quantity(0),
            "end": model.quantity(40), "kind": "fixed", "evidence": "p09-reuse-attempt", "binding": "rule:one"}))
        self.reject_unchanged(book, overlap)
        whole_quantum_intervals = [(k - 1, k) for k in range(61, 101)]
        self.assertEqual(whole_quantum_intervals[0], (60, 61))
        self.assertEqual(whole_quantum_intervals[-1], (99, 100))
        self.assertEqual(sum(end - start for start, end in whole_quantum_intervals), 40)


if __name__ == "__main__":
    unittest.main(verbosity=2)
