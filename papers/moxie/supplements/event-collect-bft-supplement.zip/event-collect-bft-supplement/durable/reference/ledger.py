"""SQLite custody for the exact, admitted closed-batch allocation contract."""
from pathlib import Path
import json
import os
import sqlite3
from model import (Rejected, Policy, canonical, digest, genesis, invariant, state_root,
                   transition, prepare, act_payload, signed)


def fault(configured, point):
    if configured == point:
        os._exit(77)


class Connection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()


def connect(path):
    db = sqlite3.connect(path, timeout=20, isolation_level=None, factory=Connection)
    try:
        db.execute("PRAGMA synchronous=FULL")
    except Exception:
        db.close()
        raise
    return db


class Ledger:
    def __init__(self, path, policy):
        self.path, self.policy = Path(path), policy

    @classmethod
    def create(cls, path, policy):
        obj = cls(path, policy)
        obj.path.parent.mkdir(parents=True, exist_ok=True)
        with connect(obj.path) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
              CREATE TABLE IF NOT EXISTS current(
                id INTEGER PRIMARY KEY CHECK(id=1), state BLOB NOT NULL,
                revision INTEGER NOT NULL, root TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS journal(
                sequence INTEGER PRIMARY KEY, event BLOB NOT NULL,
                receipt BLOB NOT NULL, parent TEXT NOT NULL, root TEXT NOT NULL);
            """)
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT state,revision,root FROM current WHERE id=1").fetchone()
            if row is None:
                state = genesis(policy)
                db.execute("INSERT INTO current VALUES(1,?,?,?)",
                           (canonical(state), 0, state_root(state)))
            else:
                obj._decode(row)
            db.commit()
        return obj

    def _decode(self, row):
        if row is None:
            raise Rejected("uninitialized ledger")
        state = json.loads(row[0])
        if canonical(state) != row[0] or state["revision"] != row[1] or state_root(state) != row[2]:
            raise Rejected("stored state binding")
        invariant(state, self.policy)
        return state

    def snapshot(self):
        with connect(self.path) as db:
            db.execute("BEGIN")
            return self._decode(db.execute("SELECT state,revision,root FROM current WHERE id=1").fetchone())

    def prepare(self, closure):
        state = self.snapshot()
        proposal = prepare(state, closure)
        return act_payload(state, "apply", proposal)

    def payload(self, op, data):
        return act_payload(self.snapshot(), op, data)

    def apply(self, envelope, crash=None):
        fault(crash, "before_begin")
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            state = self._decode(db.execute("SELECT state,revision,root FROM current WHERE id=1").fetchone())
            fault(crash, "after_read")
            successor, receipt = transition(state, self.policy, envelope)
            if successor is None:
                row = db.execute("SELECT receipt FROM journal WHERE sequence=?",
                                 (receipt["replay_sequence"],)).fetchone()
                if row is None:
                    raise Rejected("consumed receipt missing")
                return json.loads(row[0])
            fault(crash, "after_slices")
            db.execute("INSERT INTO journal VALUES(?,?,?,?,?)", (receipt["sequence"], canonical(envelope),
                       canonical(receipt), receipt["parent"], receipt["root"]))
            db.execute("UPDATE current SET state=?,revision=?,root=? WHERE id=1 AND revision=? AND root=?",
                       (canonical(successor), successor["revision"], receipt["root"],
                        state["revision"], state_root(state)))
            if db.execute("SELECT changes()").fetchone()[0] != 1:
                raise Rejected("atomic predecessor changed")
            fault(crash, "after_write")
            fault(crash, "before_commit")
            db.commit()
        fault(crash, "after_commit")
        return receipt

    def export(self):
        with connect(self.path) as db:
            db.execute("BEGIN")
            state = self._decode(db.execute("SELECT state,revision,root FROM current WHERE id=1").fetchone())
            events = [json.loads(row[0]) for row in db.execute("SELECT event FROM journal ORDER BY sequence")]
            return {"genesis": genesis(self.policy), "events": events,
                    "revision": state["revision"], "root": state_root(state)}


def replay(exported, policy):
    if exported["genesis"] != genesis(policy):
        raise Rejected("replay genesis")
    state = genesis(policy)
    receipts = []
    for envelope in exported["events"]:
        successor, receipt = transition(state, policy, envelope)
        if successor is None:
            raise Rejected("journal contains a repeated transition")
        state = successor
        receipts.append(receipt)
    if state["revision"] != exported["revision"] or state_root(state) != exported["root"]:
        raise Rejected("replay final binding")
    return state, receipts
