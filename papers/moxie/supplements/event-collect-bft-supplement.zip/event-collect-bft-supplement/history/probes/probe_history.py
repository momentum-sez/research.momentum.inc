"""Regression for a structured release context across SQLite replay."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REF = HERE.parent / 'reference'
sys.path.insert(0, str(REF))
from history_store import HistoryStore
from frozen_protocol import CipherInput


def check(condition, message):
    if not condition:
        raise ValueError(message)


def run():
    bindings = {name: sha256((REF / name).read_bytes()).hexdigest()
                for name in ('history.py', 'history_store.py', 'frozen_protocol.py')}
    with tempfile.TemporaryDirectory(prefix='structured-context-', dir=HERE) as directory:
        path = Path(directory) / 'history.sqlite'
        store = HistoryStore(path)
        cipher = CipherInput()
        context = ('chain', 'epoch-a', 11, 'parent', 'witness', 'o', 'capsule-1')
        first = store.submit('command', b'buy 10', cipher, context)
        again = store.submit('command', b'buy 10', cipher, context)
        check(first == again, 'ImmediateRetryChanged')
        original_share = store.apply('share', {'command': 'command', 'signer': 'validator-1'})
        store = HistoryStore(path)
        after_restart = store.submit('command', b'buy 10', cipher, context)
        share = store.apply('share', {'command': 'command', 'signer': 'validator-1'})
        check(after_restart == first and share == original_share, 'RestartChangedRetry')
        history, sequence, head = store.snapshot()
        check(len(history.service.assignments) == 1, 'DuplicateAssignment')
        check(len(history.service.replies) == 1, 'DuplicateShare')
        try:
            store.submit('command', b'buy 10', cipher, context[:-1] + ('other-capsule',))
        except RuntimeError as error:
            check(str(error) == 'retry changed its capsule or assignment', 'WrongConflictError')
        else:
            raise ValueError('ChangedContextAccepted')
        _, current_sequence, current_head = store.snapshot((sequence, head))
        check((current_sequence, current_head) == (sequence, head), 'RejectedWriteChangedHistory')
        print(json.dumps({'bindings': bindings, 'result': 'pass',
                          'cases': ['structured immediate retry', 'restart and cached share',
                                    'one assignment', 'conflicting context rejects atomically']}, indent=2))


if __name__ == '__main__':
    run()
