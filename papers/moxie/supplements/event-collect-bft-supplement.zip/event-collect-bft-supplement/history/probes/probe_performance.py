"""Finite independent probes for the new performance projection."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REF = HERE.parent / 'reference'
sys.path.insert(0, str(REF))
from performance import report
from store import SettlementStore
from codec import parse, i64
from contract import sign_fixture, occurrence_key


def check(condition, message):
    if not condition:
        raise ValueError(message)


def run():
    results = {'bindings': {name: sha256((REF / name).read_bytes()).hexdigest()
                            for name in ('history.py', 'performance.py')}, 'cases': []}
    with tempfile.TemporaryDirectory(prefix='performance-probe-', dir=HERE) as work:
        store = SettlementStore.create(Path(work) / 'state.sqlite', 200)
        store.create_target('duty', 100, 'payee', 'immutable-due')

        def prepare(attempt, quantity):
            key = store.prepare('duty', attempt, quantity)
            store.commit('arm', {'command': key, 'authority_epoch': 0})
            return key

        def consume(key, sequence, kind, quantity, reference=None, reverses=None):
            ident = None if kind == 'closed' else {
                'provider': store.policy.scope,
                'account': 'payee' if kind == 'payment' else 'payer-account',
                'asset': 'USD', 'unit': 'cent', 'namespace': 'provider-posting-id',
                'epoch': 'account-ledger-1', 'reference': reference}
            body = {'provider': store.policy.scope, 'contract': store.policy.contract,
                    'command': key, 'request': store.read()['commands'][key]['request_digest'],
                    'sequence': sequence, 'kind': kind, 'occurrence': ident,
                    'amount': i64(quantity), 'reverses': reverses}
            store.receive(sign_fixture(body))
            store.consume_local()
            return occurrence_key(ident) if ident else None

        def current(**kwargs):
            journal = store.export_journal()
            return report(journal, policy=store.policy, target='duty', source='immutable-due',
                          expected_head=parse(journal)[-1]['head'], **kwargs)

        key = prepare('original', 100)
        credit = consume(key, 1, 'payment', 100, 'original')
        consume(key, 2, 'closed', 100)
        paid = current()
        consume(key, 3, 'return', 40, 'original-return', credit)
        replacement = prepare('replacement', 20)
        new_credit = consume(replacement, 1, 'payment', 20, 'replacement')
        consume(replacement, 2, 'closed', 20)
        partial = current()
        check((partial['first_completed'], partial['current_effective'], partial['net_recovery'],
               partial['outstanding']) == (1, 80, 20, 20), 'PartialRecoveryMismatch')
        store.cancel_target('duty', 20, 'independent-cancellation-authority')
        cancelled = current()
        check((cancelled['first_completed'], cancelled['current_complete'],
               cancelled['current_effective'], cancelled['cancelled'], cancelled['outstanding'],
               cancelled['net_recovery']) == (1, False, 80, 20, 0, 20), 'CancellationMismatch')
        consume(replacement, 3, 'return', 5, 'replacement-return', new_credit)
        final = current()
        check((final['current_effective'], final['cancelled'], final['outstanding'],
               final['net_recovery'], final['reopening_episodes']) == (75, 20, 5, 15, 2),
              'PostCancellationReturnMismatch')
        results['cases'].append({'case': 'partial recovery, cancellation, later return',
                                 'result': 'pass', 'first_sequence_unchanged':
                                 final['first_sequence'] == paid['first_sequence'],
                                 'final': {name: final[name] for name in
                                           ('current_effective', 'cancelled', 'outstanding',
                                            'net_recovery', 'reopening_episodes')}})
        records = parse(store.export_journal())
        times = [{'sequence': 2, 'head': records[1]['head'], 'time': 10},
                 {'sequence': paid['first_sequence'], 'head': records[paid['first_sequence']-1]['head'],
                  'time': 25}]
        observations = {'binding': final['binding'], 'head': final['head'], 'times': times,
                        'costs': [], 'costs_complete': False,
                        'clock_domain': 'admitted-monotonic-clock', 'time_unit': 'second',
                        'usable': [], 'evidence': 'time-observation-only'}
        measured = current(observations=observations)
        check(measured['cost'] is None and measured['recorded_cost'] == 0,
              'EmptyObservedCostsReportedAsComplete')
        check((measured['first_recorded_latency'], measured['clock_domain'], measured['time_unit']) ==
              (15, 'admitted-monotonic-clock', 'second'), 'MeasurementUnitsLost')
        results['cases'].append({'case': 'time evidence with no supplied cost items',
                                 'cost': measured['cost'],
                                 'recorded_cost': measured['recorded_cost'],
                                 'first_recorded_latency': measured['first_recorded_latency'],
                                 'clock_domain': measured['clock_domain'],
                                 'time_unit': measured['time_unit'], 'result': 'pass'})
        observations['costs_complete'] = True
        zero = current(observations=observations)
        check(zero['cost'] == 0, 'ExplicitCompleteZeroCostLost')
        results['cases'].append({'case': 'explicit complete zero-cost statement', 'result': 'pass'})
        historical = {'sequence': paid['first_sequence'], 'head': records[paid['first_sequence']-1]['head'],
                      'time': 28, 'available': 100, 'evidence': 'historical-beneficiary-access'}
        observations['usable'] = [historical]
        historical_only = current(observations=observations)
        check(historical_only['current_usable'] is None and
              historical_only['beneficiary_usable_latency'] == 18, 'HistoricalAccessBecameCurrent')
        observations['usable'].append({'sequence': final['sequence'], 'head': final['head'],
                                       'time': 40, 'available': 70, 'evidence': 'current-access'})
        available = current(observations=observations)
        check(available['current_usable'] == 70 and available['beneficiary_usable_latency'] == 18,
              'PartialCurrentAccessMismatch')
        observations['usable'][-1]['available'] = 76
        try:
            current(observations=observations)
        except ValueError as error:
            check(str(error) == 'UsableQuantity', 'WrongAvailabilityRejection')
        else:
            raise ValueError('AvailabilityAboveAllocationAccepted')
        observations['usable'][-1]['available'] = 70
        results['cases'].append({'case': 'historical and current beneficiary access',
                                 'result': 'pass', 'historical_does_not_imply_current': True,
                                 'current_usable': 70, 'overstatement_rejected': True})
        observations['clock_domain'] = ''
        try:
            current(observations=observations)
        except ValueError as error:
            check(str(error) == 'ClockDomain', 'WrongClockRejection')
        else:
            raise ValueError('EmptyClockDomainAccepted')
        results['cases'].append({'case': 'empty clock domain', 'result': 'rejected'})
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    run()
