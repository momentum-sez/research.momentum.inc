from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import tempfile
import unittest
import subprocess
import sys

from history import History
from frozen_protocol import CipherInput
from performance import report
from store import SettlementStore
from codec import encode, parse, i64
from contract import sign_fixture, occurrence_key
from history_store import HistoryStore


class HistoryTests(unittest.TestCase):
    def setUp(self):
        self.h = History()
        self.c = CipherInput()

    def fresh(self, **kwargs):
        args = {'alternatives': (b'buy 10', b'buy 20'),
                'capsules': (self.c, replace(self.c, cipher='capsule-2')),
                'metadata': ({'length': 6}, {'length': 6}),
                'equal_prior_view': True, 'session_keys': ('key-1', 'key-2')}
        args.update(kwargs)
        return self.h.fresh_challenge(**args)

    def test_fresh_hidden_challenge_and_public_ciphertext(self):
        public_transcript = [self.c]
        self.assertTrue(public_transcript)
        self.assertTrue(self.fresh())

    def test_disclosed_retry_reuses_assignment_and_exact_share(self):
        before = self.h.submit('command', b'buy 10', self.c, 'witness-a')
        share = self.h.retry_share('command', 'validator-1')
        self.h.disclose('command')
        after = self.h.submit('command', b'buy 10', self.c, 'witness-a')
        self.assertEqual(before['visibility'], 'undisclosed_in_recorded_history')
        self.assertEqual(after['visibility'], 'disclosed')
        self.assertEqual(self.h.retry_share('command', 'validator-1'), share)
        self.assertEqual(len(self.h.service.assignments), 1)
        with self.assertRaisesRegex(RuntimeError, 'earlier semantic disclosure'):
            self.fresh(capsules=(replace(self.c, cipher='new-a'), replace(self.c, cipher='new-b')))

    def test_fresh_outer_id_does_not_restore_terms_secrecy(self):
        self.h.submit('old', b'buy 10', self.c, 'old-context')
        self.h.disclose('old')
        new = replace(self.c, cipher='new', instruction='outer-new')
        status = self.h.submit('new', b'buy 10', new, 'new-context')
        self.assertEqual(status['visibility'], 'disclosed')

    def test_retry_changes_rejected(self):
        self.h.submit('command', b'buy 10', self.c, 'witness-a')
        for semantics, cipher, context in ((b'buy 20', self.c, 'witness-a'),
                                          (b'buy 10', replace(self.c, cipher='other'), 'witness-a'),
                                          (b'buy 10', self.c, 'other')):
            with self.assertRaises(RuntimeError):
                self.h.submit('command', semantics, cipher, context)

    def test_assigned_unrevealed_capsule_and_exposed_session_key(self):
        self.h.submit('command', b'other!', self.c, 'witness-a')
        with self.assertRaisesRegex(RuntimeError, 'earlier release assignment'):
            self.fresh()
        self.h.exposed_keys.add('key-2')
        with self.assertRaisesRegex(RuntimeError, 'session-key exposure'):
            self.fresh()

    def test_eligibility_checks_both_worlds_and_public_leakage(self):
        self.h.disclosed.add(b'buy 20')
        with self.assertRaisesRegex(RuntimeError, 'semantic disclosure'):
            self.fresh()
        for kwargs in ({'equal_prior_view': False}, {'metadata': ({'x': 1}, {'x': 2})},
                       {'alternatives': (b'short', b'longer')}):
            with self.assertRaises(RuntimeError):
                self.fresh(**kwargs)


class PerformanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='p10-history-')
        self.path = Path(self.temp.name)
        self.s = SettlementStore.create(self.path / 'settlement.sqlite', 200)
        self.s.create_target('duty', 100, 'payee', 'immutable-due')

    def tearDown(self):
        self.temp.cleanup()

    def prepare(self, attempt='original', amount=100):
        key = self.s.prepare('duty', attempt, amount)
        self.s.commit('arm', {'command': key, 'authority_epoch': 0})
        return key

    def envelope(self, key, sequence, kind, amount, reference=None, reverses=None):
        policy, state = self.s.policy, self.s.read()
        occurrence = None
        if kind in ('payment', 'return'):
            occurrence = {'provider': policy.scope,
                          'account': 'payee' if kind == 'payment' else 'payer-account',
                          'asset': 'USD', 'unit': 'cent', 'namespace': 'provider-posting-id',
                          'epoch': 'account-ledger-1', 'reference': reference}
        return sign_fixture({'provider': policy.scope, 'contract': policy.contract,
                             'command': key, 'request': state['commands'][key]['request_digest'],
                             'sequence': sequence, 'kind': kind, 'occurrence': occurrence,
                             'amount': i64(amount), 'reverses': reverses})

    def consume(self, envelope):
        self.s.receive(envelope)
        self.s.consume_local()
        body = parse(envelope['body'].encode())
        return occurrence_key(body['occurrence']) if body['occurrence'] else None

    def report(self, **kwargs):
        journal = self.s.export_journal()
        return report(journal, policy=self.s.policy, target='duty', source='immutable-due',
                      expected_head=parse(journal)[-1]['head'], **kwargs)

    def cycle(self):
        key = self.prepare()
        payment = self.consume(self.envelope(key, 1, 'payment', 100, 'original-credit'))
        self.consume(self.envelope(key, 2, 'closed', 100))
        complete = self.report()
        self.consume(self.envelope(key, 3, 'return', 40, 'returned', payment))
        reopened = self.report()
        retry = self.prepare('replacement', 40)
        replacement = self.consume(self.envelope(retry, 1, 'payment', 40, 'replacement-credit'))
        self.consume(self.envelope(retry, 2, 'closed', 40))
        recovered = self.report()
        self.consume(self.envelope(retry, 3, 'return', 10, 'replacement-return', replacement))
        return complete, reopened, recovered, self.report()

    def test_reversal_and_recovery_preserve_first_count(self):
        complete, reopened, recovered, final = self.cycle()
        self.assertEqual([x['first_completed'] for x in (complete, reopened, recovered, final)], [1]*4)
        self.assertEqual([x['current_effective'] for x in (complete, reopened, recovered, final)], [100, 60, 100, 90])
        self.assertEqual([x['outstanding'] for x in (complete, reopened, recovered, final)], [0, 40, 0, 10])
        self.assertEqual([x['net_recovery'] for x in (complete, reopened, recovered, final)], [0, 0, 40, 30])
        self.assertEqual(final['reopening_episodes'], 2)
        self.assertEqual(final['reopening_rate'], [1, 1])
        self.assertEqual(final['first_sequence'], complete['first_sequence'])
        self.assertEqual(final['cost'], None)
        self.assertEqual(final['beneficiary_usable_latency'], None)

    def test_pending_link_is_explicit_and_does_not_fake_completion(self):
        key = self.prepare()
        payment = self.envelope(key, 2, 'payment', 100, 'late-credit')
        oid = occurrence_key(parse(payment['body'].encode())['occurrence'])
        self.consume(self.envelope(key, 1, 'return', 40, 'early-return', oid))
        pending = self.report()
        self.assertEqual(pending['first_completed'], 0)
        self.assertEqual(len(pending['pending_return_links']), 1)
        self.consume(payment)
        current = self.report()
        self.assertEqual((current['current_effective'], current['outstanding']), (60, 40))
        self.assertEqual(current['first_completed'], 0)

    def test_cancellation_does_not_count_as_performance(self):
        self.s.cancel_target('duty', 100, 'cancellation-authority')
        current = self.report()
        self.assertEqual((current['first_completed'], current['current_effective'], current['cancelled']), (0, 0, 100))
        self.assertEqual(current['outstanding'], 0)
        self.assertFalse(current['current_complete'])

    def test_duplicate_observation_and_restart_are_invariant(self):
        key = self.prepare()
        envelope = self.envelope(key, 1, 'payment', 100, 'same-credit')
        self.consume(envelope)
        before = self.report()
        self.consume(envelope)
        self.s = SettlementStore(self.path / 'settlement.sqlite')
        after = self.report(previous=(before['sequence'], before['head']))
        for field in ('first_completed', 'first_sequence', 'current_effective', 'outstanding', 'net_recovery'):
            self.assertEqual(before[field], after[field])
        self.assertEqual(len(after['evidence']), 1)

    def test_altered_or_truncated_history_rejected(self):
        complete, _, _, current = self.cycle()
        records = parse(self.s.export_journal())
        for field in ('previous', 'state_hash', 'head'):
            bad = deepcopy(records)
            bad[-1][field] = 'wrong'
            with self.assertRaises(ValueError):
                report(encode(bad), policy=self.s.policy, target='duty', source='immutable-due', expected_head=current['head'])
        with self.assertRaisesRegex(ValueError, 'UnadmittedHead'):
            report(encode(records[:complete['sequence']]), policy=self.s.policy, target='duty', source='immutable-due', expected_head=current['head'])
        with self.assertRaisesRegex(ValueError, 'PreviousPrefixMissing'):
            self.report(previous=(complete['sequence'], 'other-history'))

    def test_economic_source_binding_is_not_an_attempt(self):
        self.cycle()
        with self.assertRaisesRegex(ValueError, 'SourceBinding'):
            report(self.s.export_journal(), policy=self.s.policy, target='duty', source='another-due', expected_head=self.report()['head'])

    def test_explicit_measurement_evidence_and_units(self):
        key = self.prepare()
        self.consume(self.envelope(key, 1, 'payment', 100, 'credit'))
        current = self.report()
        records = parse(self.s.export_journal())
        first = current['first_sequence']
        obs = {'binding': current['binding'], 'head': current['head'],
               'times': [{'sequence': 2, 'head': records[1]['head'], 'time': 10},
                         {'sequence': first, 'head': records[first-1]['head'], 'time': 25}],
               'costs': [{'id': 'fee-occurrence', 'amount': 3, 'asset': 'USD', 'unit': 'cent'}],
               'costs_complete': True, 'clock_domain': 'admitted-clock', 'time_unit': 'millisecond',
               'usable': [],
               'evidence': 'admitted-measurement-receipt'}
        result = self.report(observations=obs)
        self.assertEqual((result['cost'], result['first_recorded_latency']), (3, 15))
        self.assertIsNone(result['beneficiary_usable_latency'])
        attested = deepcopy(obs)
        attested['usable'] = [{'sequence': current['sequence'], 'head': current['head'],
                              'time': 40, 'available': 100, 'evidence': 'beneficiary-access-attestation'}]
        available = self.report(observations=attested)
        self.assertEqual((available['beneficiary_usable_latency'], available['current_usable']), (30, 100))
        bad_available = deepcopy(attested)
        bad_available['usable'][0]['available'] = 101
        with self.assertRaisesRegex(ValueError, 'UsableQuantity'):
            self.report(observations=bad_available)
        incomplete = deepcopy(obs)
        incomplete['costs'] = []
        incomplete['costs_complete'] = False
        missing = self.report(observations=incomplete)
        self.assertEqual(missing['recorded_cost'], 0)
        self.assertIsNone(missing['cost'])
        for mutation in ('unit', 'duplicate', 'negative', 'time', 'head'):
            bad = deepcopy(obs)
            if mutation == 'unit': bad['costs'][0]['unit'] = 'dollar'
            if mutation == 'duplicate': bad['costs'] *= 2
            if mutation == 'negative': bad['costs'][0]['amount'] = -1
            if mutation == 'time': bad['times'][1]['time'] = 1
            if mutation == 'head': bad['head'] = 'other'
            with self.assertRaises(ValueError): self.report(observations=bad)


class DurableHistoryTests(unittest.TestCase):
    def test_structured_release_context_retries_after_json_roundtrip(self):
        with tempfile.TemporaryDirectory(prefix='p10-structured-context-') as directory:
            path = Path(directory) / 'history.sqlite'
            context = ('chain', 'epoch-a', 11, 'parent', 'witness', 'occurrence', 'capsule-1')
            first = HistoryStore(path).submit('command', b'buy 10', CipherInput(), context)
            replayed = HistoryStore(path).submit('command', b'buy 10', CipherInput(), context)
            self.assertEqual(first, replayed)
            self.assertEqual(len(HistoryStore(path).snapshot()[0].service.assignments), 1)

    def test_disclosure_and_exact_share_survive_process_exit(self):
        with tempfile.TemporaryDirectory(prefix='p10-release-history-') as directory:
            path = Path(directory) / 'history.sqlite'
            store = HistoryStore(path)
            store.submit('command', b'buy 10', CipherInput(), 'witness')
            first = store.apply('share', {'command': 'command', 'signer': 'validator-1'})
            store.apply('disclose', {'command': 'command'})
            _, sequence, head = store.snapshot()
            code = ('from history_store import HistoryStore; import sys; '
                    "HistoryStore(sys.argv[1]).apply('share', "
                    "{'command':'command','signer':'validator-1'}, crash=sys.argv[2])")
            for point in ('before_commit', 'after_commit'):
                run = subprocess.run([sys.executable, '-B', '-c', code, str(path), point], capture_output=True)
                self.assertEqual(run.returncode, 77, run.stderr.decode())
                reopened = HistoryStore(path)
                history, _, _ = reopened.snapshot(anchor=(sequence, head))
                self.assertEqual(history.status('command')['visibility'], 'disclosed')
                self.assertEqual(len(history.service.assignments), 1)
                self.assertEqual(reopened.apply('share', {'command': 'command', 'signer': 'validator-1'}), first)

    def test_history_anchor_detects_wrong_prefix(self):
        with tempfile.TemporaryDirectory(prefix='p10-history-anchor-') as directory:
            store = HistoryStore(Path(directory) / 'history.sqlite')
            store.submit('command', b'buy 10', CipherInput(), 'witness')
            with self.assertRaisesRegex(ValueError, 'HistoryAnchorConflict'):
                store.snapshot(anchor=(1, 'other'))
            with self.assertRaisesRegex(ValueError, 'HistoryAnchorMissing'):
                store.snapshot(anchor=(2, 'other'))


if __name__ == '__main__':
    unittest.main()
