"""Exact historical and current performance from the actual Op journal.

The caller admits the journal head and its institutional source. A hash chain
alone establishes neither provider finality nor beneficiary access to value.
"""
from pathlib import Path
from hashlib import sha256
import json
import sys

OP = Path(__file__).with_name('op')
for name, expected in json.loads((OP / 'SOURCE-BINDINGS.json').read_text()).items():
    if sha256((OP / name).read_bytes()).hexdigest() != expected:
        raise ValueError('ChangedOpDependency')
sys.path.insert(0, str(OP))
from codec import parse, digest, i64
from model import apply_event, target_view


def require(condition, message):
    if not condition:
        raise ValueError(message)


def report(journal_bytes, *, policy, target, source, expected_head,
           previous=None, observations=None):
    """Replay immutable target history at one admitted head.

    observations is optional, separately admitted measurement evidence. It
    supplies journal-bound times and cost facts. Missing measures remain null.
    """
    records = parse(journal_bytes)
    require(bool(records), 'EmptyJournal')
    state, head, bound = None, 'genesis', None
    first, opened, episodes, seen_open = None, False, 0, False
    recovery_payments, trace, anchors = set(), [], {0: 'genesis'}
    initial_sequence = None
    observed_occurrences = set()
    for sequence, record in enumerate(records, 1):
        require(set(record) == {'sequence', 'event', 'previous', 'state_hash', 'head'}, 'JournalShape')
        require(record['sequence'] == sequence and record['previous'] == head, 'JournalOrder')
        state = apply_event(state, record['event'], policy)
        require(digest('settlement-state', state) == record['state_hash'], 'JournalState')
        head = digest('settlement-receipt', {k: record[k] for k in
                      ('sequence', 'event', 'previous', 'state_hash')})
        require(head == record['head'], 'JournalHash')
        anchors[sequence] = head
        if target not in state['targets']:
            continue
        row = state['targets'][target]
        current = {'target': target, 'source': row['source'],
                   'quantity': row['quantity'], 'payee': row['payee'],
                   'pool': state['pool']['id'], 'payer': state['pool']['account'],
                   'asset': state['pool']['asset'], 'unit': state['pool']['unit']}
        require(current['source'] == source, 'SourceBinding')
        require(bound is None or current == bound, 'TargetChanged')
        bound = current
        if initial_sequence is None:
            initial_sequence = sequence
        for oid, occurrence in state['occurrences'].items():
            if occurrence['target'] == target and oid not in observed_occurrences:
                if opened and occurrence['kind'] == 'payment':
                    recovery_payments.add(oid)
                observed_occurrences.add(oid)
        view = target_view(state, target)
        outstanding = int(view['outstanding'])
        if first is None and view['status'] == 'paid':
            first = sequence
        if first is not None and outstanding > 0:
            if not seen_open:
                episodes += 1
            opened = True
            seen_open = True
        else:
            seen_open = False
        trace.append({'sequence': sequence, 'head': head,
                      'effective': int(view['paid']) - int(view['returned']),
                      'outstanding': outstanding, 'status': view['status']})
    require(bound is not None, 'UnknownTarget')
    require(head == expected_head, 'UnadmittedHead')
    if previous is not None:
        require(type(previous) in (tuple, list) and len(previous) == 2 and
                anchors.get(previous[0]) == previous[1], 'PreviousPrefixMissing')
    view = target_view(state, target)
    gross, returned = int(view['paid']), int(view['returned'])
    effective = gross - returned
    cancelled, outstanding = int(view['cancelled']), int(view['outstanding'])
    require(int(bound['quantity']) == effective + cancelled + outstanding,
            'PerformanceConservation')
    recovery = sum(int(state['occurrences'][o]['allocated']) -
                   int(state['occurrences'][o]['returned_allocated'])
                   for o in recovery_payments)
    evidence = []
    for oid in sorted(observed_occurrences):
        occurrence = state['occurrences'][oid]
        aid = occurrence['first_assertion']
        entry = state['assertions'][aid]
        require(aid in state['consumed'], 'UnconsumedOccurrenceEvidence')
        evidence.append({'occurrence': oid, 'assertion': aid, 'envelope': entry['envelope']})
    result = {'binding': bound, 'sequence': len(records), 'head': head,
              'first_completed': int(first is not None), 'first_sequence': first,
              'current_complete': view['status'] == 'paid', 'status': view['status'],
              'gross_allocated': gross, 'reversed_allocation': returned,
              'current_effective': effective, 'cancelled': cancelled,
              'outstanding': outstanding, 'net_recovery': recovery,
              'reopened_ever': opened, 'reopening_episodes': episodes,
              'reopening_rate': [int(opened), 1] if first is not None else None,
              'pending_return_links': sorted(o for o in state['pending_returns']
                                             if state['occurrences'][o]['target'] == target),
              'cost': None, 'recorded_cost': None, 'first_recorded_latency': None,
              'clock_domain': None, 'time_unit': None,
              'beneficiary_usable_latency': None, 'current_usable': None,
              'measurement_evidence': None,
              'evidence': evidence, 'trace': trace}
    if observations is not None:
        require(type(observations) is dict and set(observations) ==
                {'binding', 'head', 'times', 'costs', 'costs_complete',
                 'clock_domain', 'time_unit', 'usable', 'evidence'}, 'MeasurementShape')
        require(observations['binding'] == bound and observations['head'] == head, 'MeasurementBinding')
        require(type(observations['evidence']) is str and bool(observations['evidence']), 'MeasurementEvidence')
        require(type(observations['costs_complete']) is bool, 'CostCompleteness')
        require(all(type(observations[k]) is str and bool(observations[k])
                    for k in ('clock_domain', 'time_unit')), 'ClockDomain')
        result['clock_domain'] = observations['clock_domain']
        result['time_unit'] = observations['time_unit']
        times = observations['times']
        require(type(times) is list, 'MeasurementTimes')
        by_sequence, last = {}, (-1, -1)
        for stamp in times:
            require(type(stamp) is dict and set(stamp) == {'sequence', 'head', 'time'}, 'TimeShape')
            s, t = stamp['sequence'], stamp['time']
            require(type(s) is int and type(t) is int and t >= 0 and
                    s > last[0] and t >= last[1] and anchors.get(s) == stamp['head'], 'TimeBinding')
            by_sequence[s] = t
            last = (s, t)
        if first is not None and initial_sequence in by_sequence and first in by_sequence:
            result['first_recorded_latency'] = by_sequence[first] - by_sequence[initial_sequence]
        costs, used, total = observations['costs'], set(), 0
        require(type(costs) is list, 'CostList')
        for item in costs:
            require(type(item) is dict and set(item) == {'id', 'amount', 'asset', 'unit'}, 'CostShape')
            require(type(item['id']) is str and bool(item['id']) and item['id'] not in used, 'DuplicateCost')
            require(type(item['amount']) is int and item['amount'] >= 0, 'CostAmount')
            require((item['asset'], item['unit']) == (bound['asset'], bound['unit']), 'CostUnit')
            used.add(item['id'])
            total += item['amount']
        result['recorded_cost'] = total
        result['cost'] = total if observations['costs_complete'] else None
        usable, seen_sequences, first_usable = observations['usable'], set(), None
        require(type(usable) is list, 'UsableList')
        views = {v['sequence']: v for v in trace}
        for item in usable:
            require(type(item) is dict and set(item) ==
                    {'sequence', 'head', 'time', 'available', 'evidence'}, 'UsableShape')
            s, t, available = item['sequence'], item['time'], item['available']
            require(type(s) is int and s in views and s not in seen_sequences and
                    anchors[s] == item['head'], 'UsableHead')
            require(type(t) is int and t >= 0 and type(available) is int and
                    0 <= available <= views[s]['effective'], 'UsableQuantity')
            require(type(item['evidence']) is str and bool(item['evidence']), 'UsableEvidence')
            if s in by_sequence:
                require(t >= by_sequence[s], 'UsableAcknowledgementTime')
            if initial_sequence in by_sequence:
                require(t >= by_sequence[initial_sequence], 'UsableBeforeAdmission')
            seen_sequences.add(s)
            full = available == int(bound['quantity']) and views[s]['status'] == 'paid'
            if full and (first_usable is None or t < first_usable):
                first_usable = t
            if s == len(records):
                result['current_usable'] = available
        if first_usable is not None and initial_sequence in by_sequence:
            result['beneficiary_usable_latency'] = first_usable - by_sequence[initial_sequence]
        result['measurement_evidence'] = observations['evidence']
    return result
