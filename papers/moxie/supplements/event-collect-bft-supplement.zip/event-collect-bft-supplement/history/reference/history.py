"""History monitor for the protocol fixture. This is not encryption code.

Semantic values belong to the private experiment. They are never wire metadata.
The monitor models recorded disclosure, not all knowledge of a real adversary.
"""
from dataclasses import dataclass, field
from frozen_protocol import ReleaseService, require


@dataclass
class History:
    service: ReleaseService = field(default_factory=ReleaseService)
    commands: dict = field(default_factory=dict)
    disclosed: set = field(default_factory=set)
    exposed_keys: set = field(default_factory=set)

    def submit(self, command, semantics, cipher, context):
        old = self.commands.get(command)
        if old is not None:
            require(old['semantics'] == semantics, 'same command changed its meaning')
            require(old['cipher'] == cipher and old['context'] == context,
                    'retry changed its capsule or assignment')
            return self.status(command)
        self.service.assign(cipher, context)
        self.commands[command] = {'semantics': semantics, 'cipher': cipher,
                                  'context': context}
        return self.status(command)

    def disclose(self, command):
        self.disclosed.add(self.commands[command]['semantics'])

    def status(self, command):
        row = self.commands[command]
        return {'command': command, 'context': row['context'],
                'visibility': 'disclosed' if row['semantics'] in self.disclosed
                else 'undisclosed_in_recorded_history',
                'assignments': 1}

    def retry_share(self, command, signer):
        row = self.commands[command]
        return self.service.release(row['cipher'], row['context'], signer)

    def fresh_challenge(self, alternatives, capsules, metadata, *,
                        equal_prior_view, session_keys):
        """Check both alternatives before choosing a challenge bit.

        equal_prior_view is an experiment premise, not a computed crypto proof.
        Excluding previously disclosed equal bytes is a conservative policy.
        Standard encryption secrecy permits knowledge of both candidate strings.
        Capsule exposure alone remains allowed. Assignment consumes freshness.
        """
        require(len(alternatives) == len(capsules) == len(metadata) ==
                len(session_keys) == 2, 'two challenge branches required')
        require(type(equal_prior_view) is bool and equal_prior_view,
                'prior history distinguishes the branch')
        require(all(type(x) is bytes for x in alternatives), 'plaintext bytes')
        require(len(alternatives[0]) == len(alternatives[1]), 'public length differs')
        require(metadata[0] == metadata[1], 'public metadata differs')
        require(all(x not in self.disclosed for x in alternatives),
                'earlier semantic disclosure')
        require(all(x not in self.exposed_keys for x in session_keys),
                'earlier session-key exposure')
        require(all((c.key, c.cipher) not in self.service.assignments
                    for c in capsules), 'earlier release assignment')
        return True
