"""Private SQLite history for the exact release fixture.

Replay reuses its actual assignment and share-response methods. The store is a
single admitted authority. Its chain does not detect rollback without an anchor.
"""
from dataclasses import asdict
from hashlib import sha256
import json
import os
import sqlite3
from history import History
from frozen_protocol import CipherInput


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def transition(history, event):
    kind, data = event['kind'], event['data']
    if kind == 'submit':
        return history.submit(data['command'], bytes.fromhex(data['semantics']),
                              CipherInput(**data['cipher']), data['context'])
    if kind == 'disclose':
        history.disclose(data['command'])
        return history.status(data['command'])
    if kind == 'share':
        return list(history.retry_share(data['command'], data['signer']))
    if kind == 'expose_key':
        history.exposed_keys.add(data['key'])
        return data['key']
    raise ValueError('UnknownHistoryEvent')


class HistoryStore:
    def __init__(self, path):
        self.path = str(path)
        with sqlite3.connect(self.path) as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('CREATE TABLE IF NOT EXISTS history('
                       'sequence INTEGER PRIMARY KEY,event BLOB,result BLOB,parent TEXT,head TEXT)')

    def _replay(self, db, anchor=None):
        history, head, seen = History(), 'genesis', anchor in (None, (0, 'genesis'))
        sequence = 0
        for expected, row in enumerate(db.execute('SELECT * FROM history ORDER BY sequence'), 1):
            sequence, raw, result, parent, recorded = row
            if sequence != expected or parent != head:
                raise ValueError('HistoryOrder')
            value = transition(history, json.loads(raw))
            if wire(value) != result:
                raise ValueError('HistoryResult')
            head = sha256(wire([sequence, parent, json.loads(raw), value])).hexdigest()
            if head != recorded:
                raise ValueError('HistoryHead')
            if anchor is not None and sequence == anchor[0]:
                if head != anchor[1]:
                    raise ValueError('HistoryAnchorConflict')
                seen = True
        if not seen:
            raise ValueError('HistoryAnchorMissing')
        return history, sequence, head

    def snapshot(self, anchor=None):
        with sqlite3.connect(self.path) as db:
            db.execute('BEGIN')
            return self._replay(db, anchor)

    def apply(self, kind, data, crash=None):
        # Apply exactly the representation that replay will decode.
        event = json.loads(wire({'kind': kind, 'data': data}))
        with sqlite3.connect(self.path, timeout=20) as db:
            db.execute('PRAGMA synchronous=FULL')
            db.execute('BEGIN IMMEDIATE')
            history, sequence, parent = self._replay(db)
            result = transition(history, event)
            head = sha256(wire([sequence+1, parent, event, result])).hexdigest()
            db.execute('INSERT INTO history VALUES(?,?,?,?,?)',
                       (sequence+1, wire(event), wire(result), parent, head))
            if crash == 'before_commit': os._exit(77)
            db.commit()
        if crash == 'after_commit': os._exit(77)
        return result

    def submit(self, command, semantics, cipher, context, crash=None):
        return self.apply('submit', {'command': command, 'semantics': semantics.hex(),
                                    'cipher': asdict(cipher), 'context': context}, crash)
