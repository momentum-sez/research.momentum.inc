"""Pure serialized settlement transitions over one shared funding authority.

Amounts in stored projections are decimal strings. Arithmetic uses exact Python
integers. Individual external/request quantities use the pinned signed64 codec.
"""
from copy import deepcopy
from codec import digest, decode_i64, quantity, integer
from contract import occurrence_key

def target_view(state, target):
    row = state["targets"][target]
    payments = [o for o in state["occurrences"].values() if o["kind"] == "payment" and o["target"] == target]
    paid = sum(int(o["allocated"]) for o in payments)
    returned = sum(int(o["returned_allocated"]) for o in payments)
    total = int(row["quantity"])
    cancelled = int(row["cancelled"])
    reserved = sum(int(c["reserved"]) for c in state["commands"].values() if c["target"] == target)
    outstanding = total - paid + returned - cancelled
    impaired = any(a["target"] == target for a in state["alerts"].values())
    pending = any(s["target"] == target for oid, s in state["occurrences"].items() if oid in state["pending_returns"])
    status = "impaired" if impaired else "pending" if pending else "paid" if outstanding == 0 and cancelled == 0 else "cancelled" if outstanding == 0 else "partial" if paid > returned else "pending"
    return {"target": target, "source": row["source"], "quantity": str(total), "paid": str(paid), "returned": str(returned), "cancelled": str(cancelled), "outstanding": str(outstanding), "reserved": str(reserved), "status": status}

def pool_view(state):
    cash = int(state["pool"]["cash"])
    reserved = sum(int(c["reserved"]) for c in state["commands"].values())
    unmatched = int(state["pool"]["unmatched_returns"])
    deficit = max(0, reserved + unmatched - cash)
    return {"pool": state["pool"]["id"], "cash": str(cash), "reserved": str(reserved), "unmatched_returns": str(unmatched), "free": str(max(0, cash - reserved - unmatched)), "deficit": str(deficit), "status": "impaired" if deficit or state["alerts"] else "funded"}

def command_view(state, key):
    c = state["commands"][key]
    impaired = any(a["command"] == key for a in state["alerts"].values()) or pool_view(state)["status"] == "impaired"
    status = "impaired" if impaired else "closed" if c["closed"] else "uncertain" if c["uncertain"] else "pending"
    return {"command": key, "target": c["target"], "requested": c["quantity"], "paid_occurrences": c["gross"], "reserved": c["reserved"], "closed": c["closed"], "dispatch": c["dispatch"], "status": status}

def _alert(s, code, key, aid):
    target = s["commands"][key]["target"] if key in s["commands"] else None
    ident = digest("settlement-alert", {"code": code, "command": key, "assertion": aid})
    s["alerts"][ident] = {"code": code, "command": key, "target": target, "assertion": aid}

def _authorized(s, epoch):
    if not s["pool"]["permitted"] or epoch != s["pool"]["authority_epoch"]:
        raise ValueError("CURRENT_USE_AUTHORITY")

def _ready(s, key, epoch):
    _authorized(s, epoch)
    c = s["commands"][key]
    if c["closed"] or c["dispatch"] == "Cancelled" or int(c["reserved"]) == 0:
        raise ValueError("EXECUTION_RIGHT_CLOSED")
    if pool_view(s)["status"] != "funded":
        raise ValueError("FUNDING_IMPAIRED")

def _receive(s, envelope, policy):
    aid, body = policy.verify(envelope)
    if aid in s["assertions"]:
        if s["assertions"][aid]["envelope"] != envelope:
            raise ValueError("ASSERTION_ID_CONFLICT")
        return
    s["received"] += 1
    key = body["command"]
    entry = {"body": body, "envelope": envelope, "order": s["received"], "status": "pending"}
    s["assertions"][aid] = entry
    c = s["commands"].get(key)
    if c is None or c["request_digest"] != body["request"]:
        entry["status"] = "conflict"
        _alert(s, "REQUEST_BINDING", key, aid)
        return
    slot = key + ":" + str(body["sequence"])
    old = s["slots"].get(slot)
    if old is not None and old != aid:
        entry["status"] = "conflict"
        if s["assertions"][old]["status"] == "pending":
            s["assertions"][old]["status"] = "conflict"
        _alert(s, "STREAM_EQUIVOCATION", key, aid)
        return
    s["slots"][slot] = aid

def _schedule(s):
    frontiers = dict(s["frontiers"])
    pending = {a: v for a, v in s["assertions"].items() if v["status"] == "pending"}
    result = []
    while pending:
        eligible = [(v["order"], a) for a, v in pending.items() if v["body"]["sequence"] == frontiers.get(v["body"]["command"], 0) + 1]
        if not eligible:
            break
        _, aid = min(eligible)
        body = pending.pop(aid)["body"]
        result.append(aid)
        frontiers[body["command"]] = body["sequence"]
    return result

def _consume_occurrence(s, key, aid, body):
    c = s["commands"][key]
    target = s["targets"][c["target"]]
    ident = body["occurrence"]
    q = decode_i64(body["amount"])
    expected_account = target["payee"] if body["kind"] == "payment" else s["pool"]["account"]
    if (ident["account"], ident["asset"], ident["unit"]) != (expected_account, s["pool"]["asset"], s["pool"]["unit"]):
        _alert(s, "OCCURRENCE_SCOPE", key, aid)
        return
    oid = occurrence_key(ident)
    facts = {"identity": ident, "kind": body["kind"], "quantity": str(q), "reverses": body["reverses"]}
    old = s["occurrences"].get(oid)
    if old:
        if any(old[k] != v for k, v in facts.items()) or old["command"] != key:
            _alert(s, "OCCURRENCE_CONFLICT", key, aid)
            if old["command"] != key:
                _alert(s, "OCCURRENCE_CONFLICT", old["command"], aid)
        return
    o = dict(facts, command=key, target=c["target"], first_assertion=aid, allocated="0", returned_allocated="0", returned_unallocated="0", unmatched="0")
    if body["kind"] == "payment":
        remaining = max(0, int(c["quantity"]) - int(c["gross"]))
        if c["dispatch"] != "Armed":
            _alert(s, "EFFECT_WITHOUT_DISPATCH", key, aid)
        allowed = min(q, remaining, int(target_view(s, c["target"])["outstanding"])) if not c["closed"] and c["dispatch"] == "Armed" else 0
        o["allocated"] = str(allowed)
        if q > remaining or c["closed"] or allowed < q:
            _alert(s, "EXCESS_FORWARD_EFFECT", key, aid)
        c["gross"] = str(int(c["gross"]) + q)
        c["reserved"] = str(max(0, int(c["reserved"]) - q))
        s["pool"]["cash"] = str(int(s["pool"]["cash"]) - q)
    else:
        s["pool"]["cash"] = str(int(s["pool"]["cash"]) + q)
        s["pool"]["unmatched_returns"] = str(int(s["pool"]["unmatched_returns"]) + q)
        o["unmatched"] = str(q)
        s["pending_returns"][oid] = {"assertion": aid, "order": s["assertions"][aid]["order"]}
    s["occurrences"][oid] = o
    _resolve_returns(s)

def _resolve_returns(s):
    # Cash is recorded once. Its unresolved attribution remains encumbered.
    ordered = sorted(s["pending_returns"], key=lambda k: (s["pending_returns"][k]["order"], k))
    for oid in ordered:
        o = s["occurrences"][oid]
        pending = s["pending_returns"][oid]
        original = s["occurrences"].get(o["reverses"])
        if original is None:
            continue
        if original["kind"] != "payment" or original["command"] != o["command"]:
            _alert(s, "RETURN_BINDING", o["command"], pending["assertion"])
            continue
        q = int(o["quantity"])
        unallocated = int(original["quantity"]) - int(original["allocated"]) - int(original["returned_unallocated"])
        recovered_unallocated = min(q, max(0, unallocated))
        returned_allocation = min(q-recovered_unallocated, int(original["allocated"])-int(original["returned_allocated"]))
        excess = q-recovered_unallocated-returned_allocation
        original["returned_unallocated"] = str(int(original["returned_unallocated"])+recovered_unallocated)
        original["returned_allocated"] = str(int(original["returned_allocated"])+returned_allocation)
        o["allocated"] = str(returned_allocation)
        o["unmatched"] = str(excess)
        s["pool"]["unmatched_returns"] = str(int(s["pool"]["unmatched_returns"])-recovered_unallocated-returned_allocation)
        if excess:
            _alert(s, "EXCESS_RETURN", o["command"], pending["assertion"])
        del s["pending_returns"][oid]


def _consume(s, aid):
    entry = s["assertions"][aid]
    body = entry["body"]
    key = body["command"]
    c = s["commands"][key]
    if entry["status"] != "pending":
        # A newly received equivocation can invalidate an already frozen member.
        _alert(s, "FROZEN_MEMBER_CONFLICT", key, aid)
        return
    if body["sequence"] != s["frontiers"].get(key, 0) + 1:
        _alert(s, "FROZEN_STREAM_BLOCKED", key, aid)
        return
    kind = body["kind"]
    if kind in {"payment", "return"}:
        _consume_occurrence(s, key, aid, body)
    elif kind == "closed":
        if decode_i64(body["amount"]) != int(c["gross"]):
            _alert(s, "CLOSURE_TOTAL_CONFLICT", key, aid)
        else:
            c["closed"] = True
            c["closure_assertion"] = aid
            if not any(a["command"] == key for a in s["alerts"].values()):
                c["reserved"] = "0"
    elif decode_i64(body["amount"]) < int(c["gross"]):
        _alert(s, "PROGRESS_CONFLICT", key, aid)
    # Progress assertions never create credit or release capacity.
    c["uncertain"] = False
    entry["status"] = "applied"
    s["frontiers"][key] = body["sequence"]
    s["consumed"][aid] = {"command": key, "epoch": s["active_epoch"]["root"], "sequence": body["sequence"]}

def apply_event(state, event, policy):
    kind, data = event["kind"], event["data"]
    if kind == "initialize":
        if state is not None:
            raise ValueError("ALREADY_INITIALIZED")
        funding = integer(decode_i64(data["funding"]))
        if funding < 0:
            raise ValueError("NEGATIVE_INITIAL_FUNDING")
        s = {"pool": {"id": data["pool"], "asset": data["asset"], "unit": data["unit"], "account": data["account"], "initial": str(funding), "cash": str(funding), "unmatched_returns": "0", "permitted": True, "authority_epoch": 0, "authority_source_sequence": 0}, "targets": {}, "commands": {}, "attempts": {}, "assertions": {}, "slots": {}, "frontiers": {}, "occurrences": {}, "pending_returns": {}, "alerts": {}, "funding": {}, "authority_events": {}, "authority_sequences": {}, "cancellations": {}, "consumed": {}, "received": 0, "epochs": [], "active_epoch": None}
        return s
    if state is None:
        raise ValueError("UNINITIALIZED")
    s = deepcopy(state)
    if kind == "target":
        q = quantity(decode_i64(data["quantity"]))
        ident = data["id"]
        row = {"quantity": str(q), "payee": data["payee"], "source": data["source"], "cancelled": "0"}
        if ident in s["targets"]:
            if any(s["targets"][ident][k] != row[k] for k in ("quantity", "payee", "source")):
                raise ValueError("FIXED_TARGET_CONFLICT")
        else:
            s["targets"][ident] = row
    elif kind == "authority":
        if type(data["permitted"]) is not bool or type(data["source_sequence"]) is not int or data["source_sequence"] < 1:
            raise ValueError("AUTHORITY_VALUE")
        evidence = data["evidence"]
        payload = {"permitted": data["permitted"], "source_sequence": data["source_sequence"]}
        prior = s["authority_events"].get(evidence)
        if prior is not None:
            if prior != payload:
                raise ValueError("AUTHORITY_EVIDENCE_CONFLICT")
            return s
        s["authority_events"][evidence] = payload
        sequence = str(data["source_sequence"])
        if sequence in s["authority_sequences"] and s["authority_sequences"][sequence] != data["permitted"]:
            _alert(s, "AUTHORITY_EQUIVOCATION", "authority", evidence)
        else:
            s["authority_sequences"][sequence] = data["permitted"]
            if data["source_sequence"] > s["pool"]["authority_source_sequence"]:
                s["pool"]["permitted"] = data["permitted"]
                s["pool"]["authority_epoch"] += 1
                s["pool"]["authority_source_sequence"] = data["source_sequence"]
    elif kind == "funding":
        amount = integer(decode_i64(data["delta"]))
        old = s["funding"].get(data["id"])
        if old is not None and old != str(amount):
            raise ValueError("FUNDING_CONFLICT")
        if old is None:
            s["funding"][data["id"]] = str(amount)
            s["pool"]["cash"] = str(int(s["pool"]["cash"]) + amount)
    elif kind == "prepare":
        request = data["request"]
        key = digest("partial-command", request)
        h = digest("partial-request", request)
        if key in s["commands"]:
            if s["commands"][key]["request"] != request:
                raise ValueError("COMMAND_CONFLICT")
            return s
        _authorized(s, data["authority_epoch"])
        if pool_view(s)["status"] != "funded":
            raise ValueError("FUNDING_IMPAIRED")
        target = request["target"]
        row = s["targets"][target]
        if (request["pool"], request["asset"], request["unit"], request["payer"], request["payee"], request["provider"], request["contract"]) != (s["pool"]["id"], s["pool"]["asset"], s["pool"]["unit"], s["pool"]["account"], row["payee"], policy.scope, policy.contract):
            raise ValueError("REQUEST_SCOPE")
        q = quantity(decode_i64(request["quantity"]))
        attempt = digest("intent-attempt", {"target": target, "attempt": request["attempt"]})
        if attempt in s["attempts"]:
            raise ValueError("ATTEMPT_CONFLICT")
        view = target_view(s, target)
        if q > int(view["outstanding"]) - int(view["reserved"]):
            raise ValueError("TARGET_ALREADY_RESERVED")
        if q > int(pool_view(s)["free"]):
            raise ValueError("AGGREGATE_FUNDING")
        s["commands"][key] = {"target": target, "quantity": str(q), "reserved": str(q), "gross": "0", "request": request, "request_digest": h, "dispatch": "Prepared", "uncertain": False, "closed": False, "closure_assertion": None}
        s["attempts"][attempt] = key
    elif kind in {"arm", "transmit"}:
        key = data["command"]
        _ready(s, key, data["authority_epoch"])
        s["commands"][key]["dispatch"] = "Armed"
        s["commands"][key]["uncertain"] = True
    elif kind == "acknowledged":
        s["commands"][data["command"]]["uncertain"] = False
    elif kind == "unavailable":
        c = s["commands"][data["command"]]
        if c["dispatch"] == "Armed" and not c["closed"]:
            c["uncertain"] = True
    elif kind == "cancel_prepared":
        c = s["commands"][data["command"]]
        if c["dispatch"] != "Prepared":
            raise ValueError("DISPATCH_ALREADY_ARMED")
        c["dispatch"] = "Cancelled"
        c["closed"] = True
        c["reserved"] = "0"
    elif kind == "cancel_target":
        q = quantity(decode_i64(data["quantity"]))
        evidence = data["evidence"]
        payload = {"target": data["target"], "quantity": str(q)}
        prior = s["cancellations"].get(evidence)
        if prior is not None:
            if prior != payload:
                raise ValueError("CANCELLATION_EVIDENCE_CONFLICT")
            return s
        _authorized(s, data["authority_epoch"])
        view = target_view(s, data["target"])
        if q > int(view["outstanding"]) - int(view["reserved"]):
            raise ValueError("UNFENCED_CANCELLATION")
        row = s["targets"][data["target"]]
        row["cancelled"] = str(int(row["cancelled"]) + q)
        s["cancellations"][evidence] = payload
    elif kind == "receive":
        _receive(s, data["envelope"], policy)
    elif kind == "epoch":
        if s["active_epoch"] is not None:
            return s
        members = _schedule(s)
        record = {"previous": s["epochs"][-1]["root"] if s["epochs"] else "genesis", "cut": s["received"], "members": members, "frontiers": dict(s["frontiers"]), "authority_epoch": s["pool"]["authority_epoch"], "provider": policy.scope, "contract": policy.contract, "source_state": digest("epoch-source-state", s)}
        root = digest("partial-epoch", record)
        s["active_epoch"] = {"root": root, "record": record, "index": 0}
    elif kind == "consume":
        epoch = s["active_epoch"]
        if epoch is None or data["epoch"] != epoch["root"] or data["index"] != epoch["index"]:
            raise ValueError("CONTINUATION_VERSION")
        aid = epoch["record"]["members"][epoch["index"]]
        _consume(s, aid)
        epoch["index"] += 1
    elif kind == "finish_epoch":
        epoch = s["active_epoch"]
        if epoch is None or data["epoch"] != epoch["root"]:
            raise ValueError("CONTINUATION_VERSION")
        if epoch["index"] != len(epoch["record"]["members"]):
            raise ValueError("EPOCH_INCOMPLETE")
        s["epochs"].append(epoch)
        s["active_epoch"] = None
    else:
        raise ValueError("EVENT_KIND")
    validate(s)
    return s

def validate(s):
    paid = sum(int(o["quantity"]) for o in s["occurrences"].values() if o["kind"] == "payment")
    returned = sum(int(o["quantity"]) for o in s["occurrences"].values() if o["kind"] == "return")
    cash = int(s["pool"]["initial"]) + sum(map(int, s["funding"].values())) - paid + returned
    if cash != int(s["pool"]["cash"]):
        raise ValueError("CASH_CONSERVATION")
    for target in s["targets"]:
        v = target_view(s, target)
        if int(v["outstanding"]) < 0 or int(v["paid"]) < int(v["returned"]):
            raise ValueError("TARGET_CONSERVATION")
    if any(int(c["reserved"]) < 0 for c in s["commands"].values()):
        raise ValueError("RESERVATION_CONSERVATION")
