"""Non-cryptographic state-machine fixtures for P10 custody and release contracts."""
from dataclasses import dataclass, field
import copy
import json
import math


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


@dataclass
class Custody:
    last_parent: int = 10
    bytes_present: bool = True
    epoch_open: bool = True
    epoch_service: bool = True
    admitted: dict = field(default_factory=dict)
    consumed: set = field(default_factory=set)
    replay_complete: bool = False
    handed_off: bool = False

    def admit(self, parent, occurrences):
        require(parent <= self.last_parent, 'descriptor admission height expired')
        require(self.epoch_open and self.epoch_service, 'epoch closed to admission')
        require(self.bytes_present, 'no certified body')
        require(not (set(occurrences) & self.consumed), 'consumed occurrence reused')
        self.admitted[parent + 1] = tuple(occurrences)

    def retire_epoch(self):
        self.epoch_open = False
        unresolved = set(sum((list(v) for v in self.admitted.values()), [])) - self.consumed
        require(not unresolved, 'retirement strands admitted ciphertext')
        self.epoch_service = False

    def delete(self, confirmed_height):
        all_occurrences = set(sum((list(v) for v in self.admitted.values()), []))
        unused_closed = confirmed_height > self.last_parent and not self.admitted
        consumed_closed = bool(self.admitted) and bool(all_occurrences) and all_occurrences <= self.consumed and self.replay_complete
        require(unused_closed or consumed_closed or self.handed_off, 'retention obligation remains')
        self.bytes_present = False

    def execute(self, child, interval, bound):
        require(self.bytes_present and self.epoch_service, 'locked child cannot reconstruct')
        require(child in self.admitted, 'not parent-fixed')
        lower, upper = interval
        require(lower <= upper, 'invalid interval')
        result = 'admitted' if upper <= bound else 'expired' if lower > bound else 'timeUncertain'
        self.consumed.update(self.admitted[child])
        return result


@dataclass(frozen=True)
class CipherInput:
    key: str = 'epoch-a'
    suite: str = 'P10-TDH2-P256-SHA256-AES256GCM'
    cipher: str = 'capsule-1'
    instruction: str = 'instruction-1'
    label: str = 'bound-header-payload'
    encoding_valid: bool = True
    primitive_valid: bool = True


@dataclass
class ReleaseService:
    active_key: str = 'epoch-a'
    assignments: dict = field(default_factory=dict)
    used_instructions: set = field(default_factory=set)
    replies: dict = field(default_factory=dict)
    retained_epochs: set = field(default_factory=lambda: {'epoch-a'})

    def assign(self, cipher, context):
        require(cipher.key == self.active_key, 'wrong epoch')
        require(cipher.suite == 'P10-TDH2-P256-SHA256-AES256GCM', 'wrong suite')
        require(cipher.encoding_valid and cipher.primitive_valid, 'malformed or invalid primitive ciphertext')
        require(cipher.label == 'bound-header-payload', 'wrong bound label')
        key = (cipher.key, cipher.cipher)
        require(key not in self.assignments and cipher.instruction not in self.used_instructions, 'duplicate assignment')
        self.assignments[key] = context
        self.used_instructions.add(cipher.instruction)

    def release(self, cipher, context, signer, confirmed=True):
        key = (cipher.key, cipher.cipher)
        require(confirmed and self.assignments.get(key) == context, 'unconfirmed or wrong release context')
        require(cipher.key in self.retained_epochs, 'retired reconstruction obligation')
        require(cipher.encoding_valid and cipher.primitive_valid and cipher.label == 'bound-header-payload', 'release input invalid')
        replay_key = (key, signer)
        if replay_key not in self.replies:
            self.replies[replay_key] = (context, signer, 'valid-share-proof')
        return self.replies[replay_key]


def combine(messages, context, threshold):
    require(len(messages) >= threshold, 'insufficient shares')
    require(len({m[1] for m in messages}) == len(messages), 'duplicate signer')
    require(all(m[0] == context and m[2] == 'valid-share-proof' for m in messages), 'mixed context or invalid proof')
    return 'reconstructed-session-key'


def decryption_result(messages, context, threshold, tag_valid=True, payload_valid=True):
    combine(messages, context, threshold)
    if not tag_valid or not payload_valid:
        return ('AuthFailure', ('cipher-bound', 'shares-bound', 'reproducible-failure'))
    return ('Plain', 'decoded-instruction')


def instruction_disposition(result):
    if result[0] == 'AuthFailure':
        return ('Reject(auth)', 'notEvaluated', 'noLocalTransfer', False)
    return ('admissible-input', 'pending-evaluation', 'no-dispatch-in-replay', True)


def rejects(call):
    try:
        call()
    except RuntimeError:
        return
    raise RuntimeError('invalid transition was accepted')


def main():
    results = []
    c = Custody()
    rejects(lambda: c.delete(1))
    c.admit(10, ['o1', 'o2'])
    rejects(lambda: c.delete(1000000))
    rejects(c.retire_epoch)
    require(c.epoch_service, 'failed retirement erased old service')
    require(c.execute(11, (11, 11), 12) == 'admitted', 'partition disabled positive ledger-height work')
    c.replay_complete = True
    c.delete(1000000)
    require(not c.bytes_present, 'completed retention cannot reclaim')
    results.append('partition retains locked bytes and permits positive work; completed retention reclaims')

    for interval, expected in [((20, math.inf), 'expired'), ((-math.inf, math.inf), 'timeUncertain')]:
        c = Custody();c.admit(9, ['o']);require(c.execute(10, interval, 15) == expected, 'clock branch mismatch')
        require(c.consumed == {'o'}, 'terminal clock result did not consume occurrence')
    c = Custody();c.retire_epoch();rejects(lambda: c.admit(5, ['o']))
    c = Custody();c.delete(11)
    require(not c.bytes_present, 'certified non-admission cannot reclaim')
    results.append('expired, unknown-time, closed-epoch, and unused-retirement branches')

    cipher = CipherInput();context = ('chain', 'epoch-a', 11, 'parent', 'witness', 'o', 'capsule-1')
    service = ReleaseService();service.assign(cipher, context)
    first = service.release(cipher, context, 0)
    restored = copy.deepcopy(service)
    require(restored.release(cipher, context, 0) == first, 'restart changed retained response')
    rejects(lambda: restored.assign(cipher, context))
    rejects(lambda: restored.release(cipher, ('wrong',), 1))
    rejects(lambda: restored.release(cipher, context, 1, False))
    restored.active_key = 'epoch-b'
    require(restored.release(cipher, context, 1)[0] == context, 'epoch change stranded old obligation')
    shares = [restored.release(cipher, context, i) for i in range(3)]
    require(combine(shares, context, 3) == 'reconstructed-session-key', 'honest quorum cannot complete')
    rejects(lambda: combine(shares[:2], context, 3))
    rejects(lambda: combine([shares[0], shares[0], shares[2]], context, 3))
    rejects(lambda: combine([shares[0], shares[1], (('wrong',), 2, 'valid-share-proof')], context, 3))
    rejects(lambda: combine([shares[0], shares[1], (context, 2, 'bad-proof')], context, 3))
    results.append('positive release, restart, same-command retry, old epoch, quorum, and malformed combination')

    require(decryption_result(shares, context, 3)[0]=='Plain', 'valid payload cannot enter execution')
    for fields in [{'tag_valid':False}, {'payload_valid':False}]:
        result=decryption_result(shares, context, 3, **fields)
        require(instruction_disposition(result)==('Reject(auth)','notEvaluated','noLocalTransfer',False),
                'invalid payload stranded progress or changed instruction-use state')
    results.append('valid capsule with failed tag or decoding yields total rejection without use-map mutation')

    for fields in [{'key':'wrong'}, {'suite':'wrong'}, {'label':'wrong'}, {'encoding_valid':False}, {'primitive_valid':False}]:
        bad = CipherInput(**fields)
        rejects(lambda: ReleaseService().assign(bad, context))
    results.append('wrong epoch, suite, payload label, encoding, and primitive verdict rejected')
    print(json.dumps({'status':'pass','groups':results,'scope':'Non-cryptographic protocol model. Cryptographic validity is an explicit input predicate, not established by these fixtures.'},indent=2))


if __name__ == '__main__':
    main()
