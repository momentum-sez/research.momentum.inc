"""Independent finite allocation checks for an admitted, single-unit snapshot."""
from dataclasses import replace
from fractions import Fraction
from itertools import product
import unittest
from unittest.mock import patch

import allocation as subject


PAIRS = (("a", "x"), ("a", "y"), ("b", "x"), ("b", "y"))


def batch(capacities=(1, 1), requirements=(1, 1), pairs=PAIRS):
    return subject.Batch(
        "state:1", "USD-cent", "compatibility:admitted:1",
        tuple(subject.Supply(i, q) for i, q in zip(("a", "b"), capacities)),
        tuple(subject.Demand(j, q) for j, q in zip(("x", "y"), requirements)),
        tuple(pairs),
    )


def independent_feasible(case, vector):
    """Check row and column inequalities directly from ledger records."""
    pairs = sorted(case.compatible)
    if len(vector) != len(pairs) or any(q < 0 for q in vector):
        return False
    for supply in case.supplies:
        used = sum(q for (i, _), q in zip(pairs, vector) if i == supply.key)
        fixed = sum(q for _, q in supply.fixed)
        if used + fixed + supply.held > supply.eligible:
            return False
    for demand in case.demands:
        used = sum(q for (_, j), q in zip(pairs, vector) if j == demand.key)
        if used + demand.effective > demand.required:
            return False
    return True


def independent_best(case, quantum=Fraction(1)):
    """Enumerate assignments without the subject's network or normalizer."""
    supplies = {
        s.key: Fraction(s.eligible) - sum(q for _, q in s.fixed) - s.held
        for s in case.supplies
    }
    demands = {d.key: Fraction(d.required) - d.effective for d in case.demands}
    bounds = [min(supplies[i], demands[j]) / quantum for i, j in sorted(case.compatible)]
    if any(q.denominator != 1 for q in bounds):
        raise ValueError("Enumeration quantum must divide every edge bound")
    best = None
    checked = 0
    for coefficients in product(*(range(int(q) + 1) for q in bounds)):
        vector = tuple(q * quantum for q in coefficients)
        checked += 1
        if independent_feasible(case, vector):
            objective = (sum(vector, Fraction(0)), vector)
            if best is None or objective > best:
                best = objective
    if best is None:
        raise ValueError("No feasible assignment")
    return best, checked


def with_vector(certificate, vector):
    return replace(certificate,
                   allocation=tuple((i, j, q) for (i, j, _), q in zip(certificate.allocation, vector)),
                   value=sum(vector, Fraction(0)))


class IndependentAllocationTests(unittest.TestCase):
    def check_against_enumeration(self, case, quantum=Fraction(1)):
        expected, checked = independent_best(case, quantum)
        actual = subject.solve(case)
        self.assertEqual((actual.value, tuple(q for _, _, q in actual.allocation)), expected)
        self.assertTrue(subject.verify(case, actual))
        return actual, checked

    def test_all_1296_two_by_two_integer_batches(self):
        cases = 0
        assignments = 0
        for flags in product((False, True), repeat=4):
            edges = tuple(pair for pair, keep in zip(PAIRS, flags) if keep)
            for quantities in product(range(3), repeat=4):
                case = batch(quantities[:2], quantities[2:], edges)
                with self.subTest(edges=edges, quantities=quantities):
                    _, checked = self.check_against_enumeration(case)
                    assignments += checked
                cases += 1
        self.assertEqual(cases, 1296)
        self.assertGreater(assignments, cases)

    def test_fractional_exact_optimum_and_lexical_priority(self):
        case = batch((Fraction(2, 3), Fraction(1, 2)),
                     (Fraction(3, 4), Fraction(5, 12)))
        certificate, _ = self.check_against_enumeration(case, Fraction(1, 12))
        self.assertEqual(certificate.value, Fraction(7, 6))
        self.assertEqual(tuple(q for _, _, q in certificate.allocation),
                         (Fraction(2, 3), 0, Fraction(1, 12), Fraction(5, 12)))

    def test_fixed_slices_and_holds_are_disjoint_resources(self):
        case = replace(batch((5, 4), (5, 3)), supplies=(
            subject.Supply("a", 5, (("x", 2),), 1),
            subject.Supply("b", 4, (("y", 1),), 2)),
            demands=(subject.Demand("x", 5, 2), subject.Demand("y", 3, 1)))
        certificate, _ = self.check_against_enumeration(case)
        self.assertEqual(certificate.value, 3)
        self.assertEqual(tuple(q for _, _, q in certificate.allocation), (2, 0, 1, 0))

    def test_existing_effective_performance_can_have_external_sources(self):
        case = replace(batch((2, 1), (3, 2)),
                       demands=(subject.Demand("x", 3, 2), subject.Demand("y", 2, 1)))
        certificate, _ = self.check_against_enumeration(case)
        self.assertEqual(certificate.value, 2)

    def test_online_greedy_strands_a_compatible_obligation(self):
        case = batch(pairs=(("a", "x"), ("a", "y"), ("b", "x")))
        greedy = (1, 0, 0)
        self.assertTrue(independent_feasible(case, greedy))
        certificate, _ = self.check_against_enumeration(case)
        self.assertEqual(tuple(q for _, _, q in certificate.allocation), (0, 1, 1))
        self.assertEqual(certificate.value, 2)
        self.assertFalse(subject.verify(case, with_vector(certificate, greedy)))

    def test_batch_reoptimization_moves_tentative_but_never_fixed_slices(self):
        initial = replace(batch((1, 0), pairs=(("a", "x"), ("a", "y"), ("b", "x"))),
                          state_root="state:initial")
        tentative = subject.solve(initial)
        self.assertEqual(tuple(q for _, _, q in tentative.allocation), (1, 0, 0))
        later = replace(initial, state_root="state:later", supplies=(subject.Supply("a", 1), subject.Supply("b", 1)))
        reoptimized = subject.solve(later)
        self.assertEqual(tuple(q for _, _, q in reoptimized.allocation), (0, 1, 1))
        fixed = replace(later, state_root="state:committed", supplies=(
            subject.Supply("a", 1, (("x", 1),)), subject.Supply("b", 1)),
            demands=(subject.Demand("x", 1, 1), subject.Demand("y", 1)))
        committed, _ = self.check_against_enumeration(fixed)
        self.assertEqual(committed.value, 0)
        self.assertEqual(fixed.supplies[0].fixed, (("x", 1),))

    def test_fixed_slice_is_preserved_when_new_compatibility_is_withdrawn(self):
        case = replace(batch(pairs=(("b", "y"),)), supplies=(
            subject.Supply("a", 1, (("x", 1),)), subject.Supply("b", 1)),
            demands=(subject.Demand("x", 1, 1), subject.Demand("y", 1)))
        certificate, _ = self.check_against_enumeration(case)
        self.assertEqual(certificate.allocation, (("b", "y", Fraction(1)),))

    def test_maximum_but_noncanonical_assignment_is_rejected(self):
        case = batch()
        certificate, _ = self.check_against_enumeration(case)
        alternative = (0, 1, 1, 0)
        self.assertTrue(independent_feasible(case, alternative))
        self.assertEqual(sum(alternative), certificate.value)
        self.assertFalse(subject.verify(case, with_vector(certificate, alternative)))

    def test_optimizer_and_residual_search_are_absent_from_verification(self):
        case = batch()
        certificate = subject.solve(case)
        with patch.object(subject, "solve", side_effect=RuntimeError("Optimizer called")), \
             patch.object(subject, "search", side_effect=RuntimeError("Search called")), \
             patch.object(subject, "residual", side_effect=RuntimeError("Residual search called")), \
             patch.object(subject, "network", side_effect=RuntimeError("Network builder called")):
            self.assertTrue(subject.verify(case, certificate))
            self.assertFalse(subject.verify(case, with_vector(certificate, (0, 1, 1, 0))))

    def test_input_order_preserves_exact_certificate(self):
        case = replace(batch((4, 3), (4, 3)), supplies=(
            subject.Supply("a", 4, (("x", 1), ("y", 1))), subject.Supply("b", 3)),
            demands=(subject.Demand("x", 4, 1), subject.Demand("y", 3, 1)))
        reordered = replace(case,
            supplies=(case.supplies[1], replace(case.supplies[0], fixed=tuple(reversed(case.supplies[0].fixed)))),
            demands=tuple(reversed(case.demands)), compatible=tuple(reversed(case.compatible)))
        self.assertEqual(subject.solve(case), subject.solve(reordered))

    def test_state_unit_and_authority_evidence_bind_the_certificate(self):
        case = batch()
        original = subject.solve(case)
        for altered in (replace(case, state_root="state:2"),
                        replace(case, unit="EUR-cent"),
                        replace(case, compatibility_evidence="compatibility:admitted:2")):
            with self.subTest(batch=altered):
                successor = subject.solve(altered)
                self.assertEqual(successor.allocation, original.allocation)
                self.assertNotEqual(successor.batch_hash, original.batch_hash)
                self.assertFalse(subject.verify(altered, original))
                self.assertFalse(subject.verify(case, successor))

    def test_invalid_certificates_and_wrong_bounds_are_rejected(self):
        case = batch()
        certificate = subject.solve(case)
        malformed = [
            None, {}, replace(certificate, batch_hash="wrong"),
            replace(certificate, value=certificate.value + 1),
            replace(certificate, value=2.0), replace(certificate, value=True),
            replace(certificate, allocation=certificate.allocation[:-1]),
            replace(certificate, allocation=tuple(reversed(certificate.allocation))),
            replace(certificate, allocation=(("unknown", "x", 1),) + certificate.allocation[1:]),
            replace(certificate, allocation=(("a", "x"),) + certificate.allocation[1:]),
            with_vector(certificate, (-1, 1, 1, 1)),
            with_vector(certificate, (2, 0, 0, 0)),
            with_vector(certificate, (1.0, 0, 0, 1)),
            replace(certificate, maximum_cut=()),
            replace(certificate, maximum_cut=(subject.SOURCE, subject.SINK)),
            replace(certificate, maximum_cut=(subject.SOURCE, ("unknown", "x"))),
            replace(certificate, maximum_cut=(["source", ""],)),
            replace(certificate, lexical_cuts=certificate.lexical_cuts[:-1]),
            replace(certificate, lexical_cuts=((),) * len(certificate.allocation)),
            replace(certificate, lexical_cuts=((subject.SOURCE,),) * len(certificate.allocation)),
        ]
        for i, forged in enumerate(malformed):
            with self.subTest(mutation=i):
                self.assertFalse(subject.verify(case, forged))

    def test_malformed_batches_are_rejected(self):
        case = batch()
        malformed = [
            replace(case, state_root="non canonical"), replace(case, unit=""),
            replace(case, compatibility_evidence=""),
            replace(case, supplies=(subject.Supply("a", -1),)),
            replace(case, supplies=(subject.Supply("a", 1.0),)),
            replace(case, supplies=(subject.Supply("a", True),)),
            replace(case, supplies=(subject.Supply("a", 1), subject.Supply("a", 1))),
            replace(case, demands=(subject.Demand("x", 1), subject.Demand("x", 1))),
            replace(case, supplies=(subject.Supply("a", 1, (("x", 1),), 1),)),
            replace(case, supplies=(subject.Supply("a", 2, (("unknown", 1),)),)),
            replace(case, supplies=(subject.Supply("a", 2, (("x", 1), ("x", 1))),)),
            replace(case, supplies=(subject.Supply("a", 2, (("x", 1),)),)),
            replace(case, demands=(subject.Demand("x", 1, 2), subject.Demand("y", 1))),
            replace(case, compatible=case.compatible + (case.compatible[0],)),
            replace(case, compatible=(("unknown", "x"),)),
            replace(case, compatible=(("a", "unknown"),)),
        ]
        certificate = subject.solve(case)
        for i, invalid in enumerate(malformed):
            with self.subTest(mutation=i):
                with self.assertRaises((ValueError, TypeError)):
                    subject.solve(invalid)
                self.assertFalse(subject.verify(invalid, certificate))

    def test_empty_and_zero_capacity_batches(self):
        for case in (batch((0, 0), (0, 0)), batch(pairs=()),
                     replace(batch(), supplies=(), demands=(), compatible=())):
            with self.subTest(batch=case):
                certificate = subject.solve(case)
                self.assertEqual(certificate.value, 0)
                self.assertTrue(subject.verify(case, certificate))

    def test_consumable_containers_cannot_erase_ledger_rows(self):
        empty = replace(batch(), supplies=(), demands=(), compatible=())
        empty_binding = subject.solve(empty).batch_hash
        cases = (
            replace(empty, supplies=(s for s in (subject.Supply("a", 1),))),
            replace(empty, demands=(d for d in (subject.Demand("x", 1),))),
        )
        for case in cases:
            with self.subTest(field="supplies" if case.supplies else "demands"):
                try:
                    certificate = subject.solve(case)
                except (ValueError, TypeError):
                    continue
                self.assertNotEqual(certificate.batch_hash, empty_binding,
                                    "A consumable ledger row disappeared during normalization")


if __name__ == "__main__":
    unittest.main(verbosity=2)
