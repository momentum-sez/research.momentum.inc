"""Exact allocation on an admitted, closed, single-unit ledger snapshot.

The solver proposes quantities. Certificate verification authorizes no legal act.
This module neither changes the ledger nor calls an external provider.
"""
from dataclasses import dataclass
from fractions import Fraction
from collections import deque
import hashlib
import json
import re


def amount(value):
    if type(value) not in (int, Fraction):
        raise ValueError("Amounts must be exact integers or fractions")
    value = Fraction(value)
    if value < 0:
        raise ValueError("Negative amount")
    return value


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]+", value):
        raise ValueError("Expected a nonempty canonical ASCII identifier")
    return value


@dataclass(frozen=True)
class Supply:
    key: str
    eligible: Fraction
    fixed: tuple = ()  # (obligation identifier, currently supported fixed amount)
    held: Fraction = Fraction(0)  # Supported reconciliation holds, disjoint from fixed.


@dataclass(frozen=True)
class Demand:
    key: str
    required: Fraction
    effective: Fraction = Fraction(0)


@dataclass(frozen=True)
class Batch:
    state_root: str
    unit: str
    compatibility_evidence: str
    supplies: tuple
    demands: tuple
    compatible: tuple

    def normalized(self):
        if any(type(xs) is not tuple for xs in (self.supplies, self.demands, self.compatible)):
            raise ValueError("Batch collections must be immutable tuples")
        identifier(self.state_root)
        identifier(self.unit)
        identifier(self.compatibility_evidence)
        if not all(type(x) is Supply for x in self.supplies):
            raise ValueError("Expected supplies")
        if not all(type(x) is Demand for x in self.demands):
            raise ValueError("Expected demands")
        supplies = tuple(sorted(self.supplies, key=lambda x: identifier(x.key)))
        demands = tuple(sorted(self.demands, key=lambda x: identifier(x.key)))
        sk = tuple(x.key for x in supplies)
        dk = tuple(x.key for x in demands)
        if len(set(sk)) != len(sk) or len(set(dk)) != len(dk):
            raise ValueError("Duplicate ledger identity")
        totals = {j: Fraction(0) for j in dk}
        fixed_by_supply = {}
        for s in supplies:
            if type(s.fixed) is not tuple or any(type(p) is not tuple or len(p) != 2 for p in s.fixed):
                raise ValueError("Fixed slices must be immutable pairs")
            fixed = tuple(sorted(s.fixed))
            if len({j for j, _ in fixed}) != len(fixed):
                raise ValueError("Duplicate fixed slice")
            for j, q in fixed:
                if j not in totals:
                    raise ValueError("Unknown fixed obligation")
                totals[j] += amount(q)
            used = sum((amount(q) for _, q in fixed), Fraction(0))
            held = amount(s.held)
            if used + held > amount(s.eligible):
                raise ValueError("Fixed and held performance exceeds supported supply")
            fixed_by_supply[s.key] = (fixed, used, held)
        for d in demands:
            if amount(d.effective) > amount(d.required):
                raise ValueError("Effective performance exceeds requirement")
            if totals[d.key] > amount(d.effective):
                raise ValueError("Fixed slices exceed recorded effective performance")
        if any(type(p) is not tuple or len(p) != 2 for p in self.compatible):
            raise ValueError("Compatible pairs must be immutable pairs")
        edges = tuple(sorted(self.compatible))
        if len(set(edges)) != len(edges):
            raise ValueError("Duplicate compatible pair")
        if any(i not in sk or j not in dk for i, j in edges):
            raise ValueError("Unknown compatible endpoint")
        c = {s.key: amount(s.eligible) - fixed_by_supply[s.key][1]
             - fixed_by_supply[s.key][2] for s in supplies}
        d = {x.key: amount(x.required) - amount(x.effective) for x in demands}
        def q(value):
            value = amount(value)
            return [str(value.numerator), str(value.denominator)]
        record = {
            "domain": "P10-compatible-divisible-batch-v1",
            "state_root": self.state_root, "unit": self.unit,
            "compatibility_evidence": self.compatibility_evidence,
            "supplies": [[s.key, q(s.eligible),
                          [[j, q(v)] for j, v in fixed_by_supply[s.key][0]],
                          q(s.held)] for s in supplies],
            "demands": [[x.key, q(x.required), q(x.effective)] for x in demands],
            "compatible": edges,
        }
        binding = hashlib.sha256(json.dumps(record, sort_keys=True,
                    separators=(",", ":"), ensure_ascii=True).encode("ascii")).hexdigest()
        return c, d, edges, binding


SOURCE = ("source", "")
SINK = ("sink", "")


def network(batch):
    c, d, pairs, binding = batch.normalized()
    bound = min(sum(c.values(), Fraction(0)), sum(d.values(), Fraction(0)))
    capacities = {}
    for i in c:
        capacities[(SOURCE, ("supply", i))] = c[i]
    for i, j in pairs:
        capacities[(("supply", i), ("demand", j))] = bound
    for j in d:
        capacities[(("demand", j), SINK)] = d[j]
    return capacities, pairs, binding


def residual(capacities, flow, excluded=frozenset()):
    graph = {}
    for edge, cap in capacities.items():
        if edge in excluded:
            continue
        u, v = edge
        if flow[edge] < cap:
            graph.setdefault(u, []).append((v, edge, 1, cap - flow[edge]))
        if flow[edge] > 0:
            graph.setdefault(v, []).append((u, edge, -1, flow[edge]))
    for arcs in graph.values():
        arcs.sort(key=lambda a: a[0])
    return graph


def search(graph, start, end):
    previous = {start: None}
    queue = deque([start])
    while queue:
        u = queue.popleft()
        for v, edge, sign, capacity in graph.get(u, ()):
            if v in previous:
                continue
            previous[v] = (u, edge, sign, capacity)
            queue.append(v)
    if end not in previous:
        return None, tuple(sorted(previous))
    path = []
    v = end
    while v != start:
        arc = previous[v]
        path.append(arc)
        v = arc[0]
    return path, tuple(sorted(previous))


def augment(flow, path, quantity):
    for _, edge, sign, _ in path:
        flow[edge] += sign * quantity


@dataclass(frozen=True)
class Certificate:
    batch_hash: str
    allocation: tuple  # Ordered (supply, demand, new amount), including zeros.
    value: Fraction
    maximum_cut: tuple
    lexical_cuts: tuple  # One vertex cut per ordered pair; empty if saturated.


def solve(batch):
    capacities, pairs, binding = network(batch)
    flow = {edge: Fraction(0) for edge in capacities}
    while True:
        path, _ = search(residual(capacities, flow), SOURCE, SINK)
        if path is None:
            break
        augment(flow, path, min(a[3] for a in path))
    locked = set()
    for i, j in pairs:
        edge = (("supply", i), ("demand", j))
        excluded = locked | {edge}
        while flow[edge] < capacities[edge]:
            path, _ = search(residual(capacities, flow, excluded), edge[1], edge[0])
            if path is None:
                break
            quantity = min(capacities[edge] - flow[edge], *(a[3] for a in path))
            augment(flow, path, quantity)
            flow[edge] += quantity
        locked.add(edge)
    _, maximum_cut = search(residual(capacities, flow), SOURCE, SINK)
    cuts = []
    locked = set()
    for i, j in pairs:
        edge = (("supply", i), ("demand", j))
        if flow[edge] == capacities[edge]:
            cuts.append(())
        else:
            path, cut = search(residual(capacities, flow, locked | {edge}), edge[1], edge[0])
            if path is not None:
                raise RuntimeError("Canonical circulation invariant failed")
            cuts.append(cut)
        locked.add(edge)
    allocation = tuple((i, j, flow[(("supply", i), ("demand", j))]) for i, j in pairs)
    return Certificate(binding, allocation, sum((x[2] for x in allocation), Fraction(0)),
                       maximum_cut, tuple(cuts))


def verify(batch, certificate):
    """Check primal feasibility, total optimum, and lexicographic uniqueness.

    This checker uses no optimizer, residual search, or solver-produced state.
    A true result remains relative to the caller's admitted batch and authority.
    """
    try:
        c, d, pairs, binding = batch.normalized()
        if type(certificate) is not Certificate or certificate.batch_hash != binding:
            return False
        if any(type(xs) is not tuple for xs in (certificate.allocation, certificate.maximum_cut,
                                                certificate.lexical_cuts)):
            return False
        rows = certificate.allocation
        if any(type(row) is not tuple or len(row) != 3 for row in rows):
            return False
        if tuple((i, j) for i, j, _ in rows) != pairs:
            return False
        x = {(i, j): amount(v) for i, j, v in rows}
        row = {i: sum((v for (a, _), v in x.items() if a == i), Fraction(0)) for i in c}
        col = {j: sum((v for (_, b), v in x.items() if b == j), Fraction(0)) for j in d}
        if any(row[i] > c[i] for i in c) or any(col[j] > d[j] for j in d):
            return False
        value = sum(x.values(), Fraction(0))
        if amount(certificate.value) != value:
            return False
        bound = min(sum(c.values(), Fraction(0)), sum(d.values(), Fraction(0)))
        capacities = {(SOURCE, ("supply", i)): c[i] for i in c}
        capacities.update({(("supply", i), ("demand", j)): bound for i, j in pairs})
        capacities.update({(("demand", j), SINK): d[j] for j in d})
        flow = {(SOURCE, ("supply", i)): row[i] for i in c}
        flow.update({(("supply", i), ("demand", j)): x[i, j] for i, j in pairs})
        flow.update({(("demand", j), SINK): col[j] for j in d})
        vertices = {SOURCE, SINK} | {("supply", i) for i in c} | {("demand", j) for j in d}
        cut = set(certificate.maximum_cut)
        if not cut <= vertices or SOURCE not in cut or SINK in cut:
            return False
        capacity = sum((cap for (u, v), cap in capacities.items()
                        if u in cut and v not in cut), Fraction(0))
        if capacity != value or len(certificate.lexical_cuts) != len(pairs):
            return False
        locked = set()
        for (i, j), witness in zip(pairs, certificate.lexical_cuts):
            edge = (("supply", i), ("demand", j))
            if flow[edge] == capacities[edge]:
                if witness != ():
                    return False
            else:
                cut = set(witness)
                if not cut <= vertices or edge[1] not in cut or edge[0] in cut:
                    return False
                for other, cap in capacities.items():
                    if other in locked or other == edge:
                        continue
                    u, v = other
                    if u in cut and v not in cut and flow[other] < cap:
                        return False
                    if v in cut and u not in cut and flow[other] > 0:
                        return False
            locked.add(edge)
        return True
    except (ValueError, TypeError, KeyError, AttributeError):
        return False
