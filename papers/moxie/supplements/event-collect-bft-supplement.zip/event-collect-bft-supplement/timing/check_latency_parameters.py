"""Fixed synthetic schedules and exact-rational parameter checks. No network measurements."""
from dataclasses import dataclass, replace
from fractions import Fraction as F
from math import ceil, inf, isfinite
import json


def require(condition, message):
    if not condition:
        raise ValueError(message)


def kth(values, threshold):
    require(1 <= threshold <= len(values) and all(x >= 0 for x in values), 'threshold/duration domain')
    return sorted(values)[threshold - 1]


def close_after(t, period=10):
    require(period > 0 and t >= 0, 'closure domain')
    return period * (t // period + 1) if isfinite(t) else inf


def recorded(evidence_at):
    return close_after(evidence_at + 1) + 3


@dataclass(frozen=True)
class Trace:
    n: int = 7
    body: float = 2
    shares: tuple = (1, 2, 3, 4, 5, inf, inf)
    event_close: float = 3
    ec_consensus: float = 2
    fact_close: float = 3
    execute: float = 1
    ledger_consensus: float = 2
    use: float = 2
    dispatch: float = 1
    providers: tuple = (2, 4)
    recipient: float = 1
    evidence: float = 2
    recovery: bool = False
    authority_at_use: tuple = (True, True)
    recovery_authority_at_use: bool = True


def run(x, threshold):
    f = (x.n - 1) // 3
    q = x.n - f
    require(len(x.shares) == x.n and f < threshold <= q, 'roster/threshold domain')
    decrypt = kth(x.shares, threshold) + 1
    admit = x.body + max(decrypt, x.event_close + x.ec_consensus, x.fact_close) + x.execute + x.ledger_consensus
    dispatched = admit + x.use + x.dispatch
    require(len(x.providers)==2 and len(x.authority_at_use)==2, 'two-leg workload domain')
    completed = tuple(dispatched + p if authority else inf
                      for p,authority in zip(x.providers,x.authority_at_use))
    usable = max(completed) + x.recipient
    observed = usable + x.evidence
    partial = None
    if x.recovery:
        # Leg2 supplies a complete prospective no-effect fence.
        partial_evidence = max(completed[0] + x.recipient + x.evidence, completed[1] + x.evidence)
        partial = recorded(partial_evidence)
        # Existing obligation, funded resources, actual-use authority.
        recovered = (partial + x.use + x.dispatch + 5 + x.recipient
                     if x.recovery_authority_at_use else inf)
        usable = max(completed[0] + x.recipient, recovered)
        observed = usable + x.evidence
    # Two distinct 100-unit obligations share 200 funded units.
    # These are synthetic provider facts under the declared contracts.
    receipts = {}
    if isfinite(completed[0]):
        receipts['original-leg-0'] = 100
    if x.recovery:
        if isfinite(usable):
            receipts['recovery-leg-1'] = 100
    elif isfinite(completed[1]):
        receipts['original-leg-1'] = 100
    performance = sum(receipts.values())
    outstanding = 200 - performance
    cash = 200 - performance
    reserved = outstanding if isfinite(admit) else 0
    require(0 <= reserved <= cash and performance + outstanding == 200,
            'obligation or funded cash conservation failed')
    accounting = {'receipts':receipts, 'performance':performance,
                  'outstanding':outstanding, 'cash':cash, 'reserved':reserved}
    return {'admission':admit,'recipient_value':usable,'recorded_settlement':recorded(observed),'partial_record':partial,'accounting':accounting}


def quantile(values, p):
    require(values and 0 < p <= 1, 'quantile domain')
    return sorted(values)[ceil(p * len(values)) - 1]


def bond(alpha, p, reward, exposure):
    require(0 < alpha <= 1 and F(1,2) < p <= 1 and min(reward,exposure) >= 0, 'bond domain')
    return max((1-p)*reward/(2*p-1),(exposure/alpha-p*reward)/(2*p-1))


def recovered_bond(alpha, p, reward, exposure, recovery):
    coefficient = p*recovery-(1-p)
    require(0 <= recovery <= 1 and coefficient > 0, 'no general upward-closed bond floor')
    return max((1-p)*reward/(2*p-1),(exposure/alpha-p*reward)/coefficient)


def main():
    base = Trace()
    slow = replace(base, shares=(1,2,3,4,100,inf,inf))
    require(kth(base.shares,5)==5, 'q requires every honest share under withholding')
    require(run(slow,5)['admission']>run(slow,3)['admission'], 'straggler not represented')
    for threshold in (3,4,5):
        before = run(base,threshold)
        require(before['accounting']['performance']==200 and
                before['accounting']['outstanding']==0 and
                len(before['accounting']['receipts'])==2,
                'positive workload lacks complete distinct performance')
        shifted = replace(base,shares=tuple(s+30 for s in base.shares),event_close=33,fact_close=33)
        require(run(shifted,threshold)['admission']==before['admission']+30,'common delay disappeared')
        previous = before['recorded_settlement']
        for delay in range(101):
            current = run(replace(base,providers=(2,4+delay)),threshold)
            require(current['admission']==before['admission'],'provider gated pending admission')
            require(current['recorded_settlement']>=previous,'provider delay decreased settlement time')
            require(current['recipient_value']==before['recipient_value']+delay,'critical delay did not reach value')
            previous = current['recorded_settlement']
        pending = run(replace(base,providers=(2,inf)),threshold)
        require(isfinite(pending['admission']) and pending['recorded_settlement']==inf,'pending represented as settled')
        require(pending['accounting']['performance']==100 and
                pending['accounting']['outstanding']==100 and
                pending['accounting']['reserved']==100,
                'partial performance or pending funding disappeared')
        revoked = run(replace(base,authority_at_use=(True,False)),threshold)
        require(isfinite(revoked['admission']) and revoked['recorded_settlement']==inf and
                revoked['accounting']['performance']==100,
                'authority revocation still admitted external use')
        require(run(replace(base,body=inf),threshold)['admission']==inf,'missing body invented')
        recovery = run(replace(base,recovery=True),threshold)
        require(isfinite(recovery['recorded_settlement']) and recovery['recorded_settlement']>recovery['partial_record'],'recovery skipped partial confirmation')
        require(recovery['accounting']['receipts']=={'original-leg-0':100,'recovery-leg-1':100},
                'recovery duplicated the original performance')
        revoked_recovery=run(replace(base,recovery=True,recovery_authority_at_use=False),threshold)
        require(isfinite(revoked_recovery['partial_record']) and
                revoked_recovery['recorded_settlement']==inf and
                revoked_recovery['accounting']['performance']==100 and
                revoked_recovery['accounting']['outstanding']==100 and
                revoked_recovery['accounting']['reserved']==100,
                'recovery bypassed current authority or erased retained partial state')
    require(recorded(18)==23 and recorded(19)==33,'missed close cycle absent')
    require(quantile(list(range(95))+[inf]*5,.99)==inf,'unresolved population omitted')

    rows=[]
    scenarios=('positive_two_leg','share_straggler','correlated_pause','provider_delay','provider_unresolved','body_absent','partial_then_recovery')
    for scenario in scenarios:
        for threshold in (3,4,5):
            admissions=[];settlements=[]
            for j in range(100):
                jitter=j%5
                x=Trace(shares=tuple(k+jitter for k in (1,2,3,4,5))+(inf,inf))
                if scenario=='share_straggler':x=replace(x,shares=x.shares[:4]+(100+jitter,inf,inf))
                elif scenario=='correlated_pause':
                    pause=25*(j//20)
                    x=replace(x,shares=tuple(s+pause for s in x.shares),event_close=x.event_close+pause,fact_close=x.fact_close+pause)
                elif scenario=='provider_delay':x=replace(x,providers=(2,4+10*j))
                elif scenario=='provider_unresolved':x=replace(x,providers=(2,inf))
                elif scenario=='body_absent':x=replace(x,body=inf)
                elif scenario=='partial_then_recovery':x=replace(x,recovery=True)
                result=run(x,threshold)
                admissions.append(result['admission']);settlements.append(result['recorded_settlement'])
            rows.append({'scenario':scenario,'threshold':threshold,'admission_p95':quantile(admissions,.95),'recorded_p95':quantile(settlements,.95),'recorded_p99':quantile(settlements,.99),'unresolved':sum(not isfinite(v) for v in settlements),'denominator':100})

    require(bond(F(1,2),F(3,4),F(2),F(3))==9,'audit sensitivity')
    require(bond(F(1),F(3,4),F(2),F(3))==3,'baseline')
    require(bond(F(1),F(1),F(2),F(3))==1,'adjudication sensitivity')
    require(bond(F(1),F(3,4),F(4),F(3))==2,
            'capacity condition omitted the truthful-report floor')
    require(F(4)+(2*F(3,4)-1)*0-(1-F(3,4))*F(4)==3 and
            F(3)+(1-F(3,4))*F(4)==4,
            'zero-bond capacity counterexample lost')
    require(recovered_bond(F(1),F(3,4),F(2),F(3),F(1,2))==12,'asymmetric collectibility')
    require(bond(F(1),F(3,4),F(2),F(3))/F(1,2)==6,'symmetric payout scaling')
    comparisons=0
    for alpha in (F(1,10),F(1,4),F(1,2),F(1)):
        for p in (F(3,5),F(3,4),F(9,10),F(1)):
            for reward in (F(0),F(1),F(2),F(5)):
                for exposure in (F(0),F(1),F(3),F(10)):
                    b=bond(alpha,p,reward,exposure)
                    true_min=min(reward,reward+(2*p-1)*b-(1-p)*reward)
                    false=exposure+(1-alpha*p)*reward-alpha*(2*p-1)*b
                    require(true_min>=false and true_min>=0,'bond floor fails payoff dominance')
                    comparisons+=1
    def safe(value):
        if isinstance(value,float) and not isfinite(value):return 'infinity'
        if isinstance(value,dict):return {k:safe(v) for k,v in value.items()}
        if isinstance(value,list):return [safe(v) for v in value]
        return value
    print(json.dumps(safe({'status':'pass','trace_count':2100,'exact_payoff_cases':comparisons,'rows':rows,'scope':'Fixed synthetic design schedules in abstract time units. These are not measured traffic distributions or deployed latency percentiles.'}),indent=2))


if __name__=='__main__':main()
