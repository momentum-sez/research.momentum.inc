# Event-Collect BFT: local supplementary sources

This archive accompanies *Event-Collect BFT*, September 2026. It supplies the
existing finite checkers, allocation references, disclosure-history fixture,
Op settlement reducer, and synthetic journal data used by that manuscript.
The historical manuscript association recorded when this archive was assembled
identifies TeX SHA-256
`b5741ab5d21bdd02cc9f4ef1d0da84bf767c1a7f68cdf6a86ba15463f8d9326a`;
the 46-page PDF has SHA-256
`41525d48bfaab6d7078d4e7941efbe46d48af75e7a0f31091638356659d3577a`.
These two hashes retain that historical association. They do not identify the
current paper. The detached publication manifest binds this archive to the
current manuscript and PDF. This metadata clarification is dated 8 September 2026.

All 32 source and fixture files were copied without changing their bytes.
The original package added this README and the dependency list. The current
revision changes only this README. The files are arranged
in separate directories because several references use the same Python module
names. Run each component in its specified directory and process.

## What each component reproduces

| Directory | Manuscript connection and executable scope |
|---|---|
| `timing/` | “Complete causal accounting” and “Threshold capacity and fixed workload evidence”: 2,100 fixed synthetic schedules, their timing summaries, and 256 exact payoff comparisons. |
| `protocol/` | The finite protocol fixtures described in “Result status and implementation boundary”: admission, retention and epoch-service conditions; clock outcomes; release assignment, retry and restart; invalid shares and authentication failure. |
| `finite-model/` | The earlier finite verifier discussed in “Result status and implementation boundary”: quorum and corroboration arithmetic, bond cases, local event-atomic execution, receipts, commutation, causal accounting and units. Its dataclasses and canonical serialization describe that limited local model. |
| `allocation/` | “Certified Compatible Allocation”: exact rational maximum allocation, deterministic lexical selection, and certificate checking, including all 1,296 two-by-two integer batches in the existing test. |
| `durable/` | The same section's persistent allocation construction: signed state changes, fixed and held slices, separate physical and economic identities, one-time allocation, journal replay, six process-crash points and two process-race cases. |
| `history/` | “Disclosure History and Effective Performance”: the existing release/disclosure fixture and persistent history, followed by the performance projection over the included Op reducer and its synthetic provider contract. |

The finite local verifier predates the complete construction's recoverable
event-collection agreement and continuing external plans. It cannot establish
their implementation conformance. No separate per-event consensus message
schema or sample was located among the supplied reference materials. The wire
data included here are the existing allocation and Op journal records described
below. They do not fill that separate consensus wire-format dependency.

## Prerequisites

The commands use a POSIX shell and were checked with CPython 3.14.6 on macOS
arm64, SQLite 3.53.3, `cryptography` 46.0.6, and `unicodedata2` 17.0.1.
Other Python versions and operating systems have not been checked here.
The `unicodedata2` package must expose Unicode **17.0.0**, as required by the
existing canonicalization profile. `cryptography` supplies Ed25519 for the
durable allocation fixture. The other external packages installed transitively
in this environment were `cffi` 2.1.1 and `pycparser` 3.0.

Use a filesystem on which SQLite locking and subprocess creation work. The
durability tests create temporary databases and deliberately terminate worker
processes. They require local write access but no provider account or service.
The extracted directory must be writable: the history probes create temporary
directories beside their own files.
Installing the Python packages requires a package source or a prepopulated
package cache; no platform-specific binary is bundled in this archive.

Extract the ZIP and enter its `event-collect-bft-supplement` directory. Create
the environment once:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
export PYTHONDONTWRITEBYTECODE=1
mkdir -p .run/tmp
export TMPDIR="$PWD/.run/tmp"
python3 -B -c 'import sys, sqlite3, cryptography, unicodedata2; print(sys.version); print(sqlite3.sqlite_version, cryptography.__version__, unicodedata2.unidata_version)'
```

The following commands start at that same archive directory with the environment
active. The parentheses keep each component's working directory local to its
command.

## Finite checks and reference tests

```sh
python3 -B timing/check_latency_parameters.py
python3 -B -O timing/check_latency_parameters.py
python3 -B protocol/check_protocol.py
python3 -B -O protocol/check_protocol.py
python3 -B finite-model/verify_event_collect.py
python3 -B -O finite-model/verify_event_collect.py
(cd allocation && python3 -B -m unittest -v test_allocation)
(cd allocation && python3 -B -O -m unittest -v test_allocation)
(cd durable/reference && python3 -B -m unittest -v test_durable)
(cd durable/reference && python3 -B -O -m unittest -v test_durable)
(cd history/reference && python3 -B -m unittest -v test_history_performance)
(cd history/reference && python3 -B -O -m unittest -v test_history_performance)
python3 -B history/probes/probe_history.py
python3 -B -O history/probes/probe_history.py
python3 -B history/probes/probe_performance.py
python3 -B -O history/probes/probe_performance.py
```

The timing checker reports `status: pass`, `trace_count: 2100`, and
`exact_payoff_cases: 256`. The protocol checker prints its passing finite groups.
The earlier finite verifier reports 67,538 cases. The three unittest components
run 15, 16, and 16 tests respectively. The history unittest suite checks
disclosure eligibility. The existing probes check structured-context retry,
restart, cached shares, conflicting-context rejection, and effective-performance
edge cases and report their outcomes.
The optimized commands exercise the same references with Python assertions
disabled. The durable allocation workers propagate this mode; the history
fixture's existing crash worker starts its own normal Python process.

## Replay the included wire data

`durable/witness/` contains an existing admitted policy, signed journal,
resulting state, and allocation receipt. Its two physical credits each supply
one unit to two compatible duties. The replay below verifies the signed journal
with the supplied policy and compares its result with both saved outputs:

```sh
(
cd durable/reference
python3 -B - <<'PY'
import json
from pathlib import Path
from model import Policy
from ledger import replay

witness = Path('../witness')
read = lambda name: json.loads((witness / name).read_text())
state, receipts = replay(read('journal.json'), Policy(**read('policy.json')))
if state != read('state.json') or receipts[-1] != read('allocation-receipt.json'):
    raise ValueError('SavedAllocationWitnessMismatch')
print('Allocation journal, state and final receipt match.')
PY
)
```

`history/witness/actual-op-journal.json` contains the existing 30-record Op
journal. The four saved reports describe payment of 100, return of 40,
replacement payment of 40, and return of 10 from that replacement. Replay each
saved prefix through the same reducer and compare every report field:

```sh
(
cd history/reference
python3 -B - <<'PY'
import json
from pathlib import Path
from performance import report
from codec import encode, parse
from contract import EvidencePolicy

witness = Path('../witness')
records = parse((witness / 'actual-op-journal.json').read_bytes())
for name in ('first-completion', 'reopened', 'recovered', 'returned-recovery'):
    saved = json.loads((witness / (name + '.json')).read_text())
    current = report(encode(records[:saved['sequence']]), policy=EvidencePolicy(),
                     target='duty', source='immutable-due', expected_head=saved['head'])
    if current != saved:
        raise ValueError('SavedHistoryWitnessMismatch: ' + name)
    print(name, current['first_completed'], current['current_effective'],
          current['outstanding'], current['net_recovery'])
PY
)
```

The four numeric columns are first-completion count, current effective value,
outstanding value, and net recovery. Expected rows are `(1,100,0,0)`,
`(1,60,40,0)`, `(1,100,0,40)`, and `(1,90,10,30)`. A retry does not create a
second original duty; a later return changes current performance while
preserving first completion. Cost and beneficiary-usable latency remain
unknown in these saved reports because no separate measurement evidence was
admitted.

## Assumptions and remaining implementation dependencies

The timing schedules use abstract time units and fixed inputs. Their reported
quantiles are summaries of those inputs, not measured network traffic or
deployed latency distributions. The protocol and disclosure fixtures use
symbolic shares and explicit validity predicates. They contain no TDH2,
distributed key generation, or hybrid-encryption conformance implementation.

The allocation references fix an admitted snapshot, divisible quantities,
compatibility, authority and prior slices. They maximize newly allocated
performance within those premises. The durable fixture uses real Ed25519
verification under a synthetic mandate and one SQLite ledger. Its signatures
do not establish real institutional authority or provider finality.

The history fixture uses the exact included Op source files, checked at import
against `history/reference/op/SOURCE-BINDINGS.json`. The adjacent canonical
profile is also covered by those existing bindings. Its provider authentication
uses a public synthetic HMAC key. The `paid` status concerns its single target,
and does not establish settlement of a complete multi-provider execution plan.
For the saved-data replay, the policy and journal heads are admitted fixture
inputs. The hash chain establishes internal replay consistency, not the
truth or completeness of external facts, beneficiary access, or finality.

Remaining dependencies of the paper's complete implementation claims include
the consensus wire schema and implementation refinement, primitive cryptographic
vectors and setup, retained custody and epoch service, operational clock and
finality evidence, and actual provider/authority/funding contracts and continuing
external-plan transitions. Those are outside these existing finite references.
This archive adds no reference construction, result, or production implementation.
