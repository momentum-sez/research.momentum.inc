"""Exact finite-model checks for duty progress and continuation contracts.

The supplied transition tables define the checked model. These checks do not
authenticate goal records, provider promises, or an executor correspondence.
Run this file to execute its companion acceptance and adverse tests.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from fractions import Fraction
from typing import Hashable, Mapping, Sequence


class ContractError(ValueError):
    """The supplied finite model violates a required contract."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ContractError(message)


def _natural(value: int, label: str) -> int:
    _require(type(value) is int and value >= 0, f"{label}: expected a natural number")
    return value


def _exact(value: int | Fraction, label: str) -> Fraction:
    _require(type(value) in (int, Fraction), f"{label}: expected an exact rational")
    return Fraction(value)


def _text(value: str, label: str) -> None:
    _require(isinstance(value, str) and bool(value), f"{label}: empty or invalid name")


Graph = tuple[frozenset[int], ...]


def _graph(edges: Sequence[Sequence[int]]) -> Graph:
    for row in edges:
        for target in row:
            _natural(target, "state index")
            _require(target < len(edges), "unknown successor state")
    return tuple(frozenset(row) for row in edges)


def _reachable(graph: Graph, initial: int, stop: frozenset[int] = frozenset()) -> frozenset[int]:
    _natural(initial, "initial state")
    _require(initial < len(graph), "unknown initial state")
    reached = {initial}
    pending = [initial]
    while pending:
        state = pending.pop()
        if state in stop:
            continue
        for target in graph[state]:
            if target not in reached:
                reached.add(target)
                pending.append(target)
    return frozenset(reached)


def _longest_completion(graph: Graph, ranks: Sequence[int], initial: int) -> int:
    goals = frozenset(state for state, rank in enumerate(ranks) if rank == 0)
    reached = _reachable(graph, initial, goals)
    lengths = {state: 0 for state in reached if ranks[state] == 0}
    pending = set(reached) - lengths.keys()
    for state in pending:
        _require(bool(graph[state]), "unfinished maximal finite execution")
    while pending:
        ready = {state for state in pending if graph[state] <= lengths.keys()}
        _require(bool(ready), "unfinished execution cycle")
        for state in ready:
            lengths[state] = 1 + max(lengths[target] for target in graph[state])
        pending -= ready
    return lengths[initial]


@dataclass(frozen=True)
class Episode:
    """Immutable identity, canonical portion scope, lineage, and named goal."""

    identity: str
    birth: int
    portions: tuple[str, ...]
    rights_lineage: str
    goal: str


@dataclass(frozen=True)
class EpisodeProgress:
    """One canonical work record, independent of representation aliases."""

    episode: Episode
    remaining: int
    recorded_goal: str | None = None


@dataclass(frozen=True)
class ProgressCertificate:
    initial_rank: int
    bound: int
    exact_worst_case: int
    cohort: tuple[str, ...] = ()


def _episode_records(rows: Sequence[EpisodeProgress]) -> dict[str, EpisodeProgress]:
    records: dict[str, EpisodeProgress] = {}
    births: set[int] = set()
    for row in rows:
        episode = row.episode
        _text(episode.identity, "episode")
        _text(episode.rights_lineage, "rights lineage")
        _text(episode.goal, "goal")
        _require(episode.goal.startswith(("decision:", "discharge:")), "unnamed goal kind")
        _require(bool(episode.goal.split(":", 1)[1]), "goal target is empty")
        _natural(episode.birth, "admission index")
        _natural(row.remaining, "canonical work")
        _require(episode.identity not in records, "duplicate canonical episode rank")
        _require(episode.birth not in births, "duplicate admission index")
        _require(isinstance(episode.portions, tuple) and bool(episode.portions), "empty or mutable canonical portion scope")
        _require(len(set(episode.portions)) == len(episode.portions), "duplicate canonical portion")
        for portion in episode.portions:
            _text(portion, "canonical portion")
        expected_goal = episode.goal if row.remaining == 0 else None
        _require(row.recorded_goal == expected_goal, "rank and declared goal disagree")
        records[episode.identity] = row
        births.add(episode.birth)
    return records


def check_cohort_progress(
    states: Sequence[Sequence[EpisodeProgress]],
    successors: Sequence[Sequence[int]],
    initial: int,
    target_episode: str,
    service_window: int,
) -> ProgressCertificate:
    """Check immutable episodes and every maximal run in a finite service model."""

    _natural(service_window, "service window")
    _require(service_window > 0, "service window must be positive")
    graph = _graph(successors)
    _require(len(states) == len(graph), "state and transition counts differ")
    records = tuple(_episode_records(rows) for rows in states)
    reached = _reachable(graph, initial)
    _require(target_episode in records[initial], "target episode is absent at admission")
    target_birth = records[initial][target_episode].episode.birth
    cohort = tuple(sorted(
        identity for identity, row in records[initial].items()
        if row.episode.birth <= target_birth
    ))
    for state in reached:
        _require(set(cohort) <= records[state].keys(), "original cohort record was lost")
        before = records[state]
        for target in graph[state]:
            after = records[target]
            _require(before.keys() <= after.keys(), "episode record was erased")
            for identity, row in before.items():
                successor = after[identity]
                _require(row.episode == successor.episode, "immutable episode was reset or relabeled")
                if row.recorded_goal is not None:
                    _require(successor.recorded_goal == row.recorded_goal, "completed episode was reopened in place")
            newest = max((row.episode.birth for row in before.values()), default=-1)
            for identity in after.keys() - before.keys():
                _require(after[identity].episode.birth > newest, "later admission entered an earlier cohort")
    ranks = tuple(
        sum(rows[identity].remaining for identity in cohort) if state in reached else 0
        for state, rows in enumerate(records)
    )
    pending = {state for state in reached if ranks[state] > 0}
    equal_edges: dict[int, frozenset[int]] = {}
    for state in reached:
        for target in graph[state]:
            _require(ranks[target] <= ranks[state], "aggregate cohort rank increased")
        if state in pending:
            _require(bool(graph[state]), "unfinished maximal finite execution")
            equal_edges[state] = frozenset(
                target for target in graph[state] if ranks[target] == ranks[state]
            )
    gaps: dict[int, int] = {}
    while pending:
        ready = {state for state in pending if equal_edges[state] <= gaps.keys()}
        _require(bool(ready), "productive service permits an infinite constant-rank run")
        for state in ready:
            gaps[state] = 1 + max((gaps[target] for target in equal_edges[state]), default=0)
            _require(gaps[state] <= service_window, "productive service exceeds its window")
        pending -= ready
    worst = _longest_completion(graph, ranks, initial)
    bound = service_window * ranks[initial]
    _require(worst <= bound, "cohort bound failed")
    return ProgressCertificate(ranks[initial], bound, worst, cohort)


@dataclass(frozen=True)
class ConcreteProgress:
    rank: int
    counter: int
    goal_recorded: bool


def check_productive_realization(
    states: Sequence[ConcreteProgress],
    successors: Sequence[Sequence[int]],
    initial: int,
    hidden_bound: int,
) -> ProgressCertificate:
    """Check the decreasing concrete potential, including unfinished deadlocks."""

    _natural(hidden_bound, "hidden-work bound")
    graph = _graph(successors)
    _require(len(states) == len(graph), "state and transition counts differ")
    for state in states:
        _natural(state.rank, "rank")
        _natural(state.counter, "counter")
        _require(state.counter <= hidden_bound, "counter exceeds its bound")
        _require(type(state.goal_recorded) is bool, "goal marker is not Boolean")
        _require((state.rank == 0) == state.goal_recorded, "rank zero does not name completion")
    goals = frozenset(state for state, row in enumerate(states) if row.rank == 0)
    reached = _reachable(graph, initial, goals)
    for index in reached:
        before = states[index]
        if before.rank == 0:
            continue
        _require(bool(graph[index]), "unfinished maximal finite execution")
        for target in graph[index]:
            after = states[target]
            productive = after.rank < before.rank
            silent = after.rank == before.rank and after.counter < before.counter
            _require(productive or silent, "concrete step is not productive")
    start = states[initial]
    bound = 0 if start.rank == 0 else (
        (hidden_bound + 1) * (start.rank - 1) + start.counter + 1
    )
    worst = _longest_completion(graph, tuple(state.rank for state in states), initial)
    _require(worst <= bound, "concrete potential bound failed")
    return ProgressCertificate(start.rank, bound, worst)


@dataclass(frozen=True)
class SlotFrame:
    slots: tuple[str | None, ...]
    completed: frozenset[str] = frozenset()

    def clear(self) -> tuple[bool, ...]:
        return tuple(episode is None or episode in self.completed for episode in self.slots)


def check_slot_history(frames: Sequence[SlotFrame]) -> bool:
    """Check latching on an observed finite prefix, without claiming recurrence."""

    _require(bool(frames) and bool(frames[0].slots), "a positive finite slot count is required")
    count = len(frames[0].slots)
    for frame in frames:
        _require(len(frame.slots) == count, "slot count changed")
        occupied = [episode for episode in frame.slots if episode is not None]
        _require(len(set(occupied)) == len(occupied), "one episode occupies two slots")
        for episode in (*occupied, *frame.completed):
            _text(episode, "slot episode")
    seen = set(frames[0].completed) | {episode for episode in frames[0].slots if episode is not None}
    for before, after in zip(frames, frames[1:]):
        _require(before.completed <= after.completed, "completion record was lost")
        newly_admitted: set[str] = set()
        for old, new in zip(before.slots, after.slots):
            if old is not None and old not in before.completed and new != old:
                _require(new is None and old in after.completed, "unfinished slot overwritten without observed clear")
            if new is not None and new != old:
                _require(new not in seen, "episode identity was reused")
                newly_admitted.add(new)
        seen |= newly_admitted
        _require(after.completed <= seen, "completion names an unadmitted episode")
    return True


def monitor_step(clear: Sequence[bool], pointer: int) -> tuple[int, bool]:
    """Advance exactly on the observed clear slot and emit a fresh wrap pulse."""

    _require(bool(clear), "a positive finite slot count is required")
    _natural(pointer, "monitor pointer")
    _require(pointer < len(clear), "monitor pointer is outside its slots")
    _require(all(type(value) is bool for value in clear), "clear observations must be Boolean")
    if not clear[pointer]:
        return pointer, False
    return (pointer + 1) % len(clear), pointer == len(clear) - 1


def monitor_cycle_accepts(cycle: Sequence[Sequence[bool]], pointer: int = 0) -> bool:
    """Decide recurrence for an exact periodic observation suffix."""

    _require(bool(cycle), "periodic suffix is empty")
    count = len(cycle[0])
    _require(all(len(frame) == count for frame in cycle), "slot count changed")
    phase = 0
    seen: dict[tuple[int, int], int] = {}
    pulses: list[bool] = []
    while (phase, pointer) not in seen:
        seen[(phase, pointer)] = len(pulses)
        pointer, pulse = monitor_step(cycle[phase], pointer)
        pulses.append(pulse)
        phase = (phase + 1) % len(cycle)
    return any(pulses[seen[(phase, pointer)]:])


@dataclass(frozen=True)
class BuchiCertificate:
    winning: frozenset[int]
    policy: Mapping[int, int]
    attractor_rank: Mapping[int, int]


def safe_buchi_game(
    actions: Sequence[Sequence[Sequence[int]]], safe: frozenset[int], pulses: frozenset[int]
) -> BuchiCertificate:
    """Solve the exact finite controller-then-adversary recurrence game."""

    count = len(actions)
    for index in (*safe, *pulses, *(target for choices in actions for row in choices for target in row)):
        _natural(index, "game state")
        _require(index < count, "unknown game state")
    game = tuple(tuple(frozenset(row) for row in choices) for choices in actions)
    _require(pulses <= safe, "pulse set is outside safety")

    def choices_into(state: int, target: set[int] | frozenset[int]) -> list[int]:
        return [index for index, row in enumerate(game[state]) if row and row <= target]

    def predecessor(target: set[int] | frozenset[int]) -> set[int]:
        return {state for state in safe if choices_into(state, target)}

    outer = set(safe)
    while True:
        target = pulses & predecessor(outer)
        inner: set[int] = set()
        policy: dict[int, int] = {}
        ranks: dict[int, int] = {}
        level = 0
        while True:
            expanded = target | predecessor(inner)
            if expanded == inner:
                break
            for state in expanded - inner:
                destination = outer if state in target else inner
                policy[state] = choices_into(state, destination)[0]
                ranks[state] = level
            inner = expanded
            level += 1
        if inner == outer:
            return BuchiCertificate(frozenset(outer), policy, ranks)
        outer = inner


@dataclass(frozen=True)
class InterfaceStep:
    successor: int
    status: str
    output: Hashable


@dataclass(frozen=True)
class FiniteInterface:
    """A complete table with exact int, str, bytes, or recursive tuple labels.

    Other observation types need an injective typed encoding over the full
    protected domain, including native labels. The checker does not establish
    that adapter correspondence.
    """

    observations: tuple[Hashable, ...]
    actions: tuple[str, ...]
    steps: tuple[tuple[InterfaceStep, ...], ...]


def _interface_label(value: object, label: str) -> None:
    """Reject Python equalities that could erase a protected type distinction."""

    pending = [value]
    while pending:
        item = pending.pop()
        kind = type(item)
        if kind is tuple:
            pending.extend(item)
        else:
            _require(kind is int or kind is str or kind is bytes,
                     f"{label}: expected exact int, str, bytes, or recursive tuple")


def _interface(interface: FiniteInterface) -> None:
    count = len(interface.observations)
    _require(count > 0 and len(interface.steps) == count, "invalid finite interface state count")
    for action in interface.actions:
        _require(type(action) is str and bool(action), "action: expected a nonempty exact str")
    _require(len(set(interface.actions)) == len(interface.actions), "duplicate action name")
    for observation, row in zip(interface.observations, interface.steps):
        _require(len(row) == len(interface.actions), "incomplete action table")
        _interface_label(observation, "current observation")
        for step in row:
            _natural(step.successor, "successor")
            _require(step.successor < count, "unknown interface successor")
            _require(type(step.status) is str and step.status in {"accepted", "refused", "unavailable", "awaiting"},
                     "missing or noncanonical action outcome status")
            _interface_label(step.output, "action observation")


def _partition(keys: Sequence[Hashable]) -> tuple[int, ...]:
    blocks: dict[Hashable, int] = {}
    return tuple(blocks.setdefault(key, len(blocks)) for key in keys)


def future_partition(interface: FiniteInterface) -> tuple[int, ...]:
    """Compute the coarsest congruence by exhaustive one-step refinement."""

    _interface(interface)
    blocks = _partition(interface.observations)
    while True:
        refined = _partition(tuple(
            (blocks[state], tuple((step.status, step.output, blocks[step.successor]) for step in row))
            for state, row in enumerate(interface.steps)
        ))
        if refined == blocks:
            return blocks
        blocks = refined


def check_congruence(interface: FiniteInterface, blocks: Sequence[int]) -> bool:
    """Check any proposed congruence, including valid finer partitions."""

    _interface(interface)
    _require(len(blocks) == len(interface.observations), "partition is not exhaustive")
    representatives: dict[int, int] = {}
    for state, block in enumerate(blocks):
        _natural(block, "partition block")
        other = representatives.setdefault(block, state)
        _require(interface.observations[state] == interface.observations[other], "protected current observations differ")
        for left, right in zip(interface.steps[state], interface.steps[other]):
            _require((left.status, left.output) == (right.status, right.output), "action outcomes differ")
            _require(blocks[left.successor] == blocks[right.successor], "successor blocks differ")
    return True


def check_projection(source: FiniteInterface, quotient: FiniteInterface, projection: Sequence[int]) -> bool:
    """Check the complete quotient implementation equations."""

    _interface(source)
    _interface(quotient)
    _require(source.actions == quotient.actions, "action alphabets differ")
    _require(len(projection) == len(source.observations), "projection is incomplete")
    for target in projection:
        _natural(target, "projected state")
        _require(target < len(quotient.observations), "projected state is unknown")
    _require(set(projection) == set(range(len(quotient.observations))), "projection is not surjective")
    for state, target in enumerate(projection):
        _require(source.observations[state] == quotient.observations[target], "projection changes a current observation")
        for left, right in zip(source.steps[state], quotient.steps[target]):
            _require((left.status, left.output) == (right.status, right.output), "projection changes an action outcome")
            _require(projection[left.successor] == right.successor, "projection changes a successor")
    return True


def distinguishing_word(interface: FiniteInterface, left: int, right: int) -> tuple[str, ...] | None:
    """Find a shortest exact distinguishing word in the finite pair graph."""

    _interface(interface)
    for state in (left, right):
        _natural(state, "comparison state")
        _require(state < len(interface.observations), "comparison state is unknown")
    pending = deque([(left, right, ())])
    seen = {(left, right)}
    while pending:
        first, second, word = pending.popleft()
        if interface.observations[first] != interface.observations[second]:
            return word
        for action, a, b in zip(interface.actions, interface.steps[first], interface.steps[second]):
            extension = word + (action,)
            if (a.status, a.output) != (b.status, b.output):
                return extension
            if interface.observations[a.successor] != interface.observations[b.successor]:
                return extension
            pair = (a.successor, b.successor)
            if pair not in seen:
                seen.add(pair)
                pending.append((*pair, extension))
    return None


@dataclass(frozen=True)
class TraceCertificate:
    equivalent: bool
    dimension: int
    stabilization_index: int
    witness: tuple[tuple[str, str], ...] | None


def stochastic_trace_certificate(
    matrices: Mapping[tuple[str, str], Sequence[Sequence[int | Fraction]]],
    left: Sequence[int | Fraction],
    right: Sequence[int | Fraction],
) -> TraceCertificate:
    """Check all finite output-labelled trace laws by exact rational spans."""

    count = len(left)
    _require(count > 0 and len(right) == count and bool(matrices), "invalid stochastic interface size")
    distributions = tuple(tuple(_exact(value, "initial probability") for value in row) for row in (left, right))
    for row in distributions:
        _require(all(value >= 0 for value in row) and sum(row) == 1, "invalid initial distribution")
    kernels: dict[tuple[str, str], tuple[tuple[Fraction, ...], ...]] = {}
    for symbol, matrix in matrices.items():
        _interface_label(symbol, "stochastic symbol")
        _require(type(symbol) is tuple and len(symbol) == 2, "complete symbols require action and output")
        _text(symbol[0], "stochastic action")
        _text(symbol[1], "stochastic output")
        rows = tuple(tuple(_exact(value, "transition probability") for value in row) for row in matrix)
        _require(len(rows) == count and all(len(row) == count for row in rows), "matrix dimension differs")
        _require(all(value >= 0 for row in rows for value in row), "negative transition probability")
        kernels[symbol] = rows
    for action in {symbol[0] for symbol in kernels}:
        for state in range(count):
            mass = sum(sum(matrix[state]) for symbol, matrix in kernels.items() if symbol[0] == action)
            _require(mass == 1, "output kernels do not form a stochastic action")

    echelon: list[tuple[int, tuple[Fraction, ...]]] = []

    def add_independent(vector: tuple[Fraction, ...]) -> bool:
        residual = list(vector)
        for pivot, row in echelon:
            factor = residual[pivot]
            residual = [value - factor * basis for value, basis in zip(residual, row)]
        pivot = next((index for index, value in enumerate(residual) if value), None)
        if pivot is None:
            return False
        scale = residual[pivot]
        echelon.append((pivot, tuple(value / scale for value in residual)))
        echelon.sort(key=lambda item: item[0])
        return True

    ones = (Fraction(1),) * count
    add_independent(ones)
    basis = [((), ones)]
    index = 0
    while True:
        previous = tuple(basis)
        for word, vector in previous:
            for symbol in sorted(kernels):
                image = tuple(sum(a * b for a, b in zip(row, vector)) for row in kernels[symbol])
                if add_independent(image):
                    basis.append(((symbol,) + word, image))
        if len(basis) == len(previous):
            break
        index += 1
    _require(index <= count - 1, "invariant span exceeded its dimension bound")
    difference = tuple(a - b for a, b in zip(*distributions))
    witness = next((word for word, vector in basis if sum(a * b for a, b in zip(difference, vector)) != 0), None)
    return TraceCertificate(witness is None, len(basis), index, witness)


def bootstrap_closure(predecessors: Sequence[Sequence[int]], seeds: frozenset[int]) -> frozenset[int]:
    """Compute the least closure under all-prerequisite readiness rules."""

    graph = _graph(predecessors)
    for seed in seeds:
        _natural(seed, "seed")
        _require(seed < len(graph), "unknown seed")
    ready = set(seeds)
    while True:
        expanded = ready | {state for state, row in enumerate(graph) if row <= ready}
        if expanded == ready:
            return frozenset(ready)
        ready = expanded


def _topological(predecessors: Graph) -> tuple[int, ...] | None:
    order: list[int] = []
    pending = set(range(len(predecessors)))
    while pending:
        ready = {state for state in pending if predecessors[state] <= set(order)}
        if not ready:
            return None
        order.extend(sorted(ready))
        pending -= ready
    return tuple(order)


def _components(graph: Graph) -> tuple[frozenset[int], ...]:
    reachable = tuple(_reachable(graph, state) for state in range(len(graph)))
    remaining = set(range(len(graph)))
    components = []
    while remaining:
        first = min(remaining)
        component = frozenset(state for state in remaining if state in reachable[first] and first in reachable[state])
        components.append(component)
        remaining -= component
    return tuple(components)


@dataclass(frozen=True)
class CompletionContract:
    prerequisites: frozenset[int]
    latency: int | Fraction
    clock: str
    reservations: tuple[int | Fraction, ...] = ()


@dataclass(frozen=True)
class ProviderCertificate:
    bounds: tuple[Fraction, ...]
    bootstrap: frozenset[int]
    components: tuple[frozenset[int], ...]


def provider_completion_bounds(
    contracts: Sequence[CompletionContract],
    clock: str,
    capacity: Sequence[int | Fraction] = (),
    *,
    seeds: Mapping[int, int | Fraction] | None = None,
    component_latencies: Mapping[frozenset[int], int | Fraction] | None = None,
) -> ProviderCertificate:
    """Check a finite timed plan with simultaneous shared reservations.

    Seed and component deadlines are supplied premises. The checker verifies
    their composition, not their legal authority or external performance.
    """

    _text(clock, "admitted clock")
    graph = _graph(tuple(contract.prerequisites for contract in contracts))
    budget = tuple(_exact(value, "capacity") for value in capacity)
    _require(all(value >= 0 for value in budget), "negative resource capacity")
    reserved = [Fraction(0)] * len(budget)
    latencies = []
    for contract in contracts:
        _require(contract.clock == clock, "provider contracts use different clocks")
        latency = _exact(contract.latency, "provider latency")
        _require(latency >= 0, "negative provider latency")
        latencies.append(latency)
        row = tuple(_exact(value, "reservation") for value in contract.reservations)
        _require(len(row) == len(budget) and all(value >= 0 for value in row), "invalid reservation vector")
        reserved = [total + value for total, value in zip(reserved, row)]
    _require(all(total <= available for total, available in zip(reserved, budget)), "joint reservations exceed shared capacity")
    seed_times: dict[int, Fraction] = {}
    for seed, time in (seeds or {}).items():
        _natural(seed, "seed")
        _require(seed < len(graph), "unknown seed")
        deadline = _exact(time, "seed deadline")
        _require(deadline >= 0, "negative seed deadline")
        seed_times[seed] = deadline
    joint: dict[frozenset[int], Fraction] = {}
    for component, time in (component_latencies or {}).items():
        _require(isinstance(component, frozenset) and bool(component), "invalid component contract")
        for state in component:
            _natural(state, "component state")
            _require(state < len(graph), "unknown component state")
        latency = _exact(time, "joint component latency")
        _require(latency >= 0, "negative component latency")
        joint[component] = latency
    closure = bootstrap_closure(graph, frozenset(seed_times))
    bounds = [Fraction(0)] * len(graph)
    order = _topological(graph)
    if order is not None:
        _require(not joint, "component contract does not name a cyclic component")
        for state in order:
            ordinary = latencies[state] + max((bounds[pred] for pred in graph[state]), default=Fraction(0))
            bounds[state] = min(ordinary, seed_times.get(state, ordinary))
        return ProviderCertificate(tuple(bounds), closure, tuple(frozenset({state}) for state in order))

    # Selecting an external seed rule removes that vertex's prerequisite edges.
    selected = tuple(frozenset() if state in seed_times else row for state, row in enumerate(graph))
    components = _components(selected)
    cyclic = {part for part in components if len(part) > 1 or next(iter(part)) in selected[next(iter(part))]}
    _require(joint.keys() <= cyclic, "joint contract does not name a selected cyclic component")
    _require(cyclic <= joint.keys(), "unseeded cycle lacks a joint completion contract")
    owner = {state: index for index, part in enumerate(components) for state in part}
    component_graph = tuple(frozenset(
        owner[pred] for state in part for pred in selected[state] if pred not in part
    ) for part in components)
    component_order = _topological(component_graph)
    _require(component_order is not None, "component graph is cyclic")
    component_bounds: dict[int, Fraction] = {}
    for index in component_order:
        part = components[index]
        start = max((component_bounds[pred] for pred in component_graph[index]), default=Fraction(0))
        if part in joint:
            deadline = start + joint[part]
        else:
            state = next(iter(part))
            deadline = seed_times[state] if state in seed_times else start + latencies[state]
        component_bounds[index] = deadline
        for state in part:
            bounds[state] = deadline
    return ProviderCertificate(tuple(bounds), closure, components)


if __name__ == "__main__":
    import unittest

    unittest.main(module="test_verify_duty_progress", verbosity=2)
