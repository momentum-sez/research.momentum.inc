"""Acceptance and adverse checks for the exact finite contract models."""

from dataclasses import replace
from fractions import Fraction
from itertools import product
import unittest

from verify_duty_progress import (
    CompletionContract,
    ConcreteProgress,
    ContractError,
    Episode,
    EpisodeProgress,
    FiniteInterface,
    InterfaceStep,
    SlotFrame,
    bootstrap_closure,
    check_cohort_progress,
    check_congruence,
    check_productive_realization,
    check_projection,
    check_slot_history,
    distinguishing_word,
    future_partition,
    monitor_cycle_accepts,
    monitor_step,
    provider_completion_bounds,
    safe_buchi_game,
    stochastic_trace_certificate,
)


def progress(identity: str, birth: int, remaining: int, kind: str = "discharge") -> EpisodeProgress:
    episode = Episode(identity, birth, (f"portion:{identity}",), f"lineage:{identity}", f"{kind}:{identity}")
    return EpisodeProgress(episode, remaining, episode.goal if remaining == 0 else None)


def has_cycle(graph, vertices) -> bool:
    """Independent depth-first cycle oracle for a selected induced graph."""

    visited = set()
    active = set()

    def visit(state):
        if state in active:
            return True
        if state in visited:
            return False
        visited.add(state)
        active.add(state)
        for target in graph[state]:
            if target in vertices and visit(target):
                return True
        active.remove(state)
        return False

    return any(visit(state) for state in vertices)


def policy_wins(game, safe, pulses, policy, initial) -> bool:
    """Decide a fixed policy by reachable deadlocks and pulse-free cycles."""

    graph = tuple(game[state][policy[state]] for state in range(len(game)))
    reached = {initial}
    pending = [initial]
    while pending:
        state = pending.pop()
        if state not in safe or not graph[state]:
            return False
        for target in graph[state]:
            if target not in reached:
                reached.add(target)
                pending.append(target)
    return not has_cycle(graph, reached - pulses)


def observed_trace(interface, initial, word):
    state = initial
    trace = [interface.observations[state]]
    for action in word:
        step = interface.steps[state][interface.actions.index(action)]
        trace.append((step.status, step.output))
        state = step.successor
        trace.append(interface.observations[state])
    return tuple(trace)


def trace_probability(matrices, initial, word):
    row = tuple(Fraction(value) for value in initial)
    for symbol in word:
        matrix = matrices[symbol]
        row = tuple(sum(row[i] * matrix[i][j] for i in range(len(row))) for j in range(len(row)))
    return sum(row)


class CohortTests(unittest.TestCase):
    def test_original_cohort_allows_redistribution_and_later_arrivals(self):
        later = progress("later", 2, 1000)
        states = (
            (progress("first", 0, 1), progress("target", 1, 2)),
            (progress("first", 0, 2), progress("target", 1, 1), later),
            (progress("first", 0, 1), progress("target", 1, 1), later),
            (progress("first", 0, 0), progress("target", 1, 1), later),
            (progress("first", 0, 0), progress("target", 1, 0), later),
        )
        certificate = check_cohort_progress(states, ({1}, {2}, {3}, {4}, {4}), 0, "target", 2)
        self.assertEqual(certificate.cohort, ("first", "target"))
        self.assertEqual((certificate.initial_rank, certificate.bound, certificate.exact_worst_case), (3, 6, 4))

    def test_exact_service_window_and_sharp_cohort_bound(self):
        states = tuple((progress("d", 0, rank),) for rank in (2, 2, 1, 1, 0))
        graph = ({1}, {2}, {3}, {4}, set())
        certificate = check_cohort_progress(states, graph, 0, "d", 2)
        self.assertEqual(certificate.bound, 4)
        self.assertEqual(certificate.exact_worst_case, 4)
        with self.assertRaisesRegex(ContractError, "exceeds its window"):
            check_cohort_progress(states, graph, 0, "d", 1)

    def test_unfinished_deadlock_and_infinite_selection_are_rejected(self):
        state = ((progress("d", 0, 1),),)
        with self.assertRaisesRegex(ContractError, "maximal finite"):
            check_cohort_progress(state, (set(),), 0, "d", 10)
        with self.assertRaisesRegex(ContractError, "constant-rank"):
            check_cohort_progress(state, ({0},), 0, "d", 10)

    def test_short_halted_run_cannot_evade_a_long_service_window(self):
        states = ((progress("d", 0, 2),), (progress("d", 0, 1),))
        with self.assertRaisesRegex(ContractError, "maximal finite"):
            check_cohort_progress(states, ({1}, set()), 0, "d", 100)

    def test_goal_zero_is_an_actual_named_record(self):
        done = progress("d", 0, 0)
        certificate = check_cohort_progress(((done,),), (set(),), 0, "d", 1)
        self.assertEqual((certificate.bound, certificate.exact_worst_case), (0, 0))
        for bad in (replace(done, recorded_goal=None), replace(done, recorded_goal="decision:refused")):
            with self.assertRaisesRegex(ContractError, "goal disagree"):
                check_cohort_progress(((bad,),), (set(),), 0, "d", 1)

    def test_decision_progress_cannot_be_renamed_discharge(self):
        pending = progress("d", 0, 1)
        refused = progress("d", 0, 0, "decision")
        with self.assertRaisesRegex(ContractError, "reset or relabeled"):
            check_cohort_progress(((pending,), (refused,)), ({1}, set()), 0, "d", 1)
        result = check_cohort_progress(((progress("d", 0, 1, "decision"),), (refused,)), ({1}, set()), 0, "d", 1)
        self.assertEqual(result.exact_worst_case, 1)

    def test_retries_cannot_reset_birth_or_copy_alias_rank(self):
        pending = progress("d", 0, 1)
        reset = replace(pending, episode=replace(pending.episode, birth=1))
        with self.assertRaisesRegex(ContractError, "reset or relabeled"):
            check_cohort_progress(((pending,), (reset,)), ({1}, {1}), 0, "d", 1)
        with self.assertRaisesRegex(ContractError, "duplicate canonical"):
            check_cohort_progress(((pending, pending),), ({0},), 0, "d", 1)

    def test_completed_episode_is_not_reopened_in_place(self):
        done = progress("d", 0, 0)
        reopened = progress("d", 0, 1)
        with self.assertRaisesRegex(ContractError, "reopened in place"):
            check_cohort_progress(((done,), (reopened,)), ({1}, {1}), 0, "d", 1)
        fresh = progress("reopening", 1, 3)
        certificate = check_cohort_progress(((done,), (done, fresh)), ({1}, {1}), 0, "d", 1)
        self.assertEqual(certificate.bound, 0)

    def test_integer_rank_and_fixed_admission_order_are_required(self):
        row = progress("d", 0, 1)
        for amount in (Fraction(1, 2), 1.0, True, -1):
            with self.assertRaises(ContractError):
                check_cohort_progress(((replace(row, remaining=amount),),), ({0},), 0, "d", 1)
        earlier = progress("new", 0, 1)
        target = progress("d", 2, 1)
        with self.assertRaisesRegex(ContractError, "earlier cohort"):
            check_cohort_progress(((target,), (target, earlier)), ({1}, {1}), 0, "d", 1)
        with self.assertRaises(ContractError):
            check_cohort_progress(((row,),), ({0},), 0, "d", 0)

    def test_aggregate_increase_is_rejected(self):
        states = ((progress("d", 0, 1),), (progress("d", 0, 2),))
        with self.assertRaisesRegex(ContractError, "aggregate cohort rank increased"):
            check_cohort_progress(states, ({1}, {1}), 0, "d", 1)

    def test_boolean_state_indices_do_not_hide_in_set_normalization(self):
        states = ((progress("d", 0, 1),), (progress("d", 0, 0),))
        with self.assertRaisesRegex(ContractError, "natural number"):
            check_cohort_progress(states, ([1, True], []), 0, "d", 1)


class ProductiveTests(unittest.TestCase):
    def test_all_allowed_edges_attain_the_sharp_bound(self):
        cases = 0
        for rank in range(1, 7):
            for hidden in range(5):
                states = (ConcreteProgress(0, 0, True),) + tuple(
                    ConcreteProgress(r, u, False) for r in range(1, rank + 1) for u in range(hidden + 1)
                )
                graph = tuple(frozenset(
                    j for j, after in enumerate(states)
                    if before.rank > 0 and (
                        after.rank < before.rank or
                        (after.rank == before.rank and after.counter < before.counter)
                    )
                ) for before in states)
                for counter in range(hidden + 1):
                    initial = states.index(ConcreteProgress(rank, counter, False))
                    certificate = check_productive_realization(states, graph, initial, hidden)
                    expected = (hidden + 1) * (rank - 1) + counter + 1
                    self.assertEqual(certificate.exact_worst_case, expected)
                    self.assertEqual(certificate.bound, expected)
                    self.assertLessEqual(expected, rank * (hidden + 1))
                    cases += 1
        self.assertEqual(cases, 90)

    def test_zero_goal_hidden_zero_deadlock_and_stutter(self):
        complete = (ConcreteProgress(0, 0, True),)
        self.assertEqual(check_productive_realization(complete, (set(),), 0, 0).bound, 0)
        unfinished = (ConcreteProgress(1, 0, False),)
        with self.assertRaisesRegex(ContractError, "maximal finite"):
            check_productive_realization(unfinished, (set(),), 0, 0)
        with self.assertRaisesRegex(ContractError, "not productive"):
            check_productive_realization(unfinished, ({0},), 0, 0)

    def test_migration_cannot_reset_the_hidden_counter(self):
        states = (ConcreteProgress(1, 0, False), ConcreteProgress(1, 1, False))
        with self.assertRaisesRegex(ContractError, "not productive"):
            check_productive_realization(states, ({1}, {0}), 0, 1)
        with self.assertRaisesRegex(ContractError, "rank zero"):
            check_productive_realization((ConcreteProgress(0, 0, False),), (set(),), 0, 0)

    def test_first_completion_does_not_charge_a_later_execution(self):
        states = (ConcreteProgress(1, 0, False), ConcreteProgress(0, 0, True), ConcreteProgress(2, 0, False))
        result = check_productive_realization(states, ({1}, {2}, {2}), 0, 0)
        self.assertEqual((result.bound, result.exact_worst_case), (1, 1))


class MonitorTests(unittest.TestCase):
    def test_clear_observation_is_required_before_reuse(self):
        frames = (
            SlotFrame(("a", "b")),
            SlotFrame(("a", None), frozenset({"b"})),
            SlotFrame((None, None), frozenset({"a", "b"})),
            SlotFrame(("c", None), frozenset({"a", "b"})),
        )
        self.assertTrue(check_slot_history(frames))
        with self.assertRaisesRegex(ContractError, "without observed clear"):
            check_slot_history((SlotFrame(("a",)), SlotFrame(("b",), frozenset({"a"}))))
        with self.assertRaisesRegex(ContractError, "identity was reused"):
            check_slot_history((SlotFrame(("a",)), SlotFrame((None,), frozenset({"a"})), SlotFrame(("a",), frozenset({"a"}))))

    def test_completed_occupied_slot_is_an_observed_clear(self):
        frames = (SlotFrame(("a",)), SlotFrame(("a",), frozenset({"a"})), SlotFrame(("b",), frozenset({"a"})))
        self.assertEqual(frames[1].clear(), (True,))
        self.assertTrue(check_slot_history(frames))

    def test_pulse_is_fresh_and_pointer_is_not_acceptance(self):
        self.assertEqual(monitor_step((True,), 0), (0, True))
        self.assertEqual(monitor_step((False,), 0), (0, False))
        self.assertFalse(monitor_cycle_accepts(((False,),)))
        self.assertFalse(monitor_cycle_accepts(((False, True),)))
        self.assertTrue(monitor_cycle_accepts(((True, True),)))
        with self.assertRaises(ContractError):
            monitor_step((), 0)

    def test_exhaustive_periodic_suffixes_match_each_slot_recurrence(self):
        cases = 0
        for count in range(1, 4):
            alphabet = tuple(product((False, True), repeat=count))
            for period in range(1, 4):
                for cycle in product(alphabet, repeat=period):
                    expected = all(any(frame[slot] for frame in cycle) for slot in range(count))
                    for pointer in range(count):
                        self.assertEqual(monitor_cycle_accepts(cycle, pointer), expected)
                        cases += 1
        self.assertEqual(cases, 1934)

    def test_exhaustive_two_state_games_match_independent_strategy_oracle(self):
        subsets = tuple(frozenset(state for state in range(2) if mask & (1 << state)) for mask in range(4))
        cases = 0
        for rows in product(subsets, repeat=4):
            game = (rows[:2], rows[2:])
            for safe in subsets:
                for pulses in subsets:
                    if not pulses <= safe:
                        continue
                    expected = frozenset(state for state in range(2) if any(
                        policy_wins(game, safe, pulses, policy, state)
                        for policy in product(range(2), repeat=2)
                    ))
                    certificate = safe_buchi_game(game, safe, pulses)
                    self.assertEqual(certificate.winning, expected)
                    policy = tuple(certificate.policy.get(state, 0) for state in range(2))
                    for state in expected:
                        self.assertTrue(policy_wins(game, safe, pulses, policy, state))
                        for target in game[state][policy[state]]:
                            self.assertIn(target, expected)
                            if state not in pulses:
                                self.assertLess(certificate.attractor_rank[target], certificate.attractor_rank[state])
                    cases += 1
        self.assertEqual(cases, 2304)

    def test_deadlock_is_losing_and_completed_idle_is_explicit(self):
        self.assertEqual(safe_buchi_game(((set(),),), frozenset({0}), frozenset({0})).winning, frozenset())
        self.assertEqual(safe_buchi_game((({0},),), frozenset({0}), frozenset({0})).winning, frozenset({0}))
        self.assertEqual(safe_buchi_game((({0},),), frozenset({0}), frozenset()).winning, frozenset())
        game = (({1, 2},), ({1},), ({2},))
        self.assertNotIn(0, safe_buchi_game(game, frozenset({0, 1}), frozenset({1})).winning)


class QuotientTests(unittest.TestCase):
    @staticmethod
    def unsupported_labels():
        class IntegerAlias(int):
            pass

        class StringAlias(str):
            pass

        class BytesAlias(bytes):
            pass

        class TupleAlias(tuple):
            pass

        return (False, True, 0.0, Fraction(0), frozenset(), None, object(),
                IntegerAlias(0), StringAlias("0"), BytesAlias(b"0"), TupleAlias((0,)),
                [0], {"value": 0})

    def assert_rejected_by_every_entry_point(self, interface, message):
        valid = FiniteInterface((0, 0), ("observe",), (
            (InterfaceStep(0, "accepted", 0),),
            (InterfaceStep(1, "accepted", 0),),
        ))
        checks = {
            "partition": lambda: future_partition(interface),
            "congruence": lambda: check_congruence(interface, (0, 0)),
            "witness": lambda: distinguishing_word(interface, 0, 1),
            "source projection": lambda: check_projection(interface, valid, (0, 1)),
            "quotient projection": lambda: check_projection(valid, interface, (0, 1)),
        }
        for name, check in checks.items():
            with self.subTest(entry_point=name), self.assertRaisesRegex(ContractError, message):
                check()

    def test_ambiguous_current_labels_are_rejected_at_every_entry_point(self):
        steps = ((InterfaceStep(0, "accepted", 0),), (InterfaceStep(1, "accepted", 0),))
        for value in self.unsupported_labels():
            for label in (value, (b"record", (value,))):
                with self.subTest(label=label):
                    interface = FiniteInterface((label, 0), ("observe",), steps)
                    self.assert_rejected_by_every_entry_point(interface, "current observation: expected exact")

    def test_ambiguous_output_labels_are_rejected_at_every_entry_point(self):
        for value in self.unsupported_labels():
            for label in (value, (b"record", (value,))):
                with self.subTest(label=label):
                    interface = FiniteInterface((0, 0), ("observe",), (
                        (InterfaceStep(0, "accepted", label),),
                        (InterfaceStep(1, "accepted", 0),),
                    ))
                    self.assert_rejected_by_every_entry_point(interface, "action observation: expected exact")

    def test_typed_encodings_preserve_current_and_output_distinctions(self):
        labels = (0, "0", b"0", (0,), ("0",), (b"0",),
                  (b"record", (0, "0", b"0")), b"bool:false", b"int:0")
        separate = tuple(range(len(labels)))
        current = FiniteInterface(labels, (), tuple(() for _ in labels))
        outputs = FiniteInterface((0,) * len(labels), ("observe",), tuple(
            (InterfaceStep(state, "accepted", label),) for state, label in enumerate(labels)
        ))
        for interface, witness in ((current, ()), (outputs, ("observe",))):
            self.assertEqual(future_partition(interface), separate)
            self.assertTrue(check_congruence(interface, separate))
            self.assertTrue(check_projection(interface, interface, separate))
            for first in range(len(labels)):
                for second in range(first + 1, len(labels)):
                    self.assertEqual(distinguishing_word(interface, first, second), witness)
            with self.assertRaises(ContractError):
                check_congruence(interface, (0,) * len(labels))
        self.assertNotEqual(labels[-2], labels[-1])

    def test_action_names_and_statuses_require_exact_strings(self):
        class StringAlias(str):
            pass

        valid = FiniteInterface((0, 0), ("observe",), (
            (InterfaceStep(0, "accepted", 0),), (InterfaceStep(1, "accepted", 0),),
        ))
        for action in (False, 0, b"observe", StringAlias("observe")):
            with self.subTest(action=action):
                self.assert_rejected_by_every_entry_point(replace(valid, actions=(action,)), "action: expected")
        for status in (False, 0, b"accepted", StringAlias("accepted")):
            with self.subTest(status=status):
                bad = replace(valid, steps=((InterfaceStep(0, status, 0),), valid.steps[1]))
                self.assert_rejected_by_every_entry_point(bad, "noncanonical action outcome status")

    def test_recovery_alphabet_extension_revalidates_pruning(self):
        old = FiniteInterface(("balance:0", "balance:0"), ("balance",), (
            (InterfaceStep(0, "accepted", 0),),
            (InterfaceStep(1, "accepted", 0),),
        ))
        self.assertEqual(future_partition(old), (0, 0))
        enlarged = FiniteInterface(old.observations, ("balance", "restore"), (
            old.steps[0] + (InterfaceStep(0, "accepted", ("paid-occurrence", "executor-index:a")),),
            old.steps[1] + (InterfaceStep(1, "accepted", ("paid-occurrence", "executor-index:b")),),
        ))
        self.assertEqual(future_partition(enlarged), (0, 1))
        self.assertEqual(distinguishing_word(enlarged, 0, 1), ("restore",))
        with self.assertRaises(ContractError):
            check_congruence(enlarged, (0, 0))

    def test_refusal_state_effects_survive_the_quotient(self):
        interface = FiniteInterface((0, 0, 0), ("refuse", "audit"), (
            (InterfaceStep(2, "refused", "denied"), InterfaceStep(0, "accepted", 0)),
            (InterfaceStep(1, "refused", "denied"), InterfaceStep(1, "accepted", 0)),
            (InterfaceStep(2, "refused", "denied"), InterfaceStep(2, "accepted", 1)),
        ))
        self.assertEqual(distinguishing_word(interface, 0, 1), ("refuse", "audit"))
        self.assertEqual(future_partition(interface), (0, 1, 2))

    def test_status_and_current_observations_are_protected(self):
        statuses = FiniteInterface((0, 0), ("request",), (
            (InterfaceStep(0, "refused", "absent"),),
            (InterfaceStep(1, "unavailable", "absent"),),
        ))
        self.assertEqual(distinguishing_word(statuses, 0, 1), ("request",))
        current = FiniteInterface(("beneficiary:a", "beneficiary:b"), (), ((), ()))
        self.assertEqual(future_partition(current), (0, 1))
        self.assertEqual(distinguishing_word(current, 0, 1), ())

    def test_finer_congruences_are_allowed_but_arbitrary_refinements_fail(self):
        interface = FiniteInterface((0, 0, 0, 0), ("step",), tuple(
            (InterfaceStep(target, "accepted", 0),) for target in (2, 3, 2, 3)
        ))
        self.assertEqual(future_partition(interface), (0, 0, 0, 0))
        self.assertTrue(check_congruence(interface, (0, 1, 2, 3)))
        self.assertTrue(check_congruence(interface, (0, 0, 1, 1)))
        with self.assertRaisesRegex(ContractError, "successor blocks"):
            check_congruence(interface, (0, 0, 1, 2))
        quotient = FiniteInterface((0, 0), ("step",), (
            (InterfaceStep(1, "accepted", 0),), (InterfaceStep(1, "accepted", 0),),
        ))
        self.assertTrue(check_projection(interface, quotient, (0, 0, 1, 1)))
        bad = replace(quotient, steps=((InterfaceStep(0, "accepted", 0),), quotient.steps[1]))
        with self.assertRaisesRegex(ContractError, "changes a successor"):
            check_projection(interface, bad, (0, 0, 1, 1))

    def test_all_two_state_interfaces_match_finite_pair_word_oracle(self):
        options = tuple(InterfaceStep(target, "accepted", output) for target, output in product(range(2), repeat=2))
        words = tuple(word for length in range(5) for word in product(("a", "b"), repeat=length))
        cases = 0
        for current in product(range(2), repeat=2):
            for steps in product(options, repeat=4):
                interface = FiniteInterface(current, ("a", "b"), (steps[:2], steps[2:]))
                equivalent = all(observed_trace(interface, 0, word) == observed_trace(interface, 1, word) for word in words)
                blocks = future_partition(interface)
                self.assertEqual(blocks[0] == blocks[1], equivalent)
                self.assertTrue(check_congruence(interface, blocks))
                witness = distinguishing_word(interface, 0, 1)
                self.assertEqual(witness is None, equivalent)
                if witness is not None:
                    self.assertNotEqual(observed_trace(interface, 0, witness), observed_trace(interface, 1, witness))
                cases += 1
        self.assertEqual(cases, 1024)

    def test_short_samples_do_not_establish_all_word_equality(self):
        interface = FiniteInterface((0,) * 6, ("advance",), tuple(
            (InterfaceStep(target, "accepted", output),)
            for target, output in ((2, 0), (3, 0), (4, 0), (5, 0), (4, 1), (5, 2))
        ))
        for length in range(3):
            word = ("advance",) * length
            self.assertEqual(observed_trace(interface, 0, word), observed_trace(interface, 1, word))
        self.assertEqual(distinguishing_word(interface, 0, 1), ("advance",) * 3)

    def test_incomplete_interface_tables_are_rejected(self):
        interface = FiniteInterface((0,), ("a",), ((),))
        with self.assertRaisesRegex(ContractError, "incomplete action"):
            future_partition(interface)

    def test_distinguishing_word_is_shortest_for_current_observations(self):
        interface = FiniteInterface((0, 0, 0, 0, 0, 1), ("a", "b"), (
            (InterfaceStep(2, "accepted", 0), InterfaceStep(4, "accepted", 0)),
            (InterfaceStep(3, "accepted", 0), InterfaceStep(5, "accepted", 0)),
            (InterfaceStep(2, "accepted", 1), InterfaceStep(2, "accepted", 0)),
            (InterfaceStep(3, "accepted", 2), InterfaceStep(3, "accepted", 0)),
            (InterfaceStep(4, "accepted", 0), InterfaceStep(4, "accepted", 0)),
            (InterfaceStep(5, "accepted", 0), InterfaceStep(5, "accepted", 0)),
        ))
        self.assertEqual(distinguishing_word(interface, 0, 1), ("b",))


class StochasticTests(unittest.TestCase):
    def test_stochastic_symbols_reject_noncanonical_labels(self):
        class StringAlias(str):
            pass

        class TupleAlias(tuple):
            pass

        symbols = (("step", False), ("step", 0.0), ("step", Fraction(0)),
                   ("step", StringAlias("output")), (StringAlias("step"), "output"),
                   TupleAlias(("step", "output")))
        for symbol in symbols:
            with self.subTest(symbol=symbol), self.assertRaisesRegex(ContractError, "stochastic symbol: expected exact"):
                stochastic_trace_certificate({symbol: ((1,),)}, (1,), (1,))

    def test_output_laws_need_the_full_invariant_span(self):
        matrices = {
            ("step", "live"): ((0, 1, 0), (0, 0, 1), (0, 0, 0)),
            ("step", "stop"): ((0, 0, 0), (0, 0, 0), (0, 0, 1)),
        }
        left, right = (1, 0, 0), (0, 1, 0)
        for symbol in matrices:
            self.assertEqual(trace_probability(matrices, left, (symbol,)), trace_probability(matrices, right, (symbol,)))
        certificate = stochastic_trace_certificate(matrices, left, right)
        self.assertFalse(certificate.equivalent)
        self.assertEqual((certificate.dimension, certificate.stabilization_index), (3, 2))
        self.assertEqual(certificate.witness, (("step", "live"), ("step", "live")))
        self.assertNotEqual(trace_probability(matrices, left, certificate.witness), trace_probability(matrices, right, certificate.witness))
        self.assertTrue(stochastic_trace_certificate(matrices, left, left).equivalent)

    def test_distinct_hidden_states_can_have_equal_complete_output_laws(self):
        matrices = {
            ("step", "heads"): ((Fraction(1, 2), 0), (0, Fraction(1, 2))),
            ("step", "tails"): ((Fraction(1, 2), 0), (0, Fraction(1, 2))),
        }
        certificate = stochastic_trace_certificate(matrices, (1, 0), (0, 1))
        self.assertTrue(certificate.equivalent)
        self.assertEqual((certificate.dimension, certificate.stabilization_index), (1, 0))

    def test_combined_representation_dimension_is_checked(self):
        matrices = {
            ("step", "yes"): ((1, 0), (0, 0)),
            ("step", "no"): ((0, 0), (0, 1)),
        }
        result = stochastic_trace_certificate(matrices, (1, 0), (0, 1))
        self.assertFalse(result.equivalent)
        self.assertEqual(result.dimension, 2)
        with self.assertRaisesRegex(ContractError, "matrix dimension"):
            stochastic_trace_certificate({("step", "yes"): ((1,),)}, (1, 0), (0, 1))

    def test_missing_probability_mass_and_float_inputs_are_rejected(self):
        with self.assertRaisesRegex(ContractError, "stochastic action"):
            stochastic_trace_certificate({("a", "o"): ((Fraction(1, 2),),)}, (1,), (1,))
        with self.assertRaisesRegex(ContractError, "exact rational"):
            stochastic_trace_certificate({("a", "o"): ((1.0,),)}, (1,), (1,))
        with self.assertRaisesRegex(ContractError, "initial distribution"):
            stochastic_trace_certificate({("a", "o"): ((1,),)}, (2,), (1,))


class ProviderTests(unittest.TestCase):
    def test_all_three_vertex_graphs_match_the_cycle_hitting_criterion(self):
        cases = 0
        for mask in range(1 << 9):
            graph = tuple(frozenset(j for j in range(3) if mask & (1 << (3 * i + j))) for i in range(3))
            for seed_mask in range(8):
                seeds = frozenset(i for i in range(3) if seed_mask & (1 << i))
                closure = bootstrap_closure(graph, seeds)
                expected = not has_cycle(graph, set(range(3)) - seeds)
                self.assertEqual(closure == frozenset(range(3)), expected)
                cases += 1
        self.assertEqual(cases, 4096)

    def test_all_three_vertex_dag_bounds_match_path_enumeration(self):
        cases = 0
        for mask in range(1 << 9):
            graph = tuple(frozenset(j for j in range(3) if mask & (1 << (3 * i + j))) for i in range(3))
            if has_cycle(graph, set(range(3))):
                continue

            def paths(state):
                if not graph[state]:
                    return [(state,)]
                return [prefix + (state,) for predecessor in graph[state] for prefix in paths(predecessor)]

            all_paths = tuple(paths(state) for state in range(3))
            for latencies in product(range(3), repeat=3):
                contracts = tuple(CompletionContract(graph[i], latencies[i], "clock") for i in range(3))
                result = provider_completion_bounds(contracts, "clock")
                expected = tuple(max(sum(latencies[j] for j in path) for path in row) for row in all_paths)
                self.assertEqual(result.bounds, expected)
                cases += 1
        self.assertEqual(cases, 675)

    def test_diamond_and_competing_external_deadlines(self):
        graph = (frozenset(), frozenset({0}), frozenset({0}), frozenset({1, 2}))
        contracts = tuple(CompletionContract(graph[i], latency, "clock") for i, latency in enumerate((1, 2, 4, 3)))
        self.assertEqual(provider_completion_bounds(contracts, "clock").bounds, (1, 3, 5, 8))
        self.assertEqual(provider_completion_bounds(contracts, "clock", seeds={3: 6}).bounds[-1], 6)
        self.assertEqual(provider_completion_bounds(contracts, "clock", seeds={3: 10}).bounds[-1], 8)

    def test_unseeded_cycle_and_component_contract(self):
        contracts = (
            CompletionContract(frozenset({1}), 3, "clock"),
            CompletionContract(frozenset({0}), 4, "clock"),
            CompletionContract(frozenset({1}), 2, "clock"),
        )
        with self.assertRaisesRegex(ContractError, "unseeded cycle"):
            provider_completion_bounds(contracts, "clock")
        joint = provider_completion_bounds(contracts, "clock", component_latencies={frozenset({0, 1}): 5})
        self.assertEqual(joint.bounds, (5, 5, 7))
        self.assertEqual(joint.bootstrap, frozenset())
        seeded = provider_completion_bounds(contracts, "clock", seeds={0: 2})
        self.assertEqual(seeded.bounds, (2, 6, 8))
        self.assertEqual(seeded.bootstrap, frozenset({0, 1, 2}))
        with self.assertRaisesRegex(ContractError, "does not name"):
            provider_completion_bounds(contracts, "clock", component_latencies={frozenset({0}): 5})

    def test_self_loop_and_only_some_cycles_seeded(self):
        self_loop = (CompletionContract(frozenset({0}), 1, "clock"),)
        with self.assertRaises(ContractError):
            provider_completion_bounds(self_loop, "clock")
        self.assertEqual(provider_completion_bounds(self_loop, "clock", seeds={0: 7}).bounds, (7,))
        self.assertEqual(provider_completion_bounds(self_loop, "clock", component_latencies={frozenset({0}): 2}).bounds, (2,))
        graph = (frozenset({1}), frozenset({0}), frozenset({3}), frozenset({2}))
        contracts = tuple(CompletionContract(row, 1, "clock") for row in graph)
        self.assertEqual(bootstrap_closure(graph, frozenset({0})), frozenset({0, 1}))
        with self.assertRaisesRegex(ContractError, "unseeded cycle"):
            provider_completion_bounds(contracts, "clock", seeds={0: 0})
        self.assertEqual(provider_completion_bounds(contracts, "clock", seeds={0: 0, 2: 0}).bounds, (0, 1, 0, 1))

    def test_individually_feasible_reservations_must_also_hold_jointly(self):
        contract = CompletionContract(frozenset(), 1, "clock", (1,))
        self.assertEqual(provider_completion_bounds((contract,), "clock", (1,)).bounds, (1,))
        with self.assertRaisesRegex(ContractError, "shared capacity"):
            provider_completion_bounds((contract, contract), "clock", (1,))
        self.assertEqual(provider_completion_bounds((contract, contract), "clock", (2,)).bounds, (1, 1))

    def test_clock_and_exact_rational_contracts_are_required(self):
        first = CompletionContract(frozenset(), Fraction(1, 3), "clock")
        second = CompletionContract(frozenset({0}), Fraction(2, 3), "clock")
        self.assertEqual(provider_completion_bounds((first, second), "clock").bounds, (Fraction(1, 3), 1))
        with self.assertRaisesRegex(ContractError, "different clocks"):
            provider_completion_bounds((first, replace(second, clock="other")), "clock")
        with self.assertRaisesRegex(ContractError, "exact rational"):
            provider_completion_bounds((replace(first, latency=0.5),), "clock")
        with self.assertRaisesRegex(ContractError, "negative provider"):
            provider_completion_bounds((replace(first, latency=-1),), "clock")
        self.assertEqual(provider_completion_bounds((), "clock").bounds, ())


if __name__ == "__main__":
    unittest.main(verbosity=2)
