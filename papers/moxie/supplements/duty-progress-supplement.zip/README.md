# Duty progress and continuation contracts

This supplement contains exact checks for supplied finite transition models.
It accompanies *Admissible Obligation Transitions* and *The Claim as Primitive*.

## Reproduction

Use Python 3.9 or later. No third-party packages are required.
The checked interpreters are Python 3.9.6 and Python 3.13.12.
Extract all five members into one directory.
Verify the four payload hashes against `SHA256SUMS`.
Run both commands from that directory:

```text
python3 verify_duty_progress.py
python3 -O verify_duty_progress.py
```

Each command must exit with status zero and report `Ran 45 tests` followed by `OK`.
The checker uses explicit exception checks that remain active with Python optimization.

## Finite scope

The episode checker retains the original finite cohort and its immutable admission records.
It checks integer ranks, exact named completion records, aggregate nonincrease, productive service windows, and unfinished deadlocks.
The concrete realization checker evaluates the sharper integer potential and its first-completion bound.

Slot histories enforce observed clarity before reuse.
The periodic monitor checker and finite control-game solver check their separately supplied models.
The game solver returns a positional policy for safe recurrence.

Deterministic interfaces retain protected current observations, action statuses, emitted outputs, and actual successor states.
Current and output labels admit only exact `int`, `str`, `bytes`, and recursively nested exact `tuple` values.
Booleans, floats, fractions, subclasses, and arbitrary hashable objects are rejected, including inside tuples.
This restriction prevents Python equality from identifying distinct typed observations such as `False` and `0`.
Action names and outcome statuses use exact strings; stochastic symbols use exact tuples of two nonempty exact strings.
The quotient checker validates every declared action and the complete one-step projection equations.
The stochastic checker uses exact rational output-labelled kernels and a stabilized invariant span.

Provider checks compose exact rational deadlines, external seeds, and declared contracts for cyclic components.
All contracts use one named clock.
The shared resource check requires simultaneous reservation totals to fit the supplied capacity vector.
Sequential resource reuse requires a separate resource model.

The tests enumerate 10,123 finite configurations:

- 90 productive-counter configurations.
- 1,934 periodic slot-monitor configurations.
- 2,304 two-state control games, checked against an independent strategy and cycle oracle.
- 1,024 two-state deterministic interfaces, checked against complete finite pair-word coverage.
- 4,096 prerequisite-graph and seed configurations.
- 675 acyclic latency configurations, checked against path enumeration.

Additional adverse fixtures cover relabelled goals, alias rank duplication, clock mismatch, incompatible reservations, refusal effects, archive restoration, unsupported labels at every interface entry point, and preservation of distinct typed encodings.

## Evidence boundary

The input transition tables and named completion records define the checked model.
External authority, authentic provider occurrences, complete executor state, and actual service availability require their own evidence.
A concrete executor needs a correspondence proof for every admitted operation, including recovery and archive restoration.
Observations outside the accepted label grammar require an injective typed encoding before admission.
For example, the distinct byte labels `b"bool:false"` and `b"int:0"` preserve that distinction.
The encoding must be injective across the full protected domain, including native labels.
An encoded Boolean must remain distinct from a native byte observation with the same displayed bytes.
The adapter must preserve every protected observation and its schema; these finite checks do not prove the adapter's correspondence.
New actions require renewed quotient acceptance.

The demanded-support result in *The Claim as Primitive* has manuscript proof status.
Its numerical evaluator has no test coverage in this supplement.
The paper retains its eager financial evidence rule.

## Archive format

`PROFILE.json` records the commands, finite scope, and checked Python versions.
`SHA256SUMS` hashes every other archive member and excludes itself.
The archive uses stored members, lexical member order, fixed permissions, and the timestamp 1980-01-01 00:00:00.
It contains no paper or PDF digest.
