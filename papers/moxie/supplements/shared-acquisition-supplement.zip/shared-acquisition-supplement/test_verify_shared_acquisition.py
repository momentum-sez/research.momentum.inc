"""Exact certificate tests with independent objective and boundary witnesses.

Run with python3 -m unittest discover -s papers -p test_verify_shared_acquisition.py.
These tests concern the declared continuous acquisition model and its parser.
"""

from copy import deepcopy
from decimal import Decimal
from fractions import Fraction
from io import StringIO
from itertools import product
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

import verify_shared_acquisition as checker


def robust_model():
    return {
        "A": [[1, 0], [0, 1]], "costs": [1, 1],
        "scenarios": [[9, 1], [1, 9]], "budget": 100,
        "purchases": [50, 50], "scenario_weights": ["1/2", "1/2"],
    }


def rational_model():
    return {
        "A": [[1, "1/3", "1/2"], ["1/2", 1, "1/3"]],
        "costs": ["17/18", "7/9", "2/3"],
        "scenarios": [[4, 3], [2, 6], [1, 1]], "budget": 3,
        "purchases": ["6/5", "12/5", 0],
        "scenario_weights": ["1/3", "2/3", 0],
    }


def certify(model):
    return checker.robust_acquisition_certificate(
        model["A"], model["costs"], model["scenarios"], model["budget"],
        model["purchases"], model["scenario_weights"],
    )


class AcquisitionTests(unittest.TestCase):
    def assert_rejected(self, model, code):
        report = checker.verify_document(model)
        self.assertIs(report["accepted"], False)
        self.assertEqual(report["reason"]["code"], code)
        self.assertTrue(report["reason"]["path"].startswith("$"))
        self.assertTrue(report["reason"]["message"])
        self.assertNotIn("certificate", report)

    def test_shared_counts_and_exact_dual(self):
        result = checker.robust_acquisition_certificate(
            [[1, 0, 0, 1], [0, 1, 0, 1], [0, 0, 1, 1]], [1, 1, 1, 2],
            [[1, 3, 9]], 600, [0, 0, 120, 240], [1],
        )
        self.assertEqual(result["counts"], (240, 240, 360))
        self.assertEqual(result["budget_spent"], 600)
        self.assertEqual(result["value"], Fraction(1, 24))
        self.assertEqual(result["dual"], (Fraction(1, 4), Fraction(3, 4), 1))
        self.assertEqual(result["bundle_slacks"], (Fraction(1, 19200), Fraction(1, 57600), 0, 0))
        self.assertEqual(Fraction(1, 240) + Fraction(3, 240) + Fraction(9, 360),
                         result["value"])

    def test_robust_plan_controls_both_scenarios(self):
        result = certify(robust_model())
        self.assertEqual(result["counts"], (50, 50))
        self.assertEqual(result["scenario_objectives"], (Fraction(1, 5), Fraction(1, 5)))
        self.assertEqual(result["dual"], (1, 1))
        self.assertEqual(result["lambda"], Fraction(1, 500))
        # The scenario average is 5/n1 + 5/n2 >= 20/(n1+n2) >= 1/5.
        for first in range(1, 100):
            costs = (Fraction(9, first) + Fraction(1, 100 - first),
                     Fraction(1, first) + Fraction(9, 100 - first))
            self.assertGreaterEqual(max(costs), Fraction(1, 5))
        self.assertEqual(Fraction(1, 75) + Fraction(9, 25), Fraction(28, 75))
        self.assertGreater(Fraction(28, 75), result["value"])

    def test_single_scenario_plan_does_not_certify_the_robust_problem(self):
        model = robust_model()
        model["purchases"] = [75, 25]
        model["scenario_weights"] = [1, 0]
        self.assert_rejected(model, "inactive_scenario")
        model["scenario_weights"] = [0, 1]
        self.assert_rejected(model, "complementarity")

    def test_one_old_dual_is_insufficient_to_decide_improvement(self):
        scenarios = [[9, 1], [1, 9]]
        for alpha, dual in (([1, 0], (Fraction(9, 10), Fraction(1, 10))),
                            ([0, 1], (Fraction(1, 10), Fraction(9, 10)))):
            old = checker.robust_acquisition_certificate([[1], [1]], [1], scenarios, 1, [1], alpha)
            self.assertEqual(old["value"], 10)
            self.assertEqual(old["dual"], dual)
        enlarged = {
            "A": [[1, 1], [1, 0]], "costs": [1, "1/5"],
            "scenarios": scenarios, "budget": 1, "purchases": [1, 0],
            "scenario_weights": [1, 0],
        }
        self.assert_rejected(enlarged, "dual_feasibility")
        enlarged["scenario_weights"] = [0, 1]
        self.assertEqual(certify(enlarged)["value"], 10)
        enlarged["A"] = [[1, 0], [1, 1]]
        enlarged["scenario_weights"] = [1, 0]
        self.assertEqual(certify(enlarged)["value"], 10)

    def test_two_complementary_bundles_improve_the_objective(self):
        scenarios = [[9, 1], [1, 9]]
        for budget, joint_purchases, expected in ((1, [0, "5/2", "5/2"], 4),
                                                 (2, [0, 5, 5], 2)):
            with self.subTest(budget=budget):
                old = checker.robust_acquisition_certificate(
                    [[1], [1]], [1], scenarios, budget, [budget], [1, 0],
                )
                self.assertEqual(old["value"], Fraction(10, budget))
                for A, alpha in (([[1, 1], [1, 0]], [0, 1]),
                                 ([[1, 0], [1, 1]], [1, 0])):
                    single = checker.robust_acquisition_certificate(
                        A, [1, "1/5"], scenarios, budget, [budget, 0], alpha,
                    )
                    self.assertEqual(single["value"], old["value"])
                joint = checker.robust_acquisition_certificate(
                    [[1, 1, 0], [1, 0, 1]], [1, "1/5", "1/5"], scenarios,
                    budget, joint_purchases, ["1/2", "1/2"],
                )
                self.assertEqual(joint["value"], expected)
                self.assertEqual(joint["dual"], (Fraction(1, 5), Fraction(1, 5)))
                self.assertLess(joint["value"], old["value"])

    def test_fractional_incidence_and_inactive_scenario(self):
        result = certify(rational_model())
        self.assertEqual(result["counts"], (2, 3))
        self.assertEqual(result["value"], 3)
        self.assertEqual(result["scenario_objectives"], (3, 3, Fraction(5, 6)))
        self.assertEqual(result["averaged_coefficients"], (Fraction(8, 3), 5))
        self.assertEqual(result["gradient"], (Fraction(2, 3), Fraction(5, 9)))
        self.assertEqual(result["lambda"], 1)
        self.assertEqual(result["bundle_slacks"], (0, 0, Fraction(4, 27)))

    def test_independent_convex_remainder_identity_includes_unused_budget(self):
        checked = 0
        for y in product((Fraction(i, 3) for i in range(9)), repeat=3):
            spent = Fraction(17, 18)*y[0] + Fraction(7, 9)*y[1] + Fraction(2, 3)*y[2]
            m1 = y[0] + y[1]/3 + y[2]/2
            m2 = y[0]/2 + y[1] + y[2]/3
            if spent > 3 or min(m1, m2) == 0:
                continue
            average = Fraction(8, 3)/m1 + 5/m2
            remainder = ((3-spent) + Fraction(4, 27)*y[2]
                         + Fraction(2, 3)*(m1-2)**2/m1
                         + Fraction(5, 9)*(m2-3)**2/m2)
            self.assertEqual(average, 3 + remainder)
            self.assertGreaterEqual(remainder, 0)
            worst = max(4/m1+3/m2, 2/m1+6/m2, 1/m1+1/m2)
            self.assertGreaterEqual(worst, average)
            checked += 1
        self.assertGreater(checked, 100)

    def test_unused_bundle_dual_constraint_has_a_strict_improvement_witness(self):
        model = rational_model()
        model["costs"][2] = "1/2"
        self.assert_rejected(model, "dual_feasibility")
        y = (Fraction(20, 27), Fraction(125, 54), Fraction(1))
        self.assertEqual(Fraction(17, 18)*y[0] + Fraction(7, 9)*y[1] + y[2]/2, 3)
        m1, m2 = y[0]+y[1]/3+y[2]/2, y[0]/2+y[1]+y[2]/3
        self.assertEqual((m1, m2), (Fraction(163, 81), Fraction(163, 54)))
        self.assertEqual(max(4/m1+3/m2, 2/m1+6/m2, 1/m1+1/m2), Fraction(486, 163))
        self.assertLess(Fraction(486, 163), 3)

    def test_zero_unused_column_and_nonunique_purchase_vectors(self):
        result = checker.robust_acquisition_certificate([[1, 0]], [1, 1], [[1]], 1, [1, 0], [1])
        self.assertEqual(result["bundle_slacks"], (0, 1))
        for purchases in ([1, 0], [0, 1], ["1/3", "2/3"]):
            result = checker.robust_acquisition_certificate(
                [[1, 1]], [1, 1], [[1], [1]], 1, purchases, [1, 0],
            )
            self.assertEqual(result["counts"], (1,))
            self.assertEqual(result["bundle_slacks"], (0, 0))

    def test_exact_checks_reject_changes_below_float_resolution(self):
        epsilon = Fraction(1, 10**100)
        model = robust_model()
        model["purchases"][0] = 50 + epsilon
        self.assertEqual(float(model["purchases"][0]), 50.0)
        self.assert_rejected(model, "budget_mismatch")
        model = {
            "A": [[1, 1]], "costs": [1, 1-epsilon], "scenarios": [[1]],
            "budget": 1, "purchases": [1, 0], "scenario_weights": [1],
        }
        self.assert_rejected(model, "dual_feasibility")
        model = {
            "A": [[1]], "costs": [1], "scenarios": [[1], [1-epsilon]],
            "budget": 1, "purchases": [1], "scenario_weights": [0, 1],
        }
        self.assert_rejected(model, "inactive_scenario")

    def test_model_and_certificate_signs_budget_and_coverage(self):
        cases = (
            ("A", [[1, -1], [0, 1]], "negative_incidence"),
            ("A", [[0, 0], [0, 1]], "uncovered_estimand"),
            ("costs", [0, 1], "nonpositive_cost"),
            ("costs", [-1, 1], "nonpositive_cost"),
            ("scenarios", [[9, 0], [1, 9]], "nonpositive_coefficient"),
            ("scenarios", [[9, 1], [-1, 9]], "nonpositive_coefficient"),
            ("budget", 0, "nonpositive_budget"),
            ("budget", -1, "nonpositive_budget"),
            ("purchases", [-1, 101], "negative_purchase"),
            ("purchases", [49, 50], "budget_mismatch"),
            ("purchases", [51, 50], "budget_mismatch"),
            ("purchases", [100, 0], "zero_count"),
            ("scenario_weights", [-1, 2], "negative_weight"),
            ("scenario_weights", [0, 0], "weight_sum"),
            ("scenario_weights", [1, 1], "weight_sum"),
        )
        for field, value, code in cases:
            with self.subTest(field=field, value=value):
                model = robust_model()
                model[field] = value
                self.assert_rejected(model, code)

    def test_empty_arrays_and_mismatched_dimensions(self):
        for field in ("A", "costs", "scenarios", "purchases", "scenario_weights"):
            model = robust_model()
            model[field] = []
            self.assert_rejected(model, "empty_array")
        for field, value, code in (
            ("A", [[], []], "empty_array"),
            ("A", [[1], [0, 1]], "dimension"),
            ("A", [[1, 0, 0], [0, 1]], "dimension"),
            ("scenarios", [[], [1, 9]], "empty_array"),
            ("scenarios", [[9, 1], [1]], "dimension"),
            ("costs", [1], "dimension"),
            ("purchases", [50], "dimension"),
            ("scenario_weights", [1], "dimension"),
        ):
            model = robust_model()
            model[field] = value
            self.assert_rejected(model, code)

    def test_every_numeric_position_rejects_inexact_or_coerced_types(self):
        positions = (("A", 0, 0), ("costs", 0), ("scenarios", 1, 1),
                     ("budget",), ("purchases", 1), ("scenario_weights", 0))
        bad_values = (True, False, 1.0, float("nan"), float("inf"), float("-inf"),
                      None, Decimal(1), 1+0j, b"1", {"numerator": 1, "denominator": 2})
        for position, value in product(positions, bad_values):
            with self.subTest(position=position, value=value):
                model = robust_model()
                container = model
                for key in position[:-1]:
                    container = container[key]
                container[position[-1]] = value
                self.assert_rejected(model, "rational_type")

    def test_rational_strings_must_be_canonical_ascii(self):
        for value in ("", " 1", "1 ", "+1", "-0", "01", "1/1", "2/4", "0/2", "1/0",
                      "1/-2", "1 / 2", "1.0", "1e3", "NaN", "Infinity", "1_000", "١"):
            with self.subTest(value=value):
                model = robust_model()
                model["budget"] = value
                self.assert_rejected(model, "rational_type")
        # Excluded syntax must not reach Fraction's decimal/exponent expansion.
        with patch.object(checker, "Fraction", side_effect=AssertionError("fraction parser called")):
            with self.assertRaises(checker.CertificateError):
                checker._rational("1e1000000000", "$.budget")

    def test_array_types_and_root_schema_are_strict(self):
        for field in ("A", "costs", "scenarios", "purchases", "scenario_weights"):
            for value in (None, "1", 1, {0: 1}, {1}, range(2)):
                model = robust_model()
                model[field] = value
                self.assert_rejected(model, "array_type")
        for value in (None, [], "{}", True):
            self.assert_rejected(value, "object_type")
        for field in robust_model():
            model = robust_model()
            del model[field]
            self.assert_rejected(model, "schema")
        for field in ("objective", "counts", "dual", "alpha", 1):
            model = robust_model()
            model[field] = 1
            self.assert_rejected(model, "schema")

    def test_exact_types_tuples_and_inputs_remain_unchanged(self):
        model = rational_model()
        original = deepcopy(model)
        report = checker.verify_document(model)
        self.assertIs(report["accepted"], True)
        self.assertEqual(report["certificate"]["counts"], ["2", "3"])
        self.assertEqual(report["certificate"]["bundle_slacks"], ["0", "0", "4/27"])
        self.assertEqual(model, original)
        result = checker.robust_acquisition_certificate(
            ((1, 0), (0, 1)), (1, 1), ((9, 1), (1, 9)), Fraction(100),
            (50, 50), (Fraction(1, 2), Fraction(1, 2)),
        )
        self.assertIs(type(result["value"]), Fraction)
        class IntegerSubclass(int):
            pass
        model = robust_model()
        model["budget"] = IntegerSubclass(100)
        self.assert_rejected(model, "rational_type")


class JsonAndCliTests(unittest.TestCase):
    def test_json_round_trip_has_exact_canonical_rationals(self):
        report = checker.verify_json(json.dumps(rational_model()))
        self.assertIs(report["accepted"], True)
        certificate = report["certificate"]
        for value in certificate.values():
            for entry in value if isinstance(value, list) else [value]:
                self.assertIs(type(entry), str)
                self.assertEqual(str(Fraction(entry)), entry)
        self.assertEqual(report, json.loads(json.dumps(report, allow_nan=False)))

    def test_json_rejects_duplicates_nonfinite_floats_and_malformed_input(self):
        valid = json.dumps(robust_model())
        for token in ("NaN", "Infinity", "-Infinity", "1e9999", "100.0", "1e2"):
            with self.subTest(token=token):
                raw = valid.replace('"budget": 100', f'"budget": {token}')
                report = checker.verify_json(raw)
                self.assertIs(report["accepted"], False)
                self.assertEqual(report["reason"]["code"], "json_number")
        duplicate = valid[:-1] + ', "budget": 100}'
        self.assertEqual(checker.verify_json(duplicate)["reason"]["code"], "duplicate_key")
        escaped_duplicate = valid[:-1] + ', "budg\\u0065t": 100}'
        self.assertEqual(checker.verify_json(escaped_duplicate)["reason"]["code"], "duplicate_key")
        for raw in ("", "{", valid + "{}", '[1,]', '\ufeff' + valid, "["*2000):
            report = checker.verify_json(raw)
            self.assertIs(report["accepted"], False)
            self.assertEqual(report["reason"]["code"], "invalid_json")
        self.assertEqual(checker.verify_json(b"{}")["reason"]["code"], "json_type")

    def test_cli_returns_deterministic_json_and_failure_status(self):
        path = str(Path(checker.__file__).resolve())
        for optimized in (False, True):
            command = [sys.executable] + (["-O"] if optimized else []) + [path]
            valid = subprocess.run(command + ["-"], input=json.dumps(robust_model()),
                                   capture_output=True, text=True, timeout=20)
            self.assertEqual(valid.returncode, 0, valid.stderr)
            report = json.loads(valid.stdout)
            self.assertIs(report["accepted"], True)
            self.assertEqual(report["certificate"]["value"], "1/5")
            self.assertEqual(valid.stdout, json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n")
            invalid = subprocess.run(command, input='{"budget": true}',
                                     capture_output=True, text=True, timeout=20)
            self.assertEqual(invalid.returncode, 1, invalid.stderr)
            self.assertIs(json.loads(invalid.stdout)["accepted"], False)

    def test_cli_file_input_and_read_failure(self):
        with patch.object(checker.Path, "read_text", return_value=json.dumps(robust_model())) as read:
            with patch.object(sys, "stdout", new_callable=StringIO) as out:
                self.assertEqual(checker.main(["certificate.json"]), 0)
                self.assertIs(json.loads(out.getvalue())["accepted"], True)
            read.assert_called_once_with(encoding="utf-8")
        with patch.object(checker.Path, "read_text", side_effect=OSError("unavailable")):
            with patch.object(sys, "stdout", new_callable=StringIO) as out:
                self.assertEqual(checker.main(["certificate.json"]), 1)
                self.assertEqual(json.loads(out.getvalue())["reason"]["code"], "input_read")

    def test_self_tests_execute_and_detect_mutations_under_optimization(self):
        path = Path(checker.__file__).resolve()
        instrument = r'''
import json, sys
from unittest.mock import patch
sys.path.insert(0, sys.argv[1])
import verify_shared_acquisition as checker
original = checker.robust_acquisition_certificate
with patch.object(checker, "robust_acquisition_certificate", wraps=original) as checked:
    count = checker.self_test()
    print(json.dumps([count, checked.call_count]))
def corrupt(*args, **kwargs):
    result = original(*args, **kwargs)
    result["value"] += 1
    return result
with patch.object(checker, "robust_acquisition_certificate", side_effect=corrupt):
    try:
        checker.self_test()
    except AssertionError:
        print("mutation detected")
    else:
        raise RuntimeError("self-test accepted a false objective")
'''
        for optimized in (False, True):
            command = [sys.executable] + (["-O"] if optimized else [])
            result = subprocess.run(command + [str(path), "--self-test"],
                                    capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), {"accepted": True, "self_test_checks": 9})
            counted = subprocess.run(command + ["-c", instrument, str(path.parent)],
                                     capture_output=True, text=True, timeout=20)
            self.assertEqual(counted.returncode, 0, counted.stderr)
            self.assertEqual(counted.stdout.splitlines(), ["[9, 7]", "mutation detected"])


if __name__ == "__main__":
    unittest.main()
