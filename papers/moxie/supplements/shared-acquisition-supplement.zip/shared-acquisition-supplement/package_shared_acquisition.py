#!/usr/bin/env python3
"""Build or verify the deterministic shared-acquisition supplement.

The build checks the accepted source digests before packaging their bytes.
Verification checks the complete member set, sizes, and SHA-256 digests.
The manifest excludes only its own file. An external digest can bind the ZIP.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
from io import BytesIO
import json
from pathlib import Path
import re
import sys
import zipfile


ARCHIVE_ROOT = "shared-acquisition-supplement"
PROFILE_ID = "shared-acquisition-exact-kkt-v1"
MANIFEST_NAME = "MANIFEST.json"
SOURCE_SHA256 = {
    "verify_shared_acquisition.py": "22ca84923fdc1b1a2f2230eaaf3ec5c451c811e0098ac7cfe428e18cf01483cf",
    "test_verify_shared_acquisition.py": "a02aa0aedc8fc06930c42e7d20fe703bccc32f113709f94bad0a928b12f76e96",
}


README = """# Shared acquisition: exact rational certificates

This package checks supplied optimality certificates for a finite continuous acquisition model.
Each purchase contributes the nonnegative incidence column for its bundle.
All bundle costs, scenario coefficients, and the budget must be positive.
Every estimand must have at least one covering bundle.
At least one estimand, bundle, and scenario is required.
The sample-count model is n = A x.

For each scenario k, the loss is sum_e a[k][e] / n[e].
The objective is the maximum scenario loss over purchases x >= 0 with c*x <= B.
A zero count gives infinite loss.
The certificate supplies a full-budget purchase plan and weights supported on its worst scenarios.
The checker recomputes counts, losses, averaged coefficients, and every bundle's KKT inequality using exact fractions.

KKT denotes the first-order optimality conditions stated in the checker.
Purchased bundles must satisfy equality.

Acceptance proves global optimality within this declared model.
The program does not find an optimum.
A rejected certificate does not prove that its purchase plan is suboptimal.
Some valid problems have irrational optima outside this certificate format.
The package does not establish a physical sampling law, valid observations, or production acceptance.

Required interpreter: Python 3.9 or later, with its standard library.
Checked interpreters: CPython 3.9.6, 3.13.12, and 3.14.6.
No external packages or network access are required.

Extract the ZIP and enter its top-level directory.
Keep the extracted files together.
Run the following commands from that directory:

```sh
export PYTHONDONTWRITEBYTECODE=1
python3 -B package_shared_acquisition.py verify .
python3 -B -m unittest -v test_verify_shared_acquisition
python3 -B -O -m unittest -v test_verify_shared_acquisition
python3 -B verify_shared_acquisition.py --self-test
python3 -B -O verify_shared_acquisition.py --self-test
```

The manifest command exits zero and reports `verified: true` with `profile_id: shared-acquisition-exact-kkt-v1`.
Each unittest command exits zero, reports `Ran 21 tests`, and ends with `OK`.
The reported test duration depends on the interpreter and machine.
Each self-test command exits zero and prints this exact JSON line:

```json
{"accepted":true,"self_test_checks":9}
```

The environment variable prevents bytecode writes in the test suite's child processes.
The `-B` option also prevents bytecode writes in each listed interpreter.
The `-O` checks confirm that certificate checks remain active with Python assertions disabled.
The test suite also detects a deliberate objective mutation under both modes.

The JSON input has exactly six fields: `A`, `costs`, `scenarios`, `budget`, `purchases`, and `scenario_weights`.
The incidence matrix `A` has one row per estimand and one column per bundle.
Numbers must be JSON integers or canonical rational strings, such as `"1/5"`.
Rational strings use reduced fractions and positive denominators.
Booleans, floats, nonfinite numbers, duplicate keys, and extra fields are rejected.

The Python API additionally accepts `Fraction` values and tuple arrays.
All rational output fields use canonical strings.

Run an example by passing its JSON path to the checker:

```sh
python3 -B verify_shared_acquisition.py examples/shared.json
python3 -B -O verify_shared_acquisition.py examples/shared.json
python3 -B verify_shared_acquisition.py examples/old-dual-new-singleton.json
python3 -B -O verify_shared_acquisition.py examples/old-dual-new-singleton.json
```

An accepted example exits zero and returns `accepted: true`.
An adverse example exits one and returns `accepted: false` with a structured reason.
Exit one is the expected result for the adverse examples below.

| Example | Expected result in either mode |
| --- | --- |
| `shared.json` | Value `1/24`, counts `[240,240,360]` |
| `robust.json` | Value `1/5`, counts `[50,50]` |
| `old-bundle.json` | Value `10`, counts `[1,1]` |
| `one-singleton.json` | Value `10`, counts `[1,1]` |
| `joint-singletons.json` | Value `4`, counts `[5/2,5/2]` |
| `rational-incidence.json` | Value `3`, counts `[2,3]` |
| `old-dual-new-singleton.json` | Rejection: `dual_feasibility` |
| `cheaper-unused-bundle.json` | Rejection: `dual_feasibility` |
| `inactive-scenario.json` | Rejection: `inactive_scenario` |
| `short-budget.json` | Rejection: `budget_mismatch` |
| `boolean-budget.json` | Rejection: `rational_type` |

The singleton examples separate a failed witness from a strict objective improvement.
One old dual fails after adding a singleton, while different scenario weights still certify value 10.
Adding both singleton bundles permits the exactly certified value 4.
The test suite supplies an independent improving plan for the cheaper unused bundle.

`PROFILE.json` records the toolchain, commands, source digests, and exact example expectations.
`MANIFEST.json` lists every other archive member with its size and SHA-256 digest.
Verification rejects missing files, extra files, symbolic links, and changed bytes.
The manifest omits itself to avoid a circular digest.
No manuscript or PDF hash appears inside the archive.
A separate release record can bind the archive to those artifacts.

The two certificate source files retain their accepted bytes.
The packaging script is also included, so the extracted sources can reproduce the ZIP:

```sh
python3 -B package_shared_acquisition.py build ../shared-acquisition-rebuilt.zip
```

The output path must not exist.
The build fixes member order, timestamps, file modes, and ZIP storage settings.
The resulting bytes are independent of the current directory, source timestamps, and Python optimization mode.
Read `NOTICE.txt` for the source licensing status and dependency statement.
"""


NOTICE = """Source and dependency notices

No separate redistribution license accompanied the two certificate source files.
This package assigns no new license to those files or the packaging script.
The programs use only the Python standard library.
No Python interpreter, standard-library implementation, or third-party package code is included.
"""


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode("utf-8")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def examples() -> list[dict[str, object]]:
    robust = {
        "A": [[1, 0], [0, 1]], "costs": [1, 1], "scenarios": [[9, 1], [1, 9]],
        "budget": 100, "purchases": [50, 50], "scenario_weights": ["1/2", "1/2"],
    }
    rational = {
        "A": [[1, "1/3", "1/2"], ["1/2", 1, "1/3"]],
        "costs": ["17/18", "7/9", "2/3"], "scenarios": [[4, 3], [2, 6], [1, 1]],
        "budget": 3, "purchases": ["6/5", "12/5", 0], "scenario_weights": ["1/3", "2/3", 0],
    }
    single = {
        "A": [[1, 1], [1, 0]], "costs": [1, "1/5"], "scenarios": [[9, 1], [1, 9]],
        "budget": 1, "purchases": [1, 0], "scenario_weights": [0, 1],
    }
    result = []

    def accepted(name: str, data: dict, value: str, counts: list[str]) -> None:
        result.append({"path": f"examples/{name}.json", "input": data,
                       "expected_exit_code": 0,
                       "expected_fields": {"accepted": True, "certificate.value": value,
                                           "certificate.counts": counts}})

    def rejected(name: str, data: dict, reason: str) -> None:
        result.append({"path": f"examples/{name}.json", "input": data,
                       "expected_exit_code": 1,
                       "expected_fields": {"accepted": False, "reason.code": reason}})

    accepted("shared", {
        "A": [[1, 0, 0, 1], [0, 1, 0, 1], [0, 0, 1, 1]], "costs": [1, 1, 1, 2],
        "scenarios": [[1, 3, 9]], "budget": 600, "purchases": [0, 0, 120, 240],
        "scenario_weights": [1],
    }, "1/24", ["240", "240", "360"])
    accepted("robust", robust, "1/5", ["50", "50"])
    accepted("old-bundle", {
        "A": [[1], [1]], "costs": [1], "scenarios": [[9, 1], [1, 9]],
        "budget": 1, "purchases": [1], "scenario_weights": [1, 0],
    }, "10", ["1", "1"])
    accepted("one-singleton", single, "10", ["1", "1"])
    accepted("joint-singletons", {
        "A": [[1, 1, 0], [1, 0, 1]], "costs": [1, "1/5", "1/5"],
        "scenarios": [[9, 1], [1, 9]], "budget": 1,
        "purchases": [0, "5/2", "5/2"], "scenario_weights": ["1/2", "1/2"],
    }, "4", ["5/2", "5/2"])
    accepted("rational-incidence", rational, "3", ["2", "3"])
    changed = deepcopy(single)
    changed["scenario_weights"] = [1, 0]
    rejected("old-dual-new-singleton", changed, "dual_feasibility")
    changed = deepcopy(rational)
    changed["costs"][2] = "1/2"
    rejected("cheaper-unused-bundle", changed, "dual_feasibility")
    changed = deepcopy(robust)
    changed["purchases"] = [75, 25]
    changed["scenario_weights"] = [1, 0]
    rejected("inactive-scenario", changed, "inactive_scenario")
    changed = deepcopy(robust)
    changed["purchases"] = [49, 50]
    rejected("short-budget", changed, "budget_mismatch")
    changed = deepcopy(robust)
    changed["budget"] = True
    rejected("boolean-budget", changed, "rational_type")
    return result


def profile(cases: list[dict[str, object]]) -> dict[str, object]:
    return {
        "schema_version": 1,
        "profile_id": PROFILE_ID,
        "archive_root": ARCHIVE_ROOT,
        "scope": "Exact rational KKT certificates for finite continuous shared acquisition.",
        "limits": ["Does not find optima.", "Does not validate sampling laws or observations.",
                   "Does not establish production acceptance.", "Does not represent irrational certificate data."],
        "python": {"minimum_version": "3.9", "checked_implementation": "CPython",
                   "checked_versions": ["3.9.6", "3.13.12", "3.14.6"],
                   "standard_library_only": True},
        "external_dependencies": [],
        "environment": {"PYTHONDONTWRITEBYTECODE": "1"},
        "source_sha256": SOURCE_SHA256,
        "manifest": {"path": MANIFEST_NAME, "schema_version": 1,
                     "excluded_self": MANIFEST_NAME, "exact_member_set": True},
        "commands": [
            {"id": f"tests-{mode}",
             "argv": ["python3", "-B"] + options + ["-m", "unittest", "-v", "test_verify_shared_acquisition"],
             "expected_exit_code": 0, "expected_stdout": "",
             "expected_stderr_contains": ["Ran 21 tests", "OK"]}
            for mode, options in (("normal", []), ("optimized", ["-O"]))
        ] + [
            {"id": f"self-test-{mode}",
             "argv": ["python3", "-B"] + options + ["verify_shared_acquisition.py", "--self-test"],
             "expected_exit_code": 0, "expected_stdout": '{"accepted":true,"self_test_checks":9}\n',
             "expected_stderr": ""}
            for mode, options in (("normal", []), ("optimized", ["-O"]))
        ],
        "example_modes": {"normal": ["python3", "-B", "verify_shared_acquisition.py"],
                          "optimized": ["python3", "-B", "-O", "verify_shared_acquisition.py"]},
        "examples": [{key: value for key, value in case.items() if key != "input"} for case in cases],
    }


def package_members(source_dir: Path) -> dict[str, bytes]:
    members = {}
    for name, expected in SOURCE_SHA256.items():
        data = (source_dir / name).read_bytes()
        if digest(data) != expected:
            raise ValueError(f"Accepted source digest differs: {name}")
        members[name] = data
    script_name = "package_shared_acquisition.py"
    members[script_name] = (source_dir / script_name).read_bytes()
    members["README.md"] = README.encode("utf-8")
    members["NOTICE.txt"] = NOTICE.encode("utf-8")
    cases = examples()
    members["PROFILE.json"] = json_bytes(profile(cases))
    for case in cases:
        members[case["path"]] = json_bytes(case["input"])
    members[MANIFEST_NAME] = json_bytes({
        "schema_version": 1, "algorithm": "sha256", "excluded_self": MANIFEST_NAME,
        "files": [{"path": name, "sha256": digest(data), "size": len(data)}
                  for name, data in sorted(members.items())],
    })
    return members


def build_archive(output: Path) -> dict[str, object]:
    members = package_members(Path(__file__).resolve().parent)
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_STORED) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(f"{ARCHIVE_ROOT}/{name}", (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, data)
    data = buffer.getvalue()
    with output.open("xb") as target:
        target.write(data)
    return {"built": True, "profile_id": PROFILE_ID, "member_count": len(members),
            "sha256": digest(data), "size": len(data)}


def verify_directory(directory: Path) -> dict[str, object]:
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError("The package root must be a real directory.")
    actual = {}
    for path in directory.rglob("*"):
        if path.is_symlink():
            raise ValueError("The package must not contain symbolic links.")
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError("The package must contain only regular files and directories.")
        actual[path.relative_to(directory).as_posix()] = path.read_bytes()
    raw = actual.get(MANIFEST_NAME)
    if raw is None:
        raise ValueError("The package manifest is missing.")
    manifest = json.loads(raw)
    if type(manifest) is not dict or set(manifest) != {"schema_version", "algorithm", "excluded_self", "files"}:
        raise ValueError("The manifest schema is invalid.")
    if (type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1
            or manifest["algorithm"] != "sha256" or manifest["excluded_self"] != MANIFEST_NAME
            or type(manifest["files"]) is not list):
        raise ValueError("The manifest contract is invalid.")
    if raw != json_bytes(manifest):
        raise ValueError("The manifest must use canonical JSON without duplicate keys.")
    expected = {}
    for row in manifest["files"]:
        if type(row) is not dict or set(row) != {"path", "sha256", "size"}:
            raise ValueError("A manifest row is invalid.")
        name = row["path"]
        if (type(name) is not str or not name or "\\" in name
                or any(part in ("", ".", "..") for part in name.split("/"))
                or name == MANIFEST_NAME or name in expected):
            raise ValueError("A manifest path is invalid or duplicated.")
        if (type(row["size"]) is not int or row["size"] < 0
                or type(row["sha256"]) is not str or not re.fullmatch("[0-9a-f]{64}", row["sha256"])):
            raise ValueError("A manifest digest or size is invalid.")
        expected[name] = row
    if list(expected) != sorted(expected) or set(actual) != set(expected) | {MANIFEST_NAME}:
        raise ValueError("The manifest must list the exact sorted member set.")
    for name, row in expected.items():
        if len(actual[name]) != row["size"] or digest(actual[name]) != row["sha256"]:
            raise ValueError(f"A member differs from its manifest: {name}")
    for name, accepted in SOURCE_SHA256.items():
        if name not in actual or digest(actual[name]) != accepted:
            raise ValueError(f"Accepted source digest differs: {name}")
    declared = package_members(Path(__file__).resolve().parent)
    if set(actual) != set(declared):
        raise ValueError("The extracted member set differs from the declared profile.")
    for name, data in declared.items():
        if actual[name] != data:
            raise ValueError(f"A member differs from the declared profile: {name}")
    return {"verified": True, "profile_id": PROFILE_ID, "member_count": len(actual)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build = commands.add_parser("build", help="write a new deterministic archive")
    build.add_argument("output", type=Path)
    verify = commands.add_parser("verify", help="verify a complete extracted package")
    verify.add_argument("directory", type=Path)
    args = parser.parse_args(argv)
    try:
        report = build_archive(args.output) if args.command == "build" else verify_directory(args.directory)
    except (OSError, ValueError, RecursionError) as error:
        print(json.dumps({"success": False, "reason": str(error)}, sort_keys=True), file=sys.stderr)
        return 1
    print(json.dumps(report, sort_keys=True, separators=(",", ":"), allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
