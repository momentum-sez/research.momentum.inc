# Shared acquisition: exact rational certificates

This package checks supplied optimality certificates for a finite continuous acquisition model.
Each purchase contributes the nonnegative incidence column for its bundle.
All bundle costs, scenario coefficients, and the budget must be positive.
Every estimand must have at least one covering bundle.
At least one estimand, bundle, and scenario is required.
The sample-count model is n = A x.

For each scenario k, the loss is sum_e a[k][e] / n[e].
The objective is the maximum scenario loss over purchases x >= 0 with c*x <= B.
A zero count gives infinite loss.
The certificate supplies a full-budget purchase plan and weights supported on its worst scenarios.
The checker recomputes counts, losses, averaged coefficients, and every bundle's KKT inequality using exact fractions.

KKT denotes the first-order optimality conditions stated in the checker.
Purchased bundles must satisfy equality.

Acceptance proves global optimality within this declared model.
The program does not find an optimum.
A rejected certificate does not prove that its purchase plan is suboptimal.
Some valid problems have irrational optima outside this certificate format.
The package does not establish a physical sampling law, valid observations, or production acceptance.

Required interpreter: Python 3.9 or later, with its standard library.
Checked interpreters: CPython 3.9.6, 3.13.12, and 3.14.6.
No external packages or network access are required.

Extract the ZIP and enter its top-level directory.
Keep the extracted files together.
Run the following commands from that directory:

```sh
export PYTHONDONTWRITEBYTECODE=1
python3 -B package_shared_acquisition.py verify .
python3 -B -m unittest -v test_verify_shared_acquisition
python3 -B -O -m unittest -v test_verify_shared_acquisition
python3 -B verify_shared_acquisition.py --self-test
python3 -B -O verify_shared_acquisition.py --self-test
```

The manifest command exits zero and reports `verified: true` with `profile_id: shared-acquisition-exact-kkt-v1`.
Each unittest command exits zero, reports `Ran 21 tests`, and ends with `OK`.
The reported test duration depends on the interpreter and machine.
Each self-test command exits zero and prints this exact JSON line:

```json
{"accepted":true,"self_test_checks":9}
```

The environment variable prevents bytecode writes in the test suite's child processes.
The `-B` option also prevents bytecode writes in each listed interpreter.
The `-O` checks confirm that certificate checks remain active with Python assertions disabled.
The test suite also detects a deliberate objective mutation under both modes.

The JSON input has exactly six fields: `A`, `costs`, `scenarios`, `budget`, `purchases`, and `scenario_weights`.
The incidence matrix `A` has one row per estimand and one column per bundle.
Numbers must be JSON integers or canonical rational strings, such as `"1/5"`.
Rational strings use reduced fractions and positive denominators.
Booleans, floats, nonfinite numbers, duplicate keys, and extra fields are rejected.

The Python API additionally accepts `Fraction` values and tuple arrays.
All rational output fields use canonical strings.

Run an example by passing its JSON path to the checker:

```sh
python3 -B verify_shared_acquisition.py examples/shared.json
python3 -B -O verify_shared_acquisition.py examples/shared.json
python3 -B verify_shared_acquisition.py examples/old-dual-new-singleton.json
python3 -B -O verify_shared_acquisition.py examples/old-dual-new-singleton.json
```

An accepted example exits zero and returns `accepted: true`.
An adverse example exits one and returns `accepted: false` with a structured reason.
Exit one is the expected result for the adverse examples below.

| Example | Expected result in either mode |
| --- | --- |
| `shared.json` | Value `1/24`, counts `[240,240,360]` |
| `robust.json` | Value `1/5`, counts `[50,50]` |
| `old-bundle.json` | Value `10`, counts `[1,1]` |
| `one-singleton.json` | Value `10`, counts `[1,1]` |
| `joint-singletons.json` | Value `4`, counts `[5/2,5/2]` |
| `rational-incidence.json` | Value `3`, counts `[2,3]` |
| `old-dual-new-singleton.json` | Rejection: `dual_feasibility` |
| `cheaper-unused-bundle.json` | Rejection: `dual_feasibility` |
| `inactive-scenario.json` | Rejection: `inactive_scenario` |
| `short-budget.json` | Rejection: `budget_mismatch` |
| `boolean-budget.json` | Rejection: `rational_type` |

The singleton examples separate a failed witness from a strict objective improvement.
One old dual fails after adding a singleton, while different scenario weights still certify value 10.
Adding both singleton bundles permits the exactly certified value 4.
The test suite supplies an independent improving plan for the cheaper unused bundle.

`PROFILE.json` records the toolchain, commands, source digests, and exact example expectations.
`MANIFEST.json` lists every other archive member with its size and SHA-256 digest.
Verification rejects missing files, extra files, symbolic links, and changed bytes.
The manifest omits itself to avoid a circular digest.
No manuscript or PDF hash appears inside the archive.
A separate release record can bind the archive to those artifacts.

The two certificate source files retain their accepted bytes.
The packaging script is also included, so the extracted sources can reproduce the ZIP:

```sh
python3 -B package_shared_acquisition.py build ../shared-acquisition-rebuilt.zip
```

The output path must not exist.
The build fixes member order, timestamps, file modes, and ZIP storage settings.
The resulting bytes are independent of the current directory, source timestamps, and Python optimization mode.
Read `NOTICE.txt` for the source licensing status and dependency statement.
