#!/usr/bin/env python3
"""Check exact optimality certificates for continuous shared acquisition.

For incidence A, costs c, and scenarios a[k], the objective is
F(Ax) = max_k sum_e a[k][e] / (Ax)[e], subject to x >= 0 and c*x <= B.
Zero counts give infinite objective. Costs, budget, and scenario coefficients
must be positive. Incidence must be nonnegative, with every estimand covered.

The certificate supplies purchases x and scenario weights alpha. The checker
recomputes all other quantities. It checks full budget, positive counts,
simplex weights supported on worst scenarios, and the exact KKT conditions.
KKT denotes the first-order optimality conditions used here.

Write bar_a = sum_k alpha[k]*a[k], g = bar_a/(Ax)**2, and lambda = F(Ax)/B.
The conditions are A.T*g <= lambda*c, with equality for purchased bundles.
For any feasible y with positive counts, convexity gives
F(Ay) >= F(Ax) - g*A(y-x) >= F(Ax).
A zero count gives infinite objective, so the certificate covers that boundary.

JSON input has exactly these fields, with A indexed by estimand then bundle:
  {"A": [[1, 0], [0, 1]], "costs": [1, 1],
   "scenarios": [[9, 1], [1, 9]], "budget": 100,
   "purchases": [50, 50], "scenario_weights": ["1/2", "1/2"]}
Numbers must be integers or canonical rational strings, such as "0" or "2/3".
Strings use reduced fractions and positive denominators. Floats are rejected.
The Python API also accepts Fraction values and tuple arrays. It rejects bools.
Reports encode every rational as a canonical string and sort object keys.
The output field bundle_slacks equals lambda*c - A.T*g.

Run with an input filename or '-' for standard input. Run --self-test for
explicit checks that remain active under Python -O. Exit status is zero for
acceptance, one for rejection, and two for command-line usage errors.

This checker verifies a supplied certificate. It does not find an optimum or
validate a physical sampling law. A rejection does not prove nonoptimality.
Some rational models have irrational optima that this format cannot represent.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path
import re
import sys


class CertificateError(ValueError):
    """A model or certificate failed the check named by code and path."""

    def __init__(self, code: str, path: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.path = path

    def as_dict(self) -> dict[str, str]:
        return {"code": self.code, "path": self.path, "message": str(self)}


def _rational(value: object, path: str) -> Fraction:
    if type(value) is int or type(value) is Fraction:
        return Fraction(value)
    if type(value) is str and re.fullmatch(r"-?(?:0|[1-9][0-9]*)(?:/[1-9][0-9]*)?", value):
        try:
            number = Fraction(value)
            if str(number) == value:
                return number
        except (ValueError, ZeroDivisionError):
            pass
    raise CertificateError(
        "rational_type", path,
        "Use an integer, Fraction, or canonical rational string.",
    )


def _array(value: object, path: str) -> list | tuple:
    if type(value) not in (list, tuple):
        raise CertificateError("array_type", path, "Use an array.")
    if not value:
        raise CertificateError("empty_array", path, "The array must contain an element.")
    return value


def _vector(value: object, path: str) -> tuple[Fraction, ...]:
    return tuple(_rational(item, f"{path}[{i}]")
                 for i, item in enumerate(_array(value, path)))


def _matrix(value: object, path: str) -> tuple[tuple[Fraction, ...], ...]:
    return tuple(_vector(row, f"{path}[{i}]")
                 for i, row in enumerate(_array(value, path)))


def robust_acquisition_certificate(
    A: object, costs: object, scenarios: object, B: object,
    x: object, weights: object,
) -> dict[str, object]:
    """Return exact Fraction witnesses or raise CertificateError.

    Arrays must be lists or tuples. The result certifies the supplied finite
    continuous model, including competing purchases with budget at most B.
    """

    incidence = _matrix(A, "$.A")
    cost = _vector(costs, "$.costs")
    coefficients = _matrix(scenarios, "$.scenarios")
    budget = _rational(B, "$.budget")
    purchases = _vector(x, "$.purchases")
    alpha = _vector(weights, "$.scenario_weights")
    estimands, bundles = len(incidence), len(cost)

    for e, row in enumerate(incidence):
        if len(row) != bundles:
            raise CertificateError("dimension", f"$.A[{e}]", "Each row must match the bundle count.")
        for b, entry in enumerate(row):
            if entry < 0:
                raise CertificateError("negative_incidence", f"$.A[{e}][{b}]", "Incidence must be nonnegative.")
        if not any(row):
            raise CertificateError("uncovered_estimand", f"$.A[{e}]", "Each estimand must have a covering bundle.")
    if len(purchases) != bundles:
        raise CertificateError("dimension", "$.purchases", "Purchases must match the bundle count.")
    for k, scenario in enumerate(coefficients):
        if len(scenario) != estimands:
            raise CertificateError("dimension", f"$.scenarios[{k}]", "Each scenario must match the estimand count.")
        for e, entry in enumerate(scenario):
            if entry <= 0:
                raise CertificateError("nonpositive_coefficient", f"$.scenarios[{k}][{e}]", "Scenario coefficients must be positive.")
    if len(alpha) != len(coefficients):
        raise CertificateError("dimension", "$.scenario_weights", "Weights must match the scenario count.")
    for b, entry in enumerate(cost):
        if entry <= 0:
            raise CertificateError("nonpositive_cost", f"$.costs[{b}]", "Costs must be positive.")
    if budget <= 0:
        raise CertificateError("nonpositive_budget", "$.budget", "The budget must be positive.")
    for b, entry in enumerate(purchases):
        if entry < 0:
            raise CertificateError("negative_purchase", f"$.purchases[{b}]", "Purchases must be nonnegative.")
    for k, entry in enumerate(alpha):
        if entry < 0:
            raise CertificateError("negative_weight", f"$.scenario_weights[{k}]", "Weights must be nonnegative.")
    if sum(alpha) != 1:
        raise CertificateError("weight_sum", "$.scenario_weights", "Weights must sum to one.")

    spent = sum(c * purchase for c, purchase in zip(cost, purchases))
    if spent != budget:
        raise CertificateError("budget_mismatch", "$.purchases", "The certificate must use the full budget.")
    counts = tuple(sum(row[b] * purchases[b] for b in range(bundles))
                   for row in incidence)
    for e, count in enumerate(counts):
        if count <= 0:
            raise CertificateError("zero_count", f"$.A[{e}]", "The purchase plan must give each estimand a positive count.")
    objectives = tuple(sum(a / n for a, n in zip(scenario, counts))
                       for scenario in coefficients)
    value = max(objectives)
    for k, weight in enumerate(alpha):
        if weight > 0 and objectives[k] != value:
            raise CertificateError("inactive_scenario", f"$.scenario_weights[{k}]", "Positive weights must select worst scenarios.")

    averaged = tuple(sum(alpha[k] * coefficients[k][e]
                         for k in range(len(coefficients)))
                     for e in range(estimands))
    gradient = tuple(a / n**2 for a, n in zip(averaged, counts))
    multiplier = value / budget
    loads = tuple(sum(incidence[e][b] * gradient[e] for e in range(estimands))
                  for b in range(bundles))
    slacks = tuple(multiplier * cost[b] - loads[b] for b in range(bundles))
    for b, slack in enumerate(slacks):
        if slack < 0:
            raise CertificateError("dual_feasibility", f"$.purchases[{b}]", "A bundle exceeds its dual cost bound.")
        if purchases[b] > 0 and slack != 0:
            raise CertificateError("complementarity", f"$.purchases[{b}]", "A purchased bundle must meet its dual cost bound.")

    return {
        "value": value, "counts": counts, "budget_spent": spent,
        "scenario_objectives": objectives, "scenario_weights": alpha,
        "averaged_coefficients": averaged, "gradient": gradient,
        "lambda": multiplier, "dual": tuple(g / multiplier for g in gradient),
        "bundle_slacks": slacks,
    }


def _jsonable(value: object) -> object:
    if type(value) is Fraction:
        return str(value)
    if type(value) is tuple:
        return [_jsonable(item) for item in value]
    if type(value) is dict:
        return {key: _jsonable(item) for key, item in value.items()}
    return value


def _rejection(error: CertificateError) -> dict[str, object]:
    return {"accepted": False, "reason": error.as_dict()}


def verify_document(document: object) -> dict[str, object]:
    """Check the input schema and return a JSON-compatible decision."""

    fields = {"A", "costs", "scenarios", "budget", "purchases", "scenario_weights"}
    try:
        if type(document) is not dict:
            raise CertificateError("object_type", "$", "The input must be an object.")
        if any(type(key) is not str for key in document) or set(document) != fields:
            raise CertificateError(
                "schema", "$",
                "Supply exactly A, costs, scenarios, budget, purchases, and scenario_weights.",
            )
        certificate = robust_acquisition_certificate(
            document["A"], document["costs"], document["scenarios"],
            document["budget"], document["purchases"], document["scenario_weights"],
        )
        try:
            result = _jsonable(certificate)
        except ValueError as error:
            raise CertificateError(
                "rational_encoding", "$",
                "The result exceeds this interpreter's integer string limit.",
            ) from error
        return {"accepted": True, "certificate": result}
    except CertificateError as error:
        return _rejection(error)


def _unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result = {}
    for key, value in pairs:
        if key in result:
            raise CertificateError("duplicate_key", "$", "JSON object keys must be unique.")
        result[key] = value
    return result


def _reject_json_number(value: str) -> None:
    raise CertificateError("json_number", "$", "Use JSON integers or canonical rational strings for numbers.")


def verify_json(text: str) -> dict[str, object]:
    """Parse strict JSON and check one certificate without input coercion."""

    if type(text) is not str:
        return _rejection(CertificateError("json_type", "$", "JSON input must be text."))
    try:
        document = json.loads(text, object_pairs_hook=_unique_object,
                              parse_float=_reject_json_number,
                              parse_constant=_reject_json_number)
    except CertificateError as error:
        return _rejection(error)
    except (ValueError, RecursionError):
        return _rejection(CertificateError("invalid_json", "$", "The input is not supported JSON."))
    return verify_document(document)


def self_test() -> int:
    """Run exact checks whose execution is unchanged by Python -O."""

    checks = 0

    def require(actual: object, expected: object, name: str) -> None:
        nonlocal checks
        if actual != expected:
            raise AssertionError(name)
        checks += 1

    shared = robust_acquisition_certificate(
        [[1, 0, 0, 1], [0, 1, 0, 1], [0, 0, 1, 1]], [1, 1, 1, 2],
        [[1, 3, 9]], 600, [0, 0, 120, 240], [1],
    )
    require(shared["counts"], (240, 240, 360), "shared counts")
    require(shared["value"], Fraction(1, 24), "shared objective")
    require(shared["dual"], (Fraction(1, 4), Fraction(3, 4), 1), "shared dual")
    robust = robust_acquisition_certificate(
        [[1, 0], [0, 1]], [1, 1], [[9, 1], [1, 9]], 100,
        [50, 50], ["1/2", "1/2"],
    )
    require(robust["value"], Fraction(1, 5), "robust objective")
    old = robust_acquisition_certificate([[1], [1]], [1], [[9, 1], [1, 9]], 1, [1], [1, 0])
    require(old["value"], 10, "old objective")
    single = robust_acquisition_certificate(
        [[1, 1], [1, 0]], [1, "1/5"], [[9, 1], [1, 9]], 1, [1, 0], [0, 1],
    )
    require(single["value"], 10, "one new bundle does not improve the objective")
    joint = robust_acquisition_certificate(
        [[1, 1, 0], [1, 0, 1]], [1, "1/5", "1/5"], [[9, 1], [1, 9]], 1,
        [0, "5/2", "5/2"], ["1/2", "1/2"],
    )
    require(joint["value"], 4, "two new bundles improve the objective")
    for weights, expected in (([1, 0], "dual_feasibility"), ([True, 0], "rational_type")):
        try:
            robust_acquisition_certificate(
                [[1, 1], [1, 0]], [1, "1/5"], [[9, 1], [1, 9]], 1, [1, 0], weights,
            )
        except CertificateError as error:
            require(error.code, expected, "rejected certificate reason")
        else:
            raise AssertionError("invalid certificate was accepted")
    return checks


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", help="JSON file, or '-' for standard input")
    parser.add_argument("--self-test", action="store_true", help="run exact internal checks")
    args = parser.parse_args(argv)
    if args.self_test:
        if args.input is not None:
            parser.error("--self-test does not take an input file")
        report = {"accepted": True, "self_test_checks": self_test()}
    else:
        try:
            raw = (sys.stdin.read() if args.input in (None, "-")
                   else Path(args.input).read_text(encoding="utf-8"))
            report = verify_json(raw)
        except (OSError, UnicodeError):
            report = _rejection(CertificateError("input_read", "$", "Cannot read the input as UTF-8 text."))
    print(json.dumps(report, sort_keys=True, separators=(",", ":"), allow_nan=False))
    return 0 if report["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
