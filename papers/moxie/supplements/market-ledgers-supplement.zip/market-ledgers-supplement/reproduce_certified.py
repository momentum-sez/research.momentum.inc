"""Reproduce recorded finite outputs through the supplied reference functions."""
from fractions import Fraction as F
from pathlib import Path
import json
import certified_estimator as c
from test_certified_estimator import count_fixture, COUNTS
from test_drift_estimator import positive_fixture

def require(value, message):
    if not value:
        raise ValueError(message)

def exact(value):
    return F(int(value['numerator_hex'], 16), int(value['denominator_hex'], 16))

expected = json.loads(Path('expected/CERTIFIED-CATALOGUE.json').read_text())
seeded = positive_fixture()
require(tuple(tuple(row['counts']) for row in seeded['results']) == COUNTS, 'Seeded nested counts differ')
observations, catalogue = count_fixture()
result = c.estimate_catalogue(observations, catalogue, bits=80)
require(result['selected_index'] == expected['selected_index'], 'Selected index differs')
require(result['selected']['window'].length == expected['selected_window_length'], 'Selected window differs')
require(len(result['results']) == len(expected['windows']), 'Window count differs')
require(list(c.display_interval(result['selected']['coupling_interval'])) == expected['selected_interval_decimal'], 'Selected displayed interval differs')
rows = []
for item, reference in zip(result['results'], expected['windows']):
    n = item['window'].length
    direct = c.counts_interval(item['counts'], F(1, 80), F(n - 1, 1000000), bits=80)
    require(tuple(item['counts']) == tuple(reference['counts']), 'Counts differ')
    for field, reference_field in [('coupling_interval', 'coupling_interval'), ('radius', 'cell_radius'), ('point_interval', 'point_interval')]:
        for endpoint in ['lower', 'upper']:
            value = getattr(item[field], endpoint)
            require(value == exact(reference[reference_field][endpoint]), field + ' differs from captured rational value')
            require(value == getattr(direct[field], endpoint), field + ' differs across fixture routes')
    for field in ['cell_lower', 'cell_upper']:
        require(len(item[field]) == len(reference[field]), field + ' length differs')
        require(all(value == exact(stored) for value, stored in zip(item[field], reference[field])), field + ' differs')
    displayed = c.display_interval(item['coupling_interval'])
    require(list(displayed) == reference['outward_six_decimal_coupling'], 'Displayed interval differs')
    radius = c.decimal_endpoint(item['radius'].upper, 6, 'upper')
    require(radius == reference['upward_six_decimal_cell_radius'], 'Displayed radius differs')
    rows.append({'window_length': n, 'counts': list(item['counts']), 'outward_interval': displayed, 'upward_cell_radius': radius})
output = {'seeded_counts_match_frozen_counts': True, 'all_recorded_rational_intervals_match': True,
          'selected_window_length': result['selected']['window'].length, 'windows': rows}
Path('certified-reproduction.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
