from fractions import Fraction as F
from itertools import permutations
import math
import unittest

import numpy as np

from pair_adapter import (APMM, JointLMSR, ParlayMarket, PairAccount, PairTarget,
                          buy_premium, native_plan, pm_conjunction_plan, quote_value)


UNIFORM = PairTarget(('0.25',)*4)
TARGET = PairTarget(('0.16', '0.04', '0.16', '0.64'))
MECHANISMS = (JointLMSR, ParlayMarket, APMM)


def total_debit(model, target, rate=F(0)):
    _, trades = native_plan(model, target)
    return sum((quote_value(t['premium'])*(1+rate) for t in trades), F(0))


class PairAdapterTests(unittest.TestCase):
    def test_exact_codec_on_positive_simplex_and_tiny_cells(self):
        checked = 0
        for a in range(1, 10):
            for b in range(1, 11-a):
                for c in range(1, 12-a-b):
                    cells = tuple(F(v, 12) for v in (a, b, c, 12-a-b-c))
                    target = PairTarget(cells)
                    self.assertEqual(PairTarget.from_moments(*target.moments), target)
                    checked += 1
        self.assertEqual(checked, 165)
        tiny = F(1, 10**100)
        target = PairTarget((tiny, F(1, 3), F(1, 3), F(1, 3)-tiny))
        self.assertEqual(PairTarget.from_moments(*target.moments), target)
        self.assertEqual(TARGET.identity, PairTarget.from_moments('0.8', '0.68', '0.64').identity)

    def test_codec_rejects_infeasible_or_incomplete_laws(self):
        for values in [('0.1', '0.1', '0.2'), ('0.9', '0.9', '0.1'), ('0', '0.5', '0')]:
            with self.assertRaises(ValueError):
                PairTarget.from_moments(*values)
        with self.assertRaises(ValueError):
            PairTarget(('0.1',)*4)

    def test_exact_codec_and_numeric_admission_have_separate_domains(self):
        tiny = F(1, 10**1000)
        target = PairTarget((tiny, F(1, 3), F(1, 3), F(1, 3)-tiny))
        self.assertEqual(PairTarget.from_moments(*target.moments), target)
        for cls in MECHANISMS:
            account = PairAccount(cls, UNIFORM)
            before = account.economic_state()
            with self.assertRaises(ValueError):
                account.execute('unrepresentable', target)
            self.assertEqual(account.economic_state(), before)

    def test_pm_pair_gradient_matches_differentiation(self):
        model = ParlayMarket([0.4, 0.1, 0.1, 0.4])
        original = model.theta.copy()
        proposed, trade = pm_conjunction_plan(model, (0, 1), F(64, 100))
        indicator = model.states[:, 0]*model.states[:, 1]
        def loss(theta):
            model.theta = theta
            q = float(model.joint() @ indicator)
            return -0.64*math.log(q)-0.36*math.log1p(-q)
        derivative = []
        for i in range(3):
            delta = np.eye(3)[i]*1e-6
            derivative.append((loss(original+delta)-loss(original-delta))/(2e-6))
        model.theta = original
        np.testing.assert_allclose(trade['gradient'], derivative, atol=2e-9, rtol=0)
        np.testing.assert_allclose(proposed, original-model.eta*np.array(derivative), atol=5e-10, rtol=0)

    def test_pm_batch_uses_each_preceding_staged_state(self):
        model = ParlayMarket(UNIFORM.vector())
        original = model.theta.copy()
        proposed, trades = native_plan(model, TARGET)
        manual = ParlayMarket(UNIFORM.vector())
        for legs, tau, record in zip(((0,), (1,), (0, 1)), TARGET.moments, trades):
            next_theta, direct = pm_conjunction_plan(manual, legs, tau)
            self.assertEqual(direct['premium'], record['premium'])
            np.testing.assert_array_equal(direct['issued_payoff'], record['issued_payoff'])
            manual.commit(next_theta)
        np.testing.assert_array_equal(proposed.theta, manual.theta)
        np.testing.assert_array_equal(model.theta, original)
        self.assertGreater(max(abs(proposed.joint()-TARGET.vector())), 0.3)

    def test_full_budget_not_renewed_per_primitive(self):
        for cls in (ParlayMarket, APMM):
            account = PairAccount(cls, UNIFORM)
            before = account.economic_state()
            _, trades = native_plan(account.model, TARGET)
            first = quote_value(trades[0]['premium'])
            row = account.execute('pair', TARGET, first)
            self.assertFalse(row['accepted'])
            self.assertEqual(row['reason'], 'request_budget')
            self.assertEqual(account.economic_state(), before)
            self.assertEqual(row['actual_issued'], (F(0),)*4)
            self.assertGreater(row['prefixes'][-1]['total_debit'], first)

    def test_budget_exact_boundary_has_no_repeatable_epsilon(self):
        for cls in MECHANISMS:
            account = PairAccount(cls, UNIFORM, fee_rate='0.013')
            charge = total_debit(account.model, TARGET, F(13, 1000))
            row = account.execute('short', TARGET, charge-F(1, 2**100))
            self.assertFalse(row['accepted'])
            self.assertEqual(row['reason'], 'request_budget')
            row = account.execute('funded', TARGET, charge)
            self.assertTrue(row['accepted'])
            self.assertEqual(account.trader_initial-account.trader_cash, charge)

    def test_capital_rejection_rolls_back_all_quotes_and_holdings(self):
        for cls in MECHANISMS:
            account = PairAccount(cls, UNIFORM, maker_cash=0)
            before = account.economic_state()
            row = account.execute('unfunded-maker', TARGET)
            self.assertFalse(row['accepted'])
            self.assertEqual(row['reason'], 'maker_prefix_reserve')
            self.assertEqual(account.economic_state(), before)

    def test_persistent_wallet_cannot_reuse_spent_cash(self):
        model = ParlayMarket(UNIFORM.vector())
        first_cost = total_debit(model, TARGET)
        account = PairAccount(ParlayMarket, UNIFORM, trader_cash=first_cost)
        self.assertTrue(account.execute('first', TARGET)['accepted'])
        self.assertEqual(account.trader_cash, 0)
        before = account.economic_state()
        row = account.execute('second', TARGET)
        self.assertFalse(row['accepted'])
        self.assertEqual(row['reason'], 'trader_balance')
        self.assertEqual(account.economic_state(), before)

    def test_replay_preserves_occurrence_and_rejects_changed_command(self):
        for cls in MECHANISMS:
            account = PairAccount(cls, UNIFORM)
            row = account.execute('same-command', TARGET)
            before = account.economic_state()
            result = account.execute('same-command', TARGET)
            self.assertTrue(result['replayed'])
            self.assertEqual(result['row'], row)
            self.assertEqual(account.economic_state(), before)
            self.assertEqual(len(account.rows), 1)
            with self.assertRaises(ValueError):
                account.execute('same-command', UNIFORM)
            with self.assertRaises(ValueError):
                account.execute('same-command', TARGET, 99)

    def test_stable_cost_at_zero_and_tiny_share_quantities(self):
        self.assertEqual(buy_premium([0.1, 0.9], [0, 0], 10), 0)
        for scale in (1e-300, 1e-20, 1e-12, 1, 10000):
            c = buy_premium([0.1, 0.9], [0, scale], 10)
            self.assertGreaterEqual(c, 0)
            self.assertLessEqual(c, scale)
        for invalid in (-1, float('inf'), float('nan')):
            with self.assertRaises(ValueError):
                quote_value(invalid)

    def test_common_information_and_exact_settlement_conservation(self):
        rng = np.random.default_rng(170113)
        arrivals = [PairTarget(tuple(F(int(v), int(sum(w))) for v in w))
                    for w in rng.integers(1, 50, size=(20, 4))]
        for cls in MECHANISMS:
            account = PairAccount(cls, UNIFORM, maker_cash=1000, trader_cash=10000, fee_rate='0.007')
            for i, target in enumerate(arrivals):
                row = account.execute(str(i), target, budget=400)
                self.assertTrue(row['accepted'])
                self.assertEqual(row['target_id'], target.identity)
                self.assertTrue(all(p['minimum_maker_cash'] >= 0 for p in row['prefixes']))
                cash = account.settlement(target)
                self.assertEqual(cash['cash_identity_error'], 0)
                self.assertEqual(cash['combined_cash_errors'], (F(0),)*4)
                self.assertGreaterEqual(min(cash['maker_terminal_cash']), 0)

    def test_complete_pair_information_is_useful(self):
        for cls in MECHANISMS:
            account = PairAccount(cls, UNIFORM)
            initial_kl = float(TARGET.vector() @ np.log(TARGET.vector()/account.model.joint()))
            for i in range(60):
                self.assertTrue(account.execute(str(i), TARGET)['accepted'])
            final_kl = float(TARGET.vector() @ np.log(TARGET.vector()/account.model.joint()))
            self.assertLess(final_kl, initial_kl)
            if cls is not ParlayMarket:
                np.testing.assert_allclose(account.model.joint(), TARGET.vector(), atol=1e-14, rtol=0)
            else:
                self.assertLess(final_kl, 0.063)
                self.assertGreater(final_kl, 0.06)

    def test_repeated_pm_information_has_additional_paid_loss(self):
        account = PairAccount(ParlayMarket, UNIFORM)
        account.execute('first', TARGET)
        first = account.settlement(TARGET)
        for i in range(1, 4):
            account.execute(str(i), TARGET)
        last = account.settlement(TARGET)
        self.assertGreater(last['expected_maker_loss'], first['expected_maker_loss'])
        self.assertGreater(account.rows[-1]['actual_premium'], 0)
        self.assertLess(last['maximum_maker_loss'], account.capital)

    def test_order_sensitivity_is_observable(self):
        quotes = []
        for order in permutations(range(3)):
            account = PairAccount(ParlayMarket, UNIFORM, pm_order=order)
            account.execute('pair', TARGET)
            quotes.append(account.model.joint())
        self.assertGreater(max(np.max(abs(p-quotes[0])) for p in quotes[1:]), 1e-4)

    def test_quote_restoring_cycle_has_statewise_positive_apmm_payout(self):
        prior = PairTarget(('0.4', '0.1', '0.1', '0.4'))
        for cls in (JointLMSR, APMM):
            account = PairAccount(cls, prior)
            self.assertTrue(account.execute('outward', TARGET)['accepted'])
            self.assertTrue(account.execute('return', prior)['accepted'])
            np.testing.assert_allclose(account.model.joint(), prior.vector(), atol=1e-14, rtol=0)
            loss = np.array([float(x) for x in account.settlement(prior)['maker_loss_by_outcome']])
            expected = 10*math.log(353/272) if cls is APMM else 0
            np.testing.assert_allclose(loss, expected, atol=2e-14, rtol=0)
            if cls is APMM:
                self.assertGreater(min(loss), 2.6)
                np.testing.assert_allclose(account.model.diagnostic()['singleton_quotes'], [0.5, 0.5], atol=1e-14, rtol=0)

    def test_repeated_cycles_retain_all_liabilities_until_capital_stops_admission(self):
        prior = PairTarget(('0.4', '0.1', '0.1', '0.4'))
        account = PairAccount(APMM, prior, maker_cash=20)
        completed = 0
        for cycle in range(20):
            rejected = False
            for step, target in enumerate((TARGET, prior)):
                before = account.economic_state()
                row = account.execute(f'{cycle}-{step}', target)
                if not row['accepted']:
                    self.assertEqual(row['reason'], 'maker_prefix_reserve')
                    self.assertEqual(account.economic_state(), before)
                    rejected = True
                    break
                self.assertGreaterEqual(min(account.settlement(prior)['maker_terminal_cash']), 0)
            if rejected:
                break
            completed += 1
        self.assertGreater(completed, 0)
        self.assertLess(completed, 20)
        self.assertGreater(float(account.settlement(prior)['expected_maker_loss']), 10)

    def test_apmm_direct_lmsr_statewise_loss_identity(self):
        rng = np.random.default_rng(20260905)
        differences = []
        for _ in range(40):
            weights = rng.integers(1, 50, size=(2, 4))
            prior, target = [PairTarget(tuple(F(int(v), int(sum(w))) for v in w)) for w in weights]
            apmm = PairAccount(APMM, prior, maker_cash=1000)
            joint = PairAccount(JointLMSR, prior, maker_cash=1000)
            self.assertTrue(apmm.execute('pair', target, 500)['accepted'])
            self.assertTrue(joint.execute('pair', target, 500)['accepted'])
            p, t = prior.vector(), target.vector()
            fa = np.array([sum(t[:2])/sum(p[:2]), sum(t[2:])/sum(p[2:])])
            fb = np.array([sum(t[::2])/sum(p[::2]), sum(t[1::2])/sum(p[1::2])])
            z = sum(p[i]*fa[i//2]*fb[i % 2] for i in range(4))
            l_joint = np.array([float(x) for x in joint.settlement(target)['maker_loss_by_outcome']])
            l_apmm = np.array([float(x) for x in apmm.settlement(target)['maker_loss_by_outcome']])
            np.testing.assert_allclose(l_joint, 10*np.log(t/p), atol=8e-14, rtol=0)
            np.testing.assert_allclose(l_apmm-l_joint, 10*math.log(z), atol=8e-14, rtol=0)
            differences.append(math.log(z))
        self.assertGreater(max(differences), 0)
        self.assertLess(min(differences), 0)


if __name__ == '__main__':
    unittest.main()
