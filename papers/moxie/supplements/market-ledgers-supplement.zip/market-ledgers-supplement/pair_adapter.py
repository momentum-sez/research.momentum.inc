"""Matched pair information, native execution, and exact finite cash accounting.

Pricing uses binary64 enumeration. A quoted binary64 share or premium becomes
its exact rational value at admission. This is a finite research realization,
not a claim about either cited project's production payment infrastructure.
The frozen native pricing implementations are in market_ledgers.py.
"""
from copy import deepcopy
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import json
import math

import numpy as np
from scipy.special import logsumexp

from market_ledgers import APMM, JointLMSR, ParlayMarket, binary_purchase


def rational(value):
    """Input money/probabilities use decimal spelling; quotes use quote_value."""
    if isinstance(value, bool):
        raise ValueError('Boolean amounts are invalid.')
    return value if isinstance(value, Fraction) else Fraction(str(value))


def quote_value(value):
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError('A quoted cash or issued-share amount must be finite and nonnegative.')
    return Fraction.from_float(value)


def buy_premium(probability, shares, liquidity):
    """Stable cost difference for a nonnegative issued bundle.

    log(1 + sum q*expm1(h/b)) avoids a negative cancellation residue when
    the bundle is zero or very small. It changes no exact LMSR formula.
    """
    q, h = np.asarray(probability, dtype=float), np.asarray(shares, dtype=float)
    if q.shape != h.shape or not np.all(np.isfinite(q)) or not np.all(np.isfinite(h)):
        raise ValueError('Finite quote and share vectors must have equal shape.')
    if min(q) <= 0 or min(h) < 0 or liquidity <= 0:
        raise ValueError('Quotes and liquidity must be positive; shares nonnegative.')
    q = q / sum(q)
    if max(h/liquidity) < 500:
        return float(liquidity * np.log1p(q @ np.expm1(h/liquidity)))
    return float(liquidity * logsumexp(np.log(q)+h/liquidity))


def exact_json(value):
    if isinstance(value, Fraction):
        return f'{value.numerator}/{value.denominator}'
    if isinstance(value, dict):
        return {str(k): exact_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_json(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    return value


@dataclass(frozen=True)
class PairTarget:
    """Positive two-event law in the order 00, 01, 10, 11."""
    cells: tuple

    def __post_init__(self):
        cells = tuple(rational(v) for v in self.cells)
        if len(cells) != 4 or min(cells) <= 0 or sum(cells) != 1:
            raise ValueError('Four positive cells must sum exactly to one.')
        object.__setattr__(self, 'cells', cells)

    @property
    def moments(self):
        _, b_only, a_only, both = self.cells
        return (a_only + both, b_only + both, both)

    @classmethod
    def from_moments(cls, a, b, c):
        a, b, c = map(rational, (a, b, c))
        return cls((1-a-b+c, b-c, a-c, c))

    def vector(self):
        vector = np.array([float(v) for v in self.cells])
        if min(vector) <= 0 or max(vector) >= 1:
            raise ValueError('The positive target lies outside the binary64 pricing domain.')
        return vector

    @property
    def identity(self):
        payload = json.dumps(exact_json(self.cells), separators=(',', ':'))
        return sha256(payload.encode()).hexdigest()


def pm_conjunction_plan(model, legs, target):
    """Eq. 13 over the native positive conjunction, before the real trade."""
    p = model.joint()
    indicator = np.prod(model.states[:, legs], axis=1)
    q = float(p @ indicator)
    h, native_premium = binary_purchase(q, float(target), model.b)
    premium = buy_premium([1-q, q], h, model.b)
    covariance = model.features.T @ (p * indicator) - (p @ model.features) * q
    gradient = (q-float(target)) / (q*(1-q)) * covariance
    return model.theta - model.eta*gradient, {
        'native_contract': list(legs), 'target_probability': target,
        'premium': premium, 'native_float_premium': native_premium,
        'issued_payoff': h[indicator].tolist(),
        'binary_issued_no_yes': h.tolist(), 'pretrade_probability': q,
        'gradient': gradient.tolist(), 'learning_rate': model.eta,
        'shadow_cash': 0.0, 'shadow_issued_payoff': [0.0]*4,
    }


def native_plan(model, target, order=(0, 1, 2)):
    """Plan on a private copy; each interface receives the same pair law.

    Only the PM adapter uses order. Entries name A, B, and A AND B. Order
    sensitivity is reported, not hidden by assigning PM a joint-target reset.
    """
    target.vector()  # Validate the numeric admission domain before planning.
    shadow = deepcopy(model)
    if isinstance(shadow, ParlayMarket):
        if tuple(sorted(order)) != (0, 1, 2):
            raise ValueError('The PM adapter requires each of A, B, AB once.')
        records = []
        for index in order:
            legs = ((0,), (1,), (0, 1))[index]
            proposed, trade = pm_conjunction_plan(shadow, legs, target.moments[index])
            shadow.commit(proposed)
            trade['quote_after'] = shadow.diagnostic()
            records.append(trade)
        return shadow, records
    if isinstance(shadow, APMM):
        proposed, trade = shadow.plan_full((0, 1), target.vector())
        for row in trade['subtrades']:
            row['native_float_premium'] = row['premium']
            row['premium'] = buy_premium(row['quote_before'], row['issued_by_book_outcome'], shadow.b)
        shadow.commit(proposed)
        return shadow, trade['subtrades']
    if isinstance(shadow, JointLMSR):
        q = shadow.joint()
        change = shadow.b * (np.log(target.vector()) - np.log(q))
        h = change - min(change)
        premium = buy_premium(q, h, shadow.b)
        shadow.commit(shadow.inventory + h)
        return shadow, [{'native_contract': ['00', '01', '10', '11'],
                         'premium': premium, 'issued_payoff': h.tolist()}]
    raise ValueError('Unrecognized native mechanism.')


class PairAccount:
    """Atomic information arrivals with a real persistent trader balance.

    Prefix reserves are checked before commit as an explicit adapter policy.
    They measure the hypothetical native sequence even though admission is
    atomic. Fee cash remains drawable here. Fees are not a segregated account.
    """
    def __init__(self, model_class, prior, *, liquidity=10, maker_cash=100,
                 trader_cash=10000, fee_rate=0, pm_order=(0, 1, 2)):
        prior = prior if isinstance(prior, PairTarget) else PairTarget(tuple(prior))
        self.capital, self.trader_initial, self.fee_rate = map(
            rational, (maker_cash, trader_cash, fee_rate))
        if min(self.capital, self.trader_initial, self.fee_rate) < 0 or liquidity <= 0:
            raise ValueError('Cash and fees must be nonnegative, liquidity positive.')
        self.model = model_class(prior.vector(), b=float(liquidity),
                                 capital=float(self.capital), fee_rate=0.0)
        self.cash = self.capital
        self.trader_cash = self.trader_initial
        self.premiums = self.fees = Fraction(0)
        self.issued = (Fraction(0),)*4
        self.rows = []
        self.pm_order = tuple(pm_order)
        self.seen = {}

    def economic_state(self):
        return {'quote': self.model.diagnostic(), 'cash': self.cash,
                'trader_cash': self.trader_cash, 'issued': self.issued,
                'premiums': self.premiums, 'fees': self.fees}

    def execute(self, request_id, target, budget=100):
        if not isinstance(request_id, str) or not request_id:
            raise ValueError('Each command needs a nonempty request identity.')
        if not isinstance(target, PairTarget):
            raise TypeError('The request must carry a validated PairTarget.')
        budget = rational(budget)
        if budget < 0:
            raise ValueError('A budget must be nonnegative.')
        command = (target.identity, budget)
        if request_id in self.seen:
            original, index = self.seen[request_id]
            if original != command:
                raise ValueError('A reused request identity has different content.')
            return {'replayed': True, 'original_index': index, 'row': self.rows[index]}

        before = self.economic_state()
        proposed, trades = native_plan(self.model, target, self.pm_order)
        debit = premiums = fees = Fraction(0)
        issue = [Fraction(0)]*4
        prefixes = []
        reason = None
        for index, trade in enumerate(trades):
            premium = quote_value(trade['premium'])
            fee = self.fee_rate * premium
            delta = tuple(quote_value(v) for v in trade['issued_payoff'])
            if len(delta) != 4:
                raise ValueError('Every sub-trade needs four settlement payouts.')
            premiums += premium
            fees += fee
            debit += premium + fee
            issue = [a+b for a, b in zip(issue, delta)]
            minimum_cash = min(self.cash+debit-old-new
                               for old, new in zip(self.issued, issue))
            failure = None
            if debit > budget:
                failure = 'request_budget'
            elif debit > self.trader_cash:
                failure = 'trader_balance'
            elif minimum_cash < 0:
                failure = 'maker_prefix_reserve'
            reason = reason or failure
            prefixes.append({'index': index, 'quoted_premium': premium, 'quoted_fee': fee,
                             'quoted_issued': delta, 'total_debit': debit,
                             'minimum_maker_cash': minimum_cash, 'failure': failure})

        accepted = reason is None
        if accepted:
            self.model = proposed
            self.cash += debit
            self.trader_cash -= debit
            self.premiums += premiums
            self.fees += fees
            self.issued = tuple(a+b for a, b in zip(self.issued, issue))
        row = {'request_id': request_id, 'target_id': target.identity,
               'target_cells': target.cells, 'target_moments': target.moments,
               'budget': budget, 'before': before, 'accepted': accepted,
               'reason': reason, 'native_subtrades': trades, 'prefixes': prefixes,
               'actual_premium': premiums if accepted else Fraction(0),
               'actual_fee': fees if accepted else Fraction(0),
               'actual_issued': tuple(issue) if accepted else (Fraction(0),)*4,
               'after': self.economic_state()}
        self.seen[request_id] = (command, len(self.rows))
        self.rows.append(row)
        return row

    def settlement(self, law):
        if not isinstance(law, PairTarget):
            raise TypeError('Settlement expectation needs an explicit law.')
        loss = tuple(v-self.premiums-self.fees for v in self.issued)
        terminal = tuple(self.cash-v for v in self.issued)
        trader_terminal = tuple(self.trader_cash+v for v in self.issued)
        path_reserve = max([Fraction(0)] + [
            self.capital-p['minimum_maker_cash'] for row in self.rows if row['accepted']
            for p in row['prefixes']])
        return {'maker_loss_by_outcome': loss, 'maker_terminal_cash': terminal,
                'trader_terminal_cash': trader_terminal,
                'expected_maker_loss': sum(p*v for p, v in zip(law.cells, loss)),
                'maximum_maker_loss': max(loss), 'path_reserve': path_reserve,
                'cash_identity_error': self.cash-self.capital-self.premiums-self.fees,
                'combined_cash_errors': tuple(a+b-self.capital-self.trader_initial
                                             for a, b in zip(terminal, trader_terminal))}


def summarize(account, target):
    end = account.model.diagnostic()
    p = np.asarray(end['joint'])
    t = target.vector()
    exact = account.settlement(target)
    return {'mechanism': account.model.name, 'final': end,
            'max_cell_error': float(max(abs(p-t))),
            'joint_kl': float(t @ np.log(t/p)),
            'accepted': sum(r['accepted'] for r in account.rows),
            'requested': len(account.rows),
            'native_subtrades_executed': sum(len(r['native_subtrades']) for r in account.rows if r['accepted']),
            'premiums': float(account.premiums), 'fees': float(account.fees),
            'expected_maker_loss': float(exact['expected_maker_loss']),
            'maximum_maker_loss': float(exact['maximum_maker_loss']),
            'path_reserve': float(exact['path_reserve']),
            'settlement_exact': exact, 'ledger': account.rows}


def experiment():
    target = PairTarget(('0.16', '0.04', '0.16', '0.64'))
    uniform = PairTarget(('0.25',)*4)
    results = {'scope': 'Two events, identical full target information, native portfolios recorded separately.',
               'liquidity': 10, 'maker_cash': 100, 'trader_cash': 10000,
               'per_request_budget': 100, 'fee_rate': 0,
               'target_id': target.identity, 'target_cells': target.cells,
               'fixtures': []}
    for name, requests in [('one_pair', 1), ('four_repeated_pairs', 4), ('sixty_repeated_pairs', 60)]:
        fixture = {'name': name, 'requests': requests, 'runs': []}
        for cls in (JointLMSR, ParlayMarket, APMM):
            account = PairAccount(cls, uniform)
            for i in range(requests):
                account.execute(f'{name}-{i}', target)
            fixture['runs'].append(summarize(account, target))
        results['fixtures'].append(fixture)
    from itertools import permutations
    results['pm_order_sensitivity'] = []
    for order in permutations(range(3)):
        account = PairAccount(ParlayMarket, uniform, pm_order=order)
        account.execute('one-pair', target)
        summary = summarize(account, target)
        results['pm_order_sensitivity'].append({'order': order, **summary})
    cycle_prior = PairTarget(('0.4', '0.1', '0.1', '0.4'))
    results['closed_target_cycle'] = []
    for cls in (JointLMSR, APMM):
        account = PairAccount(cls, cycle_prior)
        account.execute('cycle-outward', target)
        account.execute('cycle-return', cycle_prior)
        results['closed_target_cycle'].append(summarize(account, cycle_prior))
    return exact_json(results)


if __name__ == '__main__':
    from pathlib import Path
    Path('pair-adapter-results.json').write_text(json.dumps(experiment(), indent=2)+'\n')
