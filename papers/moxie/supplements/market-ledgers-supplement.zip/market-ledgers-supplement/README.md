# Parlay Identification of Ising Couplings: accompanying computations

This package contains the finite reference computations cited by the paper. The source capture date is 6 September 2026.

The experiment acceptance checks were updated on 8 September 2026. Their numerical predicates and calculations remain unchanged. Eight other reference files retain their captured bytes.

`REFERENCE-MANIFEST.json` identifies current and historical source hashes. The original numerical outputs in `expected/` retain their capture date, 5 September 2026. `expected/experiment-acceptance.json` records the additional acceptance output dated 8 September 2026.

## Reproduce

Use Python 3.14.6, NumPy 2.4.3, and SciPy 1.17.1 for the recorded environment. Other environments have not been validated for this package.

Extract the archive, enter `market-ledgers-supplement`, and run:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -B -m unittest -v test_market_ledgers test_pair_adapter test_drift_estimator test_certified_estimator
.venv/bin/python -B -m unittest -v test_market_ledgers_optimized
.venv/bin/python -B experiments.py
.venv/bin/python -B -O experiments.py
.venv/bin/python -B market_ledgers.py
.venv/bin/python -B pair_adapter.py
.venv/bin/python -B reproduce_certified.py
.venv/bin/python -B verify_results.py
```

The four original test modules exercise 57 checks: 14 market-ledger, 18 pair-adapter, 10 drift, and 15 certified-arithmetic checks.

`test_market_ledgers_optimized.py` runs the actual experiment in separate normal and optimized processes. It checks the recorded environment and compares both outputs against the numerical and acceptance references. Thirteen adverse inputs exercise all ten guard sites, including each condition in compound guards. Each input must stop execution in both modes before a result file appears.

`experiments.py` writes `experiment-results.json` beside its source. It runs seeded synthetic inference and loss examples. Its inputs and sampling rules appear in the source. The JSON records summaries, 18 named acceptance records, residuals, tolerances, and solver termination statuses. It does not serialize every sampled count or full trade path.

Each acceptance check uses an explicit exception and remains active under `python -O`. The environment record identifies the optimization mode. BFGS acceptance uses the stated gradient residual. A solver can report precision loss while that residual passes. The output records acceptance and solver termination separately.

`market_ledgers.py` and `pair_adapter.py` write their result files in the working directory. They record the specified arrivals, staged trades, premiums, payouts, and accounts.

`reproduce_certified.py` calls the supplied drift fixture and certified arithmetic. It verifies the seeded nested counts against the stored count fixture. It then checks every published rational interval and outward decimal endpoint against `expected/CERTIFIED-CATALOGUE.json`. The constructed count sequence and seeded simulation are distinct witnesses with the same nested counts.

`verify_results.py` compares result structure and values against captured outputs, including the separate acceptance reference. It omits the environment field and local timing fields. Numerical comparisons use relative tolerance 1e-10 and absolute tolerance 1e-10. Local timing varies across runs.

To compare only the experiment output, run `.venv/bin/python -B verify_results.py experiment-results.json`. The optimization tests also check each acceptance threshold independently.

`expected/` provides comparison evidence. Successful execution, comparison, and tests establish only these finite computations. Sampling validity, drift evidence, and performance on market data remain separate requirements.

## Contents and terms

The four source pairs cover market ledgers, pair requests, drift fixtures, and certified interval arithmetic. `experiments.py` contains the remaining synthetic examples. NumPy and SciPy are the only nonstandard dependencies.

Read `NOTICE.txt` before redistribution. No source license was supplied with the nine reference files. Dependency licenses appear in `dependencies/`.
