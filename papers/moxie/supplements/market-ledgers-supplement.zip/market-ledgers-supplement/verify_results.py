"""Compare generated finite results with supplied captured outputs."""
from pathlib import Path
import argparse
import json
import math

OMIT = {'environment', 'marginal_evaluation_microseconds'}

def compare(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) - OMIT != set(b) - OMIT:
            raise ValueError('Keys differ at ' + path)
        for key in sorted(set(a) - OMIT):
            compare(a[key], b[key], path + '/' + key)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            raise ValueError('Lengths differ at ' + path)
        for i, (x, y) in enumerate(zip(a, b)):
            compare(x, y, path + '/' + str(i))
    elif isinstance(a, (int, float)) and not isinstance(a, bool) and isinstance(b, (int, float)) and not isinstance(b, bool):
        if not math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-10):
            raise ValueError('Values differ at ' + path + ': ' + repr((a, b)))
    elif a != b:
        raise ValueError('Values differ at ' + path + ': ' + repr((a, b)))

names = ['experiment-results.json', 'market-ledger-results.json', 'pair-adapter-results.json']
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('result', nargs='?', choices=names)
selected = parser.parse_args().result
for name in [selected] if selected else names:
    expected = json.loads((Path('expected') / name).read_text())
    if name == 'experiment-results.json':
        expected['acceptance_checks'] = json.loads(Path('expected/experiment-acceptance.json').read_text())
    compare(json.loads(Path(name).read_text()), expected, name)
    print(name + ': matches within stated tolerance')
