"""Rational enclosures for the declared finite-window inference contract.

The arithmetic certifies calculated bounds. The caller supplies the sampling
law, drift premise, catalogue, and their statistical failure budgets.
"""

from dataclasses import dataclass
from fractions import Fraction
from math import isqrt


def rational(value):
    if type(value) is int:
        return Fraction(value)
    if type(value) is Fraction:
        return value
    raise TypeError("Use an exact integer or Fraction, never a float")


def precision(bits):
    if type(bits) is not int or not 8 <= bits <= 512:
        raise ValueError("Precision must be an integer from 8 through 512 bits")
    return bits


def power_two(k):
    return Fraction(1 << k) if k >= 0 else Fraction(1, 1 << -k)


def binary_exponent(x):
    x = rational(x)
    if x <= 0:
        raise ValueError("A binary exponent requires a positive rational")
    k = x.numerator.bit_length() - x.denominator.bit_length()
    if x < power_two(k):
        k -= 1
    return k


@dataclass(frozen=True)
class Interval:
    lower: Fraction
    upper: Fraction

    def __post_init__(self):
        if type(self.lower) is not Fraction or type(self.upper) is not Fraction:
            raise TypeError("Interval endpoints must be exact Fractions")
        if self.lower > self.upper:
            raise ValueError("Reversed interval")

    @property
    def width(self):
        return self.upper - self.lower


@dataclass(frozen=True)
class ExtendedInterval:
    # None denotes negative infinity on the left and positive infinity on the right.
    lower: Fraction | None
    upper: Fraction | None

    @property
    def width(self):
        return None if self.lower is None or self.upper is None else self.upper - self.lower


def log_core(z, tolerance, max_terms=4096):
    """Bound 2 atanh(z) by a positive series and its geometric tail."""
    z, tolerance = rational(z), rational(tolerance)
    if type(max_terms) is not int or max_terms <= 0:
        raise ValueError("Use a positive integer term budget")
    if not 0 <= z <= Fraction(1, 3) or tolerance <= 0:
        raise ValueError("Invalid reduced logarithm contract")
    if z == 0:
        return Interval(Fraction(0), Fraction(0))
    z2 = z * z
    total, term = Fraction(0), z
    for n in range(1, max_terms + 1):
        total += 2 * term / (2 * n - 1)
        term *= z2
        tail = 2 * term / ((2 * n + 1) * (1 - z2))
        if tail <= tolerance:
            return Interval(total, total + tail)
    raise ArithmeticError("Logarithm term budget exhausted")


def log_interval(x, bits=80):
    x = rational(x)
    bits = precision(bits)
    if x <= 0:
        raise ValueError("The logarithm requires a positive rational")
    if x == 1:
        return Interval(Fraction(0), Fraction(0))
    k = binary_exponent(x)
    y = x / power_two(k)
    tolerance = power_two(-bits) / (abs(k) + 1)
    small = log_core((y - 1) / (y + 1), tolerance)
    two = log_core(Fraction(1, 3), tolerance)
    if k >= 0:
        return Interval(k * two.lower + small.lower, k * two.upper + small.upper)
    return Interval(k * two.upper + small.lower, k * two.lower + small.upper)


def sqrt_interval(x, bits=80):
    """Use a scaled dyadic grid to retain relative accuracy for small inputs."""
    x = rational(x)
    bits = precision(bits)
    if x < 0:
        raise ValueError("The square root requires a nonnegative rational")
    if x == 0:
        return Interval(Fraction(0), Fraction(0))
    scale = power_two(binary_exponent(x) // 2)
    normalized = x / (scale * scale)
    grid = 1 << bits
    scaled = normalized * grid * grid
    m = isqrt(scaled.numerator // scaled.denominator)
    lower = scale * Fraction(m, grid)
    if lower * lower == x:
        return Interval(lower, lower)
    return Interval(lower, scale * Fraction(m + 1, grid))


def drift_radius(n, delta, drift, bits=80):
    if type(n) is not int or n <= 0:
        raise ValueError("Use a positive integer round count")
    delta, drift = rational(delta), rational(drift)
    if not 0 < delta < 1 or drift < 0:
        raise ValueError("Invalid failure budget or drift envelope")
    logarithm = log_interval(8 / delta, bits)
    lower = sqrt_interval(logarithm.lower / (2 * n), bits).lower
    upper = sqrt_interval(logarithm.upper / (2 * n), bits).upper
    return Interval(lower + drift, upper + drift)


def contrast_interval(cells, signs=(1, -1, -1, 1), bits=80):
    if len(cells) != 4 or sorted(signs) != [-1, -1, 1, 1]:
        raise ValueError("Use four cells and a balanced sign contrast")
    cells = tuple(rational(x) for x in cells)
    if min(cells) <= 0 or sum(cells) != 1:
        raise ValueError("Use a positive normalized cell law")
    ratio = Fraction(1)
    for q, sign in zip(cells, signs):
        ratio = ratio * q if sign == 1 else ratio / q
    result = log_interval(ratio, bits)
    return Interval(result.lower / 4, result.upper / 4)


def interior_error(radius, kappa, bits=80):
    kappa = rational(kappa)
    if radius.lower < 0:
        raise ValueError("Use a nonnegative radius interval")
    if kappa <= 0:
        raise ValueError("Use a positive population cell floor")
    if radius.upper >= kappa:
        return None
    result = log_interval((kappa + radius.upper) / (kappa - radius.upper), bits)
    return result.upper / 2


def counts_interval(counts, delta, drift, bits=80):
    if len(counts) != 4 or any(type(k) is not int or k < 0 for k in counts):
        raise ValueError("Use four nonnegative integer cell counts")
    n = sum(counts)
    if n == 0:
        raise ValueError("A window must contain an observed round")
    empirical = tuple(Fraction(k, n) for k in counts)
    radius = drift_radius(n, delta, drift, bits)
    lower = tuple(max(Fraction(0), q - radius.upper) for q in empirical)
    upper = tuple(min(Fraction(1), q + radius.upper) for q in empirical)
    lo_num, lo_den = lower[0] * lower[3], upper[1] * upper[2]
    hi_num, hi_den = upper[0] * upper[3], lower[1] * lower[2]
    lo = None if lo_num == 0 else log_interval(lo_num / lo_den, bits).lower / 4
    hi = None if hi_den == 0 else log_interval(hi_num / hi_den, bits).upper / 4
    return {"counts": tuple(counts), "rounds": n, "delta": rational(delta),
            "drift": rational(drift), "empirical": empirical, "radius": radius,
            "cell_lower": lower, "cell_upper": upper,
            "coupling_interval": ExtendedInterval(lo, hi),
            "point_interval": contrast_interval(empirical, bits=bits) if min(counts) else None,
            "estimate_status": "Interior" if min(counts) else "Boundary"}


@dataclass(frozen=True)
class Window:
    end: int
    length: int
    drift: Fraction
    drift_evidence: str


@dataclass(frozen=True)
class Catalogue:
    windows: tuple[Window, ...]
    delta: Fraction
    rho: Fraction = Fraction(0)

    def __post_init__(self):
        if type(self.windows) is not tuple or not self.windows:
            raise ValueError("Declare a nonempty immutable catalogue")
        delta, rho = rational(self.delta), rational(self.rho)
        if not 0 < delta < 1 or not 0 <= rho < 1 - delta:
            raise ValueError("Require delta > 0, rho >= 0, and delta + rho < 1")
        seen = set()
        for w in self.windows:
            if type(w.end) is not int or type(w.length) is not int or not 1 <= w.length <= w.end:
                raise ValueError("Invalid integer window locators")
            if rational(w.drift) < 0 or not w.drift_evidence.strip():
                raise ValueError("Declare a nonnegative drift envelope and its premise")
            if (w.end, w.length) in seen:
                raise ValueError("Duplicate catalogue entry")
            seen.add((w.end, w.length))


def estimate_catalogue(observations, catalogue, bits=80):
    precision(bits)
    if any(type(x) is not int or x not in range(4) for x in observations):
        raise ValueError("Use aligned categorical outcome indices")
    delta = rational(catalogue.delta) / len(catalogue.windows)
    results = []
    for w in catalogue.windows:
        if w.end > len(observations):
            raise ValueError("Missing rounds for a declared window")
        counts = [0] * 4
        for z in observations[w.end - w.length:w.end]:
            counts[z] += 1
        result = counts_interval(counts, delta, w.drift, bits)
        result["window"] = w
        results.append(result)
    # Infinite-width results follow all finite widths. Exact rational ties use index order.
    def order(i):
        width = results[i]["coupling_interval"].width
        return (width is None, Fraction(0) if width is None else width, i)
    selected = min(range(len(results)), key=order)
    return {"results": results, "selected_index": selected, "selected": results[selected],
            "total_failure_budget": rational(catalogue.delta) + rational(catalogue.rho)}


def decimal_endpoint(value, digits, direction):
    """Round a finite rational outward on the requested decimal grid."""
    if type(digits) is not int or not 0 <= digits <= 1000 or direction not in ('lower', 'upper'):
        raise ValueError("Invalid outward decimal format")
    if value is None:
        return '-infinity' if direction == 'lower' else '+infinity'
    value = rational(value)
    scale = 10 ** digits
    n, d = value.numerator * scale, value.denominator
    rounded = n // d if direction == 'lower' else -((-n) // d)
    sign = '-' if rounded < 0 else ''
    a = abs(rounded)
    return sign + str(a // scale) + ('.' + str(a % scale).zfill(digits) if digits else '')


def display_interval(interval, digits=6):
    return (decimal_endpoint(interval.lower, digits, 'lower'),
            decimal_endpoint(interval.upper, digits, 'upper'))
