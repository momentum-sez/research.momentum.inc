import math
import random
import unittest
from fractions import Fraction as F

from drift_estimator import Catalogue, Window, coupling, estimate_catalogue, from_counts, pooling_counterexample


def positive_fixture():
    n = 32768
    slope = 0.000002
    rng = random.Random(20260905)
    observations = []
    for s in range(1, n + 1):
        a = .4 - slope * (n - s)
        b = .1 + slope * (n - s)
        u = rng.random()
        observations.append(0 if u < a else 1 if u < a + b else 2 if u < a + 2 * b else 3)
    lengths = (512, 2048, 8192, 32768)
    cat = Catalogue(tuple(Window(n, w, slope * (w - 1) / 2,
                                     "Declared independent linear cell law, slope 2e-6") for w in lengths), .05)
    return estimate_catalogue(observations, cat)


class DriftEstimatorTests(unittest.TestCase):
    def test_exact_constant_interaction_counterexample(self):
        x = pooling_counterexample()
        self.assertEqual(x["pooled"], (F(17, 50), F(4, 25), F(4, 25), F(17, 50)))
        for p in (x["first"], x["second"]):
            self.assertEqual(p[0] * p[3], p[1] * p[2])
        self.assertEqual(x["pooled"][0] * x["pooled"][3] / (x["pooled"][1] * x["pooled"][2]), F(289, 64))
        self.assertAlmostEqual(x["pooled_coupling"], .5 * math.log(17 / 8), places=14)

    def test_lipschitz_average_drift_exact(self):
        n, slope = 10000, F(1, 1000000)
        history = [F(34, 100) + slope * s for s in range(n)]
        self.assertEqual(history[-1] - sum(history) / n, slope * (n - 1) / 2)

    def test_informative_fixed_count_witness(self):
        r = from_counts((3450, 1550, 1550, 3450), .0049995, .05)
        target = (.349999, .150001, .150001, .349999)
        truth = coupling(target)
        self.assertLess(r["coupling_interval"][0], truth)
        self.assertGreater(r["coupling_interval"][1], truth)
        self.assertGreater(r["coupling_interval"][0], 0)
        self.assertLess(abs(r["coupling"] - truth), math.atanh(r["cell_radius"] / .15))

    def test_useful_adaptive_window_selection(self):
        r = positive_fixture()
        truth = .5 * math.log(4)
        self.assertEqual(r["selected"]["window"]["length"], 8192)
        self.assertGreater(r["selected"]["coupling_interval"][0], 0)
        for candidate in r["results"]:
            self.assertLess(candidate["coupling_interval"][0], truth)
            self.assertGreater(candidate["coupling_interval"][1], truth)
        self.assertEqual(sum(x["delta"] for x in r["results"]), .05)

    def test_zero_counts_keep_uncertainty_and_boundary(self):
        r = from_counts((100, 0, 0, 0), 0, .05)
        self.assertIsNone(r["coupling"])
        self.assertEqual(r["estimate_status"], "Boundary")
        self.assertEqual(r["coupling_interval"], (-math.inf, math.inf))
        self.assertEqual(r["cell_lower"][1], 0)

    def test_large_drift_returns_distributional_uncertainty(self):
        r = from_counts((25, 25, 25, 25), 1, .05)
        self.assertEqual(r["cell_lower"], (0, 0, 0, 0))
        self.assertEqual(r["cell_upper"], (1, 1, 1, 1))
        self.assertEqual(r["coupling_interval"], (-math.inf, math.inf))

    def test_catalogue_counts_all_choices(self):
        observations = (0, 1, 2, 3) * 250
        one = Catalogue((Window(1000, 1000, 0, "Stationary fixture"),), .05)
        two = Catalogue((Window(1000, 1000, 0, "Stationary fixture"), Window(1000, 500, 0, "Stationary fixture")), .05)
        self.assertGreater(estimate_catalogue(observations, two)["results"][0]["cell_radius"],
                           estimate_catalogue(observations, one)["results"][0]["cell_radius"])
        self.assertNotEqual(one.identity, two.identity)

    def test_separate_drift_failure_budget(self):
        cat = Catalogue((Window(4, 4, .1, "Independent simultaneous envelope"),), .03, .02)
        self.assertEqual(estimate_catalogue((0, 1, 2, 3), cat)["total_failure_budget"], .05)

    def test_invalid_contracts_fail_explicitly(self):
        for window in (Window(5, 6, 0, "Law"), Window(5, 5, -.1, "Law"), Window(5, 5, 0, "")):
            with self.assertRaises(ValueError):
                Catalogue((window,), .05)
        with self.assertRaises(ValueError):
            Catalogue((Window(5, 5, 0, "Law"), Window(5, 5, 0, "Law")), .05)
        with self.assertRaises(ValueError):
            from_counts((0, 0, 0, 0), 0, .05)

    def test_missing_or_malformed_rounds_rejected(self):
        cat = Catalogue((Window(4, 4, 0, "Law"),), .05)
        for observations in ((0, 1, 2), (0, 1, 2, 4), (0, 1, 2, True)):
            with self.assertRaises(ValueError):
                estimate_catalogue(observations, cat)


if __name__ == "__main__":
    unittest.main(verbosity=2)
