"""Reproduce synthetic identification and uncertainty examples for the paper."""
from itertools import product, combinations
from pathlib import Path
import hashlib
import json
import platform
import sys
import time
import numpy as np
import scipy
from scipy.special import logsumexp
from scipy.stats import beta, norm
from scipy.optimize import linprog, minimize

SEED = 20260905
rng = np.random.default_rng(SEED)
OUT = Path(__file__).resolve().parent
acceptance_checks = []

def require(name, passed, **evidence):
    record = {'name': name, 'passed': bool(passed), **evidence}
    acceptance_checks.append(record)
    if not record['passed']:
        raise ValueError('Experiment acceptance failed: ' + name + ': ' + repr(record))

def solver_status(result, method):
    return {'method': method, 'success': bool(result.success), 'status': int(result.status),
            'message': str(result.message), 'iterations': int(result.nit)}

def states(n):
    return np.array(list(product([-1., 1.], repeat=n)))

def features(x):
    pairs = list(combinations(range(x.shape[1]), 2))
    return np.column_stack([x] + [x[:, i] * x[:, j] for i, j in pairs]), pairs

def law(x, h, j):
    energy = x @ h + np.einsum('ni,ij,nj->n', x, j, x) / 2
    return np.exp(energy - logsumexp(energy))

def pair_cells(x, p, i, j):
    return np.array([p[(x[:, i] == a) & (x[:, j] == b)].sum()
                     for a, b in [(1, 1), (1, -1), (-1, 1), (-1, -1)]])

def coupling(p):
    p = np.asarray(p)
    return np.log(p) @ np.array([1., -1., -1., 1.]) / 4

def cell_intervals(counts, delta=.05):
    counts = np.asarray(counts)
    n = counts.sum(axis=-1, keepdims=True)
    lo = np.where(counts == 0, 0., beta.ppf(delta / 8, counts, n - counts + 1))
    hi = np.where(counts == n, 1., beta.ppf(1 - delta / 8, counts + 1, n - counts))
    return lo, hi

def coupling_interval(counts, delta=.05):
    lo, hi = cell_intervals(counts, delta)
    with np.errstate(divide='ignore', invalid='ignore'):
        lower = (np.log(lo[..., 0]) + np.log(lo[..., 3]) - np.log(hi[..., 1]) - np.log(hi[..., 2])) / 4
        upper = (np.log(hi[..., 0]) + np.log(hi[..., 3]) - np.log(lo[..., 1]) - np.log(lo[..., 2])) / 4
    return lower, upper

def fit_full(x, p, support=None, *, sample):
    f, pairs = features(x)
    keep = list(range(x.shape[1])) + [x.shape[1] + k for k, e in enumerate(pairs) if support is None or e in support]
    f = f[:, keep]
    target = p @ f
    def obj(theta):
        z = f @ theta
        q = np.exp(z - logsumexp(z))
        return logsumexp(z) - theta @ target, q @ f - target
    result = minimize(obj, np.zeros(f.shape[1]), jac=True, method='BFGS', options={'gtol': 1e-11, 'maxiter': 2000})
    require('full_mle_moment_residual', np.max(np.abs(obj(result.x)[1])) < 1e-7,
            sample=sample, criterion='max_absolute_moment_residual < tolerance',
            residual=float(np.max(np.abs(obj(result.x)[1]))), tolerance=1e-7,
            solver=solver_status(result, 'BFGS'))
    return result.x, float(np.max(np.abs(obj(result.x)[1])))

def fit_pseudolikelihood(x, p, *, sample):
    n = x.shape[1]
    directed = np.zeros((n, n))
    for i in range(n):
        others = [k for k in range(n) if k != i]
        a = np.column_stack([np.ones(len(x)), x[:, others]])
        def obj(theta):
            z = a @ theta
            return p @ (np.logaddexp(z, -z) - x[:, i] * z), a.T @ (p * (np.tanh(z) - x[:, i]))
        result = minimize(obj, np.zeros(n), jac=True, method='BFGS', options={'gtol': 1e-11})
        require('pseudolikelihood_gradient_residual', np.max(np.abs(obj(result.x)[1])) < 1e-7,
                sample=sample, site=i, criterion='max_absolute_gradient_residual < tolerance',
                residual=float(np.max(np.abs(obj(result.x)[1]))), tolerance=1e-7,
                solver=solver_status(result, 'BFGS'))
        directed[i, others] = result.x[1:]
    return (directed + directed.T) / 2

def uncertainty_margin(quote, radius):
    a, b, c = quote
    ra, rb, rc = radius
    return np.array([c-rc, a-c-ra-rc, b-c-rb-rc, 1-a-b+c-ra-rb-rc])

results = {'seed': SEED, 'environment': {'python': platform.python_version(), 'numpy': np.__version__, 'scipy': scipy.__version__, 'optimization': sys.flags.optimize},
           'evidence_type': 'Synthetic experiments and exact finite-state examples. No empirical market data.'}

# The selected observation interface cannot distinguish a chain from an isolated pair.
x = states(3)
j = np.zeros((3, 3)); j[0, 2] = j[2, 0] = .4; j[1, 2] = j[2, 1] = .6
p = law(x, np.zeros(3), j)
cells = pair_cells(x, p, 0, 1); effective = coupling(cells)
j_alternative = np.zeros_like(j); j_alternative[0, 1] = j_alternative[1, 0] = effective
alternative = law(x, np.zeros(3), j_alternative)
selected_error = max(np.max(np.abs(p @ x - alternative @ x)), np.max(np.abs(cells - pair_cells(x, alternative, 0, 1))))
require('selected_interface_nonidentification', selected_error < 1e-14 and np.max(np.abs(p-alternative)) > .01,
        criterion='selected_residual < tolerance and full_law_difference > minimum_difference',
        residual=float(selected_error), tolerance=1e-14,
        full_law_difference=float(np.max(np.abs(p-alternative))), minimum_difference=.01)
full_theta, fit_residual = fit_full(x, p, sample='population')
pl = fit_pseudolikelihood(x, p, sample='population')
full_counts = rng.multinomial(5000, p)
finite_theta, _ = fit_full(x, full_counts/5000, sample='sample_5000')
finite_pl = fit_pseudolikelihood(x, full_counts/5000, sample='sample_5000')
results['identification'] = {'chain_edges': {'02': .4, '12': .6, '01': 0}, 'effective_01': float(effective),
    'selected_interface_max_error': float(selected_error), 'minimum_law_cell': float(min(p.min(),alternative.min())),
    'different_full_laws_max_cell_difference': float(np.max(np.abs(p-alternative))), 'selected_interface_status': 'Nonidentifiable',
    'full_vector_population_mle_theta': full_theta.tolist(), 'full_vector_population_mle_moment_residual': fit_residual,
    'full_vector_population_pseudolikelihood_01': float(pl[0,1]), 'finite_independent_rounds': 5000,
    'finite_full_mle_01': float(finite_theta[3]), 'finite_pseudolikelihood_01': float(finite_pl[0,1]),
    'no_parlay_quote': {'quote_estimate': None, 'aligned_outcome_rounds': 5000, 'outcome_estimate_effective': float(coupling(pair_cells(x,full_counts/5000,0,1)))}}

# Complete conjunction moments reconstruct every positive three-spin table.
p_saturated = np.array([.04, .08, .12, .10, .16, .14, .18, .18])
sets = [tuple(i for i in range(3) if mask >> i & 1) for mask in range(8)]
u = {a: float(p_saturated[np.all(x[:, a] == 1, axis=1)].sum()) if a else 1. for a in sets}
reconstructed=[]
for spin in x:
    a = set(np.flatnonzero(spin == 1)); remaining = set(range(3))-a
    val=0.
    for b in sets:
        if set(b) <= remaining:
            val += (-1)**len(b)*u[tuple(sorted(a | set(b)))]
    reconstructed.append(val)
reconstructed=np.array(reconstructed)
walsh = {a: float(np.log(p_saturated) @ np.prod(x[:,a],axis=1) / 8) for a in sets if a}
logfit = np.full(8, np.log(p_saturated).mean())
for a, coefficient in walsh.items(): logfit += coefficient*np.prod(x[:,a],axis=1)
require('saturated_reconstruction', np.max(np.abs(reconstructed-p_saturated))<1e-14,
        criterion='max_absolute_cell_residual < tolerance',
        residual=float(np.max(np.abs(reconstructed-p_saturated))), tolerance=1e-14)
results['saturated_reconstruction']={'cells':p_saturated.tolist(),'conjunction_moments':{str(a):v for a,v in u.items()},
    'max_cell_error':float(np.max(np.abs(reconstructed-p_saturated))), 'max_log_cell_error':float(np.max(np.abs(logfit-np.log(p_saturated))))}

# Pairwise feasible three-spin correlations violate a global facet.
f, pairs = features(x)
target=np.array([0.,0.,0.,-.9,-.9,-.9])
eq=np.vstack([np.ones(8), f.T]); rhs=np.r_[1.,target]
feasible=linprog(np.zeros(8),A_eq=eq,b_eq=rhs,bounds=(0,None),method='highs')
require('global_infeasibility', not feasible.success and feasible.status == 2,
        criterion='solver_success is false and solver_status == 2',
        solver=solver_status(feasible, 'highs'))
# Minimize t subject to an explicit probability law and coordinate residual <= t.
a_ub=np.vstack([np.c_[f.T,-np.ones(6)],np.c_[-f.T,-np.ones(6)]])
b_ub=np.r_[target,-target]
projected=linprog(np.r_[np.zeros(8),1.],A_ub=a_ub,b_ub=b_ub,A_eq=np.array([np.r_[np.ones(8),0.]]),b_eq=[1.],bounds=[(0,None)]*9,method='highs')
require('global_projection', projected.success and abs(projected.fun-17/30)<1e-12,
        criterion='solver_success and absolute_objective_residual < tolerance',
        residual=None if projected.fun is None else float(abs(projected.fun-17/30)),
        objective=None if projected.fun is None else float(projected.fun),
        expected_objective=17/30, tolerance=1e-12, solver=solver_status(projected, 'highs'))
results['global_feasibility']={'pair_cells':[.025,.475,.475,.025], 'status':'Infeasible',
    'facet_correlation_sum':-2.7,'facet_lower_bound':-1.,'minimum_linf_moment_projection_residual':float(projected.fun),
    'projected_law':projected.x[:8].tolist(),'projected_moments':(projected.x[:8]@f).tolist(),
    'arithmetic_tolerance':1e-12,'scope':'Exact enumerated marginal polytope, floating-point linear programming with analytical residual certificate.'}

# Quote uncertainty requires each affine cell constraint over the full box.
quote=[.6,.5,.3]
margin=uncertainty_margin(quote,[.01,.02,.01])
corner_cells=[]
for sign in product([-1,1],repeat=3):
    a,b,c=np.array(quote)+np.array(sign)*[.01,.02,.01]
    corner_cells.append([c,a-c,b-c,1-a-b+c])
require('quote_box_corner_minima', np.allclose(margin,np.min(corner_cells,axis=0)),
        criterion='absolute_cell_residual <= absolute_tolerance + relative_tolerance * absolute_corner_minimum',
        residual=float(np.max(np.abs(margin-np.min(corner_cells,axis=0)))),
        absolute_tolerance=1e-8, relative_tolerance=1e-5)
negative=uncertainty_margin([.2,.3,.02],[.03,.03,.03])
require('quote_box_boundary_crossing', min(negative)<0,
        criterion='minimum_cell_lower_bound < 0', minimum_cell_lower_bound=float(min(negative)))
results['quote_uncertainty']={'positive_quote':quote,'radii':[.01,.02,.01],'cell_lower_bounds':margin.tolist(),
    'kappa':float(min(margin)),'corner_check_error':float(np.max(np.abs(margin-np.min(corner_cells,axis=0)))),
    'crossing_quote':[.2,.3,.04],'crossing_radius':.03,'crossing_margin':float(min(negative))}
# A second fixture crosses the ++ facet although its center is interior.
results['quote_uncertainty']['crossing_quote']=[.2,.3,.02]
results['quote_uncertainty']['crossing_margin']=float(min(uncertainty_margin([.2,.3,.02],[.03]*3)))

# Simultaneous exact binomial intervals work at zero empirical cells.
zero_counts=np.array([0,20,30,50]); zero_lo,zero_hi=coupling_interval(zero_counts)
results['boundary']={'cells':[0,.2,.3,.5],'moments':[-.6,-.4,0.], 'status':'Boundary',
    'counts':zero_counts.tolist(),'unregularized_mle':None,'regularized_alpha':.5,
    'regularized_estimate':float(coupling((zero_counts+.5)/(100+2))),
    'confidence_lower':None if not np.isfinite(zero_lo) else float(zero_lo), 'confidence_upper':float(zero_hi),
    'nonfinite_endpoint_meaning':'The lower endpoint is unbounded. The regularized estimate is separate from the confidence set.'}

# Repeated synthetic samples separate coverage, precision and data horizon.
pair_truth=np.array([.45,.20,.20,.15]); true_j=coupling(pair_truth)
replicates=2000; coverage=[]
for n in [104,520,2600,5000]:
    counts=rng.multinomial(n,pair_truth,size=replicates)
    positive=np.all(counts>0,axis=1)
    lower,upper=coupling_interval(counts)
    with np.errstate(divide='ignore',invalid='ignore'):
        mle=np.log(counts/n)@np.array([1.,-1.,-1.,1.])/4
        se=np.sqrt(np.sum(1/counts,axis=1)/16)
    regularized=(counts+.5)/(n+2)
    shrunk=np.log(regularized)@np.array([1.,-1.,-1.,1.])/4
    finite= np.isfinite(lower)&np.isfinite(upper)
    coverage.append({'n':n,'replicates':replicates,'positive_count_fraction':float(positive.mean()),
        'cell_interval_coverage':float(np.mean((lower<=true_j)&(true_j<=upper))),
        'wald_coverage_all_replicates':float(np.mean(positive&(mle-1.96*se<=true_j)&(true_j<=mle+1.96*se))),
        'regularized_rmse':float(np.sqrt(np.mean((shrunk-true_j)**2))),
        'mle_rmse_conditional_positive_counts':float(np.sqrt(np.mean((mle[positive]-true_j)**2))),
        'median_interval_width_finite':float(np.median((upper-lower)[finite])),
        'positive_sign_certification_fraction':float(np.mean(lower>0)),
        'test_cross_entropy':float(np.mean(-np.log(regularized)@pair_truth)),
        'test_entropy_truth':float(-np.log(pair_truth)@pair_truth)})
results['sampling']={'truth_cells':pair_truth.tolist(),'true_effective_coupling':float(true_j),
    'confidence_level':.95,'rows':coverage,'weekly_rounds_per_year':52,'independent_rounds_75000_years':75000/52,
    'pooling_example':'Five mutually independent strata with the identical pair law supply 2600 rounds from 520 rounds each. Exchangeability alone does not establish independence.',
    'positive_counts_witness':[2250,1000,1000,750], 'positive_witness_interval':[float(v) for v in coupling_interval(np.array([2250,1000,1000,750]))]}

# Known variance allocation has a closed-form optimum.
a=np.array([1.,4.,9.]); total=600.; allocation=total*np.sqrt(a)/np.sqrt(a).sum()
results['allocation']={'a':a.tolist(),'budget':total,'optimal_counts':allocation.tolist(),
    'optimal_objective':float(np.sum(a/allocation)),'equal_objective':float(np.sum(a/(total/3))),
    'kkt_multiplier_values':(a/allocation**2).tolist()}

# Exact small-state checks for the Dobrushin susceptibility bound.
environment_rows=[]
for n, strength in [(3,.12),(5,.18),(6,.12)]:
    env_x=states(n); env_j=np.zeros((n,n))
    for i in range(n):
        k=(i+1)%n; env_j[i,k]=env_j[k,i]=strength
    env_h=np.linspace(-.2,.2,n); env_p=law(env_x,env_h,env_j)
    mean=env_p@env_x; covariance=env_x.T@(env_p[:,None]*env_x)-np.outer(mean,mean)
    influence=np.tanh(np.abs(env_j)); q=float(np.max(influence.sum(axis=1)))
    bound=q/(1-q); measured=float(np.max(np.sum(np.abs(covariance),axis=1)-np.diag(covariance)))
    require('environmental_susceptibility', measured<=bound+1e-12,
            sites=n, criterion='measured <= bound + tolerance', measured=measured, bound=bound,
            residual=measured-bound, tolerance=1e-12)
    environment_rows.append({'sites':n,'coupling':strength,'q':q,'chi_env':measured,'certified_bound':bound})
results['environmental_susceptibility']=environment_rows

# Inference methods use one known six-spin tree and the same contract universe.
x6=states(6); h=np.array([.15,-.1,.2,-.15,.1,-.05]); j6=np.zeros((6,6))
for i, value in enumerate([.22,-.18,.20,.16,-.21]): j6[i,i+1]=j6[i+1,i]=value
truth=law(x6,h,j6); true_m=truth@x6
single=[np.array([truth[x6[:,i]==a].sum() for a in [-1,1]]) for i in range(6)]
tree=np.ones(len(x6))
for i in range(5):
    pc=pair_cells(x6,truth,i,i+1)
    mapping={(1,1):pc[0],(1,-1):pc[1],(-1,1):pc[2],(-1,-1):pc[3]}
    tree*=np.array([mapping[tuple(row[[i,i+1]])] for row in x6])
for i in range(1,5): tree/=np.array([single[i][int(row[i]==1)] for row in x6])
require('known_tree_reconstruction', np.max(np.abs(tree-truth))<1e-14,
        criterion='max_absolute_cell_residual < tolerance',
        residual=float(np.max(np.abs(tree-truth))), tolerance=1e-14)
mf=np.zeros(6); iterations=0
while True:
    new=np.tanh(h+j6@mf); iterations+=1
    if np.max(np.abs(new-mf))<1e-12: mf=new; break
    mf=new
independent=np.prod((1+x6*true_m)/2,axis=1)
mf_law=np.prod((1+x6*mf)/2,axis=1)
f6,_=features(x6)
bench=[]
for name,q in [('Exact enumeration',truth),('Known-tree reconstruction',tree),('Independent matched marginals',independent),('Mean-field product',mf_law)]:
    start=time.perf_counter()
    for _ in range(1000): q@f6
    elapsed=(time.perf_counter()-start)/1000
    bench.append({'method':name,'normalization_error':float(abs(q.sum()-1)),
        'max_singleton_mean_error':float(np.max(np.abs(q@x6-true_m))),
        'max_pair_mean_error':float(np.max(np.abs((q-truth)@f6[:,6:]))),
        'expected_log_loss':float(-truth@np.log(q)),'marginal_evaluation_microseconds':elapsed*1e6})
results['inference_benchmark']={'sites':6,'states':64,'known_parameters':True,'same_contract_universe':'All 6 singleton and 15 pair features',
    'mean_field_iterations':iterations,'r':float(np.max(np.abs(j6).sum(axis=1))),'rows':bench,
    'timing_scope':'Mean computation for a supplied 64-cell law, 1000 repetitions. Excludes learning and law construction. Local timing only.'}

# A common exact cost-function experiment separates coherence from maker loss.
b=10.; trades=np.zeros(64); revenue={name:0. for name in ['Uniform','Independent','Ising']}
priors={'Uniform':np.ones(64)/64,'Independent':independent,'Ising':truth}
path=[(int(rng.integers(64)),float(rng.choice([.5,1.,2.]))) for _ in range(100)]
for state,volume in path:
    new=trades.copy(); new[state]+=volume
    for name,prior in priors.items():
        revenue[name]+=b*(logsumexp(np.log(prior)+new/b)-logsumexp(np.log(prior)+trades/b))
    trades=new
results['maker_loss']={'liquidity':b,'trade_count':100,'same_path_sha256':hashlib.sha256(json.dumps(path).encode()).hexdigest(),
    'contract_universe':'64 complete outcome contracts, no fees, unit settlement payout',
    'rows':[{'prior':name,'worst_realized_loss_on_path':float(trades.max()-revenue[name]),
        'all_inventory_worst_case_bound':float(b*np.log(1/prior.min())),
        'expected_profit_under_synthetic_truth':float(revenue[name]-truth@trades)} for name,prior in priors.items()],
    'scope':'An exact common LMSR baseline, not a reproduction of ParlayMarket or APMM mechanisms.'}

results['acceptance_checks'] = acceptance_checks
(OUT/'experiment-results.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
print(json.dumps(results,indent=2,allow_nan=False))
