"""Finite-window calculations for a declared four-cell sampling contract.

Floating-point outputs illustrate the analytic enclosures in the manuscript.
They are not certified interval arithmetic or evidence for a drift premise.
"""

from dataclasses import asdict, dataclass
from fractions import Fraction
import hashlib
import json
import math


@dataclass(frozen=True)
class Window:
    end: int
    length: int
    drift: float
    drift_evidence: str


@dataclass(frozen=True)
class Catalogue:
    windows: tuple[Window, ...]
    delta: float
    rho: float = 0.0

    def __post_init__(self):
        if not isinstance(self.windows, tuple) or not self.windows:
            raise ValueError("Declare a nonempty immutable window catalogue")
        if not 0 < self.delta < 1 or not 0 <= self.rho < 1 - self.delta:
            raise ValueError("Require delta > 0, rho >= 0, and delta + rho < 1")
        seen = set()
        for w in self.windows:
            if type(w.end) is not int or type(w.length) is not int:
                raise ValueError("Window locators must be integers")
            if not 1 <= w.length <= w.end:
                raise ValueError("Require 1 <= window length <= end")
            if not math.isfinite(w.drift) or w.drift < 0:
                raise ValueError("Require a finite nonnegative drift envelope")
            if not w.drift_evidence.strip():
                raise ValueError("Name the drift premise or its evidence")
            if (w.end, w.length) in seen:
                raise ValueError("Duplicate catalogue entry")
            seen.add((w.end, w.length))

    @property
    def identity(self):
        return hashlib.sha256(json.dumps(asdict(self), sort_keys=True).encode()).hexdigest()


def coupling(p):
    if len(p) != 4 or any(v <= 0 for v in p):
        raise ValueError("A finite coupling requires four positive cells")
    return 0.25 * sum(sign * math.log(float(v)) for sign, v in zip((1, -1, -1, 1), p))


def from_counts(counts, drift, delta):
    if len(counts) != 4 or any(type(k) is not int or k < 0 for k in counts):
        raise ValueError("Require four nonnegative integer counts")
    n = sum(counts)
    if n <= 0 or not 0 < delta < 1 or not math.isfinite(drift) or drift < 0:
        raise ValueError("Invalid count, drift, or failure budget")
    p = tuple(k / n for k in counts)
    stochastic = math.sqrt(math.log(8 / delta) / (2 * n))
    eta = stochastic + drift
    lower = tuple(max(0.0, q - eta) for q in p)
    upper = tuple(min(1.0, q + eta) for q in p)
    jlo = (-math.inf if lower[0] * lower[3] == 0 else
           0.25 * (math.log(lower[0]) + math.log(lower[3]) - math.log(upper[1]) - math.log(upper[2])))
    jhi = (math.inf if lower[1] * lower[2] == 0 else
           0.25 * (math.log(upper[0]) + math.log(upper[3]) - math.log(lower[1]) - math.log(lower[2])))
    return {
        "counts": tuple(counts), "rounds": n, "empirical": p,
        "stochastic_radius": stochastic, "drift_radius": drift, "cell_radius": eta,
        "cell_lower": lower, "cell_upper": upper, "coupling_interval": (jlo, jhi),
        "coupling": coupling(p) if min(counts) > 0 else None,
        "estimate_status": "Interior" if min(counts) > 0 else "Boundary",
        "delta": delta,
    }


def estimate_catalogue(observations, catalogue):
    if any(type(z) is not int or z not in range(4) for z in observations):
        raise ValueError("Each aligned outcome must identify one cell")
    budget = catalogue.delta / len(catalogue.windows)
    results = []
    for w in catalogue.windows:
        if w.end > len(observations):
            raise ValueError("Missing rounds for a declared window")
        counts = [0] * 4
        for z in observations[w.end - w.length:w.end]:
            counts[z] += 1
        r = from_counts(counts, w.drift, budget)
        r.update({"window": asdict(w), "catalogue": catalogue.identity})
        results.append(r)
    best = min(range(len(results)), key=lambda i: (
        results[i]["coupling_interval"][1] - results[i]["coupling_interval"][0], i))
    return {"catalogue": catalogue.identity, "total_failure_budget": catalogue.delta + catalogue.rho,
            "results": results, "selected_index": best, "selected": results[best]}


def independent_pair(a, b):
    return (a * b, a * (1 - b), (1 - a) * b, (1 - a) * (1 - b))


def pooling_counterexample():
    first = independent_pair(Fraction(4, 5), Fraction(4, 5))
    second = independent_pair(Fraction(1, 5), Fraction(1, 5))
    pooled = tuple((a + b) / 2 for a, b in zip(first, second))
    return {"first": first, "second": second, "pooled": pooled,
            "regime_couplings": (coupling(first), coupling(second)),
            "pooled_coupling": coupling(pooled)}
