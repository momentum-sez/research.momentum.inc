"""Exact finite market ledgers with separate pricing and issued positions."""
from copy import deepcopy
from itertools import combinations, product
from pathlib import Path
import json
import math

import numpy as np
from scipy.special import logsumexp


def subsets(n):
    return [s for k in range(1, n + 1) for s in combinations(range(n), k)]


def marginal(p, states, s):
    index = states[:, s] @ (2 ** np.arange(len(s) - 1, -1, -1))
    return np.bincount(index, weights=p, minlength=2 ** len(s))


def binary_purchase(q, target, b):
    if not 0 < q < 1 or not 0 < target < 1:
        raise ValueError("The quote and target must lie strictly between zero and one.")
    d = b * (math.log(target / (1 - target)) - math.log(q / (1 - q)))
    h = np.array([max(-d, 0.0), max(d, 0.0)])
    premium = b * logsumexp(np.log([1 - q, q]) + h / b)
    return h, float(premium)


class Ledger:
    def __init__(self, prior, b=10.0, capital=100.0, fee_rate=0.0):
        self.prior = np.asarray(prior, dtype=float)
        self.n = int(round(math.log2(len(prior))))
        if len(prior) != 2 ** self.n or np.min(prior) <= 0:
            raise ValueError("The prior must be a positive binary outcome law.")
        if abs(sum(prior) - 1) > 1e-12:
            raise ValueError("The prior must sum to one.")
        self.states = np.array(list(product([0, 1], repeat=self.n)))
        self.b, self.capital, self.fee_rate = b, capital, fee_rate
        self.cash = capital
        self.premiums = self.fees = 0.0
        self.issued = np.zeros(len(prior))
        self.rows = []

    def execute(self, event, target, budget=100.0):
        proposed, trade = self.plan(event, target)
        return self._execute_plan(event, target, budget, proposed, trade)

    def _execute_plan(self, event, target, budget, proposed, trade):
        before = self.diagnostic()
        premium = trade['premium']
        fee = self.fee_rate * premium
        issue = np.asarray(trade['issued_payoff'])
        reason = None
        if premium + fee > budget + 1e-10:
            reason = 'trader_budget'
        elif np.max(self.issued + issue) > self.cash + premium + fee + 1e-10:
            reason = 'maker_capital'
        row = {
            'arrival': len(self.rows), 'event': event, 'target': target,
            'trader_budget': budget, 'accepted': reason is None, 'reason': reason,
            'quote_before': before, 'quoted_trade': trade,
            'quoted_fee': fee,
        }
        if reason is None:
            self.commit(proposed)
            self.cash += premium + fee
            self.premiums += premium
            self.fees += fee
            self.issued += issue
        row.update({
            'actual_premium': premium if reason is None else 0.0,
            'actual_fee': fee if reason is None else 0.0,
            'actual_issued_payoff': issue.tolist() if reason is None else [0.0] * len(issue),
            'quote_after': self.diagnostic(), 'cash_after': self.cash,
            'issued_payoff_after': self.issued.tolist(),
            'minimum_settlement_cash': float(np.min(self.cash - self.issued)),
        })
        self.rows.append(row)
        return row

    def settlement(self, truth):
        loss = self.issued - self.premiums - self.fees
        return {
            'outcomes': self.states.tolist(),
            'issued_payoff': self.issued.tolist(),
            'collected_premiums': self.premiums, 'collected_fees': self.fees,
            'maker_loss_by_outcome': loss.tolist(),
            'trader_profit_by_outcome': loss.tolist(),
            'maker_terminal_cash': (self.capital - loss).tolist(),
            'expected_maker_loss': float(np.asarray(truth) @ loss),
            'maximum_maker_loss': float(max(loss)),
            'required_reserve_on_path': float(max([0.0] + [self.capital - r['minimum_settlement_cash'] for r in self.rows])),
            'cash_identity_error': float(abs(self.cash - self.capital - self.premiums - self.fees)),
        }

    def diagnostic(self):
        joint = self.joint()
        return {'joint': joint.tolist(), 'singleton_quotes': (joint @ self.states).tolist(),
                'joint_singletons': (joint @ self.states).tolist(), 'book_disagreement': 0.0}


class ParlayMarket(Ledger):
    name = 'ParlayMarket_target_replay'

    def __init__(self, prior, eta=0.2, **kwargs):
        super().__init__(prior, **kwargs)
        self.features = np.column_stack([
            np.prod(self.states[:, s], axis=1)
            for s in subsets(self.n) if len(s) <= 2
        ])
        design = np.column_stack([np.ones(len(prior)), self.features])
        fit = np.linalg.lstsq(design, np.log(prior), rcond=None)[0]
        if np.max(np.abs(design @ fit - np.log(prior))) > 1e-10:
            raise ValueError("The prior must belong to the pairwise family.")
        self.theta, self.eta = fit[1:], eta

    def joint(self):
        scores = self.features @ self.theta
        return np.exp(scores - logsumexp(scores))

    def plan(self, event, target):
        p = self.joint()
        indicator = self.states[:, event]
        q = float(p @ indicator)
        h, premium = binary_purchase(q, target, self.b)
        covariance = self.features.T @ (p * indicator) - (p @ self.features) * q
        gradient = (q - target) / (q * (1 - q)) * covariance
        theta = self.theta - self.eta * gradient
        return theta, {'premium': premium, 'issued_payoff': h[indicator].tolist(),
                       'binary_issued_no_yes': h.tolist(), 'pretrade_probability': q,
                       'gradient': gradient.tolist(), 'learning_rate': self.eta,
                       'shadow_cash': 0.0, 'shadow_issued_payoff': [0.0] * len(p),
                       'subtrades': 1}

    def commit(self, proposed):
        self.theta = proposed


class JointLMSR(Ledger):
    name = 'exact_joint_LMSR'

    def __init__(self, prior, **kwargs):
        super().__init__(prior, **kwargs)
        self.inventory = np.zeros(len(prior))

    def joint(self):
        z = np.log(self.prior) + self.inventory / self.b
        return np.exp(z - logsumexp(z))

    def plan(self, event, target):
        q = float(self.joint() @ self.states[:, event])
        h, premium = binary_purchase(q, target, self.b)
        issue = h[self.states[:, event]]
        return self.inventory + issue, {'premium': premium, 'issued_payoff': issue.tolist(),
                                       'binary_issued_no_yes': h.tolist(), 'subtrades': 1}

    def commit(self, proposed):
        self.inventory = proposed


class APMM(Ledger):
    name = 'APMM_hierarchical_LMSR'

    def __init__(self, prior, **kwargs):
        super().__init__(prior, **kwargs)
        self.books = subsets(self.n)
        self.blocks = {}
        for s in self.books:
            self.blocks[s] = self.b * np.log(marginal(self.prior, self.states, s)) - self.lower(self.blocks, s)

    @staticmethod
    def pattern_index(states, s):
        return states[:, s] @ (2 ** np.arange(len(s) - 1, -1, -1))

    def lower(self, blocks, s):
        states = np.array(list(product([0, 1], repeat=len(s))))
        q = np.zeros(len(states))
        for t, block in blocks.items():
            if len(t) < len(s) and set(t).issubset(s):
                q += block[self.pattern_index(states, tuple(s.index(i) for i in t))]
        return q

    def aggregate(self, blocks, s):
        return blocks[s] + self.lower(blocks, s)

    def probabilities(self, blocks, s):
        q = self.aggregate(blocks, s) / self.b
        return np.exp(q - logsumexp(q))

    def joint(self):
        return self.probabilities(self.blocks, tuple(range(self.n)))

    def diagnostic(self):
        result = super().diagnostic()
        quotes = [self.probabilities(self.blocks, (i,))[1] for i in range(self.n)]
        result['singleton_quotes'] = [float(x) for x in quotes]
        result['book_disagreement'] = float(max(abs(np.array(quotes) - np.array(result['joint_singletons']))))
        result['book_probabilities'] = {','.join(map(str, s)): self.probabilities(self.blocks, s).tolist() for s in self.books}
        return result

    def plan(self, event, target):
        return self.plan_full((event,), np.array([1 - target, target]))

    def plan_full(self, s, target):
        target = np.asarray(target, dtype=float)
        if len(target) != 2 ** len(s) or min(target) <= 0 or abs(sum(target) - 1) > 1e-12:
            raise ValueError("The target must be a positive probability table on its leg set.")
        blocks = deepcopy(self.blocks)
        local_states = np.array(list(product([0, 1], repeat=len(s))))
        total = np.zeros(len(self.prior))
        premium = 0.0
        records = []
        for t in self.books:
            if not set(t).issubset(s):
                continue
            tau = marginal(target, local_states, tuple(s.index(i) for i in t))
            before = self.aggregate(blocks, t)
            proposed_block = self.b * np.log(tau) - self.lower(blocks, t)
            change = proposed_block - blocks[t]
            h = change - min(change)
            charge = float(self.b * (logsumexp((before + h) / self.b) - logsumexp(before / self.b)))
            blocks[t] += h
            issued = h[self.pattern_index(self.states, t)]
            premium += charge
            total += issued
            records.append({'book': list(t), 'issued_by_book_outcome': h.tolist(),
                            'premium': charge, 'issued_payoff': issued.tolist(),
                            'quote_before': np.exp(before / self.b - logsumexp(before / self.b)).tolist(),
                            'quote_after': self.probabilities(blocks, t).tolist(),
                            'propagated_books': [list(u) for u in self.books if set(t) < set(u)],
                            'propagation_premium': 0.0, 'propagation_issued_payoff': [0.0] * len(total)})
        return blocks, {'premium': premium, 'issued_payoff': total.tolist(),
                        'subtrades': records}

    def execute_full(self, s, target, budget=100.0):
        proposed, trade = self.plan_full(s, target)
        return self._execute_plan(list(s), list(target), budget, proposed, trade)

    def commit(self, proposed):
        self.blocks = proposed


def run_fixture(name, prior, truth, arrivals):
    rows = []
    truth = np.array(truth)
    for cls in (JointLMSR, ParlayMarket, APMM):
        market = cls(prior)
        initial = market.diagnostic()
        for event, target in arrivals:
            market.execute(event, target)
        end = market.diagnostic()
        true_singletons = truth @ market.states
        rows.append({'mechanism': market.name, 'initial': initial, 'final': end,
                     'initial_max_singleton_error': float(max(abs(np.array(initial['singleton_quotes']) - true_singletons))),
                     'final_max_singleton_error': float(max(abs(np.array(end['singleton_quotes']) - true_singletons))),
                     'final_joint_kl': float(truth @ np.log(truth / np.array(end['joint']))),
                     'max_book_disagreement': max(r['quote_after']['book_disagreement'] for r in market.rows),
                     'accepted': sum(r['accepted'] for r in market.rows),
                     'ledger': market.rows, 'settlement': market.settlement(truth)})
    return {'name': name, 'prior': prior, 'settlement_law': truth.tolist(),
            'arrivals': [{'event': e, 'target': t, 'budget': 100.0} for e, t in arrivals],
            'mechanisms': rows}


def main():
    fixtures = [
        run_fixture('informative_independent', [.25] * 4, [.06, .14, .24, .56], [(0, .8), (1, .7)] * 30),
        run_fixture('correlated_information', [.4, .1, .1, .4], [.16, .04, .16, .64], [(0, .8), (1, .68)]),
        run_fixture('repeated_information', [.4, .1, .1, .4], [.16, .04, .16, .64], [(0, .8), (1, .68)] * 4),
    ]
    pair = APMM([.25] * 4)
    pair.execute_full((0, 1), [.16, .04, .16, .64])
    result = {'contract': {
        'outcome_order': ['00', '01', '10', '11'],
        'executed_contracts': ['A', 'not A', 'B', 'not B'],
        'arrival_interface': 'One singleton Bernoulli target per arrival, in the recorded order.',
        'liquidity_b': 10.0, 'maker_initial_cash': 100.0,
        'trader_budget_per_arrival': 100.0, 'fee_rate_on_premium': 0.0,
        'payout_per_winning_share': 1.0, 'settlement': 'Enumerate all four outcomes under each declared synthetic law.',
        'capital_admission': 'After each accepted trade, cash covers issued payouts at every outcome.',
        'buy_gauge': 'Subtract the minimum own-book share differential.',
        'PM_learning': 'One exact pretrade expectation gradient step, eta=0.2. Internal shadow resets issue no claims and move no cash.',
        'PM_execution_binding': 'ParlayMarket v3 Appendix E.4 specifies a target-moving binary LMSR bundle, cost-difference revenue, then the equation 13 update and shadow trades. This target-replay realization chooses the minimum buy-only gauge and exact inference. Its reported losses belong to this declared realization.',
        'APMM_propagation': 'Propagate stored lower-order blocks into higher quotes without premium or issued holdings.',
        'APMM_execution_binding': 'APMM v2 equations 7-10 and section 3.3 determine aggregate inventory, own-book cost differences and bottom-up buy-only routing. Full-pair requests charge each current own block once after lower-order propagation.',
        'common_execution_controls': 'Budget and capital admission are supplied experimental controls. Fees are zero in the matched runs. All matched requests pass admission.',
        'scope': 'Native common singleton arrival interface. Pair-book quotes are diagnostics. No matched pair-execution or empirical market ranking.'
    }, 'fixtures': fixtures, 'apmm_full_pair_accounting': {
        'scope': 'Full pair target, three real bottom-up sub-trades, atomic admission. Separate from the matched singleton comparison.',
        'initial_prior': [.25] * 4, 'target_and_settlement_law': [.16, .04, .16, .64],
        'ledger': pair.rows, 'settlement': pair.settlement([.16, .04, .16, .64])}}
    Path('market-ledger-results.json').write_text(json.dumps(result, indent=2) + '\n')
    for fixture in fixtures:
        print(fixture['name'])
        for row in fixture['mechanisms']:
            settlement = row['settlement']
            print(row['mechanism'], row['accepted'], 'error', row['final_max_singleton_error'],
                  'gap', row['max_book_disagreement'], 'loss', settlement['expected_maker_loss'], settlement['maximum_maker_loss'])


if __name__ == '__main__':
    main()
