"""Check cash, claims, propagation, common inputs, and finite loss witnesses."""
import math
import unittest

import numpy as np
from scipy.special import logsumexp

from market_ledgers import APMM, JointLMSR, ParlayMarket, binary_purchase, run_fixture


CLASSES = (APMM, JointLMSR, ParlayMarket)
PRIOR = [.4, .1, .1, .4]
TRUTH = [.16, .04, .16, .64]


class AccountingTests(unittest.TestCase):
    def test_binary_purchase_and_uniform_gauge(self):
        for q, target in [(.5, .8), (.7, .2), (.1, .9)]:
            h, premium = binary_purchase(q, target, 10)
            price = np.array([1 - q, q]) * np.exp(h / 10)
            self.assertAlmostEqual(price[1] / sum(price), target)
            for k in [0, 3, 10]:
                charge = 10 * logsumexp(np.log([1 - q, q]) + (h + k) / 10)
                np.testing.assert_allclose(h + k - charge, h - premium, atol=1e-12)

    def test_single_trade_entropy_loss_identity(self):
        target = .8
        expected = 10 * (target * math.log(target / .5) + (1 - target) * math.log((1 - target) / .5))
        for cls in CLASSES:
            market = cls(PRIOR)
            market.execute(0, target)
            self.assertAlmostEqual(market.settlement(TRUTH)['expected_maker_loss'], expected)

    def test_fee_and_counterparty_conservation(self):
        for cls in CLASSES:
            plain, fee = cls(PRIOR), cls(PRIOR, fee_rate=.01)
            for event, target in [(0, .8), (1, .68), (0, .3)]:
                plain.execute(event, target)
                fee.execute(event, target)
            np.testing.assert_allclose(plain.issued, fee.issued)
            self.assertAlmostEqual(fee.fees, .01 * fee.premiums)
            np.testing.assert_allclose(np.array(plain.settlement(TRUTH)['maker_loss_by_outcome']) - fee.fees,
                                       fee.settlement(TRUTH)['maker_loss_by_outcome'])
            result = fee.settlement(TRUTH)
            for trader, maker in zip(result['trader_profit_by_outcome'], result['maker_terminal_cash']):
                self.assertAlmostEqual(trader + maker, fee.capital)

    def test_budget_rejection_is_atomic(self):
        for cls in CLASSES:
            market = cls(PRIOR)
            before = market.diagnostic()
            row = market.execute(0, .8, budget=.01)
            self.assertEqual(row['reason'], 'trader_budget')
            self.assertEqual(before, market.diagnostic())
            np.testing.assert_array_equal(market.issued, np.zeros(4))
            self.assertEqual(market.cash, market.capital)

    def test_capital_rejection_is_atomic(self):
        for cls in CLASSES:
            market = cls(PRIOR, capital=.01)
            before = market.diagnostic()
            row = market.execute(0, .8)
            self.assertEqual(row['reason'], 'maker_capital')
            self.assertEqual(before, market.diagnostic())
            self.assertEqual(row['actual_premium'], 0)
            self.assertEqual(market.cash, .01)

    def test_pm_gradient_uses_pretrade_law(self):
        market = ParlayMarket(PRIOR)
        theta = market.theta.copy()
        q = market.joint() @ market.states[:, 0]
        step, trade = market.plan(0, .8)
        numeric = []
        for j in range(len(theta)):
            losses = []
            for sign in [1, -1]:
                market.theta = theta.copy()
                market.theta[j] += sign * 1e-6
                u = market.joint() @ market.states[:, 0]
                losses.append(-.8 * math.log(u) - .2 * math.log(1 - u))
            numeric.append((losses[0] - losses[1]) / 2e-6)
        market.theta = theta
        np.testing.assert_allclose(trade['gradient'], numeric, atol=2e-9)
        np.testing.assert_allclose(step, theta - .2 * np.array(numeric), atol=2e-9)
        self.assertAlmostEqual(trade['pretrade_probability'], q)

    def test_pm_shadow_repricing_creates_no_cash_or_holdings(self):
        market = ParlayMarket(PRIOR)
        row = market.execute(0, .8)
        h, cash = binary_purchase(.5, .8, 10)
        np.testing.assert_allclose(market.issued, h[market.states[:, 0]], atol=1e-12)
        self.assertAlmostEqual(market.cash, 100 + cash)
        self.assertNotAlmostEqual(row['quote_after']['singleton_quotes'][0], .8)
        self.assertEqual(row['quoted_trade']['shadow_cash'], 0)
        self.assertEqual(sum(row['quoted_trade']['shadow_issued_payoff']), 0)

    def test_apmm_propagation_separates_internal_inventory(self):
        market = APMM(PRIOR)
        row = market.execute(0, .8)
        np.testing.assert_allclose(market.joint(), TRUTH, atol=1e-12)
        self.assertAlmostEqual(market.diagnostic()['book_disagreement'], .18)
        h, cash = binary_purchase(.5, .8, 10)
        np.testing.assert_allclose(market.issued, h[market.states[:, 0]], atol=1e-12)
        self.assertAlmostEqual(market.premiums, cash)
        trade = row['quoted_trade']['subtrades'][0]
        self.assertEqual(trade['propagated_books'], [[0, 1]])
        self.assertEqual(trade['propagation_premium'], 0)

    def test_apmm_full_pair_charges_each_current_own_block(self):
        market = APMM([.25] * 4)
        row = market.execute_full((0, 1), TRUTH)
        self.assertTrue(row['accepted'])
        trade = row['quoted_trade']
        np.testing.assert_allclose(market.joint(), TRUTH, atol=1e-12)
        np.testing.assert_allclose(market.diagnostic()['singleton_quotes'], [.8, .68], atol=1e-12)
        self.assertEqual([r['book'] for r in trade['subtrades']], [[0], [1], [0, 1]])
        pair = trade['subtrades'][2]
        independent = np.array([.2 * .32, .2 * .68, .8 * .32, .8 * .68])
        np.testing.assert_allclose(pair['quote_before'], independent, atol=1e-12)
        raw = 10 * np.log(np.array(TRUTH) / independent)
        expected_h = raw - min(raw)
        np.testing.assert_allclose(pair['issued_by_book_outcome'], expected_h, atol=1e-12)
        expected_c = 10 * logsumexp(np.log(independent) + expected_h / 10)
        self.assertAlmostEqual(pair['premium'], expected_c)
        np.testing.assert_allclose(trade['issued_payoff'], sum(np.array(r['issued_payoff']) for r in trade['subtrades']))
        self.assertAlmostEqual(trade['premium'], sum(r['premium'] for r in trade['subtrades']))
        np.testing.assert_allclose(market.issued, trade['issued_payoff'])
        self.assertAlmostEqual(market.cash, 100 + trade['premium'])

    def test_full_pair_budget_rejection_keeps_all_blocks(self):
        market = APMM([.25] * 4)
        before = market.diagnostic()
        _, trade = market.plan_full((0, 1), TRUTH)
        budget = trade['subtrades'][0]['premium'] + .01
        self.assertLess(budget, trade['premium'])
        row = market.execute_full((0, 1), TRUTH, budget=budget)
        self.assertEqual(row['reason'], 'trader_budget')
        self.assertEqual(before, market.diagnostic())
        self.assertEqual(market.cash, 100)
        np.testing.assert_array_equal(market.issued, np.zeros(4))

    def test_matched_path_cash_and_prefix_reserve(self):
        result = run_fixture('matched', PRIOR, TRUTH, [(0, .8), (1, .68)] * 4)
        for row in result['mechanisms']:
            self.assertEqual(row['accepted'], 8)
            issued = np.zeros(4)
            cash = 100.0
            reserve = 0.0
            for record, arrival in zip(row['ledger'], result['arrivals']):
                self.assertEqual((record['event'], record['target']), (arrival['event'], arrival['target']))
                issued += record['actual_issued_payoff']
                cash += record['actual_premium'] + record['actual_fee']
                self.assertAlmostEqual(record['cash_after'], cash)
                np.testing.assert_allclose(record['issued_payoff_after'], issued)
                reserve = max(reserve, float(max(issued) - cash + 100))
                self.assertGreaterEqual(min(cash - issued), -1e-10)
            self.assertAlmostEqual(row['settlement']['required_reserve_on_path'], reserve)
            np.testing.assert_allclose(row['settlement']['maker_loss_by_outcome'], issued - cash + 100)

    def test_independent_information_is_useful(self):
        result = run_fixture('useful', [.25] * 4, [.06, .14, .24, .56], [(0, .8), (1, .7)] * 30)
        for row in result['mechanisms']:
            self.assertLess(row['final_max_singleton_error'], .04)
            self.assertGreater(row['initial_max_singleton_error'], .29)
            self.assertEqual(row['accepted'], 60)

    def test_repeated_information_adverse_payment(self):
        results = [run_fixture('repeated', PRIOR, TRUTH, [(0, .8), (1, .68)] * k) for k in [1, 4]]
        indexed = [{r['mechanism']: r for r in f['mechanisms']} for f in results]
        pm = [r[ParlayMarket.name]['settlement']['expected_maker_loss'] for r in indexed]
        apmm = [r[APMM.name]['settlement']['expected_maker_loss'] for r in indexed]
        np.testing.assert_allclose(pm, [2.405785331, 6.221670244], atol=1e-8)
        np.testing.assert_allclose(apmm, [2.590224800, 2.590224800], atol=1e-8)
        self.assertGreater(pm[1], pm[0])

    def test_joint_lmsr_all_outcome_bound_on_path(self):
        market = JointLMSR(PRIOR)
        bound = 10 * math.log(1 / min(PRIOR))
        for event, target in [(0, .9), (1, .1), (0, .1), (1, .9)] * 8:
            market.execute(event, target)
            self.assertLessEqual(market.settlement(TRUTH)['maximum_maker_loss'], bound + 1e-10)


if __name__ == '__main__':
    unittest.main(verbosity=2)
