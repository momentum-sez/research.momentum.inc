import unittest
from fractions import Fraction as F

import certified_estimator as c


def exp_enclosure(x, tolerance=F(1, 1 << 80)):
    """Independent positive Taylor series used only by the tests."""
    if x < 0:
        lo, hi = exp_enclosure(-x, tolerance)
        return 1 / hi, 1 / lo
    if x == 0:
        return F(1), F(1)
    total, term, n = F(1), F(1), 0
    while True:
        n += 1
        term *= x / n
        total += term
        if x < n + 2:
            tail = term * x / (n + 1) / (1 - x / (n + 2))
            if tail <= tolerance:
                return total, total + tail


LENGTHS = (512, 2048, 8192, 32768)
COUNTS = ((207, 48, 44, 213), (799, 208, 206, 835),
          (3236, 882, 909, 3165), (12084, 4345, 4361, 11978))


def count_fixture():
    """Construct an aligned sequence with the frozen nested-window counts."""
    previous = (0, 0, 0, 0)
    segments = []
    for counts in COUNTS:
        increments = tuple(x - y for x, y in zip(counts, previous))
        segments.append(tuple(z for z, n in enumerate(increments) for _ in range(n)))
        previous = counts
    observations = tuple(z for segment in reversed(segments) for z in segment)
    catalogue = c.Catalogue(tuple(c.Window(32768, n, F(n - 1, 1000000),
                                         "Declared full-law per-round slope1/500000") for n in LENGTHS), F(1, 20))
    return observations, catalogue


class CertifiedArithmeticTests(unittest.TestCase):
    def test_exact_binary_normalization(self):
        for x in (F(1, 7), F(1), F(2), F(3), F(1, 1 << 20000), F(1 << 20000)):
            k = c.binary_exponent(x)
            self.assertLessEqual(c.power_two(k), x)
            self.assertLess(x, c.power_two(k + 1))

    def test_log_enclosures_against_independent_rational_exponential(self):
        for x in (F(1, 4), F(2, 3), F(3, 2), F(2), F(7, 3)):
            v = c.log_interval(x, bits=16)
            self.assertLessEqual(v.width, F(1, 1 << 16))
            self.assertLessEqual(exp_enclosure(v.lower)[1], x)
            self.assertGreaterEqual(exp_enclosure(v.upper)[0], x)

    def test_log_exact_zero_and_negative_scale(self):
        self.assertEqual(c.log_interval(F(1)), c.Interval(F(0), F(0)))
        two = c.log_interval(F(2), 96)
        small = c.log_interval(F(1, 1 << 1024), 80)
        self.assertLessEqual(small.lower, -1024 * two.upper)
        self.assertGreaterEqual(small.upper, -1024 * two.lower)
        self.assertLess(small.upper, 0)

    def test_square_root_brackets_exactly(self):
        for x in (F(0), F(1), F(4), F(2), F(5, 9), F(1, 1 << 20000), F(1 << 20001)):
            v = c.sqrt_interval(x)
            self.assertLessEqual(v.lower * v.lower, x)
            self.assertGreaterEqual(v.upper * v.upper, x)
            if x:
                scale = c.power_two(c.binary_exponent(x) // 2)
                self.assertLessEqual(v.width, scale / (1 << 80))
        self.assertEqual(c.sqrt_interval(F(9, 16)), c.Interval(F(3, 4), F(3, 4)))

    def test_component_enclosures_compose_outward(self):
        n, delta, drift = 10000, F(1, 20), F(9999, 2000000)
        v = c.drift_radius(n, delta, drift, bits=32)
        sharp = c.drift_radius(n, delta, drift, bits=128)
        self.assertLessEqual(v.lower, sharp.lower)
        self.assertGreaterEqual(v.upper, sharp.upper)
        self.assertGreater(v.lower, drift)

    def test_tiny_cell_and_large_rounds_do_not_underflow(self):
        n = 10 ** 400
        r = c.counts_interval((n - 3, 1, 1, 1), F(1, 20), F(0))
        self.assertGreater(r['radius'].lower, 0)
        self.assertLess(r['radius'].upper, F(1, 10 ** 190))
        self.assertIsNone(r['coupling_interval'].lower)
        self.assertIsNone(r['coupling_interval'].upper)
        self.assertIsNotNone(r['point_interval'])

    def test_zero_count_boundary_keeps_infinite_endpoints(self):
        r = c.counts_interval((100, 0, 0, 0), F(1, 20), F(0))
        self.assertIsNone(r['point_interval'])
        self.assertEqual(r['estimate_status'], 'Boundary')
        self.assertIsNone(r['coupling_interval'].lower)
        self.assertIsNone(r['coupling_interval'].upper)

    def test_near_boundary_interior_claim_requires_upper_bound(self):
        radius = c.drift_radius(10000, F(1, 20), F(0), 32)
        middle = (radius.lower + radius.upper) / 2
        self.assertIsNone(c.interior_error(radius, middle))
        self.assertIsNone(c.interior_error(radius, radius.upper))
        self.assertIsNotNone(c.interior_error(radius, radius.upper + F(1, 10 ** 50)))
        self.assertGreater(c.interior_error(radius, radius.upper + F(1, 10 ** 50)), 40)

    def test_negative_radius_cannot_produce_negative_error_bound(self):
        with self.assertRaises(ValueError):
            c.interior_error(c.Interval(F(-1, 8), F(-1, 8)), F(1, 4))
        with self.assertRaises(ValueError):
            c.interior_error(c.Interval(F(-1, 8), F(1, 8)), F(1, 4))

    def test_coupling_point_certificate_preserves_exact_independence(self):
        self.assertEqual(c.contrast_interval((F(16, 25), F(4, 25), F(4, 25), F(1, 25))),
                         c.Interval(F(0), F(0)))
        mixed = c.contrast_interval((F(17, 50), F(4, 25), F(4, 25), F(17, 50)))
        direct = c.log_interval(F(17, 8))
        self.assertLessEqual(mixed.lower, direct.upper / 2)
        self.assertGreaterEqual(mixed.upper, direct.lower / 2)

    def test_frozen_adaptive_positive_witness(self):
        observations, catalogue = count_fixture()
        r = c.estimate_catalogue(observations, catalogue)
        self.assertEqual(tuple(x['counts'] for x in r['results']), COUNTS)
        self.assertEqual(r['selected']['window'].length, 8192)
        self.assertGreater(r['selected']['coupling_interval'].lower, 0)
        truth = c.contrast_interval((F(2, 5), F(1, 10), F(1, 10), F(2, 5)), bits=128)
        for candidate in r['results']:
            interval = candidate['coupling_interval']
            self.assertLess(interval.lower, truth.lower)
            self.assertGreater(interval.upper, truth.upper)
        self.assertEqual(r['total_failure_budget'], F(1, 20))

    def test_adaptive_finite_and_infinite_width_ties(self):
        catalogue = c.Catalogue((c.Window(4, 4, F(0), 'Law'), c.Window(5, 4, F(0), 'Law')), F(1, 20))
        r = c.estimate_catalogue((0, 0, 0, 0, 0), catalogue)
        self.assertEqual(r['selected_index'], 0)

    def test_signed_decimal_rounding_is_outward(self):
        for value in (F(-1, 3), F(1, 3), F(-1, 100000), F(0), F(5, 2)):
            lower = c.decimal_endpoint(value, 4, 'lower')
            upper = c.decimal_endpoint(value, 4, 'upper')
            self.assertLessEqual(F(lower), value)
            self.assertGreaterEqual(F(upper), value)
        self.assertEqual(c.display_interval(c.Interval(F(-1, 3), F(-1, 3)), 4), ('-0.3334', '-0.3333'))
        self.assertEqual(c.display_interval(c.ExtendedInterval(None, None)), ('-infinity', '+infinity'))

    def test_rational_contract_rejects_floats_and_invalid_laws(self):
        for call in (lambda: c.log_interval(.5), lambda: c.sqrt_interval(True),
                     lambda: c.counts_interval((25, 25, 25, 25), .05, F(0)),
                     lambda: c.log_interval(F(0)), lambda: c.sqrt_interval(F(-1)),
                     lambda: c.contrast_interval((F(1), F(1), F(1), F(1)))):
            with self.assertRaises((ValueError, TypeError)):
                call()

    def test_precision_or_term_exhaustion_is_explicit(self):
        with self.assertRaises(ValueError):
            c.log_interval(F(2), 0)
        with self.assertRaises(ArithmeticError):
            c.log_core(F(1, 3), F(1, 1 << 100), max_terms=1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
