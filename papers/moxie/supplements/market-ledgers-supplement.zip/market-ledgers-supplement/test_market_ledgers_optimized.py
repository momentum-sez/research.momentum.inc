"""Check experiment acceptance under normal and optimized Python.

Run with Python 3.14.6 and the supplement's exact dependency versions.
The tests use unittest checks, which remain active under optimization.
"""

import ast
from collections import Counter
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import unittest
import zipfile


ENVIRONMENT = {'python': '3.14.6', 'numpy': '2.4.3', 'scipy': '1.17.1'}
COUNTS = {
    'full_mle_moment_residual': 2,
    'pseudolikelihood_gradient_residual': 6,
    'selected_interface_nonidentification': 1,
    'saturated_reconstruction': 1,
    'global_infeasibility': 1,
    'global_projection': 1,
    'quote_box_corner_minima': 1,
    'quote_box_boundary_crossing': 1,
    'environmental_susceptibility': 3,
    'known_tree_reconstruction': 1,
}
PROBES = (
    ('full_mle_moment_residual', 'wrong_fit', 'result.x = np.zeros_like(result.x)'),
    ('pseudolikelihood_gradient_residual', 'wrong_fit', 'result.x = np.zeros_like(result.x)'),
    ('selected_interface_nonidentification', 'different_interface', 'selected_error = 1.0'),
    ('selected_interface_nonidentification', 'identical_laws', 'alternative = p.copy()'),
    ('saturated_reconstruction', 'wrong_cell', 'reconstructed[0] += .1'),
    ('global_infeasibility', 'unexpected_success', 'feasible.success = True'),
    ('global_infeasibility', 'wrong_status', 'feasible.status = 0'),
    ('global_projection', 'failed_solver', 'projected.success = False'),
    ('global_projection', 'wrong_objective', 'projected.fun += .1'),
    ('quote_box_corner_minima', 'wrong_bound', 'margin[0] += .1'),
    ('quote_box_boundary_crossing', 'no_crossing', 'negative = np.ones(4)'),
    ('environmental_susceptibility', 'bound_exceeded', 'measured = bound + 1.0'),
    ('known_tree_reconstruction', 'wrong_cell', 'tree[0] += .1'),
)


def payloads():
    """Read the distributed package or the repository's archive."""
    here = Path(__file__).resolve().parent
    if (here / 'experiments.py').is_file():
        sums = (here / 'SHA256SUMS').read_bytes()
        names = [line.split('  ', 1)[1] for line in sums.decode().splitlines()]
        return {'SHA256SUMS': sums, **{name: (here / name).read_bytes() for name in names}}
    archive = here / 'moxie/supplements/market-ledgers-supplement.zip'
    prefix = 'market-ledgers-supplement/'
    with zipfile.ZipFile(archive) as source:
        return {name.removeprefix(prefix): source.read(name) for name in source.namelist()}


def load_json(text):
    def reject_constant(value):
        raise ValueError('Nonfinite JSON number: ' + value)
    return json.loads(text, parse_constant=reject_constant)


def invoke(directory, optimization, script, *arguments):
    environment = os.environ.copy()
    environment.pop('PYTHONOPTIMIZE', None)
    command = [sys.executable, '-B'] + (['-O'] if optimization else [])
    return subprocess.run(command + [script, *arguments], cwd=directory,
                          env=environment, capture_output=True, text=True, timeout=90)


class ExperimentAcceptanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        actual = {'python': platform.python_version(),
                  'numpy': importlib.metadata.version('numpy'),
                  'scipy': importlib.metadata.version('scipy')}
        if actual != ENVIRONMENT:
            raise RuntimeError('Use the recorded environment: ' + repr(ENVIRONMENT)
                               + '. Found: ' + repr(actual))
        cls.files = payloads()
        cls.source = cls.files['experiments.py'].decode()
        cls.temporary = tempfile.TemporaryDirectory(prefix='experiment-acceptance-')
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.root = Path(cls.temporary.name)
        cls.runs = {}
        for mode in (0, 1):
            directory = cls.root / str(mode)
            (directory / 'expected').mkdir(parents=True)
            for name in ('experiments.py', 'verify_results.py',
                         'expected/experiment-results.json', 'expected/experiment-acceptance.json'):
                (directory / name).write_bytes(cls.files[name])
            cls.runs[mode] = (directory, invoke(directory, mode, 'experiments.py'))

    def compare_values(self, actual, expected, path=''):
        if isinstance(actual, dict) and isinstance(expected, dict):
            omitted = {'environment', 'marginal_evaluation_microseconds'}
            self.assertEqual(set(actual) - omitted, set(expected) - omitted, path)
            for key in sorted(set(actual) - omitted):
                self.compare_values(actual[key], expected[key], path + '/' + key)
        elif isinstance(actual, list) and isinstance(expected, list):
            self.assertEqual(len(actual), len(expected), path)
            for index, (a, b) in enumerate(zip(actual, expected)):
                self.compare_values(a, b, path + '/' + str(index))
        elif (isinstance(actual, (int, float)) and not isinstance(actual, bool)
              and isinstance(expected, (int, float)) and not isinstance(expected, bool)):
            self.assertTrue(math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-10),
                            (path, actual, expected))
        else:
            self.assertEqual(actual, expected, path)

    def result(self, mode):
        directory, run = self.runs[mode]
        self.assertEqual(run.returncode, 0, run.stderr)
        result = load_json((directory / 'experiment-results.json').read_text())
        self.assertEqual(result, load_json(run.stdout))
        self.assertEqual(result['environment'], {**ENVIRONMENT, 'optimization': mode})
        return result

    def test_package_hashes_match_all_payloads(self):
        sums = {}
        for line in self.files['SHA256SUMS'].decode().splitlines():
            digest, name = line.split('  ', 1)
            self.assertNotIn(name, sums)
            sums[name] = digest
        self.assertEqual(set(sums), set(self.files) - {'SHA256SUMS'})
        for name, digest in sums.items():
            with self.subTest(path=name):
                self.assertEqual(hashlib.sha256(self.files[name]).hexdigest(), digest)
        manifest = load_json(self.files['REFERENCE-MANIFEST.json'])
        for reference in manifest['reference_files']:
            self.assertEqual(sums[reference['path']], reference['sha256'])

    def test_actual_experiments_match_references_in_both_modes(self):
        expected = load_json(self.files['expected/experiment-results.json'])
        expected['acceptance_checks'] = load_json(self.files['expected/experiment-acceptance.json'])
        for mode in (0, 1):
            with self.subTest(optimization=mode):
                self.compare_values(self.result(mode), expected)
                directory, _ = self.runs[mode]
                verification = invoke(directory, mode, 'verify_results.py', 'experiment-results.json')
                self.assertEqual(verification.returncode, 0, verification.stderr)
        self.compare_values(self.result(0), self.result(1))

    def test_acceptance_records_expose_criteria_and_solver_status(self):
        tree = ast.parse(self.source)
        self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))
        for mode in (0, 1):
            result = self.result(mode)
            checks = result['acceptance_checks']
            self.assertEqual(Counter(row['name'] for row in checks), COUNTS)
            for row in checks:
                with self.subTest(optimization=mode, check=row):
                    self.assertIs(row['passed'], True)
                    self.assertTrue(row['criterion'])
                    if row['name'] in ('full_mle_moment_residual', 'pseudolikelihood_gradient_residual'):
                        self.assertLess(row['residual'], 1e-7)
                        self.assertEqual(row['tolerance'], 1e-7)
                        self.assertEqual(row['solver']['method'], 'BFGS')
                        self.assertIn(row['sample'], ('population', 'sample_5000'))
                    elif row['name'] in ('saturated_reconstruction', 'known_tree_reconstruction'):
                        self.assertLess(row['residual'], 1e-14)
                    elif row['name'] == 'selected_interface_nonidentification':
                        self.assertLess(row['residual'], 1e-14)
                        self.assertGreater(row['full_law_difference'], .01)
                    elif row['name'] == 'global_infeasibility':
                        self.assertIs(row['solver']['success'], False)
                        self.assertEqual(row['solver']['status'], 2)
                    elif row['name'] == 'global_projection':
                        self.assertIs(row['solver']['success'], True)
                        self.assertLess(abs(row['objective'] - 17 / 30), 1e-12)
                    elif row['name'] == 'quote_box_corner_minima':
                        quote = result['quote_uncertainty']
                        self.assertEqual(row['residual'], quote['corner_check_error'])
                        self.assertLess(row['residual'], 1e-8)
                    elif row['name'] == 'quote_box_boundary_crossing':
                        self.assertLess(row['minimum_cell_lower_bound'], 0)
                    elif row['name'] == 'environmental_susceptibility':
                        self.assertLessEqual(row['measured'], row['bound'] + 1e-12)
                    if 'solver' in row:
                        self.assertIs(type(row['solver']['success']), bool)
                        self.assertIs(type(row['solver']['status']), int)
                        self.assertIs(type(row['solver']['iterations']), int)
                        self.assertTrue(row['solver']['message'])
            pseudolikelihood = {(row['sample'], row['site']) for row in checks
                                if row['name'] == 'pseudolikelihood_gradient_residual'}
            self.assertEqual(pseudolikelihood, {(sample, site) for sample in ('population', 'sample_5000')
                                                for site in range(3)})

    def test_each_adverse_input_stops_execution_in_both_modes(self):
        tree = ast.parse(self.source)
        for name, probe, statement in PROBES:
            sites = [node for node in ast.walk(tree)
                     if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                     and isinstance(node.value.func, ast.Name) and node.value.func.id == 'require'
                     and isinstance(node.value.args[0], ast.Constant) and node.value.args[0].value == name]
            self.assertEqual(len(sites), 1, name)
            lines = self.source.splitlines(keepends=True)
            site = sites[0]
            lines.insert(site.lineno - 1, ' ' * site.col_offset + statement + '\n')
            mutant = ''.join(lines)
            for mode in (0, 1):
                with self.subTest(check=name, probe=probe, optimization=mode):
                    directory = self.root / (name + '-' + probe + '-' + str(mode))
                    directory.mkdir()
                    (directory / 'experiments.py').write_text(mutant)
                    run = invoke(directory, mode, 'experiments.py')
                    self.assertNotEqual(run.returncode, 0)
                    self.assertIn('Experiment acceptance failed: ' + name + ':', run.stderr)
                    self.assertFalse((directory / 'experiment-results.json').exists())
                    print(json.dumps({'adverse_probe': name + '/' + probe,
                                      'optimization': mode, 'returncode': run.returncode,
                                      'named_failure': name}), flush=True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
