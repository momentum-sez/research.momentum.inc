# Central Counterparty Risk computational supplement

This supplement accompanies *Central Counterparty Risk in Automated Markets*. It contains the existing synthetic study and three reference calculations used in the manuscript. The source files implement finite mathematical models and synthetic settlement examples.

## Contents

| Directory | Contents |
|---|---|
| `reference/synthetic` | Deterministic generator, declared inputs, loss and fill records, monitoring replications, formula table, and rational checks. |
| `reference/completion` | Exact rational completion calculation, finite risk budgets, runtime tests and independent oracle. |
| `reference/monitoring` | Persistent binary monitoring, budget and admission rules, and exact probability checks. |
| `reference/durable` | Single-asset durable completion adapter, settlement store, worker and synthetic-provider tests. |
| `reference/encoding` | Exact canonical encoding, source-pin fixtures and synthetic provider. |
| `reference/catalogue` | Fixed catalogue metadata consumed by the monitoring test. The estimator itself is outside this supplement. |
| `historical` | Labeled exports of historical successful runs and their command records. |

The rational completion model permits exact fractional amounts. The durable adapter uses integral settlement quantities, one controlled authority and a selected finite policy. Its provider evidence is synthetic. Separate currencies and partial observations remain extensions. Model loss laws, institutional authority, funding facts and provider truth retain their stated assumptions.

The synthetic tests bind the included historical manuscript fixture, SHA-256 `f04d9290409ac7f5784eb87ece00d1f0b2913eb279f946e009deb8322632b8a0`. They check that fixture and its exact expressions. They do not certify every statement of the accompanying manuscript. The generator imports helpers from both test modules.

Public packaging changes only dependency paths in the durable adapter and one monitoring test. The dependency inventory also uses package-relative paths. The reference calculations, state transitions, exact source pins and fixed catalogue data retain their contents. `SOURCE-IDENTITIES.json` distinguishes unchanged files from path adaptations. Original code, commands and logs remain preserved separately.

## Reproduction

Use CPython 3.14 with SQLite support. Install the single external dependency:

```sh
python3.14 -m pip install -r requirements.txt
```

The required distribution is `unicodedata2==17.0.1`. It supplies Unicode data version `17.0.0`, which the encoding source checks explicitly. `DEPENDENCIES.json` identifies the exact macOS ARM64 wheel used for validation. Its license is included. The dependency binary is obtained separately. Other platforms require the same distribution and Unicode data versions; they have not been validated here.

Extract the archive into a new directory. From `ccp-risk-supplement`, run:

```sh
python3.14 -B reproduce.py --work "$PWD/portability-check"
```

The wrapper verifies all payload hashes. It creates an unused work directory inside the extracted supplement, then copies the reference tree. It runs the generator and each computation group once in normal mode. All temporary databases and fresh logs remain inside that work directory.

The six groups are the synthetic generator, 41 synthetic checks, 39 completion checks, 14 monitoring checks, eight probability checks and 12 durable checks. These are finite examples and checks of the stated reference models. Their execution does not establish a general refinement theorem or empirical calibration.

`VERIFICATION.json` records the actual interpreter, platform, commands, log hashes, elapsed times and generated-product comparisons. Small interpreter-dependent floating-point differences can occur in the results JSON. Raw inputs, CSV records and displayed tables are compared separately. SQLite resource warnings are retained in the logs if emitted.

To check hashes without executing computations, select another unused absolute path:

```sh
python3.14 -B reproduce.py --verify-only --work "$PWD/hash-check"
```

## Historical evidence

`historical/COMMANDS.json` gives the normal and optimized commands recorded on 5 September 2026. Interpreter paths and working directories are normalized to portable forms. Flags, test selection and result counts are retained. Each log has an export label. These exports are not the original log bytes. Both original and exported content hashes are recorded.

Historical synthetic checks refer to their included source fixture. Historical durable runs used CPython 3.14.6. Public path adaptations receive separate fresh-extraction verification. Historical runs are not relabeled as tests of transformed source.

`MANIFEST.json` and `MANIFEST.sha256` bind every payload file except those two manifests. The delivery receipt binds the archive and both manifests. No private source paths, internal receipts or repository history are included.
