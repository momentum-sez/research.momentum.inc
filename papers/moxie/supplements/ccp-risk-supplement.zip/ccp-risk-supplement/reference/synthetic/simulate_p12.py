"""Deterministic synthetic P12 study. No external datasets or live venue calls."""
from fractions import Fraction as F
from pathlib import Path
from statistics import NormalDist
import csv
import hashlib
import json
import math
import random

from test_p12_upgrade import binomial_tail, likelihood_threshold, schedule

ROOT=Path(__file__).resolve().parent


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def empirical_es(losses,q):
    remaining=q*len(losses);total=0.0
    for loss in sorted(losses,reverse=True):
        take=min(1.0,remaining);total+=take*loss;remaining-=take
        if remaining<=1e-12:break
    return total/(q*len(losses))


def monitor(losses,p0,p1,alpha):
    loge=0.0;first=None;peak=0.0
    for t,loss in enumerate(losses,1):
        bit=int(loss>0)
        loge+=math.log(p1/p0) if bit else math.log((1-p1)/(1-p0))
        peak=max(peak,loge)
        if first is None and loge>=math.log(1/alpha):first=t
    return first,peak


def main():
    inputs={
      'data_kind':'synthetic', 'generator':'independent two-point losses and independent funded round trips',
      'seed':120018,'training_count':1000,'held_out_count':5000,'change_after_held_out_index':2500,
      'loss_values':[0,100],'nominal_event_probability':.005,'shift_event_probability':.015,
      'tail_mass':.01,'stress_event_probability_upper':.02,
      'health_alpha':.05,'health_alternative_probability':.015,'health_replications':200,'health_horizon':1000,
      'buyback_replications':1000,'buyback_initial_cash':150,'buyback_protected_target':100,
      'buyback_curve_input':20,'buyback_fee':.2,'buyback_pool_reserves':[1000,1000],
      'buyback_budget_fraction':.5,'buyback_reserve_threshold':.5,'buyback_risk_budget':.06,'buyback_value_budget':0,
      'buyback_post_credit_requirement':80,'buyback_target_multiplier':1.25,'buyback_stress_payment_after_fill':80,
      'buyback_exit_scenarios':[
        {'probability':.94,'settlement_reserve':1100,'hub_reserve':1000,'fill':True},
        {'probability':.05,'settlement_reserve':800,'hub_reserve':1000,'fill':True},
        {'probability':.01,'settlement_reserve':1000,'hub_reserve':1000,'fill':False}],
      'efficiency_rows':[{'spokes':10,'rho':r,'credit_sum':d,'isolated_per_spoke':1.15} for r,d in [(.2,.08),(.4,.08),(.5,.08),(.4,.04)]]}
    (ROOT/'synthetic-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
    rng=random.Random(inputs['seed']);p0=inputs['nominal_event_probability'];q=inputs['tail_mass']
    training=[100*int(rng.random()<p0) for _ in range(inputs['training_count'])]
    cutoff=len(training)
    probabilities=[p0 if t<inputs['change_after_held_out_index'] else inputs['shift_event_probability'] for t in range(inputs['held_out_count'])]
    losses=[100*int(rng.random()<p) for p in probabilities]
    mu=sum(training)/len(training);variance=sum((x-mu)**2 for x in training)/len(training)
    z=NormalDist().inv_cdf(1-q);normal_es=math.exp(-z*z/2)/math.sqrt(2*math.pi)/q
    strategies={
      'Gaussian linear baseline':mu+math.sqrt(variance)*normal_es,
      'Known nominal full-loss ES':100*p0/q,
      'Joint stress envelope':100*min(inputs['stress_event_probability_upper']/q,1),
      'Isolated full-loss limit':100}
    with (ROOT/'synthetic-losses.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['index','partition','generator_probability','loss','forecast_cutoff'])
        for t,x in enumerate(training,1):writer.writerow([t,'training',p0,x,''])
        for t,(x,pr) in enumerate(zip(losses,probabilities),cutoff+1):writer.writerow([t,'held-out',pr,x,cutoff])
    metrics=[]
    for name,margin in strategies.items():
        breaches=[max(x-margin,0) for x in losses]
        metrics.append({'strategy':name,'forecast_cutoff':cutoff,'margin':margin,
          'held_out_observations':len(losses),'breaches':sum(b>0 for b in breaches),
          'breach_rate':sum(b>0 for b in breaches)/len(losses),'coverage':sum(b==0 for b in breaches)/len(losses),
          'mean_unfunded_loss':sum(breaches)/len(losses),'max_unfunded_loss':max(breaches),
          'empirical_tail_loss':empirical_es(losses,q),'capital_use_per_100_notional':margin,
          'execution_liquidity_cost':0.0,
          'interpretation':'Synthetic fixed-forecast comparison. The Gaussian baseline does not satisfy the exact elliptical linear-loss premise for this digital loss.' if name.startswith('Gaussian') else 'Synthetic full-loss or stress calculation; physical calibration is conditional on generator coverage.'})
    null_rng=random.Random(inputs['seed']+1);alt_rng=random.Random(inputs['seed']+2)
    null_alarms=0;alt_detections=0;delays=[];health_records=[]
    for replication in range(inputs['health_replications']):
        null=[int(null_rng.random()<p0) for _ in range(inputs['health_horizon'])]
        alt=[int(alt_rng.random()<inputs['health_alternative_probability']) for _ in range(inputs['health_horizon'])]
        first,peak=monitor(null,p0,inputs['health_alternative_probability'],inputs['health_alpha'])
        null_alarms+=first is not None
        health_records.append({'replication':replication+1,'law':'null','first_alarm':first,'peak_log_e':peak,'events':sum(null)})
        first,peak=monitor(alt,p0,inputs['health_alternative_probability'],inputs['health_alpha'])
        alt_detections+=first is not None
        health_records.append({'replication':replication+1,'law':'shifted','first_alarm':first,'peak_log_e':peak,'events':sum(alt)})
        if first is not None:delays.append(first)
    with (ROOT/'synthetic-health.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(health_records[0]));writer.writeheader();writer.writerows(health_records)
    n=inputs['health_horizon'];threshold=likelihood_threshold(n,p0,inputs['health_alternative_probability'],inputs['health_alpha'])
    health={'kind':'Independent synthetic null and shifted replications',
      'replications':inputs['health_replications'],'horizon':n,'null_false_alarms':null_alarms,
      'null_false_alarm_rate':null_alarms/inputs['health_replications'],'lifetime_probability_bound':inputs['health_alpha'],
      'shift_detections':alt_detections,'shift_detection_rate':alt_detections/inputs['health_replications'],
      'mean_detected_delay':sum(delays)/len(delays) if delays else None,
      'exact_terminal_binomial_threshold':threshold,
      'proved_detection_probability_lower_bound':binomial_tail(n,inputs['health_alternative_probability'],threshold),
      'empirical_claim':False}
    outcomes_rng=random.Random(inputs['seed']+3);q_buy=F(1000,51);cash0=F(150);debit=F(101,5)
    budget=F(str(inputs['buyback_budget_fraction']))*(cash0-F(inputs['buyback_protected_target']))
    current_bad_probability=F(6,100);current_expected_net=F(17,26)
    # Evaluate all admission conditions before reading the future outcome RNG.
    admitted=(budget>=debit and cash0/F(150)>=F(str(inputs['buyback_reserve_threshold']))
       and current_bad_probability<=F(str(inputs['buyback_risk_budget']))
       and current_expected_net>=-F(inputs['buyback_value_budget'])
       and cash0-debit>=F(inputs['buyback_post_credit_requirement'])*F(str(inputs['buyback_target_multiplier']))
       and cash0-debit>=F(inputs['buyback_stress_payment_after_fill']))
    if not admitted:raise ValueError('decision-time synthetic admission failed')
    trades=[]
    for i in range(inputs['buyback_replications']):
        u=outcomes_rng.random()
        if u<.94:label='favorable';proceeds=F(1100)*q_buy/(1000+q_buy);paid=debit;qty=q_buy
        elif u<.99:label='adverse';proceeds=F(800)*q_buy/(1000+q_buy);paid=debit;qty=q_buy
        else:label='failed fill';proceeds=F(0);paid=F(1,5);qty=F(0)
        post_buy=cash0-paid;final=post_buy+proceeds
        if post_buy<100:raise ValueError('protected cash violated')
        trades.append({'independent_book':i+1,'decision_before_outcome':admitted,'outcome':label,'cash_initial':float(cash0),'cash_debit':float(paid),
                       'settled_quantity':float(qty),'cash_after_buy':float(post_buy),'exit_proceeds':float(proceeds),
                       'cash_final':float(final),'net':float(final-cash0)})
    with (ROOT/'synthetic-buybacks.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(trades[0]));writer.writeheader();writer.writerows(trades)
    table=[]
    for row in inputs['efficiency_rows']:
        ratio=(row['isolated_per_spoke']-row['credit_sum'])/row['isolated_per_spoke']*math.sqrt(row['rho']+(1-row['rho'])/row['spokes'])
        table.append(dict(row,ratio=ratio,rounded=f'{ratio:.2f}'))
    (ROOT/'synthetic-efficiency-table.json').write_text(json.dumps(table,indent=2)+'\n')
    result={
      'data_kind':'synthetic','generator_inputs_sha256':digest(ROOT/'synthetic-inputs.json'),
      'simulation_source_sha256':digest(Path(__file__)),
      'training_cutoff':cutoff,'held_out_index_range':[cutoff+1,cutoff+len(losses)],
      'training_event_count':sum(x>0 for x in training),'held_out_event_count':sum(x>0 for x in losses),
      'forecast_uses_future_observations':False,'metrics':metrics,'health':health,
      'funded_round_trips':{'independent_books':len(trades),'initial_funding_per_book':150,'protected_floor':100,'decision_time_admission':admitted,'all_in_budget':float(budget),
          'minimum_post_buy_cash':min(t['cash_after_buy'] for t in trades),'observed_mean_net':sum(t['net'] for t in trades)/len(trades),
          'exact_generator_expected_net':str(F(17,26)),'failed_fills':sum(t['outcome']=='failed fill' for t in trades),
          'mean_all_in_cash_debit':sum(t['cash_debit'] for t in trades)/len(trades),
          'mean_curve_entry_slippage_and_fee':sum(t['cash_debit']-t['settled_quantity'] for t in trades)/len(trades)},
      'sequencing':{'A_then_B':list(map(str,schedule(['A','B'])[:3])),'B_then_A':list(map(str,schedule(['B','A'])[:3])),
                    'interpretation':'Same final proceeds, different deadline shortfall. Cash and receivables remain separate.'},
      'calibration_scope':'Generator probabilities are fixed inputs. These synthetic comparisons do not establish venue calibration, actual capital savings, provider performance or regulatory acceptance.'}
    result['raw_outputs']={name:digest(ROOT/name) for name in ['synthetic-losses.csv','synthetic-buybacks.csv','synthetic-health.csv','synthetic-efficiency-table.json']}
    (ROOT/'synthetic-results.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=[r'\begin{table}[htbp]',r'\centering',r'\footnotesize',r'\begin{tabular}{@{}lrrrr@{}}',r'\toprule',
      r'Forecast & Margin & Breaches & Coverage & Mean shortfall \\',r'\midrule']
    for m in metrics:
        lines.append(f"{m['strategy']} & {m['margin']:.2f} & {m['breaches']} & {100*m['coverage']:.2f}\\% & {m['mean_unfunded_loss']:.3f} \\\\")
    lines += [r'\bottomrule',r'\end{tabular}',r'\caption{Synthetic held-out loss comparison over 5,000 observations. Amounts use one settlement unit.}',r'\label{tab:synthetic-tail-study}',r'\end{table}']
    (ROOT/'synthetic-study-table.tex').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'metrics':metrics,'health':health,'funded_round_trips':result['funded_round_trips']},indent=2))

if __name__=='__main__':main()
