"""Finite mathematical checks for P12's nonlinear risk and funded execution models."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import itertools
import math
import random
from statistics import NormalDist
import unittest

from test_risk_accounting import es


def hinge_es(losses, probabilities, q):
    return min(v+sum(p*max(x-v,0) for x,p in zip(losses,probabilities))/q for v in losses)


def softmax_cost(cost, prior, tau):
    values=[p*math.exp(-c/tau) for c,p in zip(cost,prior)]
    return [v/sum(values) for v in values]


def entropy_objective(p, prior, cost, tau):
    return tau*sum(x*math.log(x/y) if x else 0 for x,y in zip(p,prior))+sum(x*c for x,c in zip(p,cost))


def adaptive_simpson(f,a,b,tol=1e-10):
    def rec(a,b,fa,fm,fb,whole,tol,depth):
        m=(a+b)/2;left=(a+m)/2;right=(m+b)/2
        fl,fr=f(left),f(right)
        s1=(m-a)*(fa+4*fl+fm)/6;s2=(b-m)*(fm+4*fr+fb)/6
        if depth<=0 or abs(s1+s2-whole)<=15*tol:
            return s1+s2+(s1+s2-whole)/15
        return rec(a,m,fa,fl,fm,s1,tol/2,depth-1)+rec(m,b,fm,fr,fb,s2,tol/2,depth-1)
    fa,fb,fm=f(a),f(b),f((a+b)/2)
    return rec(a,b,fa,fm,fb,(b-a)*(fa+4*fm+fb)/6,tol,22)


def student_tail(nu,z,moment=False):
    norm=math.gamma((nu+1)/2)/(math.sqrt(nu*math.pi)*math.gamma(nu/2))
    def integrand(theta):
        if theta>=math.pi/2:return 0.0
        x=math.tan(theta)
        return norm*(1+x*x/nu)**(-(nu+1)/2)*(1+x*x)*(x if moment else 1)
    return adaptive_simpson(integrand,math.atan(z),math.pi/2)


def student_es(nu,q):
    lo,hi=0.0,100.0
    for _ in range(55):
        mid=(lo+hi)/2
        if student_tail(nu,mid)>q:lo=mid
        else:hi=mid
    z=(lo+hi)/2
    pdf=math.gamma((nu+1)/2)/(math.sqrt(nu*math.pi)*math.gamma(nu/2))*(1+z*z/nu)**(-(nu+1)/2)
    analytic=math.sqrt((nu-2)/nu)*(nu+z*z)/(nu-1)*pdf/q
    numerical=math.sqrt((nu-2)/nu)*student_tail(nu,z,True)/q
    return analytic,numerical


def causal_response(initial, matrix, cap, steps=500):
    x=list(initial)
    for _ in range(steps):
        d=[1-(1+t)**-2 for t in x]
        nxt=[a+min(c-a,sum(m*y for m,y in zip(row,d))) for a,c,row in zip(initial,cap,matrix)]
        if max(abs(a-b) for a,b in zip(x,nxt))<1e-14:return nxt
        x=nxt
    return x


def binomial_tail(n,p,k):
    if k<=0:return 1.0
    if k>n:return 0.0
    return sum(math.exp(math.lgamma(n+1)-math.lgamma(j+1)-math.lgamma(n-j+1)+j*math.log(p)+(n-j)*math.log1p(-p)) for j in range(k,n+1))


def likelihood_threshold(n,p0,p1,alpha):
    a,b=math.log(p1/p0),math.log((1-p1)/(1-p0))
    return max(0,min(n+1,math.ceil((math.log(1/alpha)-n*b)/(a-b))))


def schedule(order):
    cash=F(0);debt=F(5);initial={'A':F(12),'B':F(8)};inventory={'A':F(1),'B':F(1)}
    deadline_shortfall=F(0);receipts=[]
    for t,asset in enumerate(order):
        q=inventory[asset];inventory[asset]-=q
        receipt=initial[asset]*q/(1+q);cash+=receipt;receipts.append(receipt)
        payment=min(cash,debt);cash-=payment;debt-=payment
        if t==0:deadline_shortfall=debt
        if min(cash,debt,*inventory.values())<0:raise ValueError('negative funded state')
    return cash,debt,deadline_shortfall,receipts


class UpgradeChecks(unittest.TestCase):
    def test_04_full_digital_loss_is_not_a_covariance_charge(self):
        p=F(1,200);q=F(1,100)
        laws=[F(0),F(100),F(200)];weights=[(1-p)**2,2*p*(1-p),p*p]
        self.assertEqual(es(laws,weights,q),100)
        self.assertEqual(hinge_es(laws,weights,q),100)
        self.assertEqual(es([F(0),F(100)],[1-p,p],q),50)
        self.assertLess(math.sqrt(50**2+50**2),100)
        # A full digital hedge still permits material activity at the independent floor.
        self.assertEqual(es([F(0)],[F(1)],q),0)
        self.assertEqual(max(F(5),es([F(0)],[F(1)],q)),5)

    def test_04_nonlinear_remainder_and_zero_delta_counterexample(self):
        normal=NormalDist();q=.01;a=normal.inv_cdf(1-q/2)
        exact=2*a*math.exp(-a*a/2)/math.sqrt(2*math.pi)/q
        self.assertAlmostEqual(exact,7.449165962104,places=9)
        self.assertGreater(exact,0) # derivative of z*z-1 at zero is zero.
        z=[normal.inv_cdf(1-q+(i+.5)*q/5000) for i in range(5000)]
        linear=sum(2*x for x in z)/len(z)
        nonlinear=sum(2*x+.1*math.sin(x) for x in z)/len(z)
        self.assertLessEqual(abs(nonlinear-linear),.1)

    def test_04_robust_scale_supremum_survives_zero_remainder(self):
        q=.01;z=NormalDist().inv_cdf(1-q)
        k=math.exp(-z*z/2)/math.sqrt(2*math.pi)/q
        scales=[1,2]
        full=max(sigma*k for sigma in scales)
        self.assertEqual(full,2*k)
        self.assertGreater(full,k)
        self.assertEqual(max(math.sqrt((sigma*k)**2) for sigma in scales),full)

    def test_05_equicorrelation_endpoint_and_strictness(self):
        for values in [(F(1),F(2)),(F(3),F(3)),(F(1),F(2),F(4))]:
            n=len(values);total=sum(values)
            for rho in [F(0),F(1,4),F(9,10),F(1)]:
                variance=(1-rho)*sum(x*x for x in values)+rho*total*total
                self.assertLessEqual(total*total/variance,F(n)/(1+(n-1)*rho))
                equality=total*total/variance==F(n)/(1+(n-1)*rho)
                self.assertEqual(equality,rho==1 or len(set(values))==1)

    def test_06_student_common_factor_by_independent_tail_integral(self):
        references={3:4.043231298781,4:3.691510485681,5:3.448836760048,10:3.008183569424,30:2.768459113578}
        for nu,expected in references.items():
            analytic,numerical=student_es(nu,.01)
            self.assertAlmostEqual(analytic,numerical,places=7)
            self.assertAlmostEqual(analytic,expected,places=7)
            standalone=3*analytic;portfolio=analytic*math.sqrt(3*(1+2*.25))
            self.assertAlmostEqual(standalone/portfolio,math.sqrt(2),places=12)

    def test_08_recorded_flow_to_clearing_influence(self):
        rng=random.Random(120008)
        for _ in range(100):
            tau=rng.uniform(.5,5);alpha=rng.uniform(0,.3);g=2
            prior=[rng.uniform(.1,1) for _ in range(5)];prior=[x/sum(prior) for x in prior]
            base=[rng.uniform(-g,g) for _ in prior];adverse=[rng.uniform(-g,g) for _ in prior]
            pert=[(1-alpha)*x+alpha*y for x,y in zip(base,adverse)]
            p=softmax_cost(base,prior,tau);pp=softmax_cost(pert,prior,tau)
            tv=sum(abs(x-y) for x,y in zip(p,pp))/2
            self.assertLessEqual(tv,g*alpha/tau+1e-12)
        p=softmax_cost([0,0],[.5,.5],2);pp=softmax_cost([.2,-.2],[.5,.5],2)
        self.assertGreater(sum(abs(x-y) for x,y in zip(p,pp)),0)
        # Output density is generally not the same-alpha mixture with the baseline.
        pp=softmax_cost([10,-10],[.5,.5],.1)
        self.assertGreater(abs(pp[1]-.5),.1)

    def test_09_jumps_atoms_and_integrable_unbounded_tail(self):
        self.assertEqual(es([F(0),F(100)],[F(199,200),F(1,200)],F(1,100)),50)
        midpoint=[F(100)*int(F(2*i+1,200)>F(199,200)) for i in range(100)]
        self.assertEqual(es(midpoint,[F(1,100)]*100,F(1,100)),0)
        strict=es([F(0),F(0),F(100)],[F(993,1000),F(2,1000),F(5,1000)],F(1,100))
        weak=es([F(0),F(100),F(100)],[F(993,1000),F(2,1000),F(5,1000)],F(1,100))
        self.assertEqual((strict,weak),(50,70))
        self.assertEqual(es([F(0),F(100),F(200)],[F(985,1000),F(10,1000),F(5,1000)],F(1,100)),150)
        q=F(1,100);m=1000
        self.assertEqual(F(20)-F(1,m)/q,F(199,10))
        self.assertGreater(math.log(1e12),math.log(1e6)) # divergent truncated E[1/X]

    def test_09_general_cell_transport_certificate(self):
        rng=random.Random(120009)
        for _ in range(200):
            losses=[F(rng.randint(-100,200)) for _ in range(6)]
            p=[F(1,6)]*6;representatives=[losses[i] for i in [0,2,4]]
            cell_mass=[F(1,3)]*3;w=[F(1,2),F(1,4),F(1,4)]
            d=sum(p[i]*abs(losses[i]-representatives[i//2]) for i in range(6))
            tv=sum(abs(x-y) for x,y in zip(cell_mass,w))/2
            radius=max(representatives)-min(representatives);q=F(1,4)
            self.assertLessEqual(abs(es(losses,p,q)-es(representatives,w,q)),(d+radius*tv)/q)

    def test_10_continuous_and_finite_entropy_clearing(self):
        b=2-1/math.log(2);q2=2*b-.5;p=[1-q2,q2];prior=[.5,.5]
        self.assertAlmostEqual(.25*p[0]+.75*p[1],b,places=14)
        self.assertAlmostEqual(2-math.sqrt(2),.5857864376269,places=12)
        self.assertNotAlmostEqual(q2,2-math.sqrt(2),places=3)
        lam=-2*math.log(p[1]/p[0]);dual=-lam*b-math.log(sum(pi*math.exp(-lam*a) for pi,a in zip(prior,[.25,.75])))
        self.assertAlmostEqual(entropy_objective(p,prior,[0,0],1),dual,places=12)
        self.assertFalse(.25<=.9<=.75) # infeasible coarse moment, not continuous infeasibility.
        # Singular and infinite-cell-cost cases fail the stated finite certificate.
        self.assertFalse(all(math.isfinite(c) for c in [math.inf,math.inf]))
        # Uniform densities on [0,epsilon] approach mean0 only with diverging entropy.
        means=[2.0**(-j)/2 for j in range(1,20)]
        entropies=[math.log(2.0**j) for j in range(1,20)]
        self.assertTrue(all(x>0 for x in means))
        self.assertLess(means[-1],1e-6)
        self.assertGreater(entropies[-1],13)

    def test_10_dual_gap_controls_price_and_probability_error(self):
        prior=[.2,.3,.5];cost=[.2,-.4,.7];tau=1.3;star=softmax_cost(cost,prior,tau)
        dual=-tau*math.log(sum(p*math.exp(-c/tau) for p,c in zip(prior,cost)))
        for p in [[.2,.3,.5],[.3,.3,.4],[.1,.6,.3]]:
            gap=entropy_objective(p,prior,cost,tau)-dual
            self.assertGreaterEqual(gap,-1e-14)
            self.assertLessEqual(sum(abs(x-y) for x,y in zip(p,star)),math.sqrt(2*gap/tau)+1e-12)

    def test_11_joint_affiliate_stress_exceeds_marginal_proxy(self):
        groups=[F(50)+F(50),F(60),F(40)]
        requirements={k:max(sum(c) for c in itertools.combinations(groups,k)) for k in (1,2)}
        self.assertEqual(requirements,{1:F(100),2:F(160)})
        self.assertEqual(requirements[2]-20,140)
        self.assertEqual(requirements[2]-20-139,1)
        # The .99 quantile is zero, yet the specified joint outcome is in the catalogue.
        law=[(F(0),F(199,200)),(F(100),F(1,200))]
        quantile=next(x for x,_ in law if sum(p for y,p in law if y<=x)>=F(99,100))
        self.assertEqual(quantile,0)
        self.assertEqual(sum(max(F(100)-10,0) for _ in range(2)),180)
        self.assertEqual(max(F(100)-20,0),80) # stressed collateral, not nominal80.
        exposures=[F(100),F(70),F(60)]
        separate=max(exposures[0],exposures[1]+exposures[2]);combined=sum(exposures[:2])
        self.assertEqual((separate,combined),(130,170))
        self.assertEqual(max(separate,combined-100),130)
        self.assertLess(max(separate,max(exposures)),combined) # k=1 is insufficient.
        self.assertEqual(max(F(70)-30-20,0),20) # lawful netting.
        self.assertEqual(max(F(70)-20,0)+max(-F(30),0),50) # separate sets.

    def test_11_currency_deadline_provider_and_borrowing_ledger(self):
        def balance(initial,receipts,borrowings,due,deadline,currency):
            return initial.get(currency,F(0))+sum(v for c,t,v in receipts if c==currency and t<=deadline)+sum(v for c,t,v in borrowings if c==currency and t<=deadline)-sum(v for c,t,v in due if c==currency and t<=deadline)
        initial={'USD':F(20)};due=[('USD',1,F(100))];late=[('USD',2,F(80))]
        self.assertEqual(balance(initial,late,[],due,1,'USD'),-80)
        line=[('USD',0,F(80))];repayment=due+[('USD',3,F(80))]
        self.assertEqual(balance(initial,late,line,repayment,1,'USD'),0)
        self.assertEqual(balance(initial,late,line,repayment,3,'USD'),0)
        self.assertEqual(balance(initial,late,[],repayment,1,'USD'),-80)
        for failed in itertools.combinations(range(4),2):
            self.assertEqual(sum(F(40) for i in range(4) if i not in failed),80)
        self.assertEqual(balance({'EUR':F(100)},[],[],due,1,'USD'),-100)
        self.assertEqual(balance({},[('USD',0,F(100))],[],due,1,'USD'),0)

    def test_12_exact_marks_cash_and_cumulative_causal_response(self):
        x=F(1,10);average=x/(1+x);terminal=1-(1+x)**-2
        self.assertEqual(average,F(1,11));self.assertEqual(terminal,F(21,121))
        h,q,p0,r=F(10),F(1),F(1),F(100)
        proceeds=p0*r*q/(r+q);mark=p0*(1+q/r)**-2
        loss=q*p0-proceeds+(h-q)*(p0-mark)
        self.assertEqual(loss,h*p0-(proceeds+(h-q)*mark))
        response=causal_response([.02,0],[[0,.2],[.2,0]],[1,1])
        self.assertAlmostEqual(response[0],.0235966695,places=9)
        self.assertAlmostEqual(response[1],.0091147956,places=9)
        self.assertLessEqual(max(response),.02/(1-.4))
        # Asset unit changes scale reserve and sale coefficient together.
        self.assertEqual(F(2,10),F(200,1000));self.assertEqual(F(2)*F(10),F(2,100)*F(1000))

    def test_13_coefficient_crossing_and_gap_are_independent(self):
        f,p,gamma,lg,v=F(1),F(2),F(3),F(1,2),F(1,10)
        for u,expected in [(F(3,5),False),(F(9,20),True)]:
            post=p-gamma*f+gamma*f*u;rho=gamma*lg*f*u/post;gap=v+f*u-post
            criterion=(1-p/(gamma*f)<u<min((gamma*f-p)/((1-lg)*gamma*f),(v+gamma*f-p)/((gamma-1)*f)))
            self.assertTrue(rho>1);self.assertEqual(post>0 and rho>1 and gap>0,criterion);self.assertEqual(criterion,expected)
        for u in [F(i,100) for i in range(34,100)]:
            post=p-gamma*f+gamma*f*u;rho=gamma*lg*f*u/post;gap=v+f*u-post
            self.assertEqual(rho>1 and gap>0,u<min((gamma*f-p)/((1-lg)*gamma*f),(v+gamma*f-p)/((gamma-1)*f)))

    def test_14_external_funding_keeps_a_nonzero_sensitivity_region(self):
        k,lam,a,v,beta,z=F(2,5),F(1),F(1,2),F(1,10),F(1,2),F(1,50)
        gain=k*lam+(k*a+v)*beta
        self.assertEqual(gain,F(11,20));self.assertEqual(z/(1-gain),F(2,45))
        self.assertEqual(k*lam+(k*a+v)*2,1)

    def test_15_actual_buyback_cash_inventory_and_failure(self):
        cash,target,curve,fee=F(150),F(100),F(20),F(1,5)
        acquired=F(1000)*curve/(1000+curve);debit=curve+fee
        self.assertEqual(cash-debit,F(649,5));self.assertGreaterEqual(cash-debit,target)
        self.assertEqual(debit-acquired,F(151,255))
        favorable=F(1100)*acquired/(1000+acquired)-debit
        adverse=F(800)*acquired/(1000+acquired)-debit
        self.assertEqual(favorable,F(62,65));self.assertEqual(adverse,F(-313,65))
        expected=F(94,100)*favorable+F(5,100)*adverse-F(1,100)*fee
        self.assertEqual(expected,F(17,26));self.assertGreater(expected,0)
        self.assertEqual(cash-fee,F(749,5)) # failed trade has no acquired inventory.
        # Existing inventory changes incremental executable exit proceeds.
        old=F(100);pool_s,pool_m=F(1100),F(1000)
        incremental=pool_s*(old+acquired)/(pool_m+old+acquired)-pool_s*old/(pool_m+old)
        self.assertLess(incremental,pool_s*acquired/(pool_m+acquired))

    def test_15_predictable_window_gate_and_lag_uncertainty(self):
        p=[F(1,100),F(2,100),F(1,100)];q=F(5,100)
        union=1-math.prod(float(1-x) for x in p)
        self.assertLessEqual(union,float(sum(p)));self.assertLessEqual(sum(p),q)
        mu,phi,old,sigma=.9,.8,.6,.1
        def forecast(d):
            mean=mu+phi**(d+1)*(old-mu)
            variance=sigma*sigma*(1-phi**(2*(d+1)))/(1-phi*phi)
            return math.exp(-(1-mean)**2/(2*variance))
        self.assertAlmostEqual(forecast(0),.0030887154,places=8)
        self.assertGreater(forecast(5),.53)
        self.assertLess(phi**5,1)

    def test_15_post_action_target_and_complete_positive_gate(self):
        cash,target,r=F(200),F(150),F(1,2)
        old_budget=r*(cash-target);post_target=F(190)
        self.assertEqual(old_budget,25)
        self.assertEqual(cash-old_budget-post_target,-15)
        admitted=min(old_budget,cash-post_target)
        self.assertEqual(admitted,10)
        self.assertGreaterEqual(cash-admitted,post_target)
        cash,target,r=F(150),F(100),F(1,2)
        outcomes=[(F(94,100),F(101,5),F(62,65)),(F(5,100),F(101,5),F(-313,65)),(F(1,100),F(1,5),F(-1,5))]
        budget=r*(cash-target)
        self.assertGreaterEqual(budget,max(c for _,c,_ in outcomes))
        self.assertGreaterEqual(cash/F(150),F(1,2))
        self.assertEqual(sum(p for p,_,net in outcomes if net<0),F(6,100))
        self.assertEqual(sum(p*net for p,_,net in outcomes),F(17,26))
        self.assertTrue(all(cash-c>=target and cash-c>=80 for _,c,_ in outcomes))

    def test_15_future_fill_selection_and_innovation_dependence(self):
        # Authorized at time0; the delayed fill occurs exactly on the bad outcome.
        bad=F(1,20);authorized=F(1);fill=bad;q=bad
        self.assertEqual(bad,authorized*q)
        self.assertGreater(bad,fill*q)
        # Two identical Rademacher innovations satisfy individual MGF bounds,
        # but the second fails the conditional centered-innovation premise.
        correlated_variance=sum(F(1,2)*(2*z)**2 for z in [-1,1])
        independent_variance=sum(F(1,4)*(a+b)**2 for a,b in itertools.product([-1,1],repeat=2))
        self.assertEqual((correlated_variance,independent_variance),(4,2))
        self.assertGreater(math.exp(1),math.exp(.5)) # conditional MGF at first sign+1.

    def test_16_profit_optimized_over_size_and_abstention(self):
        self.assertEqual(-2*F(1,100)*1,F(-1,50))
        self.assertGreater(F(-1,50),-2*F(1,100)*10)
        for gain,fee,cost in itertools.product([F(0),F(1,100),F(1,2)],[F(0),F(1,100)],[F(0),F(1,10)]):
            coefficient=gain-2*fee;bound=max(0,F(10)*coefficient-cost)
            observed=[F(0)]+[F(i,10)*coefficient-cost for i in range(1,101)]
            self.assertEqual(max(observed),bound)

    def test_18_e_process_false_alarm_and_exact_power(self):
        p0,p1,alpha=.01,.05,.05;lam=(p1-p0)/(1-p0)
        self.assertAlmostEqual((1-p0)*(1-lam)+p0*(1+lam*(1/p0-1)),1,places=14)
        n=1000;k=likelihood_threshold(n,p0,p1,alpha)
        self.assertGreater(binomial_tail(n,p1,k),.999)
        self.assertLess(binomial_tail(n,p0,k),alpha)
        # Exact enumeration of a small stopped process verifies the anytime budget.
        n=12;p0,p1,alpha=.2,.6,.2;total=0.0
        for path in itertools.product([0,1],repeat=n):
            e=1;crossed=False
            for bit in path:
                e*=p1/p0 if bit else (1-p1)/(1-p0)
                crossed|=e>=1/alpha-1e-12
            if crossed:total+=p0**sum(path)*(1-p0)**(n-sum(path))
        self.assertLessEqual(total,alpha+1e-12)

    def test_18_funded_deadline_schedule_and_path_independence(self):
        good=schedule(['A','B']);bad=schedule(['B','A'])
        self.assertEqual(good[:3],(5,0,0));self.assertEqual(bad[:3],(5,0,1))
        self.assertEqual(sum(good[3]),sum(bad[3]))
        r,m=F(100),F(120)
        first=m*F(3)/(r+3);m2=m-first;r2=r+3
        second=m2*F(7)/(r2+7)
        self.assertEqual(first+second,m*10/(r+10))

    def test_source_binding(self):
        path=Path(__file__).with_name('amm-aware-central-counterparty-risk.tex')
        expected=Path(__file__).with_name('source.sha256').read_text().split()[0]
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),expected)
        print('UPGRADE_TESTED_SOURCE_SHA256',expected)


if __name__=='__main__':unittest.main(verbosity=2)
