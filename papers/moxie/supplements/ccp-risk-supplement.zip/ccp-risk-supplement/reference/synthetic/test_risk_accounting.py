"""Exact mathematical and reference-state checks, bound to the integrated P12 source.

These checks exercise the proposal's equations and a small legal-event ledger.
They are not tests of deployed clearing, legal feeds, or empirical calibration.
Run with python3 -B out/test_proposal.py, and repeat with -O.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import hashlib
import random
import unittest


def positive(x):
    return max(x, F(0))


def waterfill(target, weights, caps):
    allocation = [F(0) for _ in caps]
    active = {i for i, c in enumerate(caps) if c > 0 and weights[i] > 0}
    remaining = min(target, sum(caps))
    while active and remaining:
        rate = remaining / sum(weights[i] for i in active)
        capped = {i for i in active if rate * weights[i] >= caps[i]}
        if not capped:
            for i in active:
                allocation[i] = rate * weights[i]
            break
        for i in capped:
            allocation[i] = caps[i]
            remaining -= caps[i]
        active -= capped
    return allocation


@dataclass(frozen=True)
class Account:
    loss: F
    gross: F
    senior: F
    subordinate: F
    weight: F
    profit: F


def clear(book, equity, fund, kappa):
    eligible = [positive(r.gross-r.senior) for r in book]
    deficit = [positive(r.senior-r.gross) for r in book]
    seizure = [min(r.loss, c) for r, c in zip(book, eligible)]
    funded_b = [min(r.subordinate, c-s) for r, c, s in zip(book, eligible, seizure)]
    deficit_b = [r.subordinate-b for r, b in zip(book, funded_b)]
    caps = [min(kappa*c, c-s-b) if r.loss <= c and r.weight > 0 else F(0)
            for r, c, s, b in zip(book, eligible, seizure, funded_b)]
    residual = sum(r.loss-s for r, s in zip(book, seizure))
    e = min(residual, equity)
    residual -= e
    d = min(residual, fund)
    residual -= d
    social = waterfill(residual, [r.weight for r in book], caps)
    residual -= sum(social)
    profit = sum(r.profit for r in book)
    adl = [r.profit*min(residual, profit)/profit if profit else F(0) for r in book]
    residual -= sum(adl)
    return eligible, deficit, seizure, funded_b, deficit_b, caps, e, d, social, adl, residual


def es(losses, probabilities, q):
    if not 0 < q <= 1 or sum(probabilities) != 1 or min(probabilities) < 0:
        raise ValueError('invalid law or tail mass')
    remaining, value = q, F(0)
    for loss, probability in sorted(zip(losses, probabilities), reverse=True):
        take = min(remaining, probability)
        value += take * loss
        remaining -= take
        if not remaining:
            return value/q
    raise ValueError('incomplete law')


def ru_es(losses, probabilities, q):
    return min(v + sum(p*positive(x-v) for x, p in zip(losses, probabilities))/q
               for v in losses)


def loss_w1(losses_a, probs_a, losses_b, probs_b):
    # Exact integral of the CDF gap; separate from the ES implementation.
    knots = sorted(set(losses_a + losses_b))
    value = F(0)
    for left, right in zip(knots, knots[1:]):
        fa = sum(p for x, p in zip(losses_a, probs_a) if x <= left)
        fb = sum(p for x, p in zip(losses_b, probs_b) if x <= left)
        value += (right-left)*abs(fa-fb)
    return value


def linear_solve(rows, rhs):
    n = len(rhs)
    a = [[F(v) for v in row]+[F(value)] for row, value in zip(rows, rhs)]
    for col in range(n):
        pivot = next((r for r in range(col, n) if a[r][col]), None)
        if pivot is None:
            return None
        a[col], a[pivot] = a[pivot], a[col]
        v = a[col][col]
        a[col] = [x/v for x in a[col]]
        for r in range(n):
            if r != col:
                v = a[r][col]
                a[r] = [x-v*y for x, y in zip(a[r], a[col])]
    return [row[-1] for row in a]


def robust_line_lp(losses, p0, p1, q):
    """Exact joint LP vertex enumeration: variables (theta,z_1,...,z_J).

    The probability law is p0+theta*(p1-p0), 0<=theta<=1.
    This enumerates vertices of the joint LP, not vertices of the law set.
    """
    n = len(losses)
    dimension = n+1
    eq = [F(0)]+[F(1)]*n
    constraints = [([-F(1)]+[F(0)]*n, F(0)),
                   ([F(1)]+[F(0)]*n, F(1))]
    for j in range(n):
        lower = [F(0)]*dimension
        lower[j+1] = -F(1)
        constraints.append((lower, F(0)))
        upper = [F(0)]*dimension
        upper[0] = -(p1[j]-p0[j])
        upper[j+1] = q
        constraints.append((upper, p0[j]))
    best = None
    witness = None
    for chosen in combinations(constraints, n):
        point = linear_solve([eq]+[row for row, _ in chosen], [F(1)]+[b for _, b in chosen])
        if point is None:
            continue
        if any(sum(a*x for a, x in zip(row, point)) > b for row, b in constraints):
            continue
        value = sum(z*x for z, x in zip(point[1:], losses))
        if best is None or value > best:
            best, witness = value, point
    if best is None:
        raise ValueError('infeasible robust ES LP')
    return best, witness


class Pot:
    def __init__(self, balance, reserved=0, encumbered=0):
        self.balance = F(balance)
        self.reserved = F(reserved)
        self.encumbered = F(encumbered)

    @property
    def free(self):
        return positive(self.balance-self.reserved-self.encumbered)

    @property
    def deficit(self):
        return positive(self.reserved+self.encumbered-self.balance)

    def external_debit(self, amount):
        if amount > self.balance:
            raise ValueError('debit exceeds funded cash')
        self.balance -= amount

    def transfer(self, target, amount):
        if amount < 0 or amount > self.free:
            raise ValueError('insufficient available funding')
        self.balance -= amount
        target.balance += amount


def validate_disjoint_pots(pots):
    seen = set()
    for units in pots.values():
        if seen.intersection(units):
            raise ValueError('one funded unit assigned twice')
        seen.update(units)


class LegalLedger:
    """Reference local atomic state, with explicit future effective events."""
    def __init__(self):
        self.generation = 0
        self.active = []
        self.future = []

    def observe(self, event_id, effective, observed, forbidden):
        event = (event_id, effective, observed, set(forbidden))
        if effective <= observed:
            self.active.append(event)
        else:
            self.future.append(event)
        self.generation += 1

    def activate(self, now):
        ready = [e for e in self.future if e[1] <= now]
        self.future = [e for e in self.future if e[1] > now]
        self.active.extend(ready)
        self.generation += len(ready)

    def eligible(self, action):
        return all(action not in event[3] for event in self.active)

    def dispatch(self, action, prepared_generation):
        # Validation and the commit result are one local state transition.
        return prepared_generation == self.generation and self.eligible(action)


class Receivable:
    def __init__(self, assessed):
        self.assessed = F(assessed)
        self.collected = F(0)
        self.discharged = F(0)
        self.ids = set()

    @property
    def outstanding(self):
        return self.assessed-self.collected-self.discharged

    def collect(self, identifier, payer, payee, due, eligible):
        if identifier in self.ids:
            return F(0)
        if not due or not eligible:
            return F(0)
        amount = min(self.outstanding, payer.free)
        payer.transfer(payee, amount)
        self.collected += amount
        self.ids.add(identifier)
        return amount


class CollectionReservations:
    """Reference single-obligation state with jointly reserved payer funding."""
    def __init__(self, assessed):
        self.assessed=F(assessed)
        self.applied=F(0)
        self.discharged=F(0)
        self.commands={}
        self.physical_receipts=set()
        self.refund_liability=F(0)

    @property
    def reserved(self):
        return sum(command['remaining'] for command in self.commands.values())

    @property
    def collectible(self):
        return self.assessed-self.applied-self.discharged-self.reserved

    def reserve(self, command_id, amount, payer, payee, legal, prepared_generation):
        if command_id in self.commands:
            return F(0)
        if not legal.dispatch('collect',prepared_generation):
            return F(0)
        amount=min(F(amount),self.collectible,payer.free)
        if amount <= 0:
            return F(0)
        payer.reserved += amount
        self.commands[command_id]={'remaining':amount,'payer':payer,'payee':payee,
                                   'generation':prepared_generation}
        return amount

    def discharge(self, amount):
        if amount > self.collectible:
            raise ValueError('discharge overlaps unresolved collection')
        self.discharged += amount

    def no_effect(self, command_id, terminal_and_fenced):
        if not terminal_and_fenced:
            return False
        command=self.commands[command_id]
        command['payer'].reserved -= command['remaining']
        command['remaining']=F(0)
        return True

    def receipt(self, command_id, physical_id, amount, terminal=True):
        if physical_id in self.physical_receipts:
            return F(0)
        command=self.commands[command_id]
        payer,payee=command['payer'],command['payee']
        amount=F(amount)
        if amount < 0 or amount > payer.balance:
            raise ValueError('physical balance reconciliation required')
        # The actual transfer is booked despite subsequent legal-generation changes.
        payer.balance -= amount
        payee.balance += amount
        applied=min(amount,command['remaining'],self.assessed-self.applied-self.discharged)
        self.applied += applied
        command['remaining'] -= applied
        payer.reserved -= applied
        excess=amount-applied
        self.refund_liability += excess
        payee.encumbered += excess
        if terminal:
            payer.reserved -= command['remaining']
            command['remaining']=F(0)
        self.physical_receipts.add(physical_id)
        return amount


class ProposalChecks(unittest.TestCase):
    def test_6000_priority_books_and_permutation(self):
        rng = random.Random(20260905)
        for _ in range(6000):
            book = []
            for _ in range(rng.randrange(1, 8)):
                loss = F(rng.randrange(201)) if rng.randrange(3) else F(0)
                profit = F(rng.randrange(201)) if not loss else F(0)
                book.append(Account(loss, F(rng.randrange(201)), F(rng.randrange(241)),
                                    F(rng.randrange(101)), F(rng.randrange(6)), profit))
            equity, fund, kappa = F(rng.randrange(80)), F(rng.randrange(80)), F(rng.randrange(1, 10), 10)
            result = clear(book, equity, fund, kappa)
            cs, ds, ss, bs, dbs, caps, e, d, social, adl, residual = result
            for row, c, ds0, seized, b, db, cap, debit, cut in zip(book, cs, ds, ss, bs, dbs, caps, social, adl):
                self.assertEqual(row.gross+ds0, c+row.senior)
                self.assertEqual(row.subordinate, b+db)
                self.assertLessEqual(seized+debit+b, c)
                self.assertLessEqual(seized+debit, row.gross)
                self.assertLessEqual(seized+debit+b+row.senior, row.gross+ds0)
                self.assertTrue(0 <= debit <= cap)
                self.assertTrue(0 <= cut <= row.profit)
                if row.loss <= c and row.weight:
                    deduction = positive(seized+b-(1-kappa)*c)
                    self.assertEqual(cap, kappa*c-deduction)
            total_loss = sum(r.loss for r in book)
            self.assertEqual(total_loss, sum(ss)+e+d+sum(social)+sum(adl)+residual)
            post_loss = sum(positive(r.loss-c) for r, c in zip(book, cs))
            self.assertEqual(residual, positive(post_loss-equity-fund-sum(caps)-sum(r.profit for r in book)))
            order = list(range(len(book)))
            rng.shuffle(order)
            permuted = clear([book[i] for i in order], equity, fund, kappa)
            for column in (0, 1, 2, 3, 4, 5, 8, 9):
                self.assertEqual(permuted[column], [result[column][i] for i in order])
            self.assertEqual((e, d, residual), (permuted[6], permuted[7], permuted[10]))

    def test_senior_priority_and_book_perimeter(self):
        separate = Account(F(90), F(100), F(30), F(0), F(1), F(0))
        result = clear([separate], F(0), F(0), F(1, 5))
        self.assertEqual((result[0][0], result[2][0], result[-1]), (70, 70, 20))
        # If total due90 includes the senior30, the actual prior payment removes
        # 30 from both cash and the total obligation before the next application.
        after_payment = Account(F(90-30), F(100-30), F(0), F(0), F(1), F(0))
        result = clear([after_payment], F(0), F(0), F(1, 5))
        self.assertEqual((result[2][0], result[-1]), (60, 0))
        # A senior deficit remains visible; the waterfall draws no cash.
        deficit = Account(F(90), F(20), F(30), F(50), F(1), F(0))
        result = clear([deficit], F(0), F(0), F(1, 5))
        self.assertEqual((result[1][0], result[2][0], result[4][0], result[-1]), (10, 0, 50, 90))

    def test_survivor_capacity_and_all_adl_losses(self):
        book = [Account(F(100),F(0),F(0),F(0),F(1),F(0)),
                Account(F(90),F(100),F(0),F(0),F(1),F(0)),
                Account(F(0),F(0),F(0),F(0),F(1),F(190))]
        result = clear(book, F(0), F(0), F(1,5))
        self.assertEqual(result[5][1], 10)
        self.assertEqual(result[2][1]+result[8][1], 100)
        self.assertEqual(result[9][2], 90)
        self.assertEqual(result[-1], 0)
        for equity, fund, loss in product((F(0),F(10)), (F(0),F(15)), (F(10),F(80),F(150))):
            book = [Account(loss,F(0),F(0),F(0),F(1),F(0)),
                    Account(F(0),F(100),F(30),F(5),F(2),F(100))]
            result = clear(book,equity,fund,F(1,5))
            a, cap, u = equity+fund, sum(result[5]), sum(r.profit for r in book)
            allocated = sum(result[8])+sum(result[9])
            self.assertEqual(allocated, min(positive(loss-a),cap+u))
            self.assertEqual(result[9][1], min(positive(loss-a-cap),u))
            self.assertLessEqual(allocated, result[5][1]*(loss>a)+u*(loss>a+cap))

    def test_distinct_pots_deficits_receipts_and_cumulative_book(self):
        validate_disjoint_pots({'member':{'u1'},'SIG':{'u2'},'IF':{'u3'}})
        with self.assertRaises(ValueError):
            validate_disjoint_pots({'member':{'u1'},'SIG':{'u2'},'IF':{'u1'}})
        pot = Pot(100, reserved=40, encumbered=30)
        pot.external_debit(50)
        self.assertEqual((pot.balance,pot.free,pot.deficit,pot.reserved,pot.encumbered),(50,0,20,40,30))
        self.assertEqual(pot.balance+pot.deficit,pot.free+pot.reserved+pot.encumbered)
        with self.assertRaises(ValueError):
            pot.transfer(Pot(0),1)
        # Paid receipt remains attributed after spending. Current cash stays zero.
        payer, recipient = Pot(100), Pot(0)
        payer.transfer(recipient, F(40))
        attributed_receipt = F(40)
        recipient.external_debit(F(40))
        self.assertEqual(attributed_receipt,40)
        self.assertEqual((payer.balance,recipient.balance),(60,0))
        # No-flow par-settlement identity, including recipient recredit.
        for p,h,r in product((F(0),F(20),F(40)),(F(0),F(10)),(F(0),F(20))):
            if r>p:
                continue
            a0,u0 = F(100),F(80)
            a,u = a0-p+r,u0-p-h
            self.assertEqual(a+u,a0+u0-2*p-h+r)
            self.assertLessEqual(p+h,a0+u0)

    def test_geometric_cap_with_prior_release(self):
        kappa = F(1,5)
        gross, senior, total = F(100), F(80), F(0)
        initial_gross, initial_c = gross, positive(gross-senior)
        first = kappa*positive(gross-senior)
        gross -= first
        total += first
        senior = F(0)  # Release changes availability; it does not create cash.
        second = kappa*positive(gross-senior)
        gross -= second
        total += second
        self.assertGreater(total,(1-(1-kappa)**2)*initial_c)
        self.assertLessEqual(total,(1-(1-kappa)**2)*initial_gross)

    def test_retained_margin_including_physical_requirement(self):
        prior = F(30)
        path = []
        for stress, physical in ((20,5),(40,35),(15,45),(5,2)):
            prior = max(F(10),F(stress),F(physical),prior)
            path.append(prior)
        self.assertEqual(path,[30,40,45,45])
        for p,stress,physical,h,a in product((F(10),F(20)),(F(0),F(30)),(F(0),F(40)),(F(0),F(50)),(F(1),F(3))):
            funded=max(p,stress,physical,h)
            algebra=positive((a-1)*p-positive(max(stress,physical,h)-p))
            self.assertEqual(algebra,positive(a*p-funded))

    def test_conditional_depeg_sharpness(self):
        for h,upper,probability in product((F(0),F(1,10),F(1,2)),(F(1,2),F(1)),(F(0),F(1,4),F(1))):
            collateral,reserves=F(100),F(25)
            outside=h*reserves
            inside=(upper-h)*collateral+upper*reserves
            expectation=(1-probability)*outside+probability*inside
            bound=h*reserves+(upper-h)*(collateral+reserves)*probability
            self.assertEqual(expectation,bound)

    def test_w1_es_numerical_allowance_and_atoms(self):
        loss,prob=[F(0),F(100)],[F(19,20),F(1,20)]
        q=F(1,10)
        eta=loss_w1(loss,prob,[F(0)],[F(1)])
        self.assertEqual((eta,es(loss,prob,q)),(5,50))
        e,eps=F(-1),F(1)
        self.assertEqual(e+eps+eta/q,50)
        self.assertLess(e+eta/q,es(loss,prob,q))
        self.assertEqual(es([F(0),F(6),F(12)],[F(1,2),F(1,3),F(1,6)],F(1,4)),10)
        rng=random.Random(7712)
        for _ in range(300):
            xs=[F(rng.randrange(-1000,1001)) for _ in range(5)]
            ys=[F(rng.randrange(-1000,1001)) for _ in range(5)]
            p=[F(1,5)]*5
            q=F(rng.randrange(1,11),10)
            self.assertEqual(es(xs,p,q),ru_es(xs,p,q))
            self.assertLessEqual(abs(es(xs,p,q)-es(ys,p,q)),loss_w1(xs,p,ys,p)/q)
        # The general bound remains useful on arbitrarily large finite losses.
        for magnitude in (10,1000,1000000):
            xs=[F(0),F(magnitude)]
            p=[F(1)-F(1,magnitude),F(1,magnitude)]
            self.assertEqual(loss_w1(xs,p,[F(0)],[F(1)]),1)
            self.assertLessEqual(es(xs,p,F(1,10)),10)

    def test_robust_joint_lp_interior_optimum_and_samples(self):
        losses=[F(0),F(10),F(20)]
        p0,p1=[F(0),F(1),F(0)],[F(3,4),F(0),F(1,4)]
        q=F(1,2)
        optimum,witness=robust_line_lp(losses,p0,p1,q)
        self.assertEqual(optimum,F(40,3))
        self.assertEqual(witness[0],F(2,3))
        self.assertEqual(es(losses,p0,q),10)
        self.assertEqual(es(losses,p1,q),10)
        grid=[]
        for k in range(61):
            theta=F(k,60)
            probabilities=[a+theta*(b-a) for a,b in zip(p0,p1)]
            value=es(losses,probabilities,q)
            self.assertLessEqual(value,optimum)
            grid.append(value)
        self.assertEqual(max(grid),optimum)
        self.assertGreater(optimum,max(es(losses,p0,q),es(losses,p1,q)))

    def test_common_set_coherence_and_numeric_example(self):
        p0,p1=[F(1,3),F(2,3)],[F(2,3),F(1,3)]
        q=F(3,4)
        def robust(loss):
            return robust_line_lp([F(x) for x in loss],p0,p1,q)[0]
        x,y=[6,0],[0,3]
        self.assertEqual((robust(x),robust(y),robust([6,3])),(F(16,3),F(8,3),F(17,3)))
        self.assertLessEqual(robust([6,3]),robust(x)+robust(y))
        self.assertEqual(robust([13,7]),robust(x)+7)
        self.assertEqual(robust([18,0]),3*robust(x))
        self.assertEqual(robust([-7,-7]),-7)
        self.assertLessEqual(robust([5,-1]),robust(x))
        p0,p1=[F(2499,2500),F(1,2500)],[F(4997,5000),F(3,5000)]
        exact,_=robust_line_lp([F(0),F(100)],p0,p1,F(1,100))
        forecast=[F(1999,2000),F(1,2000)]
        self.assertEqual(exact,6)
        self.assertEqual(es([F(0),F(100)],forecast,F(1,100)),5)
        self.assertEqual(loss_w1([F(0),F(100)],p1,[F(0),F(100)],forecast),F(1,100))

    def test_unbounded_tail_clipping_certificate_and_unit_scaling(self):
        xs,ys=[F(-100),F(0),F(200)],[F(-50),F(1),F(20)]
        p=[F(1,5),F(3,5),F(1,5)]
        m=F(10)
        clip=lambda x:max(-m,min(m,x))
        xc,yc=[clip(x) for x in xs],[clip(y) for y in ys]
        tx=sum(prob*positive(abs(x)-m) for x,prob in zip(xs,p))
        ty=sum(prob*positive(abs(y)-m) for y,prob in zip(ys,p))
        knots=sorted(set(xc+yc))
        beta=max(abs(sum(prob for x,prob in zip(xc,p) if x<=k)-sum(prob for y,prob in zip(yc,p) if y<=k)) for k in knots)
        self.assertLessEqual(loss_w1(xs,p,ys,p),tx+ty+2*m*beta)
        scale=F(7,3)
        self.assertEqual(loss_w1([scale*x for x in xs],p,[scale*y for y in ys],p),scale*loss_w1(xs,p,ys,p))
        self.assertEqual(es([scale*x for x in xs],p,F(1,10)),scale*es(xs,p,F(1,10)))

    def test_physical_set_hausdorff_bridge(self):
        zero=([F(0)],[F(1)])
        tail=([F(0),F(100)],[F(19,20),F(1,20)])
        set_a,set_b=[zero,tail],[zero]
        def directed(a,b):
            return max(min(loss_w1(*p,*q) for q in b) for p in a)
        delta=max(directed(set_a,set_b),directed(set_b,set_a))
        q,zeta=F(1,10),F(1,5)
        ra=max(es(x,p,q) for x,p in set_a)
        rb=max(es(x,p,q) for x,p in set_b)
        self.assertEqual((delta,ra,rb),(5,50,0))
        self.assertEqual(abs(ra-rb),delta/q)
        ma,mb=(1+zeta)*positive(ra),(1+zeta)*positive(rb)
        self.assertEqual(abs(ma-mb),(1+zeta)*delta/q)

    def test_legal_event_overrides_economic_timer(self):
        ledger=LegalLedger()
        prepared=ledger.generation
        next_economic_change=100
        ledger.observe('order',effective=5,observed=9,forbidden={'close','open'})
        self.assertLess(9,next_economic_change)
        self.assertFalse(ledger.dispatch('close',prepared))
        self.assertFalse(ledger.dispatch('close',ledger.generation))
        self.assertTrue(ledger.dispatch('fund',ledger.generation))
        ledger.observe('future',effective=20,observed=10,forbidden={'port'})
        self.assertTrue(ledger.dispatch('port',ledger.generation))
        prepared=ledger.generation
        ledger.activate(20)
        self.assertFalse(ledger.dispatch('port',prepared))
        self.assertTrue(ledger.dispatch('settle',ledger.generation))

    def test_assessment_is_not_funding_or_duplicate_collection(self):
        payer,payee=Pot(0),Pot(0)
        rec=Receivable(50)
        self.assertEqual((rec.outstanding,payer.balance,payee.balance),(50,0,0))
        self.assertEqual(rec.collect('c1',payer,payee,due=True,eligible=True),0)
        payer.balance=F(100)
        payer.encumbered=F(80)
        self.assertEqual(rec.collect('c2',payer,payee,due=True,eligible=False),0)
        self.assertEqual(rec.collect('c2',payer,payee,due=True,eligible=True),20)
        self.assertEqual((rec.outstanding,payer.balance,payee.balance),(30,80,20))
        self.assertEqual(rec.collect('c2',payer,payee,due=True,eligible=True),0)
        rec.discharged=F(5)
        self.assertEqual((rec.outstanding,payee.balance),(25,20))

    def test_concurrent_collections_reserve_obligation_and_cash(self):
        legal=LegalLedger()
        payer,payee=Pot(100),Pot(0)
        rec=CollectionReservations(50)
        g=legal.generation
        self.assertEqual(rec.reserve('one',50,payer,payee,legal,g),50)
        self.assertEqual(rec.reserve('two',50,payer,payee,legal,g),0)
        self.assertEqual((rec.reserved,rec.collectible,payer.reserved,payer.free),(50,0,50,50))
        with self.assertRaises(ValueError):
            rec.discharge(F(1))
        legal.observe('restriction',effective=1,observed=2,forbidden={'collect'})
        self.assertFalse(rec.no_effect('one',terminal_and_fenced=False))
        self.assertEqual(rec.reserved,50)
        # A stale receipt is still an actual transfer under its original command.
        self.assertEqual(rec.receipt('one','physical-1',50),50)
        self.assertEqual((rec.applied,rec.reserved,payer.balance,payee.balance),(50,0,50,50))
        self.assertEqual(rec.receipt('one','physical-1',50),0)
        self.assertEqual(payee.balance,50)

    def test_excess_receipt_is_cash_and_refund_liability(self):
        legal=LegalLedger()
        payer,payee=Pot(100),Pot(0)
        rec=CollectionReservations(50)
        rec.reserve('one',50,payer,payee,legal,legal.generation)
        rec.receipt('one','physical-1',60)
        self.assertEqual((rec.applied,rec.refund_liability,payer.balance,payee.balance),(50,10,40,60))
        self.assertEqual((payee.encumbered,payee.free),(10,50))
        self.assertEqual(rec.collectible,0)
        self.assertLessEqual(rec.applied+rec.discharged+rec.reserved,rec.assessed)

    def test_partial_receipts_are_distinct_from_command_retries(self):
        legal=LegalLedger()
        payer,payee=Pot(100),Pot(0)
        rec=CollectionReservations(50)
        rec.reserve('one',50,payer,payee,legal,legal.generation)
        self.assertEqual(rec.reserve('one',50,payer,payee,legal,legal.generation),0)
        rec.receipt('one','part-1',20,terminal=False)
        self.assertEqual((rec.applied,rec.reserved,payer.reserved,payee.balance),(20,30,30,20))
        self.assertEqual(rec.receipt('one','part-1',20,terminal=False),0)
        rec.receipt('one','part-2',30,terminal=True)
        self.assertEqual((rec.applied,rec.reserved,payer.reserved,payee.balance),(50,0,0,50))
        # A later distinct excess occurrence is still physical cash, not a retry.
        rec.receipt('one','part-3',10,terminal=True)
        self.assertEqual((rec.applied,rec.refund_liability,payee.balance,payee.free),(50,10,60,50))

    def test_proposal_source_binding(self):
        source_path=Path(__file__).with_name('amm-aware-central-counterparty-risk.tex')
        data=source_path.read_bytes()
        source=data.decode()
        # Digest is checked against a separately generated receipt file.
        expected=Path(__file__).with_name('source.sha256').read_text().split()[0]
        self.assertEqual(hashlib.sha256(data).hexdigest(),expected)
        for expression in (r'C_k:=(G_k-h_k^{\mathrm{sen}})_+',r'G_k+D_k^{\mathrm{sen}}=C_k+h_k^{\mathrm{sen}}',
                           r'\min\{\kappa C_k,F_k\}',r's_k+\ell_k+b_k\le C_k',
                           r'\Delta_k^{\mathrm{prop}}:=\ell_k+\delta_k',
                           r'\max\{B_t(\Pi),M_{\mathrm{req},t^-}(\Pi)\}',
                           r'h_SW_R+(\delta_q-h_S)(W_C+W_R)p_q',
                           r'|\ES_q(P)-\ES_q(\widehat P)|\le\eta/q',
                           r'R^{\mathrm{rec}}:=J-Y-V\ge0',
                           r'Y+V+K^{\mathrm{rec}}\le J',
                           r'|R(\mathcal A)-R(\mathcal B)|\le\delta/q',
                           'commits against that generation atomically',
                           'and containing deterministic cash losses'):
            self.assertIn(expression,source)
        print('TESTED_SOURCE_SHA256',expected)


if __name__=='__main__':
    unittest.main(verbosity=2)
