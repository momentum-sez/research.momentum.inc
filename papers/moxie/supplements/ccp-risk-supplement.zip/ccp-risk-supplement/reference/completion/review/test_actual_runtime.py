"""Independent runtime checks for debt timing and observable cash paths."""

from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "runtime"))

from completion import Action, Debt, Edge, Graph, Node, Payment, Receipt


class IndependentRuntimeTests(unittest.TestCase):
    def test_existing_debt_cannot_settle_after_its_deadline(self):
        debt = Debt("existing", 7, 1)
        with self.assertRaises(ValueError):
            Graph("root", [
                Node("root", 0, (Action("wait", (Edge("late", "end",
                    (Receipt("late-cash", 7, "cash"),),
                    (Payment("late-repayment", 7, "existing"),)),)),), (debt,)),
                Node("end", 3, terminal_other_due=0),
            ], {"cash": 7})

    def test_new_debt_cannot_predate_its_receipt_checkpoint(self):
        debt = Debt("new-loan", 7, 1)
        with self.assertRaises(ValueError):
            Graph("root", [
                Node("root", 0, (Action("wait", (Edge("late", "end",
                    (Receipt("late-draw", 7, "facility", debt),),
                    (Payment("late-repayment", 7, "new-loan"),)),)),)),
                Node("end", 3, terminal_other_due=0),
            ], {"facility": 7})

    def test_receipt_at_debt_deadline_can_fund_edge_repayment(self):
        debt = Debt("existing", 7, 1)
        graph = Graph("root", [
            Node("root", 0, (Action("wait", (Edge("on-time", "end",
                (Receipt("cash", 7, "cash"),),
                (Payment("repayment", 7, "existing"),)),)),), (debt,)),
            Node("end", 1, terminal_other_due=0),
        ], {"cash": 7})
        self.assertEqual(graph.requirements()[0]["root"], 0)
        self.assertEqual(graph.trace(0, {"root": "wait"}, {"root": "on-time"})[-1]["surplus"], "0")

    def test_payment_before_a_later_checkpoint_discharges_debt(self):
        debt = Debt("existing", 7, 1)
        graph = Graph("root", [
            Node("root", 0, (Action("pay", (Edge("later", "end"),),
                (Payment("early-payment", 7, "existing"),)),), (debt,)),
            Node("end", 3, terminal_other_due=0),
        ])
        self.assertEqual(graph.requirements()[0]["root"], 7)

    def test_new_loan_at_its_deadline_can_settle_on_the_same_edge(self):
        debt = Debt("new-loan", 8, 1)
        graph = Graph("root", [
            Node("root", 0, (Action("draw", (Edge("ready", "end",
                (Receipt("draw", 7, "facility", debt),),
                (Payment("repayment", 8, "new-loan"),)),)),)),
            Node("end", 1, terminal_other_due=0),
        ], {"facility": 7})
        self.assertEqual(graph.requirements()[0]["root"], 1)

    def test_repayment_does_not_restore_gross_draw_capacity(self):
        debt = Debt("first-debt", 5, 1)
        with self.assertRaises(ValueError):
            Graph("root", [
                Node("root", 0, (Action("draw", (Edge("ready", "again",
                    (Receipt("first-draw", 5, "facility", debt),),
                    (Payment("first-repayment", 5, "first-debt"),)),)),)),
                Node("again", 1, (Action("draw", (Edge("ready", "end",
                    (Receipt("second-draw", 5, "facility"),)),)),)),
                Node("end", 2, terminal_other_due=0),
            ], {"facility": 5})

    def test_observation_labels_identify_distinct_targets(self):
        with self.assertRaises(ValueError):
            Graph("root", [
                Node("root", 0, (Action("wait", (
                    Edge("same", "low"), Edge("same", "high"))),)),
                Node("low", 1, terminal_other_due=0),
                Node("high", 1, terminal_other_due=100),
            ])

    def test_merged_histories_check_each_resource_use(self):
        with self.assertRaises(ValueError):
            Graph("root", [
                Node("root", 0, (Action("wait", (
                    Edge("unused", "merge"),
                    Edge("used", "merge", (Receipt("first", 5, "facility"),)))),)),
                Node("merge", 1, (Action("draw", (Edge("ready", "end",
                    (Receipt("second", 5, "facility"),)),)),)),
                Node("end", 2, terminal_other_due=0),
            ], {"facility": 5})

    def test_terminal_debt_adds_to_other_terminal_obligations(self):
        graph = Graph("end", [Node("end", 1, debts=(Debt("debt", 8, 2),), terminal_other_due=3)])
        self.assertEqual(graph.requirements()[0]["end"], 11)
        with self.assertRaises(ValueError):
            graph.trace(10, {}, {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
