"""Enumerate finite policies and cash paths without a backward recursion."""

from itertools import product
import json
from math import inf


def terminal(amount=0):
    return {"terminal": amount}


def action(payment, floor, *edges):
    return {"payment": payment, "floor": floor, "edges": edges}


def state(*actions):
    return {"actions": actions}


def policy_threshold(nodes, start, policy):
    """Calculate every required initial balance along each induced path."""
    pending = [(start, 0, 0)]
    required = 0
    while pending:
        name, cash_change, path_required = pending.pop()
        node = nodes[name]
        if "terminal" in node:
            required = max(required, path_required, node["terminal"] - cash_change)
            continue
        if not node["actions"]:
            return inf
        selected = node["actions"][policy[name]]
        if not selected["edges"]:
            raise ValueError("A nonterminal action needs a supported child")
        paid = cash_change - selected["payment"]
        path_required = max(path_required, selected["floor"] - paid)
        for increment, child in selected["edges"]:
            pending.append((child, paid + increment, path_required))
    return required


def exhaustive_threshold(nodes, start):
    """Choose the best complete policy after evaluating all its cash paths."""
    names = [name for name, node in nodes.items() if node.get("actions")]
    choices = [range(len(nodes[name]["actions"])) for name in names]
    return min(
        policy_threshold(nodes, start, dict(zip(names, selected)))
        for selected in product(*choices)
    )


def cases():
    return [
        ("terminal_discharge", {"s": terminal(17)}, 17),
        ("empty_action_set", {"s": state()}, inf),
        ("late_receipt", {
            "s": state(action(100, 0, (100, "t"))), "t": terminal(),
        }, 100),
        ("retained_floor", {
            "s": state(action(20, 15, (100, "t"))), "t": terminal(),
        }, 35),
        ("signed_loss", {
            "s": state(action(10, 0, (-30, "t"))), "t": terminal(),
        }, 40),
        ("maturity_matched_receipt", {
            "s": state(action(0, 0, (60, "pay"))),
            "pay": state(action(100, 0, (0, "t"))), "t": terminal(),
        }, 40),
        ("receipt_removed", {
            "s": state(action(0, 0, (0, "pay"))),
            "pay": state(action(100, 0, (0, "t"))), "t": terminal(),
        }, 100),
        ("facility_with_repayment", {
            "s": state(action(0, 0, (60, "pay"))),
            "pay": state(action(100, 0, (65, "debt"))), "debt": terminal(65),
        }, 40),
        ("unfunded_repayment", {
            "s": state(action(0, 0, (60, "pay"))),
            "pay": state(action(100, 0, (0, "debt"))), "debt": terminal(65),
        }, 105),
        ("unfunded_with_cash_only_route", {
            "s": state(action(0, 0, (60, "draw_pay")), action(0, 0, (0, "cash_pay"))),
            "draw_pay": state(action(100, 0, (0, "debt"))),
            "cash_pay": state(action(100, 0, (0, "t"))),
            "debt": terminal(65), "t": terminal(),
        }, 100),
        ("draw_default_in_support", {
            "s": state(action(0, 0, (60, "funded"), (0, "failed"))),
            "funded": state(action(100, 0, (65, "debt"))),
            "failed": state(action(100, 0, (0, "t"))),
            "debt": terminal(65), "t": terminal(),
        }, 100),
        ("one_shared_facility", {
            "s": state(action(0, 0, (60, "first"))),
            "first": state(action(60, 0, (0, "second"))),
            "second": state(action(60, 0, (120, "debt"))), "debt": terminal(60),
        }, 60),
        ("invalid_capacity_reset", {
            "s": state(action(0, 0, (60, "first"))),
            "first": state(action(60, 0, (60, "second"))),
            "second": state(action(60, 0, (120, "debt"))), "debt": terminal(120),
        }, 0),
        ("action_before_outcome", {
            "s": state(action(0, 0, (0, "zero"), (0, "loss")),
                       action(0, 0, (0, "loss"), (0, "zero"))),
            "zero": terminal(), "loss": terminal(100),
        }, 100),
        ("invalid_action_after_outcome", {
            "s": state(action(0, 0, (0, "left"), (0, "right"))),
            "left": state(action(0, 0, (0, "zero")), action(0, 0, (0, "loss"))),
            "right": state(action(0, 0, (0, "loss")), action(0, 0, (0, "zero"))),
            "zero": terminal(), "loss": terminal(100),
        }, 0),
        ("terminal_four_leaf_losses", {
            "s": state(action(0, 0, (0, "left"), (0, "right"))),
            "left": state(action(0, 0, (0, "a"), (0, "b"))),
            "right": state(action(0, 0, (0, "c"), (0, "d"))),
            "a": terminal(), "b": terminal(), "c": terminal(), "d": terminal(100),
        }, 100),
    ]


def upper_half_es(losses):
    ordered = sorted(losses)
    assert len(ordered) % 2 == 0
    tail = ordered[len(ordered) // 2:]
    return sum(tail) / len(tail)


def main():
    results = {}
    for name, nodes, expected in cases():
        actual = exhaustive_threshold(nodes, "s")
        assert actual == expected, (name, actual, expected)
        results[name] = "infinity" if actual == inf else actual
    static = upper_half_es([0, 0, 0, 100])
    nested = upper_half_es([upper_half_es([0, 0]), upper_half_es([0, 100])])
    assert static == 50 and nested == 100
    results["static_upper_half_es"] = static
    results["nested_upper_half_es"] = nested
    assert results["one_shared_facility"] > results["invalid_capacity_reset"]
    assert results["action_before_outcome"] > results["invalid_action_after_outcome"]
    print(json.dumps({"status": "PASS", "cases": results}, indent=2))


if __name__ == "__main__":
    main()
