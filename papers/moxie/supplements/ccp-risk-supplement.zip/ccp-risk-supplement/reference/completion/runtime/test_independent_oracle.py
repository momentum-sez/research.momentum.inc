"""Retain the independent path oracle's comparisons under optimized Python."""

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "review"))
import adversarial_oracle as oracle


class IndependentOracleTests(unittest.TestCase):
    def test_all_sixteen_cash_path_cases(self):
        for name, nodes, expected in oracle.cases():
            with self.subTest(case=name):
                self.assertEqual(oracle.exhaustive_threshold(nodes, "s"), expected)

    def test_both_risk_values(self):
        self.assertEqual(oracle.upper_half_es([0, 0, 0, 100]), 50)
        self.assertEqual(oracle.upper_half_es([
            oracle.upper_half_es([0, 0]), oracle.upper_half_es([0, 100])]), 100)


if __name__ == "__main__":
    unittest.main(verbosity=2)
