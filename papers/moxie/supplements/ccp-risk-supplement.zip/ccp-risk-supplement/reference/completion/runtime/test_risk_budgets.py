import unittest
from fractions import Fraction as Q

from completion import Action, Edge, Graph, Node


def budget_tree(root_budget):
    return Graph("root", [
        Node("root", 0, (Action("observe", (
            Edge("left", "left", probability=Q(1, 2)),
            Edge("right", "right", probability=Q(1, 2))), tail_mass=Q(1, 2)),), risk_budget=root_budget),
        Node("left", 1, (Action("settle", (
            Edge("zero-a", "ll", probability=Q(1, 2)),
            Edge("zero-b", "lr", probability=Q(1, 2))), tail_mass=Q(1, 2)),), risk_budget=0),
        Node("right", 1, (Action("settle", (
            Edge("zero", "rl", probability=Q(1, 2)),
            Edge("hundred", "rr", probability=Q(1, 2))), tail_mass=Q(1, 2)),), risk_budget=100),
        Node("ll", 2, terminal_other_due=0, risk_budget=0),
        Node("lr", 2, terminal_other_due=0, risk_budget=0),
        Node("rl", 2, terminal_other_due=0, risk_budget=0),
        Node("rr", 2, terminal_other_due=100, risk_budget=100, terminal_economic_loss=100),
    ])


class RiskBudgetTests(unittest.TestCase):
    def test_static_fifty_cannot_carry_conditional_hundred(self):
        with self.assertRaisesRegex(ValueError, "successor risk exceeds"):
            budget_tree(50)

    def test_nested_budget_and_cash_are_both_carried(self):
        graph = budget_tree(100)
        self.assertEqual(graph.requirements()[0]["root"], 100)
        self.assertEqual(graph.admissible("root", 100), ("observe",))

    def test_probability_budget_does_not_pay_every_stress_branch(self):
        graph = Graph("root", [Node("root", 0, (Action("settle", (
            Edge("rare", "rare", probability=Q(1, 100)),
            Edge("normal", "normal", probability=Q(99, 100))), tail_mass=1),), risk_budget=1),
            Node("rare", 1, terminal_other_due=100, risk_budget=100, terminal_economic_loss=100),
            Node("normal", 1, terminal_other_due=0, risk_budget=0)])
        self.assertEqual(graph.requirements()[0]["root"], 100)
        self.assertEqual(graph.admissible("root", 1), ())

    def test_zero_probability_stress_still_needs_cash(self):
        graph = Graph("root", [Node("root", 0, (Action("settle", (
            Edge("stress", "stress", probability=0),
            Edge("model", "model", probability=1)), tail_mass=1),), risk_budget=0),
            Node("stress", 1, terminal_other_due=100, risk_budget=100, terminal_economic_loss=100),
            Node("model", 1, terminal_other_due=0, risk_budget=0)])
        self.assertEqual(graph.requirements()[0]["root"], 100)

    def test_terminal_loss_cannot_exceed_terminal_budget(self):
        with self.assertRaisesRegex(ValueError, "Terminal economic loss"):
            Graph("end", [Node("end", 0, terminal_other_due=0,
                risk_budget=5, terminal_economic_loss=6)])

    def test_edge_loss_is_added_to_successor_budget(self):
        with self.assertRaisesRegex(ValueError, "successor risk exceeds"):
            Graph("root", [Node("root", 0, (Action("advance", (
                Edge("ok", "end", probability=1, economic_loss=3),), tail_mass=1),), risk_budget=12),
                Node("end", 1, terminal_other_due=0, risk_budget=10)])

    def test_all_nodes_need_budgets_in_opted_in_profile(self):
        with self.assertRaisesRegex(ValueError, "every state"):
            Graph("root", [Node("root", 0, (Action("advance", (Edge("ok", "end"),)),), risk_budget=1),
                Node("end", 1, terminal_other_due=0)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
