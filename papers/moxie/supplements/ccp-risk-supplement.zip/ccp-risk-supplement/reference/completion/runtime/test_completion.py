import unittest
from fractions import Fraction as Q
from itertools import product
from math import inf

from completion import Action, Debt, Edge, Graph, Node, Payment, Receipt
from completion import expected_shortfall, nested_es, static_es


def facility_graph(receivable=65, failure=False, include_cash_route=False):
    debt = Debt("facility-debt", 65, 3)
    funded = Edge("delivered", "pay-funded", (Receipt("draw-60", 60, "facility", debt),))
    draw_edges = (funded,)
    nodes = [
        Node("pay-funded", 1, (Action("perform", (Edge("earned", "repay", (
            Receipt("earned-receipt", receivable, "earned"),)),),
            (Payment("customer-payment", 100),)),), (debt,)),
        Node("repay", 3, debts=(debt,), terminal_other_due=0),
    ]
    if failure or include_cash_route:
        nodes.append(Node("pay-cash", 1, terminal_other_due=100))
    if failure:
        draw_edges += (Edge("provider-failure", "pay-cash"),)
    actions = (Action("draw", draw_edges),)
    if include_cash_route:
        actions += (Action("own-cash", (Edge("ready", "pay-cash"),)),)
    return Graph("start", [Node("start", 0, actions)] + nodes,
                 {"facility": 60, "earned": receivable})


def four_leaf_funding():
    return Graph("root", [
        Node("root", 0, (Action("continue", (Edge("left", "left"), Edge("right", "right"))),)),
        Node("left", 1, (Action("continue", (Edge("low", "ll"), Edge("high", "lr"))),)),
        Node("right", 1, (Action("continue", (Edge("low", "rl"), Edge("high", "rr"))),)),
        Node("ll", 2, terminal_other_due=0), Node("lr", 2, terminal_other_due=0),
        Node("rl", 2, terminal_other_due=0), Node("rr", 2, terminal_other_due=100),
    ])


def feasible_by_forward_search(graph, node, cash):
    """Independent feasibility search. It does not call the backward calculation."""
    state = graph.nodes[node]
    if state.terminal_due is not None:
        return cash >= state.terminal_due
    for action in state.actions:
        after = cash - action.cost
        if after < action.floor:
            continue
        if all(feasible_by_forward_search(graph, edge.target, after + edge.increment)
               for edge in action.edges):
            return True
    return False


class CompletionTests(unittest.TestCase):
    def test_four_leaf_static_and_nested_risk(self):
        tree = ((Q(1, 2), ((Q(1, 2), 0), (Q(1, 2), 0))),
                (Q(1, 2), ((Q(1, 2), 0), (Q(1, 2), 100))))
        self.assertEqual(static_es(tree, Q(1, 2)), 50)
        self.assertEqual(nested_es(tree, Q(1, 2)), 100)

    def test_initial_static_margin_does_not_fund_completion(self):
        graph = four_leaf_funding()
        req, _ = graph.requirements()
        self.assertEqual(req["root"], 100)
        self.assertEqual(req["left"], 0)
        self.assertEqual(req["right"], 100)
        self.assertEqual(graph.admissible("root", 50), ())
        self.assertEqual(graph.admissible("root", 100), ("continue",))

    def test_funded_facility_preserves_useful_subnotional_cash(self):
        graph = facility_graph()
        self.assertEqual(graph.requirements()[0]["start"], 40)
        trace = graph.trace(40, {"start": "draw", "pay-funded": "perform"},
                            {"start": "delivered", "pay-funded": "earned"})
        self.assertEqual(trace[-1]["terminal_payment"], "65")
        self.assertEqual(trace[-1]["surplus"], "0")

    def test_borrowing_does_not_create_equity(self):
        self.assertEqual(facility_graph(receivable=0).requirements()[0]["start"], 105)
        self.assertEqual(facility_graph(receivable=0, include_cash_route=True).requirements()[0]["start"], 100)

    def test_provider_failure_is_a_supported_branch(self):
        graph = facility_graph(failure=True)
        self.assertEqual(graph.requirements()[0]["start"], 100)
        self.assertEqual(graph.admissible("start", 40), ())

    def test_observation_selects_a_funded_continuation(self):
        funded = facility_graph()
        shifted = [Node(n.identity, n.stage + 1, n.actions,
                        tuple(Debt(d.identity, d.amount, d.deadline + 1) for d in n.debts),
                        n.terminal_other_due) for n in funded.nodes.values()]
        debt = Debt("facility-debt", 65, 4)
        shifted = [n for n in shifted if n.identity != "start"]
        shifted.append(Node("start", 1, (Action("draw", (Edge("delivered", "pay-funded", (
            Receipt("draw-60", 60, "facility", debt),)),)),)))
        observe = Action("observe", (Edge("low", "small"), Edge("high", "start")))
        graph = Graph("observe", [Node("observe", 0, (observe,)),
            Node("small", 1, terminal_other_due=20)] + shifted, funded.resource_limits)
        self.assertEqual(graph.requirements()[0]["observe"], 40)
        low = graph.trace(40, {"observe": "observe"}, {"observe": "low"})
        self.assertEqual(low[-1]["terminal_payment"], "20")
        high = graph.trace(40, {"observe": "observe", "start": "draw", "pay-funded": "perform"},
            {"observe": "high", "start": "delivered", "pay-funded": "earned"})
        self.assertEqual(high[-1]["terminal_payment"], "65")

    def test_loan_debt_cannot_disappear_in_child(self):
        debt = Debt("loan", 65, 2)
        with self.assertRaisesRegex(ValueError, "retain every unpaid debt"):
            Graph("root", [Node("root", 0, (Action("draw", (Edge("ok", "end", (
                Receipt("draw", 60, "facility", debt),)),)),)),
                Node("end", 2, terminal_other_due=0)], {"facility": 60})

    def test_terminal_cash_includes_all_retained_debt(self):
        graph = Graph("end", [Node("end", 1, debts=(Debt("loan", 65, 1),), terminal_other_due=12)])
        self.assertEqual(graph.requirements()[0]["end"], 77)

    def test_current_debt_must_be_paid_before_departure(self):
        debt = Debt("old", 15, 0)
        with self.assertRaisesRegex(ValueError, "current debt unpaid"):
            Graph("root", [Node("root", 0, (Action("defer", (Edge("ok", "end"),)),), (debt,)),
                           Node("end", 1, debts=(debt,), terminal_other_due=0)])

    def test_exact_repayment_releases_debt_once(self):
        debt = Debt("old", 15, 0)
        graph = Graph("root", [Node("root", 0, (Action("repay", (Edge("ok", "end"),),
            (Payment("old-payment", 15, "old"),)),), (debt,)), Node("end", 1, terminal_other_due=0)])
        self.assertEqual(graph.requirements()[0]["root"], 15)

    def test_late_receipt_cannot_fund_current_payment(self):
        graph = Graph("pay", [Node("pay", 0, (Action("pay", (Edge("later", "end", (
            Receipt("receipt", 100, "receivable"),)),), (Payment("due-now", 100),)),)),
            Node("end", 1, terminal_other_due=0)], {"receivable": 100})
        self.assertEqual(graph.requirements()[0]["pay"], 100)

    def test_hidden_outcome_cannot_select_the_prior_action(self):
        hedge_left = Action("hedge-left", (
            Edge("left", "end", (Receipt("left-win", 100, "hedge"),)), Edge("right", "end")))
        hedge_right = Action("hedge-right", (
            Edge("left", "end"), Edge("right", "end", (Receipt("right-win", 100, "hedge"),))))
        nodes = [Node("root", 0, (hedge_left, hedge_right)),
            Node("end", 1, terminal_other_due=100)]
        graph = Graph("root", nodes, {"hedge": 100})
        self.assertEqual(graph.requirements()[0]["root"], 100)
        clairvoyant = max(min(100 - 100, 100), min(100, 100 - 100))
        self.assertEqual(clairvoyant, 0)

    def test_retained_floor_has_its_own_requirement(self):
        graph = Graph("pay", [Node("pay", 0, (Action("settle", (Edge("ok", "end"),),
            (Payment("payment", 20),), floor=30),)), Node("end", 1, terminal_other_due=0)])
        self.assertEqual(graph.requirements()[0]["pay"], 50)

    def test_one_facility_cannot_fund_two_draws_beyond_limit(self):
        with self.assertRaisesRegex(ValueError, "resource beyond its limit"):
            Graph("root", [Node("root", 0, (Action("draw", (Edge("ok", "again", (
                Receipt("first", 60, "facility"),)),)),)),
                Node("again", 1, (Action("draw", (Edge("ok", "end", (
                Receipt("second", 60, "facility"),)),)),)), Node("end", 2, terminal_other_due=120)],
                {"facility": 60})

    def test_one_receipt_cannot_reappear_under_another_resource(self):
        with self.assertRaisesRegex(ValueError, "occurrence cannot be used twice"):
            Graph("root", [Node("root", 0, (Action("receive", (Edge("ok", "again", (
                Receipt("same-transfer", 60, "one"),)),)),)),
                Node("again", 1, (Action("receive", (Edge("ok", "end", (
                Receipt("same-transfer", 60, "two"),)),)),)), Node("end", 2, terminal_other_due=120)],
                {"one": 60, "two": 60})

    def test_mutually_exclusive_draws_share_capacity(self):
        draw = Action("draw", (
            Edge("left", "end", (Receipt("left-draw", 60, "facility"),)),
            Edge("right", "end", (Receipt("right-draw", 60, "facility"),))))
        graph = Graph("root", [Node("root", 0, (draw,)),
            Node("end", 1, terminal_other_due=100)], {"facility": 60})
        self.assertEqual(graph.requirements()[0]["root"], 40)

    def test_empty_action_set_is_impossible(self):
        graph = Graph("stuck", [Node("stuck", 0)])
        self.assertEqual(graph.requirements()[0]["stuck"], inf)

    def test_cycle_or_missing_time_order_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "deadline order"):
            Graph("loop", [Node("loop", 0, (Action("retry", (Edge("again", "loop"),)),))])

    def test_fractional_atoms_are_not_rounded(self):
        self.assertEqual(expected_shortfall([(0, Q(2, 3)), (1, Q(1, 3))], Q(1, 2)), Q(2, 3))
        graph = Graph("root", [Node("root", 0, (Action("pay", (Edge("ok", "end"),),
            (Payment("one-third", Q(1, 3)),)),)), Node("end", 1, terminal_other_due=Q(1, 7))])
        self.assertEqual(graph.requirements()[0]["root"], Q(10, 21))

    def test_binary_float_is_rejected(self):
        with self.assertRaises(ValueError):
            Node("terminal", 0, terminal_other_due=0.1)
        with self.assertRaises(ValueError):
            expected_shortfall([(0, 0.5), (1, 0.5)], Q(1, 2))

    def test_backward_threshold_matches_independent_forward_policies(self):
        cases = 0
        for due_left, due_right, pay_a, pay_b, gain_a, gain_b in product(range(3), repeat=6):
            action_a = Action("a", (
                Edge("left", "left", (Receipt("a", gain_a, "a-resource"),)), Edge("right", "right")),
                (Payment("a-pay", pay_a),))
            action_b = Action("b", (
                Edge("left", "left"), Edge("right", "right", (Receipt("b", gain_b, "b-resource"),))),
                (Payment("b-pay", pay_b),))
            graph = Graph("root", [Node("root", 0, (action_a, action_b)),
                Node("left", 1, terminal_other_due=due_left),
                Node("right", 1, terminal_other_due=due_right)],
                {"a-resource": gain_a, "b-resource": gain_b})
            requirement = graph.requirements()[0]["root"]
            for cash in range(6):
                self.assertEqual(cash >= requirement, feasible_by_forward_search(graph, "root", Q(cash)))
                cases += 1
        self.assertEqual(cases, 4374)


if __name__ == "__main__":
    unittest.main(verbosity=2)
