"""Exact completion cash on a finite observable state graph.

The caller supplies the legal obligations, available resources, and stress branches.
Validation checks the represented cash and debt ledger. It does not establish external facts.
"""

from dataclasses import dataclass
from fractions import Fraction
from math import inf


def money(value):
    if isinstance(value, bool) or not isinstance(value, (int, Fraction)):
        raise ValueError("Use an exact integer or Fraction.")
    return Fraction(value)


def nonnegative(value):
    value = money(value)
    if value < 0:
        raise ValueError("Amount must be nonnegative.")
    return value


@dataclass(frozen=True)
class Debt:
    identity: str
    amount: Fraction
    deadline: int

    def __post_init__(self):
        if not self.identity or type(self.deadline) is not int or self.deadline < 0:
            raise ValueError("Debt identity and deadline are required.")
        object.__setattr__(self, "amount", nonnegative(self.amount))


@dataclass(frozen=True)
class Receipt:
    identity: str
    amount: Fraction
    resource: str
    loan: Debt | None = None

    def __post_init__(self):
        if not self.identity or not self.resource:
            raise ValueError("Receipt identity and resource are required.")
        object.__setattr__(self, "amount", nonnegative(self.amount))


@dataclass(frozen=True)
class Payment:
    identity: str
    amount: Fraction
    settles: str | None = None

    def __post_init__(self):
        if not self.identity:
            raise ValueError("Payment identity is required.")
        object.__setattr__(self, "amount", nonnegative(self.amount))


@dataclass(frozen=True)
class Edge:
    observation: str
    target: str
    receipts: tuple[Receipt, ...] = ()
    payments: tuple[Payment, ...] = ()
    probability: Fraction | None = None
    economic_loss: Fraction = Fraction(0)

    def __post_init__(self):
        if self.probability is not None:
            object.__setattr__(self, "probability", nonnegative(self.probability))
        object.__setattr__(self, "economic_loss", money(self.economic_loss))

    @property
    def increment(self):
        return sum((r.amount for r in self.receipts), Fraction(0)) - sum(
            (p.amount for p in self.payments), Fraction(0)
        )


@dataclass(frozen=True)
class Action:
    identity: str
    edges: tuple[Edge, ...]
    payments: tuple[Payment, ...] = ()
    floor: Fraction = Fraction(0)
    tail_mass: Fraction | None = None

    def __post_init__(self):
        if not self.identity or not self.edges:
            raise ValueError("A nonterminal action needs an identity and an outcome.")
        object.__setattr__(self, "floor", nonnegative(self.floor))
        if self.tail_mass is not None:
            q = money(self.tail_mass)
            if not 0 < q <= 1:
                raise ValueError("Tail mass must belong to (0, 1].")
            object.__setattr__(self, "tail_mass", q)

    @property
    def cost(self):
        return sum((p.amount for p in self.payments), Fraction(0))


@dataclass(frozen=True)
class Node:
    identity: str
    stage: int
    actions: tuple[Action, ...] = ()
    debts: tuple[Debt, ...] = ()
    terminal_other_due: Fraction | None = None
    risk_budget: Fraction | None = None
    terminal_economic_loss: Fraction = Fraction(0)

    def __post_init__(self):
        if not self.identity or type(self.stage) is not int or self.stage < 0:
            raise ValueError("A node needs an identity and an integer stage.")
        if self.terminal_other_due is not None:
            object.__setattr__(self, "terminal_other_due", nonnegative(self.terminal_other_due))
            if self.actions:
                raise ValueError("A terminal node cannot also offer actions.")
        if self.risk_budget is not None:
            object.__setattr__(self, "risk_budget", nonnegative(self.risk_budget))
        object.__setattr__(self, "terminal_economic_loss", money(self.terminal_economic_loss))

    @property
    def terminal_due(self):
        if self.terminal_other_due is None:
            return None
        return self.terminal_other_due + sum((d.amount for d in self.debts), Fraction(0))


class Graph:
    """Validate the finite ledger before backward cash calculation.

    An edge receives its cash before paying its listed outflows.
    Split the edge when another ordering or deadline matters.
    Resource limits bound cumulative gross receipts along each history.
    Repayment does not replenish a resource in this finite profile.
    """

    def __init__(self, root, nodes, resource_limits=None):
        self.root = root
        self.nodes = {n.identity: n for n in nodes}
        if len(self.nodes) != len(nodes) or root not in self.nodes:
            raise ValueError("Node identities must be unique and include the root.")
        self.resource_limits = {
            key: nonnegative(value) for key, value in (resource_limits or {}).items()
        }
        self._validate()

    @staticmethod
    def _pay(debts, payment):
        if payment.settles is not None:
            debt = debts.pop(payment.settles, None)
            if debt is None or payment.amount != debt.amount:
                raise ValueError("A repayment must discharge one exact recorded debt.")

    def _validate(self):
        reachable = set()
        budgets = [n.risk_budget is not None for n in self.nodes.values()]
        if any(budgets) and not all(budgets):
            raise ValueError("Conditional risk budgets must cover every state.")
        if all(budgets):
            for node in self.nodes.values():
                if node.terminal_due is not None:
                    if node.terminal_economic_loss > node.risk_budget:
                        raise ValueError("Terminal economic loss exceeds its risk budget.")
                    continue
                for action in node.actions:
                    if action.tail_mass is None or any(e.probability is None for e in action.edges):
                        raise ValueError("A budgeted action needs its exact conditional risk law.")
                    if any(e.target not in self.nodes for e in action.edges):
                        raise ValueError("A risk branch needs a known target.")
                    value = expected_shortfall([
                        (e.economic_loss + self.nodes[e.target].risk_budget, e.probability)
                        for e in action.edges], action.tail_mass)
                    if value > node.risk_budget:
                        raise ValueError("Conditional successor risk exceeds the current budget.")

        def visit(identity, used, events, opened):
            node = self.nodes[identity]
            reachable.add(identity)
            debts = {d.identity: d for d in node.debts}
            if len(debts) != len(node.debts):
                raise ValueError("Debt identities must be unique within a state.")
            if any(d.deadline < node.stage for d in node.debts):
                raise ValueError("A debt has passed its payment deadline.")
            if node.terminal_due is not None:
                return
            if len({a.identity for a in node.actions}) != len(node.actions):
                raise ValueError("Action identities must be unique within a state.")
            for action in node.actions:
                if len({e.observation for e in action.edges}) != len(action.edges):
                    raise ValueError("An action must identify each observable outcome once.")
                paid = dict(debts)
                action_events = set(events)
                for payment in action.payments:
                    if payment.identity in action_events:
                        raise ValueError("One cash occurrence cannot be used twice.")
                    action_events.add(payment.identity)
                    self._pay(paid, payment)
                if any(d.deadline <= node.stage for d in paid.values()):
                    raise ValueError("The action leaves a current debt unpaid.")
                for edge in action.edges:
                    if edge.target not in self.nodes or not edge.observation:
                        raise ValueError("An edge needs a known target and observation.")
                    child = self.nodes[edge.target]
                    if child.stage <= node.stage:
                        raise ValueError("Edges must advance through the finite deadline order.")
                    edge_debts, edge_used = dict(paid), dict(used)
                    edge_events, edge_opened = set(action_events), set(opened)
                    for receipt in edge.receipts:
                        if receipt.identity in edge_events:
                            raise ValueError("One cash occurrence cannot be used twice.")
                        edge_events.add(receipt.identity)
                        if receipt.resource not in self.resource_limits:
                            raise ValueError("A receipt needs a recorded gross resource limit.")
                        total = edge_used.get(receipt.resource, Fraction(0)) + receipt.amount
                        if total > self.resource_limits[receipt.resource]:
                            raise ValueError("A history draws one resource beyond its limit.")
                        edge_used[receipt.resource] = total
                        if receipt.loan is not None:
                            debt = receipt.loan
                            if debt.identity in edge_opened:
                                raise ValueError("A loan identity cannot be opened twice.")
                            edge_opened.add(debt.identity)
                            edge_debts[debt.identity] = debt
                    if any(debt.deadline < child.stage for debt in edge_debts.values()):
                        raise ValueError("An edge crosses a debt deadline before its cash arrives.")
                    for payment in edge.payments:
                        if payment.identity in edge_events:
                            raise ValueError("One cash occurrence cannot be used twice.")
                        edge_events.add(payment.identity)
                        self._pay(edge_debts, payment)
                    if edge_debts != {d.identity: d for d in child.debts}:
                        raise ValueError("The child must retain every unpaid debt exactly.")
                    visit(edge.target, edge_used, edge_events, edge_opened)

        visit(self.root, {}, set(), {d.identity for d in self.nodes[self.root].debts})
        if reachable != set(self.nodes):
            raise ValueError("Every supplied node must be reachable from the root.")

    def requirements(self):
        result, actions = {}, {}
        for node in sorted(self.nodes.values(), key=lambda n: n.stage, reverse=True):
            if node.terminal_due is not None:
                result[node.identity] = node.terminal_due
                continue
            for action in node.actions:
                threshold = max(
                    [action.cost + action.floor]
                    + [action.cost - e.increment + result[e.target] for e in action.edges]
                )
                actions[node.identity, action.identity] = threshold
            result[node.identity] = min(
                (actions[node.identity, a.identity] for a in node.actions), default=inf
            )
        return result, actions

    def admissible(self, node, cash):
        cash = nonnegative(cash)
        _, thresholds = self.requirements()
        return tuple(a.identity for a in self.nodes[node].actions if thresholds[node, a.identity] <= cash)

    def trace(self, cash, choices, observations):
        """Execute one supplied adapted policy path without external dispatch."""
        cash = nonnegative(cash)
        requirements, thresholds = self.requirements()
        node = self.nodes[self.root]
        history = []
        while node.terminal_due is None:
            selected = choices[node.identity]
            action = next((a for a in node.actions if a.identity == selected), None)
            if action is None or thresholds[node.identity, selected] > cash:
                raise ValueError("Selected action has no complete funded continuation.")
            after = cash - action.cost
            observation = observations[node.identity]
            edge = next((e for e in action.edges if e.observation == observation), None)
            if edge is None:
                raise ValueError("Observed outcome is outside the supplied model.")
            history.append({"node": node.identity, "cash": str(cash), "action": selected,
                            "retained": str(after), "observation": observation})
            cash = after + edge.increment
            node = self.nodes[edge.target]
        if cash < requirements[node.identity]:
            raise ValueError("Terminal obligations exceed available cash.")
        history.append({"node": node.identity, "cash": str(cash),
                        "terminal_payment": str(node.terminal_due),
                        "surplus": str(cash - node.terminal_due)})
        return history


def expected_shortfall(weighted_losses, tail_mass):
    """Average the worst exact tail mass, including fractional probability atoms."""
    q = money(tail_mass)
    if not 0 < q <= 1:
        raise ValueError("Tail mass must belong to (0, 1].")
    pairs = [(money(loss), nonnegative(weight)) for loss, weight in weighted_losses]
    if sum((weight for _, weight in pairs), Fraction(0)) != 1:
        raise ValueError("Probabilities must sum exactly to one.")
    remaining, total = q, Fraction(0)
    for loss, weight in sorted(pairs, reverse=True):
        take = min(remaining, weight)
        total += take * loss
        remaining -= take
        if remaining == 0:
            return total / q
    raise ValueError("Tail mass exceeds the supplied probability mass.")


def nested_es(tree, tail_mass):
    """A leaf is an exact loss. A branch is a tuple of (probability, subtree)."""
    if isinstance(tree, (int, Fraction)) and not isinstance(tree, bool):
        return money(tree)
    return expected_shortfall([(nested_es(child, tail_mass), p) for p, child in tree], tail_mass)


def static_es(tree, tail_mass):
    leaves = []

    def collect(part, mass):
        if isinstance(part, (int, Fraction)) and not isinstance(part, bool):
            leaves.append((money(part), mass))
            return
        if sum((money(p) for p, _ in part), Fraction(0)) != 1:
            raise ValueError("Each conditional law must sum exactly to one.")
        for p, child in part:
            collect(child, mass * nonnegative(p))

    collect(tree, Fraction(1))
    return expected_shortfall(leaves, tail_mass)
