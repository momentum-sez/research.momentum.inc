"""JCS-compatible closed-profile values with exact integer application fields."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
import sys

# Bind the normalization table as part of the executable profile.
sys.path.insert(0, str(Path(__file__).resolve().parent / "unicode-runtime"))
import unicodedata2 as unicodedata
if unicodedata.unidata_version != "17.0.0":
    raise RuntimeError("UNICODE_VERSION")

SAFE = 2**53 - 1
I64_MIN, I64_MAX = -(2**63), 2**63 - 1
PROFILE = "op:jcs-exact:2"

def string(value: str) -> str:
    if any(0xD800 <= ord(c) <= 0xDFFF for c in value):
        raise ValueError("UNPAIRED_SURROGATE")
    if any(0xFDD0 <= ord(c) <= 0xFDEF or ord(c) & 0xFFFF in (0xFFFE,0xFFFF) for c in value):
        raise ValueError("UNICODE_NONCHARACTER")
    if unicodedata.normalize("NFC", value) != value:
        raise ValueError("NON_NFC")
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))

def encode(value: object) -> bytes:
    def emit(v: object) -> str:
        if v is None: return "null"
        if v is True: return "true"
        if v is False: return "false"
        if type(v) is int:
            if not -SAFE <= v <= SAFE: raise ValueError("UNSAFE_JSON_INTEGER")
            return str(v)
        if isinstance(v, str): return string(v)
        if isinstance(v, list): return "[" + ",".join(emit(x) for x in v) + "]"
        if isinstance(v, dict):
            if any(not isinstance(k, str) for k in v): raise ValueError("PROPERTY_TYPE")
            for key in v: string(key)
            keys = sorted(v, key=lambda key: key.encode("utf-16-be"))
            return "{" + ",".join(string(k) + ":" + emit(v[k]) for k in keys) + "}"
        raise ValueError("PROFILE_TYPE")
    return emit(value).encode("utf-8")

def parse(data: bytes) -> object:
    def integer(token: str) -> int:
        if token == "-0": raise ValueError("NEGATIVE_ZERO")
        value = int(token)
        if not -SAFE <= value <= SAFE: raise ValueError("UNSAFE_JSON_INTEGER")
        return value
    def invalid(_: str): raise ValueError("NON_INTEGER_NUMBER")
    def pairs(items: list[tuple[str, object]]) -> dict[str, object]:
        result = {}
        for key, value in items:
            if key in result: raise ValueError("DUPLICATE_PROPERTY")
            result[key] = value
        return result
    value = json.loads(data.decode("utf-8", errors="strict"), parse_int=integer,
                       parse_float=invalid, parse_constant=invalid,
                       object_pairs_hook=pairs)
    canonical = encode(value)
    if canonical != data: raise ValueError("NON_CANONICAL_BYTES")
    return value

def i64(value: int) -> dict[str, str]:
    if type(value) is not int or not I64_MIN <= value <= I64_MAX:
        raise ValueError("I64_RANGE")
    return {"type": "i64", "decimal": str(value)}

def decode_i64(value: object) -> int:
    if not isinstance(value, dict) or set(value) != {"type", "decimal"}:
        raise ValueError("I64_SCHEMA")
    decimal = value["decimal"]
    if value["type"] != "i64" or not isinstance(decimal, str): raise ValueError("I64_SCHEMA")
    if re.fullmatch(r"0|-?[1-9][0-9]*", decimal) is None: raise ValueError("I64_GRAMMAR")
    result = int(decimal)
    if not I64_MIN <= result <= I64_MAX: raise ValueError("I64_RANGE")
    return result

def digest(kind: str, value: object) -> str:
    domain = (PROFILE + ":" + kind).encode("ascii") + b"\0"
    return hashlib.sha256(domain + encode(value)).hexdigest()
