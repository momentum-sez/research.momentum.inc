"""Persistent synthetic provider with one bounded execution right per command.

Keys remain retained permanently. Its own account ledger assigns occurrence
references. These reference facts establish no live provider or legal fact.
"""
from pathlib import Path
from codec import encode, parse, digest, i64, decode_i64, quantity
from contract import SCOPE, CONTRACT, sign_fixture, occurrence_key
from online import ProviderUnavailable
from store import connect, fault

class SyntheticProvider:
    def __init__(self, path, crash=None):
        self.path = Path(path)
        self.crash = crash
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with connect(self.path) as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS commands(k TEXT PRIMARY KEY,h TEXT NOT NULL,request BLOB NOT NULL,closed INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS plans(k TEXT PRIMARY KEY,plan BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS occurrences(k TEXT PRIMARY KEY,command TEXT NOT NULL,kind TEXT NOT NULL,quantity TEXT NOT NULL,reverses TEXT,body BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS assertions(id TEXT PRIMARY KEY,command TEXT NOT NULL,sequence INTEGER NOT NULL,envelope BLOB NOT NULL,UNIQUE(command,sequence));
            CREATE TABLE IF NOT EXISTS control(id INTEGER PRIMARY KEY,available INTEGER NOT NULL,submits INTEGER NOT NULL,recovers INTEGER NOT NULL);
            INSERT OR IGNORE INTO control VALUES(1,1,0,0);
            """)

    def available(self, value):
        with connect(self.path) as db:
            db.execute("UPDATE control SET available=? WHERE id=1", (int(value),))

    def plan(self, key, payments, close=False):
        body = {"payments": [i64(quantity(q)) for q in payments], "close": bool(close)}
        with connect(self.path) as db:
            db.execute("INSERT INTO plans VALUES(?,?)", (key, encode(body)))

    def _begin_call(self, kind):
        if kind not in {"submits", "recovers"}:
            raise ValueError("FIXTURE_CALL_KIND")
        with connect(self.path) as db:
            db.execute(f"UPDATE control SET {kind}={kind}+1 WHERE id=1")
            if not db.execute("SELECT available FROM control WHERE id=1").fetchone()[0]:
                raise ProviderUnavailable()

    def _emit(self, db, key, kind, q, occurrence=None, reverses=None):
        h = db.execute("SELECT h FROM commands WHERE k=?", (key,)).fetchone()[0]
        sequence = db.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM assertions WHERE command=?", (key,)).fetchone()[0]
        body = {"provider": SCOPE, "contract": CONTRACT, "command": key, "request": h, "sequence": sequence, "kind": kind, "occurrence": occurrence, "amount": i64(q), "reverses": reverses}
        envelope = sign_fixture(body)
        db.execute("INSERT INTO assertions VALUES(?,?,?,?)", (digest("partial-assertion", body), key, sequence, encode(envelope)))
        return envelope

    def _posting(self, db, key, kind, q, reference=None, reverses=None):
        quantity(q)
        row = db.execute("SELECT request,closed FROM commands WHERE k=?", (key,)).fetchone()
        if row is None:
            raise ValueError("PROVIDER_UNKNOWN_COMMAND")
        request = parse(row[0])
        if kind == "payment":
            if row[1]:
                raise ValueError("PROVIDER_CLOSED")
            gross = sum(int(x[0]) for x in db.execute("SELECT quantity FROM occurrences WHERE command=? AND kind='payment'", (key,)))
            if gross + q > decode_i64(request["quantity"]):
                raise ValueError("PROVIDER_CAPACITY")
        else:
            prior = db.execute("SELECT command,quantity FROM occurrences WHERE k=? AND kind='payment'", (reverses,)).fetchone()
            if prior is None or prior[0] != key:
                raise ValueError("PROVIDER_RETURN_LINK")
            returned = sum(int(x[0]) for x in db.execute("SELECT quantity FROM occurrences WHERE reverses=?", (reverses,)))
            if returned + q > int(prior[1]):
                raise ValueError("PROVIDER_RETURN_CAPACITY")
        if reference is None:
            reference = "posting-" + str(db.execute("SELECT COUNT(*)+1 FROM occurrences").fetchone()[0])
        identity = {"provider": SCOPE, "account": request["payee"] if kind == "payment" else request["payer"], "asset": request["asset"], "unit": request["unit"], "namespace": "provider-posting-id", "epoch": "account-ledger-1", "reference": reference}
        oid = occurrence_key(identity)
        envelope = self._emit(db, key, kind, q, identity, reverses)
        db.execute("INSERT INTO occurrences VALUES(?,?,?,?,?,?)", (oid, key, kind, str(q), reverses, envelope["body"].encode()))
        return oid, envelope

    def submit(self, key, request_digest, request_bytes):
        self._begin_call("submits")
        request = parse(request_bytes)
        if digest("partial-command", request) != key or digest("partial-request", request) != request_digest:
            raise ValueError("PROVIDER_REQUEST_BINDING")
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            old = db.execute("SELECT h,request FROM commands WHERE k=?", (key,)).fetchone()
            if old is not None and old != (request_digest, request_bytes):
                raise ValueError("PROVIDER_CONFLICT")
            if old is None:
                db.execute("INSERT INTO commands VALUES(?,?,?,0)", (key, request_digest, request_bytes))
                plan = db.execute("SELECT plan FROM plans WHERE k=?", (key,)).fetchone()
                if plan:
                    plan = parse(plan[0])
                    for q in plan["payments"]:
                        self._posting(db, key, "payment", decode_i64(q))
                    if plan["close"]:
                        self._close(db, key)
            fault("inside_provider", self.crash)
            db.commit()
        fault("after_provider", self.crash)
        return self._outcomes(key)

    def _outcomes(self, key):
        with connect(self.path) as db:
            return [parse(r[0]) for r in db.execute("SELECT envelope FROM assertions WHERE command=? ORDER BY sequence", (key,))]

    def recover(self, key):
        self._begin_call("recovers")
        return self._outcomes(key)

    def post_payment(self, key, q, reference=None):
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            result = self._posting(db, key, "payment", q, reference)
            db.commit()
            return result

    def post_return(self, key, original, q, reference=None):
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            result = self._posting(db, key, "return", q, reference, original)
            db.commit()
            return result

    def _close(self, db, key):
        total = sum(int(r[0]) for r in db.execute("SELECT quantity FROM occurrences WHERE command=? AND kind='payment'", (key,)))
        db.execute("UPDATE commands SET closed=1 WHERE k=?", (key,))
        return self._emit(db, key, "closed", total)

    def close(self, key):
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            envelope = self._close(db, key)
            db.commit()
            return envelope

    def repeat_assertion(self, key, occurrence):
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            body = parse(db.execute("SELECT body FROM occurrences WHERE k=?", (occurrence,)).fetchone()[0])
            result = self._emit(db, key, body["kind"], decode_i64(body["amount"]), body["occurrence"], body["reverses"])
            db.commit()
            return result

    def progress(self, key, total):
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            result = self._emit(db, key, "progress", total)
            db.commit()
            return result

    def counts(self):
        with connect(self.path) as db:
            submits, recovers = db.execute("SELECT submits,recovers FROM control WHERE id=1").fetchone()
            occurrences = db.execute("SELECT COUNT(*) FROM occurrences").fetchone()[0]
            commands = db.execute("SELECT COUNT(*) FROM commands").fetchone()[0]
        return {"submits": submits, "recovers": recovers, "occurrences": occurrences, "commands": commands}
