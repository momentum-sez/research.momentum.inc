"""Durable one-pool authority with atomic state, reservations and append receipts."""
from pathlib import Path
import os
import sqlite3
from codec import encode, parse, digest, i64
from contract import EvidencePolicy
from model import apply_event, pool_view, target_view, command_view

CRASH_POINTS = tuple(f"{stage}_{action}" for action in ("prepare", "receive", "epoch", "consume", "finish_epoch", "funding", "arm", "transmit") for stage in ("before", "inside", "after"))

def fault(point, configured):
    if point == configured:
        os._exit(77)

class Connection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()

def connect(path):
    db = sqlite3.connect(path, timeout=20, isolation_level=None, factory=Connection)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=FULL")
    return db

class SettlementStore:
    def __init__(self, path, policy=None):
        self.path = Path(path)
        self.policy = policy or EvidencePolicy()

    @classmethod
    def create(cls, path, funding, pool="funding-pool", asset="USD", unit="cent", account="payer-account", policy=None):
        obj = cls(path, policy)
        obj.path.parent.mkdir(parents=True, exist_ok=True)
        with connect(obj.path) as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS current(id INTEGER PRIMARY KEY CHECK(id=1), state BLOB NOT NULL, sequence INTEGER NOT NULL, head TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS journal(sequence INTEGER PRIMARY KEY, event BLOB NOT NULL, previous TEXT NOT NULL, state_hash TEXT NOT NULL, head TEXT NOT NULL);
            """)
        if obj.read(optional=True) is None:
            obj.commit("initialize", {"pool": pool, "asset": asset, "unit": unit, "account": account, "funding": i64(funding)})
        return obj

    def read(self, optional=False):
        with connect(self.path) as db:
            row = db.execute("SELECT state FROM current WHERE id=1").fetchone()
        if row is None:
            if optional:
                return None
            raise ValueError("UNINITIALIZED")
        return parse(row[0])

    def commit(self, kind, data, crash=None):
        fault("before_" + kind, crash)
        event = {"kind": kind, "data": data}
        with connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT state,sequence,head FROM current WHERE id=1").fetchone()
            state, sequence, previous = (parse(current[0]), current[1], current[2]) if current else (None, 0, "genesis")
            successor = apply_event(state, event, self.policy)
            state_hash = digest("settlement-state", successor)
            receipt = {"sequence": sequence + 1, "event": event, "previous": previous, "state_hash": state_hash}
            head = digest("settlement-receipt", receipt)
            db.execute("INSERT INTO journal VALUES(?,?,?,?,?)", (sequence+1, encode(event), previous, state_hash, head))
            db.execute("INSERT INTO current VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET state=excluded.state,sequence=excluded.sequence,head=excluded.head", (encode(successor), sequence+1, head))
            fault("inside_" + kind, crash)
            db.commit()
        fault("after_" + kind, crash)
        return successor

    def create_target(self, target, quantity, payee, source_digest):
        return self.commit("target", {"id": target, "quantity": i64(quantity), "payee": payee, "source": source_digest})

    def prepare(self, target, attempt, quantity, crash=None):
        s = self.read()
        request = {"pool": s["pool"]["id"], "target": target, "attempt": attempt, "asset": s["pool"]["asset"], "unit": s["pool"]["unit"], "payer": s["pool"]["account"], "payee": s["targets"][target]["payee"], "provider": self.policy.scope, "contract": self.policy.contract, "quantity": i64(quantity)}
        self.commit("prepare", {"request": request, "authority_epoch": s["pool"]["authority_epoch"]}, crash)
        return digest("partial-command", request)

    def set_authority(self, permitted, evidence_id, source_sequence):
        return self.commit("authority", {"permitted": permitted, "evidence": evidence_id, "source_sequence": source_sequence})

    def record_backing_change(self, event_id, delta, crash=None):
        return self.commit("funding", {"id": event_id, "delta": i64(delta)}, crash)

    def cancel_target(self, target, amount, evidence_id):
        s = self.read()
        return self.commit("cancel_target", {"target": target, "quantity": i64(amount), "authority_epoch": s["pool"]["authority_epoch"], "evidence": evidence_id})

    def receive(self, envelope, crash=None):
        return self.commit("receive", {"envelope": envelope}, crash)

    def consume_local(self, crash=None):
        # An already committed epoch always resumes before a new admission cut.
        state = self.read()
        if state["active_epoch"] is None:
            state = self.commit("epoch", {}, crash)
        while True:
            epoch = state["active_epoch"]
            if epoch["index"] == len(epoch["record"]["members"]):
                try:
                    return self.commit("finish_epoch", {"epoch": epoch["root"]}, crash)
                except ValueError as error:
                    if str(error) != "CONTINUATION_VERSION":
                        raise
                    return self.read()
            try:
                state = self.commit("consume", {"epoch": epoch["root"], "index": epoch["index"]}, crash)
            except ValueError as error:
                if str(error) != "CONTINUATION_VERSION":
                    raise
                state = self.read()
                if state["active_epoch"] is None:
                    return state

    def snapshot(self):
        state = self.read()
        return {"pool": pool_view(state), "targets": {k: target_view(state, k) for k in state["targets"]}, "commands": {k: command_view(state, k) for k in state["commands"]}, "pending_occurrence_links": {oid: {"reverses": state["occurrences"][oid]["reverses"], "command": state["occurrences"][oid]["command"], "quantity": state["occurrences"][oid]["quantity"]} for oid in state["pending_returns"]}, "alerts": state["alerts"]}

    def allocation_rows(self, target):
        state = self.read()
        return [{"occurrence": key, "command": o["command"], "target": target, "kind": o["kind"], "quantity": o["allocated"], "reverses": o["reverses"]} for key, o in state["occurrences"].items() if o["target"] == target and int(o["allocated"]) > 0]

    def settlement_export(self, target):
        """One-row checkpoint plus stable nonzero credit/return allocation receipts.

        Consumers deduplicate receipt_id. A return reopens entitlement. Pending
        links produce no zero-value receipt that could suppress later allocation.
        """
        with connect(self.path) as db:
            raw, sequence, head = db.execute("SELECT state,sequence,head FROM current WHERE id=1").fetchone()
        state = parse(raw)
        t = state["targets"][target]
        pool = state["pool"]
        binding = {"target": target, "source": t["source"], "quantity": i64(int(t["quantity"])), "payee": t["payee"], "payer": pool["account"], "pool": pool["id"], "asset": pool["asset"], "unit": pool["unit"]}
        binding_id = digest("fixed-settlement-target", binding)
        receipts = []
        occurrences = {}
        for oid, o in state["occurrences"].items():
            if o["target"] != target:
                continue
            occurrences[oid] = {"identity": o["identity"], "physical_quantity": i64(int(o["quantity"])), "kind": o["kind"], "command": o["command"], "reverses": o["reverses"], "assertion": o["first_assertion"]}
            if int(o["allocated"]) == 0:
                continue
            evidence = [o["first_assertion"]]
            if o["kind"] == "return":
                evidence.append(state["occurrences"][o["reverses"]]["first_assertion"])
            evidence.sort()
            data = {"target": target, "target_binding": binding_id, "command": o["command"], "request": state["commands"][o["command"]]["request_digest"], "occurrence": oid, "physical_identity": o["identity"], "physical_quantity": i64(int(o["quantity"])), "kind": o["kind"], "quantity": i64(int(o["allocated"])), "asset": pool["asset"], "unit": pool["unit"], "reverses": o["reverses"], "evidence": evidence, "epochs": [state["consumed"][aid]["epoch"] for aid in evidence]}
            receipts.append({"receipt_id": digest("settlement-allocation", data), "data": data})
        receipts.sort(key=lambda r: r["receipt_id"])
        return {"checkpoint": {"sequence": sequence, "head": head, "state_hash": digest("settlement-state", state)}, "target_binding": binding, "target_binding_id": binding_id, "view": target_view(state, target), "occurrences": occurrences, "receipts": receipts}

    def export_journal(self):
        with connect(self.path) as db:
            rows = db.execute("SELECT sequence,event,previous,state_hash,head FROM journal ORDER BY sequence").fetchall()
        return encode([{"sequence": r[0], "event": parse(r[1]), "previous": r[2], "state_hash": r[3], "head": r[4]} for r in rows])
