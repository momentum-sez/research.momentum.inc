"""Use the preserved exact-byte profile without modifying its directory."""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from canonical_profile import encode, parse, digest, i64, decode_i64

def quantity(value):
    if type(value) is not int or not 0 < value < 2**63:
        raise ValueError("POSITIVE_I64_QUANTITY")
    return value

def integer(value):
    if type(value) is not int or not -(2**63) <= value < 2**63:
        raise ValueError("I64_QUANTITY")
    return value
