"""Explicit synthetic evidence contract. Production verification is an integration boundary."""
from dataclasses import dataclass
import hashlib
import hmac
from codec import parse, encode, digest, decode_i64

SCOPE = "synthetic-provider/account-ledger"
CONTRACT = "synthetic-partial-provider:1"
TEST_KEY = b"public-synthetic-partial-provider-key"

@dataclass(frozen=True)
class EvidencePolicy:
    scope: str = SCOPE
    contract: str = CONTRACT
    key: bytes = TEST_KEY

    def verify(self, envelope):
        if set(envelope) != {"body", "signature"}:
            raise ValueError("ENVELOPE_SCHEMA")
        raw = envelope["body"].encode("utf-8")
        expected = hmac.new(self.key, raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(envelope["signature"], expected):
            raise ValueError("EVIDENCE_AUTHENTICATION")
        body = parse(raw)
        keys = {"provider", "contract", "command", "request", "sequence", "kind", "occurrence", "amount", "reverses"}
        if not isinstance(body, dict) or set(body) != keys:
            raise ValueError("ASSERTION_SCHEMA")
        if body["provider"] != self.scope or body["contract"] != self.contract:
            raise ValueError("PROVIDER_SCOPE")
        if not all(isinstance(body[k], str) and body[k] for k in ("command", "request")):
            raise ValueError("REQUEST_IDENTITY")
        if type(body["sequence"]) is not int or body["sequence"] < 1:
            raise ValueError("ASSERTION_SEQUENCE")
        if body["kind"] not in {"payment", "return", "closed", "progress"}:
            raise ValueError("ASSERTION_KIND")
        amount = decode_i64(body["amount"])
        if amount < 0 or (body["kind"] in {"payment", "return"} and amount == 0):
            raise ValueError("ASSERTION_QUANTITY")
        if body["kind"] in {"payment", "return"}:
            ident = body["occurrence"]
            if not isinstance(ident, dict) or set(ident) != {"provider", "account", "asset", "unit", "namespace", "epoch", "reference"}:
                raise ValueError("OCCURRENCE_SCHEMA")
            if ident["provider"] != self.scope or not all(isinstance(v, str) and v for v in ident.values()):
                raise ValueError("OCCURRENCE_IDENTITY")
        elif body["occurrence"] is not None:
            raise ValueError("NON_OCCURRENCE_ASSERTION")
        if (body["kind"] == "return") != isinstance(body["reverses"], str):
            raise ValueError("RETURN_LINK")
        return digest("partial-assertion", body), body

def occurrence_key(identity):
    # Physical occurrence identity excludes command, report, amount, phase and legal origin.
    return digest("physical-occurrence", identity)

def sign_fixture(body):
    raw = encode(body)
    return {"body": raw.decode(), "signature": hmac.new(TEST_KEY, raw, hashlib.sha256).hexdigest()}
