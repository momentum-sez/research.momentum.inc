"""Pure receipt replay. This module has no provider, transport or dispatch interface."""
from dataclasses import dataclass
from codec import parse, digest
from contract import EvidencePolicy
from model import apply_event

@dataclass(frozen=True)
class ReplayResult:
    state: dict
    head: str
    entries: int

def replay(journal_bytes, policy=None):
    policy = policy or EvidencePolicy()
    records = parse(journal_bytes)
    state, head = None, "genesis"
    for sequence, record in enumerate(records, 1):
        if set(record) != {"sequence", "event", "previous", "state_hash", "head"} or record["sequence"] != sequence or record["previous"] != head:
            raise ValueError("JOURNAL_ORDER")
        state = apply_event(state, record["event"], policy)
        if digest("settlement-state", state) != record["state_hash"]:
            raise ValueError("JOURNAL_STATE")
        calculated = digest("settlement-receipt", {k: record[k] for k in ("sequence", "event", "previous", "state_hash")})
        if calculated != record["head"]:
            raise ValueError("JOURNAL_HASH")
        head = calculated
    return ReplayResult(state, head, len(records))
