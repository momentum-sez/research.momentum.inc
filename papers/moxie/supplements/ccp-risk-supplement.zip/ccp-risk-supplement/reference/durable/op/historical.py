"""Historical attestation admission under explicit synthetic trust roots.

The HMAC fixtures exercise message and temporal binding. The host supplies an
authenticated, complete checkpoint. Its selection and external truth are trust
assumptions. Replay reads each committed checkpoint, never a live key registry.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import hmac
from pathlib import Path
import sqlite3
from codec import encode, parse, digest
from contract import EvidencePolicy, SCOPE, CONTRACT


class TemporalPending(ValueError):
    """The declared temporal evidence does not determine admission."""


def mac(key, domain, value):
    return hmac.new(key, domain.encode() + b"\x00" + encode(value), hashlib.sha256).hexdigest()


def signed(key, domain, value):
    return {"value": deepcopy(value), "signature": mac(key, domain, value)}


def verified(key, domain, record):
    if not isinstance(record, dict) or set(record) != {"value", "signature"}:
        raise ValueError("SIGNED_RECORD_SCHEMA")
    if not isinstance(record["signature"], str) or not hmac.compare_digest(record["signature"], mac(key, domain, record["value"])):
        raise ValueError("SIGNED_RECORD_AUTHENTICATION")
    return deepcopy(record["value"])


def provider_assertion(key, key_id, body, event_time):
    return signed(key, "provider-attestation", {"key_id": key_id, "body": encode(body).decode(), "event_time": event_time})


def assertion_id(assertion):
    return digest("provider-attestation", assertion)


def time_integer(x):
    if type(x) is not int or x < 0:
        raise ValueError("TIME_SCHEMA")
    return x


@dataclass(frozen=True)
class HistoricalPolicy:
    registry_root: bytes
    clock_root: bytes
    admission_root: bytes
    scope: str = SCOPE
    contract: str = CONTRACT

    def _check(self, assertion, checkpoint, anchor, admission_time):
        view = verified(self.registry_root, "key-checkpoint", checkpoint)
        required = {"epoch", "previous", "as_of", "complete_through", "valid_until", "keys"}
        if not isinstance(view, dict) or set(view) != required:
            raise ValueError("CHECKPOINT_SCHEMA")
        for name in ("epoch", "as_of", "complete_through", "valid_until"):
            time_integer(view[name])
        time_integer(admission_time)
        if not (view["as_of"] <= admission_time <= view["complete_through"] <= view["valid_until"]):
            raise TemporalPending("CHECKPOINT_COVERAGE")
        if not isinstance(assertion, dict) or set(assertion) != {"value", "signature"}:
            raise ValueError("ASSERTION_SCHEMA")
        payload = assertion["value"]
        if not isinstance(payload, dict) or set(payload) != {"key_id", "body", "event_time"}:
            raise ValueError("ATTESTATION_SCHEMA")
        time_integer(payload["event_time"])
        key = view["keys"].get(payload["key_id"])
        if key is None:
            raise TemporalPending("HISTORICAL_DESIGNATION_MISSING")
        key_fields = {"key", "scope", "contract", "role", "from", "until", "compromise", "compromised_from"}
        if not isinstance(key, dict) or set(key) != key_fields:
            raise ValueError("KEY_HISTORY_SCHEMA")
        if (key["scope"], key["contract"], key["role"]) != (self.scope, self.contract, "attest"):
            raise ValueError("HISTORICAL_SCOPE")
        material = bytes.fromhex(key["key"])
        verified(material, "provider-attestation", assertion)
        # Reuse the original complete body, quantity, and occurrence validation.
        inner = {"body": payload["body"], "signature": hmac.new(material, payload["body"].encode(), hashlib.sha256).hexdigest()}
        _, body = EvidencePolicy(self.scope, self.contract, material).verify(inner)
        if anchor is None:
            raise TemporalPending("SIGNATURE_TIME_MISSING")
        timing = verified(self.clock_root, "signature-time", anchor)
        if not isinstance(timing, dict) or set(timing) != {"assertion", "meaning", "lower", "upper"}:
            raise ValueError("TIME_EVIDENCE_SCHEMA")
        if timing["assertion"] != assertion_id(assertion):
            raise ValueError("TIME_EVIDENCE_BINDING")
        if timing["meaning"] != "signing-interval":
            raise TemporalPending("INSUFFICIENT_TIME_MEANING")
        lo, hi = time_integer(timing["lower"]), time_integer(timing["upper"])
        start, end = time_integer(key["from"]), time_integer(key["until"])
        if lo > hi or start >= end or hi > admission_time:
            raise ValueError("TIME_INTERVAL")
        if hi < start or lo >= end:
            raise ValueError("SIGNING_OUTSIDE_DESIGNATION")
        if lo < start or hi >= end:
            raise TemporalPending("DESIGNATION_BOUNDARY_UNRESOLVED")
        status = key["compromise"]
        if status == "unknown":
            raise TemporalPending("COMPROMISE_INTERVAL_UNKNOWN")
        if status == "known":
            compromised = time_integer(key["compromised_from"])
            if lo >= compromised:
                raise ValueError("COMPROMISED_SIGNING")
            if hi >= compromised:
                raise TemporalPending("COMPROMISE_BOUNDARY_UNRESOLVED")
        elif status != "clear" or key["compromised_from"] is not None:
            raise ValueError("COMPROMISE_SCHEMA")
        return body

    def admit(self, assertion, *, current_checkpoint, anchor, admission_time):
        self._check(assertion, current_checkpoint, anchor, admission_time)
        facts = {"assertion": assertion, "checkpoint": current_checkpoint, "anchor": anchor, "admission_time": admission_time}
        return signed(self.admission_root, "historical-admission", facts)

    def verify(self, record):
        facts = verified(self.admission_root, "historical-admission", record)
        if not isinstance(facts, dict) or set(facts) != {"assertion", "checkpoint", "anchor", "admission_time"}:
            raise ValueError("ADMISSION_SCHEMA")
        body = self._check(facts["assertion"], facts["checkpoint"], facts["anchor"], facts["admission_time"])
        # Signer endorsements remain distinct evidence. The physical root is unchanged.
        return assertion_id(facts["assertion"]), body

    def reassess(self, admitted_record, *, current_checkpoint, evaluation_time):
        self.verify(admitted_record)
        current = verified(self.registry_root, "key-checkpoint", current_checkpoint)
        facts = verified(self.admission_root, "historical-admission", admitted_record)
        original = verified(self.registry_root, "key-checkpoint", facts["checkpoint"])
        if evaluation_time < facts["admission_time"] or current["epoch"] < original["epoch"]:
            raise ValueError("REASSESSMENT_PRECEDES_ADMISSION")
        if current["epoch"] == original["epoch"] and current_checkpoint != facts["checkpoint"]:
            raise ValueError("CHECKPOINT_EQUIVOCATION")
        try:
            self._check(facts["assertion"], current_checkpoint, facts["anchor"], evaluation_time)
            status, reason = "supported", None
        except TemporalPending as error:
            status, reason = "pending", str(error)
        except ValueError as error:
            status, reason = "obstruction", str(error)
        return signed(self.admission_root, "historical-reassessment", {
            "admission": digest("historical-admission", admitted_record),
            "checkpoint": current_checkpoint, "evaluation_time": evaluation_time,
            "status": status, "reason": reason,
        })

    def verify_reassessment(self, record, admitted_record):
        facts = verified(self.admission_root, "historical-reassessment", record)
        if not isinstance(facts, dict) or set(facts) != {"admission", "checkpoint", "evaluation_time", "status", "reason"}:
            raise ValueError("REASSESSMENT_SCHEMA")
        expected = self.reassess(admitted_record, current_checkpoint=facts["checkpoint"], evaluation_time=facts["evaluation_time"])
        if record != expected:
            raise ValueError("REASSESSMENT_BINDING")
        return facts


class HistoricalInbox:
    """Retain raw candidates, admission attempts, and later reassessments."""

    def __init__(self, path, policy):
        self.path, self.policy = Path(path), policy
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS attempts (sequence INTEGER PRIMARY KEY, candidate TEXT, record BLOB)")
            db.execute("CREATE TABLE IF NOT EXISTS admitted (candidate TEXT PRIMARY KEY, record BLOB)")
            db.execute("CREATE TABLE IF NOT EXISTS reassessments (sequence INTEGER PRIMARY KEY, candidate TEXT, record BLOB)")
            db.execute("CREATE TABLE IF NOT EXISTS destination (singleton INTEGER PRIMARY KEY CHECK(singleton=1), path TEXT)")

    def _connect(self):
        from contextlib import contextmanager
        @contextmanager
        def connection():
            db = sqlite3.connect(self.path)
            try:
                db.execute("PRAGMA synchronous=FULL")
                with db:
                    yield db
            finally:
                db.close()
        return connection()

    def receive(self, assertion, *, current_checkpoint, anchor, admission_time):
        candidate = assertion_id(assertion)
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            prior = db.execute("SELECT record FROM admitted WHERE candidate=?", (candidate,)).fetchone()
            if prior:
                return {"status": "admitted", "record": parse(prior[0]), "repeated": True}
            inputs = {"assertion": assertion, "checkpoint": current_checkpoint, "anchor": anchor, "admission_time": admission_time}
            try:
                admitted = self.policy.admit(assertion, current_checkpoint=current_checkpoint, anchor=anchor, admission_time=admission_time)
                result = {"status": "admitted", "record": admitted, "repeated": False}
                db.execute("INSERT INTO admitted VALUES (?,?)", (candidate, encode(admitted)))
            except TemporalPending as error:
                result = {"status": "pending", "reason": str(error)}
            except ValueError as error:
                result = {"status": "rejected", "reason": str(error)}
            db.execute("INSERT INTO attempts(candidate,record) VALUES (?,?)", (candidate, encode({"input": inputs, "result": result})))
            return result

    def deliver(self, candidate, store):
        # Persist the one funding authority before the first cross-store delivery.
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            path = str(store.path.resolve())
            row = db.execute("SELECT path FROM destination WHERE singleton=1").fetchone()
            if row is not None and row[0] != path:
                raise ValueError("HISTORICAL_DESTINATION_CONFLICT")
            db.execute("INSERT OR IGNORE INTO destination VALUES (1,?)", (path,))
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT record FROM admitted WHERE candidate=?", (candidate,)).fetchone()
            if row is None:
                raise TemporalPending("HISTORICAL_ADMISSION_PENDING")
            reviews = [parse(r[0]) for r in db.execute("SELECT record FROM reassessments WHERE candidate=? ORDER BY sequence", (candidate,))]
            # One settlement commit makes all known reassessments precede eligibility.
            store.commit("historical_delivery", {"envelope": parse(row[0]), "reassessments": reviews})
            return store.consume_local()

    def reassess(self, candidate, *, current_checkpoint, evaluation_time, store=None):
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT record FROM admitted WHERE candidate=?", (candidate,)).fetchone()
            if row is None:
                raise TemporalPending("HISTORICAL_ADMISSION_PENDING")
            result = self.policy.reassess(parse(row[0]), current_checkpoint=current_checkpoint, evaluation_time=evaluation_time)
            db.execute("INSERT INTO reassessments(candidate,record) VALUES (?,?)", (candidate, encode(result)))
            destination = db.execute("SELECT path FROM destination WHERE singleton=1").fetchone()
            if destination is not None:
                if store is not None and str(store.path.resolve()) != destination[0]:
                    raise ValueError("HISTORICAL_DESTINATION_CONFLICT")
                if store is None:
                    from store import SettlementStore
                    store = SettlementStore(destination[0], policy=self.policy)
            if store is not None and candidate in store.read()["assertions"]:
                store.commit("evidence_reassessment", {"assertion": candidate, "record": result})
        return result
