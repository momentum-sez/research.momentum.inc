"""Provider I/O boundary. Recovery folds durable local evidence before network access."""
from typing import Protocol
from codec import encode
from store import fault

class ProviderUnavailable(Exception):
    pass

class Provider(Protocol):
    def submit(self, command: str, request_digest: str, request: bytes) -> list[dict]: ...
    def recover(self, command: str) -> list[dict]: ...

class OnlineAdapter:
    def __init__(self, store):
        self.store = store

    def dispatch(self, key, provider: Provider, crash=None):
        self.store.consume_local()
        state = self.store.read()
        c = state["commands"][key]
        if c["closed"] or int(c["reserved"]) == 0:
            return self.store.snapshot()
        self.store.commit("arm", {"command": key, "authority_epoch": state["pool"]["authority_epoch"]}, crash)
        state = self.store.read()
        self.store.commit("transmit", {"command": key, "authority_epoch": state["pool"]["authority_epoch"]}, crash)
        fault("before_provider", crash)
        try:
            envelopes = provider.submit(key, c["request_digest"], encode(c["request"]))
        except ProviderUnavailable:
            self.store.commit("unavailable", {"command": key})
            return self.store.snapshot()
        fault("after_provider", crash)
        for envelope in envelopes:
            self.store.receive(envelope, crash)
        self.store.commit("acknowledged", {"command": key})
        self.store.consume_local(crash)
        return self.store.snapshot()

    def recover(self, provider: Provider | None = None, crash=None, include_closed=True):
        # This operation never submits an external action, including after a crash.
        self.store.consume_local(crash)
        if provider is None:
            return self.store.snapshot()
        state = self.store.read()
        for key, c in state["commands"].items():
            if c["dispatch"] != "Armed" or (c["closed"] and not include_closed):
                continue
            try:
                envelopes = provider.recover(key)
            except ProviderUnavailable:
                self.store.commit("unavailable", {"command": key})
                continue
            for envelope in envelopes:
                self.store.receive(envelope, crash)
        self.store.consume_local(crash)
        return self.store.snapshot()
