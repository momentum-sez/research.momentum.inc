"""Completion policies use actual cash, reservations, and provider outcomes."""
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest

from durable_completion import Gateway, cp, signed, codec, online, op_model, replay, load, P05

provider_module = load("completion_provider_fixture", P05 / "runtime/provider_fixture.py")
KEY = b"public-completion-host-fixture"
RESOURCE_KEY = b"public-completion-resource-fixture"
HERE = Path(__file__).resolve().parent


def facility(failure=False):
    debt = cp.Debt("facility-debt", 65, 3)
    edges = (cp.Edge("delivered", "pay", (cp.Receipt("draw", 60, "facility", debt),)),)
    nodes = [cp.Node("pay", 1, (cp.Action("perform", (cp.Edge("earned", "repay", (
        cp.Receipt("earned", 65, "earnings"),)),), (cp.Payment("customer", 100),)),), (debt,)),
        cp.Node("repay", 3, debts=(debt,), terminal_other_due=0)]
    if failure:
        edges += (cp.Edge("provider-failure", "cash"),)
        nodes.append(cp.Node("cash", 1, terminal_other_due=100))
    return cp.Graph("start", [cp.Node("start", 0, (cp.Action("draw", edges),))] + nodes,
                    {"facility": 60, "earnings": 65})


class Fixture:
    def __init__(self, directory, cash=40, failure=False):
        self.directory = Path(directory)
        self.gateway = Gateway.create(self.directory / "host.sqlite", cash, KEY)
        self.gateway.register_resource("facility", 60, RESOURCE_KEY)
        self.gateway.register_resource("earnings", 65, RESOURCE_KEY)
        self.gateway.register_graph("facility", facility(failure), {"start": "draw", "pay": "perform"},
            {"start": "new-risk", "pay": "settlement"},
            {"customer": "customer-account", "repay:facility-debt": "lender-account", "terminal:cash": "customer-account"})
        self.provider = provider_module.SyntheticProvider(self.directory / "provider.sqlite")
        self.adapter = online.OnlineAdapter(self.gateway.settlement())

    def flow(self):
        return self.gateway.snapshot()["completion"]["flows"]["flow"]

    def outcome(self, observation):
        flow = self.flow()
        return signed(KEY, "completion-outcome", {"workflow": "flow", "graph": flow["graph_digest"],
            "node": flow["node"], "action": flow["pending"]["action"],
            "history": codec.digest("completion-history", flow["history"]),
            "observation": observation, "evidence": "synthetic-observed-" + observation})

    def funding(self, receipt, resource, amount):
        state = self.gateway.snapshot()["completion"]
        flow = state["flows"]["flow"]
        edge = flow["pending"]["edge"]["fields"]
        return signed(RESOURCE_KEY, "completion-physical-credit", {"workflow": "flow", "graph": flow["graph_digest"],
            "node": flow["node"], "action": flow["pending"]["action"], "observation": edge["observation"],
            "receipt": receipt, "resource": resource, "resource_epoch": state["resources"][resource]["epoch"],
            "amount": codec.i64(amount), "occurrence": {"provider": "funding-provider", "account": "payer-account",
            "asset": "USD", "unit": "cent", "namespace": "account-posting", "epoch": "1", "reference": receipt},
            "evidence": "synthetic-physical-credit-" + receipt})

    def draw(self):
        g = self.gateway
        g.start("flow", "facility", 40)
        g.begin("flow")
        g.observe("flow", self.outcome("delivered"))
        envelope = self.funding("draw", "facility", 60)
        g.fund("flow", envelope)
        g.reconcile("flow")
        return envelope

    def latest(self, payment):
        state = self.gateway.snapshot()["op"]
        return max((k for k, v in self.flow()["commands"].items() if v["payment"] == payment),
                   key=lambda k: int(state["commands"][k]["request"]["attempt"].split(":")[-1]))

    def pay(self, payment, parts, close=True):
        key = self.latest(payment)
        self.provider.plan(key, parts, close=close)
        self.adapter.dispatch(key, self.provider)
        return key


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        work = HERE / "work"
        work.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix="case-", dir=work)
        self.addCleanup(self.temp.cleanup)
        self.fixture = Fixture(self.temp.name)

    def test_actual_40_cash_100_payment_and_65_repayment(self):
        f = self.fixture
        draw = f.draw()
        g = f.gateway
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["cash"], "100")
        g.begin("flow")
        f.pay("customer", [35, 65])
        g.observe("flow", f.outcome("earned"))
        g.fund("flow", f.funding("earned", "earnings", 65))
        g.reconcile("flow")
        g.begin("flow")
        f.pay("repay:facility-debt", [65])
        g.reconcile("flow")
        before = g.snapshot()
        self.assertEqual(f.flow()["phase"], "done")
        self.assertEqual(op_model.pool_view(before["op"])["cash"], "0")
        self.assertEqual(before["completion"]["resources"]["facility"]["used"], "60")
        self.assertEqual(before["completion"]["resources"]["earnings"]["used"], "65")
        g.fund("flow", draw)
        self.assertEqual(g.snapshot()["op"], before["op"])
        self.assertEqual(replay.replay(g.settlement().export_journal()).state, before["op"])

    def test_timeout_and_partial_closure_keep_a_funded_residual(self):
        f = self.fixture
        f.draw()
        g = f.gateway
        g.begin("flow")
        key = f.latest("customer")
        f.provider.available(False)
        f.adapter.dispatch(key, f.provider)
        self.assertTrue(g.snapshot()["op"]["commands"][key]["uncertain"])
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["external_reserved"], "100")
        with self.assertRaisesRegex(ValueError, "ActualActionPaymentIncomplete"):
            g.observe("flow", f.outcome("earned"))
        f.provider.available(True)
        f.pay("customer", [30], close=True)
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["internal_reserved"], "70")
        g.retry_payments("flow")
        residual = f.latest("customer")
        self.assertNotEqual(residual, key)
        self.assertEqual(g.snapshot()["op"]["commands"][residual]["quantity"], "70")
        f.pay("customer", [70])
        g.observe("flow", f.outcome("earned"))
        self.assertEqual(f.flow()["phase"], "edge")

    def test_provider_failure_branch_requires_100_initial_cash(self):
        f = self.fixture
        g = f.gateway
        g.register_graph("failure", facility(True), {"start": "draw", "pay": "perform"},
            {"start": "new-risk", "pay": "settlement"},
            {"customer": "customer-account", "repay:facility-debt": "lender-account", "terminal:cash": "customer-account"})
        with self.assertRaisesRegex(ValueError, "CompletionCashRequirement"):
            g.start("flow", "failure", 40)
        self.assertFalse(g.snapshot()["completion"]["flows"])

    def test_current_graph_and_resource_depletion_block_new_execution(self):
        f = self.fixture
        g = f.gateway
        g.start("flow", "facility", 40)
        g.register_resource("facility", 59, RESOURCE_KEY)
        with self.assertRaisesRegex(ValueError, "ResourceCapacityImpaired"):
            g.begin("flow")
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["internal_reserved"], "40")
        g.register_resource("facility", 60, RESOURCE_KEY)
        graph = facility()
        g.register_graph("facility", graph, {"start": "draw", "pay": "perform"},
            {"start": "new-risk", "pay": "settlement"}, {"customer": "different-account"})
        with self.assertRaisesRegex(ValueError, "CurrentGraphChanged"):
            g.begin("flow")

    def test_degraded_requirement_persists_and_margin_call_is_not_cash(self):
        g = self.fixture.gateway
        g.start("flow", "facility", 40)
        g.update_margin("flow", healthy=True, floor=10, stress=20, physical=0, parametric=30)
        g.update_margin("flow", healthy=False, floor=10, stress=20, physical=0, parametric=0)
        self.assertEqual(self.fixture.flow()["margin"], "30")
        with self.assertRaisesRegex(ValueError, "DegradedNewRisk"):
            g.begin("flow")
        g.update_margin("flow", healthy=True, floor=10, stress=20, physical=0, parametric=0)
        self.assertTrue(self.fixture.flow()["degraded"])
        g.update_margin("flow", healthy=True, floor=10, stress=20, physical=0, parametric=0,
                        recovery="synthetic-current-repricing-and-reconciliation")
        self.assertEqual(self.fixture.flow()["margin"], "20")
        g.update_margin("flow", healthy=True, floor=10, stress=50, physical=0, parametric=0)
        self.assertEqual(self.fixture.flow()["margin_shortfall"], "10")
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["cash"], "40")
        with self.assertRaisesRegex(ValueError, "UnfundedMarginCall"):
            g.begin("flow")

    def test_backing_loss_preserves_existing_hold_and_blocks_dispatch(self):
        f = self.fixture
        f.draw()
        g = f.gateway
        g.begin("flow")
        key = f.latest("customer")
        g.settlement().record_backing_change("synthetic-backing-loss", -1)
        state = g.snapshot()["op"]
        self.assertEqual((op_model.pool_view(state)["cash"], op_model.pool_view(state)["reserved"]), ("99", "100"))
        with self.assertRaisesRegex(ValueError, "ActualPoolImpaired"):
            f.adapter.dispatch(key, f.provider)
        self.assertEqual(f.provider.counts()["submits"], 0)

    def test_retained_margin_is_additional_to_spendable_completion_cash(self):
        f = self.fixture
        g = f.gateway
        with self.assertRaisesRegex(ValueError, "CompletionCashRequirement"):
            g.start("flow", "facility", 40, margin=30)
        f.draw()
        g.update_margin("flow", healthy=True, floor=30, stress=0, physical=0, parametric=0)
        before = g.snapshot()
        with self.assertRaisesRegex(ValueError, "CompletionCashRequirement"):
            g.begin("flow")
        self.assertEqual(g.snapshot(), before)
        self.assertEqual(op_model.pool_view(before["op"])["internal_reserved"], "100")

    def test_margin_increase_before_dispatch_retains_the_actual_reservation(self):
        f = self.fixture
        f.draw()
        g = f.gateway
        g.begin("flow")
        key = f.latest("customer")
        g.update_margin("flow", healthy=True, floor=30, stress=0, physical=0, parametric=0)
        self.assertEqual(f.flow()["margin_shortfall"], "30")
        with self.assertRaisesRegex(ValueError, "RetainedMarginUnavailable"):
            f.adapter.dispatch(key, f.provider)
        self.assertEqual(f.provider.counts()["submits"], 0)
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["external_reserved"], "100")
        g.update_margin("flow", healthy=True, floor=0, stress=0, physical=0, parametric=0)
        f.pay("customer", [100])
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["cash"], "0")

    def test_useful_completion_preserves_and_explicitly_releases_retained_margin(self):
        directory = Path(self.temp.name) / "retained"
        directory.mkdir()
        f = Fixture(directory, cash=70)
        g = f.gateway
        g.start("flow", "facility", 70, margin=30)
        g.begin("flow")
        g.observe("flow", f.outcome("delivered"))
        g.fund("flow", f.funding("draw", "facility", 60))
        g.reconcile("flow")
        g.begin("flow")
        f.pay("customer", [100])
        g.observe("flow", f.outcome("earned"))
        g.fund("flow", f.funding("earned", "earnings", 65))
        g.reconcile("flow")
        g.begin("flow")
        f.pay("repay:facility-debt", [65])
        g.reconcile("flow")
        self.assertEqual(f.flow()["phase"], "done")
        self.assertEqual((op_model.pool_view(g.snapshot()["op"])["cash"],
                          op_model.pool_view(g.snapshot()["op"])["internal_reserved"]), ("30", "30"))
        g.update_margin("flow", healthy=True, floor=0, stress=0, physical=0, parametric=0)
        self.assertEqual(op_model.pool_view(g.snapshot()["op"])["internal_reserved"], "0")
        self.assertEqual(f.flow()["released_cash"], "30")

    def worker(self, operation, point, envelope=None):
        request = {"database": str(self.fixture.gateway.path), "key": KEY.hex(), "workflow": "flow",
                   "operation": operation, "envelope": envelope}
        path = Path(self.temp.name) / "worker-request.json"
        path.write_bytes(codec.encode(request))
        result = subprocess.run([sys.executable, "-B", *(["-O"] if sys.flags.optimize else []),
                                 str(HERE / "worker.py"), str(path), point], capture_output=True)
        self.assertEqual(result.returncode, 77, result.stderr.decode())

    def test_physical_funding_and_contingent_use_commit_together_after_restart(self):
        f = self.fixture
        g = f.gateway
        g.start("flow", "facility", 40)
        g.begin("flow")
        g.observe("flow", f.outcome("delivered"))
        envelope = f.funding("draw", "facility", 60)
        before = g.snapshot()
        self.worker("fund", "inside_fund", envelope)
        self.assertEqual(g.snapshot(), before)
        self.worker("fund", "after_fund", envelope)
        successor = g.snapshot()
        self.assertEqual(op_model.pool_view(successor["op"])["cash"], "100")
        self.assertEqual(successor["completion"]["resources"]["facility"]["used"], "60")
        restarted = Gateway(g.path, KEY)
        restarted.fund("flow", envelope)
        self.assertEqual(restarted.snapshot(), successor)

    def test_internal_hold_and_actual_payment_commands_survive_restart_atomically(self):
        f = self.fixture
        f.draw()
        g = f.gateway
        before = g.snapshot()
        self.worker("begin", "inside_begin")
        self.assertEqual(g.snapshot(), before)
        self.worker("begin", "after_begin")
        successor = g.snapshot()
        self.assertEqual((op_model.pool_view(successor["op"])["internal_reserved"],
                          op_model.pool_view(successor["op"])["external_reserved"]), ("0", "100"))
        Gateway(g.path, KEY).begin("flow")
        self.assertEqual(g.snapshot(), successor)

    def test_repeated_observation_preserves_the_original_history(self):
        f = self.fixture
        g = f.gateway
        g.start("flow", "facility", 40)
        g.begin("flow")
        outcome = f.outcome("delivered")
        g.observe("flow", outcome)
        g.fund("flow", f.funding("draw", "facility", 60))
        g.reconcile("flow")
        before = g.snapshot()
        g.observe("flow", outcome)
        self.assertEqual(g.snapshot(), before)
        g.reconcile("flow")
        after = g.snapshot()
        self.assertEqual(after["completion"], before["completion"])
        self.assertEqual({k: v for k, v in after["op"].items() if k != "epochs"},
                         {k: v for k, v in before["op"].items() if k != "epochs"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
