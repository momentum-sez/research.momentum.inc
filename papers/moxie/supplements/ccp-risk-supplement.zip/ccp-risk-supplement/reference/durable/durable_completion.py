"""Finite completion policies over the actual isolated Op settlement store."""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import fields, is_dataclass
from fractions import Fraction
import hashlib
import hmac
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
P05 = ROOT / "encoding"
P12 = ROOT / "completion/runtime/completion.py"
if hashlib.sha256(P12.read_bytes()).hexdigest() != "d029f7f7407a844d3f921fecd15b2d7541ad95e03fd5eaa546ec4164d803439a":
    raise RuntimeError("ChangedCompletionModel")
for record in json.loads((HERE / "SOURCE-COPY.json").read_text()):
    if hashlib.sha256((ROOT / record["source"]).read_bytes()).hexdigest() != record["base_sha256"]:
        raise RuntimeError("ChangedOpBase")


def load(name, path):
    if name in sys.modules:
        if Path(sys.modules[name].__file__).resolve() != path.resolve():
            raise RuntimeError("ConflictingModule:" + name)
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


load("canonical_profile", P05 / "canonical_profile.py")
sys.path.insert(0, str(HERE / "op"))
import store as op_store
import model as op_model
import codec
import contract
import online
import replay
sys.path.pop(0)
for module in (op_store, op_model, codec, contract, online, replay):
    if Path(module.__file__).resolve().parent != HERE / "op":
        raise RuntimeError("WrongOpRuntime")
cp = load("p12_completion_model", P12)
CLASSES = {c.__name__: c for c in (cp.Debt, cp.Receipt, cp.Payment, cp.Edge, cp.Action, cp.Node)}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def units(value):
    q = cp.money(value)
    require(q.denominator == 1 and 0 <= q < 2**63, "IntegralSettlementQuantumRequired")
    return q.numerator


def pack(value):
    if isinstance(value, Fraction):
        return {"fraction": [str(value.numerator), str(value.denominator)]}
    if is_dataclass(value):
        return {"record": type(value).__name__, "fields": {f.name: pack(getattr(value, f.name)) for f in fields(value)}}
    if isinstance(value, tuple):
        return {"tuple": [pack(x) for x in value]}
    if isinstance(value, list):
        return [pack(x) for x in value]
    if isinstance(value, dict):
        return {k: pack(v) for k, v in value.items()}
    return value


def unpack(value):
    if isinstance(value, dict):
        if set(value) == {"fraction"}:
            return Fraction(*map(int, value["fraction"]))
        if set(value) == {"tuple"}:
            return tuple(unpack(x) for x in value["tuple"])
        if set(value) == {"record", "fields"}:
            return CLASSES[value["record"]](**{k: unpack(v) for k, v in value["fields"].items()})
        return {k: unpack(v) for k, v in value.items()}
    if isinstance(value, list):
        return [unpack(x) for x in value]
    return value


def graph_record(graph):
    return pack({"root": graph.root, "nodes": list(graph.nodes.values()), "resources": graph.resource_limits})


def graph_from(record, policy):
    data = unpack(record)
    original = cp.Graph(data["root"], data["nodes"], data["resources"])
    nodes = []
    for node in original.nodes.values():
        if node.terminal_due is None:
            require(node.identity in policy, "IncompletePolicy")
            selected = tuple(a for a in node.actions if a.identity == policy[node.identity])
            require(len(selected) == 1, "UnknownPolicyAction")
            node = cp.Node(node.identity, node.stage, selected, node.debts, None,
                           node.risk_budget, node.terminal_economic_loss)
        nodes.append(node)
    # Retain only states reachable under the selected adapted policy.
    by_id = {n.identity: n for n in nodes}
    seen = set()
    def visit(identity):
        if identity in seen:
            return
        seen.add(identity)
        for action in by_id[identity].actions:
            for edge in action.edges:
                visit(edge.target)
    visit(original.root)
    return cp.Graph(original.root, [n for n in nodes if n.identity in seen], original.resource_limits)


def future_resources(graph, identity):
    node = graph.nodes[identity]
    if node.terminal_due is not None:
        return {}
    result = {}
    for edge in node.actions[0].edges:
        branch = future_resources(graph, edge.target)
        for receipt in edge.receipts:
            branch[receipt.resource] = branch.get(receipt.resource, 0) + units(receipt.amount)
        for resource, amount in branch.items():
            result[resource] = max(result.get(resource, 0), amount)
    return result


def signed(key, domain, value):
    body = deepcopy(value)
    signature = hmac.digest(key, domain.encode() + b"\0" + codec.encode(body), "sha256").hex()
    return {"body": body, "signature": signature}


def verify(key, domain, envelope):
    require(type(envelope) is dict and set(envelope) == {"body", "signature"}, "SignedFactShape")
    expected = signed(key, domain, envelope["body"])
    require(type(envelope["signature"]) is str and hmac.compare_digest(expected["signature"], envelope["signature"]),
            "FactAuthentication")
    return deepcopy(envelope["body"])


class Gateway:
    """One durable authority owns all workflow holds and Op transactions."""
    def __init__(self, path, key, policy=None):
        self.path, self.key = Path(path), key
        self.policy = policy or contract.EvidencePolicy()
        with op_store.connect(self.path) as db:
            db.execute("CREATE TABLE IF NOT EXISTS completion_state (id INTEGER PRIMARY KEY CHECK(id=1), body BLOB NOT NULL, mac TEXT NOT NULL)")
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM completion_state WHERE id=1").fetchone() is None:
                self._save(db, {"graphs": {}, "resources": {}, "flows": {}, "funding": {}, "facts": {}})
            else:
                self._load(db)
            db.commit()

    @classmethod
    def create(cls, path, funding, key, **kwargs):
        op_store.SettlementStore.create(path, units(funding), **kwargs)
        return cls(path, key, kwargs.get("policy"))

    def _load(self, db):
        body, mac = db.execute("SELECT body,mac FROM completion_state WHERE id=1").fetchone()
        require(hmac.compare_digest(mac, hmac.digest(self.key, b"completion-state\0" + body, "sha256").hex()),
                "CompletionStateAuthentication")
        return codec.parse(body)

    def _save(self, db, state):
        body = codec.encode(state)
        require(len(body) <= 32_000_000, "CompletionStateTooLarge")
        mac = hmac.digest(self.key, b"completion-state\0" + body, "sha256").hex()
        db.execute("INSERT INTO completion_state VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,mac=excluded.mac", (body, mac))

    def _run(self, kind, function, crash=None):
        op_store.fault("before_" + kind, crash)
        with op_store.connect(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            state = self._load(db)
            op = op_store.SettlementStore(self.path, self.policy)
            op.borrowed = db
            result = function(state, op, db)
            for flow in state["flows"].values():
                self._recoveries(flow, op)
                self._hold(flow, op, db)
            self._save(db, state)
            op_store.fault("inside_" + kind, crash)
            db.commit()
        op_store.fault("after_" + kind, crash)
        return deepcopy(result)

    def snapshot(self):
        with op_store.connect(self.path) as db:
            db.execute("BEGIN")
            state = self._load(db)
            raw = db.execute("SELECT state FROM current WHERE id=1").fetchone()[0]
            return {"completion": state, "op": codec.parse(raw)}

    def register_resource(self, identity, capacity, authority_key):
        """Admit funded capacity. This commitment does not increase Op cash."""
        capacity = units(capacity)
        def update(state, op, db):
            old = state["resources"].get(identity)
            state["resources"][identity] = {"capacity": str(capacity), "key": authority_key.hex(),
                "used": old["used"] if old else "0", "epoch": old["epoch"] + 1 if old else 0}
        self._run("resource", update)

    def register_graph(self, identity, graph, policy, modes, payees):
        record = graph_record(graph)
        checked = graph_from(record, policy)
        for node in checked.nodes.values():
            if node.actions:
                require(modes.get(node.identity) in {"new-risk", "settlement", "closure"}, "ActionModeRequired")
        body = {"graph": record, "policy": deepcopy(policy), "modes": deepcopy(modes), "payees": deepcopy(payees)}
        digest = codec.digest("completion-graph", body)
        def update(state, op, db):
            state["graphs"][identity] = {"digest": digest, "body": body}
        self._run("graph", update)
        return digest

    def _graph(self, flow):
        body = flow["binding"]
        require(codec.digest("completion-graph", body) == flow["graph_digest"], "ImmutableGraphBinding")
        return graph_from(body["graph"], body["policy"])

    def _cash(self, flow, state):
        targets = {p["target"] for p in flow["payments"].values()}
        paid = sum(int(o["quantity"]) * (1 if o["kind"] == "payment" else -1)
                   for o in state["occurrences"].values() if o["target"] in targets)
        return int(flow["initial_cash"]) + sum(int(x["amount"]) for x in flow["receipts"].values()) - paid - int(flow["released_cash"])

    def _release(self, flow, op):
        if flow["hold"] is not None:
            op.commit("release_internal", {"id": flow["hold"], "owner": flow["id"],
                "source": flow["graph_digest"], "authority_epoch": op.read()["pool"]["authority_epoch"]})
            flow["hold"] = None

    def _recoveries(self, flow, op):
        state = op.read()
        flow["recovery"] = [identity for identity in flow["completed_payments"]
                            if int(op_model.target_view(state, flow["payments"][identity]["target"])["outstanding"])]
        if flow["recovery"] and flow["phase"] == "done":
            flow["phase"] = "recovery"
            flow["pending"] = {"action": "reperform", "mode": "closure", "payments": pack(()), "edge": None}

    def _hold(self, flow, op, db):
        state = op.read()
        external = sum(int(state["commands"][key]["reserved"]) for key in flow["commands"])
        cash = self._cash(flow, state)
        wanted = max(0, cash - external)
        if flow["phase"] == "done" and not flow["degraded"] and int(flow["margin"]) == 0:
            wanted = 0
        prior = int(state["internal_holds"][flow["hold"]]["quantity"]) if flow["hold"] else 0
        flow["cash_projection"] = str(cash)
        flow["margin_shortfall"] = str(max(0, int(flow["margin"]) - max(0, cash - external)))
        if wanted == prior:
            return
        before = flow["hold"]
        db.execute("SAVEPOINT hold_update")
        try:
            self._release(flow, op)
            if flow["phase"] == "done" and wanted == 0:
                flow["released_cash"] = str(int(flow["released_cash"]) + prior)
            if wanted:
                identity = codec.digest("completion-hold", {"flow": flow["id"], "generation": flow["hold_generation"]})
                op.commit("reserve_internal", {"id": identity, "owner": flow["id"], "source": flow["graph_digest"],
                    "quantity": codec.i64(wanted), "authority_epoch": op.read()["pool"]["authority_epoch"]})
                flow["hold"] = identity
                flow["hold_generation"] += 1
            db.execute("RELEASE hold_update")
            flow["hold_shortfall"] = "0"
            flow["cash_projection"] = str(self._cash(flow, op.read()))
        except ValueError as error:
            if str(error) not in {"INTERNAL_HOLD_FUNDING", "CURRENT_USE_AUTHORITY"}:
                raise
            db.execute("ROLLBACK TO hold_update")
            db.execute("RELEASE hold_update")
            flow["hold"] = before
            flow["hold_shortfall"] = str(max(0, wanted - prior))

    def _resource_free(self, state, identity):
        resource = state["resources"][identity]
        held = sum(int(f["resources"].get(identity, "0")) for f in state["flows"].values())
        return int(resource["capacity"]) - int(resource["used"]) - held

    def start(self, workflow, graph_id, initial_cash, *, margin=0, crash=None):
        initial_cash, margin = units(initial_cash), units(margin)
        def action(state, op, db):
            current = state["graphs"][graph_id]
            prior = state["flows"].get(workflow)
            if prior:
                require((prior["graph_id"], prior["initial_cash"], prior["graph_digest"]) ==
                        (graph_id, str(initial_cash), current["digest"]), "ImmutableWorkflowCommand")
                return prior
            graph = graph_from(current["body"]["graph"], current["body"]["policy"])
            requirement = graph.requirements()[0][graph.root]
            # The reference requirement is spendable completion cash. A
            # separately retained margin remains unavailable to these payments.
            require(initial_cash >= requirement + margin, "CompletionCashRequirement")
            resources = future_resources(graph, graph.root)
            for identity, amount in resources.items():
                require(identity in state["resources"] and self._resource_free(state, identity) >= amount,
                        "AggregateResourceReservation")
            flow = {"id": workflow, "graph_id": graph_id, "graph_digest": current["digest"], "binding": deepcopy(current["body"]),
                "initial_cash": str(initial_cash), "node": graph.root, "phase": "idle", "pending": None, "history": [],
                "receipts": {}, "payments": {}, "commands": {}, "resources": {k: str(v) for k, v in resources.items()},
                "completed_payments": [], "recovery": [], "completion_receipts": [], "released_cash": "0",
                "hold": None, "hold_generation": 0, "hold_shortfall": "0", "margin_shortfall": "0",
                "margin": str(margin), "degraded": False, "health": True, "risk_updates": []}
            state["flows"][workflow] = flow
            self._hold(flow, op, db)
            require(flow["hold"] is not None or initial_cash == 0, "AggregateCashReservation")
            return flow
        return self._run("start", action, crash)

    def _current(self, state, flow, op, mode):
        require(state["graphs"][flow["graph_id"]]["digest"] == flow["graph_digest"], "CurrentGraphChanged")
        require(not flow["degraded"] or mode != "new-risk", "DegradedNewRisk")
        require(op_model.pool_view(op.read())["status"] == "funded", "ActualPoolImpaired")
        require(self._cash(flow, op.read()) >= int(flow["margin"]), "UnfundedMarginCall")
        for identity in flow["resources"]:
            require(self._resource_free(state, identity) >= 0, "ResourceCapacityImpaired")

    def _retain_margin(self, flow, op, additional=0):
        current = op.read()
        external = sum(int(current["commands"][key]["reserved"]) for key in flow["commands"])
        require(self._cash(flow, current) >= external + additional + int(flow["margin"]),
                "RetainedMarginUnavailable")

    def _payment(self, flow, payment, op):
        quantity = units(payment.amount)
        if quantity == 0:
            return
        old = flow["payments"].get(payment.identity)
        target = codec.digest("completion-payment", {"workflow": flow["id"], "payment": payment.identity})
        source = codec.digest("completion-payment-binding", {"graph": flow["graph_digest"], "payment": pack(payment)})
        payee = flow["binding"]["payees"].get(payment.identity)
        require(type(payee) is str and payee, "PaymentPayeeRequired")
        op.create_target(target, quantity, payee, source)
        if old is None:
            old = {"target": target, "quantity": str(quantity), "source": source, "attempts": 0,
                   "settles": payment.settles}
            flow["payments"][payment.identity] = old
        view = op_model.target_view(op.read(), target)
        outstanding = int(view["outstanding"]) - int(view["reserved"])
        if outstanding:
            self._retain_margin(flow, op, outstanding)
            attempt = "completion-attempt:" + str(old["attempts"])
            key = op.prepare(target, attempt, outstanding)
            flow["commands"][key] = {"payment": payment.identity, "node": flow["node"],
                                     "graph": flow["graph_digest"], "mode": flow["pending"]["mode"] if flow["pending"] else "closure"}
            old["attempts"] += 1

    def begin(self, workflow, *, crash=None):
        def action(state, op, db):
            flow = state["flows"][workflow]
            if flow["phase"] in {"action", "terminal"}:
                return flow
            require(flow["phase"] == "idle", "PendingCompletionStage")
            require(not flow["recovery"], "UnresolvedPriorPayment")
            graph = self._graph(flow)
            node = graph.nodes[flow["node"]]
            mode = "settlement" if node.terminal_due is not None else flow["binding"]["modes"][node.identity]
            self._current(state, flow, op, mode)
            require(self._cash(flow, op.read()) >= graph.requirements()[0][node.identity] + int(flow["margin"]),
                    "CompletionCashRequirement")
            if node.terminal_due is not None:
                payments = tuple(cp.Payment("repay:" + d.identity, d.amount, d.identity) for d in node.debts)
                if node.terminal_other_due:
                    payments += (cp.Payment("terminal:" + node.identity, node.terminal_other_due),)
                flow["phase"] = "terminal"
                flow["pending"] = {"action": "terminal", "mode": mode, "payments": pack(payments), "edge": None}
            else:
                chosen = node.actions[0]
                payments = chosen.payments
                flow["phase"] = "action"
                flow["pending"] = {"action": chosen.identity, "mode": mode, "payments": pack(payments), "edge": None}
            self._release(flow, op)
            for payment in payments:
                self._payment(flow, payment, op)
            return flow
        return self._run("begin", action, crash)

    def _paid(self, flow, payments, op):
        for payment in payments:
            if units(payment.amount):
                row = flow["payments"].get(payment.identity)
                if row is None or int(op_model.target_view(op.read(), row["target"])["outstanding"]):
                    return False
        return True

    def observe(self, workflow, envelope, *, crash=None):
        fact = verify(self.key, "completion-outcome", envelope)
        def action(state, op, db):
            flow = state["flows"][workflow]
            identity = codec.digest("completion-observation", envelope)
            if identity in state["facts"]:
                require(state["facts"][identity] == envelope and fact["workflow"] == workflow, "OutcomeReplayBinding")
                return flow
            require(flow["phase"] == "action", "ActionObservationStage")
            pending = flow["pending"]
            expected = {"workflow": workflow, "graph": flow["graph_digest"], "node": flow["node"],
                        "action": pending["action"], "history": codec.digest("completion-history", flow["history"])}
            require(set(fact) == set(expected) | {"observation", "evidence"} and
                    all(fact[k] == v for k, v in expected.items()) and bool(fact["evidence"]), "OutcomeBinding")
            require(self._paid(flow, unpack(pending["payments"]), op), "ActualActionPaymentIncomplete")
            require(not flow["recovery"], "UnresolvedPriorPayment")
            for payment in unpack(pending["payments"]):
                if units(payment.amount) and payment.identity not in flow["completed_payments"]:
                    flow["completed_payments"].append(payment.identity)
            graph = self._graph(flow)
            edge = next((e for e in graph.nodes[flow["node"]].actions[0].edges if e.observation == fact["observation"]), None)
            require(edge is not None, "OutcomeOutsideModel")
            pending["edge"] = pack(edge)
            pending["outcome"] = deepcopy(envelope)
            state["facts"][identity] = deepcopy(envelope)
            flow["phase"] = "edge"
            return flow
        return self._run("observe", action, crash)

    def fund(self, workflow, envelope, *, crash=None):
        def action(state, op, db):
            flow = state["flows"][workflow]
            identity = envelope.get("body", {}).get("occurrence")
            if type(identity) is dict:
                previous = state["funding"].get(contract.occurrence_key(identity))
                if previous is not None:
                    require(previous == envelope and envelope["body"]["workflow"] == workflow,
                            "PhysicalFundingAlreadyOwned")
                    return flow
            require(flow["phase"] == "edge", "FundingStage")
            edge = unpack(flow["pending"]["edge"])
            body = envelope["body"]
            receipt = next((r for r in edge.receipts if r.identity == body.get("receipt")), None)
            require(receipt is not None, "UnknownContingentReceipt")
            resource = state["resources"][receipt.resource]
            fact = verify(bytes.fromhex(resource["key"]), "completion-physical-credit", envelope)
            expected = {"workflow": workflow, "graph": flow["graph_digest"], "node": flow["node"],
                "action": flow["pending"]["action"], "observation": edge.observation, "receipt": receipt.identity,
                "resource": receipt.resource, "resource_epoch": resource["epoch"], "amount": codec.i64(units(receipt.amount))}
            require(set(fact) == set(expected) | {"occurrence", "evidence"} and
                    all(fact[k] == v for k, v in expected.items()) and bool(fact["evidence"]), "PhysicalFundingBinding")
            ident = fact["occurrence"]
            require(type(ident) is dict and set(ident) == {"provider", "account", "asset", "unit", "namespace", "epoch", "reference"}
                    and all(type(v) is str and v for v in ident.values()), "PhysicalFundingIdentity")
            pool = op.read()["pool"]
            require((ident["account"], ident["asset"], ident["unit"]) == (pool["account"], pool["asset"], pool["unit"]), "PhysicalFundingScope")
            occurrence = contract.occurrence_key(ident)
            prior = state["funding"].get(occurrence)
            if prior is not None:
                require(prior == envelope, "PhysicalFundingAlreadyOwned")
                return flow
            require(receipt.identity not in flow["receipts"], "ReceiptAlreadyFunded")
            amount = units(receipt.amount)
            require(int(flow["resources"].get(receipt.resource, "0")) >= amount, "MissingContingentReservation")
            # Admit the physical fact even when a separate capacity update exposes a deficit.
            op.commit("physical_funding", {"occurrence": ident, "quantity": codec.i64(amount),
                      "evidence": codec.digest("completion-funding-evidence", envelope)})
            state["funding"][occurrence] = deepcopy(envelope)
            flow["receipts"][receipt.identity] = {"amount": str(amount), "occurrence": occurrence,
                                                 "loan": pack(receipt.loan), "resource": receipt.resource}
            resource["used"] = str(int(resource["used"]) + amount)
            flow["resources"][receipt.resource] = str(int(flow["resources"][receipt.resource]) - amount)
            return flow
        return self._run("fund", action, crash)

    def reconcile(self, workflow, *, crash=None):
        def action(state, op, db):
            flow = state["flows"][workflow]
            op.consume_local()
            self._recoveries(flow, op)
            graph = self._graph(flow)
            if flow["phase"] in {"idle", "done"}:
                return flow
            if op_model.pool_view(op.read())["status"] != "funded":
                flow["obstruction"] = "ActualPoolImpaired"
                return flow
            if flow["phase"] in {"terminal", "recovery"}:
                if self._paid(flow, unpack(flow["pending"]["payments"]), op) and not flow["recovery"]:
                    for payment in unpack(flow["pending"]["payments"]):
                        if units(payment.amount) and payment.identity not in flow["completed_payments"]:
                            flow["completed_payments"].append(payment.identity)
                    flow["history"].append({"node": flow["node"], "terminal": True})
                    flow["phase"] = "done"
                    flow["pending"] = None
                    flow["resources"] = {}
                    flow["completion_receipts"].append({"history": codec.digest("completion-history", flow["history"]),
                        "op_state": codec.digest("settlement-state", op.read())})
                return flow
            require(flow["phase"] == "edge", "EdgeReconciliationStage")
            if flow["recovery"]:
                flow["obstruction"] = "UnresolvedPriorPayment"
                return flow
            edge = unpack(flow["pending"]["edge"])
            if not all(r.identity in flow["receipts"] for r in edge.receipts):
                return flow
            self._release(flow, op)
            for payment in edge.payments:
                self._payment(flow, payment, op)
            if not self._paid(flow, edge.payments, op):
                return flow
            for payment in edge.payments:
                if units(payment.amount) and payment.identity not in flow["completed_payments"]:
                    flow["completed_payments"].append(payment.identity)
            if self._cash(flow, op.read()) < graph.requirements()[0][edge.target] + int(flow["margin"]):
                flow["obstruction"] = "ActualContinuationShortfall"
                return flow
            flow["history"].append({"node": flow["node"], "action": flow["pending"]["action"],
                "observation": edge.observation, "evidence": flow["pending"]["outcome"]})
            flow["node"] = edge.target
            flow["pending"] = None
            flow["phase"] = "idle"
            flow["resources"] = {k: str(v) for k, v in future_resources(graph, edge.target).items()}
            return flow
        return self._run("reconcile", action, crash)

    def retry_payments(self, workflow):
        def action(state, op, db):
            flow = state["flows"][workflow]
            require(flow["pending"] is not None or flow["recovery"], "NoPendingPayment")
            self._current(state, flow, op, "closure" if flow["recovery"] else flow["pending"]["mode"])
            self._release(flow, op)
            payments = tuple(cp.Payment(identity, int(flow["payments"][identity]["quantity"]),
                              flow["payments"][identity]["settles"]) for identity in flow["recovery"])
            if not payments:
                payments = unpack(flow["pending"]["payments"])
            if not flow["recovery"] and flow["phase"] == "edge":
                payments = unpack(flow["pending"]["edge"]).payments
            for payment in payments:
                old_commands = set(flow["commands"])
                self._payment(flow, payment, op)
                if flow["recovery"]:
                    for key in set(flow["commands"]) - old_commands:
                        flow["commands"][key]["mode"] = "closure"
            return flow
        return self._run("retry", action)

    def update_margin(self, workflow, *, healthy, floor, stress, physical, parametric, recovery=None):
        values = list(map(units, (floor, stress, physical, parametric)))
        require(type(healthy) is bool, "HealthBooleanRequired")
        def action(state, op, db):
            flow = state["flows"][workflow]
            if not healthy:
                flow["degraded"] = True
            if recovery is not None:
                require(healthy and type(recovery) is str and recovery, "RecoveryDecisionRequired")
                flow["degraded"] = False
            flow["health"] = healthy
            base = max(values[:3])
            flow["margin"] = str(max(base, int(flow["margin"])) if flow["degraded"] else max(base, values[3]))
            flow["risk_updates"].append({"healthy": healthy, "layers": [str(x) for x in values],
                "recovery": recovery, "required": flow["margin"], "degraded": flow["degraded"]})
            return flow
        return self._run("margin", action)

    def op_event(self, kind, data, crash=None):
        allowed = {"arm", "transmit", "acknowledged", "unavailable", "receive", "epoch", "consume", "finish_epoch", "funding", "authority"}
        require(kind in allowed, "CompletionGatewayEvent")
        def action(state, op, db):
            if kind == "funding":
                require(codec.decode_i64(data["delta"]) <= 0, "PhysicalCreditRequired")
            if kind in {"arm", "transmit"}:
                key = data["command"]
                owners = [f for f in state["flows"].values() if key in f["commands"]]
                require(len(owners) == 1, "UnboundCompletionCommand")
                flow = owners[0]
                self._current(state, flow, op, flow["commands"][key]["mode"])
                self._retain_margin(flow, op)
            return op.commit(kind, data)
        return self._run("op_" + kind, action, crash)

    def settlement(self):
        owner = self
        class Managed(op_store.SettlementStore):
            def commit(self, kind, data, crash=None):
                return owner.op_event(kind, data, crash)
        return Managed(self.path, self.policy)
