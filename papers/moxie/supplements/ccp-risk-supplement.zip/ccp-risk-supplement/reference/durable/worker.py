"""Terminate one actual completion transaction at the requested boundary."""
from pathlib import Path
import sys
from durable_completion import Gateway, codec

request = codec.parse(Path(sys.argv[1]).read_bytes())
gateway = Gateway(request["database"], bytes.fromhex(request["key"]))
if request["operation"] == "fund":
    gateway.fund(request["workflow"], request["envelope"], crash=sys.argv[2])
elif request["operation"] == "begin":
    gateway.begin(request["workflow"], crash=sys.argv[2])
else:
    raise ValueError("UnknownWorkerOperation")
