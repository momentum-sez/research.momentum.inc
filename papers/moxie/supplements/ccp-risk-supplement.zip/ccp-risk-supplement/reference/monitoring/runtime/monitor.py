"""Exact reference gate under explicitly declared conditional binary laws.

SQLite transactions provide persistence and stale-writer rejection. The caller
is authorized to supply observations, funding facts, and law assumptions.
Hashing records identity and history. It does not authenticate those facts.
"""

import copy
import hashlib
import json
import sqlite3
from fractions import Fraction


class Invalid(ValueError):
    pass


class Stale(Invalid):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def fraction(value):
    require(isinstance(value, (str, int, Fraction)) and not isinstance(value, bool), 'exact rational required')
    return Fraction(value)


def rational(value):
    return str(fraction(value))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def identifier(value):
    require(isinstance(value, str) and bool(value.strip()), 'nonempty identifier required')
    return value


def p13_metadata(raw_bytes, expected_sha256):
    """Read existing certificate metadata without evaluating a P13 estimator."""
    require(hashlib.sha256(raw_bytes).hexdigest() == expected_sha256, 'P13 artifact hash mismatch')
    payload = json.loads(raw_bytes)
    def decoded(value):
        return Fraction(int(value['numerator_hex'], 16), int(value['denominator_hex'], 16))
    catalogue = payload['catalogue']
    entries = {}
    for index, window in enumerate(catalogue['windows']):
        entries[str(index)] = {'start': window['end'] - window['length'] + 1, 'end': window['end'],
                              'statement': 'Member of the fixed P13 simultaneous conditional-law catalogue.',
                              'source_window': copy.deepcopy(window), 'source_model': payload['model_id'],
                              'source_catalogue': payload['catalogue_id'], 'source_sha256': expected_sha256}
    return {'entries': entries, 'delta': decoded(catalogue['delta']), 'rho': decoded(catalogue['rho']),
            'external_catalogue_id': payload['catalogue_id'],
            'simultaneous_scope': payload['simultaneous_validity_scope'],
            'assumption': payload['drift_premise'], 'conditional_at_issuance': False}


class Monitor:
    ASSUMPTIONS = {
        'observations': 'Authorized caller supplies successive binary outcomes in observation order.',
        'calibration': 'Under each epoch null, E[Y_t given the full past] is at most p_t, registered before Y_t; bets are nonnegative.',
        'action': 'For the recorded common binary adverse-event stream and action class, every future one-step bad-event probability is at most p0 conditionally on its full past. The monitor does not certify this law.',
        'catalogue': 'The entire deterministic catalogue and its simultaneous failure bound are valid and fixed before the first observation.',
        'funding': 'Authorized caller supplies funded cash changes and actual outcome facts.',
        'baseline': 'Caller certifies baseline and closeout operations add no modeled exposure; funding alone does not establish absence of every economic risk.',
        'scope': 'Reference one-step monitor and current W-step union-bound gate. No authentication or provider guarantee.',
    }

    @classmethod
    def create(cls, path, *, alarm_budget, certificate_budget, action_budget,
               event_class='Common binary adverse event for this monitor\u2019s model-exposure actions'):
        budgets = {}
        for name, value in [('alarm', alarm_budget), ('certificate', certificate_budget), ('action', action_budget)]:
            value = fraction(value)
            require(0 <= value <= 1, 'probability budget must lie in [0,1]')
            budgets[name] = {'limit': str(value), 'spent': '0'}
        state = dict(cutoff=0, budgets=budgets, epochs={}, current=None, catalogue={},
                     certificates={}, decisions={}, occurrences={}, outcomes={}, commands={},
                     cash='0', reserved='0', event_class=identifier(event_class), assumptions=cls.ASSUMPTIONS)
        db = sqlite3.connect(path, isolation_level=None)
        try:
            db.execute('BEGIN IMMEDIATE')
            db.execute('CREATE TABLE current (singleton INTEGER PRIMARY KEY CHECK(singleton=1), revision INTEGER, state TEXT, head TEXT)')
            db.execute('CREATE TABLE history (revision INTEGER PRIMARY KEY, previous TEXT, event TEXT, state TEXT, head TEXT)')
            db.execute("CREATE TRIGGER history_no_update BEFORE UPDATE ON history BEGIN SELECT RAISE(ABORT,'immutable history'); END")
            db.execute("CREATE TRIGGER history_no_delete BEFORE DELETE ON history BEGIN SELECT RAISE(ABORT,'immutable history'); END")
            event = {'kind': 'create', 'budgets': budgets, 'event_class': event_class, 'assumptions': cls.ASSUMPTIONS}
            head = digest(['0', event, state])
            db.execute('INSERT INTO current VALUES (1,0,?,?)', (canonical(state), head))
            db.execute('INSERT INTO history VALUES (0,?,?,?,?)', ('0', canonical(event), canonical(state), head))
            db.commit()
        finally:
            db.close()
        return cls(path)

    def __init__(self, path):
        self.path = str(path)
        self.revision = self.snapshot()['revision']

    def snapshot(self):
        with sqlite3.connect(self.path) as db:
            row = db.execute('SELECT revision,state,head FROM current WHERE singleton=1').fetchone()
        require(row is not None, 'missing monitor')
        return {'revision': row[0], 'state': json.loads(row[1]), 'head': row[2]}

    def peek(self):
        return self.snapshot()

    def history(self):
        with sqlite3.connect(self.path) as db:
            rows = db.execute('SELECT revision,previous,event,state,head FROM history ORDER BY revision').fetchall()
        return [dict(revision=r[0], previous=r[1], event=json.loads(r[2]), state=json.loads(r[3]), head=r[4]) for r in rows]

    def refresh(self):
        result = self.snapshot()
        self.revision = result['revision']
        return result

    def _commit(self, command, request, transition):
        db = sqlite3.connect(self.path, isolation_level=None)
        try:
            db.execute('BEGIN IMMEDIATE')
            revision, encoded, previous = db.execute('SELECT revision,state,head FROM current WHERE singleton=1').fetchone()
            state = json.loads(encoded)
            old = state['commands'].get(command)
            if old is not None:
                require(old['request'] == digest(request), 'command identity reused with changed request')
                db.rollback()
                self.revision = revision
                return copy.deepcopy(old['result'])
            if revision != self.revision:
                raise Stale('writer revision is stale')
            result = transition(state, revision + 1)
            state['commands'][command] = {'request': digest(request), 'result': result}
            event = {'command': command, 'request': request, 'result': result}
            head = digest([previous, event, state])
            db.execute('INSERT INTO history VALUES (?,?,?,?,?)', (revision + 1, previous, canonical(event), canonical(state), head))
            db.execute('UPDATE current SET revision=?,state=?,head=? WHERE singleton=1', (revision + 1, canonical(state), head))
            db.commit()
            self.revision = revision + 1
            return copy.deepcopy(result)
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _spend(state, name, amount):
        amount = fraction(amount)
        budget = state['budgets'][name]
        require(amount >= 0, 'negative probability charge')
        total = fraction(budget['spent']) + amount
        require(total <= fraction(budget['limit']), f'{name} budget exhausted')
        budget['spent'] = str(total)

    def fund(self, fact_id, delta):
        request = {'kind': 'fund', 'fact_id': identifier(fact_id), 'delta': rational(delta)}
        def transition(state, rev):
            total = fraction(state['cash']) + fraction(delta)
            require(total >= fraction(state['reserved']), 'funding would consume reserved cash')
            state['cash'] = str(total)
            return {'revision': rev, 'cash': str(total)}
        return self._commit('fund:' + fact_id, request, transition)

    @staticmethod
    def catalogue_digest(entries, delta, rho):
        return digest({'entries': entries, 'delta': rational(delta), 'rho': rational(rho)})

    def register_catalogue(self, catalogue_id, entries, *, delta, rho, expected_digest):
        entries = copy.deepcopy(entries)
        delta, rho = fraction(delta), fraction(rho)
        require(delta >= 0 and rho >= 0 and delta + rho <= 1, 'invalid simultaneous failure cost')
        identity = self.catalogue_digest(entries, delta, rho)
        require(identity == expected_digest, 'catalogue digest mismatch')
        request = dict(kind='catalogue', catalogue_id=identifier(catalogue_id), entries=entries,
                       delta=str(delta), rho=str(rho), digest=identity)
        def transition(state, rev):
            require(state['cutoff'] == 0, 'catalogue must be fixed at initial observation history')
            require(all(c['digest'] != identity for c in state['catalogue'].values()), 'catalogue relabeling')
            require(bool(entries), 'empty catalogue')
            for key, entry in entries.items():
                identifier(key)
                start, end = entry['start'], entry['end']
                require(type(start) is int and type(end) is int and 1 <= start <= end, 'invalid catalogue window')
                require(isinstance(entry['statement'], str) and bool(entry['statement']), 'missing certificate statement')
            self._spend(state, 'certificate', delta + rho)
            state['catalogue'][catalogue_id] = dict(request, revision=rev, committed_cutoff=0)
            return {'revision': rev, 'catalogue': catalogue_id, 'digest': identity, 'charged': str(delta + rho)}
        return self._commit('catalogue:' + catalogue_id, request, transition)

    def inspect_window(self, catalogue_id, entry_id):
        snapshot = self.snapshot()
        record = snapshot['state']['catalogue'][catalogue_id]
        entry = record['entries'][entry_id]
        require(entry['end'] <= snapshot['state']['cutoff'], 'window has not ended')
        return dict(catalogue=catalogue_id, entry=entry_id, window=copy.deepcopy(entry), digest=record['digest'],
                    failure_bound=str(fraction(record['delta']) + fraction(record['rho'])),
                    inspected_cutoff=snapshot['state']['cutoff'], conditional_at_issuance=False,
                    scope='Past-data-selected member of the initial fixed simultaneous catalogue.')

    def start_epoch(self, epoch_id, *, model, fit_id, alpha, risk_p0):
        alpha, p0 = fraction(alpha), fraction(risk_p0)
        require(0 < alpha <= 1 and 0 <= p0 <= 1, 'invalid epoch parameters')
        request = dict(kind='epoch', epoch=identifier(epoch_id), model=identifier(model), fit_id=identifier(fit_id),
                       alpha=str(alpha), risk_p0=str(p0))
        def transition(state, rev):
            require(all(e['fit_id'] != fit_id for e in state['epochs'].values()), 'fit identity cannot be relabeled to reset evidence')
            self._spend(state, 'alarm', alpha)
            record = dict(request, start=state['cutoff'], e='1', alarm=(alpha == 1), forecast=None,
                          declaration='New model and fit declared by caller. Identity uniqueness does not prove fit independence. Conditional validity is assumed and does not require independent fitting.')
            state['epochs'][epoch_id] = record
            state['current'] = epoch_id
            return {'revision': rev, 'epoch': epoch_id, 'alpha_charged': str(alpha), 'e': '1'}
        return self._commit('epoch:' + epoch_id, request, transition)

    def forecast(self, epoch_id, *, cutoff, p, bet):
        p, bet = fraction(p), fraction(bet)
        require(0 <= p <= 1 and bet >= 0 and 1 - bet * p >= 0 and 1 + bet * (1 - p) >= 0, 'invalid nonnegative bet or e-factor')
        request = dict(kind='forecast', epoch=identifier(epoch_id), cutoff=cutoff, p=str(p), bet=str(bet))
        def transition(state, rev):
            require(epoch_id == state['current'], 'old model epoch')
            epoch = state['epochs'][epoch_id]
            require(not epoch['alarm'], 'epoch alarm is terminal')
            require(type(cutoff) is int and cutoff == state['cutoff'] + 1, 'forecast must precede the next observation')
            require(p <= fraction(epoch['risk_p0']), 'forecast conflicts with declared conditional risk bound')
            require(epoch['forecast'] is None, 'forecast already registered')
            epoch['forecast'] = dict(request, registered_revision=rev, registered_cutoff=state['cutoff'])
            return {'revision': rev, 'cutoff': cutoff, 'epoch': epoch_id}
        return self._commit(f'forecast:{epoch_id}:{cutoff}', request, transition)

    def observe(self, cutoff, outcome):
        require(type(cutoff) is int and type(outcome) is int and outcome in (0, 1), 'binary observation required')
        request = dict(kind='observe', cutoff=cutoff, outcome=outcome)
        def transition(state, rev):
            require(cutoff == state['cutoff'] + 1, 'observation cutoff must increase by one')
            epoch = state['epochs'].get(state['current'])
            if epoch is not None and not epoch['alarm']:
                forecast = epoch['forecast']
                require(forecast is not None and forecast['cutoff'] == cutoff, 'observation lacks precommitted forecast')
                factor = 1 + fraction(forecast['bet']) * (outcome - fraction(forecast['p']))
                epoch['e'] = str(fraction(epoch['e']) * factor)
                epoch['forecast'] = None
                epoch['alarm'] = fraction(epoch['e']) >= 1 / fraction(epoch['alpha'])
            state['cutoff'] = cutoff
            return {'revision': rev, 'cutoff': cutoff, 'epoch': state['current'],
                    'e': None if epoch is None else epoch['e'], 'alarm': False if epoch is None else epoch['alarm']}
        return self._commit(f'observe:{cutoff}', request, transition)

    def conditional_certificate(self, certificate_id, epoch_id, *, horizon):
        require(type(horizon) is int and horizon > 0, 'positive integer horizon required')
        request = dict(kind='conditional_certificate', certificate=identifier(certificate_id), epoch=identifier(epoch_id), horizon=horizon)
        def transition(state, rev):
            require(epoch_id == state['current'], 'old model epoch')
            epoch = state['epochs'][epoch_id]
            require(not epoch['alarm'], 'alarmed model cannot issue current certificate')
            require(epoch['forecast'] is not None, 'current one-step forecast required')
            q = min(Fraction(1), horizon * fraction(epoch['risk_p0']))
            cert = dict(request, revision=rev, cutoff=state['cutoff'], model=epoch['model'], fit_id=epoch['fit_id'],
                        start=state['cutoff'] + 1, end=state['cutoff'] + horizon, q=str(q), p0=epoch['risk_p0'],
                        forecast=copy.deepcopy(epoch['forecast']), conditional_at_issuance=True,
                        event_class=state['event_class'], assumptions=self.ASSUMPTIONS['action'])
            state['certificates'][certificate_id] = cert
            return copy.deepcopy(cert)
        return self._commit('certificate:' + certificate_id, request, transition)

    def admit(self, action_id, *, occurrence, mode, amount, risk_increase, certificate=None):
        amount, increase = fraction(amount), fraction(risk_increase)
        require(amount > 0 and increase >= 0, 'positive funded amount and nonnegative risk increase required')
        require(mode in ('model', 'funded_baseline', 'closeout'), 'unknown action mode')
        request = dict(kind='admit', action=identifier(action_id), occurrence=identifier(occurrence), mode=mode,
                       amount=str(amount), risk_increase=str(increase), certificate=certificate)
        def transition(state, rev):
            require(occurrence not in state['occurrences'], 'occurrence cannot be relabeled')
            cert = state['certificates'].get(certificate)
            reason, charge = None, Fraction(0)
            if mode == 'model':
                if cert is None or not cert['conditional_at_issuance']:
                    reason = 'current conditional certificate required'
                elif cert['epoch'] != state['current'] or state['epochs'][cert['epoch']]['alarm']:
                    reason = 'old or alarmed model'
                elif cert['cutoff'] != state['cutoff']:
                    reason = 'certificate is stale after observation'
                else:
                    charge = fraction(cert['q'])
                    budget = state['budgets']['action']
                    if fraction(budget['spent']) + charge > fraction(budget['limit']):
                        reason = 'action risk budget exhausted'
            elif increase != 0:
                reason = 'baseline and closeout cannot increase modeled exposure'
            if fraction(state['cash']) - fraction(state['reserved']) < amount:
                reason = 'insufficient current funded cash'
            accepted = reason is None
            funding = {'cash': state['cash'], 'reserved_before': state['reserved'], 'requested': str(amount)}
            if accepted:
                self._spend(state, 'action', charge)
                state['reserved'] = str(fraction(state['reserved']) + amount)
            decision = dict(request, revision=rev, cutoff=state['cutoff'], current_epoch=state['current'],
                            event_class=state['event_class'],
                            model_record=copy.deepcopy(state['epochs'].get(state['current'])),
                            certificate_record=copy.deepcopy(cert), funding=funding, admitted=accepted,
                            result='admitted' if accepted else reason, risk_charge=str(charge if accepted else 0),
                            scope=('Conditional adverse-event family for admitted model actions' if mode == 'model'
                                   else 'Outside model-action adverse-event probability family; funded/nonexpansion only'),
                            adverse_probability_bound=str(charge) if mode == 'model' and accepted else None,
                            existing_risk='unquantified' if mode != 'model' else 'subject to the recorded conditional contract')
            state['decisions'][action_id] = decision
            if accepted:
                state['occurrences'][occurrence] = action_id
            return copy.deepcopy(decision)
        return self._commit('admit:' + action_id, request, transition)

    def resolve(self, action_id, *, filled):
        require(type(filled) is bool, 'explicit Boolean fill status required')
        request = dict(kind='resolve', action=identifier(action_id), filled=filled)
        def transition(state, rev):
            action = state['decisions'][action_id]
            require(action['admitted'], 'rejected action has no funded reservation')
            amount = fraction(action['amount'])
            state['reserved'] = str(fraction(state['reserved']) - amount)
            if filled:
                state['cash'] = str(fraction(state['cash']) - amount)
            result = dict(request, revision=rev, cutoff=state['cutoff'], risk_refund='0')
            state['outcomes'][action_id] = result
            return result
        return self._commit('resolve:' + action_id, request, transition)
