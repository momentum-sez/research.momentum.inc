"""Bounded useful and adversarial checks for the persistent reference monitor."""

import hashlib
import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from fractions import Fraction as F
from pathlib import Path

from monitor import Monitor, Invalid, Stale, digest, p13_metadata


class MonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'monitor.sqlite'
        self.m = Monitor.create(self.path, alarm_budget='1/5', certificate_budget='1/5', action_budget='1/2')

    def tearDown(self):
        self.tmp.cleanup()

    def epoch(self, name='e1', fit='fit1', alpha='1/10', p0='1/10'):
        return self.m.start_epoch(name, model='model:' + fit, fit_id=fit, alpha=alpha, risk_p0=p0)

    def current(self, horizon=2):
        self.epoch()
        self.m.forecast('e1', cutoff=1, p='1/10', bet=1)
        return self.m.conditional_certificate('c1', 'e1', horizon=horizon)

    def catalogue(self):
        entries = {'short': {'start': 1, 'end': 2, 'statement': 'Fixed simultaneous two-observation window'},
                   'long': {'start': 1, 'end': 3, 'statement': 'Fixed simultaneous three-observation window'}}
        sha = self.m.catalogue_digest(entries, F(1, 20), F(1, 100))
        return entries, sha, self.m.register_catalogue('cat', entries, delta='1/20', rho='1/100', expected_digest=sha)

    def test_useful_continue_and_detection_then_funded_closeout(self):
        self.m.fund('cash:1', 100)
        self.current()
        decision = self.m.admit('a1', occurrence='command:1', mode='model', amount=10, risk_increase=5, certificate='c1')
        self.assertTrue(decision['admitted'])
        self.assertEqual(decision['risk_charge'], '1/5')
        self.assertFalse(self.m.observe(1, 0)['alarm'])
        # A high, admissible bet detects a positive event without retrospective fitting.
        self.m.forecast('e1', cutoff=2, p='1/10', bet=10)
        self.assertFalse(self.m.observe(2, 1)['alarm'])  # E=.9*10=9 < 10.
        self.m.forecast('e1', cutoff=3, p='1/10', bet=10)
        alarm = self.m.observe(3, 1)
        self.assertTrue(alarm['alarm'])
        self.assertEqual(alarm['e'], '90')
        rejected = self.m.admit('a2', occurrence='command:2', mode='model', amount=1, risk_increase=1, certificate='c1')
        self.assertFalse(rejected['admitted'])
        closeout = self.m.admit('close', occurrence='close:1', mode='closeout', amount=2, risk_increase=0)
        self.assertTrue(closeout['admitted'])
        self.assertEqual(closeout['risk_charge'], '0')
        self.assertEqual(self.m.snapshot()['state']['budgets']['action']['spent'], '1/5')

    def test_peeking_is_free_and_alarm_is_terminal(self):
        self.epoch()
        self.m.forecast('e1', cutoff=1, p='1/10', bet=10)
        self.assertTrue(self.m.observe(1, 1)['alarm'])
        before = self.m.snapshot()
        for _ in range(30):
            self.assertEqual(self.m.peek(), before)
        with self.assertRaises(Invalid):
            self.m.forecast('e1', cutoff=2, p='1/10', bet=10)
        self.assertEqual(self.m.snapshot(), before)

    def test_reset_spends_fresh_alpha_and_model_ids_cannot_relabel_fit(self):
        self.epoch()
        with self.assertRaises(Invalid):
            self.epoch(name='alias', fit='fit1')
        self.m.forecast('e1', cutoff=1, p='1/10', bet=10)
        self.m.observe(1, 1)
        self.epoch('e2', 'fit2')
        self.assertEqual(self.m.snapshot()['state']['budgets']['alarm']['spent'], '1/5')
        with self.assertRaises(Invalid):
            self.epoch('e3', 'fit3')
        with self.assertRaises(Invalid):
            self.m.forecast('e1', cutoff=2, p='1/10', bet=1)
        self.m.forecast('e2', cutoff=2, p='1/10', bet=1)
        self.assertFalse(self.m.observe(2, 0)['alarm'])

    def test_forecasts_precede_each_one_step_observation(self):
        self.epoch()
        with self.assertRaises(Invalid):
            self.m.observe(1, 1)
        with self.assertRaises(Invalid):
            self.m.forecast('e1', cutoff=2, p='1/10', bet=1)
        with self.assertRaises(Invalid):
            self.m.forecast('e1', cutoff=1, p='1/10', bet=11)
        with self.assertRaises(Invalid):
            self.m.forecast('e1', cutoff=1, p='1/10', bet=-1)
        self.m.forecast('e1', cutoff=1, p='1/10', bet=1)
        with self.assertRaises(Invalid):
            self.m.forecast('e1', cutoff=1, p='1/10', bet=2)
        self.m.observe(1, 0)
        with self.assertRaises(Invalid):
            self.m.observe(1, 1)
        with self.assertRaises(Invalid):
            self.m.observe(3, 0)

    def test_catalogue_spends_once_and_completed_selection_is_not_conditional(self):
        entries, sha, committed = self.catalogue()
        before = self.m.snapshot()
        self.assertEqual(self.m.register_catalogue('cat', entries, delta='1/20', rho='1/100', expected_digest=sha), committed)
        self.assertEqual(self.m.snapshot(), before)
        with self.assertRaises(Invalid):
            self.m.register_catalogue('alias', entries, delta='1/20', rho='1/100', expected_digest=sha)
        with self.assertRaises(Invalid):
            self.m.inspect_window('cat', 'short')
        self.m.observe(1, 1)
        self.m.observe(2, 0)
        inspected = self.m.inspect_window('cat', 'short')
        self.assertFalse(inspected['conditional_at_issuance'])
        self.assertEqual(inspected['failure_bound'], '3/50')
        before = self.m.snapshot()
        for _ in range(20):
            self.assertEqual(self.m.inspect_window('cat', 'short'), inspected)
        self.assertEqual(self.m.snapshot(), before)
        self.m.fund('cash', 5)
        action = self.m.admit('cat_action', occurrence='cat:1', mode='model', amount=1, risk_increase=1, certificate='cat')
        self.assertFalse(action['admitted'])
        totals = self.m.snapshot()['state']['budgets']
        self.assertEqual(totals['certificate']['spent'], '3/50')
        self.assertEqual(totals['alarm']['spent'], '0')
        self.assertEqual(totals['action']['spent'], '0')
        entries['new'] = {'start': 3, 'end': 4, 'statement': 'Future window selected after observations'}
        sha = self.m.catalogue_digest(entries, '1/20', 0)
        with self.assertRaises(Invalid):
            self.m.register_catalogue('adaptive', entries, delta='1/20', rho=0, expected_digest=sha)

    def test_current_window_union_bound_and_old_certificate_rejected(self):
        self.m.fund('cash', 100)
        cert = self.current(horizon=3)
        self.assertEqual((cert['start'], cert['end'], cert['q']), (1, 3, '3/10'))
        self.assertTrue(cert['conditional_at_issuance'])
        self.m.observe(1, 0)
        action = self.m.admit('stale_cert', occurrence='stale:1', mode='model', amount=1, risk_increase=1, certificate='c1')
        self.assertFalse(action['admitted'])
        self.assertEqual(action['result'], 'certificate is stale after observation')

    def test_action_budget_survives_unfilled_outcome_and_no_identity_relabel(self):
        self.m.fund('cash', 100)
        self.current()
        kwargs = dict(occurrence='physical:1', mode='model', amount=10, risk_increase=1, certificate='c1')
        first = self.m.admit('one', **kwargs)
        self.assertEqual(self.m.admit('one', **kwargs), first)
        with self.assertRaises(Invalid):
            self.m.admit('alias', **kwargs)
        self.m.resolve('one', filled=False)
        state = self.m.snapshot()['state']
        self.assertEqual((state['cash'], state['reserved'], state['budgets']['action']['spent']), ('100', '0', '1/5'))
        second = self.m.admit('two', occurrence='physical:2', mode='model', amount=10, risk_increase=1, certificate='c1')
        self.assertTrue(second['admitted'])
        third = self.m.admit('three', occurrence='physical:3', mode='model', amount=10, risk_increase=1, certificate='c1')
        self.assertFalse(third['admitted'])
        self.assertEqual(third['result'], 'action risk budget exhausted')
        self.assertEqual(self.m.snapshot()['state']['budgets']['action']['spent'], '2/5')

    def test_funding_gate_is_live_and_baseline_cannot_add_exposure(self):
        self.m.fund('cash', 2)
        self.current()
        action = self.m.admit('large', occurrence='large:1', mode='model', amount=3, risk_increase=1, certificate='c1')
        self.assertFalse(action['admitted'])
        bad = self.m.admit('fakebase', occurrence='base:1', mode='funded_baseline', amount=1, risk_increase=1)
        self.assertFalse(bad['admitted'])
        base = self.m.admit('base', occurrence='base:2', mode='funded_baseline', amount=2, risk_increase=0)
        self.assertTrue(base['admitted'])
        with self.assertRaises(Invalid):
            self.m.fund('withdraw', -1)
        self.m.resolve('base', filled=True)
        self.assertEqual(self.m.snapshot()['state']['cash'], '0')

    def test_denied_occurrence_retries_with_current_funding_and_certificate(self):
        self.current()
        original = dict(occurrence='retry:1', mode='model', amount=10, risk_increase=1, certificate='c1')
        denial = self.m.admit('denied', **original)
        self.assertFalse(denial['admitted'])
        self.assertEqual(denial['result'], 'insufficient current funded cash')
        self.m.observe(1, 0)
        self.m.fund('new_funding', 100)
        self.m.forecast('e1', cutoff=2, p='1/10', bet=1)
        self.m.conditional_certificate('c2', 'e1', horizon=2)
        retry = dict(original, certificate='c2')
        admitted = self.m.admit('fresh_attempt', **retry)
        self.assertTrue(admitted['admitted'])
        self.assertEqual(admitted['certificate_record']['cutoff'], 1)
        self.assertEqual(admitted['funding']['cash'], '100')
        self.assertEqual(self.m.snapshot()['state']['budgets']['action']['spent'], '1/5')
        before_replay = self.m.snapshot()
        self.assertEqual(self.m.admit('denied', **original), denial)
        self.assertEqual(self.m.snapshot(), before_replay)
        self.assertEqual(self.m.snapshot()['state']['decisions']['denied'], denial)
        self.assertEqual(self.m.snapshot()['state']['occurrences']['retry:1'], 'fresh_attempt')
        with self.assertRaises(Invalid):
            self.m.admit('admitted_alias', **retry)

    def test_stale_handle_restart_and_immutable_historical_decision(self):
        stale = Monitor(self.path)
        self.m.fund('cash', 100)
        with self.assertRaises(Stale):
            stale.fund('other', 1)
        self.current()
        kwargs = dict(occurrence='immutable:1', mode='model', amount=10, risk_increase=1, certificate='c1')
        decision = self.m.admit('saved', **kwargs)
        serialized = json.dumps(decision, sort_keys=True)
        self.m.observe(1, 1)
        restarted = Monitor(self.path)
        self.assertEqual(json.dumps(restarted.admit('saved', **kwargs), sort_keys=True), serialized)
        self.assertEqual(restarted.snapshot()['state']['budgets']['action']['spent'], '1/5')
        # A separate interpreter reads the same committed ledger.
        code = 'from monitor import Monitor;import json,sys;print(json.dumps(Monitor(sys.argv[1]).snapshot(),sort_keys=True))'
        run = subprocess.run([sys.executable, '-c', code, str(self.path)], cwd=Path(__file__).parent, capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(run.stdout), restarted.snapshot())

    def test_zero_action_budget_baseline_has_no_zero_probability_claim(self):
        path = Path(self.tmp.name) / 'zero-action-risk.sqlite'
        baseline = Monitor.create(path, alarm_budget=0, certificate_budget=0, action_budget=0)
        baseline.fund('cash', 3)
        decision = baseline.admit('base', occurrence='base:1', mode='funded_baseline', amount=2, risk_increase=0)
        self.assertTrue(decision['admitted'])
        self.assertEqual(decision['risk_charge'], '0')
        self.assertIsNone(decision['adverse_probability_bound'])
        self.assertEqual(decision['existing_risk'], 'unquantified')
        self.assertEqual(decision['scope'], 'Outside model-action adverse-event probability family; funded/nonexpansion only')
        self.assertEqual(baseline.snapshot()['state']['budgets']['action']['spent'], '0')

    def test_committed_history_chain_and_sql_immutability(self):
        self.catalogue()
        self.m.fund('cash', 20)
        self.current()
        self.m.admit('a', occurrence='a:1', mode='model', amount=1, risk_increase=1, certificate='c1')
        previous = '0'
        for revision, row in enumerate(self.m.history()):
            self.assertEqual(row['revision'], revision)
            self.assertEqual(row['previous'], previous)
            self.assertEqual(row['head'], digest([previous, row['event'], row['state']]))
            previous = row['head']
        self.assertEqual(previous, self.m.snapshot()['head'])
        with sqlite3.connect(self.path) as db:
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute('DELETE FROM history WHERE revision=0')

    def test_process_death_before_commit_rolls_back_and_after_commit_replays(self):
        self.m.fund('cash', 100)
        self.current()
        before = self.m.snapshot()
        count = len(self.m.history())
        code = '''
import os,sqlite3,sys
from monitor import Monitor
original=sqlite3.connect
class CrashConnection(sqlite3.Connection):
    def execute(self, sql, parameters=()):
        result=super().execute(sql,parameters)
        if sql.startswith('INSERT INTO history'):
            os._exit(77)
        return result
sqlite3.connect=lambda *args,**kw: original(*args,factory=CrashConnection,**kw)
m=Monitor(sys.argv[1])
m.admit('crash',occurrence='crash:1',mode='model',amount=10,risk_increase=1,certificate='c1')
'''
        run = subprocess.run([sys.executable, '-c', code, str(self.path)], cwd=Path(__file__).parent, capture_output=True, text=True)
        self.assertEqual(run.returncode, 77, run.stderr)
        self.assertEqual(self.m.snapshot(), before)
        self.assertEqual(len(self.m.history()), count)
        committed = '''
import os,sys
from monitor import Monitor
m=Monitor(sys.argv[1])
m.admit('crash',occurrence='crash:1',mode='model',amount=10,risk_increase=1,certificate='c1')
os._exit(77)
'''
        run = subprocess.run([sys.executable, '-c', committed, str(self.path)], cwd=Path(__file__).parent, capture_output=True, text=True)
        self.assertEqual(run.returncode, 77, run.stderr)
        # Replaying an exact committed command is safe even through this stale handle.
        decision = self.m.admit('crash', occurrence='crash:1', mode='model', amount=10, risk_increase=1, certificate='c1')
        self.assertTrue(decision['admitted'])
        self.assertEqual(self.m.snapshot()['state']['budgets']['action']['spent'], '1/5')
        self.assertEqual(len(self.m.history()), count + 1)

    def test_p13_exact_metadata_ingestion_without_numeric_recomputation(self):
        frontier = Path(__file__).resolve().parents[2]
        path = frontier / 'catalogue' / 'CERTIFIED-CATALOGUE.json'
        expected = 'c5e73a7c15c8490e9de681045ff78b223f91056252e84988ce844fb7c78a30cb'
        raw = path.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), expected)
        metadata = p13_metadata(raw, expected)
        self.assertEqual(metadata['external_catalogue_id'], '29d76b27c3e4b5b4f31961958999c9d7308654e9babdb8b946f77dcab8a2bfbf')
        self.assertEqual(metadata['delta'] + metadata['rho'], F(1, 20))
        self.assertFalse(metadata['conditional_at_issuance'])
        entries = metadata['entries']
        self.assertEqual(sorted(e['end'] - e['start'] + 1 for e in entries.values()), [512, 2048, 8192, 32768])
        sha = self.m.catalogue_digest(entries, metadata['delta'], metadata['rho'])
        self.m.register_catalogue('p13', entries, delta=metadata['delta'], rho=metadata['rho'], expected_digest=sha)
        with self.assertRaises(Invalid):
            self.m.inspect_window('p13', '2')
        with self.assertRaises(Invalid):
            p13_metadata(raw + b' ', expected)


if __name__ == '__main__':
    unittest.main(verbosity=2)
