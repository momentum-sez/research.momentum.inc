"""Independent exact probability checks. No runtime implementation is imported."""

import math
import unittest
from fractions import Fraction as F


def crossing_mass(depth=10):
    """Enumerate a history-adaptive null and charged, adaptively closed epochs."""
    allowances = (F(1, 8), F(1, 16), F(1, 32))
    leaves = 0

    def walk(history, epoch, age, capital, mass, seen):
        nonlocal leaves
        if len(history) == depth:
            leaves += 1
            return mass if seen else F(0)
        # The law and bet depend on observed history, never the next outcome.
        p = F(1, 4) if sum(history) % 2 == 0 else F(1, 2)
        bet = 1 / p if not history or history[-1] == 0 else 1 / (2 * p)
        total = F(0)
        for y, probability in ((0, 1 - p), (1, p)):
            active = epoch < len(allowances)
            next_capital = capital * (1 + bet * (y - p)) if active else capital
            alarm = active and next_capital >= 1 / allowances[epoch]
            next_epoch, next_age = epoch, age + 1
            # Closing on the just-observed zero is an optional stopping rule.
            # The replacement is charged before, and scores only, later data.
            if active and (alarm or y == 0 or next_age == 3):
                next_epoch, next_age, next_capital = epoch + 1, 0, F(1)
            total += walk(history + (y,), next_epoch, next_age, next_capital,
                          mass * probability, seen or alarm)
        return total

    return walk((), 0, 0, F(1), F(1), False), sum(allowances), leaves


def action_mass(depth=8):
    """Adaptive admissions under current conditional laws and a pathwise budget."""
    limit = F(2, 5)
    leaves = 0

    def walk(history, spent, mass, seen):
        nonlocal leaves
        if len(history) == depth:
            leaves += 1
            return mass if seen else F(0)
        p = F(1, 20) if not history or history[-1] == 0 else F(1, 5)
        admitted = spent + p <= limit and (not history or sum(history) % 3 != 2)
        charged = spent + p if admitted else spent
        if charged > limit:
            raise RuntimeError('oracle violates its declared pathwise allocation')
        return sum((walk(history + (y,), charged, mass * probability,
                         seen or (admitted and y == 1))
                    for y, probability in ((0, 1 - p), (1, p))), F(0))

    return walk((), F(0), F(1), False), limit, leaves


class ExactProbabilityOracle(unittest.TestCase):
    def test_nonnegative_conditional_multipliers(self):
        cases = 0
        for p in (F(1, 10), F(1, 2), F(9, 10)):
            for true_p in (F(0), p / 2, p):
                for bet in (F(0), 1 / (2 * p), 1 / p):
                    low, high = 1 - bet * p, 1 + bet * (1 - p)
                    self.assertGreaterEqual(low, 0)
                    self.assertGreaterEqual(high, 0)
                    self.assertLessEqual((1 - true_p) * low + true_p * high, 1)
                    cases += 1
        self.assertEqual(cases, 27)

    def test_adaptive_null_resets_and_optional_inspection(self):
        mass, budget, leaves = crossing_mass()
        self.assertEqual(leaves, 1024)
        self.assertGreater(mass, 0)
        self.assertLessEqual(mass, budget)

    def test_fresh_nominal_reset_is_unsound(self):
        # Each block rejects on two fair-coin successes: individual size 1/4.
        naive = 1 - F(3, 4) ** 4
        self.assertEqual(naive, F(175, 256))
        self.assertGreater(naive, F(1, 4))
        # Four allocations of 1/16 each instead require four successes.
        charged = 1 - F(15, 16) ** 4
        self.assertLessEqual(charged, F(1, 4))

    def test_selected_minimum_requires_simultaneous_coverage(self):
        a = F(1, 20)
        self.assertEqual(1 - (1 - a) ** 2, F(39, 400))
        self.assertGreater(F(39, 400), a)
        self.assertLessEqual(1 - (1 - a / 2) ** 2, a)

    def test_power_and_ordinary_operation(self):
        ordinary = F(10, 11) ** 20
        self.assertLess(ordinary, 1)
        self.assertLess(ordinary * 100, 40)
        self.assertGreater(ordinary * 1000, 40)
        capital = lambda k: F(10) ** k * F(10, 11) ** (100 - k)
        self.assertLess(capital(5), 40)
        self.assertGreaterEqual(capital(6), 40)
        tail = sum((F(math.comb(100, k)) * F(1, 10) ** k * F(9, 10) ** (100 - k)
                    for k in range(6, 101)), F(0))
        self.assertGreater(tail, F(942423, 1000000))
        self.assertLess(tail, F(942424, 1000000))
        self.assertEqual(100 * F(1, 10000), F(1, 100))

    def test_adaptive_admission_probability(self):
        mass, budget, leaves = action_mass()
        self.assertEqual(leaves, 256)
        self.assertGreater(mass, F(1, 10))
        self.assertLessEqual(mass, budget)

    def test_simultaneous_failure_adds_without_future_conditioning(self):
        # A signal is known at decision. Bad signal has mass delta and p=1.
        # Else p=q. This explicitly tests C={p>q}, not conditioning on B^c.
        delta, q = F(1, 20), F(1, 10)
        actual = delta + (1 - delta) * q
        self.assertLessEqual(actual, delta + q)
        self.assertGreater(actual, q)

    def test_delayed_forecast_cannot_ignore_revealing_information(self):
        # A once-correct issuance forecast p=.01 has become certain after signal.
        p, bet = F(1, 100), F(1)
        conditional_factor_after_signal = 1 + bet * (1 - p)
        self.assertGreater(conditional_factor_after_signal, 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
