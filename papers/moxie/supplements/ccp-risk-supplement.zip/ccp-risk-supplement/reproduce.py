"""Reproduce preserved computations in a new local work directory."""
from pathlib import Path
import argparse, hashlib, json, os, platform, shutil, subprocess, sys, time

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', required=True, help='New absolute directory under the extracted supplement')
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    work = Path(args.work).resolve()
    if not work.is_relative_to(ROOT) or work == ROOT or work.exists():
        raise SystemExit('--work must be a new absolute directory inside the extracted supplement')
    if not Path(args.work).is_absolute():
        raise SystemExit('--work must be absolute')
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for entry in manifest['files']:
        path = ROOT / entry['path']
        if not path.resolve().is_relative_to(ROOT) or sha(path) != entry['sha256']:
            raise SystemExit('Manifest mismatch: ' + entry['path'])
    if args.verify_only:
        print(json.dumps({'manifest_files_verified':len(manifest['files'])}))
        return
    work.mkdir()
    reference = work / 'reference'
    shutil.copytree(ROOT / 'reference', reference)
    durable = reference / 'durable'
    # Dependency paths in the public source are relative to this reference tree.
    # No historical absolute path or working-copy source rewrite is used.
    logdir = work / 'logs'; logdir.mkdir()
    tempdir = work / 'temporary'; tempdir.mkdir()
    env = dict(os.environ)
    env.update({'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(tempdir),'TMP':str(tempdir),'TEMP':str(tempdir)})
    env.pop('PYTHONPATH',None)
    front = reference
    plans = [
        ('synthetic-study',reference/'synthetic',['simulate_p12.py']),
        ('synthetic-checks',reference/'synthetic',['-m','unittest','-v','test_risk_accounting','test_p12_upgrade']),
        ('completion',front/'completion',['-c',"import sys,unittest;sys.path[:0]=['runtime','review'];suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in ['test_completion','test_risk_budgets','test_actual_runtime','test_independent_oracle']);r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not r.wasSuccessful())"]),
        ('monitoring',front/'monitoring/runtime',['-m','unittest','-v','test_monitor']),
        ('probability',front/'monitoring',['test_probability_oracle.py']),
        ('durable',durable,['-m','unittest','-v','test_integration'])]
    report = {'scope':'Fresh-extraction portability checks; historical evidence remains unchanged',
              'environment':{'python':sys.version,'executable':sys.executable,'platform':platform.platform()},
              'manifest_files_verified':len(manifest['files']),'runs':[]}
    for label,cwd,command in plans:
        cmd=[sys.executable,'-B']+command
        started=time.monotonic()
        result=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True)
        log=logdir/(label+'.log');log.write_text(result.stdout+result.stderr)
        report['runs'].append({'name':label,'command':cmd,'cwd':str(cwd),'exit_code':result.returncode,
            'elapsed_seconds':time.monotonic()-started,'log':str(log.relative_to(work)),'log_sha256':sha(log)})
        (work/'VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
        print(label, result.returncode, flush=True)
        if result.returncode:
            raise SystemExit(result.stdout[-1500:]+result.stderr[-3000:])
    # Compare deterministic products with their archived bytes; record float drift.
    products=[]
    for baseline in sorted((ROOT/'reference/synthetic').glob('synthetic-*')):
        current=reference/'synthetic'/baseline.name
        products.append({'path':baseline.name,'historical_sha256':sha(baseline),'fresh_sha256':sha(current),'byte_identical':sha(baseline)==sha(current)})
    report['synthetic_products']=products
    report['python_sources_byte_identical']=all(sha(f)==sha(reference/f.relative_to(ROOT/'reference')) for f in (ROOT/'reference').rglob('*.py'))
    report['completed']=all(r['exit_code']==0 for r in report['runs']) and report['python_sources_byte_identical']
    (work/'VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
