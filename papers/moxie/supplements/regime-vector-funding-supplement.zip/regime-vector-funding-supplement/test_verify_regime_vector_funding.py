"""Adverse tests for the bounded research checker and independent path oracles."""

from fractions import Fraction
from itertools import product
from pathlib import Path
import random
import subprocess
import sys
import unittest
from unittest.mock import patch

import verify_regime_vector_funding as checker
from verify_regime_vector_funding import Action, Edge, FundingSummary, Outcome, State


HALF = Fraction(1, 2)
ZERO2 = (0, 0)
A = ((0, 2), (0, 0))
B = ((0, 0), (2, 0))


def enumerate_policies(states, name):
    """Enumerate complete policy trees without funding or dominance calculations."""
    state = states[name]
    if state.terminal is not None:
        return [(name, None, ())]
    policies = []
    for index, action in enumerate(state.actions):
        choices = [enumerate_policies(states, outcome.state) for outcome in action.outcomes]
        policies.extend((name, index, children) for children in product(*choices))
    return policies


def policy_paths(states, policy, dimension):
    """Expand a fixed policy into ordered debit, floor, receipt, and terminal paths."""
    name, index, children = policy
    state = states[name]
    zero = (Fraction(0),) * dimension
    if index is None:
        debit = tuple(-Fraction(x) for x in state.terminal)
        return [((debit, zero),)]
    action = state.actions[index]
    debit = tuple(-Fraction(x) for x in action.debit)
    floor = tuple(Fraction(x) for x in action.floor)
    paths = []
    for outcome, child in zip(action.outcomes, children):
        receipt = tuple(Fraction(x) for x in outcome.increment)
        prefix = ((debit, floor), (receipt, zero))
        paths.extend(prefix + path for path in policy_paths(states, child, dimension))
    return paths


def direct_path_feasible(balance, path):
    """Test every checkpoint directly, without a funding summary or frontier."""
    cash = list(balance)
    for increment, floor in path:
        for i in range(len(cash)):
            cash[i] += increment[i]
            if cash[i] < floor[i]:
                return False
    return True


def witness_policy(states, witness):
    """Check the reported strategy shape and translate it for the path oracle."""
    state = states[witness.state]
    if state.terminal is not None:
        if witness.action is not None or witness.children:
            raise ValueError("terminal witness has a continuation")
        return witness.state, None, ()
    matches = [(i, action) for i, action in enumerate(state.actions)
               if action.name == witness.action]
    if len(matches) != 1:
        raise ValueError("witness does not name one permitted action")
    index, action = matches[0]
    if len(witness.children) != len(action.outcomes):
        raise ValueError("witness omits a possible outcome")
    if any(child.state != outcome.state for child, outcome in
           zip(witness.children, action.outcomes)):
        raise ValueError("witness follows the wrong observed successor")
    return witness.state, index, tuple(witness_policy(states, child) for child in witness.children)


def dyadic_graph(decisions):
    graph = {str(decisions): State(terminal=ZERO2)}
    for i in reversed(range(decisions)):
        amount = 2 ** i
        child = (Outcome(str(i + 1), ZERO2),)
        graph[str(i)] = State((Action("first", (amount, 0), ZERO2, child),
                               Action("second", (0, amount), ZERO2, child)))
    return graph


class ExactArithmeticTests(unittest.TestCase):
    def test_rational_strings_preserve_a_difference_below_float_precision(self):
        epsilon = Fraction(1, 10**80)
        edge = Edge("loop", "v", "v", ((HALF + epsilon,),))
        self.assertFalse(checker.verify_box_certificate([edge], {"v": ("1",)}, "1/2"))
        self.assertEqual(checker.matrix_product((("1/3", "1/7"),), ((3,), (7,))), ((2,),))
        self.assertEqual(checker.matrix_vector((("1/3", "1/7"),), (3, 7)), (2,))

    def test_floats_and_other_inexact_input_types_are_rejected(self):
        values = (0.5, float("inf"), float("nan"), True, None, complex(1, 0))
        for value in values:
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    checker.matrix_vector(((value,),), (1,))
                with self.assertRaises(ValueError):
                    checker.frontier_contains([(0,)], (value,))

    def test_invalid_rational_strings_are_rejected(self):
        for value in ("NaN", "Infinity", "1/0", "not rational"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                checker.matrix_vector(((value,),), (1,))

    def test_matrix_shapes_and_nonnegativity_are_checked(self):
        for matrix in ((), ((),), ((1,), (1, 2)), ((-1,),), ((1.0,),)):
            with self.subTest(matrix=matrix), self.assertRaises(ValueError):
                checker.matrix_product(matrix, ((1,),))
        with self.assertRaises(ValueError):
            checker.matrix_product(((1, 2),), ((1,),))
        with self.assertRaises(ValueError):
            checker.matrix_vector(((1, 2),), (1,))
        with self.assertRaises(ValueError):
            checker.matrix_vector(((1, 2),), "12")

    def test_input_containers_are_not_modified(self):
        matrix, weights = [["1/4"]], {"v": ["2/3"]}
        self.assertTrue(checker.verify_box_certificate([Edge("e", "v", "v", matrix)], weights, HALF))
        self.assertEqual(matrix, [["1/4"]])
        self.assertEqual(weights, {"v": ["2/3"]})


class BoxCertificateTests(unittest.TestCase):
    def test_denominator_weights_use_source_to_target_orientation(self):
        edges = [Edge("out", "u", "v", ((2,),)),
                 Edge("back", "v", "u", ((Fraction(1, 8),),))]
        self.assertTrue(checker.verify_box_certificate(edges, {"u": (1,), "v": (4,)}, HALF))
        self.assertFalse(checker.verify_box_certificate(edges, {"u": (4,), "v": (1,)}, HALF))
        for scale in (Fraction(1, 13), 7, 10**50):
            self.assertTrue(checker.verify_box_certificate(edges, {"u": (scale,), "v": (4 * scale,)}, HALF))

    def test_frozen_nilpotent_certificates_do_not_certify_switching(self):
        self.assertEqual(checker.matrix_product(A, A), ((0, 0), (0, 0)))
        self.assertEqual(checker.matrix_product(B, B), ((0, 0), (0, 0)))
        self.assertTrue(checker.verify_box_certificate([Edge("a", "v", "v", A)], {"v": (4, 1)}, HALF))
        self.assertTrue(checker.verify_box_certificate([Edge("b", "v", "v", B)], {"v": (1, 4)}, HALF))
        self.assertEqual(checker.matrix_product(B, A), ((0, 0), (0, 4)))
        self.assertEqual(checker.matrix_product(checker.matrix_product(B, A),
                                               checker.matrix_product(B, A)), ((0, 0), (0, 16)))
        edges = [Edge("a", "u", "v", A), Edge("b", "v", "u", B)]
        for values in product((Fraction(1, 4), 1, 4), repeat=4):
            self.assertFalse(checker.verify_box_certificate(edges, {"u": values[:2], "v": values[2:]}, HALF))

    def test_incident_edges_cannot_supply_inconsistent_shared_mode_weights(self):
        edge_a, edge_b = Edge("a", "u", "v", A), Edge("b", "v", "u", B)
        first = {"u": (1, 1), "v": (4, 1)}
        second = {"u": (1, 4), "v": (1, 1)}
        self.assertTrue(checker.verify_box_certificate([edge_a], first, HALF))
        self.assertTrue(checker.verify_box_certificate([edge_b], second, HALF))
        self.assertFalse(checker.verify_box_certificate([edge_a, edge_b], first, HALF))
        self.assertFalse(checker.verify_box_certificate([edge_a, edge_b], second, HALF))

    def test_parallel_labelled_edges_are_all_checked(self):
        edges = [Edge("safe", "v", "v", ((Fraction(1, 4),),)),
                 Edge("unsafe", "v", "v", ((2,),))]
        self.assertFalse(checker.verify_box_certificate(edges, {"v": (1,)}, HALF))

    def test_rate_is_exact_and_strictly_between_zero_and_one(self):
        for rate in (-1, 0, 1, 2, 0.5, "1/0"):
            with self.subTest(rate=rate), self.assertRaises(ValueError):
                checker.verify_box_certificate([], {"v": (1,)}, rate)
        self.assertTrue(checker.verify_box_certificate([], {"isolated": (1,)}, HALF))

    def test_modes_and_weights_have_one_positive_common_dimension(self):
        for weights in ({}, {"": (1,)}, {"v": ()}, {"v": (0,)}, {"v": (-1,)},
                        {"u": (1,), "v": (1, 2)}, {"v": (1.0,)}):
            with self.subTest(weights=weights), self.assertRaises(ValueError):
                checker.verify_box_certificate([], weights, HALF)

    def test_edge_identity_endpoints_and_square_shape_are_validated(self):
        cases = ([Edge("", "v", "v", ((0,),))],
                 [Edge("e", "v", "missing", ((0,),))],
                 [Edge("e", "v", "v", ((0,),)), Edge("e", "v", "v", ((0,),))],
                 [Edge("e", "v", "v", ((0,), (0,)))],
                 [Edge("e", "v", "v", ((0, 0),))],
                 [Edge("e", "v", "v", ((-1,),))])
        for edges in cases:
            with self.subTest(edges=edges), self.assertRaises(ValueError):
                checker.verify_box_certificate(edges, {"v": (1,)}, HALF)

    def test_invalid_tail_is_not_hidden_by_an_earlier_failed_inequality(self):
        edges = [Edge("failed", "v", "v", ((2,),)), Edge("invalid", "v", "v", ((0.0,),))]
        with self.assertRaises(ValueError):
            checker.verify_box_certificate(edges, {"v": (1,)}, HALF)


class PolyhedralCertificateTests(unittest.TestCase):
    def setUp(self):
        self.rate = Fraction(3, 4)
        self.edges = [Edge("r1", "v", "v", ((self.rate, self.rate), (0, 0))),
                      Edge("r2", "v", "v", ((0, 0), (self.rate, self.rate)))]
        self.rows = {"v": ((1, 0), (0, 1), (1, 1))}
        self.combinations = {"r1": ((0, 0, 1),) * 3, "r2": ((0, 0, 1),) * 3}

    def test_l1_certificate_covers_a_family_without_a_shared_box(self):
        self.assertTrue(checker.verify_polyhedral_certificate(
            self.edges, self.rows, self.rate, self.combinations))
        for weights in product((Fraction(1, 4), 1, 4), repeat=2):
            self.assertFalse(checker.verify_box_certificate(self.edges, {"v": weights}, Fraction(99, 100)))
        self.assertFalse(checker.verify_polyhedral_certificate(
            self.edges, self.rows, HALF, self.combinations))

    def test_target_rows_pull_back_to_convex_combinations_of_source_rows(self):
        edges = [Edge("out", "u", "v", ((2,),)),
                 Edge("back", "v", "u", ((Fraction(1, 8),),))]
        rows = {"u": ((1,), (4,)), "v": ((1,),)}
        combinations = {"out": ((0, 1),), "back": ((1,), (1,))}
        self.assertTrue(checker.verify_polyhedral_certificate(edges, rows, HALF, combinations))
        self.assertFalse(checker.verify_polyhedral_certificate(
            edges, rows, HALF, {"out": ((1, 0),), "back": ((1,), (1,))}))

    def test_a_true_convex_mixture_can_be_necessary(self):
        edge = Edge("e", "v", "v", ((Fraction(1, 4), Fraction(1, 4)), (0, 0)))
        rows = {"v": ((1, 0), (0, 1))}
        self.assertTrue(checker.verify_polyhedral_certificate(
            [edge], rows, HALF, {"e": ((HALF, HALF), (1, 0))}))
        for unit in ((1, 0), (0, 1)):
            self.assertFalse(checker.verify_polyhedral_certificate(
                [edge], rows, HALF, {"e": (unit, (1, 0))}))

    def test_every_unit_row_and_every_mode_dimension_is_required(self):
        for rows in ({}, {"v": ((1, 1),)}, {"v": ((1, 0),)},
                     {"v": ((1, 0), (0, 1)), "other": ((1,),)},
                     {"v": ((1, 0), (0, 1), (-1, 1))}):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                checker.verify_polyhedral_certificate([], rows, HALF, {})

    def test_convex_coefficients_are_exact_nonnegative_and_sum_to_one(self):
        for bad in ((0, 0, 2), (0, -1, 2), (0, 0, 0.5), (0, 1), (0, 0, "1/0")):
            combinations = dict(self.combinations, r1=(bad,) * 3)
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                checker.verify_polyhedral_certificate(self.edges, self.rows, self.rate, combinations)

    def test_all_edge_rows_need_exactly_one_combination(self):
        for combinations in ({}, {"r1": self.combinations["r1"]},
                             dict(self.combinations, extra=((1,),)),
                             dict(self.combinations, r1=((0, 0, 1),))):
            with self.subTest(combinations=combinations), self.assertRaises(ValueError):
                checker.verify_polyhedral_certificate(self.edges, self.rows, self.rate, combinations)

    def test_invalid_later_combination_is_checked_before_returning_false(self):
        combinations = dict(self.combinations, r2=((0, 0, 1.0),) * 3)
        with self.assertRaises(ValueError):
            checker.verify_polyhedral_certificate(self.edges, self.rows, HALF, combinations)


class FundingSummaryTests(unittest.TestCase):
    def test_receipt_and_debit_order_changes_required_funding_by_100(self):
        payment = FundingSummary((100,), (-100,))
        receipt = FundingSummary((0,), (100,))
        self.assertEqual(checker.compose_summaries(payment, receipt), FundingSummary((100,), (0,)))
        self.assertEqual(checker.compose_summaries(receipt, payment), FundingSummary((0,), (0,)))

    def test_retained_floor_survives_zero_physical_increments(self):
        self.assertEqual(checker.path_summary([(0,)], [(1,)], 1), FundingSummary((1,), (0,)))
        self.assertEqual(checker.action_summary((0,), (1,), (0,)), FundingSummary((1,), (0,)))
        self.assertEqual(checker.path_summary([(0,)], [(0,)], 1), FundingSummary((0,), (0,)))

    def test_terminal_obligation_is_a_payment_checkpoint(self):
        summary = checker.path_summary([(10,), (-13,)], [(0,), (0,)], 1)
        self.assertEqual(summary, FundingSummary((3,), (-3,)))

    def test_summary_domain_rejects_nonrealizable_and_inexact_pairs(self):
        for required, delta in (((0,), (-1,)), ((-1,), (1,)), ((0,), (0, 0)),
                                ((0.0,), (0,)), ((), ()), ((0,), (0.0,))):
            with self.subTest(required=required, delta=delta), self.assertRaises(ValueError):
                FundingSummary(required, delta)
        with self.assertRaises(ValueError):
            checker.compose_summaries(FundingSummary((0,), (0,)), FundingSummary(ZERO2, ZERO2))

    def test_associativity_and_identity_on_all_small_realizable_pairs(self):
        pairs = [FundingSummary((r,), (d,)) for r in range(3) for d in range(-r, 3)]
        identity = FundingSummary((0,), (0,))
        for item in pairs:
            self.assertEqual(checker.compose_summaries(identity, item), item)
            self.assertEqual(checker.compose_summaries(item, identity), item)
            self.assertEqual(checker.path_summary([(-item.required[0],),
                                                   (item.required[0] + item.delta[0],)],
                                                  [(0,), (0,)], 1), item)
        triples = 0
        for a, b, c in product(pairs, repeat=3):
            self.assertEqual(checker.compose_summaries(checker.compose_summaries(a, b), c),
                             checker.compose_summaries(a, checker.compose_summaries(b, c)))
            triples += 1
        self.assertEqual(triples, 1728)

    def test_concatenation_and_direct_checkpoint_feasibility_agree(self):
        checkpoints = [((x,), (f,)) for x in (-1, 0, 1) for f in (0, 1)]
        paths = [()] + [(item,) for item in checkpoints] + list(product(checkpoints, repeat=2))

        def summary(path):
            return checker.path_summary([x for x, _ in path], [f for _, f in path], 1)

        for path in paths:
            result = summary(path)
            for balance in (0, HALF, 1, Fraction(3, 2), 2, 3):
                self.assertEqual(balance >= result.required[0], direct_path_feasible((balance,), path))
        pairs = 0
        for left, right in product(paths, repeat=2):
            self.assertEqual(checker.compose_summaries(summary(left), summary(right)), summary(left + right))
            pairs += 1
        self.assertEqual(pairs, 1849)

    def test_vector_summary_and_local_action_composition_are_componentwise(self):
        result = checker.path_summary([(-2, 5), (4, -7)], [(3, 0), (0, 1)], 2)
        self.assertEqual(result, FundingSummary((5, 3), (2, -2)))
        local = checker.action_summary((2, 3), (1, 4), (-5, 10))
        continuation = FundingSummary((7, 2), (-7, -2))
        result = checker.compose_summaries(local, continuation)
        self.assertEqual(result.required, (2 + max(1, 7 + 5), 3 + max(4, 2 - 10)))

    def test_paths_validate_dimensions_floors_and_checkpoint_count(self):
        cases = (([(0,)], [], 1), ([(0,)], [(-1,)], 1), ([(0,)], [(0,)], 2),
                 ([], [], 0), ([], [], True), ([(0.0,)], [(0,)], 1),
                 ([(0,)], [(0.0,)], 1))
        for increments, floors, dimension in cases:
            with self.subTest(increments=increments, floors=floors, dimension=dimension):
                with self.assertRaises(ValueError):
                    checker.path_summary(increments, floors, dimension)
        self.assertEqual(checker.path_summary([], [], 2), FundingSummary(ZERO2, ZERO2))


class CompletionFrontierTests(unittest.TestCase):
    def test_missing_floor_and_terminal_obligation_are_preserved(self):
        graph = {"s": State((Action("retain", (0,), (1,), (Outcome("t", (0,)),)),)),
                 "t": State(terminal=(0,))}
        self.assertEqual(set(checker.completion_frontiers(graph, 1)["s"]), {(1,)})
        graph["t"] = State(terminal=(7,))
        self.assertEqual(set(checker.completion_frontiers(graph, 1)["s"]), {(7,)})

    def test_signed_receipts_do_not_fund_an_earlier_debit(self):
        after = {"s": State((Action("pay", (100,), (0,), (Outcome("t", (100,)),)),)),
                 "t": State(terminal=(0,))}
        before = {"s": State((Action("receive", (0,), (0,), (Outcome("pay", (100,)),)),)),
                  "pay": State((Action("pay", (100,), (0,), (Outcome("t", (0,)),)),)),
                  "t": State(terminal=(0,))}
        self.assertEqual(set(checker.completion_frontiers(after, 1)["s"]), {(100,)})
        self.assertEqual(set(checker.completion_frontiers(before, 1)["s"]), {(0,)})
        debit = {"s": State((Action("settle", (3,), (1,), (Outcome("t", (-5,)),)),)),
                 "t": State(terminal=(2,))}
        self.assertEqual(set(checker.completion_frontiers(debit, 1)["s"]), {(10,)})

    def test_actions_form_a_union_outcomes_form_a_coordinatewise_maximum(self):
        choices = {"s": State((Action("first", (1, 0), ZERO2, (Outcome("t", ZERO2),)),
                                Action("second", (0, 1), ZERO2, (Outcome("t", ZERO2),)))),
                   "t": State(terminal=ZERO2)}
        self.assertEqual(set(checker.completion_frontiers(choices, 2)["s"]), {(1, 0), (0, 1)})
        outcomes = {"s": State((Action("both", ZERO2, ZERO2,
                                        (Outcome("a", ZERO2), Outcome("b", ZERO2))),)),
                    "a": State(terminal=(1, 0)), "b": State(terminal=(0, 1))}
        self.assertEqual(set(checker.completion_frontiers(outcomes, 2)["s"]), {(1, 1)})

    def test_action_choice_cannot_use_an_unobserved_outcome(self):
        graph = {"s": State((Action("first", (0,), (0,),
                                      (Outcome("left", (0,)), Outcome("right", (-100,)))),
                               Action("second", (0,), (0,),
                                      (Outcome("left", (-100,)), Outcome("right", (0,)))))),
                 "left": State(terminal=(0,)), "right": State(terminal=(0,))}
        frontier = checker.completion_frontiers(graph, 1)["s"]
        self.assertEqual(set(frontier), {(100,)})
        self.assertFalse(checker.frontier_contains(frontier, (0,)))

    def test_observed_histories_can_select_different_continuations_at_a_shared_state(self):
        graph = {"s": State((Action("observe", ZERO2, ZERO2,
                                    (Outcome("left", (1, 0)), Outcome("right", (0, 1)))),)),
                 "left": State((Action("continue", ZERO2, ZERO2, (Outcome("shared", ZERO2),)),)),
                 "right": State((Action("continue", ZERO2, ZERO2, (Outcome("shared", ZERO2),)),)),
                 "shared": State((Action("first", (1, 0), ZERO2, (Outcome("t", ZERO2),)),
                                    Action("second", (0, 1), ZERO2, (Outcome("t", ZERO2),)))),
                 "t": State(terminal=ZERO2)}
        frontier = checker.completion_frontiers(graph, 2)["s"]
        self.assertEqual(set(frontier), {ZERO2})
        witness = frontier[ZERO2]
        self.assertEqual([child.children[0].action for child in witness.children], ["first", "second"])
        paths = policy_paths(graph, witness_policy(graph, witness), 2)
        self.assertTrue(all(direct_path_feasible(ZERO2, path) for path in paths))

    def test_empty_child_invalidates_an_action_and_empty_union_propagates(self):
        graph = {"blocked": State(), "t": State(terminal=(0,)),
                 "bad": State((Action("try", (0,), (0,),
                                      (Outcome("t", (0,)), Outcome("blocked", (10**50,)))),)),
                 "root": State((Action("bad", (0,), (0,), (Outcome("bad", (0,)),)),
                                  Action("good", (7,), (0,), (Outcome("t", (0,)),))))}
        frontiers = checker.completion_frontiers(graph, 1)
        self.assertEqual(frontiers["blocked"], {})
        self.assertEqual(frontiers["bad"], {})
        self.assertFalse(checker.frontier_contains(frontiers["bad"], (10**100,)))
        self.assertEqual(set(frontiers["root"]), {(7,)})

    def test_dominated_and_duplicate_candidates_preserve_a_valid_witness(self):
        actions = tuple(Action(str(d), (d,), (0,), (Outcome("t", (0,)),)) for d in (3, 1, 2))
        duplicate = Action("duplicate", (1,), (0,), (Outcome("t", (0,)),))
        graph = {"s": State(actions + (duplicate,)),
                 "t": State(terminal=(0,))}
        frontier = checker.completion_frontiers(graph, 1)["s"]
        self.assertEqual(set(frontier), {(1,)})
        self.assertTrue(all(direct_path_feasible((1,), path) for path in
                            policy_paths(graph, witness_policy(graph, frontier[(1,)]), 1)))

    def test_two_resource_dyadic_frontiers_have_exactly_2_to_n_elements(self):
        for decisions in range(1, 9):
            graph = dyadic_graph(decisions)
            frontier = checker.completion_frontiers(graph, 2)["0"]
            total = 2 ** decisions - 1
            self.assertEqual(set(frontier), {(x, total - x) for x in range(total + 1)})
            self.assertEqual(len(frontier), 2 ** decisions)
            for vector, witness in frontier.items():
                paths = policy_paths(graph, witness_policy(graph, witness), 2)
                self.assertEqual(len(paths), 1)
                self.assertTrue(direct_path_feasible(vector, paths[0]))

    def test_frontier_membership_matches_exhaustive_independent_policy_paths(self):
        rng = random.Random(8123)
        comparisons = 0
        empty_roots = nonempty_roots = 0
        for dimension, graph_count in ((1, 12), (2, 24)):
            for _ in range(graph_count):
                graph = {"3": State(terminal=tuple(Fraction(rng.randrange(3), 2)
                                                   for _ in range(dimension)))}
                for i in reversed(range(3)):
                    actions = []
                    for j in range(rng.randrange(3)):
                        later = list(range(i + 1, 4))
                        targets = rng.sample(later, rng.randrange(1, min(2, len(later)) + 1))
                        debit = tuple(Fraction(rng.randrange(3), 2) for _ in range(dimension))
                        floor = tuple(Fraction(rng.randrange(3), 2) for _ in range(dimension))
                        outcomes = tuple(Outcome(str(t), tuple(Fraction(rng.randrange(-3, 4), 2)
                                                               for _ in range(dimension))) for t in targets)
                        actions.append(Action(str(j), debit, floor, outcomes))
                    graph[str(i)] = State(tuple(actions))
                frontiers = checker.completion_frontiers(graph, dimension)
                root = frontiers["0"]
                empty_roots += not bool(root)
                nonempty_roots += bool(root)
                policies = enumerate_policies(graph, "0")
                paths = [policy_paths(graph, policy, dimension) for policy in policies]
                grid = range(13) if dimension == 1 else range(7)
                for values in product(grid, repeat=dimension):
                    balance = tuple(Fraction(x, 2) for x in values)
                    expected = any(all(direct_path_feasible(balance, path) for path in policy)
                                   for policy in paths)
                    self.assertEqual(checker.frontier_contains(root, balance), expected,
                                     (graph, balance, root))
                    comparisons += 1
                for frontier in frontiers.values():
                    for vector, witness in frontier.items():
                        paths = policy_paths(graph, witness_policy(graph, witness), dimension)
                        self.assertTrue(all(direct_path_feasible(vector, path) for path in paths))
        self.assertEqual(comparisons, 1332)
        self.assertGreater(empty_roots, 0)
        self.assertGreater(nonempty_roots, 0)

    def test_fractional_frontiers_use_exact_coordinatewise_order(self):
        epsilon = Fraction(1, 10**80)
        graph = {"s": State((Action("a", (HALF, HALF), ZERO2, (Outcome("t", ZERO2),)),
                               Action("b", (HALF + epsilon, HALF - epsilon), ZERO2,
                                      (Outcome("t", ZERO2),)))), "t": State(terminal=ZERO2)}
        frontier = checker.completion_frontiers(graph, 2)["s"]
        self.assertEqual(len(frontier), 2)
        self.assertFalse(checker.frontier_contains(frontier, (HALF, HALF - epsilon)))
        self.assertTrue(checker.frontier_contains(frontier, ("1/2", "1/2")))

    def test_completion_data_rejects_cycles_missing_states_and_empty_outcomes(self):
        cases = ({}, {"s": State((Action("a", (0,), (0,), (Outcome("s", (0,)),)),))},
                 {"s": State((Action("a", (0,), (0,), (Outcome("missing", (0,)),)),))},
                 {"s": State((Action("a", (0,), (0,), ()),))},
                 {"s": State((Action("a", (0,), (0,), (Outcome("t", (0,)),)),), terminal=(0,)),
                  "t": State(terminal=(0,))})
        for graph in cases:
            with self.subTest(graph=graph), self.assertRaises(ValueError):
                checker.completion_frontiers(graph, 1)

    def test_model_validation_includes_unreachable_data_and_all_named_fields(self):
        valid = Action("a", (0,), (0,), (Outcome("t", (0,)),))
        bad_actions = (Action("", (0,), (0,), valid.outcomes),
                       Action("a", (-1,), (0,), valid.outcomes),
                       Action("a", (0,), (-1,), valid.outcomes),
                       Action("a", (0, 0), (0,), valid.outcomes),
                       Action("a", (0.0,), (0,), valid.outcomes),
                       Action("a", (0,), (0.0,), valid.outcomes),
                       Action("a", (0,), (0,), (Outcome("t", (0.0,)),)),
                       Action("a", (0,), (0,), valid.outcomes * 2))
        for action in bad_actions:
            graph = {"t": State(terminal=(0,)), "unreachable": State((action,))}
            with self.subTest(action=action), self.assertRaises(ValueError):
                checker.completion_frontiers(graph, 1)
        with self.assertRaises(ValueError):
            checker.completion_frontiers({"s": State((valid, valid)), "t": State(terminal=(0,))}, 1)
        for terminal in ((-1,), (0.0,), (0, 0)):
            with self.subTest(terminal=terminal), self.assertRaises(ValueError):
                checker.completion_frontiers({"t": State(terminal=terminal)}, 1)
        for dimension in (0, -1, True, 1.0):
            with self.subTest(dimension=dimension), self.assertRaises(ValueError):
                checker.completion_frontiers({"t": State(terminal=(0,))}, dimension)

    def test_membership_validates_every_vector_even_after_an_early_match(self):
        for frontier, balance in (([(0,), (0.0,)], (1,)), ([(0,)], (-1,)),
                                   ([(0, 0)], (1,)), ([(-1,)], (1,))):
            with self.subTest(frontier=frontier, balance=balance), self.assertRaises(ValueError):
                checker.frontier_contains(frontier, balance)


class IncrementComparisonTests(unittest.TestCase):
    def test_bounded_shocks_and_increments_do_not_bound_lifetime_total(self):
        edge = Edge("zero", "v", "v", ((0,),))
        self.assertTrue(checker.verify_box_certificate([edge], {"v": (1,)}, HALF))
        for count in (1, 10, 1000):
            increments = [Fraction(1)] * count
            self.assertTrue(all(r <= 0 * previous + 1 for previous, r in
                                zip(increments, increments[1:])))
            self.assertEqual(max(increments), 1)
            self.assertEqual(sum(increments), count)

    def test_monotone_dispatch_target_changes_can_grow_despite_small_cycle_gain(self):
        edges = [Edge("out", "u", "v", ((2,),)),
                 Edge("back", "v", "u", ((Fraction(1, 8),),))]
        self.assertTrue(checker.verify_box_certificate(edges, {"u": (1,), "v": (4,)}, HALF))

        def dispatch(cap, steps):
            def phi(mode, value):
                gain = Fraction(1, 8) if mode == "u" else Fraction(2)
                return min(Fraction(cap), 1 + gain * value)

            previous, current = Fraction(0), Fraction(1)
            mode = "u"
            cumulative, shocks = [current], []
            for _ in range(steps):
                following = "v" if mode == "u" else "u"
                gain = Fraction(2) if following == "v" else Fraction(1, 8)
                shock = max(Fraction(0), phi(following, previous) - phi(mode, previous))
                updated = max(current, phi(following, current))
                self.assertLessEqual(updated - current, gain * (current - previous) + shock)
                self.assertGreaterEqual(updated, current)
                self.assertLessEqual(updated, cap)
                cumulative.append(updated)
                shocks.append(shock)
                previous, current, mode = current, updated, following
            return cumulative, shocks

        cumulative, shocks = dispatch(1000, 24)
        self.assertEqual(cumulative[:7], [1, 3, 3, 7, 7, 15, 15])
        self.assertEqual(shocks[:5], [0, 0, Fraction(45, 8), 0, Fraction(105, 8)])
        self.assertEqual(cumulative[-1], 1000)
        for cap in (100, 1000, 10000):
            path, _ = dispatch(cap, 32)
            increments = [path[0]] + [right - left for left, right in zip(path, path[1:])]
            self.assertEqual(sum(increments), cap)


class SelfTestTests(unittest.TestCase):
    def test_self_test_checks_success_and_failure(self):
        self.assertEqual(checker.self_test(), 12)
        for function in ("verify_box_certificate", "verify_polyhedral_certificate"):
            for value in (True, False):
                with self.subTest(function=function, value=value):
                    with patch.object(checker, function, return_value=value):
                        with self.assertRaises(RuntimeError):
                            checker.self_test()

    def test_cli_runs_the_same_checks_with_assertions_disabled(self):
        path = Path(checker.__file__).resolve()
        for optimized in (False, True):
            with self.subTest(optimized=optimized):
                command = [sys.executable] + (["-O"] if optimized else []) + [str(path)]
                result = subprocess.run(command, capture_output=True, text=True, timeout=20)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stdout.strip(), "12 exact mathematical checks passed")


if __name__ == "__main__":
    unittest.main(verbosity=2)
