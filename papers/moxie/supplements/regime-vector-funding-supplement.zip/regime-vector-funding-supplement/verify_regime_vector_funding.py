#!/usr/bin/env python3
"""Exact finite witnesses for regime contraction and vector completion funding.

This research checker verifies supplied rational certificates and finite models.
It is not a production admission system or an optimizer. It does not establish
physical response bounds, observation adequacy, or authority for an action.

A regime edge maps a source vector to a target vector. A box certificate assigns
one positive weight vector to each mode. A polyhedral certificate supplies
nonnegative norm rows and an explicit convex combination for each edge and row.
Failure of a supplied certificate does not prove instability.

A completion model has fixed data on a finite acyclic graph. An action precedes
its outcome observation. Balance eligibility consists only of the stated debit,
floor, successor, and terminal requirements. Frontiers list minimal sufficient
vectors and retain a strategy for each vector. Enumeration can be exponential.

Amounts accept integers, rational strings, and Fraction values. Floats are invalid.
Run this file directly for a finite self-test, including adverse witnesses.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from graphlib import CycleError, TopologicalSorter
from itertools import product
from typing import Iterable, Mapping, Sequence, Union


Number = Union[int, str, Fraction]
Row = Sequence[Number]
Vector = tuple[Fraction, ...]
Matrix = tuple[Vector, ...]


def _q(value: Number) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if type(value) is not int and not isinstance(value, str):
        raise ValueError("amounts must be integers, rational strings, or Fractions")
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError) as error:
        raise ValueError("amount must be a finite rational") from error


def _dimension(value: int) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError("dimension must be a positive integer")
    return value


def _vector(values: Row, dimension: int | None = None, *,
            nonnegative: bool = False) -> Vector:
    if isinstance(values, (str, bytes)):
        raise ValueError("a vector must contain separate rational entries")
    result = tuple(_q(value) for value in values)
    if not result or (dimension is not None and len(result) != dimension):
        raise ValueError("vectors must have the stated positive dimension")
    if nonnegative and any(value < 0 for value in result):
        raise ValueError("vector entries must be nonnegative")
    return result


def _matrix(rows: Sequence[Row], width: int | None = None) -> Matrix:
    result = tuple(_vector(row, width, nonnegative=True) for row in rows)
    if not result or any(len(row) != len(result[0]) for row in result):
        raise ValueError("matrices must be nonempty and rectangular")
    return result


def _name(value: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError("names must be nonempty strings")
    return value


def _leq(left: Vector, right: Vector) -> bool:
    return all(x <= y for x, y in zip(left, right))


def matrix_product(left: Sequence[Row], right: Sequence[Row]) -> Matrix:
    """Multiply compatible nonnegative matrices with exact rational arithmetic."""
    a, b = _matrix(left), _matrix(right)
    if len(a[0]) != len(b):
        raise ValueError("matrix product dimensions do not match")
    return tuple(tuple(sum((x * y for x, y in zip(row, column)), Fraction(0))
                       for column in zip(*b)) for row in a)


def matrix_vector(matrix: Sequence[Row], vector: Row) -> Vector:
    """Apply a nonnegative matrix to an exact vector."""
    values = _vector(vector)
    rows = _matrix(matrix, len(values))
    return tuple(sum((x * y for x, y in zip(row, values)), Fraction(0))
                 for row in rows)


@dataclass(frozen=True)
class Edge:
    name: str
    source: str
    target: str
    matrix: Sequence[Row]


def _regime_edges(edges: Sequence[Edge], modes: Iterable[str],
                  dimension: int) -> tuple[Edge, ...]:
    known = set(modes)
    if not known:
        raise ValueError("a regime graph must contain a mode")
    result = []
    names = set()
    for edge in edges:
        name = _name(edge.name)
        source, target = _name(edge.source), _name(edge.target)
        if name in names:
            raise ValueError("edge names must be unique")
        if source not in known or target not in known:
            raise ValueError("every edge endpoint needs a mode certificate")
        matrix = _matrix(edge.matrix, dimension)
        if len(matrix) != dimension:
            raise ValueError("regime matrices must have the common square dimension")
        names.add(name)
        result.append(Edge(name, source, target, matrix))
    return tuple(result)


def _rate(q: Number) -> Fraction:
    value = _q(q)
    if not 0 < value < 1:
        raise ValueError("the contraction rate must satisfy 0 < q < 1")
    return value


def verify_box_certificate(edges: Sequence[Edge], weights: Mapping[str, Row],
                           q: Number) -> bool:
    """Check T_e w_source <= q w_target with one positive vector per mode.

    Invalid data raises ValueError. A failed exact inequality returns False.
    The common dimension fixes the coordinate system for every edge.
    """
    rate = _rate(q)
    vectors = {_name(mode): _vector(row) for mode, row in weights.items()}
    if not vectors:
        raise ValueError("a box certificate must contain a mode")
    dimension = len(next(iter(vectors.values())))
    if any(len(row) != dimension or any(x <= 0 for x in row)
           for row in vectors.values()):
        raise ValueError("mode weights must have common dimension and positive entries")
    checked = _regime_edges(edges, vectors, dimension)
    return all(_leq(matrix_vector(edge.matrix, vectors[edge.source]),
                    tuple(rate * x for x in vectors[edge.target]))
               for edge in checked)


def verify_polyhedral_certificate(
    edges: Sequence[Edge], rows: Mapping[str, Sequence[Row]], q: Number,
    combinations: Mapping[str, Sequence[Row]],
) -> bool:
    """Check supplied finite norm rows and convex combinations exactly.

    Mode v has N_v(x) = max(a * abs(x) for a in rows[v]). Each row family
    includes every unit row. For edge u -> v, combinations[e][j] gives the
    coefficients of b in rows[u] for target row a = rows[v][j].
    Coefficients are nonnegative, sum to one, and must give T_e^T a <= q b.
    This function verifies witnesses. It does not search for row families.
    """
    rate = _rate(q)
    families = {_name(mode): _matrix(family) for mode, family in rows.items()}
    if not families:
        raise ValueError("a polyhedral certificate must contain a mode")
    dimension = len(next(iter(families.values()))[0])
    units = {tuple(Fraction(i == j) for i in range(dimension))
             for j in range(dimension)}
    for family in families.values():
        if any(len(row) != dimension for row in family):
            raise ValueError("norm rows must have a common dimension")
        if not units.issubset(family):
            raise ValueError("each norm row family must contain every unit row")
    checked = _regime_edges(edges, families, dimension)
    if set(combinations) != {edge.name for edge in checked}:
        raise ValueError("convex combinations must cover exactly the supplied edges")
    mixtures = {}
    for edge in checked:
        coefficients = _matrix(combinations[edge.name], len(families[edge.source]))
        if len(coefficients) != len(families[edge.target]):
            raise ValueError("each target row needs one convex combination")
        if any(sum(row) != 1 for row in coefficients):
            raise ValueError("convex coefficients must sum to one")
        mixtures[edge.name] = coefficients
    for edge in checked:
        transpose = tuple(zip(*edge.matrix))
        for target, coefficients in zip(families[edge.target], mixtures[edge.name]):
            bound = tuple(rate * sum(c * row[i] for c, row in
                                     zip(coefficients, families[edge.source]))
                          for i in range(dimension))
            if not _leq(matrix_vector(transpose, target), bound):
                return False
    return True


@dataclass(frozen=True)
class FundingSummary:
    """A path needs balance >= required and returns balance + delta."""

    required: Row
    delta: Row

    def __post_init__(self) -> None:
        required = _vector(self.required, nonnegative=True)
        delta = _vector(self.delta, len(required))
        if any(r + d < 0 for r, d in zip(required, delta)):
            raise ValueError("a realizable summary requires required + delta >= 0")
        object.__setattr__(self, "required", required)
        object.__setattr__(self, "delta", delta)


def compose_summaries(first: FundingSummary, second: FundingSummary) -> FundingSummary:
    """Compose two realizable summaries in execution order."""
    if len(first.required) != len(second.required):
        raise ValueError("summary dimensions do not match")
    required = tuple(max(r, s - d) for r, d, s in
                     zip(first.required, first.delta, second.required))
    delta = tuple(d + e for d, e in zip(first.delta, second.delta))
    return FundingSummary(required, delta)


def path_summary(increments: Sequence[Row], floors: Sequence[Row],
                 dimension: int) -> FundingSummary:
    """Summarize ordered increments and their nonnegative checkpoint floors.

    Include each retained floor and terminal debit as a checkpoint. The implicit
    initial checkpoint has zero increment and zero floor.
    """
    dimension = _dimension(dimension)
    steps = tuple(_vector(row, dimension) for row in increments)
    bounds = tuple(_vector(row, dimension, nonnegative=True) for row in floors)
    if len(steps) != len(bounds):
        raise ValueError("each increment needs one checkpoint floor")
    required = delta = (Fraction(0),) * dimension
    for step, floor in zip(steps, bounds):
        delta = tuple(d + x for d, x in zip(delta, step))
        required = tuple(max(r, f - d) for r, f, d in zip(required, floor, delta))
    return FundingSummary(required, delta)


def action_summary(debit: Row, floor: Row, increment: Row) -> FundingSummary:
    """Summarize payment, retained floor, and one observed signed increment."""
    d = _vector(debit, nonnegative=True)
    h = _vector(floor, len(d), nonnegative=True)
    g = _vector(increment, len(d))
    return path_summary([tuple(-x for x in d), g], [h, (0,) * len(d)], len(d))


@dataclass(frozen=True)
class Outcome:
    state: str
    increment: Row


@dataclass(frozen=True)
class Action:
    name: str
    debit: Row
    floor: Row
    outcomes: Sequence[Outcome]


@dataclass(frozen=True)
class State:
    actions: Sequence[Action] = ()
    terminal: Row | None = None


@dataclass(frozen=True)
class Strategy:
    """Choose action first, then follow children in that action's outcome order.

    A terminal strategy has action=None and no children. Each child records its
    observed successor state. Histories may choose different continuations.
    """

    state: str
    action: str | None = None
    children: tuple[Strategy, ...] = ()


def _completion_model(states: Mapping[str, State], dimension: int
                      ) -> tuple[dict[str, State], tuple[str, ...]]:
    dimension = _dimension(dimension)
    if not states:
        raise ValueError("a completion graph must contain a state")
    result = {}
    dependencies = {}
    for name, state in states.items():
        _name(name)
        terminal = None if state.terminal is None else _vector(
            state.terminal, dimension, nonnegative=True)
        if terminal is not None and state.actions:
            raise ValueError("a terminal state cannot contain actions")
        actions = []
        names = set()
        dependencies[name] = set()
        for action in state.actions:
            action_name = _name(action.name)
            if action_name in names:
                raise ValueError("action names must be unique within a state")
            names.add(action_name)
            debit = _vector(action.debit, dimension, nonnegative=True)
            floor = _vector(action.floor, dimension, nonnegative=True)
            outcomes = []
            children = set()
            for outcome in action.outcomes:
                child = _name(outcome.state)
                if child not in states:
                    raise ValueError("every outcome must name a declared state")
                if child in children:
                    raise ValueError("an action must have distinct successor states")
                children.add(child)
                outcomes.append(Outcome(child, _vector(outcome.increment, dimension)))
            if not outcomes:
                raise ValueError("each action needs a nonempty successor set")
            dependencies[name].update(children)
            actions.append(Action(action_name, debit, floor, tuple(outcomes)))
        result[name] = State(tuple(actions), terminal)
    try:
        order = tuple(TopologicalSorter(dependencies).static_order())
    except CycleError as error:
        raise ValueError("completion graphs must be acyclic") from error
    return result, order


def completion_frontiers(states: Mapping[str, State], dimension: int
                         ) -> dict[str, dict[Vector, Strategy]]:
    """Enumerate exact minimal funding vectors and adapted strategy witnesses.

    A terminal frontier is {m}. An empty frontier means no finite completion.
    An empty child frontier invalidates its action. Each retained strategy picks
    one action and one continuation per possible outcome, before pruning.
    """
    model, order = _completion_model(states, dimension)
    frontiers: dict[str, dict[Vector, Strategy]] = {}
    for name in order:
        state = model[name]
        if state.terminal is not None:
            frontiers[name] = {state.terminal: Strategy(name)}
            continue
        candidates = {}
        for action in state.actions:
            factors = [tuple(frontiers[outcome.state].items()) for outcome in action.outcomes]
            for selection in product(*factors):
                required = tuple(action.debit[i] + max(
                    [action.floor[i]] + [vector[i] - outcome.increment[i]
                                         for (vector, _), outcome in
                                         zip(selection, action.outcomes)])
                                 for i in range(dimension))
                strategy = Strategy(name, action.name, tuple(witness for _, witness in selection))
                candidates.setdefault(required, strategy)
        frontiers[name] = {vector: candidates[vector] for vector in sorted(candidates)
                           if not any(other != vector and _leq(other, vector)
                                      for other in candidates)}
    return frontiers


def frontier_contains(frontier: Iterable[Row], balance: Row) -> bool:
    """Test membership in the upward closure of a finite funding frontier."""
    available = _vector(balance, nonnegative=True)
    vectors = tuple(_vector(row, len(available), nonnegative=True) for row in frontier)
    return any(_leq(required, available) for required in vectors)


def self_test() -> int:
    """Execute bounded exact checks, including when Python disables assertions."""
    checks = 0

    def require(condition: bool, name: str) -> None:
        nonlocal checks
        if not condition:
            raise RuntimeError(name)
        checks += 1

    half = Fraction(1, 2)
    edges = [Edge("out", "u", "v", ((2,),)),
             Edge("back", "v", "u", ((Fraction(1, 8),),))]
    require(verify_box_certificate(edges, {"u": (1,), "v": (4,)}, half), "edge orientation")
    require(not verify_box_certificate(edges, {"u": (4,), "v": (1,)}, half), "reversed weights")
    a, b = ((0, 2), (0, 0)), ((0, 0), (2, 0))
    require(matrix_product(a, a) == matrix_product(b, b) == ((0, 0), (0, 0)), "nilpotent modes")
    require(matrix_product(b, a) == ((0, 0), (0, 4)), "unstable alternating product")
    require(not verify_box_certificate([Edge("a", "u", "v", a), Edge("b", "v", "u", b)],
                                       {"u": (1, 4), "v": (4, 1)}, half), "switching refusal")
    rate = Fraction(3, 4)
    loops = [Edge("r1", "v", "v", ((rate, rate), (0, 0))),
             Edge("r2", "v", "v", ((0, 0), (rate, rate)))]
    rows = {"v": ((1, 0), (0, 1), (1, 1))}
    mixtures = {"r1": ((0, 0, 1),) * 3, "r2": ((0, 0, 1),) * 3}
    require(verify_polyhedral_certificate(loops, rows, rate, mixtures), "polyhedral contraction")
    require(not verify_polyhedral_certificate(loops, rows, half, mixtures), "polyhedral refusal")
    graph = {"s": State((Action("retain", (0,), (1,), (Outcome("t", (0,)),)),)),
             "t": State(terminal=(0,))}
    require(set(completion_frontiers(graph, 1)["s"]) == {(Fraction(1),)}, "retained floor")
    paid_first = path_summary([(-100,), (100,)], [(0,), (0,)], 1)
    paid_last = path_summary([(100,), (-100,)], [(0,), (0,)], 1)
    require(paid_first == FundingSummary((100,), (0,)) and
            paid_last == FundingSummary((0,), (0,)), "payment order")
    require(compose_summaries(action_summary((0,), (1,), (0,)),
                              FundingSummary((0,), (0,))).required == (1,), "floor composition")
    require(completion_frontiers({"blocked": State()}, 1)["blocked"] == {}, "empty frontier")
    increments = [Fraction(1)] * 10
    require(all(r <= Fraction(0) * previous + 1 for previous, r in
                zip(increments, increments[1:])) and sum(increments) == 10,
            "bounded increments do not bound lifetime totals")
    return checks


if __name__ == "__main__":
    print(f"{self_test()} exact mathematical checks passed")
