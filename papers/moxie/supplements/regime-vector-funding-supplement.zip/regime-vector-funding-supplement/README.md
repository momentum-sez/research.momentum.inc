# Regime certificates and vector completion funding

This companion contains exact finite calculations for nonnegative regime matrices and completion funding in several resources.
It accompanies the regime-response and resource-frontier results of *Central Counterparty Risk in Automated Markets*.
The calculations use rational arithmetic and reject floating-point inputs.
They verify supplied mathematical data and do not establish physical response bounds, current authority, live funding, or production admission.

## Requirements

Use CPython 3.9 or later. This profile was checked with CPython 3.9.6, 3.13.12, and 3.14.6.
All dependencies belong to the Python standard library. No package installation is required.
Run the commands below from this extracted directory.

## Reproduce the checks

```sh
python3 -B verify_regime_vector_funding.py
python3 -O -B verify_regime_vector_funding.py
python3 -B -m unittest -q test_verify_regime_vector_funding.py
python3 -O -B -m unittest -q test_verify_regime_vector_funding.py
```

Each checker command exits with status zero and prints `12 exact mathematical checks passed`.
Each test command exits with status zero and reports `Ran 45 tests` and `OK`.
Python reports the elapsed test time separately. That time can vary.
The optimized commands verify that input validation remains active when Python disables assertions.
`PROFILE.json` records these commands, expected results, version requirements, and source hashes.

## Mathematical scope

- Box certificates check one positive weight vector per regime and the directed inequality `T_e w_source <= q w_target`.
- Polyhedral certificates check supplied nonnegative norm rows and exact convex-combination witnesses. The checker does not search for a certificate.
- Completion frontiers use finite acyclic graphs, fixed vector debits, retained floors, signed outcome increments, and terminal payments.
- Each frontier vector retains one adapted strategy. An action is chosen before its outcome becomes known.
- Empty frontiers mean that no finite initial vector completes the represented plan.
- Funding summaries preserve all checkpoint floors, ordered cash movements, and the terminal debit.

The tests include a stable matrix cycle with increasing cumulative sale targets, the unstable product of individually nilpotent matrices, and a stable family without common box weights.
They check the separate finite inventory cap and the need for a target-change bound.
For funding, the tests compare strategies with independent policy and path enumeration and check exponential explicit frontiers in two resources.
The suite covers 1,332 membership comparisons across 36 finite graphs, 1,728 associativity triples, and 1,849 path concatenations.
These finite tests support the stated mathematical implementation. They do not replace the manuscript proofs or establish a production engine.

## Verify the payload

`SHA256SUMS` records every other regular file in this directory. It excludes itself.
The following standard-library command verifies all four payload files:

```sh
python3 - <<'PYVERIFY'
from hashlib import sha256
from pathlib import Path
for line in Path("SHA256SUMS").read_text().splitlines():
    expected, name = line.split("  ", 1)
    if sha256(Path(name).read_bytes()).hexdigest() != expected:
        raise SystemExit("hash mismatch: " + name)
print("4 payload hashes match")
PYVERIFY
```

Archive members have fixed timestamps, permissions, and order. They use stored compression for deterministic bytes.
