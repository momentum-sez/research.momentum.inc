"""Exact finite witnesses for the curvature and arithmetic-size claims."""
from fractions import Fraction as Q
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import statistics
import sys
import time
import tracemalloc


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def polynomial(coefficients, x):
    result = Q(0)
    for coefficient in reversed(coefficients):
        result = result * x + coefficient
    return result


def derivative(coefficients):
    return [i * value for i, value in enumerate(coefficients)][1:]


checks = 0
for p0 in (Q(-3), Q(0), Q(5)):
    for a, lipschitz in ((Q(2), Q(6)), (Q(3), Q(2))):
        f = [Q(0), p0, a / 2, lipschitz / 6]
        df, ddf = derivative(f), derivative(derivative(f))
        radius = a / (2 * lipschitz)
        for ratio in (Q(-3, 4), Q(-1, 3), Q(1, 5), Q(4, 5)):
            d = radius * ratio
            actual = polynomial(f, d) - polynomial(f, Q(0))
            quadratic = polynomial(df, Q(0)) * d + polynomial(ddf, Q(0)) * d * d / 2
            require(abs(actual - quadratic) == lipschitz * abs(d) ** 3 / 6, 'sharp cubic')
            require(polynomial(ddf, d) > a / 2, 'positive curvature')
            alpha, beta = Q(1, 20), Q(1, 10)
            estimate = (p0 + alpha) * d + (a - beta) * d * d / 2
            envelope = alpha * abs(d) + beta * d * d / 2 + lipschitz * abs(d) ** 3 / 6
            require(abs(actual - estimate) <= envelope, 'certified numerical quote')
            checks += 3
for depth in range(10):
    value = Q(2, 3)
    for _ in range(depth):
        value *= value
    require(value.numerator == 2 ** (2 ** depth), 'squaring numerator')
    require(value.denominator == 3 ** (2 ** depth), 'squaring denominator')
    require(value.numerator.bit_length() == 2 ** depth + 1, 'exponential output bits')
    checks += 3

path = Path(__file__).resolve().parent / 'numeric' / 'exact_numeric.py'
spec = importlib.util.spec_from_file_location('p08_numeric_measurement', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
measurements = []
for bits in (16, 64, 256, 1024):
    case = {'id': f'multiply-{bits}', 'op': 'mul',
            'a': {'n': str(2**bits - 1), 'd': str(2**(bits-1) + 1)},
            'b': {'n': str(2**bits - 3), 'd': str(2**(bits-1) + 3)},
            'budget': {'max_bits': min(4096, 2 * bits + 8), 'max_steps': 10000}}
    expected = Q(int(case['a']['n']), int(case['a']['d'])) * Q(int(case['b']['n']), int(case['b']['d']))
    durations = []
    for _ in range(21):
        start = time.perf_counter_ns()
        result = module.evaluate_case(case)
        durations.append(time.perf_counter_ns() - start)
        require(result['status'] == 'Ok', 'reference multiplication admission')
        require(Q(int(result['value']['n']), int(result['value']['d'])) == expected, 'reference product')
        checks += 2
    tracemalloc.start()
    module.evaluate_case(case)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    measurements.append({'input_bits': bits, 'max_bits': case['budget']['max_bits'],
                         'repetitions': 21, 'median_nanoseconds': int(statistics.median(durations)),
                         'traced_peak_bytes_one_case': peak})
result = {'checks': checks, 'status': 'pass', 'python': sys.version.split()[0],
          'platform': platform.platform(), 'numeric_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
          'measurement_scope': 'Python reference case parse, arithmetic, and result serialization. No provider, graph scheduling, or production throughput claim.',
          'measurements': measurements}
print(json.dumps(result, indent=2))
