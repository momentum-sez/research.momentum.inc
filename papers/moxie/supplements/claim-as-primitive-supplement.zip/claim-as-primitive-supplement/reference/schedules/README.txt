Schedule admission reference

Run from this directory with Python 3.9 or later:

    python3 -B test_schedules.py
    python3 -O -B test_schedules.py

The modules use only the Python standard library.

admission.py checks schedule declarations. Each Claim supplies a nonempty H
and a finite tuple of Case(U, P) entries. P lists the input leaves of a
separately typed payoff DAG. A complete payoff type checker supplies those
leaves. This reference checks their schedule obligations.

Descriptor(a, p, F, R) denotes:

    F union {h >= a : h mod p belongs to R}.

The conditions are a,p >= 1, F subset {1,...,a-1}, and
R subset {0,...,p-1}. Heights outside the positive integers are excluded.
An empty R gives a finite schedule. Cases may have empty schedules.
Sets must be frozensets. Declaration sequences must be tuples.

Universal decision bounds

For exact coverage, include H and every U in the cutoff maximum T and
period LCM L. At every h in 1,...,T+L-1, require:

    sum(1_U(h) for U in cases) = 1_H(h).

For a reference from U=(a,p,F,R) to target H=(b,q,G,S), require
h-tau in H whenever h in U. Use tau >= 1,
T=max(a,b+tau), and L=lcm(p,q).

For Window(target,W), require W >= 1. Every h in U must satisfy h >= W+1.
Its target schedule must contain at least one height in [h-W,h-1].
Use T=max(a,b+W) and L=lcm(p,q).

Each predicate is L-periodic from T. Every h >= T has the representative
T+((h-T) mod L), which lies in T,...,T+L-1. The prefix covers every
earlier positive height. The finite check therefore decides the universal
predicate, including the infinite tail.

Oracle leaves permit tau >= 0. Their dates must remain positive.
Admission checks those dates. Attestation availability belongs to readiness.

Resource bounds

Budget bounds each integer's bits, total input bits, input items, maximum
check horizon, and total estimated membership checks. It counts each
descriptor occurrence. Input validation precedes all LCM and height loops.

Before multiplying an accumulated LCM l by f=p/gcd(l,p), the checker
requires f <= period_limit//l. Let work_horizon be the remaining membership
budget divided by the required checks per height. Then
period_limit=min(max_horizon,work_horizon)-T+1.
It reserves the whole declaration's work before checking any height.
A window reserves W+1 membership checks per tested height.
The checker allocates no array whose size depends on the height horizon.

Invalid identifies malformed data or a witnessed failed obligation.
BudgetExceeded gives no validity decision. Supply a larger explicit Budget
to retry. Admission with fixed budgets is a resource-limited decision
procedure for the stated descriptor class. It does not claim polynomial
runtime in binary descriptor size.

Readiness

readiness.py reads one admitted leaf. The caller supplies admitted target
schedules, resolved claim values, and available oracle attestations.
It returns Resolved(amount) or Await(missing, action, amount=None).
A deadline selects an explicit action. The amount remains unresolved.
The function records no oracle value or claim resolution on its own.

A window selects its samples from the declared target schedule. Every
selected sample must have a resolved value. Avg divides by the scheduled
sample count after all samples resolve. An available zero remains a value.
An unavailable sample remains a missing input. Independent leaves can resolve
while another claim awaits evidence. This reference does not implement the
complete payoff evaluator, persistence, signing, settlement, or legal finality.
The window budget bounds sample enumeration. Supplied numerical values and
exact reduction arithmetic have no separate bit budget. The resolved mapping
contains only available amounts. The caller omits every unresolved entry.

Tests include finite bonds, monthly schedules, perpetual references, sparse
windows, seeded infinite recurrences, missing dates, overlapping cases, and
unseeded fixed programs. Boundary fixtures exercise the final check height
and shifted cutoff. Deterministic random tests compare 300 partitions and
800 reference/window obligations against independent finite enumeration.
Those intervals extend beyond three common periods. Tests use explicit
unittest checks, which remain active with Python optimization.
