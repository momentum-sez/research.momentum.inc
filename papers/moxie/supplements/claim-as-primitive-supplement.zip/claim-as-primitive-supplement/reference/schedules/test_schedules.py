"""Exercise universal schedule admission and unavailable-input behavior."""

from dataclasses import replace
from fractions import Fraction
from math import prod
from random import Random
import unittest
from unittest.mock import patch

from admission import (
    Budget, BudgetExceeded, Case, Claim, Const, Descriptor, Invalid,
    Oracle, Ref, Window, admit,
)
from readiness import Await, DeadlinePolicy, Resolved, read_leaf


def finite(*heights):
    return Descriptor(max(heights, default=0) + 1, 1, frozenset(heights))


def periodic(a=1, p=1, residues=(0,)):
    return Descriptor(a, p, R=frozenset(residues))


def constant(name, schedule):
    return Claim(name, schedule, (Case(schedule, (Const(1),)),))


def dependency(source, target, leaf):
    return (constant("target", target), Claim("consumer", source, (Case(source, (leaf,)),)))


def brute_points(descriptor, stop):
    """Enumerate each arithmetic progression without the checker's membership method."""
    points = {h for h in descriptor.F if h <= stop}
    for residue in descriptor.R:
        first = residue
        while first < descriptor.a:
            first += descriptor.p
        points.update(range(first, stop + 1, descriptor.p))
    return points


def accepted(claims):
    try:
        admit(claims)
        return True
    except Invalid:
        return False


class AdmissionTests(unittest.TestCase):
    def test_finite_bond(self):
        claims = (constant("coupons", finite(30, 60, 90)), constant("principal", finite(90)))
        certificate = admit(claims)
        self.assertEqual(certificate.obligations, 2)
        self.assertEqual(certificate.max_horizon, 91)

    def test_monthly_schedule(self):
        monthly = periodic(30, 30)
        certificate = admit((constant("monthly", monthly),))
        self.assertEqual(certificate.max_horizon, 59)
        self.assertEqual([h for h in range(1, 121) if monthly.contains(h)], [30, 60, 90, 120])

    def test_perpetual_reads_two_spot_dates_and_funding(self):
        feed, trade = periodic(), periodic(3)
        claims = (
            constant("spot", feed), constant("funding", feed),
            Claim("perpetual", trade, (Case(trade, (Ref("spot", 1), Ref("spot", 2), Ref("funding", 1))),)),
        )
        self.assertEqual(admit(claims).obligations, 6)

    def test_infinite_seeded_recurrence(self):
        all_heights, later = periodic(), periodic(2)
        memory = Claim("m", all_heights, (Case(finite(1), (Const(0),)), Case(later, (Ref("m", 1),))))
        payoff = Claim("y", later, (Case(later, (Ref("m", 1),)),))
        self.assertEqual(admit((memory, payoff)).obligations, 4)

    def test_sparse_infinite_seeded_recurrence(self):
        odds, later = periodic(1, 2, (1,)), periodic(3, 2, (1,))
        memory = Claim("m", odds, (Case(finite(1), (Const(0),)), Case(later, (Ref("m", 2),))))
        payoff = Claim("y", later, (Case(later, (Ref("m", 2),)),))
        admit((memory, payoff))

    def test_fixed_program_self_reference_has_no_seed(self):
        all_heights = periodic()
        fixed = Claim("m", all_heights, (Case(all_heights, (Ref("m", 1),)),))
        with self.assertRaisesRegex(Invalid, "ref obligation fails at height 1"):
            admit((fixed,))
        later = periodic(2)
        with self.assertRaisesRegex(Invalid, "ref obligation fails at height 2"):
            admit((Claim("m", later, (Case(later, (Ref("m", 1),)),)),))

    def test_fixed_mutual_cycle_cannot_supply_its_first_instance(self):
        all_heights = periodic()
        first = Claim("a", all_heights, (Case(all_heights, (Ref("b", 1),)),))
        second = Claim("b", all_heights, (Case(all_heights, (Ref("a", 1),)),))
        with self.assertRaisesRegex(Invalid, "height 1"):
            admit((first, second))

    def test_sparse_window(self):
        source, target = periodic(3), periodic(1, 2, (1,))
        admit(dependency(source, target, Window("target", 2)))
        with self.assertRaisesRegex(Invalid, "window obligation fails at height 3"):
            admit(dependency(source, target, Window("target", 1)))
        for tau in range(1, 20):
            with self.subTest(tau=tau), self.assertRaises(Invalid):
                admit(dependency(source, target, Ref("target", tau)))

    def test_reference_targets_aggregate_schedule(self):
        target = Claim("target", periodic(), (Case(periodic(1, 2, (1,))), Case(periodic(2, 2, (0,)))))
        consumer = Claim("consumer", periodic(2), (Case(periodic(2), (Ref("target", 1),)),))
        admit((target, consumer))

    def test_missing_target_date(self):
        with self.assertRaisesRegex(Invalid, "height 4"):
            admit(dependency(finite(4), finite(1, 2), Ref("target", 1)))

    def test_overlap_gap_and_outside_claim(self):
        target = periodic()
        cases = (
            (Case(target), Case(finite(3))),
            (Case(periodic(2)),),
            (Case(periodic(1, 3, (1, 2))),),
        )
        for variant in cases:
            with self.subTest(cases=variant), self.assertRaises(Invalid):
                admit((Claim("c", target, variant),))
        with self.assertRaisesRegex(Invalid, "height 2"):
            admit((Claim("c", finite(1), (Case(finite(1, 2)),)),))

    def test_empty_cases_are_permitted(self):
        admit((Claim("c", finite(1), (Case(finite()), Case(finite(1)))),))

    def test_final_check_height_is_inclusive(self):
        with self.assertRaisesRegex(Invalid, "cover obligation fails at height 3"):
            admit((Claim("c", periodic(), (Case(periodic(1, 3, (1, 2))),)),))
        source = Descriptor(3, 3, frozenset((2,)), frozenset((2,)))
        with self.assertRaisesRegex(Invalid, "ref obligation fails at height 5"):
            admit(dependency(source, finite(1), Ref("target", 1)))
        source = Descriptor(4, 3, frozenset((3,)), frozenset((0,)))
        with self.assertRaisesRegex(Invalid, "window obligation fails at height 6"):
            admit(dependency(source, finite(1), Window("target", 2)))

    def test_shifted_cutoff_is_included(self):
        for leaf in (Ref("target", 2), Window("target", 2)):
            with self.subTest(leaf=leaf), self.assertRaisesRegex(Invalid, "height 6"):
                admit(dependency(periodic(3), finite(1, 2, 3), leaf))

    def test_window_minimum_height_and_last_offset(self):
        admit(dependency(finite(3), finite(1), Window("target", 2)))
        with self.assertRaisesRegex(Invalid, "height 2"):
            admit(dependency(finite(2), finite(1), Window("target", 2)))

    def test_natural_number_and_descriptor_validation(self):
        bad = (
            Descriptor(0, 1), Descriptor(1, 0), Descriptor(True, 1),
            Descriptor(2, 1, frozenset((0,))), Descriptor(2, 1, frozenset((-1,))),
            Descriptor(2, 1, frozenset((2,))), Descriptor(1, 2, R=frozenset((2,))),
            Descriptor(1, 2, R=frozenset((-1,))), Descriptor(1, 1, R=frozenset((False,))),
            Descriptor(1, 1, set(), frozenset((0,))), Descriptor(1, 1),
        )
        for descriptor in bad:
            with self.subTest(descriptor=descriptor), self.assertRaises(Invalid):
                admit((constant("c", descriptor),))
        for leaf in (Ref("target", 0), Ref("target", -1), Window("target", 0), Oracle("o", -1)):
            with self.subTest(leaf=leaf), self.assertRaises(Invalid):
                admit(dependency(periodic(3), periodic(), leaf))
        with self.assertRaisesRegex(Invalid, "oracle obligation fails at height 1"):
            admit((Claim("c", periodic(), (Case(periodic(), (Oracle("o", 1),)),)),))
        for h in (0, -1, -100):
            self.assertFalse(periodic().contains(h))

    def test_declaration_validation(self):
        claim = constant("c", periodic())
        for declarations in ((claim, claim), [claim], iter((claim,)), (replace(claim, cases=[]),)):
            with self.subTest(declarations=declarations), self.assertRaises(Invalid):
                admit(declarations)
        with self.assertRaisesRegex(Invalid, "undeclared"):
            admit((Claim("c", periodic(2), (Case(periodic(2), (Ref("absent", 1),)),)),))

    def test_giant_coprime_periods_fail_before_any_height_check(self):
        first, second = periodic(1, 100_003), periodic(1, 100_019)
        declaration = (Claim("c", first, (Case(second),)),)
        for _ in range(3):
            with patch.object(Descriptor, "contains", side_effect=RuntimeError("Height loop started")):
                with self.assertRaisesRegex(BudgetExceeded, "LCM"):
                    admit(declaration, Budget(max_horizon=200_000))

    def test_bits_and_items_fail_before_arithmetic(self):
        huge = periodic(1, 1 << 1024)
        with patch("admission.gcd", side_effect=RuntimeError("Arithmetic started")):
            with self.assertRaisesRegex(BudgetExceeded, "Integer bit"):
                admit((constant("c", huge),))
            with self.assertRaisesRegex(BudgetExceeded, "Input bit"):
                admit((constant("c", periodic()),), Budget(max_input_bits=16))
            with self.assertRaisesRegex(BudgetExceeded, "Input item"):
                admit((constant("c", finite(*range(1, 100))),), Budget(max_input_items=10))

    def test_work_budget_limits_lcm_arithmetic(self):
        first, second = periodic(1, 100_003), periodic(1, 100_019)
        declaration = (Claim("c", first, (Case(second),)),)
        with patch("admission.gcd", side_effect=(1, RuntimeError("Second LCM step started"))):
            with self.assertRaisesRegex(BudgetExceeded, "LCM"):
                admit(declaration, Budget(max_horizon=10 ** 30, max_checks=10))
        with patch("admission.gcd", side_effect=RuntimeError("LCM arithmetic started")):
            with self.assertRaisesRegex(BudgetExceeded, "membership checks"):
                admit((constant("c", periodic()),), Budget(max_checks=1))

    def test_all_preflight_checks_precede_height_loops(self):
        first = constant("small", finite(1))
        huge = constant("large", periodic(1_000_000))
        with patch.object(Descriptor, "contains", side_effect=RuntimeError("Height loop started")):
            with self.assertRaisesRegex(BudgetExceeded, "Cutoff"):
                admit((first, huge))
            many = tuple(constant(f"c{i}", periodic()) for i in range(20))
            with self.assertRaisesRegex(BudgetExceeded, "membership checks"):
                admit(many, Budget(max_checks=39))

    def test_window_work_and_explicit_larger_budget(self):
        claims = dependency(periodic(101), periodic(), Window("target", 100))
        with patch.object(Descriptor, "contains", side_effect=RuntimeError("Height loop started")):
            with self.assertRaisesRegex(BudgetExceeded, "membership checks"):
                admit(claims, Budget(max_checks=10_000))
        certificate = admit(claims, Budget(max_checks=20_000))
        self.assertEqual(certificate.membership_bound, 10_405)
        with self.assertRaises(BudgetExceeded):
            admit((constant("monthly", periodic(30, 30)),), Budget(max_horizon=58))
        admit((constant("monthly", periodic(30, 30)),), Budget(max_horizon=59))
        self.assertFalse(issubclass(BudgetExceeded, Invalid))


class IndependentEnumerationTests(unittest.TestCase):
    def random_descriptor(self, rng, nonempty=False):
        while True:
            a, p = rng.randrange(1, 7), rng.randrange(1, 6)
            descriptor = Descriptor(a, p, frozenset(h for h in range(1, a) if rng.randrange(2)),
                                    frozenset(r for r in range(p) if rng.randrange(2)))
            if not nonempty or descriptor.F or descriptor.R:
                return descriptor

    def test_random_exact_partitions_against_long_enumeration(self):
        rng = Random(50804)
        for trial in range(300):
            declared = self.random_descriptor(rng, True)
            parts = tuple(self.random_descriptor(rng) for _ in range(rng.randrange(4)))
            if trial % 5 == 0:
                parts = (declared,)
            descriptors = (declared,) + parts
            stop = max(s.a for s in descriptors) + 3 * prod(s.p for s in descriptors) + 10
            sets = [brute_points(s, stop) for s in descriptors]
            expected = all(sum(h in s for s in sets[1:]) == int(h in sets[0]) for h in range(1, stop + 1))
            with self.subTest(trial=trial):
                self.assertEqual(accepted((Claim("c", declared, tuple(Case(s) for s in parts)),)), expected)

    def test_random_references_and_windows_against_long_enumeration(self):
        rng = Random(50805)
        for trial in range(400):
            source, target = self.random_descriptor(rng, True), self.random_descriptor(rng, True)
            shift = rng.randrange(1, 7)
            stop = max(source.a, target.a) + shift + 3 * source.p * target.p + 10
            sources, targets = brute_points(source, stop), brute_points(target, stop)
            reference_ok = all(h - shift in targets for h in sources)
            window_ok = all(h > shift and bool(targets.intersection(range(h - shift, h))) for h in sources)
            for leaf, expected in ((Ref("target", shift), reference_ok), (Window("target", shift), window_ok)):
                with self.subTest(trial=trial, leaf=leaf):
                    self.assertEqual(accepted(dependency(source, target, leaf)), expected)


class ReadinessTests(unittest.TestCase):
    def read(self, leaf, h, resolved=None, oracles=None, now=None, schedule=None, **kwargs):
        return read_leaf(leaf, h, {"target": schedule or periodic()}, resolved or {}, oracles or {},
                         now=h if now is None else now, policy=DeadlinePolicy(h + 5, "refer for decision"), **kwargs)

    def test_missing_oracle_awaits_through_deadline_and_retry(self):
        for now, action in ((1, "wait"), (6, "refer for decision"), (20, "refer for decision")):
            state = self.read(Oracle("price"), 1, now=now)
            self.assertIsInstance(state, Await)
            self.assertEqual(state.missing, (("oracle", "price", 1),))
            self.assertEqual(state.action, action)
            self.assertIsNone(state.amount)
        state = self.read(Oracle("price"), 1, now=20, oracles={("price", 1): 9})
        self.assertEqual(state, Resolved(Fraction(9)))

    def test_independent_later_constant_resolves(self):
        self.assertIsInstance(self.read(Oracle("price"), 1), Await)
        self.assertEqual(self.read(Const(7), 2), Resolved(Fraction(7)))
        dependent = self.read(Ref("target", 1), 2)
        self.assertEqual(dependent.missing, (("claim", "target", 1),))
        self.assertIsNone(dependent.amount)

    def test_sparse_average_keeps_missing_scheduled_sample(self):
        odd = periodic(1, 2, (1,))
        state = self.read(Window("target", 2), 3, schedule=odd)
        self.assertEqual(state.missing, (("claim", "target", 1),))
        state = self.read(Window("target", 4), 5, schedule=odd, resolved={("target", 3): 30})
        self.assertIsInstance(state, Await)
        self.assertIsNone(state.amount)
        values = {("target", 1): 10, ("target", 3): 30}
        self.assertEqual(self.read(Window("target", 4), 5, schedule=odd, resolved=values), Resolved(Fraction(20)))

    def test_all_reductions_use_exact_scheduled_values(self):
        values = {("target", 1): 2, ("target", 3): 5}
        for kind, expected in (("Min", 2), ("Max", 5), ("Sum", 7), ("Avg", Fraction(7, 2))):
            self.assertEqual(self.read(Window("target", 4, kind), 5, schedule=periodic(1, 2, (1,)),
                                       resolved=values), Resolved(Fraction(expected)))

    def test_zero_is_an_available_value(self):
        self.assertEqual(self.read(Oracle("price"), 1, oracles={("price", 1): 0}), Resolved(Fraction(0)))

    def test_window_budget_precedes_enumeration(self):
        with patch.object(Descriptor, "contains", side_effect=RuntimeError("Window loop started")):
            with self.assertRaises(BudgetExceeded):
                self.read(Window("target", 100_000), 100_001, max_window=10)

    def test_unscheduled_reads_are_invalid(self):
        with self.assertRaises(Invalid):
            self.read(Ref("target", 1), 3, schedule=finite(1))
        with self.assertRaises(Invalid):
            self.read(Window("target", 2), 4, schedule=finite(1))


if __name__ == "__main__":
    unittest.main(verbosity=2)
