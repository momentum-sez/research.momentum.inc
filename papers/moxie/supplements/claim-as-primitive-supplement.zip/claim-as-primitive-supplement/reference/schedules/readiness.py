"""Read one admitted leaf while preserving unavailable inputs.

The caller supplies resolved claim values and available oracle attestations.
This module does not evaluate a complete payoff DAG or operate a settlement system.
"""

from dataclasses import dataclass
from fractions import Fraction

from admission import Const, Oracle, Ref, Window, Invalid, BudgetExceeded


@dataclass(frozen=True)
class Resolved:
    amount: Fraction


@dataclass(frozen=True)
class Await:
    missing: tuple
    action: str
    amount: None = None


@dataclass(frozen=True)
class DeadlinePolicy:
    deadline: int
    action: str


def read_leaf(leaf, h, schedules, resolved, oracles, *, now, policy, max_window=10_000):
    """Return a value or the exact unavailable scheduled inputs.

    An elapsed deadline selects the stated action and preserves the unresolved amount.
    Window membership selects samples before availability checks.
    """
    if type(h) is not int or h < 1 or type(now) is not int or now < h:
        raise Invalid("Read heights must satisfy 1 <= h <= now.")
    if type(policy) is not DeadlinePolicy or type(policy.deadline) is not int or policy.deadline < h:
        raise Invalid("The deadline must be an integer at or after the instance height.")
    if type(policy.action) is not str or not policy.action:
        raise Invalid("The deadline policy must name an action.")
    if type(max_window) is not int or max_window < 1:
        raise Invalid("The window budget must be a positive integer.")
    if type(leaf) is Const:
        if type(leaf.value) is not int:
            raise Invalid("The constant must be an integer.")
        return Resolved(Fraction(leaf.value))
    if type(leaf) is Oracle:
        if type(leaf.tau) is not int or leaf.tau < 0 or h <= leaf.tau:
            raise Invalid("The oracle offset must target a positive height.")
        samples = (("oracle", leaf.source, h - leaf.tau),)
    elif type(leaf) in (Ref, Window):
        if leaf.target not in schedules:
            raise Invalid("The target schedule is undeclared.")
        target = schedules[leaf.target]
        if type(leaf) is Ref:
            if type(leaf.tau) is not int or leaf.tau < 1 or not target.contains(h - leaf.tau):
                raise Invalid("The reference must target an earlier scheduled instance.")
            samples = (("claim", leaf.target, h - leaf.tau),)
        else:
            if type(leaf.W) is not int or leaf.W < 1 or h <= leaf.W:
                raise Invalid("The window must contain only positive earlier heights.")
            if leaf.W > max_window:
                raise BudgetExceeded("Window read exceeds the explicit window budget.")
            if leaf.reduction not in ("Min", "Max", "Sum", "Avg"):
                raise Invalid("Unknown window reduction.")
            samples = tuple(("claim", leaf.target, b) for b in range(h - leaf.W, h) if target.contains(b))
            if not samples:
                raise Invalid("The window has no scheduled sample.")
    else:
        raise Invalid("Unknown program leaf.")
    values, missing = [], []
    for kind, name, height in samples:
        mapping = oracles if kind == "oracle" else resolved
        key = (name, height)
        if key not in mapping:
            missing.append((kind, name, height))
            continue
        value = mapping[key]
        if type(value) not in (int, Fraction):
            raise Invalid("Available values must be integers or Fractions.")
        values.append(Fraction(value))
    if missing:
        return Await(tuple(missing), "wait" if now < policy.deadline else policy.action)
    if type(leaf) is not Window:
        return Resolved(values[0])
    if leaf.reduction == "Min":
        amount = min(values)
    elif leaf.reduction == "Max":
        amount = max(values)
    else:
        amount = sum(values, Fraction(0))
        if leaf.reduction == "Avg":
            amount /= len(values)
    return Resolved(amount)
