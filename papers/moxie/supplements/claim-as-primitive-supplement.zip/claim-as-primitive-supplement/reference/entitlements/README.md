# Entitlements and funded payoff notes

This finite reference model uses Python integers and exact `Fraction` values.
The test evidence labels are synthetic inputs.
The model assumes the caller has admitted the named authority and evidence.
It does not verify signatures, provider records, custody, title, or redemption access.

Run both test modes from this directory:

```sh
python3 -B -m unittest -v test_entitlements.py
python3 -B -O -m unittest -v test_entitlements.py
```

The model requires Python 3.9 or later and the standard library.
Transition guards use explicit exceptions.
The tests use `unittest` methods, which remain active under `-O`.

`entitlement_model.py` defines these transitions:

- `resolve` binds `(issuance, position_lot, height, leg)` to the complete immutable entitlement record.
  It directs the exact signed product `quantity * value` and stores a nonnegative due.
  An identical replay changes nothing. A changed binding conflicts.
- `record_auxiliary` stores a sample without creating a position or due.
  `reset_coupon_memory` changes evaluation memory independently of retained dues.
- `correct_target` appends a separate directed adjustment due under an atomic expected-head check.
  Targets `100`, `80`, and `70` produce adjustments `-20` and `-10`.
  The original due remains. The model performs no automatic set-off.
- `record_credit` admits one canonical physical booking.
  Reporter and legal-origin labels identify evidence, without creating attribution capacity.
  Authenticated alias resolution precedes admission under an alternate identifier.
  A proposed merger of two admitted bookings raises an identity conflict.
- `allocate` consumes global occurrence capacity and reduces the named due atomically.
  Due and occurrence reports read the same immutable allocation rows.
- `correct_quantity` changes attribution support, while retaining the admitted physical cash booking.
  This operation models a correction to supporting evidence, rather than a replacement cash-booking amount.
  It exposes unsupported historical ownership and leaves accepted legal discharge intact.
  Support returns to original allocation owners in allocation order before new capacity becomes available.
- `record_return` records a distinct physical debit, including one that exposes a cash deficit.
  `reopen` applies an admitted governing return rule and restores the specified outstanding debt.
  Each reopening stays within its debit quantity and original allocation quantity.
- `spend_cash` and `reserve_cash` use current funding independently of historical attribution.
  Creditor spending does not erase the original debt's discharge.

For one occurrence, current support partitions into supported historical ownership and available attribution capacity.
Unsupported historical ownership remains a separate quantity.
The API provides no cancellation operation that releases consumed ownership.
The outstanding amount equals the original due minus legal discharge plus authorized restoration.

`funded_wrapper.py` constructs notes for a declared finite payoff bound `-L <= f <= U`.
It sets `a = L + epsilon`, `b = U + epsilon`, and requires complete funding `G = a + b`.
The note payouts are `a + f` and `b - f`.
They stay positive and sum to `G`. The first note's net gain relative to `a` equals `f`.
`payouts` evaluates scenarios for one funded instance and performs no settlement.
Each scheduled interval requires its own funding reservation.
The tests reject reuse of one cash balance for two simultaneous interval reservations.
The raw pool rejects negative payoffs.
The margin route retains the debt and collateral deficit for an unbounded payoff.
Collateral alone leaves the debt outstanding. Applied collateral requires an admitted performance identifier.
Missing or failed title, redemption, or funding conditions produce `Impaired`.

One process lock models each atomic transition.
The object retains history during its lifetime.
Storage durability, distributed transactions, legal set-off, identity reconciliation, command dispatch, and provider execution require separate implementations.
The wrapper arithmetic assumes its stated funding and rights conditions. It supplies no production or custody evidence.
