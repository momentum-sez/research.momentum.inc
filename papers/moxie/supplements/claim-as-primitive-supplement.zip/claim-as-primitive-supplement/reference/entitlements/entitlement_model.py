"""Finite exact entitlement and receipt model.

Evidence identifiers denote admitted inputs in this fixture. They do not verify
signatures, provider records, legal authority, or custody. One process lock
models each atomic transition. Storage durability and distributed execution
remain outside this reference model.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from threading import RLock


ZERO = Fraction(0)


class Conflict(ValueError):
    """An identity already binds a different immutable record."""


class Rejected(ValueError):
    """A transition fails its declared precondition."""


def exact(value):
    if type(value) not in (int, Fraction):
        raise Rejected("Use an integer or an exact Fraction.")
    return Fraction(value)


def positive(value):
    value = exact(value)
    if value <= 0:
        raise Rejected("The quantity must be positive.")
    return value


def evidence(identifier):
    if not isinstance(identifier, str) or not identifier:
        raise Rejected("Supply an admitted evidence identifier.")


@dataclass(frozen=True)
class CoreKey:
    issuance: str
    position_lot: str
    height: int
    leg: str


@dataclass(frozen=True)
class BoundEntitlement:
    key: CoreKey
    program_digest: str
    resolution_evidence: str
    quantity: Fraction
    value: Fraction
    obligor: str
    beneficiary: str
    asset: str
    context: str
    position_evidence: str
    terms_evidence: str


@dataclass(frozen=True)
class DueId:
    core: CoreKey
    act: str = "resolution"


@dataclass(frozen=True)
class Due:
    origin: DueId
    debtor: str
    creditor: str
    asset: str
    amount: Fraction
    context: str


@dataclass(frozen=True)
class TargetCorrection:
    act: str
    key: CoreKey
    expected_head: str
    target: Fraction
    authority: str


@dataclass(frozen=True)
class CorrectionEntry:
    record: TargetCorrection
    delta: Fraction
    due: Due | None


@dataclass(frozen=True)
class OccurrenceKey:
    namespace: str
    record_kind: str
    stable_reference: str


@dataclass(frozen=True)
class Credit:
    key: OccurrenceKey
    account: str
    asset: str
    amount: Fraction
    booking_evidence: str


@dataclass(frozen=True)
class CreditReport:
    assertion_id: str
    reported_key: OccurrenceKey
    credit: Credit
    reporter: str
    legal_origin: str


@dataclass(frozen=True)
class Allocation:
    allocation_id: str
    occurrence: OccurrenceKey
    due: DueId
    amount: Fraction
    owner: str
    authority: str


@dataclass(frozen=True)
class QuantityCorrection:
    """Correct attribution support while retaining the physical booking."""

    act: str
    occurrence: OccurrenceKey
    expected_head: str
    target: Fraction
    authority: str


@dataclass(frozen=True)
class ReturnDebit:
    key: OccurrenceKey
    credit: OccurrenceKey
    amount: Fraction
    booking_evidence: str


@dataclass(frozen=True)
class Reopening:
    act: str
    debit: OccurrenceKey
    allocation_id: str
    amount: Fraction
    governing_rule: str
    authority: str


@dataclass(frozen=True)
class Support:
    allocation_id: str
    owner: str
    historical_quantity: Fraction
    supported_quantity: Fraction
    unsupported_quantity: Fraction


@dataclass(frozen=True)
class CashState:
    balance: Fraction
    reservations: Fraction
    encumbrances: Fraction
    free: Fraction
    deficit: Fraction


class EntitlementLedger:
    """Retain immutable dues, physical bookings, and allocation ownership."""

    def __init__(self):
        self._lock = RLock()
        self._bindings = {}
        self._dues = {}
        self._targets = {}
        self._heads = {}
        self._corrections = {}
        self._memory = {}
        self._auxiliary = {}
        self._credits = {}
        self._reports = {}
        self._aliases = {}
        self._alias_evidence = {}
        self._allocations = {}
        self._quantity_targets = {}
        self._quantity_heads = {}
        self._quantity_corrections = {}
        self._returns = {}
        self._reopenings = {}
        self._cash_bookings = {}
        self._reservations = {}
        self._encumbrances = {}

    @staticmethod
    def _direct(binding, signed, due_id):
        if signed == 0:
            return None
        debtor, creditor = binding.obligor, binding.beneficiary
        if signed < 0:
            debtor, creditor = creditor, debtor
        return Due(due_id, debtor, creditor, binding.asset,
                   abs(signed), binding.context)

    def resolve(self, binding):
        """Atomically bind the complete record and create its directed due."""
        with self._lock:
            quantity, value = exact(binding.quantity), exact(binding.value)
            prior = self._bindings.get(binding.key)
            if prior is not None:
                if prior != binding:
                    raise Conflict("The core key binds another entitlement.")
                return self._dues.get(DueId(binding.key))
            for item in (binding.program_digest, binding.resolution_evidence,
                         binding.position_evidence, binding.terms_evidence):
                evidence(item)
            if binding.obligor == binding.beneficiary:
                raise Rejected("The counterparties must differ.")
            signed = quantity * value
            due = self._direct(binding, signed, DueId(binding.key))
            self._bindings[binding.key] = binding
            self._targets[binding.key] = signed
            self._heads[binding.key] = "resolution"
            if due is not None:
                self._dues[due.origin] = due
            return due

    def correct_target(self, correction):
        """Append the difference from the current target as a distinct due."""
        with self._lock:
            target = exact(correction.target)
            prior = self._corrections.get(correction.act)
            if prior is not None:
                if prior.record != correction:
                    raise Conflict("The correction act binds another record.")
                return prior
            if correction.act == "resolution":
                raise Rejected("The correction needs a distinct act identifier.")
            evidence(correction.act)
            evidence(correction.authority)
            if self._heads[correction.key] != correction.expected_head:
                raise Conflict("The correction head changed.")
            binding = self._bindings[correction.key]
            delta = target - self._targets[correction.key]
            due = self._direct(binding, delta, DueId(correction.key, correction.act))
            entry = CorrectionEntry(correction, delta, due)
            self._corrections[correction.act] = entry
            self._targets[correction.key] = target
            self._heads[correction.key] = correction.act
            if due is not None:
                self._dues[due.origin] = due
            return entry

    def correction_head(self, key):
        with self._lock:
            return self._heads[key]

    def record_auxiliary(self, claim, height, value, source):
        """Record a sample without issuing a position or creating a due."""
        record = (exact(value), source)
        evidence(source)
        with self._lock:
            key = (claim, height)
            if key in self._auxiliary and self._auxiliary[key] != record:
                raise Conflict("The auxiliary sample binds another record.")
            self._auxiliary[key] = record
            self._memory[claim] = record[0]

    def reset_coupon_memory(self, claim):
        with self._lock:
            self._memory[claim] = ZERO

    def dues(self):
        with self._lock:
            return tuple(self._dues.values())

    def _canonical(self, key):
        return self._aliases.get(key, key)

    def register_alias(self, alias, canonical, authority):
        """Resolve an authenticated alias before it can supply capacity."""
        evidence(authority)
        with self._lock:
            canonical = self._canonical(canonical)
            if canonical not in self._credits:
                raise Rejected("The canonical credit must exist.")
            if alias in self._credits and alias != canonical:
                raise Conflict("Two admitted credits require identity reconciliation.")
            if alias in self._returns or alias in self._cash_bookings:
                raise Conflict("The alias identifies a distinct physical booking.")
            prior = self._aliases.get(alias)
            if prior is not None and prior != canonical:
                raise Conflict("The alias already identifies another occurrence.")
            if alias == canonical:
                raise Rejected("An alias must have a distinct identifier.")
            self._aliases[alias] = canonical
            self._alias_evidence[(alias, canonical, authority)] = authority

    def record_credit(self, report):
        """Record one physical credit despite repeated reporters or origins."""
        with self._lock:
            amount = positive(report.credit.amount)
            prior_report = self._reports.get(report.assertion_id)
            if prior_report is not None:
                if prior_report != report:
                    raise Conflict("The assertion binds another report.")
                return self._credits[report.credit.key]
            credit = report.credit
            evidence(report.assertion_id)
            evidence(credit.booking_evidence)
            if self._canonical(credit.key) != credit.key:
                raise Conflict("Use the canonical occurrence identity.")
            if self._canonical(report.reported_key) != credit.key:
                raise Rejected("Resolve the reported alias before credit admission.")
            prior_credit = self._credits.get(credit.key)
            if prior_credit is not None and prior_credit != credit:
                raise Conflict("The occurrence binds another booking.")
            if prior_credit is None:
                if credit.key in self._cash_bookings:
                    raise Conflict("The occurrence identifies another cash booking.")
                self._credits[credit.key] = credit
                self._quantity_targets[credit.key] = amount
                self._quantity_heads[credit.key] = credit.booking_evidence
                self._cash_bookings[credit.key] = (credit.account, credit.asset, amount)
            self._reports[report.assertion_id] = report
            return credit

    def _support(self, canonical):
        returned = sum((r.amount for r in self._returns.values()
                        if r.credit == canonical), ZERO)
        return max(self._quantity_targets[canonical] - returned, ZERO)

    def support_rows(self, occurrence):
        """Assign current support to historical owners in allocation order."""
        with self._lock:
            canonical = self._canonical(occurrence)
            remaining = self._support(canonical)
            rows = []
            for allocation in self._allocations.values():
                if allocation.occurrence == canonical:
                    supported = min(allocation.amount, remaining)
                    remaining -= supported
                    rows.append(Support(allocation.allocation_id, allocation.owner,
                                        allocation.amount, supported,
                                        allocation.amount - supported))
            return tuple(rows)

    def available_attribution(self, occurrence):
        with self._lock:
            canonical = self._canonical(occurrence)
            owned = sum((a.amount for a in self._allocations.values()
                         if a.occurrence == canonical), ZERO)
            return max(self._support(canonical) - owned, ZERO)

    def allocation_rows(self, due=None, occurrence=None):
        """Project the same immutable rows by due or canonical occurrence."""
        with self._lock:
            canonical = self._canonical(occurrence) if occurrence is not None else None
            return tuple(a for a in self._allocations.values()
                         if (due is None or a.due == due)
                         and (canonical is None or a.occurrence == canonical))

    def legal_discharge(self, due):
        with self._lock:
            return sum((a.amount for a in self._allocations.values()
                        if a.due == due), ZERO)

    def authorized_restoration(self, due):
        with self._lock:
            return sum((r.amount for r in self._reopenings.values()
                        if self._allocations[r.allocation_id].due == due), ZERO)

    def outstanding(self, due):
        with self._lock:
            return (self._dues[due].amount - self.legal_discharge(due)
                    + self.authorized_restoration(due))

    def allocate(self, allocation_id, occurrence, due, amount, authority):
        """Consume global receipt capacity and update one due atomically."""
        with self._lock:
            amount = positive(amount)
            evidence(authority)
            canonical = self._canonical(occurrence)
            obligation = self._dues[due]
            allocation = Allocation(allocation_id, canonical, due, amount,
                                    obligation.creditor, authority)
            prior = self._allocations.get(allocation_id)
            if prior is not None:
                if prior != allocation:
                    raise Conflict("The allocation binds another record.")
                return prior
            credit = self._credits[canonical]
            if (credit.account, credit.asset) != (obligation.creditor, obligation.asset):
                raise Rejected("The credit must match the creditor and asset.")
            if amount > self.available_attribution(canonical):
                raise Rejected("The occurrence has insufficient attribution capacity.")
            if amount > self.outstanding(due):
                raise Rejected("The allocation exceeds the outstanding due.")
            self._allocations[allocation_id] = allocation
            return allocation

    def correct_quantity(self, correction):
        """Revise support without inserting a physical cash occurrence."""
        with self._lock:
            target = exact(correction.target)
            prior = self._quantity_corrections.get(correction.act)
            if prior is not None:
                if prior[0] != correction:
                    raise Conflict("The quantity act binds another correction.")
                return prior[1]
            evidence(correction.act)
            evidence(correction.authority)
            if target < 0:
                raise Rejected("The supported credit quantity must be nonnegative.")
            canonical = self._canonical(correction.occurrence)
            if canonical != correction.occurrence:
                raise Rejected("The correction must name the canonical credit.")
            if correction.act == self._credits[canonical].booking_evidence:
                raise Rejected("A correction cannot reuse the initial booking head.")
            if self._quantity_heads[canonical] != correction.expected_head:
                raise Conflict("The quantity correction head changed.")
            if correction.act == correction.expected_head:
                raise Rejected("The correction needs a distinct act identifier.")
            delta = target - self._quantity_targets[canonical]
            self._quantity_corrections[correction.act] = (correction, delta)
            self._quantity_targets[canonical] = target
            self._quantity_heads[canonical] = correction.act
            return delta

    def record_return(self, debit):
        """Record an actual debit, including an adverse cash deficit."""
        with self._lock:
            amount = positive(debit.amount)
            prior = self._returns.get(debit.key)
            if prior is not None:
                if prior != debit:
                    raise Conflict("The debit occurrence binds another record.")
                return prior
            evidence(debit.booking_evidence)
            if self._canonical(debit.credit) != debit.credit:
                raise Rejected("The debit must name the canonical credit.")
            credit = self._credits[debit.credit]
            if debit.key in self._cash_bookings or debit.key in self._aliases:
                raise Conflict("The debit needs a distinct physical occurrence.")
            self._returns[debit.key] = debit
            self._cash_bookings[debit.key] = (credit.account, credit.asset, -amount)
            return debit

    def reopen(self, reopening):
        """Apply a governing return rule while retaining allocation ownership."""
        with self._lock:
            amount = positive(reopening.amount)
            prior = self._reopenings.get(reopening.act)
            if prior is not None:
                if prior != reopening:
                    raise Conflict("The reopening act binds another record.")
                return prior
            evidence(reopening.governing_rule)
            evidence(reopening.authority)
            debit = self._returns[reopening.debit]
            allocation = self._allocations[reopening.allocation_id]
            if allocation.occurrence != debit.credit:
                raise Rejected("The debit and allocation must name one credit.")
            prior_debit = sum((r.amount for r in self._reopenings.values()
                               if r.debit == debit.key), ZERO)
            prior_allocation = sum((r.amount for r in self._reopenings.values()
                                    if r.allocation_id == allocation.allocation_id), ZERO)
            if amount + prior_debit > debit.amount:
                raise Rejected("The reopening exceeds the debit quantity.")
            if amount + prior_allocation > allocation.amount:
                raise Rejected("The reopening exceeds the allocated quantity.")
            self._reopenings[reopening.act] = reopening
            return reopening

    def cash_state(self, account, asset):
        with self._lock:
            balance = sum((amount for owner, unit, amount in self._cash_bookings.values()
                           if (owner, unit) == (account, asset)), ZERO)
            reserved = sum((q for owner, unit, q in self._reservations.values()
                            if (owner, unit) == (account, asset)), ZERO)
            encumbered = self._encumbrances.get((account, asset), ZERO)
            return CashState(balance, reserved, encumbered,
                             max(balance - reserved - encumbered, ZERO),
                             max(reserved + encumbered - balance, ZERO))

    def reserve_cash(self, command, account, asset, amount):
        with self._lock:
            record = (account, asset, positive(amount))
            prior = self._reservations.get(command)
            if prior is not None:
                if prior != record:
                    raise Conflict("The command binds another reservation.")
                return
            if amount > self.cash_state(account, asset).free:
                raise Rejected("The account has insufficient free cash.")
            self._reservations[command] = record

    def spend_cash(self, occurrence, account, asset, amount):
        """Book ordinary spending without changing historical attribution."""
        with self._lock:
            amount = positive(amount)
            record = (account, asset, -amount)
            prior = self._cash_bookings.get(occurrence)
            if prior is not None:
                if prior != record or occurrence in self._returns:
                    raise Conflict("The occurrence binds another cash booking.")
                return
            if occurrence in self._aliases:
                raise Conflict("The occurrence is an existing credit alias.")
            if amount > self.cash_state(account, asset).free:
                raise Rejected("The account has insufficient free cash.")
            self._cash_bookings[occurrence] = record
