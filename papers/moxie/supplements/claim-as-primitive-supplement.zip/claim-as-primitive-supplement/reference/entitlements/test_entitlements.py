"""Finite positive and adverse traces. All evidence labels are synthetic."""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import fields, replace
from fractions import Fraction as F
from threading import Barrier
import unittest

from entitlement_model import (
    BoundEntitlement, Conflict, CoreKey, Credit, CreditReport, DueId,
    EntitlementLedger, OccurrenceKey, QuantityCorrection, Rejected,
    Reopening, ReturnDebit, TargetCorrection,
)
from funded_wrapper import (
    ComplementNotes, WrapperState, admit_raw_pool_payoff, margin_route,
)


def binding(lot="lot-a", quantity=F(1), value=F(100)):
    return BoundEntitlement(
        CoreKey("issuance-a", lot, 10, "coupon"), "program-digest",
        "resolution-evidence", quantity, value, "issuer", "holder", "USD",
        "payment-height-10", "position-snapshot", "governing-terms",
    )


def occurrence(ref, kind="credit"):
    return OccurrenceKey("synthetic-bank", kind, ref)


def credit_report(ref="payment-a", amount=F(100), assertion="report-a"):
    key = occurrence(ref)
    return CreditReport(assertion, key,
                        Credit(key, "holder", "USD", amount, "booking-" + ref),
                        "reporter-a", "dispute-a")


class EntitlementTests(unittest.TestCase):
    def setUp(self):
        self.ledger = EntitlementLedger()

    def test_core_identity_excludes_mutable_binding_fields(self):
        self.assertEqual([f.name for f in fields(CoreKey)],
                         ["issuance", "position_lot", "height", "leg"])
        original = binding()
        due = self.ledger.resolve(original)
        self.assertEqual(self.ledger.resolve(original), due)
        changes = {
            "program_digest": "other-program",
            "resolution_evidence": "other-resolution",
            "quantity": F(2), "value": F(50),
            "beneficiary": "new-holder", "obligor": "new-issuer",
            "asset": "EUR", "context": "other-maturity",
            "position_evidence": "other-position",
            "terms_evidence": "other-terms",
        }
        for field, value in changes.items():
            with self.subTest(field=field):
                with self.assertRaises(Conflict):
                    self.ledger.resolve(replace(original, **{field: value}))
        self.assertEqual(self.ledger.dues(), (due,))

    def test_signed_quantity_times_value_gives_nonnegative_directed_debt(self):
        cases = [(F(2), F(3), "issuer", "holder", F(6)),
                 (F(-2), F(3), "holder", "issuer", F(6)),
                 (F(2), F(-3), "holder", "issuer", F(6)),
                 (F(-2), F(-3), "issuer", "holder", F(6)),
                 (F(2, 3), F(1, 2), "issuer", "holder", F(1, 3))]
        for i, (q, v, debtor, creditor, amount) in enumerate(cases):
            due = self.ledger.resolve(binding(str(i), q, v))
            self.assertEqual((due.debtor, due.creditor, due.amount),
                             (debtor, creditor, amount))

    def test_zero_and_auxiliary_memory_create_no_debt(self):
        for i, (q, v) in enumerate([(F(0), F(10)), (F(10), F(0))]):
            record = binding(str(i), q, v)
            self.assertIsNone(self.ledger.resolve(record))
            self.assertIsNone(self.ledger.resolve(record))
            with self.assertRaises(Conflict):
                self.ledger.resolve(replace(record, program_digest="new-program"))
        self.ledger.record_auxiliary("miss-counter", 9, F(8), "sample-9")
        self.ledger.reset_coupon_memory("miss-counter")
        self.assertEqual(self.ledger.dues(), ())

    def test_coupon_reset_preserves_due_and_exact_dust(self):
        due = self.ledger.resolve(binding(value=F(1, 3)))
        report = credit_report(amount=F(33, 100))
        self.ledger.record_credit(report)
        self.ledger.allocate("allocation-a", report.credit.key, due.origin,
                             F(33, 100), "allocation-authority")
        self.ledger.record_auxiliary("coupon-memory", 10, F(1, 3), "sample")
        self.ledger.reset_coupon_memory("coupon-memory")
        self.assertEqual(self.ledger.outstanding(due.origin), F(1, 300))
        self.assertEqual(self.ledger.dues(), (due,))

    def test_correction_targets_append_successive_differences(self):
        original = binding()
        due = self.ledger.resolve(original)
        first = TargetCorrection("correction-a", original.key, "resolution",
                                 F(80), "correction-authority")
        second = TargetCorrection("correction-b", original.key, "correction-a",
                                  F(70), "correction-authority")
        a = self.ledger.correct_target(first)
        b = self.ledger.correct_target(second)
        self.assertEqual((a.delta, b.delta), (F(-20), F(-10)))
        self.assertEqual((a.due.debtor, a.due.creditor), ("holder", "issuer"))
        self.assertEqual(due.amount + a.delta + b.delta, F(70))
        self.assertEqual(self.ledger.correct_target(first), a)
        self.assertEqual(self.ledger.correct_target(second), b)
        self.assertEqual(len(self.ledger.dues()), 3)
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(0))
        with self.assertRaises(Conflict):
            self.ledger.correct_target(replace(first, target=F(60)))
        with self.assertRaises(Conflict):
            self.ledger.correct_target(replace(second, act="stale", expected_head="resolution"))

    def test_atomic_expected_head_allows_one_concurrent_original_correction(self):
        original = binding()
        self.ledger.resolve(original)
        barrier = Barrier(2)

        def attempt(item):
            barrier.wait()
            try:
                return self.ledger.correct_target(item)
            except Conflict as error:
                return error

        candidates = [TargetCorrection("correction-a", original.key, "resolution",
                                       F(80), "authority"),
                      TargetCorrection("correction-b", original.key, "resolution",
                                       F(70), "authority")]
        with ThreadPoolExecutor(max_workers=2) as workers:
            results = list(workers.map(attempt, candidates))
        self.assertEqual(sum(isinstance(result, Conflict) for result in results), 1)
        self.assertEqual(len(self.ledger.dues()), 2)

    def test_correction_can_cross_zero_without_rewriting_the_original(self):
        original = binding()
        first = self.ledger.resolve(original)
        correction = TargetCorrection("negative-target", original.key, "resolution",
                                      F(-10), "correction-authority")
        entry = self.ledger.correct_target(correction)
        self.assertEqual(entry.delta, F(-110))
        self.assertEqual((entry.due.debtor, entry.due.creditor), ("holder", "issuer"))
        self.assertEqual(first.amount + entry.delta, F(-10))
        self.assertEqual(self.ledger.outstanding(first.origin), F(100))

    def test_atomic_resolution_creates_one_due(self):
        original = binding()
        with ThreadPoolExecutor(max_workers=8) as workers:
            results = list(workers.map(self.ledger.resolve, [original] * 32))
        self.assertTrue(all(result == results[0] for result in results))
        self.assertEqual(self.ledger.dues(), (results[0],))

    def test_float_values_fail_explicitly(self):
        with self.assertRaises(Rejected):
            self.ledger.resolve(binding(value=0.1))
        self.assertEqual(self.ledger.dues(), ())
        self.ledger.resolve(binding())
        with self.assertRaises(Rejected):
            self.ledger.resolve(binding(value=100.0))


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.ledger = EntitlementLedger()
        self.a = self.ledger.resolve(binding("lot-a", value=F(3)))
        self.b = self.ledger.resolve(binding("lot-b", value=F(3)))
        self.report = credit_report(amount=F(3))
        self.key = self.report.credit.key
        self.ledger.record_credit(self.report)

    def allocate(self, name, due, amount, key=None):
        return self.ledger.allocate(name, self.key if key is None else key,
                                    due.origin, amount, "allocation-rule")

    def correction(self, act, head, target):
        return QuantityCorrection(act, self.key, head, F(target), "quantity-authority")

    def returned(self, amount=F(1)):
        return ReturnDebit(occurrence("return-a", "debit"), self.key, amount,
                           "actual-debit-booking")

    def test_valid_partial_allocations_span_dues_without_duplicate_capacity(self):
        a = self.allocate("allocation-a", self.a, F(7, 3))
        b = self.allocate("allocation-b", self.b, F(2, 3))
        self.assertEqual((self.ledger.outstanding(self.a.origin),
                          self.ledger.outstanding(self.b.origin)), (F(2, 3), F(7, 3)))
        self.assertEqual(self.ledger.available_attribution(self.key), F(0))
        with self.assertRaises(Rejected):
            self.allocate("allocation-c", self.b, F(1, 3))
        self.assertEqual(self.allocate("allocation-a", self.a, F(7, 3)), a)
        with self.assertRaises(Conflict):
            self.allocate("allocation-a", self.b, F(7, 3))
        self.assertEqual(sum(r.historical_quantity for r in self.ledger.support_rows(self.key)),
                         a.amount + b.amount)

    def test_reporter_and_origin_changes_do_not_create_cash_or_attribution(self):
        self.allocate("allocation-a", self.a, F(3))
        self.ledger.record_credit(self.report)
        changed_origin = replace(self.report, assertion_id="report-b", reporter="reporter-b",
                                 legal_origin="another-dispute")
        self.ledger.record_credit(changed_origin)
        self.assertEqual(self.ledger.available_attribution(self.key), F(0))
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(3))
        with self.assertRaises(Conflict):
            self.ledger.record_credit(replace(self.report, legal_origin="changed"))
        with self.assertRaises(Conflict):
            self.ledger.record_credit(replace(changed_origin, assertion_id="report-c",
                                               credit=replace(self.report.credit, amount=F(4))))

    def test_due_and_occurrence_reports_project_the_same_allocation_rows(self):
        first = self.allocate("allocation-a", self.a, F(2))
        second = self.allocate("allocation-b", self.b, F(1))
        occurrence_rows = self.ledger.allocation_rows(occurrence=self.key)
        self.assertEqual(occurrence_rows, (first, second))
        self.assertEqual(self.ledger.allocation_rows(due=self.a.origin), (first,))
        self.assertEqual(self.ledger.allocation_rows(due=self.b.origin), (second,))
        self.assertIs(occurrence_rows[0], self.ledger.allocation_rows(due=self.a.origin)[0])

    def test_alias_resolution_precedes_report_and_preserves_one_capacity(self):
        alias = occurrence("external-alias")
        alias_report = replace(self.report, assertion_id="alias-report", reported_key=alias)
        with self.assertRaises(Rejected):
            self.ledger.record_credit(alias_report)
        self.ledger.register_alias(alias, self.key, "authenticated-alias")
        self.ledger.record_credit(alias_report)
        self.allocate("allocation-a", self.a, F(3), alias)
        self.assertEqual(self.ledger.available_attribution(alias), F(0))
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(3))
        with self.assertRaises(Conflict):
            self.ledger.record_credit(replace(alias_report, assertion_id="forged-report",
                                               credit=replace(self.report.credit, key=alias)))

    def test_late_alias_merge_of_two_admitted_occurrences_is_rejected(self):
        other = credit_report("payment-b", F(3), "report-b")
        self.ledger.record_credit(other)
        self.allocate("allocation-a", self.a, F(3))
        self.allocate("allocation-b", self.b, F(3), other.credit.key)
        with self.assertRaises(Conflict):
            self.ledger.register_alias(other.credit.key, self.key, "late-alias-evidence")
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(0))
        self.assertEqual(self.ledger.outstanding(self.b.origin), F(0))

    def test_quantity_loss_preserves_owner_and_restored_support_returns_to_owner(self):
        self.allocate("allocation-a", self.a, F(3))
        first = self.correction("quantity-a", self.report.credit.booking_evidence, 1)
        self.assertEqual(self.ledger.correct_quantity(first), F(-2))
        row = self.ledger.support_rows(self.key)[0]
        self.assertEqual((row.owner, row.historical_quantity, row.supported_quantity,
                          row.unsupported_quantity), ("holder", F(3), F(1), F(2)))
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(0))
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(3))
        self.assertEqual(self.ledger.correct_quantity(first), F(-2))
        with self.assertRaises(Rejected):
            self.allocate("allocation-b", self.b, F(1))
        self.ledger.correct_quantity(self.correction("quantity-b", "quantity-a", 3))
        row = self.ledger.support_rows(self.key)[0]
        self.assertEqual((row.supported_quantity, row.unsupported_quantity), (F(3), F(0)))
        self.assertEqual(self.ledger.available_attribution(self.key), F(0))
        with self.assertRaises(Rejected):
            self.allocate("allocation-b", self.b, F(1))

    def test_support_is_partitioned_across_every_due(self):
        self.allocate("allocation-a", self.a, F(2))
        self.allocate("allocation-b", self.b, F(1))
        self.ledger.correct_quantity(self.correction(
            "quantity-a", self.report.credit.booking_evidence, F(5, 2)))
        rows = self.ledger.support_rows(self.key)
        self.assertEqual([r.supported_quantity for r in rows], [F(2), F(1, 2)])
        self.assertEqual([r.unsupported_quantity for r in rows], [F(0), F(1, 2)])
        self.assertEqual(sum(r.supported_quantity for r in rows), F(5, 2))

    def test_quantity_target_chain_and_stale_head_conflict(self):
        large = credit_report("large", F(100), "large-report")
        self.ledger.record_credit(large)
        key = large.credit.key
        a = QuantityCorrection("large-a", key, large.credit.booking_evidence, F(80), "authority")
        b = QuantityCorrection("large-b", key, "large-a", F(70), "authority")
        self.assertEqual((self.ledger.correct_quantity(a), self.ledger.correct_quantity(b)),
                         (F(-20), F(-10)))
        with self.assertRaises(Conflict):
            self.ledger.correct_quantity(replace(b, act="stale", expected_head=a.expected_head))
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(103))
        self.assertEqual(self.ledger.available_attribution(key), F(70))

    def test_spending_before_attribution_does_not_debit_twice(self):
        spend = occurrence("ordinary-spend", "debit")
        self.ledger.spend_cash(spend, "holder", "USD", F(3))
        self.ledger.spend_cash(spend, "holder", "USD", F(3))
        self.allocate("allocation-a", self.a, F(3))
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(0))
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(0))
        self.assertEqual(self.ledger.support_rows(self.key)[0].supported_quantity, F(3))

    def test_quantity_correction_cannot_restore_an_old_head_identifier(self):
        initial_head = self.report.credit.booking_evidence
        self.ledger.correct_quantity(self.correction("quantity-a", initial_head, 2))
        with self.assertRaises(Rejected):
            self.ledger.correct_quantity(self.correction(initial_head, "quantity-a", 3))
        with self.assertRaises(Conflict):
            self.ledger.correct_quantity(self.correction("stale-correction", initial_head, 1))
        self.assertEqual(self.ledger.available_attribution(self.key), F(2))

    def test_actual_return_is_distinct_and_reopening_needs_authority(self):
        self.allocate("allocation-a", self.a, F(3))
        debit = self.returned()
        self.ledger.record_return(debit)
        self.ledger.record_return(debit)
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(2))
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(0))
        self.assertEqual(self.ledger.support_rows(self.key)[0].unsupported_quantity, F(1))
        reopening = Reopening("reopen-a", debit.key, "allocation-a", F(1),
                               "return-reopens-debt", "governing-authority")
        with self.assertRaises(Rejected):
            self.ledger.reopen(replace(reopening, authority=""))
        self.ledger.reopen(reopening)
        self.ledger.reopen(reopening)
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(1))
        self.assertEqual(self.ledger.legal_discharge(self.a.origin), F(3))
        self.assertEqual(self.ledger.authorized_restoration(self.a.origin), F(1))
        self.assertEqual(self.ledger.support_rows(self.key)[0].owner, "holder")
        with self.assertRaises(Rejected):
            self.ledger.reopen(replace(reopening, act="reopen-twice"))
        self.assertEqual(self.ledger.cash_state("holder", "USD").balance, F(2))

    def test_return_after_spending_exposes_deficit_and_preserves_due(self):
        self.ledger.spend_cash(occurrence("spend", "debit"), "holder", "USD", F(3))
        self.allocate("allocation-a", self.a, F(3))
        self.ledger.record_return(self.returned())
        cash = self.ledger.cash_state("holder", "USD")
        self.assertEqual((cash.balance, cash.free, cash.deficit), (F(-1), F(0), F(1)))
        self.assertEqual(cash.balance + cash.deficit,
                         cash.free + cash.reservations + cash.encumbrances)
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(0))

    def test_adverse_debit_preserves_existing_cash_reservation(self):
        self.ledger.reserve_cash("command-a", "holder", "USD", F(3))
        self.ledger.record_return(self.returned())
        cash = self.ledger.cash_state("holder", "USD")
        self.assertEqual((cash.balance, cash.reservations, cash.deficit), (F(2), F(3), F(1)))
        self.assertEqual(cash.balance + cash.deficit,
                         cash.free + cash.reservations + cash.encumbrances)
        with self.assertRaises(Rejected):
            self.ledger.reserve_cash("command-b", "holder", "USD", F(1))
        self.assertEqual(self.ledger.outstanding(self.a.origin), F(3))

    def test_currency_and_creditor_mismatch_cannot_discharge(self):
        for field, value in [("asset", "EUR"), ("beneficiary", "other-holder")]:
            due = self.ledger.resolve(replace(binding(field, value=F(3)), **{field: value}))
            with self.assertRaises(Rejected):
                self.allocate("mismatch-" + field, due, F(1))
        self.assertEqual(self.ledger.available_attribution(self.key), F(3))

    def test_concurrent_allocations_conserve_global_capacity(self):
        barrier = Barrier(2)

        def attempt(pair):
            barrier.wait()
            try:
                return self.allocate(pair[0], pair[1], F(2))
            except Rejected as error:
                return error

        with ThreadPoolExecutor(max_workers=2) as workers:
            results = list(workers.map(attempt, [("a", self.a), ("b", self.b)]))
        self.assertEqual(sum(isinstance(result, Rejected) for result in results), 1)
        self.assertEqual(self.ledger.available_attribution(self.key), F(1))


class WrapperTests(unittest.TestCase):
    def test_two_scheduled_intervals_require_separate_funding(self):
        notes = ComplementNotes(F(1, 3), F(2, 3), F(1, 10), F(6, 5))
        ledger = EntitlementLedger()
        report = credit_report(amount=notes.posted_funding)
        ledger.record_credit(report)
        ledger.reserve_cash("interval-a", "holder", "USD", notes.posted_funding)
        with self.assertRaises(Rejected):
            ledger.reserve_cash("interval-b", "holder", "USD", notes.posted_funding)
        ledger.record_credit(credit_report("payment-b", notes.posted_funding, "report-b"))
        ledger.reserve_cash("interval-b", "holder", "USD", notes.posted_funding)
        self.assertEqual(ledger.cash_state("holder", "USD").reservations, F(12, 5))

    def test_complement_boundary_payouts_and_net_gain(self):
        notes = ComplementNotes(F(1, 3), F(2, 3), F(1, 10), F(6, 5))
        self.assertEqual(notes.payouts(F(-1, 3)), (F(1, 10), F(11, 10)))
        self.assertEqual(notes.payouts(F(2, 3)), (F(11, 10), F(1, 10)))
        for numerator in range(-10, 21):
            payoff = F(numerator, 30)
            positive_note, negative_note = notes.payouts(payoff)
            self.assertGreater(positive_note, 0)
            self.assertGreater(negative_note, 0)
            self.assertEqual(positive_note + negative_note, notes.posted_funding)
            self.assertEqual(notes.net_gain(payoff), payoff)

    def test_wrapper_rejects_underfunding_invalid_bounds_and_zero_epsilon(self):
        for args in [(F(1), F(2), F(1, 10), F(3)),
                     (F(-1), F(2), F(1, 10), F(6, 5)),
                     (F(1), F(2), F(0), F(3))]:
            with self.assertRaises(Rejected):
                ComplementNotes(*args)
        notes = ComplementNotes(F(1), F(2), F(1), F(5))
        with self.assertRaises(Rejected):
            notes.payouts(F(-3, 2))
        with self.assertRaises(Rejected):
            notes.payouts(F(5, 2))

    def test_negative_payoff_requires_a_funded_or_margin_route(self):
        with self.assertRaises(Rejected):
            admit_raw_pool_payoff(F(-1))
        self.assertEqual(admit_raw_pool_payoff(F(0)), F(0))
        self.assertEqual(admit_raw_pool_payoff(F(1, 3)), F(1, 3))

    def test_unbounded_route_preserves_debt_and_deficit(self):
        for sign in (-1, 1):
            pending = margin_route(F(sign * 100), "long", "short", F(7))
            self.assertEqual((pending.owed, pending.remaining_debt, pending.deficit),
                             (F(100), F(100), F(93)))
            self.assertEqual(pending.debtor, "long" if sign < 0 else "short")
            applied = margin_route(F(sign * 100), "long", "short", F(7), F(7),
                                   "synthetic-performance-evidence")
            self.assertEqual((applied.funded_performance, applied.remaining_debt, applied.deficit),
                             (F(7), F(93), F(93)))
        with self.assertRaises(Rejected):
            margin_route(F(100), "long", "short", F(7), F(7))

    def test_title_and_redemption_failure_produce_impaired_state(self):
        complete = WrapperState(F(10), F(10), "synthetic-title",
                                "synthetic-redemption", True, True)
        self.assertEqual(complete.status, "SpotEquivalent")
        for changes in ({"title_valid": False}, {"redemption_available": False},
                        {"title_evidence": None}, {"redemption_evidence": None},
                        {"funded_amount": F(9)}):
            with self.subTest(changes=changes):
                self.assertEqual(replace(complete, **changes).status, "Impaired")


if __name__ == "__main__":
    unittest.main(verbosity=2)
