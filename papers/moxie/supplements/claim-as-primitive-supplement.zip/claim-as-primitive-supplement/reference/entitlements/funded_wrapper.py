"""Exact finite payoff wrappers with explicit funding and impairment states."""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from entitlement_model import Rejected, ZERO, evidence, exact, positive


@dataclass(frozen=True)
class ComplementNotes:
    lower_loss: Fraction
    upper_gain: Fraction
    epsilon: Fraction
    posted_funding: Fraction

    def __post_init__(self):
        lower, upper = exact(self.lower_loss), exact(self.upper_gain)
        epsilon, funding = positive(self.epsilon), exact(self.posted_funding)
        if lower < 0 or upper < 0:
            raise Rejected("Use nonnegative finite payoff bounds.")
        if funding != lower + upper + 2 * epsilon:
            raise Rejected("The complement pair requires its complete funded amount.")

    @property
    def a(self):
        return self.lower_loss + self.epsilon

    @property
    def b(self):
        return self.upper_gain + self.epsilon

    def payouts(self, payoff):
        payoff = exact(payoff)
        if not -self.lower_loss <= payoff <= self.upper_gain:
            raise Rejected("The payoff exceeds the declared finite bounds.")
        return self.a + payoff, self.b - payoff

    def net_gain(self, payoff):
        return self.payouts(payoff)[0] - self.a


@dataclass(frozen=True)
class WrapperState:
    funded_amount: Fraction
    required_amount: Fraction
    title_evidence: str | None
    redemption_evidence: str | None
    title_valid: bool
    redemption_available: bool

    @property
    def status(self):
        funding = exact(self.funded_amount)
        required = positive(self.required_amount)
        complete = (funding >= required and self.title_evidence
                    and self.redemption_evidence and self.title_valid
                    and self.redemption_available)
        return "SpotEquivalent" if complete else "Impaired"


@dataclass(frozen=True)
class MarginOutcome:
    debtor: str | None
    creditor: str | None
    owed: Fraction
    collateral: Fraction
    funded_performance: Fraction
    remaining_debt: Fraction
    deficit: Fraction


def margin_route(payoff, long_party, short_party, debtor_collateral,
                 applied_collateral=ZERO, performance_evidence=None):
    """Retain debt beyond supplied collateral for an unbounded payoff route."""
    payoff, collateral = exact(payoff), exact(debtor_collateral)
    performed = exact(applied_collateral)
    if collateral < 0 or performed < 0:
        raise Rejected("The collateral amount must be nonnegative.")
    if performed > min(abs(payoff), collateral):
        raise Rejected("Applied collateral exceeds the debt or funded collateral.")
    if performed > 0:
        evidence(performance_evidence)
    if payoff == 0:
        return MarginOutcome(None, None, ZERO, collateral, ZERO, ZERO, ZERO)
    debtor, creditor = short_party, long_party
    if payoff < 0:
        debtor, creditor = creditor, debtor
    owed = abs(payoff)
    remaining = owed - performed
    return MarginOutcome(debtor, creditor, owed, collateral, performed,
                         remaining, max(owed - collateral, ZERO))


def admit_raw_pool_payoff(payoff):
    payoff = exact(payoff)
    if payoff < 0:
        raise Rejected("A signed negative payoff requires a funded or margin route.")
    return payoff
