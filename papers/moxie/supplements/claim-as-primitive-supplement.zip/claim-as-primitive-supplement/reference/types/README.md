# Financial type reference checker

`financial_types.py` checks financial types and evaluates exact rational values. `test_financial_types.py` supplies positive and adverse vectors.

A scalar type `Theta(unit, scale, context)` has three components. `unit` is a product of named currency, asset, or quantity units. `scale` states physical units per represented number. `context` is a product of economic context names. `Group` stores integer powers of names in canonical order. An empty group is neutral. For example, cents have type `Theta(USD, Fraction(1, 100))`.

Every payoff literal and input has a named `Declaration` in the admitted `Manifest`. Expressions refer to these declarations through `Leaf`. This includes coefficients, bounds, and Boolean literals. Raw numeric expression arguments fail. Type scales, reference offsets, and resolution heights are metadata, rather than payoff literals.

The checker permits one implicit coercion: `Bool` to neutral `Num`. Linear combinations require neutral coefficients and exactly equal argument types. Multiplication combines all three type components. Comparisons require equal types and permit evidence from different heights. Bounds and branches require equal types. Every successful result retains evidence from all operands, including zero terms and unchosen branches.

`Rescale` preserves the unit and context. It multiplies the represented number by `source_scale / target_scale`.

`Convert` requires an admitted `Witness` for the current use. The witness binds source and target types, direction, height, authority, scope, purpose, and the complete rate declaration. The rate unit must equal `target_unit / source_unit`. The rate context must equal `target_context / source_context`. The output number is:

```text
input_number * rate_number * input_scale * rate_scale / target_scale
```

Admission marks each observed conversion rate with `conversion_rate=True`, including rates whose source is a resolved claim. The `observed_rate` role sets this restriction automatically. A restricted declaration can enter an expression only through `Convert`. Neither `Leaf` nor `Ref` can remove this restriction. `Convert` can consume a historical resolved rate by its declared name and exact source record. It requires a strictly earlier source height and the current-use witness.

A contractual dimensioned coefficient can enter multiplication when its declared permitted use matches the current use. That binding includes authority, scope, purpose, and height. Admission fixes each declaration's role, rate restriction, and authorization.

`Ref(name, offset, mode="sample")` reads a declared resolved claim at the exact historical height. Sample mode preserves the unit and scale and returns neutral context. Amount mode preserves all three components. Evidence retains the complete immutable declaration, including its original source, authority, height, type, value, and role.

`check_claim(expression, expected, maturity)` checks the instance height and the declared output type. The caller supplies `expected` and `maturity` from admitted issuance terms. Monetary issuance terms can specify `due(height)` in the expected context. State and observation claims can specify neutral context.

The manifest fixtures represent admitted authority and signature premises. The checker verifies bindings within those premises. Signature verification, signer authorization, source authenticity, and issuance admission remain external obligations. The sample issuer, feeds, and witnesses are fictional test fixtures.

This module implements the finite type rules. Schedule admission, exact numeric budgets, serialization, and production execution are separate concerns.

Run both checks from this directory:

```bash
python3 -B test_financial_types.py
python3 -B -O test_financial_types.py
```

Both runs use explicit checks that remain active under Python optimization.
