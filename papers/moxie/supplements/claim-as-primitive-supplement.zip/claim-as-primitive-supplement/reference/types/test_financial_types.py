"""Positive and adverse financial type vectors with active checks under -O."""

from dataclasses import replace
from fractions import Fraction as F

from financial_types import (
    Cap, Checker, Convert, Declaration, Floor, Group, IfElse, Ind, Leaf,
    LinComb, Manifest, Mul, NEUTRAL, Ref, Rescale, Theta, TypeCheckError,
    Use, Witness, due,
)


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


USD, BTC, GRAM = map(Group.atom, ("USD", "BTC", "gram"))
DOLLAR, CENT = Theta(USD), Theta(USD, F(1, 100))
BITCOIN, SATOSHI = Theta(BTC), Theta(BTC, F(1, 100_000_000))
CASH100, CASH200 = Theta(USD, 1, due(100)), Theta(USD, 1, due(200))
RATE = Theta(USD / BTC)
USE = Use(100, "issuer-A", "claim-A", "settlement")


def fixture():
    items = [
        Declaration("one", 1), Declaration("zero", 0), Declaration("minus", -1),
        Declaration("half", F(1, 2)), Declaration("true", True, sort="Bool"),
        Declaration("false", False, sort="Bool"),
        Declaration("btc", 1, BITCOIN), Declaration("sats", 100_000_000, SATOSHI),
        Declaration("usd", 10, DOLLAR), Declaration("cents", 1000, CENT),
        Declaration("grams", 10, Theta(GRAM)), Declaration("usd_zero", 0, DOLLAR),
        Declaration("usd_bound", 8, DOLLAR), Declaration("cash100", 100, CASH100),
        Declaration("cash200", 100, CASH200),
        Declaration("price80", 50, DOLLAR, role="input", source="feed-A", height=80),
        Declaration("price90", 60, DOLLAR, role="input", source="feed-A", height=90),
        Declaration("rate", 60_000, RATE, role="observed_rate", source="feed-A", height=100),
        Declaration("same_rate", 60_000, RATE, role="observed_rate", source="feed-B", height=100),
        Declaration("discount", F(9, 10), Theta(Group(), 1, due(100) / due(200)),
                    role="observed_rate", source="curve-A", height=100),
        Declaration("fixed_rate", 60_000, RATE, role="contractual_coefficient",
                    source="issuance-A", authority="issuer-A", issuance_use=USE),
        Declaration("old_cash", 100, Theta(USD, F(1, 100), due(80)),
                    role="resolved_claim", source="claim-old", height=80),
        Declaration("new_cash", 110, Theta(USD, F(1, 100), due(90)),
                    role="resolved_claim", source="claim-new", height=90),
        Declaration("future", 1, DOLLAR, role="input", source="feed-A", height=101),
    ]
    declarations = {item.name: replace(item, authority=item.source) if item.authority == "issuance" else item
                    for item in items}
    witnesses = [
        Witness("btc_to_cents", BITCOIN, CENT, declarations["rate"], USE),
        Witness("sats_to_cents", SATOSHI, CENT, declarations["rate"], USE),
        Witness("discount200", CASH200, CASH100, declarations["discount"], USE),
    ]
    manifest = Manifest(declarations, {item.name: item for item in witnesses})
    return Checker(manifest, USE)


def sum_of(left, right):
    return LinComb(((Leaf("one"), left), (Leaf("one"), right)))


def run():
    checker = fixture()
    passed = []

    def positive(name, expression, value, theta, evidence, sort="Num", selected=checker, witnesses=()):
        result = selected.evaluate(expression)
        check(result.value == value and result.theta == theta and result.sort == sort, name + ": result")
        check({item.name for item in result.evidence} == set(evidence), name + ": evidence")
        check(result.witnesses == frozenset(witnesses), name + ": witnesses")
        passed.append(name)
        return result

    def adverse(name, operation, code):
        try:
            operation()
        except TypeCheckError as error:
            check(error.code == code, name + ": wrong rejection " + error.code)
        else:
            raise RuntimeError(name + ": accepted adverse input")
        passed.append(name)

    def reject_expr(name, expression, code, selected=checker):
        adverse(name, lambda: selected.evaluate(expression), code)

    exchange = Convert(Leaf("btc"), "rate", CENT, "btc_to_cents")
    sat_exchange = Convert(Leaf("sats"), "rate", CENT, "sats_to_cents")
    positive("bitcoin_to_satoshi", Rescale(Leaf("btc"), SATOSHI.scale), F(100_000_000), SATOSHI, ("btc",))
    positive("bitcoin_to_cents", exchange, F(6_000_000), CENT, ("btc", "rate"), witnesses=("btc_to_cents",))
    positive("satoshi_to_cents", sat_exchange, F(6_000_000), CENT, ("sats", "rate"), witnesses=("sats_to_cents",))
    positive("bitcoin_via_satoshi_to_cents", replace(sat_exchange, value=Rescale(Leaf("btc"), SATOSHI.scale)),
             F(6_000_000), CENT, ("btc", "rate"), witnesses=("sats_to_cents",))
    positive("cent_to_dollar", Rescale(Leaf("cents"), F(1)), F(10), DOLLAR, ("cents",))
    positive("rescale_then_add", sum_of(Leaf("usd"), Rescale(Leaf("cents"), F(1))), F(20), DOLLAR, ("one", "usd", "cents"))
    positive("historical_price_comparison", Ind("<", Leaf("price80"), Leaf("price90")), True,
             NEUTRAL, ("price80", "price90"), sort="Bool")
    positive("bool_to_neutral_num", Mul(Leaf("true"), Leaf("usd")), F(10), DOLLAR, ("true", "usd"))
    positive("contractual_dimensioned_coefficient", Mul(Leaf("btc"), Leaf("fixed_rate")),
             F(60_000), DOLLAR, ("btc", "fixed_rate"))
    positive("zero_term_keeps_evidence", LinComb(((Leaf("zero"), Leaf("price80")),
             (Leaf("one"), Leaf("price90")))), F(60), DOLLAR, ("zero", "one", "price80", "price90"))
    positive("cancellation_keeps_evidence", LinComb(((Leaf("one"), Leaf("price80")),
             (Leaf("minus"), Leaf("price80")))), F(0), DOLLAR, ("one", "minus", "price80"))
    positive("unchosen_branch_keeps_evidence", IfElse(Leaf("true"), Leaf("price80"), Leaf("price90")),
             F(50), DOLLAR, ("true", "price80", "price90"))
    positive("cap_keeps_both_operands", Cap(Leaf("usd"), Leaf("usd_bound")), F(8), DOLLAR, ("usd", "usd_bound"))
    positive("floor_keeps_both_operands", Floor(Leaf("usd"), Leaf("usd_bound")), F(10), DOLLAR, ("usd", "usd_bound"))
    discount = Convert(Leaf("cash200"), "discount", CASH100, "discount200")
    positive("maturity_conversion_with_witness", sum_of(Leaf("cash100"), discount), F(190), CASH100,
             ("one", "cash100", "cash200", "discount"), witnesses=("discount200",))
    sampled = positive("sample_retains_scale", Ref("old_cash", 20), F(100), CENT, ("old_cash",))
    origin = next(iter(sampled.evidence))
    check(origin.height == 80 and origin.theta == Theta(USD, F(1, 100), due(80)), "sample origin")
    check(origin.value == F(100) and origin.authority == "claim-old", "sample value and authority")
    positive("amount_retains_maturity", Ref("old_cash", 20, "amount"), F(100),
             Theta(USD, F(1, 100), due(80)), ("old_cash",))
    positive("historical_samples_compare", Ind("<", Ref("old_cash", 20), Ref("new_cash", 10)),
             True, NEUTRAL, ("old_cash", "new_cash"), sort="Bool")
    positive("unchosen_conversion_keeps_witness", IfElse(Leaf("false"), exchange, Leaf("cents")),
             F(1000), CENT, ("false", "btc", "rate", "cents"), witnesses=("btc_to_cents",))
    positive("multiplication_combines_context_and_scale", Mul(Leaf("cash100"), Leaf("cents")),
             F(100_000), Theta(USD * USD, F(1, 100), due(100)), ("cash100", "cents"))

    reject_expr("usd_plus_btc", sum_of(Leaf("usd"), Leaf("btc")), "LinCombTypeMismatch")
    reject_expr("grams_plus_currency", sum_of(Leaf("grams"), Leaf("usd")), "LinCombTypeMismatch")
    reject_expr("dollar_plus_cent_without_rescale", sum_of(Leaf("usd"), Leaf("cents")), "LinCombTypeMismatch")
    reject_expr("different_maturities", sum_of(Leaf("cash100"), Leaf("cash200")), "LinCombTypeMismatch")
    reject_expr("dimensioned_linear_coefficient", LinComb(((Leaf("fixed_rate"), Leaf("btc")),)), "DimensionedLinCombCoefficient")
    reject_expr("scaled_neutral_linear_coefficient", LinComb(((Rescale(Leaf("one"), F(1, 100)), Leaf("usd")),)),
                "DimensionedLinCombCoefficient")
    reject_expr("undeclared_literal", 1, "UndeclaredLiteralOrUnknownExpression")
    reject_expr("undeclared_named_literal", Leaf("unissued_zero"), "UndeclaredLeaf")
    reject_expr("undeclared_coefficient", LinComb(((1, Leaf("usd")),)), "UndeclaredLiteralOrUnknownExpression")
    reject_expr("undeclared_bound", Floor(Leaf("usd"), 0), "UndeclaredLiteralOrUnknownExpression")
    reject_expr("undeclared_rate", replace(exchange, rate_name="unknown_rate"), "UndeclaredLeaf")
    reject_expr("naked_observed_rate", Mul(Leaf("btc"), Leaf("rate")), "RateRequiresConvert")
    reject_expr("rate_laundering_by_rescale", Mul(Leaf("btc"), Rescale(Leaf("rate"), F(1))), "RateRequiresConvert")
    reject_expr("rate_laundering_in_zero_term", LinComb(((Leaf("zero"), Leaf("rate")),)), "RateRequiresConvert")
    reject_expr("valid_conversion_does_not_authorize_other_rate_use", sum_of(exchange, Mul(Leaf("btc"), Leaf("rate"))),
                "RateRequiresConvert")
    reject_expr("missing_conversion_witness", replace(exchange, witness_name="absent"), "MissingWitness")
    reject_expr("wrong_source_scale", replace(exchange, value=Leaf("sats")), "WitnessSourceMismatch")
    reject_expr("wrong_target_scale", replace(exchange, target=DOLLAR), "WitnessTargetMismatch")
    reject_expr("reversed_direction", replace(exchange, direction="target_to_source"), "WitnessDirectionMismatch")
    reject_expr("same_rate_value_different_source", replace(exchange, rate_name="same_rate"), "WitnessRateMismatch")
    reject_expr("unitless_source_cannot_extract_rate", replace(exchange, value=Leaf("one")), "WitnessSourceMismatch")
    for field, value in (("height", 101), ("authority", "issuer-B"), ("scope", "claim-B"), ("purpose", "valuation")):
        replay = Checker(checker.manifest, replace(USE, **{field: value}))
        reject_expr(field + "_replay", exchange, "WitnessUseMismatch", replay)
    reject_expr("num_cannot_be_condition", IfElse(Leaf("one"), Leaf("usd"), Leaf("usd_zero")), "ConditionRequiresBool")
    reject_expr("unchosen_branch_type_mismatch", IfElse(Leaf("true"), Leaf("usd"), Leaf("btc")), "BranchTypeMismatch")
    reject_expr("unchosen_branch_undeclared", IfElse(Leaf("true"), Leaf("usd"), Leaf("missing")), "UndeclaredLeaf")
    reject_expr("zero_coefficient_undeclared_operand", LinComb(((Leaf("zero"), Leaf("missing")),)), "UndeclaredLeaf")
    reject_expr("zero_coefficient_wrong_type", LinComb(((Leaf("zero"), Leaf("btc")), (Leaf("one"), Leaf("usd")))), "LinCombTypeMismatch")
    reject_expr("wrong_cap_bound_type", Cap(Leaf("usd"), Leaf("btc")), "BoundTypeMismatch")
    reject_expr("untyped_floor_zero", Floor(Leaf("usd"), Leaf("zero")), "BoundTypeMismatch")
    reject_expr("comparison_scale_mismatch", Ind("=", Leaf("usd"), Leaf("cents")), "IndicatorTypeMismatch")
    reject_expr("amount_reference_context_mismatch", Ind("<", Ref("old_cash", 20, "amount"), Ref("new_cash", 10, "amount")),
                "IndicatorTypeMismatch")
    reject_expr("zero_reference_offset", Ref("old_cash", 0), "NonpositiveReferenceOffset")
    reject_expr("wrong_reference_height", Ref("old_cash", 10), "ReferenceHeightMismatch")
    reject_expr("observed_rate_cannot_be_sampled", Ref("rate", 1), "RefRequiresResolvedClaim")
    reject_expr("direct_resolved_claim_leaf", Leaf("old_cash"), "ResolvedClaimRequiresRef")
    reject_expr("future_input", Leaf("future"), "FutureSource")
    reject_expr("negative_scale", Rescale(Leaf("usd"), F(-1)), "NonpositiveScale")
    reject_expr("floating_point_scale", Rescale(Leaf("usd"), 0.01), "InexactScale")
    reject_expr("empty_linear_combination", LinComb(()), "EmptyLinComb")

    def modified_rate(rate, witness_name="btc_to_cents"):
        entries, witnesses = dict(checker.manifest.declarations), dict(checker.manifest.witnesses)
        entries[rate.name] = rate
        witnesses[witness_name] = replace(witnesses[witness_name], rate=rate)
        return Checker(Manifest(entries, witnesses), USE)

    rate = checker.manifest.declarations["rate"]
    reject_expr("admitted_rate_wrong_unit", exchange, "RateUnitMismatch", modified_rate(replace(rate, theta=Theta(BTC / USD))))
    reject_expr("admitted_rate_wrong_context", exchange, "RateContextMismatch", modified_rate(replace(rate, theta=Theta(USD / BTC, 1, due(200)))))
    scaled_rate = replace(rate, value=F(6_000_000), theta=Theta(USD / BTC, F(1, 100)))
    positive("rate_scale_is_applied", exchange, F(6_000_000), CENT, ("btc", "rate"),
             selected=modified_rate(scaled_rate), witnesses=("btc_to_cents",))
    entries = dict(checker.manifest.declarations)
    entries["rate"] = replace(rate, value=F(60_001))
    reject_expr("rate_value_changed_after_admission", exchange, "WitnessRateMismatch",
                Checker(Manifest(entries, checker.manifest.witnesses), USE))
    for field, value in (("height", 101), ("authority", "issuer-B"), ("scope", "claim-B"), ("purpose", "valuation")):
        replay = Checker(checker.manifest, replace(USE, **{field: value}))
        reject_expr("contractual_coefficient_" + field + "_replay", Mul(Leaf("btc"), Leaf("fixed_rate")),
                    "IssuanceUseMismatch", replay)
    adverse("contractual_coefficient_requires_issuance", lambda: Declaration("coefficient", 1, RATE, role="contractual_coefficient"),
            "MissingIssuanceAuthorization")
    evidence_before = checker.evaluate(Leaf("usd")).evidence
    entries = dict(checker.manifest.declarations)
    entries["usd"] = replace(entries["usd"], value=F(11))
    changed_value = Checker(Manifest(entries, checker.manifest.witnesses), USE)
    check(evidence_before != changed_value.evaluate(Leaf("usd")).evidence, "evidence binds exact value")
    entries["usd"] = replace(checker.manifest.declarations["usd"], authority="issuer-B")
    changed_authority = Checker(Manifest(entries, checker.manifest.witnesses), USE)
    check(evidence_before != changed_authority.evaluate(Leaf("usd")).evidence, "evidence binds source authority")
    passed.extend(("evidence_binds_value", "evidence_binds_authority"))
    historical_rate = Declaration("historical_rate", 60_000, RATE, role="resolved_claim", source="resolved-fx-feed",
                                  height=80, authority="feed-A", conversion_rate=True)
    entries = dict(checker.manifest.declarations)
    entries[historical_rate.name] = historical_rate
    historical_witness = Witness("historical_fx", BITCOIN, CENT, historical_rate, USE)
    historical = Checker(Manifest(entries, {historical_witness.name: historical_witness}), USE)
    reject_expr("resolved_rate_cannot_bypass_conversion", Mul(Leaf("btc"), Ref("historical_rate", 20)),
                "RateRequiresConvert", historical)
    reject_expr("resolved_rate_amount_mode_cannot_bypass_conversion", Mul(Leaf("btc"), Ref("historical_rate", 20, "amount")),
                "RateRequiresConvert", historical)
    positive("resolved_rate_with_current_use_witness", Convert(Leaf("btc"), "historical_rate", CENT, "historical_fx"),
             F(6_000_000), CENT, ("btc", "historical_rate"), selected=historical, witnesses=("historical_fx",))
    reject_expr("historical_rate_purpose_replay", Convert(Leaf("btc"), "historical_rate", CENT, "historical_fx"),
                "WitnessUseMismatch", Checker(historical.manifest, replace(USE, purpose="valuation")))
    entries[historical_rate.name] = replace(historical_rate, height=100)
    reject_expr("resolved_rate_must_be_historical", Convert(Leaf("btc"), "historical_rate", CENT, "historical_fx"),
                "NonhistoricalResolvedRate", Checker(Manifest(entries, historical.manifest.witnesses), USE))
    adverse("python_bool_is_not_rational", lambda: Declaration("bad", True), "InexactNumber")
    adverse("python_int_is_not_bool", lambda: Declaration("bad", 1, sort="Bool"), "InvalidBool")
    adverse("float_is_not_exact_input", lambda: Declaration("bad", 0.1), "InexactNumber")
    adverse("bool_is_not_group_power", lambda: Group((("USD", True),)), "InvalidPower")
    adverse("zero_scale", lambda: Theta(USD, F(0)), "NonpositiveScale")
    adverse("declaration_identifier_mismatch", lambda: Manifest({"alias": rate}, {}), "DeclarationKeyMismatch")
    check(Group((("USD", 2), ("BTC", 0), ("USD", -1))) == USD, "canonical groups")
    check(Theta(USD, F(2, 200)) == CENT and (USD / BTC) * BTC == USD, "canonical fractions and cancellation")
    passed.append("canonical_type_equality")

    root = checker.check_claim(Leaf("cash100"), CASH100, 100)
    check(root.value == F(100) and root.theta == CASH100, "monetary claim root")
    state = checker.check_claim(Leaf("one"), NEUTRAL, 100)
    check(state.value == F(1) and state.theta == NEUTRAL, "state claim root")
    passed.extend(("monetary_claim_root", "neutral_state_claim_root"))
    adverse("wrong_claim_height", lambda: checker.check_claim(Leaf("cash100"), CASH100, 200), "ClaimMaturityMismatch")
    adverse("wrong_claim_currency", lambda: checker.check_claim(Leaf("btc"), CASH100, 100), "ClaimRootTypeMismatch")
    adverse("wrong_claim_economic_maturity", lambda: checker.check_claim(Leaf("cash200"), CASH100, 100), "ClaimRootTypeMismatch")
    adverse("sample_does_not_become_cash_payable", lambda: checker.check_claim(Ref("old_cash", 20), CASH100, 100), "ClaimRootTypeMismatch")
    print(f"PASS {len(passed)} financial type vectors")


if __name__ == "__main__":
    run()
