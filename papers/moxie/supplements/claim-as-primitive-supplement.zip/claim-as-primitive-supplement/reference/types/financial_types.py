"""Exact financial type checking over admitted declarations and witnesses.

The caller supplies the authority and signature admission premise.
This module checks reference bindings. It does not verify signatures.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from fractions import Fraction
from types import MappingProxyType
from typing import Mapping


class TypeCheckError(ValueError):
    """A named type or evidence rule failed."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def require(condition: bool, code: str) -> None:
    if not condition:
        raise TypeCheckError(code)


@dataclass(frozen=True)
class Group:
    """A canonical finite product of named generators with integer powers."""

    powers: tuple[tuple[str, int], ...] = ()

    def __post_init__(self):
        combined: dict[str, int] = {}
        for name, power in self.powers:
            require(isinstance(name, str) and bool(name), "InvalidGenerator")
            require(type(power) is int, "InvalidPower")
            combined[name] = combined.get(name, 0) + power
        canonical = tuple(sorted((name, power) for name, power in combined.items() if power))
        object.__setattr__(self, "powers", canonical)

    @classmethod
    def atom(cls, name: str) -> Group:
        return cls(((name, 1),))

    def __mul__(self, other: Group) -> Group:
        return Group(self.powers + other.powers)

    def __truediv__(self, other: Group) -> Group:
        return self * Group(tuple((name, -power) for name, power in other.powers))


@dataclass(frozen=True)
class Theta:
    """Nominal unit, physical units per number, and economic context."""

    unit: Group = Group()
    scale: Fraction = Fraction(1)
    context: Group = Group()

    def __post_init__(self):
        require(isinstance(self.unit, Group) and isinstance(self.context, Group), "InvalidGroup")
        require(type(self.scale) in (int, Fraction), "InexactScale")
        require(self.scale > 0, "NonpositiveScale")
        object.__setattr__(self, "scale", Fraction(self.scale))

    def __mul__(self, other: Theta) -> Theta:
        return Theta(self.unit * other.unit, self.scale * other.scale, self.context * other.context)


NEUTRAL = Theta()


def due(height: int) -> Group:
    require(type(height) is int and height >= 0, "InvalidHeight")
    return Group.atom(f"due:{height}")


@dataclass(frozen=True)
class Declaration:
    """An admitted literal, input, rate, coefficient, or resolved claim."""

    name: str
    value: Fraction | bool
    theta: Theta = NEUTRAL
    sort: str = "Num"
    role: str = "literal"
    source: str = "issuance"
    height: int | None = None
    authority: str = "issuance"
    issuance_use: Use | None = None
    conversion_rate: bool = False

    def __post_init__(self):
        require(bool(self.name) and bool(self.source) and bool(self.authority), "MissingDeclarationIdentity")
        require(isinstance(self.theta, Theta), "InvalidTheta")
        require(self.role in ("literal", "input", "observed_rate", "contractual_coefficient", "resolved_claim"), "InvalidRole")
        require(self.sort in ("Num", "Bool"), "InvalidSort")
        require(type(self.conversion_rate) is bool, "InvalidRateRestriction")
        if self.role == "observed_rate":
            object.__setattr__(self, "conversion_rate", True)
        if self.conversion_rate:
            require(self.role in ("input", "observed_rate", "resolved_claim") and self.sort == "Num", "InvalidRateRole")
        if self.sort == "Bool":
            require(type(self.value) is bool and self.theta == NEUTRAL, "InvalidBool")
        else:
            require(type(self.value) in (int, Fraction), "InexactNumber")
            object.__setattr__(self, "value", Fraction(self.value))
        if self.height is not None:
            require(type(self.height) is int and self.height >= 0, "InvalidHeight")
        if self.role in ("input", "observed_rate", "resolved_claim"):
            require(self.height is not None, "MissingSourceHeight")
        if self.role in ("observed_rate", "contractual_coefficient", "resolved_claim"):
            require(self.sort == "Num", "InvalidRoleSort")
        if self.role == "contractual_coefficient":
            require(isinstance(self.issuance_use, Use), "MissingIssuanceAuthorization")


@dataclass(frozen=True)
class Use:
    height: int
    authority: str
    scope: str
    purpose: str

    def __post_init__(self):
        require(type(self.height) is int and self.height >= 0, "InvalidHeight")
        require(bool(self.authority) and bool(self.scope) and bool(self.purpose), "MissingUseBinding")


@dataclass(frozen=True)
class Witness:
    """An admitted authorization with exact source, target, and rate bindings."""

    name: str
    source_theta: Theta
    target_theta: Theta
    rate: Declaration
    use: Use
    direction: str = "source_to_target"


@dataclass(frozen=True)
class Manifest:
    """The caller admits this immutable fixture before checking a program."""

    declarations: Mapping[str, Declaration]
    witnesses: Mapping[str, Witness]

    def __post_init__(self):
        entries, witnesses = dict(self.declarations), dict(self.witnesses)
        require(all(name == item.name for name, item in entries.items()), "DeclarationKeyMismatch")
        require(all(name == item.name for name, item in witnesses.items()), "WitnessKeyMismatch")
        object.__setattr__(self, "declarations", MappingProxyType(entries))
        object.__setattr__(self, "witnesses", MappingProxyType(witnesses))


class Expr:
    pass


@dataclass(frozen=True)
class Leaf(Expr):
    name: str


@dataclass(frozen=True)
class Ref(Expr):
    name: str
    offset: int
    mode: str = "sample"


@dataclass(frozen=True)
class LinComb(Expr):
    terms: tuple[tuple[Expr, Expr], ...]


@dataclass(frozen=True)
class Mul(Expr):
    left: Expr
    right: Expr


@dataclass(frozen=True)
class Ind(Expr):
    relation: str
    left: Expr
    right: Expr


@dataclass(frozen=True)
class Cap(Expr):
    value: Expr
    bound: Expr


@dataclass(frozen=True)
class Floor(Expr):
    value: Expr
    bound: Expr


@dataclass(frozen=True)
class IfElse(Expr):
    condition: Expr
    positive: Expr
    negative: Expr


@dataclass(frozen=True)
class Rescale(Expr):
    value: Expr
    target_scale: Fraction


@dataclass(frozen=True)
class Convert(Expr):
    value: Expr
    rate_name: str
    target: Theta
    witness_name: str
    direction: str = "source_to_target"


Evidence = Declaration


@dataclass(frozen=True)
class Result:
    value: Fraction | bool
    theta: Theta
    sort: str
    evidence: frozenset[Evidence]
    witnesses: frozenset[str] = frozenset()


def numeric(result: Result) -> Result:
    if result.sort == "Bool":
        return replace(result, value=Fraction(int(result.value)), theta=NEUTRAL, sort="Num")
    return result


def joined(value, theta, sort, *operands: Result) -> Result:
    evidence = frozenset(item for operand in operands for item in operand.evidence)
    witnesses = frozenset(item for operand in operands for item in operand.witnesses)
    return Result(value, theta, sort, evidence, witnesses)


class Checker:
    def __init__(self, manifest: Manifest, use: Use):
        self.manifest = manifest
        self.use = use

    def declaration(self, name: str) -> Declaration:
        require(name in self.manifest.declarations, "UndeclaredLeaf")
        declaration = self.manifest.declarations[name]
        if declaration.height is not None:
            require(declaration.height <= self.use.height, "FutureSource")
        if declaration.role == "contractual_coefficient":
            require(declaration.issuance_use == self.use, "IssuanceUseMismatch")
        return declaration

    @staticmethod
    def source_result(item: Declaration) -> Result:
        return Result(item.value, item.theta, item.sort, frozenset((item,)))

    def evaluate(self, expression: Expr) -> Result:
        if isinstance(expression, Leaf):
            item = self.declaration(expression.name)
            require(not item.conversion_rate, "RateRequiresConvert")
            require(item.role != "resolved_claim", "ResolvedClaimRequiresRef")
            return self.source_result(item)

        if isinstance(expression, Ref):
            item = self.declaration(expression.name)
            require(item.role == "resolved_claim", "RefRequiresResolvedClaim")
            require(not item.conversion_rate, "RateRequiresConvert")
            require(type(expression.offset) is int and expression.offset > 0, "NonpositiveReferenceOffset")
            require(item.height == self.use.height - expression.offset, "ReferenceHeightMismatch")
            require(expression.mode in ("sample", "amount"), "InvalidReferenceMode")
            result = self.source_result(item)
            if expression.mode == "amount":
                return result
            return replace(result, theta=Theta(item.theta.unit, item.theta.scale, Group()))

        if isinstance(expression, LinComb):
            require(bool(expression.terms), "EmptyLinComb")
            pairs = [(numeric(self.evaluate(a)), numeric(self.evaluate(x))) for a, x in expression.terms]
            theta = pairs[0][1].theta
            require(all(a.theta == NEUTRAL for a, _ in pairs), "DimensionedLinCombCoefficient")
            require(all(x.theta == theta for _, x in pairs), "LinCombTypeMismatch")
            total = sum((a.value * x.value for a, x in pairs), Fraction(0))
            return joined(total, theta, "Num", *(item for pair in pairs for item in pair))

        if isinstance(expression, (Mul, Ind)):
            left, right = numeric(self.evaluate(expression.left)), numeric(self.evaluate(expression.right))
            if isinstance(expression, Mul):
                return joined(left.value * right.value, left.theta * right.theta, "Num", left, right)
            require(left.theta == right.theta, "IndicatorTypeMismatch")
            require(expression.relation in ("<", "<=", "=", ">=", ">"), "InvalidRelation")
            comparisons = {"<": left.value < right.value, "<=": left.value <= right.value,
                           "=": left.value == right.value, ">=": left.value >= right.value,
                           ">": left.value > right.value}
            return joined(comparisons[expression.relation], NEUTRAL, "Bool", left, right)

        if isinstance(expression, (Cap, Floor)):
            value, bound = numeric(self.evaluate(expression.value)), numeric(self.evaluate(expression.bound))
            require(value.theta == bound.theta, "BoundTypeMismatch")
            operation = min if isinstance(expression, Cap) else max
            return joined(operation(value.value, bound.value), value.theta, "Num", value, bound)

        if isinstance(expression, IfElse):
            condition = self.evaluate(expression.condition)
            positive, negative = numeric(self.evaluate(expression.positive)), numeric(self.evaluate(expression.negative))
            require(condition.sort == "Bool", "ConditionRequiresBool")
            require(positive.theta == negative.theta, "BranchTypeMismatch")
            value = positive.value if condition.value else negative.value
            return joined(value, positive.theta, "Num", condition, positive, negative)

        if isinstance(expression, Rescale):
            value = numeric(self.evaluate(expression.value))
            target = Theta(value.theta.unit, expression.target_scale, value.theta.context)
            number = value.value * value.theta.scale / target.scale
            return joined(number, target, "Num", value)

        if isinstance(expression, Convert):
            value = numeric(self.evaluate(expression.value))
            rate = self.declaration(expression.rate_name)
            require(rate.conversion_rate, "ConvertRequiresObservedRate")
            if rate.role == "resolved_claim":
                require(rate.height < self.use.height, "NonhistoricalResolvedRate")
            require(expression.witness_name in self.manifest.witnesses, "MissingWitness")
            witness = self.manifest.witnesses[expression.witness_name]
            require(witness.use == self.use, "WitnessUseMismatch")
            require(witness.source_theta == value.theta, "WitnessSourceMismatch")
            require(witness.target_theta == expression.target, "WitnessTargetMismatch")
            require(witness.direction == expression.direction == "source_to_target", "WitnessDirectionMismatch")
            require(witness.rate == rate, "WitnessRateMismatch")
            require(rate.theta.unit == expression.target.unit / value.theta.unit, "RateUnitMismatch")
            require(rate.theta.context == expression.target.context / value.theta.context, "RateContextMismatch")
            number = value.value * rate.value * value.theta.scale * rate.theta.scale / expression.target.scale
            output = joined(number, expression.target, "Num", value, self.source_result(rate))
            return replace(output, witnesses=output.witnesses | frozenset((witness.name,)))

        raise TypeCheckError("UndeclaredLiteralOrUnknownExpression")

    def check_claim(self, expression: Expr, expected: Theta, maturity: int) -> Result:
        """Check a declared claim instance at its resolution height."""
        require(type(maturity) is int and maturity >= 0, "InvalidMaturity")
        require(self.use.height == maturity, "ClaimMaturityMismatch")
        result = numeric(self.evaluate(expression))
        require(result.theta == expected, "ClaimRootTypeMismatch")
        return result
