# Exact rational numeric reference

This reference evaluates rational payoff nodes and records settlement residuals.
Python uses integers and `Fraction`. JavaScript uses `BigInt` and Euclid reduction.
Both implementations consume the same JSON vectors and return canonical rational pairs.
This is a research reference. It supplies executable numerical evidence, with no production runtime claim.

## Input and result contract

A rational represents the exact real number `n/d`, where `d > 0`.
Every result reduces the pair by its greatest common divisor.
Zero has the unique output pair `{"n":"0","d":"1"}`.

Inputs use canonical decimal strings or pairs of canonical integer strings.
Examples include `"9007199254740993"`, `"-0.125"`, and `{"n":"2","d":"6"}`.
The last input normalizes to `{"n":"1","d":"3"}`.
Canonical strings omit a leading plus, leading integer zeros, trailing fractional zeros, exponents, and negative zero.
JSON numeric values do not enter rational arithmetic.

Each request has a `cases` array. Each case supplies `id`, `op`, and the named operands.
Case IDs must be strings. A missing or non-string ID returns `id: null` with `InvalidInput` before numeric evaluation.
Each response has a matching `results` array.
A successful case returns `status: Ok` and `value`.
A rejected case returns one named status, without a numeric value.
The statuses are `BudgetExceeded`, `InvalidInput`, `InvalidBool`, and `AmbiguousGuard`.

| Operation | Operands | Result |
| --- | --- | --- |
| `parse` | `value` | Reduced rational |
| `add`, `sub`, `mul` | `a`, `b` | Exact rational |
| `compare` | `relation`, `a`, `b` | JSON Boolean |
| `indicator` | `relation`, `a`, `b` | Typed object Boolean |
| `cap`, `floor` | `value`, `bound` | Minimum or maximum |
| `lincomb` | `coefficients`, `values` | Exact weighted sum |
| `ifelse` | `condition`, `then`, `else` | Selected rational |
| `interval` | `relation`, `a`, `b` | Comparison knowledge |
| `guard` | `knowledge`, `then`, `else` | Certified branch value |
| `settle` | `value`, `quantum` | Units, amount, and residual |

Relations are `<`, `<=`, `=`, `>=`, and `>`.
An object Boolean has exactly `{"sort":"Bool","value":0}` or `{"sort":"Bool","value":1}`.
The node evaluator validates both branch operands before a successful selection.
The reference has no graph scheduler, oracle authentication, or historical-reference resolver.
Resolved leaf values enter the rational input boundary.

## Integer and execution budgets

Each case creates a budget with `max_bits` and `max_steps`.
Defaults are 256 bits and 10,000 steps.
Admitted ranges are 1 through 4,096 bits and 1 through 1,000,000 steps.
Budget metadata uses integral JSON numbers, with Boolean aliases rejected.
The spellings `1` and `1.0` have the same metadata meaning.
Explicit typed Boolean values also accept these integral spellings.

Let `B = max_bits` and `L = 2^B - 1`.
The bound applies to the magnitude of each integer operand and arithmetic intermediate.
The implementation constructs `L` from integers of at most `B` bits.
It compares decimal input digits with the decimal form of `L` before integer conversion.
Non-ASCII numeric strings return `InvalidInput` before length admission.
ASCII length checks precede integer conversion and canonical decimal validation.
Decimal denominators use checked multiplication by ten.

Multiplication first checks `abs(a) <= L // abs(b)` when both operands are nonzero.
Addition first checks `abs(a) <= L - abs(b)` when both operands have the same sign.
These checks precede the potentially oversized result allocation.
Opposite-sign addition cannot exceed the larger admitted magnitude.
Division, remainders, sign changes, and reductions do not increase admitted magnitudes.
Cross cancellation occurs before rational multiplication.
Addition shares denominator factors before forming its numerator.
Comparisons check both cross products before ordering them.

The implementation charges deterministic steps before parsing integers, arithmetic primitives, Euclid iterations, and normalization.
Settlement also charges before integer floor division.
An exhausted budget returns `BudgetExceeded`. Arithmetic never wraps or substitutes a saturated amount.
The budget can reject an operation whose reduced answer fits, because an intermediate exceeds `B`.
The vectors include `255/2 + 255/2` under an eight-bit bound.
Its numerator requires nine bits before reduction, so admission fails.

These are numeric admission bounds. The caller separately bounds JSON transport, case counts, and retained graph values.
The reference does not claim a process memory quota or a wall-clock deadline.
If a graph retains `N` rational slots, its stored integer payload uses `O(NB)` bits.
For schoolbook arithmetic, multiplication and division cost `O(B^2)` bit operations.
Euclid reduction takes `O(B)` remainder steps, giving the conservative bound `O(B^3)` per reduction.
Python normalization also calls the bounded `Fraction` constructor.
Including that constructor, `T` charged steps give the conservative arithmetic bound `O(TB^3)`.
Host allocator overhead and decimal serialization require separate implementation accounting.

## Exact payoff relation

Associate each stored pair with its rational value in the real numbers.
Reduction preserves that value because it divides both integers by a common positive factor.
Cross cancellation preserves products. Common denominators preserve sums and differences.
Positive denominators make cross-product comparisons equivalent to real-number comparisons.
Thus each successful arithmetic node returns the exact rational interpretation of its inputs.
This statement is a direct arithmetic argument, with executable examples below. It is not a mechanized proof.

Rational constants, coefficients, oracle observations, and resolved historical values preserve a useful part of the payoff language.
Weighted baskets, coupon amounts, linear perpetual amounts, caps, floors, and rational barriers remain exact until the settlement boundary.
The vectors include a 5.25 percent annual coupon, a quarter-year accrual, and a principal of 1,000,000.
The resulting coupon is exactly 13,125.
They also include a weighted basket of 100.25 and a perpetual amount of 2.375 after funding.

For a finite graph, apply the node relation in topological order with all operands available.
On successful admission of every node, induction gives equality with the graph's rational real-number interpretation.
This relation assumes canonical input interpretation and the same operation order.
It supplies no approximation theorem for irrational observations, analytic primitives, or intermediate fixed-point rounding.

## Interval knowledge and guarded branches

An interval is a pair of ordered, closed rational endpoints.
It states that the exact value lies between those endpoints.
`CertifiedTrue` means every pair of represented values satisfies the comparison.
`CertifiedFalse` means every pair fails it.
`Ambiguous` means the endpoints admit both outcomes.
These three results describe evaluator knowledge. They are separate from the object's two Boolean values.

For `<`, certification requires the left upper endpoint below the right lower endpoint.
Refutation requires the left lower endpoint at or above the right upper endpoint.
The other ordered relations use their corresponding strict or inclusive endpoints.
Equality is certified only for equal singleton intervals, and refuted for disjoint intervals.
Overlapping intervals otherwise leave equality ambiguous.

The guarded branch policy is `RefineOrDefer`.
Certified knowledge selects the corresponding branch after validation of both numeric operands.
Ambiguous knowledge returns `AmbiguousGuard`, preserving the unresolved branch question.
A caller must refine its evidence or defer evaluation before supplying a certified result.
Casting interval knowledge or a numeric amount to an object Boolean is invalid.
The `guard` operation assumes that the caller obtained its certification from the stated comparison and unchanged evidence.
Binding that knowledge to an authenticated observation and graph node belongs to the integrating evaluator.

## Settlement rule

Let the exact amount be `x` and the positive settlement quantum be `q`.
The canonical rule returns integer units `u = floor(x/q)`, amount `a = u*q`, and residual `r = x-a`.
Consequently, `x = a+r` and `0 <= r < q`, including for negative amounts.
For example, `x = -1.231` and `q = 0.01` give `a = -1.24` and `r = 0.009`.
The residual rule is `RetainSeparately`. A caller must carry the residual as an explicit quantity.
This primitive neither assigns the residual to a beneficiary nor proves discharge of an obligation.

## Reproduction

Run both commands from this directory:

```sh
python3 -B run_vectors.py
python3 -O -B run_vectors.py
```

Each command runs ordinary Python, optimized Python, and Node against 122 common cases.
The runner checks every expected result and complete equality across all three backend runs.
It also checks that a deliberately incorrect result triggers its mismatch detector.
Checks use explicit exceptions and remain active under Python optimization.
The commands record runtime versions, executed commands, result counts, and source hashes in verification receipts.
The vectors cover every comparison below, at, and above a barrier beyond the binary64 exact-integer boundary.
They cover negative settlement, interval knowledge, malformed inputs, eager branches, and preallocation budget failures.
