"""Exact rational node evaluation with deterministic integer admission checks."""

from __future__ import annotations

from fractions import Fraction
import json
import re
import sys


class NumericError(Exception):
    def __init__(self, status: str):
        self.status = status
        super().__init__(status)


def reject(status: str = "InvalidInput"):
    raise NumericError(status)


class Budget:
    def __init__(self, options=None):
        if options is None:
            options = {}
        if not isinstance(options, dict) or set(options) - {"max_bits", "max_steps"}:
            reject()
        self.max_bits = options.get("max_bits", 256)
        self.max_steps = options.get("max_steps", 10000)
        for value, upper in ((self.max_bits, 4096), (self.max_steps, 1000000)):
            if type(value) not in (int, float) or not 1 <= value <= upper or int(value) != value:
                reject()
        self.max_bits, self.max_steps = int(self.max_bits), int(self.max_steps)
        high = 1 << (self.max_bits - 1)
        self.limit = high | (high - 1)
        self.limit_text = str(self.limit)
        self.steps = 0

    def charge(self):
        if self.steps >= self.max_steps:
            reject("BudgetExceeded")
        self.steps += 1

    def integer(self, text: str, positive=False):
        self.charge()
        if not isinstance(text, str):
            reject()
        if not text.isascii():
            reject()
        if len(text) > self.max_bits + 3:
            reject("BudgetExceeded")
        if re.fullmatch(r"-?(0|[1-9][0-9]*)", text) is None or text == "-0":
            reject()
        digits = text[1:] if text.startswith("-") else text
        if len(digits) > len(self.limit_text) or (
            len(digits) == len(self.limit_text) and digits > self.limit_text
        ):
            reject("BudgetExceeded")
        result = int(text)
        if positive and result <= 0:
            reject()
        return result

    def add(self, a: int, b: int):
        self.charge()
        if (a >= 0) == (b >= 0) and abs(a) > self.limit - abs(b):
            reject("BudgetExceeded")
        return a + b

    def mul(self, a: int, b: int):
        self.charge()
        if a and b and abs(a) > self.limit // abs(b):
            reject("BudgetExceeded")
        return a * b

    def gcd(self, a: int, b: int):
        a, b = abs(a), abs(b)
        while b:
            self.charge()
            a, b = b, a % b
        return a


class Rational:
    def __init__(self, n: int, d: int, budget: Budget):
        if d <= 0:
            reject()
        self.budget = budget
        common = budget.gcd(n, d)
        budget.charge()
        self.value = Fraction(n // common, d // common)

    @property
    def n(self):
        return self.value.numerator

    @property
    def d(self):
        return self.value.denominator

    def wire(self):
        return {"n": str(self.n), "d": str(self.d)}

    @classmethod
    def parse(cls, value, budget):
        if isinstance(value, dict):
            if set(value) != {"n", "d"}:
                reject()
            return cls(budget.integer(value["n"]), budget.integer(value["d"], True), budget)
        if not isinstance(value, str):
            reject()
        if not value.isascii():
            reject()
        if len(value) > budget.max_bits + 3:
            reject("BudgetExceeded")
        if re.fullmatch(r"-?(0|[1-9][0-9]*)(\.[0-9]*[1-9])?", value) is None or value == "-0":
            reject()
        if "." not in value:
            return cls(budget.integer(value), 1, budget)
        negative = value.startswith("-")
        unsigned = value[1:] if negative else value
        whole, part = unsigned.split(".")
        digits = (whole + part).lstrip("0") or "0"
        n = budget.integer(("-" if negative else "") + digits)
        d = 1
        for _ in part:
            d = budget.mul(d, 10)
        return cls(n, d, budget)

    def add(self, other, subtract=False):
        b = self.budget
        common = b.gcd(self.d, other.d)
        left, right = self.d // common, other.d // common
        n1 = b.mul(self.n, right)
        n2 = b.mul(other.n, left)
        n = b.add(n1, -n2 if subtract else n2)
        d = b.mul(left, other.d)
        return Rational(n, d, b)

    def mul(self, other):
        b = self.budget
        g1, g2 = b.gcd(self.n, other.d), b.gcd(other.n, self.d)
        n = b.mul(self.n // g1, other.n // g2)
        d = b.mul(self.d // g2, other.d // g1)
        return Rational(n, d, b)

    def compare(self, other, relation):
        if relation not in ("<", "<=", "=", ">=", ">"):
            reject()
        a = self.budget.mul(self.n, other.d)
        b = self.budget.mul(other.n, self.d)
        return {"<": a < b, "<=": a <= b, "=": a == b, ">=": a >= b, ">": a > b}[relation]


def interval_outcome(relation, a, b, budget):
    if not isinstance(a, list) or not isinstance(b, list) or len(a) != 2 or len(b) != 2:
        reject()
    lo, hi = [Rational.parse(x, budget) for x in a]
    low, high = [Rational.parse(x, budget) for x in b]
    if lo.compare(hi, ">") or low.compare(high, ">"):
        reject()
    if relation == "<":
        yes, no = hi.compare(low, "<"), lo.compare(high, ">=")
    elif relation == "<=":
        yes, no = hi.compare(low, "<="), lo.compare(high, ">")
    elif relation == ">":
        yes, no = lo.compare(high, ">"), hi.compare(low, "<=")
    elif relation == ">=":
        yes, no = lo.compare(high, ">="), hi.compare(low, "<")
    elif relation == "=":
        yes = lo.compare(hi, "=") and low.compare(high, "=") and lo.compare(low, "=")
        no = hi.compare(low, "<") or high.compare(lo, "<")
    else:
        reject()
    return "CertifiedTrue" if yes else "CertifiedFalse" if no else "Ambiguous"


def evaluate_case(case):
    if not isinstance(case, dict) or not isinstance(case.get("id"), str):
        return {"id": None, "status": "InvalidInput"}
    identifier = case["id"]
    try:
        if not isinstance(case, dict) or "op" not in case:
            reject()
        if "budget" in case and case["budget"] is None:
            reject()
        budget = Budget(case.get("budget", {}))
        parse = lambda value: Rational.parse(value, budget)
        op = case["op"]
        if op == "parse":
            value = parse(case.get("value")).wire()
        elif op in ("add", "sub", "mul", "compare", "indicator"):
            a, b = parse(case.get("a")), parse(case.get("b"))
            if op in ("add", "sub"):
                value = a.add(b, op == "sub").wire()
            elif op == "mul":
                value = a.mul(b).wire()
            else:
                result = a.compare(b, case.get("relation"))
                value = {"sort": "Bool", "value": int(result)} if op == "indicator" else result
        elif op in ("cap", "floor"):
            value, bound = parse(case.get("value")), parse(case.get("bound"))
            value = (bound if value.compare(bound, ">" if op == "cap" else "<") else value).wire()
        elif op == "lincomb":
            coefficients, values = case.get("coefficients"), case.get("values")
            if not isinstance(coefficients, list) or not isinstance(values, list):
                reject()
            if not values or len(coefficients) != len(values):
                reject()
            total = parse("0")
            for coefficient, item in zip(coefficients, values):
                total = total.add(parse(coefficient).mul(parse(item)))
            value = total.wire()
        elif op in ("ifelse", "guard"):
            if op == "ifelse":
                condition = case.get("condition")
                if not isinstance(condition, dict) or set(condition) != {"sort", "value"}:
                    reject("InvalidBool")
                if condition["sort"] != "Bool" or type(condition["value"]) not in (int, float) or condition["value"] not in (0, 1):
                    reject("InvalidBool")
                choose = condition["value"] == 1
            else:
                knowledge = case.get("knowledge")
                if knowledge == "Ambiguous":
                    reject("AmbiguousGuard")
                if knowledge not in ("CertifiedTrue", "CertifiedFalse"):
                    reject()
                choose = knowledge == "CertifiedTrue"
            positive, negative = parse(case.get("then")), parse(case.get("else"))
            value = (positive if choose else negative).wire()
        elif op == "interval":
            value = interval_outcome(case.get("relation"), case.get("a"), case.get("b"), budget)
        elif op == "settle":
            exact, quantum = parse(case.get("value")), parse(case.get("quantum"))
            if quantum.n <= 0:
                reject()
            ratio = exact.mul(Rational(quantum.d, quantum.n, budget))
            budget.charge()
            units = ratio.n // ratio.d
            amount = Rational(units, 1, budget).mul(quantum)
            residual = exact.add(amount, True)
            value = {
                "units": str(units), "amount": amount.wire(), "residual": residual.wire(),
                "rounding": "Floor", "residual_rule": "RetainSeparately",
            }
        else:
            reject()
        return {"id": identifier, "status": "Ok", "value": value}
    except NumericError as error:
        return {"id": identifier, "status": error.status}


def evaluate_document(document):
    if not isinstance(document, dict) or not isinstance(document.get("cases"), list):
        reject()
    return {"results": [evaluate_case(case) for case in document["cases"]]}


if __name__ == "__main__":
    print(json.dumps(evaluate_document(json.load(sys.stdin)), sort_keys=True))
