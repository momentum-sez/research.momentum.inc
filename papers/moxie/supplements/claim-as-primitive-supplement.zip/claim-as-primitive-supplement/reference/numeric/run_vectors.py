"""Compare exact numeric implementations against the common expected results."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def require_equal(actual, expected, label):
    if actual != expected:
        raise RuntimeError(f"{label}: expected {expected!r}, received {actual!r}")


def execute(command, payload):
    completed = subprocess.run(
        command, input=payload, text=True, capture_output=True, check=True, cwd=ROOT,
    )
    if completed.stderr:
        raise RuntimeError(f"Unexpected backend stderr: {completed.stderr}")
    return json.loads(completed.stdout)


def main():
    payload = (ROOT / "golden-vectors.json").read_text()
    cases = json.loads(payload)["cases"]
    ids = [case["id"] for case in cases]
    require_equal(len(set(ids)), len(ids), "Unique case identifiers")
    expected = {"results": [{"id": case["id"], **case["expected"]} for case in cases]}
    commands = [
        [sys.executable, "-B", "exact_numeric.py"],
        [sys.executable, "-O", "-B", "exact_numeric.py"],
        ["node", "exact_numeric.mjs"],
    ]
    outputs = [execute(command, payload) for command in commands]
    for command, output in zip(commands, outputs):
        require_equal(len(output["results"]), len(cases), f"Case count for {command}")
        for actual, wanted in zip(output["results"], expected["results"]):
            require_equal(actual, wanted, f"{command}: {wanted['id']}")
    require_equal(outputs[0], outputs[1], "Python optimization equivalence")
    require_equal(outputs[0], outputs[2], "Python and JavaScript equivalence")

    detected = False
    try:
        require_equal({"n": "9007199254740992"}, {"n": "9007199254740993"}, "Negative control")
    except RuntimeError:
        detected = True
    require_equal(detected, True, "Mismatch detection remains active")

    filenames = ["exact_numeric.py", "exact_numeric.mjs", "golden-vectors.json", "run_vectors.py", "README.md"]
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in filenames}
    summary = {
        "status": "PASS",
        "golden_cases": len(cases),
        "backend_runs": len(commands),
        "expected_result_checks": len(cases) * len(commands),
        "cross_language_equal": True,
        "python_optimized_equal": True,
        "negative_control_detected": detected,
        "runner_optimization": sys.flags.optimize,
        "python": sys.version.split()[0],
        "node": subprocess.run(["node", "--version"], capture_output=True, text=True, check=True).stdout.strip(),
        "commands": commands,
        "sha256": hashes,
    }
    receipt = ROOT / ("verification-optimized.json" if sys.flags.optimize else "verification.json")
    receipt.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
