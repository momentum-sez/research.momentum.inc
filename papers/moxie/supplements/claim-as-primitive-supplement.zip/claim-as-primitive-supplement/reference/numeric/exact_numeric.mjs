import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

class NumericError extends Error {
  constructor(status) {
    super(status);
    this.status = status;
  }
}

const fail = (status) => { throw new NumericError(status); };
const abs = (x) => x < 0n ? -x : x;
const record = (x) => x !== null && typeof x === 'object' && !Array.isArray(x);
const own = (x, key) => Object.hasOwn(x, key);
const exactKeys = (x, keys) => record(x)
  && Object.keys(x).length === keys.length && keys.every((key) => own(x, key));
const fullMatch = (pattern, value) => pattern.exec(value)?.[0] === value;
const INTEGER = /^-?(?:0|[1-9][0-9]*)$/;
const DECIMAL = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]*[1-9])?$/;
const RELATIONS = ['<', '<=', '=', '>=', '>'];

export class Budget {
  constructor(options = {}) {
    if (!record(options) || Object.keys(options).some((key) => !['max_bits', 'max_steps'].includes(key))) {
      fail('InvalidInput');
    }
    this.maxBits = own(options, 'max_bits') ? options.max_bits : 256;
    this.maxSteps = own(options, 'max_steps') ? options.max_steps : 10000;
    if (!Number.isInteger(this.maxBits) || this.maxBits < 1 || this.maxBits > 4096
      || !Number.isInteger(this.maxSteps) || this.maxSteps < 1 || this.maxSteps > 1000000) {
      fail('InvalidInput');
    }
    const high = 1n << BigInt(this.maxBits - 1);
    this.limit = high | (high - 1n);
    this.limitText = this.limit.toString();
    this.steps = 0;
  }

  charge() {
    if (this.steps >= this.maxSteps) fail('BudgetExceeded');
    this.steps += 1;
  }

  check(x) {
    if (typeof x !== 'bigint') fail('InvalidInput');
    if (abs(x) > this.limit) fail('BudgetExceeded');
    return x;
  }

  text(value) {
    if (typeof value !== 'string') fail('InvalidInput');
    if (/[^\x00-\x7F]/.test(value)) fail('InvalidInput');
    if (value.length > this.maxBits + 3) fail('BudgetExceeded');
    return value;
  }

  integer(value, positive = false) {
    this.charge();
    this.text(value);
    if (!fullMatch(INTEGER, value) || value === '-0') fail('InvalidInput');
    const magnitude = value[0] === '-' ? value.slice(1) : value;
    if (magnitude.length > this.limitText.length
      || (magnitude.length === this.limitText.length && magnitude > this.limitText)) {
      fail('BudgetExceeded');
    }
    const result = BigInt(value);
    if (positive && result <= 0n) fail('InvalidInput');
    return result;
  }

  add(a, b) {
    this.charge();
    if ((a < 0n) === (b < 0n) && abs(a) > this.limit - abs(b)) fail('BudgetExceeded');
    return a + b;
  }

  neg(a) {
    return -a;
  }

  sub(a, b) {
    return this.add(a, this.neg(b));
  }

  mul(a, b) {
    this.charge();
    if (a !== 0n && b !== 0n && abs(a) > this.limit / abs(b)) fail('BudgetExceeded');
    return a * b;
  }

  div(a, b) {
    if (b === 0n) fail('InvalidInput');
    return a / b;
  }

  remainder(a, b) {
    if (b === 0n) fail('InvalidInput');
    return a % b;
  }

  gcd(a, b) {
    let x = abs(a);
    let y = abs(b);
    while (y !== 0n) {
      this.charge();
      [x, y] = [y, x % y];
    }
    return x;
  }
}

export class Rational {
  constructor(n, d, budget) {
    budget.check(n);
    budget.check(d);
    if (d <= 0n) fail('InvalidInput');
    const g = budget.gcd(n, d);
    budget.charge();
    this.n = budget.div(n, g);
    this.d = budget.div(d, g);
    this.budget = budget;
  }

  static parse(value, budget) {
    if (record(value)) {
      if (!exactKeys(value, ['n', 'd'])) fail('InvalidInput');
      return new Rational(budget.integer(value.n), budget.integer(value.d, true), budget);
    }
    budget.text(value);
    if (!fullMatch(DECIMAL, value) || value === '-0') fail('InvalidInput');
    const negative = value[0] === '-';
    const unsigned = negative ? value.slice(1) : value;
    const [whole, fraction = ''] = unsigned.split('.');
    const digits = (whole + fraction).replace(/^0+/, '') || '0';
    const n = budget.integer(negative ? '-' + digits : digits);
    let d = 1n;
    for (let i = 0; i < fraction.length; i += 1) d = budget.mul(d, 10n);
    return new Rational(n, d, budget);
  }

  add(other, subtract = false) {
    const b = this.budget;
    const g = b.gcd(this.d, other.d);
    const u = b.div(this.d, g);
    const v = b.div(other.d, g);
    const left = b.mul(this.n, v);
    const right = b.mul(other.n, u);
    const n = subtract ? b.sub(left, right) : b.add(left, right);
    return new Rational(n, b.mul(u, other.d), b);
  }

  sub(other) {
    return this.add(other, true);
  }

  mul(other) {
    const b = this.budget;
    const g = b.gcd(this.n, other.d);
    const h = b.gcd(other.n, this.d);
    const n = b.mul(b.div(this.n, g), b.div(other.n, h));
    const d = b.mul(b.div(this.d, h), b.div(other.d, g));
    return new Rational(n, d, b);
  }

  compare(other, relation) {
    if (!RELATIONS.includes(relation)) fail('InvalidInput');
    const b = this.budget;
    const left = b.mul(this.n, other.d);
    const right = b.mul(other.n, this.d);
    switch (relation) {
      case '<': return left < right;
      case '<=': return left <= right;
      case '=': return left === right;
      case '>=': return left >= right;
      case '>': return left > right;
    }
  }

  wire() {
    return { n: this.n.toString(), d: this.d.toString() };
  }
}

function certify(a, b, relation, budget) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== 2 || b.length !== 2) fail('InvalidInput');
  const [al, ah] = a.map((value) => Rational.parse(value, budget));
  const [bl, bh] = b.map((value) => Rational.parse(value, budget));
  if (al.compare(ah, '>') || bl.compare(bh, '>')) fail('InvalidInput');
  let yes;
  let no;
  switch (relation) {
    case '<':
      yes = ah.compare(bl, '<');
      no = al.compare(bh, '>=');
      break;
    case '<=':
      yes = ah.compare(bl, '<=');
      no = al.compare(bh, '>');
      break;
    case '>':
      yes = al.compare(bh, '>');
      no = ah.compare(bl, '<=');
      break;
    case '>=':
      yes = al.compare(bh, '>=');
      no = ah.compare(bl, '<');
      break;
    case '=':
      yes = al.compare(ah, '=') && bl.compare(bh, '=') && al.compare(bl, '=');
      no = ah.compare(bl, '<') || bh.compare(al, '<');
      break;
    default: fail('InvalidInput');
  }
  return yes ? 'CertifiedTrue' : no ? 'CertifiedFalse' : 'Ambiguous';
}

function evaluate(test, budget) {
  const parse = (value) => Rational.parse(value, budget);
  switch (test.op) {
    case 'parse': return parse(test.value).wire();
    case 'add': return parse(test.a).add(parse(test.b)).wire();
    case 'sub': return parse(test.a).sub(parse(test.b)).wire();
    case 'mul': return parse(test.a).mul(parse(test.b)).wire();
    case 'compare': return parse(test.a).compare(parse(test.b), test.relation);
    case 'indicator':
      return { sort: 'Bool', value: parse(test.a).compare(parse(test.b), test.relation) ? 1 : 0 };
    case 'cap': {
      const value = parse(test.value);
      const bound = parse(test.bound);
      return (value.compare(bound, '<=') ? value : bound).wire();
    }
    case 'floor': {
      const value = parse(test.value);
      const bound = parse(test.bound);
      return (value.compare(bound, '>=') ? value : bound).wire();
    }
    case 'lincomb': {
      if (!Array.isArray(test.coefficients) || !Array.isArray(test.values)
        || test.coefficients.length === 0 || test.coefficients.length !== test.values.length) fail('InvalidInput');
      let sum = parse('0');
      for (let i = 0; i < test.values.length; i += 1) {
        sum = sum.add(parse(test.coefficients[i]).mul(parse(test.values[i])));
      }
      return sum.wire();
    }
    case 'interval': return certify(test.a, test.b, test.relation, budget);
    case 'ifelse': {
      const condition = test.condition;
      if (!exactKeys(condition, ['sort', 'value']) || condition.sort !== 'Bool'
        || typeof condition.value !== 'number' || (condition.value !== 0 && condition.value !== 1)) fail('InvalidBool');
      const yes = parse(test.then);
      const no = parse(test.else);
      return (condition.value === 1 ? yes : no).wire();
    }
    case 'guard': {
      if (test.knowledge === 'Ambiguous') fail('AmbiguousGuard');
      if (!['CertifiedTrue', 'CertifiedFalse'].includes(test.knowledge)) fail('InvalidInput');
      const yes = parse(test.then);
      const no = parse(test.else);
      return (test.knowledge === 'CertifiedTrue' ? yes : no).wire();
    }
    case 'settle': {
      const value = parse(test.value);
      const quantum = parse(test.quantum);
      if (quantum.n <= 0n) fail('InvalidInput');
      const ratio = value.mul(new Rational(quantum.d, quantum.n, budget));
      budget.charge();
      let units = budget.div(ratio.n, ratio.d);
      if (ratio.n < 0n && budget.remainder(ratio.n, ratio.d) !== 0n) units -= 1n;
      const amount = new Rational(units, 1n, budget).mul(quantum);
      return {
        units: units.toString(), amount: amount.wire(), residual: value.sub(amount).wire(),
        rounding: 'Floor', residual_rule: 'RetainSeparately',
      };
    }
    default: fail('InvalidInput');
  }
}

export function evaluateCase(test) {
  if (!record(test) || !own(test, 'id') || typeof test.id !== 'string') {
    return { id: null, status: 'InvalidInput' };
  }
  const id = test.id;
  try {
    const budget = new Budget(own(test, 'budget') ? test.budget : {});
    return { id, status: 'Ok', value: evaluate(test, budget) };
  } catch (error) {
    if (!(error instanceof NumericError)) throw error;
    return { id, status: error.status };
  }
}

export function evaluateDocument(document) {
  if (!record(document) || !Array.isArray(document.cases)) fail('InvalidInput');
  return { results: document.cases.map(evaluateCase) };
}

// JSON transport allocation has a separate boundary from the numeric budget.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const document = JSON.parse(readFileSync(0, 'utf8'));
  process.stdout.write(JSON.stringify(evaluateDocument(document)) + '\n');
}
