"""Execute the two declared programs and emit their observed results."""

from programs import *


def examples():
    coupon = Evaluator(coupon_program())
    for h in (2, 3, 4, 5): coupon.request("coupon", h, context_id=CONTEXT)
    coupon.request("memory", 5, context_id=CONTEXT)
    coupon.request("independent", 5, context_id=CONTEXT)
    for h in (2, 3): coupon.offer(observation("trigger", h, 0), context_id=CONTEXT)
    before = coupon.run(now=5, context_id=CONTEXT)
    ready_before = coupon.resolutions[("independent", 5)]["value"].number.lower
    for h in (4, 5): coupon.offer(observation("trigger", h, 1), context_id=CONTEXT)
    after = coupon.run(now=5, context_id=CONTEXT)
    dues = sorted(coupon.ledger.dues(), key=lambda d: d.origin.core.height)
    occurrence = ent.OccurrenceKey("example-provider", "credit", "coupon-payment-35")
    credit = ent.Credit(occurrence, "holder", "USD", F(35), "example-credit-evidence")
    coupon.ledger.record_credit(ent.CreditReport("example-credit-report", occurrence, credit, "provider", "coupons"))
    coupon.ledger.allocate("coupon-payment-30", occurrence, dues[0].origin, 30, "example-route-authority")
    coupon.ledger.allocate("coupon-payment-5", occurrence, dues[1].origin, 5, "example-route-authority")
    program, fx, witness = multicurrency_program()
    window = Evaluator(program)
    window.request("signed-window", 6, context_id=CONTEXT)
    for h, v in ((1, 100), (5, 80)):
        window.offer(observation("euro-observation", h, v, ft.Theta(EUR)), context_id=CONTEXT)
    window_before = window.run(now=6, context_id=CONTEXT)
    window.offer(observation("euro-observation", 3, 120, ft.Theta(EUR)), context_id=CONTEXT)
    window.offer(fx, context_id=CONTEXT)
    window.offer_witness("signed-window", 6, witness, context_id=CONTEXT)
    window_after = window.run(now=6, context_id=CONTEXT)
    v = window.resolutions[("signed-window", 6)]["value"]
    due = window.ledger.dues()[0]
    return {
        "coupon": {
            "program_digest": coupon.program.identity,
            "before_evidence_status": before["status"],
            "independent_ready_value": str(ready_before),
            "after_evidence_status": after["status"],
            "memory": [str(coupon.resolutions[("memory", h)]["value"].number.lower) for h in (1, 2, 3, 4, 5)],
            "coupon_values": [str(coupon.resolutions[("coupon", h)]["value"].number.lower) for h in (2, 3, 4, 5)],
            "created_dues": [str(d.amount) for d in dues],
            "outstanding_after_35_payment": [str(coupon.ledger.outstanding(d.origin)) for d in dues],
            "work": after["work"], "number_bits": after["number_bits"],
            "every_cached_node_executed_once": all(n == 1 for n in coupon.execution_counts.values()),
        },
        "signed_window": {
            "program_digest": program.identity,
            "missing_selected_sample_status": window_before["status"],
            "completed_status": window_after["status"],
            "represented_usd_cents": str(v.number.lower), "physical_scale": str(v.theta.scale),
            "canonical_asset": due.asset, "canonical_amount": str(due.amount),
            "debtor": due.debtor, "creditor": due.creditor,
            "selected_source_heights": sorted(r.height for r in v.history),
            "retained_evidence_count": len(v.evidence),
            "conversion_witness": next(iter(v.witnesses)).name,
            "work": window_after["work"], "number_bits": window_after["number_bits"],
        },
        "execution_scope": "Actual common evaluator and admitted synthetic evidence. No provider dispatch or distributed adapter.",
    }


if __name__ == "__main__":
    print(json.dumps(examples(), sort_keys=True, indent=2))
