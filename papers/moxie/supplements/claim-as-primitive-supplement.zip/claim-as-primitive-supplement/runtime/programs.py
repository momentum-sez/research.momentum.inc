"""Two financial programs declared entirely through the common payoff AST."""

from evaluator import *

CONTEXT = "rules:coupon-and-fx:2026-09-05"
USD = ft.Group.atom("USD")
EUR = ft.Group.atom("EUR")


def finite(*heights):
    return sched.Descriptor(max(heights) + 1, 1, frozenset(heights))


def literal(name, value, theta=ft.NEUTRAL):
    return ft.Declaration(name, F(value), theta)


def observation(source, height, amount, theta=ft.NEUTRAL, *, rate=False, upper=None, identity=None):
    declaration = ft.Declaration(identity or f"{source}:{height}", F(amount), theta,
                     role="observed_rate" if rate else "input", source=source,
                     height=height, authority="feed", conversion_rate=rate)
    return Observation(declaration, CONTEXT, None if upper is None else F(upper))


def position(issuance, asset="USD", quantity=1):
    return Position(issuance, "lot:1", "payoff", F(quantity), "issuer", "holder", asset,
                    "governing-route:retained-residual", "position:issued", "terms:issued")


def coupon_program(envelope=Envelope()):
    """Predeclare the paper's initialized infinite memory-coupon family."""
    seed = finite(1)
    tail = sched.Descriptor(2, 1, R=frozenset((0,)))
    whole = sched.Descriptor(1, 1, R=frozenset((0,)))
    numeric = (literal("zero", 0), literal("one", 1))
    trigger = Ind(">=", Oracle("trigger"), Const("one"))
    count = LinComb(((Const("one"), Const("one")), (Const("one"), Ref("memory", 1))))
    memory = Claim("memory", whole,
        (Case(seed, Const("zero")), Case(tail, IfElse(trigger, Const("zero"), count))),
        ft.NEUTRAL, numeric)
    money = ft.Theta(USD, F(1), INSTANCE_DUE)
    coupons = Claim("coupon", tail,
        (Case(tail, IfElse(trigger, Mul(Const("coupon"), count), Const("zero-money"))),),
        money, numeric + (literal("coupon", 10, money), literal("zero-money", 0, money)),
        (position("coupon-issuance"),))
    ready = Claim("independent", finite(5), (Case(finite(5), Const("one")),), ft.NEUTRAL, numeric)
    return Program((memory, coupons, ready), (OracleContract("trigger", ft.NEUTRAL, "feed"),), CONTEXT, envelope)


def multicurrency_program(envelope=Envelope()):
    """A signed EUR window payoff, converted to a dated USD entitlement."""
    history = finite(1, 3, 5)
    date = finite(6)
    eur = ft.Theta(EUR)
    euro_cents = ft.Theta(EUR, F(1, 100))
    usd_cents_due = ft.Theta(USD, F(1, 100), ft.due(6))
    rate_type = ft.Theta(USD / EUR, F(1), ft.due(6))
    values = (literal("one", 1), literal("minus-one", -1), literal("minus-three", -3),
              literal("strike", 90, eur), literal("lower", -50, eur), literal("upper", 20, eur),
              literal("zero", 0, eur), literal("barrier", 70, eur))
    spot = Claim("spot-eur", history, (Case(history, Oracle("euro-observation")),), eur)
    difference = LinComb(((Const("one"), Window("spot-eur", 5, "Avg")),
                          (Const("minus-one"), Const("strike"))))
    signed = Mul(Const("minus-three"), difference)
    bounded = Cap(Floor(signed, Const("lower")), Const("upper"))
    condition = Ind(">=", Window("spot-eur", 5, "Min"), Const("barrier"))
    foreign = IfElse(condition, bounded, Const("zero"))
    expression = Convert(Rescale(foreign, F(1, 100)), "EURUSD", usd_cents_due, "valuation:6")
    payoff = Claim("signed-window", date, (Case(date, expression),), usd_cents_due, values,
                   (position("window-issuance"),))
    program = Program((spot, payoff),
        (OracleContract("euro-observation", eur, "feed"), OracleContract("EURUSD", rate_type, "feed", True)),
        CONTEXT, envelope)
    fx = observation("EURUSD", 6, F(5, 4), rate_type, rate=True)
    witness = ft.Witness("valuation:6", euro_cents, usd_cents_due, fx.declaration,
                        ft.Use(6, "runtime", "claims", "resolution"))
    return program, fx, witness
