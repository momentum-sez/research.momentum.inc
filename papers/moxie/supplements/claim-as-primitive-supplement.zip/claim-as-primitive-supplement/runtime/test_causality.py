import dataclasses as dc
import tempfile
import unittest
from pathlib import Path

from evaluator import *
from causality import Manifest, Producer, Read, Cycle
from programs import CONTEXT, finite, literal, observation, position
from durable_evaluator import DurableEvaluator


def cash_program(*, feedback=False, envelope=Envelope(), contract="fixture:account-authority"):
    date = finite(3)
    money = ft.Theta(ft.Group.atom("USD"), F(1), INSTANCE_DUE)
    gross = Claim("z-gross", date, (Case(date, Oracle("cash")),), money)
    fee = Claim("y-fee", date, (Case(date, Mul(Const("rate"), Ref("z-gross", 0, "amount"))),),
                money, (literal("rate", F(1, 10)),), (position("fee"),))
    net = Claim("a-net", date,
        (Case(date, LinComb(((Const("one"), Ref("z-gross", 0, "amount")),
                             (Const("minus"), Ref("y-fee", 0, "amount"))))),),
        money, (literal("one", 1), literal("minus", -1)), (position("net"),))
    reads = (Read("clearing"),) if feedback else ()
    extra = (Producer("clearing", "clearing", "fixture:clearing", "fixture:venue",
                      (Read("risk"),), date),
             Producer("risk", "risk", "fixture:risk", "fixture:risk-owner",
                      (Read("claim:a-net"),), date)) if feedback else ()
    manifest = Manifest((Producer("cash-input", "oracle" if feedback else "external", "fixture:cash-source",
        contract, reads, date,
        "fixture:balance-fixed-before-event" if not feedback else ""),) + extra, (("cash", "cash-input"),))
    return Program((net, fee, gross), (OracleContract("cash", money, "feed"),), CONTEXT,
                   envelope, producer_manifest=manifest)


class CausalityTests(unittest.TestCase):
    def test_same_event_fee_and_net_execute_once_in_rank_order(self):
        e = Evaluator(cash_program())
        e.request("a-net", 3, context_id=CONTEXT)
        d = observation("cash", 3, 100, at(e.program.oracles["cash"].theta, 3))
        e.offer(e.bind_observation(d), context_id=CONTEXT)
        result = e.run(now=3, context_id=CONTEXT)
        self.assertEqual(result["status"], "Resolved")
        self.assertEqual(e.resolutions[("a-net", 3)]["value"].number.lower, F(90))
        self.assertEqual(e.resolutions[("y-fee", 3)]["value"].number.lower, F(10))
        self.assertEqual(sum(x.amount for x in e.ledger._dues.values()), F(100))
        self.assertTrue(all(n == 1 for n in e.execution_counts.values()))
        before = dict(e.execution_counts)
        e.run(now=3, context_id=CONTEXT)
        self.assertEqual(before, e.execution_counts)
        history = e.resolutions[("a-net", 3)]["value"].history
        self.assertEqual({x.claim for x in history}, {"z-gross", "y-fee"})

    def test_hidden_oracle_clearing_cycle_has_closed_witness(self):
        with self.assertRaises(Cycle) as raised:
            cash_program(feedback=True)
        cycle = raised.exception
        self.assertEqual(cycle.height, 3)
        self.assertEqual(cycle.path[0], cycle.path[-1])
        self.assertIn("cash-input", cycle.path)
        self.assertIn("clearing", cycle.path)
        self.assertIn("risk", cycle.path)
        self.assertIn("claim:a-net", cycle.path)

    def test_two_claim_zero_delay_cycle_is_rejected(self):
        d = finite(3)
        claims = tuple(Claim(a, d, (Case(d, Ref(b, 0)),), ft.NEUTRAL)
                       for a, b in (("A", "B"), ("B", "A")))
        with self.assertRaises(Cycle):
            Program(claims, (), CONTEXT, producer_manifest=Manifest((), ()))

    def test_legacy_admission_still_requires_historical_refs(self):
        d = finite(3)
        a = Claim("A", d, (Case(d, Const("one")),), ft.NEUTRAL, (literal("one", 1),))
        b = Claim("B", d, (Case(d, Ref("A", 0)),), ft.NEUTRAL)
        with self.assertRaises(sched.Invalid):
            Program((a, b), (), CONTEXT)

    def test_periodic_cases_can_reverse_same_event_order(self):
        all_dates = sched.Descriptor(1, 1, R=frozenset((0,)))
        odd = sched.Descriptor(1, 2, R=frozenset((1,)))
        even = sched.Descriptor(1, 2, R=frozenset((0,)))
        a = Claim("A", all_dates, (Case(odd, Const("one")), Case(even, Ref("B", 0))),
                  ft.NEUTRAL, (literal("one", 1),))
        b = Claim("B", all_dates, (Case(odd, Ref("A", 0)), Case(even, Const("two"))),
                  ft.NEUTRAL, (literal("two", 2),))
        p = Program((a, b), (), CONTEXT, producer_manifest=Manifest((), ()))
        e = Evaluator(p)
        for h in (5, 6):
            for name in ("A", "B"):
                e.request(name, h, context_id=CONTEXT)
        self.assertEqual(e.run(now=6, context_id=CONTEXT)["status"], "Resolved")
        for name in ("A", "B"):
            self.assertEqual(e.resolutions[(name, 5)]["value"].number.lower, 1)
            self.assertEqual(e.resolutions[(name, 6)]["value"].number.lower, 2)

    def test_missing_source_binding_fails_before_evaluation(self):
        p = cash_program()
        with self.assertRaises(sched.Invalid):
            Program((), tuple(p.oracles.values()), CONTEXT, producer_manifest=Manifest((), ()))

    def test_uncontracted_opaque_root_is_rejected(self):
        p = Producer("root", "external", "fixture", "fixture")
        with self.assertRaises(sched.Invalid):
            Program((), (), CONTEXT, producer_manifest=Manifest((p,), ()))
        with self.assertRaises(sched.Invalid):
            Program((), (), CONTEXT, producer_manifest=Manifest((dc.replace(p, root_contract=7),), ()))

    def test_wrong_causal_binding_and_value_substitution_fail(self):
        e = Evaluator(cash_program())
        d = observation("cash", 3, 100, at(e.program.oracles["cash"].theta, 3))
        with self.assertRaisesRegex(Invalid, "CausalObservationBindingMismatch"):
            e.offer(d, context_id=CONTEXT)
        bound = e.bind_observation(d)
        changed = dc.replace(bound, declaration=dc.replace(bound.declaration, value=F(200)))
        with self.assertRaisesRegex(Invalid, "CausalObservationBindingMismatch"):
            e.offer(changed, context_id=CONTEXT)
        e.offer(bound, context_id=CONTEXT)

    def test_settlement_derived_observation_waits_for_its_actual_claim(self):
        d = finite(3)
        money = ft.Theta(ft.Group.atom("USD"), F(1), INSTANCE_DUE)
        amount = Claim("amount", d, (Case(d, Const("ten")),), money,
                       (literal("ten", 10, money),), (position("principal"),))
        recovered = Claim("recovered", d, (Case(d, Oracle("received")),), money)
        m = Manifest((Producer("receipt", "settlement", "fixture:provider-adapter",
                     "fixture:receipt-authority", (Read("claim:amount"), Read("bank-credit")), d),
                     Producer("bank-credit", "external", "fixture:bank-ledger", "fixture:bank-authority",
                              (), d, "fixture:independent-posted-credit")),
                     (("received", "receipt"), ("credit-fact", "bank-credit")))
        p = Program((recovered, amount), tuple(OracleContract(s, money, "feed") for s in ("received", "credit-fact")),
                    CONTEXT, producer_manifest=m)
        e = Evaluator(p)
        event = observation("received", 3, 7, at(money, 3))
        with self.assertRaisesRegex(Invalid, "AwaitProducerClaims"):
            e.bind_observation(event)
        e.request("recovered", 3, context_id=CONTEXT)
        self.assertEqual(e.run(now=3, context_id=CONTEXT)["status"], "Pending")
        self.assertIn(("amount", 3), e.resolutions)
        due = e.ledger.dues()[0]
        occurrence = ent.OccurrenceKey("synthetic-provider", "credit", "partial-seven")
        credit = ent.Credit(occurrence, "holder", "USD", F(7), "booking:partial-seven")
        report = ent.CreditReport("assertion:partial-seven", occurrence, credit,
                                  "synthetic-provider", "synthetic-route")
        e.ledger.record_credit(report)
        e.ledger.allocate("allocation:partial-seven", occurrence, due.origin, F(7), "synthetic-route")
        self.assertEqual(e.ledger.outstanding(due.origin), F(3))
        e.offer(e.bind_observation(observation("credit-fact", 3, 7, at(money, 3))), context_id=CONTEXT)
        bound = e.bind_observation(event)
        self.assertEqual(bound.causal_binding[-1][0][-1], e.resolutions[("amount", 3)]["identity"])
        e.offer(bound, context_id=CONTEXT)
        self.assertEqual(e.run(now=3, context_id=CONTEXT)["status"], "Resolved")
        self.assertEqual(e.resolutions[("recovered", 3)]["value"].number.lower, 7)
        self.assertEqual(e.ledger.outstanding(due.origin), F(3))

    def test_causal_program_identity_binds_contract_and_profile(self):
        p = cash_program()
        q = cash_program(contract="fixture:replacement-authority")
        self.assertNotEqual(p.identity, q.identity)
        self.assertNotEqual(p.causality.identity, q.causality.identity)
        e, other = Evaluator(p), Evaluator(q)
        bound = e.bind_observation(observation("cash", 3, 100, at(p.oracles["cash"].theta, 3)))
        with self.assertRaisesRegex(Invalid, "CausalObservationBindingMismatch"):
            other.offer(bound, context_id=CONTEXT)

    def test_off_schedule_self_dependency_cannot_start_a_frontier(self):
        empty = sched.Descriptor(1, 1)
        producer = Producer("absent", "oracle", "fixture", "fixture",
                            (Read("absent", 1),), empty)
        p = Program((), (OracleContract("absent", ft.NEUTRAL, "feed"),), CONTEXT,
                    producer_manifest=Manifest((producer,), (("absent", "absent"),)))
        e = Evaluator(p)
        with self.assertRaisesRegex(sched.Invalid, "Unscheduled oracle producer"):
            e.bind_observation(observation("absent", 1, 1))

    def test_mapped_oracle_predecessor_is_required_and_bound(self):
        d = finite(3)
        producers = (Producer("base", "external", "fixture:base", "fixture", (), d, "fixture:independent"),
                     Producer("derived", "risk", "fixture:risk", "fixture", (Read("base"),), d))
        oracles = tuple(OracleContract(name, ft.NEUTRAL, "feed") for name in ("X", "Y"))
        p = Program((), oracles, CONTEXT,
                    producer_manifest=Manifest(producers, (("X", "base"), ("Y", "derived"))))
        e = Evaluator(p)
        y = observation("Y", 3, 2)
        with self.assertRaisesRegex(Invalid, "AwaitProducerObservations"):
            e.bind_observation(y)
        x = e.bind_observation(observation("X", 3, 1))
        e.offer(x, context_id=CONTEXT)
        y = e.bind_observation(y)
        self.assertEqual(y.causal_binding[-2], (("X", 3, digest(x)),))
        e.offer(y, context_id=CONTEXT)

    def test_full_durable_wrapper_restores_same_event_programme(self):
        p = cash_program()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "causal.sqlite"
            key = b"causal-durable-key-at-least-32-bytes"
            store = DurableEvaluator(path, key)
            store.create("cash", p)
            def apply(identity, method, *args, **kwargs):
                return store.apply(store.handle("cash", p), p, identity, "evaluator", method, *args, **kwargs)
            apply("request", "request", "a-net", 3, context_id=CONTEXT)
            plain = observation("cash", 3, 100, at(p.oracles["cash"].theta, 3))
            bound = Evaluator(p).bind_observation(plain)
            apply("offer", "offer", bound, context_id=CONTEXT)
            result = apply("run", "run", now=3, context_id=CONTEXT)
            self.assertEqual(result["outcome"]["value"]["status"], "Resolved")
            reopened = DurableEvaluator(path, key)
            snapshot = reopened.read("cash", p)
            self.assertEqual(snapshot["continuation"]["resolutions"][("a-net", 3)]["value"].number.lower, 90)

    def test_checkpoint_retains_same_event_resolution_provenance(self):
        e = Evaluator(cash_program())
        e.request("a-net", 3, context_id=CONTEXT)
        obs = observation("cash", 3, 100, at(e.program.oracles["cash"].theta, 3))
        e.offer(e.bind_observation(obs), context_id=CONTEXT)
        e.run(now=3, context_id=CONTEXT)
        key = b"causal-checkpoint-key-32-bytes-long"
        copy = Evaluator.restore(e.program, e.checkpoint(key), key, ledger=e.ledger, journal=e.journal,
                                 context_id=CONTEXT)
        self.assertEqual(copy.resolutions, e.resolutions)
        self.assertEqual(copy.observations, e.observations)


if __name__ == "__main__":
    unittest.main()
