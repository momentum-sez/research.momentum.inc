"""Exercise actual programs, resumption, numerical bounds, and ledger effects."""

import dataclasses as dc
import hashlib
import json
import unittest
import threading
from programs import *

KEY = b"synthetic-checkpoint-key-0000000000000000"


def run(evaluator, now, **kwargs):
    return evaluator.run(now=now, context_id=CONTEXT, **kwargs)


def ask(evaluator, name, height):
    evaluator.request(name, height, context_id=CONTEXT)


def offer(evaluator, record):
    evaluator.offer(record, context_id=CONTEXT)


def amount(evaluator, name, height):
    return evaluator.resolutions[(name, height)]["value"].number.lower


def single(expression, declarations, output=ft.NEUTRAL, positions=(), envelope=Envelope()):
    h = finite(2)
    return Program((Claim("one", h, (Case(h, expression),), output, declarations, positions, deadline_delay=1),), (), CONTEXT, envelope)


class CompleteEvaluatorTests(unittest.TestCase):
    def test_actual_infinite_coupon_program_and_unpaid_residual(self):
        program = coupon_program()
        evaluator = Evaluator(program)
        for h in (2, 3, 4, 5): ask(evaluator, "coupon", h)
        ask(evaluator, "memory", 5)
        ask(evaluator, "independent", 5)
        offer(evaluator, observation("trigger", 2, 0))
        offer(evaluator, observation("trigger", 3, 0))
        report = run(evaluator, 5)
        self.assertEqual(report["status"], "Pending")
        self.assertEqual(amount(evaluator, "independent", 5), 1)
        self.assertEqual(amount(evaluator, "memory", 3), 2)
        self.assertNotIn(("coupon", 4), evaluator.resolutions)
        counts = dict(evaluator.execution_counts)
        work = evaluator.meter.steps
        saved = evaluator.checkpoint(KEY)
        evaluator = Evaluator.restore(program, saved, KEY, evaluator.ledger, context_id=CONTEXT, journal=evaluator.journal)
        self.assertEqual(evaluator.meter.steps, work)
        self.assertEqual(evaluator.execution_counts, counts)
        offer(evaluator, observation("trigger", 4, 1))
        offer(evaluator, observation("trigger", 5, 1))
        self.assertEqual(run(evaluator, 5)["status"], "Resolved")
        self.assertEqual([amount(evaluator, "coupon", h) for h in (2, 3, 4, 5)], [0, 0, 30, 10])
        self.assertEqual([amount(evaluator, "memory", h) for h in (1, 2, 3, 4, 5)], [0, 1, 2, 0, 0])
        self.assertTrue(all(c == 1 for c in evaluator.execution_counts.values()))
        ledger = evaluator.ledger
        dues = sorted(ledger.dues(), key=lambda d: d.origin.core.height)
        self.assertEqual([d.amount for d in dues], [30, 10])
        occurrence = ent.OccurrenceKey("provider", "credit", "35")
        credit = ent.Credit(occurrence, "holder", "USD", F(35), "provider-booking")
        ledger.record_credit(ent.CreditReport("report:35", occurrence, credit, "provider", "coupon"))
        ledger.allocate("allocation:30", occurrence, dues[0].origin, 30, "route-authority")
        ledger.allocate("allocation:5", occurrence, dues[1].origin, 5, "route-authority")
        before = evaluator.checkpoint(KEY)
        evaluator = Evaluator.restore(program, before, KEY, ledger, context_id=CONTEXT, journal=evaluator.journal)
        ask(evaluator, "coupon", 5)
        run(evaluator, 5)
        self.assertEqual(len(ledger.dues()), 2)
        self.assertEqual(ledger.outstanding(dues[1].origin), 5)
        self.assertEqual(ledger._memory["memory"], 0)

    def test_actual_signed_multicurrency_sparse_window(self):
        program, fx, witness = multicurrency_program()
        evaluator = Evaluator(program)
        ask(evaluator, "signed-window", 6)
        eur = ft.Theta(EUR)
        for h, v in ((1, 100), (5, 80)):
            offer(evaluator, observation("euro-observation", h, v, eur))
        self.assertEqual(run(evaluator, 6)["status"], "Pending")
        self.assertNotIn(("signed-window", 6), evaluator.resolutions)
        self.assertEqual(set(evaluator.resolutions), {("spot-eur", 1), ("spot-eur", 5)})
        offer(evaluator, observation("euro-observation", 3, 120, eur))
        offer(evaluator, fx)
        run(evaluator, 6)
        self.assertNotIn(("signed-window", 6), evaluator.resolutions)
        evaluator.offer_witness("signed-window", 6, witness, context_id=CONTEXT)
        self.assertEqual(run(evaluator, 6)["status"], "Resolved")
        value = evaluator.resolutions[("signed-window", 6)]["value"]
        self.assertEqual(value.number.lower, -3750)
        self.assertEqual(value.theta.scale, F(1, 100))
        self.assertEqual({r.height for r in value.history}, {1, 3, 5})
        self.assertEqual({e.declaration.name if isinstance(e, Observation) else e.name for e in value.evidence},
            {"one", "minus-one", "minus-three", "strike", "lower", "upper", "zero", "barrier",
             "euro-observation:1", "euro-observation:3", "euro-observation:5", "EURUSD:6"})
        self.assertEqual(value.witnesses, frozenset((witness,)))
        due = evaluator.ledger.dues()[0]
        self.assertEqual((due.debtor, due.creditor, due.asset, due.amount), ("holder", "issuer", "USD", F(75, 2)))

    def test_all_exact_operators_match_existing_financial_checker(self):
        declarations = tuple(literal(k, v) for k, v in (("a", -3), ("b", 2), ("one", 1), ("zero", 0), ("upper", 5)))
        for relation in ("<", "<=", "=", ">=", ">"):
            shared = Mul(Const("a"), Const("b"))
            expression = Rescale(IfElse(Ind(relation, Const("a"), Const("b")),
                Floor(Cap(shared, Const("upper")), Const("a")),
                LinComb(((Const("one"), shared), (Const("zero"), Const("upper"))))), F(1, 10))
            output = ft.Theta(scale=F(1, 10))
            program = single(expression, declarations, output)
            evaluator = Evaluator(program)
            ask(evaluator, "one", 2)
            run(evaluator, 2)
            checker = ft.Checker(ft.Manifest({d.name: d for d in declarations}, {}), ft.Use(2, "runtime", "claims", "resolution"))
            expected = checker.evaluate(expression)
            self.assertEqual(amount(evaluator, "one", 2), expected.value)
            self.assertEqual(evaluator.resolutions[("one", 2)]["value"].theta, expected.theta)
            self.assertTrue(all(c == 1 for c in evaluator.execution_counts.values()))

    def test_every_window_reduction_uses_scheduled_samples(self):
        history = finite(1, 3)
        end = finite(4)
        spot = Claim("samples", history, (Case(history, Oracle("x")),), ft.NEUTRAL)
        claims = [spot]
        for reduction in ("Min", "Max", "Sum", "Avg"):
            claims.append(Claim(reduction, end, (Case(end, Window("samples", 3, reduction)),), ft.NEUTRAL))
        evaluator = Evaluator(Program(tuple(claims), (OracleContract("x", ft.NEUTRAL, "feed"),), CONTEXT))
        for reduction in ("Min", "Max", "Sum", "Avg"): ask(evaluator, reduction, 4)
        offer(evaluator, observation("x", 1, F(1, 3)))
        offer(evaluator, observation("x", 3, F(2, 3)))
        self.assertEqual(run(evaluator, 4)["status"], "Resolved")
        self.assertEqual([amount(evaluator, r, 4) for r in ("Min", "Max", "Sum", "Avg")], [F(1, 3), F(2, 3), 1, F(1, 2)])

    def test_ambiguous_indicator_refines_without_false_branch(self):
        h = finite(2)
        declarations = tuple(literal(n, x) for n, x in (("zero", 0), ("one", 1), ("hundred", 100)))
        expression = IfElse(Ind(">=", Oracle("x"), Const("zero")), Const("hundred"), Const("one"))
        claim = Claim("digital", h, (Case(h, expression),), ft.NEUTRAL, declarations)
        evaluator = Evaluator(Program((claim,), (OracleContract("x", ft.NEUTRAL, "feed"),), CONTEXT))
        ask(evaluator, "digital", 2)
        offer(evaluator, observation("x", 2, -1, upper=1, identity="range"))
        run(evaluator, 2)
        self.assertNotIn(("digital", 2), evaluator.resolutions)
        self.assertIn("AmbiguousGuard", evaluator.tasks[("digital", 2)]["blocked"].values())
        offer(evaluator, observation("x", 2, 0, identity="exact"))
        run(evaluator, 2)
        self.assertEqual(amount(evaluator, "digital", 2), 100)

    def test_both_branches_and_zero_coefficients_retain_missing_evidence(self):
        h = finite(2)
        declarations = tuple(literal(n, v) for n, v in (("zero", 0), ("one", 1)))
        dead = LinComb(((Const("zero"), Oracle("missing")),))
        expression = IfElse(Ind("=", Const("one"), Const("one")), Const("one"), dead)
        c = Claim("all-evidence", h, (Case(h, expression),), ft.NEUTRAL, declarations, deadline_delay=0)
        evaluator = Evaluator(Program((c,), (OracleContract("missing", ft.NEUTRAL, "feed"),), CONTEXT))
        ask(evaluator, "all-evidence", 2)
        report = run(evaluator, 2)
        self.assertEqual(report["pending"][("all-evidence", 2)]["action"], "retain-and-recover")
        self.assertNotIn(("all-evidence", 2), evaluator.resolutions)
        offer(evaluator, observation("missing", 2, 7))
        run(evaluator, 2)
        value = evaluator.resolutions[("all-evidence", 2)]["value"]
        self.assertEqual(value.number.lower, 1)
        self.assertTrue(any(isinstance(e, Observation) and e.declaration.source == "missing" for e in value.evidence))

    def test_budget_suspension_keeps_work_and_completed_nodes(self):
        x = Const("two-thirds")
        for _ in range(5): x = Mul(x, x)
        declarations = (literal("two-thirds", F(2, 3)),)
        program = single(x, declarations)
        evaluator = Evaluator(program, envelope=Envelope(max_bits=16))
        ask(evaluator, "one", 2)
        run(evaluator, 2)
        self.assertNotIn(("one", 2), evaluator.resolutions)
        counts, work, bits = dict(evaluator.execution_counts), evaluator.meter.steps, evaluator.meter.number_bits
        self.assertIn("BudgetExceeded", evaluator.tasks[("one", 2)]["blocked"].values())
        run(evaluator, 2, envelope=Envelope(max_bits=128))
        self.assertEqual(amount(evaluator, "one", 2), F(2, 3) ** 32)
        self.assertGreater(evaluator.meter.steps, work)
        self.assertGreater(evaluator.meter.number_bits, bits)
        for key, count in counts.items(): self.assertEqual(evaluator.execution_counts[key], count)
        self.assertTrue(all(c == 1 for c in evaluator.execution_counts.values()))

    def test_cumulative_work_and_number_charges(self):
        declarations = (literal("one", 1),)
        x = Const("one")
        for _ in range(8): x = LinComb(((Const("one"), x),))
        program = single(x, declarations)
        for envelope in (Envelope(max_steps=80), Envelope(max_number_bits=2000)):
            evaluator = Evaluator(program, envelope=envelope)
            ask(evaluator, "one", 2)
            run(evaluator, 2)
            self.assertNotIn(("one", 2), evaluator.resolutions)
            self.assertLessEqual(evaluator.meter.steps, envelope.max_steps)
            self.assertLessEqual(evaluator.meter.number_bits, envelope.max_number_bits)
            run(evaluator, 2, envelope=Envelope())
            self.assertEqual(amount(evaluator, "one", 2), 1)

    def test_schedule_admission_honors_work_envelope(self):
        with self.assertRaises(sched.BudgetExceeded):
            single(Const("one"), (literal("one", 1),), envelope=Envelope(max_steps=1))

    def test_scale_bits_cannot_bypass_budget(self):
        t = ft.Theta(scale=F(16))
        with self.assertRaises(num.NumericError):
            single(Mul(Const("x"), Const("x")), (literal("x", 1, t),), ft.Theta(scale=F(256)), envelope=Envelope(max_bits=5))

    def test_position_scale_and_asset_binding(self):
        t = ft.Theta(USD, F(1, 100), ft.due(2))
        program = single(Const("cents"), (literal("cents", 100, t),), t, (position("scale"),))
        evaluator = Evaluator(program)
        ask(evaluator, "one", 2)
        run(evaluator, 2)
        self.assertEqual(evaluator.ledger.dues()[0].amount, 1)
        wrong = single(Const("cents"), (literal("cents", 100, t),), t, (position("wrong", "EUR"),))
        evaluator = Evaluator(wrong)
        ask(evaluator, "one", 2)
        with self.assertRaisesRegex(Invalid, "PositionSettlementAssetMismatch"): run(evaluator, 2)
        self.assertEqual(evaluator.ledger.dues(), ())

    def test_duplicate_core_keys_reject_before_any_ledger_write(self):
        t = ft.Theta(USD, context=ft.due(2))
        p = position("duplicate")
        program = single(Const("one"), (literal("one", 1, t),), t, (p, dc.replace(p, quantity=F(2))))
        evaluator = Evaluator(program)
        ask(evaluator, "one", 2)
        with self.assertRaisesRegex(Invalid, "DuplicateEntitlementKeyConflict"): run(evaluator, 2)
        self.assertEqual(evaluator.ledger.dues(), ())
        self.assertEqual(evaluator.ledger._bindings, {})

    def test_stale_context_and_witness_are_rejected(self):
        program, fx, witness = multicurrency_program()
        evaluator = Evaluator(program)
        with self.assertRaisesRegex(Invalid, "StaleContext"):
            evaluator.run(now=6, context_id="obsolete-rules")
        with self.assertRaisesRegex(Invalid, "WitnessUseMismatch"):
            evaluator.offer_witness("signed-window", 6, dc.replace(witness, use=ft.Use(5, "runtime", "claims", "resolution")), context_id=CONTEXT)
        with self.assertRaisesRegex(Invalid, "ObservationContextMismatch"):
            offer(evaluator, dc.replace(fx, context_id="obsolete-rules"))

    def test_continuation_authentication_and_auxiliary_ledger_binding(self):
        program = single(Const("one"), (literal("one", 1),))
        evaluator = Evaluator(program)
        ask(evaluator, "one", 2)
        run(evaluator, 2)
        saved = evaluator.checkpoint(KEY)
        with self.assertRaisesRegex(Invalid, "ContinuationLedgerMismatch"):
            Evaluator.restore(program, saved, KEY, ent.EntitlementLedger(), context_id=CONTEXT, journal=evaluator.journal)
        with self.assertRaisesRegex(Invalid, "ContinuationAuthenticationFailed"):
            Evaluator.restore(program, saved, b"x" * 40, evaluator.ledger, context_id=CONTEXT, journal=evaluator.journal)
        with self.assertRaisesRegex(Invalid, "ContinuationContextOrProgramMismatch"):
            Evaluator.restore(program, saved, KEY, evaluator.ledger, context_id="stale", journal=evaluator.journal)

    def test_strictly_historical_reference_and_infinite_admission(self):
        h = finite(2)
        bad = Claim("bad", h, (Case(h, Ref("bad", 0)),), ft.NEUTRAL)
        with self.assertRaises(sched.Invalid): Program((bad,), (), CONTEXT)
        program = coupon_program()
        self.assertGreater(program.certificate.obligations, 0)

    def test_reference_amount_context_is_preserved(self):
        source_type = ft.Theta(USD, context=ft.due(1))
        source = Claim("source", finite(1), (Case(finite(1), Const("money")),), source_type, (literal("money", 10, source_type),))
        amount_claim = Claim("amount", finite(2), (Case(finite(2), Ref("source", 1, "amount")),), source_type)
        sample = Claim("sample", finite(2), (Case(finite(2), Ref("source", 1)),), ft.Theta(USD))
        evaluator = Evaluator(Program((source, amount_claim, sample), (), CONTEXT))
        ask(evaluator, "amount", 2)
        ask(evaluator, "sample", 2)
        run(evaluator, 2)
        a, s = [evaluator.resolutions[(name, 2)]["value"] for name in ("amount", "sample")]
        self.assertEqual(a.theta.context, ft.due(1))
        self.assertEqual(s.theta.context, ft.Group())
        self.assertEqual(next(iter(s.history)).theta.context, ft.due(1))

    def test_resolved_conversion_rate_retains_transitive_provenance(self):
        rate_type = ft.Theta(USD / EUR, context=ft.due(3))
        euros = ft.Theta(EUR)
        dollars = ft.Theta(USD, context=ft.due(3))
        source = Claim("rate-source", finite(2), (Case(finite(2), Oracle("forward-rate")),), rate_type)
        converted = Claim("converted", finite(3),
            (Case(finite(3), Convert(Const("euros"), "historical-rate", dollars, "use:3")),), dollars,
            (literal("euros", 8, euros),), (position("rate-consumer"),),
            rate_references=(("historical-rate", sched.Ref("rate-source", 1)),))
        program = Program((source, converted), (OracleContract("forward-rate", rate_type, "feed"),), CONTEXT)
        evaluator = Evaluator(program)
        ask(evaluator, "converted", 3)
        offered = observation("forward-rate", 2, F(5, 4), rate_type)
        offer(evaluator, offered)
        run(evaluator, 3)
        rate = evaluator.rate_declaration(("rate-source", 2), "historical-rate", "converted", 3)
        witness = ft.Witness("use:3", euros, dollars, rate, evaluator.use("converted", 3))
        evaluator.offer_witness("converted", 3, witness, context_id=CONTEXT)
        run(evaluator, 3)
        value = evaluator.resolutions[("converted", 3)]["value"]
        self.assertEqual(value.number.lower, 10)
        self.assertIn(offered, value.evidence)
        self.assertEqual(next(iter(value.history)).claim, "rate-source")

    def test_structural_budget_does_not_block_independent_ready_root(self):
        declarations = (literal("one", 1),)
        first = Claim("first", finite(1), (Case(finite(1), Const("one")),), ft.NEUTRAL, declarations)
        second = Claim("dependent", finite(2), (Case(finite(2), Ref("first", 1)),), ft.NEUTRAL)
        ready = Claim("ready", finite(2), (Case(finite(2), Const("one")),), ft.NEUTRAL, declarations)
        program = Program((first, second, ready), (), CONTEXT)
        evaluator = Evaluator(program, envelope=Envelope(max_instances=2))
        ask(evaluator, "dependent", 2)
        ask(evaluator, "ready", 2)
        report = run(evaluator, 2)
        self.assertEqual(amount(evaluator, "ready", 2), 1)
        self.assertEqual(report["unexpanded"], {("first", 1): "BudgetExceeded"})
        run(evaluator, 2, envelope=Envelope())
        self.assertEqual(amount(evaluator, "dependent", 2), 1)

    def test_restore_retains_existing_payment_history_and_allows_more_payments(self):
        t = ft.Theta(USD, context=ft.due(2))
        program = single(Const("ten"), (literal("ten", 10, t),), t, (position("payments"),))
        evaluator = Evaluator(program)
        ask(evaluator, "one", 2)
        run(evaluator, 2)
        ledger = evaluator.ledger
        due = ledger.dues()[0]
        key = ent.OccurrenceKey("provider", "credit", "payment")
        credit = ent.Credit(key, "holder", "USD", F(10), "booking")
        ledger.record_credit(ent.CreditReport("report", key, credit, "provider", "origin"))
        ledger.allocate("first-part", key, due.origin, 3, "authority")
        checkpoint = evaluator.checkpoint(KEY)
        missing_history = ent.EntitlementLedger()
        for binding in ledger._bindings.values(): missing_history.resolve(binding)
        with self.assertRaisesRegex(Invalid, "ContinuationLedgerMismatch"):
            Evaluator.restore(program, checkpoint, KEY, missing_history, context_id=CONTEXT, journal=evaluator.journal)
        ledger.allocate("second-part", key, due.origin, 2, "authority")
        restored = Evaluator.restore(program, checkpoint, KEY, ledger, context_id=CONTEXT, journal=evaluator.journal)
        self.assertEqual(restored.ledger.outstanding(due.origin), 5)

    def test_evidence_delivery_order_preserves_resolution_identity(self):
        identities = []
        program = coupon_program()
        for heights in ((2, 3, 4, 5), (5, 3, 2, 4)):
            evaluator = Evaluator(program)
            ask(evaluator, "coupon", 5)
            for h in heights:
                offer(evaluator, observation("trigger", h, int(h >= 4)))
                run(evaluator, 5)
            identities.append(evaluator.resolutions[("coupon", 5)]["identity"])
        self.assertEqual(identities[0], identities[1])

    def test_old_authenticated_checkpoint_cannot_reset_spent_budget(self):
        program = coupon_program()
        evaluator = Evaluator(program)
        ask(evaluator, "coupon", 2)
        saved = evaluator.checkpoint(KEY)
        work = evaluator.meter.steps
        run(evaluator, 2)
        self.assertGreater(evaluator.meter.steps, work)
        with self.assertRaisesRegex(Invalid, "StaleContinuationCheckpoint"):
            Evaluator.restore(program, saved, KEY, evaluator.ledger, context_id=CONTEXT, journal=evaluator.journal)
        current = evaluator.checkpoint(KEY)
        resumed = Evaluator.restore(program, current, KEY, evaluator.ledger, context_id=CONTEXT, journal=evaluator.journal)
        self.assertEqual(resumed.meter.steps, evaluator.meter.steps)
        with self.assertRaisesRegex(Invalid, "StaleContinuationHandle"): run(evaluator, 2)
        with self.assertRaisesRegex(Invalid, "StaleContinuationCheckpoint"):
            Evaluator.restore(program, current, KEY, resumed.ledger, context_id=CONTEXT, journal=resumed.journal)
        offer(resumed, observation("trigger", 2, 1))
        self.assertEqual(run(resumed, 2)["status"], "Resolved")

    def test_dimension_exponent_intermediates_use_the_same_budget(self):
        positive = ft.Theta(ft.Group((("unit", 16),)))
        negative = ft.Theta(ft.Group((("unit", -16),)))
        expression = Mul(Mul(Const("p"), Const("p")), Mul(Const("n"), Const("n")))
        program = single(expression, (literal("p", 1, positive), literal("n", 1, negative)), envelope=Envelope(max_bits=5))
        evaluator = Evaluator(program, envelope=Envelope(max_bits=5))
        ask(evaluator, "one", 2)
        report = run(evaluator, 2)
        self.assertEqual(report["unexpanded"], {("one", 2): "BudgetExceeded"})
        self.assertNotIn(("one", 2), evaluator.resolutions)
        run(evaluator, 2, envelope=Envelope(max_bits=6))
        self.assertEqual(amount(evaluator, "one", 2), 1)

    def test_concurrent_restores_share_the_journal_lock_across_ledgers(self):
        program = single(Const("one"), (literal("one", 1),))
        evaluator = Evaluator(program)
        ask(evaluator, "one", 2)
        run(evaluator, 2)
        for h in range(1, 301): evaluator.ledger.record_auxiliary("history", h, F(h), "prior-evidence")
        saved = evaluator.checkpoint(KEY)
        copies = [ent.EntitlementLedger(), ent.EntitlementLedger()]
        for ledger in copies:
            for (name, height), (value, evidence) in evaluator.ledger._auxiliary.items():
                ledger.record_auxiliary(name, height, value, evidence)
        barrier = threading.Barrier(2)
        results = []
        def restore_one(ledger):
            barrier.wait()
            try:
                Evaluator.restore(program, saved, KEY, ledger, context_id=CONTEXT, journal=evaluator.journal)
                results.append("Restored")
            except Invalid as error:
                results.append(str(error))
        threads = [threading.Thread(target=restore_one, args=(ledger,)) for ledger in copies]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertEqual(sorted(results), ["Restored", "StaleContinuationCheckpoint"])


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CompleteEvaluatorTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(json.dumps({"tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
                      "optimized": not __debug__}, sort_keys=True))
    raise SystemExit(not result.wasSuccessful())
