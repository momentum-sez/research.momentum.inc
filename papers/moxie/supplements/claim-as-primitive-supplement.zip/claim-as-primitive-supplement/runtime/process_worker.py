"""A separate-process client for durable evaluator integration tests.

All observations, accounts and credentials in this harness are synthetic.
"""
import json
import sys

import evaluator as ev
from durable_evaluator import DurableEvaluator, Handle, StoreError
from programs import coupon_program, multicurrency_program

KEY = b'synthetic-durable-test-key-00000000000000'


def main():
    request = ev.decode(json.loads(sys.stdin.buffer.read()))
    programme = (coupon_program() if request['programme'] == 'coupon'
                 else multicurrency_program()[0])
    store = DurableEvaluator(request['path'], KEY)
    instance = request.get('instance', request['programme'])
    if request.get('create'):
        store.create(instance, programme)
    results = []
    for op in request.get('operations', ()):
        current = store.handle(instance, programme)
        if 'revision' in op:
            current = Handle(instance, op['revision'], programme.identity)
        try:
            result = store.apply(current, programme, op['id'], op['service'],
                op['method'], *op.get('args', ()), fault_at=op.get('fault_at'),
                **op.get('kwargs', {}))
        except StoreError as error:
            result = {'store_error': str(error)}
        results.append(result)
    result = {'results': tuple(results), 'state': store.read(instance, programme)}
    sys.stdout.buffer.write(ev.wire(result))


if __name__ == '__main__':
    main()
