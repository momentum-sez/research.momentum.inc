"""Transactional persistence for the complete P08 evaluator and shared ledger.

This wrapper provides local durable serialization, not distributed consensus or
external effect atomicity. All programs use the copied, unchanged evaluator.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import hmac
import json
import os
from pathlib import Path
import sqlite3

import evaluator as ev


class StoreError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise StoreError(message)


def fault(point, configured):
    if point == configured:
        os._exit(77)


FAULTS = ('before_action', 'after_action', 'after_write', 'before_commit', 'after_commit')
EVALUATOR_ACTIONS = frozenset(('request', 'offer', 'offer_witness', 'run'))
LEDGER_ACTIONS = frozenset(('record_credit', 'register_alias', 'allocate',
    'record_return', 'reopen', 'correct_target', 'correct_quantity', 'reserve_cash', 'spend_cash'))
EXPECTED_FAILURES = (ev.Invalid, ev.num.NumericError, ev.ent.Rejected, ev.ent.Conflict)
LEDGER_MAPS = tuple(name for name in ev.ent.EntitlementLedger().__dict__ if name != '_lock')


@dataclass(frozen=True)
class Handle:
    instance: str
    revision: int
    program: str


def ledger_dump(ledger):
    # Map order is part of allocation priority after support falls.
    return {name: tuple(getattr(ledger, name).items()) for name in LEDGER_MAPS}


def ledger_load(saved):
    require(type(saved) is dict and set(saved) == set(LEDGER_MAPS), 'LedgerSchemaMismatch')
    ledger = ev.ent.EntitlementLedger()
    for name, entries in saved.items():
        require(type(entries) is tuple, 'UnorderedLedgerMap')
        values = {}
        for pair in entries:
            require(type(pair) is tuple and len(pair) == 2, 'InvalidLedgerEntry')
            key, value = pair
            require(key not in values, 'DuplicateLedgerKey')
            values[key] = value
        setattr(ledger, name, values)
    return ledger


def strict_json(body):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'DuplicateJsonKey')
            result[key] = value
        return result
    return json.loads(body, object_pairs_hook=pairs)


class DurableEvaluator:
    """One SQLite state authority shared by all registered program instances.

    A caller-held key authenticates the full state, including the current head,
    ledger map order, continuations and command outcomes. SQLite remains the
    monotonic storage premise. Copying an old entire database is outside this
    anti-stale-handle guarantee and requires an external rollback anchor.
    """
    def __init__(self, path, key, *, max_snapshot_bytes=32_000_000,
                 max_command_bytes=4_000_000):
        require(type(key) is bytes and len(key) >= 32, 'StoreKeyTooShort')
        require(type(max_snapshot_bytes) is int and max_snapshot_bytes > 0, 'InvalidSizeLimit')
        require(type(max_command_bytes) is int and max_command_bytes > 0, 'InvalidSizeLimit')
        self.path, self.key = Path(path), key
        self.max_snapshot_bytes = max_snapshot_bytes
        self.max_command_bytes = max_command_bytes
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as db:
            db.execute('CREATE TABLE IF NOT EXISTS state '
                       '(id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, '
                       'body BLOB NOT NULL, mac TEXT NOT NULL)')
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT 1 FROM state WHERE id=1').fetchone() is None:
                state = {'schema': 1, 'revision': 0, 'ledger': ledger_dump(ev.ent.EntitlementLedger()),
                         'heads': {}, 'instances': {}, 'commands': {}}
                body, mac = self._seal(state)
                db.execute('INSERT INTO state VALUES(1,0,?,?)', (body, mac))
            else:
                self._load(db)
            db.commit()

    @contextmanager
    def _connection(self):
        db = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        try:
            require(db.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower() == 'wal', 'WALUnavailable')
            db.execute('PRAGMA synchronous=FULL')
            require(db.execute('PRAGMA synchronous').fetchone()[0] == 2, 'FullSyncUnavailable')
            db.execute('PRAGMA foreign_keys=ON')
            yield db
        finally:
            # SQLITE_BUSY may leave a transaction open; no staged object escapes.
            try:
                if db.in_transaction:
                    db.rollback()
            finally:
                db.close()

    def _seal(self, state):
        body = ev.wire(state)
        require(len(body) <= self.max_snapshot_bytes, 'SnapshotSizeExceeded')
        return body, hmac.digest(self.key, body, 'sha256').hex()

    def _load(self, db):
        header = db.execute('SELECT revision,length(body) FROM state WHERE id=1').fetchone()
        require(header is not None, 'MissingStoreState')
        require(header[1] <= self.max_snapshot_bytes, 'SnapshotSizeExceeded')
        body, mac = db.execute('SELECT body,mac FROM state WHERE id=1').fetchone()
        require(hmac.compare_digest(mac, hmac.digest(self.key, body, 'sha256').hex()), 'StateAuthenticationFailed')
        state = ev.decode(strict_json(body))
        require(state['schema'] == 1 and state['revision'] == header[0], 'StoreRevisionMismatch')
        ledger_load(state['ledger'])
        return state

    def _write(self, db, state, expected_revision):
        state['revision'] = expected_revision + 1
        body, mac = self._seal(state)
        changed = db.execute('UPDATE state SET revision=?,body=?,mac=? WHERE id=1 AND revision=?',
                             (state['revision'], body, mac, expected_revision)).rowcount
        require(changed == 1, 'StoreCompareAndSwapFailed')

    @staticmethod
    def _bind(record, program):
        require(record['program'] == program.identity and record['context'] == program.context_id,
                'ProgramOrContextMismatch')

    def create(self, instance, program, *, envelope=ev.Envelope()):
        require(type(instance) is str and bool(instance), 'InvalidInstance')
        with self._connection() as db:
            db.execute('BEGIN IMMEDIATE')
            state = self._load(db)
            if instance in state['instances']:
                row = state['instances'][instance]
                self._bind(row, program)
                return Handle(instance, row['revision'], row['program'])
            ledger = ledger_load(state['ledger'])
            journal = ev.ContinuationJournal()
            journal.heads = dict(state['heads'])
            engine = ev.Evaluator(program, ledger, envelope, journal)
            state['instances'][instance] = {'program': program.identity, 'context': program.context_id,
                'revision': 0, 'checkpoint': engine.checkpoint(self.key).decode()}
            state['heads'] = dict(journal.heads)
            self._write(db, state, state['revision'])
            db.commit()
            return Handle(instance, 0, program.identity)

    def handle(self, instance, program):
        with self._connection() as db:
            db.execute('BEGIN')
            state = self._load(db)
            record = state['instances'][instance]
            self._bind(record, program)
            return Handle(instance, record['revision'], record['program'])

    def apply(self, handle, program, command_id, service, method, *args,
              fault_at=None, **kwargs):
        require(type(handle) is Handle and handle.program == program.identity, 'InvalidHandle')
        require(type(command_id) is str and bool(command_id), 'InvalidCommandIdentity')
        require(service in ('evaluator', 'ledger'), 'UnknownService')
        allowed = EVALUATOR_ACTIONS if service == 'evaluator' else LEDGER_ACTIONS
        require(method in allowed, 'MethodNotExposed')
        require(fault_at is None or fault_at in FAULTS, 'UnknownFaultPoint')
        request = (handle.instance, program.identity, program.context_id, service, method, args, kwargs)
        body = ev.wire(request)
        require(len(body) <= self.max_command_bytes, 'CommandSizeExceeded')
        request_digest = hashlib.sha256(body).hexdigest()
        command_key = (handle.instance, command_id)
        with self._connection() as db:
            db.execute('BEGIN IMMEDIATE')
            state = self._load(db)
            record = state['instances'][handle.instance]
            self._bind(record, program)
            previous = state['commands'].get(command_key)
            if previous is not None:
                require(previous['request_digest'] == request_digest, 'CommandContentConflict')
                # This precedes stale-handle rejection: commit-then-kill retries work.
                return {'replayed': True, **previous}
            require(record['revision'] == handle.revision, 'StaleDurableHandle')
            ledger = ledger_load(state['ledger'])
            journal = ev.ContinuationJournal()
            journal.heads = dict(state['heads'])
            engine = ev.Evaluator.restore(program, record['checkpoint'].encode(), self.key,
                                          ledger, context_id=program.context_id, journal=journal,
                                          max_bytes=self.max_snapshot_bytes)
            fault('before_action', fault_at)
            try:
                target = engine if service == 'evaluator' else ledger
                result = getattr(target, method)(*args, **kwargs)
                outcome = {'status': 'Ok', 'value': result}
            except EXPECTED_FAILURES as error:
                # Record the actual partial progress, counters, and typed failure.
                # SQL/infrastructure failures are never classified as engine failures.
                outcome = {'status': 'Rejected', 'error_type': type(error).__name__,
                           'reason': getattr(error, 'status', str(error))}
            fault('after_action', fault_at)
            record['checkpoint'] = engine.checkpoint(self.key).decode()
            record['revision'] += 1
            state['ledger'] = ledger_dump(ledger)
            state['heads'] = dict(journal.heads)
            receipt = {'request_digest': request_digest, 'request': request,
                       'instance_revision': record['revision'], 'outcome': outcome,
                       'work': engine.meter.steps, 'number_bits': engine.meter.number_bits}
            state['commands'][command_key] = receipt
            self._write(db, state, state['revision'])
            fault('after_write', fault_at)
            fault('before_commit', fault_at)
            db.commit()
            fault('after_commit', fault_at)
            return {'replayed': False, **receipt}

    def read(self, instance, program):
        """Read-only reconstruction. No evaluator restore or dispatch occurs."""
        with self._connection() as db:
            db.execute('BEGIN')
            state = self._load(db)
            row = state['instances'][instance]
            self._bind(row, program)
            checkpoint = strict_json(row['checkpoint'])
            raw = checkpoint['payload'].encode()
            require(hmac.compare_digest(checkpoint['hmac'], hmac.digest(self.key, raw, 'sha256').hex()),
                    'ContinuationAuthenticationFailed')
            continuation = ev.decode(strict_json(raw))
            ledger = ledger_load(state['ledger'])
            return {'store_revision': state['revision'], 'instance_revision': row['revision'],
                    'continuation': continuation, 'dues': ledger.dues(),
                    'outstanding': tuple((d.origin, ledger.outstanding(d.origin)) for d in ledger.dues()),
                    'ledger': state['ledger'], 'commands': tuple((k, v) for k, v in state['commands'].items()
                                                             if k[0] == instance)}
