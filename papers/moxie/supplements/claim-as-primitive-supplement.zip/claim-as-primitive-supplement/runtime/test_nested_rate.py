"""Preserve conversion witnesses through a resolved historical rate claim."""
from fractions import Fraction as F
from pathlib import Path
import tempfile
import unittest

from programs import *
from durable_evaluator import DurableEvaluator

KEY = b'synthetic-nested-rate-durable-key-00000000'


def nested_program():
    sterling = ft.Group.atom('GBP')
    source = ft.Theta(sterling / EUR)
    bridge = ft.Theta(USD / sterling, context=ft.due(3))
    rate_type = ft.Theta(USD / EUR, context=ft.due(3))
    euros = ft.Theta(EUR)
    dollars = ft.Theta(USD, context=ft.due(3))
    upstream = Claim('rate-source', finite(2),
        (Case(finite(2), Convert(Const('GBP-per-EUR'), 'GBPUSD', rate_type, 'use:2')),),
        rate_type, (literal('GBP-per-EUR', 2, source),))
    consumer = Claim('converted', finite(3),
        (Case(finite(3), Convert(Const('euros'), 'historical-rate', dollars, 'use:3')),),
        dollars, (literal('euros', 8, euros),), (position('nested-rate-consumer'),),
        rate_references=(('historical-rate', sched.Ref('rate-source', 1)),))
    program = Program((upstream, consumer), (OracleContract('GBPUSD', bridge, 'feed', conversion_rate=True),), CONTEXT)
    observed = observation('GBPUSD', 2, F(5, 8), bridge, rate=True)
    witness = ft.Witness('use:2', source, rate_type, observed.declaration,
                         ft.Use(2, 'runtime', 'claims', 'resolution'))
    return program, observed, witness, euros, dollars


def consumer_witness(resolution, euros, dollars):
    rate = ft.Declaration('historical-rate', resolution['value'].number.lower,
        resolution['value'].theta, role='resolved_claim',
        source='resolution:' + resolution['identity'], height=2,
        authority='runtime', conversion_rate=True)
    return ft.Witness('use:3', euros, dollars, rate, ft.Use(3, 'runtime', 'claims', 'resolution'))


class NestedRateTests(unittest.TestCase):
    def test_nested_historical_conversion_retains_both_witnesses(self):
        program, observed, upstream, euros, dollars = nested_program()
        engine = Evaluator(program)
        engine.request('converted', 3, context_id=CONTEXT)
        engine.offer(observed, context_id=CONTEXT)
        engine.offer_witness('rate-source', 2, upstream, context_id=CONTEXT)
        engine.run(now=3, context_id=CONTEXT)
        rate = engine.resolutions[('rate-source', 2)]
        self.assertEqual(rate['value'].witnesses, frozenset((upstream,)))
        current = consumer_witness(rate, euros, dollars)
        engine.offer_witness('converted', 3, current, context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)['status'], 'Resolved')
        value = engine.resolutions[('converted', 3)]['value']
        self.assertEqual(value.number.lower, 10)
        self.assertEqual(value.witnesses, frozenset((upstream, current)))
        self.assertIn(observed, value.evidence)

    def test_nested_witnesses_persist_before_and_after_consumer_resolution(self):
        program, observed, upstream, euros, dollars = nested_program()
        with tempfile.TemporaryDirectory(prefix='nested-rate-', dir=Path(__file__).parent) as work:
            path = Path(work) / 'state.sqlite'
            store = DurableEvaluator(path, KEY)
            store.create('nested', program)
            def apply(identity, method, *args, **kwargs):
                nonlocal store
                store = DurableEvaluator(path, KEY)
                handle = store.handle('nested', program)
                result = store.apply(handle, program, identity, 'evaluator', method,
                                     *args, context_id=CONTEXT, **kwargs)
                self.assertEqual(result['outcome']['status'], 'Ok')
                return result
            apply('ask', 'request', 'converted', 3)
            apply('observation', 'offer', observed)
            apply('upstream', 'offer_witness', 'rate-source', 2, upstream)
            apply('rate-ready', 'run', now=3)
            state = store.read('nested', program)['continuation']
            rate = state['resolutions'][('rate-source', 2)]
            self.assertEqual(rate['value'].witnesses, frozenset((upstream,)))
            current = consumer_witness(rate, euros, dollars)
            apply('consumer-witness', 'offer_witness', 'converted', 3, current)
            apply('consumer-ready', 'run', now=3)
            final = DurableEvaluator(path, KEY).read('nested', program)
            value = final['continuation']['resolutions'][('converted', 3)]['value']
            self.assertEqual((value.number.lower, final['dues'][0].amount), (10, 10))
            self.assertEqual(value.witnesses, frozenset((upstream, current)))
            self.assertTrue(all(n == 1 for n in final['continuation']['execution_counts'].values()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
