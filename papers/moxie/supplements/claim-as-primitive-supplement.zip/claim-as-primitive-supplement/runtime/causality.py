"""Check complete declared producer graphs over finite-prefix periodic schedules.

Claim reads are extracted from compiled instructions. External producer read
completeness, computation and authentication remain admitted contract premises.
"""
from dataclasses import dataclass, asdict
from hashlib import sha256
import json
import heapq
from types import MappingProxyType
import admission as sched


@dataclass(frozen=True)
class Read:
    producer: str
    delay: int = 0


@dataclass(frozen=True)
class Producer:
    name: str
    kind: str
    implementation: str
    authority_contract: str
    reads: tuple[Read, ...] = ()
    schedule: sched.Descriptor = sched.Descriptor(1, 1, R=frozenset((0,)))
    root_contract: str = ""


@dataclass(frozen=True)
class Manifest:
    producers: tuple[Producer, ...]
    oracle_bindings: tuple[tuple[str, str], ...]


class Cycle(sched.Invalid):
    def __init__(self, height, path):
        self.height, self.path = height, tuple(path)
        super().__init__(f"Producer cycle at height {height}: {' -> '.join(path)}")


def canonical(value):
    if hasattr(value, "__dataclass_fields__"):
        return {k: canonical(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {k: canonical(v) for k, v in sorted(value.items())}
    if type(value) in (tuple, list):
        return [canonical(v) for v in value]
    if type(value) is frozenset:
        return sorted(value)
    return value


def digest(value):
    return sha256(json.dumps(canonical(value), sort_keys=True,
                             separators=(",", ":")).encode()).hexdigest()


def order(graph, height):
    """Prerequisites precede consumers. Return an explicit cycle on failure."""
    pending = {k: set(v) for k, v in graph.items()}
    users = {k: set() for k in graph}
    for consumer, deps in pending.items():
        for dep in deps:
            users[dep].add(consumer)
    ready = [k for k, deps in pending.items() if not deps]
    heapq.heapify(ready)
    result = []
    while ready:
        key = heapq.heappop(ready)
        result.append(key)
        for user in sorted(users[key]):
            pending[user].remove(key)
            if not pending[user]:
                heapq.heappush(ready, user)
        del pending[key]
    if pending:
        key = min(pending)
        visited, path = {}, []
        while key not in visited:
            visited[key] = len(path)
            path.append(key)
            key = min(pending[key])
        raise Cycle(height, path[visited[key]:] + [key])
    return tuple(result)


class Certificate:
    def __init__(self, claims, oracles, manifest, code_binding, budget):
        if type(manifest) is not Manifest or type(manifest.producers) is not tuple or type(manifest.oracle_bindings) is not tuple:
            raise sched.Invalid("An immutable producer manifest is required.")
        meter = sched._Meter(budget)
        self.frontier_limit = budget.max_input_items
        meter.sequence(manifest.producers)
        meter.sequence(manifest.oracle_bindings)
        self.claims = MappingProxyType(dict(claims))
        self.producers = MappingProxyType({p.name: p for p in manifest.producers})
        self.bindings = MappingProxyType(dict(manifest.oracle_bindings))
        if len(self.producers) != len(manifest.producers) or len(self.bindings) != len(manifest.oracle_bindings):
            raise sched.Invalid("Duplicate producer or oracle binding.")
        if set(self.bindings) != set(oracles):
            raise sched.Invalid("Every declared oracle needs one producer binding.")
        for source, target in manifest.oracle_bindings:
            meter.name(source)
            meter.name(target)
            if target not in self.producers:
                raise sched.Invalid("Unknown oracle producer.")
        schedules = []
        delay = 0
        edge_bound = 0
        for c in self.claims.values():
            schedules.extend([c.schedule] + [x.schedule for x in c.cases])
            if any(r.tau < 1 for _, r in c.rate_references):
                raise sched.Invalid("Resolved conversion rates retain their historical-use contract.")
            for case in c.cases:
                for read in self.claim_reads(c, case):
                    delay = max(delay, read.delay)
                    edge_bound += 1
        for p in self.producers.values():
            if type(p) is not Producer or type(p.reads) is not tuple:
                raise sched.Invalid("Invalid producer record.")
            for s in (p.name, p.implementation, p.authority_contract):
                meter.name(s)
            if p.name.startswith("claim:") or p.kind not in ("oracle", "clearing", "risk", "settlement", "external"):
                raise sched.Invalid("Invalid producer name or kind.")
            meter.descriptor(p.schedule)
            meter.sequence(p.reads)
            schedules.append(p.schedule)
            if not p.reads and not p.root_contract:
                raise sched.Invalid("A primitive input needs its exogeneity or prior-commitment contract.")
            if p.root_contract:
                meter.name(p.root_contract)
            for read in p.reads:
                if type(read) is not Read:
                    raise sched.Invalid("Invalid producer read.")
                meter.name(read.producer)
                meter.number(read.delay, 0)
                delay = max(delay, read.delay)
                edge_bound += 1
        cutoff = max((s.a for s in schedules), default=1)
        self.cutoff = meter.shifted_cutoff(cutoff, delay)
        width = max(1, len(self.claims) + len(self.producers) + edge_bound)
        end = meter.horizon(self.cutoff, (s.p for s in schedules), width)
        self.period = end - self.cutoff + 1
        profiles = {}
        for h in range(1, end + 1):
            graph = self.graph(h)
            profiles[h] = order({k: {r.producer for r in reads if r.delay == 0}
                                 for k, reads in graph.items()}, h)
        self.profiles = MappingProxyType(profiles)
        self.membership_bound = meter.checks
        self.record = ("whole-producer-causality-v1", code_binding,
                       json.dumps(canonical(manifest), sort_keys=True, separators=(",", ":")),
                       self.cutoff, self.period, tuple(profiles.items()))
        self.identity = digest(self.record)

    def claim_reads(self, claim, case):
        rates = dict(claim.rate_references)
        declarations = {d.name for d in claim.declarations}
        result = []
        for ins in case.instructions:
            p = ins.parameters
            if ins.operator == "Ref":
                result.append(Read("claim:" + p[0], p[1]))
            elif ins.operator == "Window":
                # Schedule membership selects the actual historical entries.
                result.extend(Read("claim:" + p[0], j) for j in range(1, p[1] + 1))
            elif ins.operator == "Oracle":
                if p[0] not in self.bindings:
                    raise sched.Invalid("An oracle read has no producer binding.")
                result.append(Read(self.bindings[p[0]], p[1]))
            elif ins.operator == "Convert":
                if p[0] in rates:
                    r = rates[p[0]]
                    result.append(Read("claim:" + r.target, r.tau))
                elif p[0] not in declarations:
                    if p[0] not in self.bindings:
                        raise sched.Invalid("A conversion rate has no producer binding.")
                    result.append(Read(self.bindings[p[0]], 0))
        return tuple(result)

    def schedule(self, node):
        if node.startswith("claim:"):
            c = self.claims.get(node[6:])
            if c is not None:
                return c.schedule
        elif node in self.producers:
            return self.producers[node].schedule
        raise sched.Invalid("Unknown producer dependency: " + node)

    def reads(self, node, height):
        if node.startswith("claim:"):
            c = self.claims[node[6:]]
            case = next(case for case in c.cases if case.schedule.contains(height))
            reads = self.claim_reads(c, case)
            # Windows omit unscheduled dates. All other reads require them.
            windows = {(ins.parameters[0], j) for ins in case.instructions if ins.operator == "Window"
                       for j in range(1, ins.parameters[1] + 1)}
            direct = {(r.producer, r.delay) for ins in case.instructions if ins.operator != "Window"
                      for r in self.claim_reads(c, type(case)(case.schedule, (ins,)))}
            return tuple(r for r in reads if (not r.producer.startswith("claim:") or
                         (r.producer[6:], r.delay) not in windows or
                         (r.producer, r.delay) in direct or self.schedule(r.producer).contains(height-r.delay)))
        return self.producers[node].reads

    def graph(self, height):
        names = ["claim:" + c.name for c in self.claims.values()] + list(self.producers)
        graph = {name: self.reads(name, height) for name in names if self.schedule(name).contains(height)}
        for name, reads in graph.items():
            for r in reads:
                if not self.schedule(r.producer).contains(height - r.delay):
                    raise sched.Invalid(f"{name}: unavailable producer {r.producer} at height {height-r.delay}")
        return graph

    def rank(self, claim, height):
        representative = height if height < self.cutoff else self.cutoff + (height-self.cutoff) % self.period
        return self.profiles[representative].index("claim:" + claim)

    def claim_dependencies(self, source, height):
        """Return the finite claim frontier behind an oracle publication."""
        return self.frontier(source, height)[0]

    def frontier(self, source, height):
        """Check the source domain and bound every traversed predecessor."""
        if type(height) is not int or height < 1 or source not in self.bindings:
            raise sched.Invalid("Invalid oracle producer instance.")
        if not self.schedule(self.bindings[source]).contains(height):
            raise sched.Invalid("Unscheduled oracle producer instance.")
        pending, seen, claims = [(self.bindings[source], height)], set(), set()
        observations = set()
        mapped = {}
        for key, node in self.bindings.items():
            mapped.setdefault(node, []).append(key)
        while pending:
            node, h = pending.pop()
            if (node, h) in seen:
                continue
            if len(seen) >= self.frontier_limit:
                raise sched.BudgetExceeded("Producer frontier exceeds its explicit bound.")
            if not self.schedule(node).contains(h):
                raise sched.Invalid("Unscheduled producer predecessor.")
            seen.add((node, h))
            if (node, h) != (self.bindings[source], height):
                observations.update((name, h) for name in mapped.get(node, ()))
            if node.startswith("claim:"):
                claims.add((node[6:], h))
            else:
                reads = self.reads(node, h)
                if len(reads) > self.frontier_limit - len(pending):
                    raise sched.BudgetExceeded("Producer frontier queue exceeds its explicit bound.")
                pending.extend((r.producer, h-r.delay) for r in reads)
        return tuple(sorted(claims)), tuple(sorted(observations))
