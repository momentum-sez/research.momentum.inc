"""Process, accounting, serialization and failure-boundary integration tests."""
from contextlib import contextmanager
from dataclasses import replace
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import evaluator as ev
from programs import *
from durable_evaluator import DurableEvaluator, Handle, StoreError, ledger_load, ledger_dump
from process_worker import KEY

HERE = Path(__file__).resolve().parent
OBSERVATIONS = {}


def operation(identity, method, *args, service='evaluator', **kwargs):
    return {'id': identity, 'service': service, 'method': method,
            'args': args, 'kwargs': kwargs}


def request(identity, name, height):
    return operation(identity, 'request', name, height, context_id=CONTEXT)


def offered(identity, record):
    return operation(identity, 'offer', record, context_id=CONTEXT)


def runop(identity, now, **kwargs):
    return operation(identity, 'run', now=now, context_id=CONTEXT, **kwargs)


def credit(identity, amount, account='holder'):
    occurrence = ent.OccurrenceKey('synthetic-provider', 'credit', identity)
    booking = ent.Credit(occurrence, account, 'USD', F(amount), 'booking:' + identity)
    return occurrence, ent.CreditReport('assertion:' + identity, occurrence, booking,
                                       'synthetic-provider', 'synthetic-route')


def worker_command():
    return [sys.executable] + (['-O'] if sys.flags.optimize else []) + [str(HERE / 'process_worker.py')]


class DurableTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='durable-test-', dir=HERE)
        self.path = Path(self.temp.name) / 'state.sqlite'
        self.program = coupon_program()
        self.store = DurableEvaluator(self.path, KEY)
        self.store.create('coupon', self.program)

    def tearDown(self):
        self.temp.cleanup()

    def apply(self, op, programme=None, instance='coupon', store=None):
        programme, store = programme or self.program, store or self.store
        h = store.handle(instance, programme)
        return store.apply(h, programme, op['id'], op['service'], op['method'],
                           *op['args'], **op['kwargs'])

    def worker(self, operations=(), programme='coupon', instance=None, create=False,
               expected=0, start=False):
        body = ev.wire({'path': str(self.path), 'programme': programme,
                        'instance': instance or programme, 'create': create,
                        'operations': tuple(operations)})
        if start:
            proc = subprocess.Popen(worker_command(), stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            proc.stdin.write(body)
            proc.stdin.close()
            proc.stdin = None
            return proc
        result = subprocess.run(worker_command(), input=body, capture_output=True, timeout=45)
        self.assertEqual(result.returncode, expected, result.stderr.decode())
        return ev.decode(json.loads(result.stdout)) if expected == 0 else None

    def body(self):
        with sqlite3.connect(self.path) as db:
            return db.execute('SELECT revision,body,mac FROM state').fetchone()

    def resolved_coupon(self):
        operations = [request('request:' + str(h), 'coupon', h) for h in (2, 3, 4, 5)]
        operations += [offered('trigger:' + str(h), observation('trigger', h, int(h >= 4)))
                       for h in (2, 3, 4, 5)]
        operations += [runop('resolve', 5)]
        for op in operations:
            self.assertEqual(self.apply(op)['outcome']['status'], 'Ok')
        return self.store.read('coupon', self.program)

    def test_coupon_actual_process_restart_retains_pending_progress_and_unpaid_due(self):
        first = [request('request:' + str(h), 'coupon', h) for h in (2, 3, 4, 5)]
        first += [request('memory', 'memory', 5), request('independent', 'independent', 5)]
        first += [offered('trigger:' + str(h), observation('trigger', h, 0)) for h in (2, 3)]
        before = self.worker(first + [runop('before', 5)])['state']
        prior = before['continuation']
        self.assertEqual(prior['resolutions'][('independent', 5)]['value'].number.lower, 1)
        self.assertNotIn(('coupon', 4), prior['resolutions'])
        after = self.worker([offered('trigger:' + str(h), observation('trigger', h, 1)) for h in (4, 5)]
                            + [runop('after', 5)])['state']
        state = after['continuation']
        self.assertEqual([state['resolutions'][('coupon', h)]['value'].number.lower for h in (2, 3, 4, 5)],
                         [0, 0, 30, 10])
        self.assertTrue(all(n == 1 for n in state['execution_counts'].values()))
        for key, value in prior['execution_counts'].items():
            self.assertEqual(state['execution_counts'][key], value)
        self.assertGreater(state['work'], prior['work'])
        dues = sorted(after['dues'], key=lambda d: d.origin.core.height)
        occurrence, report = credit('coupon-35', 35)
        paid = self.worker([
            operation('credit', 'record_credit', report, service='ledger'),
            operation('pay-30', 'allocate', 'z-first', occurrence, dues[0].origin, F(30), 'route', service='ledger'),
            operation('pay-5', 'allocate', 'a-second', occurrence, dues[1].origin, F(5), 'route', service='ledger'),
            runop('repeat-run', 5)])['state']
        self.assertEqual([x[1] for x in paid['outstanding']], [0, 5])
        self.assertEqual(dict(paid['ledger']['_memory'])['memory'], 0)
        self.assertEqual(paid['continuation']['execution_counts'], state['execution_counts'])
        OBSERVATIONS['coupon'] = {'values': [0, 0, 30, 10], 'outstanding': [0, 5],
                                  'work_before': prior['work'], 'work_after': state['work'],
                                  'cached_nodes': len(state['execution_counts'])}

    def test_signed_window_process_restart_uses_all_samples_and_creates_directional_due(self):
        programme, fx, witness = multicurrency_program()
        before = self.worker([request('ask', 'signed-window', 6),
            offered('one', observation('euro-observation', 1, 100, ft.Theta(EUR))),
            offered('five', observation('euro-observation', 5, 80, ft.Theta(EUR))),
            runop('pending', 6)], programme='window', create=True)['state']
        self.assertNotIn(('signed-window', 6), before['continuation']['resolutions'])
        after = self.worker([
            offered('three', observation('euro-observation', 3, 120, ft.Theta(EUR))),
            offered('fx', fx),
            operation('witness', 'offer_witness', 'signed-window', 6, witness, context_id=CONTEXT),
            runop('resolve', 6)], programme='window')['state']
        due = after['dues'][0]
        self.assertEqual((due.debtor, due.creditor, due.asset, due.amount),
                         ('holder', 'issuer', 'USD', F(75, 2)))
        value = after['continuation']['resolutions'][('signed-window', 6)]['value']
        self.assertEqual((value.number.lower, value.theta.scale), (-3750, F(1, 100)))
        self.assertEqual({row.height for row in value.history}, {1, 3, 5})
        for amount in (20, F(35, 2)):
            occurrence, report = credit('window:' + str(amount), amount, 'issuer')
            after = self.worker([
                operation('credit:' + str(amount), 'record_credit', report, service='ledger'),
                operation('pay:' + str(amount), 'allocate', 'allocation:' + str(amount),
                          occurrence, due.origin, amount, 'route', service='ledger')], programme='window')['state']
        self.assertEqual(after['outstanding'][0][1], 0)
        OBSERVATIONS['window'] = {'represented_usd_cents': -3750, 'canonical_usd': '75/2',
                                  'debtor': due.debtor, 'creditor': due.creditor, 'paid': '75/2'}

    def test_process_exit_at_every_evaluator_commit_boundary(self):
        observations = []
        for point in ('before_action', 'after_action', 'after_write', 'before_commit', 'after_commit'):
            with self.subTest(point=point):
                self.path = Path(self.temp.name) / (point + '.sqlite')
                self.store = DurableEvaluator(self.path, KEY)
                self.store.create('coupon', self.program)
                self.apply(request('ask', 'coupon', 2))
                self.apply(offered('trigger', observation('trigger', 2, 1)))
                old = self.body()
                h = self.store.handle('coupon', self.program)
                op = {**runop('execute', 2), 'revision': h.revision, 'fault_at': point}
                self.worker([op], expected=77)
                self.assertEqual(self.body() == old, point != 'after_commit')
                retry = {**runop('execute', 2), 'revision': h.revision}
                final = self.worker([retry])
                self.assertEqual(final['results'][0]['replayed'], point == 'after_commit')
                self.assertEqual(len(final['state']['dues']), 1)
                self.assertEqual(final['state']['dues'][0].amount, 10)
                self.assertTrue(all(n == 1 for n in final['state']['continuation']['execution_counts'].values()))
                observations.append({'point': point, 'exit': 77, 'replayed': point == 'after_commit'})
        OBSERVATIONS['process_exit_boundaries'] = observations

    def test_payment_commit_then_exit_retries_without_second_allocation(self):
        state = self.resolved_coupon()
        due = state['dues'][0]
        occurrence, report = credit('payment', 30)
        self.apply(operation('credit', 'record_credit', report, service='ledger'))
        h = self.store.handle('coupon', self.program)
        op = operation('pay', 'allocate', 'pay-identity', occurrence, due.origin, F(30), 'route', service='ledger')
        self.worker([{**op, 'revision': h.revision, 'fault_at': 'after_commit'}], expected=77)
        output = self.worker([{**op, 'revision': h.revision}])
        self.assertTrue(output['results'][0]['replayed'])
        self.assertEqual(len(output['state']['ledger']['_allocations']), 1)
        self.assertEqual(output['state']['outstanding'][0][1], 0)

    def test_duplicate_command_precedes_stale_handle_but_changed_content_rejects(self):
        h = self.store.handle('coupon', self.program)
        receipt = self.store.apply(h, self.program, 'same', 'evaluator', 'request', 'coupon', 2, context_id=CONTEXT)
        old = self.body()
        replay = self.store.apply(h, self.program, 'same', 'evaluator', 'request', 'coupon', 2, context_id=CONTEXT)
        self.assertTrue(replay['replayed'])
        self.assertEqual(receipt['outcome'], replay['outcome'])
        self.assertEqual(self.body(), old)
        with self.assertRaisesRegex(StoreError, 'CommandContentConflict'):
            self.store.apply(h, self.program, 'same', 'evaluator', 'request', 'coupon', 3, context_id=CONTEXT)
        with self.assertRaisesRegex(StoreError, 'StaleDurableHandle'):
            self.store.apply(h, self.program, 'different', 'evaluator', 'request', 'coupon', 3, context_id=CONTEXT)

    def test_current_global_ledger_retains_another_instances_intervening_payment(self):
        state = self.resolved_coupon()
        programme = multicurrency_program()[0]
        self.store.create('window', programme)
        paused = self.store.handle('coupon', self.program)
        due = state['dues'][0]
        occurrence, report = credit('external-during-suspension', 30)
        self.apply(operation('credit', 'record_credit', report, service='ledger'), programme, 'window')
        self.apply(operation('pay', 'allocate', 'foreign-allocation', occurrence, due.origin, 20, 'route', service='ledger'),
                   programme, 'window')
        result = self.store.apply(paused, self.program, 'resume', 'evaluator', 'run', now=5, context_id=CONTEXT)
        self.assertEqual(result['outcome']['status'], 'Ok')
        current = self.store.read('coupon', self.program)
        self.assertEqual(current['outstanding'][0][1], 10)
        rejected = self.apply(operation('double', 'allocate', 'second', occurrence, due.origin, 20, 'route', service='ledger'))
        self.assertEqual(rejected['outcome']['status'], 'Rejected')
        self.assertEqual(len(self.store.read('coupon', self.program)['ledger']['_allocations']), 1)

    def test_allocation_order_corrections_returns_and_restoration_survive_restart(self):
        state = self.resolved_coupon()
        first, second = state['dues']
        occurrence, report = credit('ordered', 35)
        for op in (operation('credit', 'record_credit', report, service='ledger'),
                   operation('first', 'allocate', 'z-first', occurrence, first.origin, 30, 'route', service='ledger'),
                   operation('second', 'allocate', 'a-second', occurrence, second.origin, 5, 'route', service='ledger')):
            self.apply(op)
        correction = ent.QuantityCorrection('support-32', occurrence, 'booking:ordered', F(32), 'correction-authority')
        self.worker([operation('correction', 'correct_quantity', correction, service='ledger')])
        saved = self.store.read('coupon', self.program)
        ledger = ledger_load(saved['ledger'])
        self.assertEqual([(r.allocation_id, r.supported_quantity) for r in ledger.support_rows(occurrence)],
                         [('z-first', 30), ('a-second', 2)])
        self.assertEqual(ledger.cash_state('holder', 'USD').balance, 35)
        debit = ent.ReturnDebit(ent.OccurrenceKey('synthetic-provider', 'debit', 'returned'), occurrence, F(40), 'return-booking')
        opening = ent.Reopening('reopen-5', debit.key, 'a-second', F(5), 'synthetic-governing-rule', 'authority')
        final = self.worker([operation('return', 'record_return', debit, service='ledger'),
                             operation('reopen', 'reopen', opening, service='ledger')])['state']
        ledger = ledger_load(final['ledger'])
        self.assertEqual(ledger.cash_state('holder', 'USD').deficit, 5)
        self.assertEqual(ledger.outstanding(second.origin), 10)
        self.assertEqual([r.allocation_id for r in ledger.support_rows(occurrence)], ['z-first', 'a-second'])
        self.assertEqual(len(ledger._allocations), 2)
        self.assertEqual(sum(x.historical_quantity for x in ledger.support_rows(occurrence)), 35)

    def test_concurrent_program_reservations_share_actual_cash(self):
        programme = multicurrency_program()[0]
        self.store.create('window', programme)
        occurrence, report = credit('funded-100', 100)
        self.apply(operation('credit', 'record_credit', report, service='ledger'))
        first = self.worker([operation('reserve-a', 'reserve_cash', 'a', 'holder', 'USD', 70, service='ledger')], start=True)
        second = self.worker([operation('reserve-b', 'reserve_cash', 'b', 'holder', 'USD', 70, service='ledger')],
                             programme='window', start=True)
        outcomes = []
        for proc in (first, second):
            out, err = proc.communicate(timeout=45)
            self.assertEqual(proc.returncode, 0, err.decode())
            outcomes.append(ev.decode(json.loads(out))['results'][0]['outcome']['status'])
        self.assertEqual(sorted(outcomes), ['Ok', 'Rejected'])
        self.assertEqual(self.apply(operation('reserve-c', 'reserve_cash', 'c', 'holder', 'USD', 20, service='ledger'))['outcome']['status'], 'Ok')
        ledger = ledger_load(self.store.read('coupon', self.program)['ledger'])
        self.assertEqual((ledger.cash_state('holder', 'USD').reservations, ledger.cash_state('holder', 'USD').free), (90, 10))
        OBSERVATIONS['concurrent_funding'] = {'cash': 100, 'competing_requests': [70, 70],
                                            'accepted_competing_requests': 1, 'later_accepted': 20, 'remaining_free': 10}

    def test_concurrent_same_instance_same_command_is_one_transition(self):
        h = self.store.handle('coupon', self.program)
        op = {**request('same', 'coupon', 2), 'revision': h.revision}
        processes = [self.worker([op], start=True) for _ in range(2)]
        replayed = []
        for proc in processes:
            out, err = proc.communicate(timeout=45)
            self.assertEqual(proc.returncode, 0, err.decode())
            replayed.append(ev.decode(json.loads(out))['results'][0]['replayed'])
        self.assertEqual(sorted(replayed), [False, True])
        self.assertEqual(len(self.store.read('coupon', self.program)['commands']), 1)

    def test_budget_counters_and_cached_nodes_survive_repeated_restart(self):
        expression = Const('two-thirds')
        for _ in range(5):
            expression = Mul(expression, expression)
        h = finite(2)
        programme = Program((Claim('bounded', h, (Case(h, expression),), ft.NEUTRAL,
                                   (literal('two-thirds', F(2, 3)),)),), (), CONTEXT)
        self.store.create('budget', programme, envelope=Envelope(max_bits=16))
        self.apply(request('ask', 'bounded', 2), programme, 'budget')
        self.apply(runop('small', 2), programme, 'budget')
        before = self.store.read('budget', programme)['continuation']
        self.assertNotIn(('bounded', 2), before['resolutions'])
        restarted = DurableEvaluator(self.path, KEY)
        self.apply(runop('larger', 2, envelope=Envelope(max_bits=128)), programme, 'budget', restarted)
        after = restarted.read('budget', programme)['continuation']
        self.assertEqual(after['resolutions'][('bounded', 2)]['value'].number.lower, F(2, 3) ** 32)
        self.assertGreater(after['work'], before['work'])
        self.assertGreater(after['number_bits'], before['number_bits'])
        for key, count in before['execution_counts'].items():
            self.assertEqual(after['execution_counts'][key], count)
        self.assertTrue(all(n == 1 for n in after['execution_counts'].values()))

    def test_typed_failure_is_durable_but_python_failure_rolls_back(self):
        old = self.store.handle('coupon', self.program)
        result = self.store.apply(old, self.program, 'bad-context', 'evaluator', 'run', now=5, context_id='obsolete')
        self.assertEqual(result['outcome']['status'], 'Rejected')
        self.assertIn('StaleContext', result['outcome']['reason'])
        self.assertEqual(self.store.handle('coupon', self.program).revision, old.revision + 1)
        self.apply(request('ask', 'coupon', 2))
        self.apply(offered('evidence', observation('trigger', 2, 1)))
        before = self.body()
        original = ev.Evaluator.run
        def fail_after_work(engine, **kwargs):
            original(engine, **kwargs)
            raise RuntimeError('synthetic process failure after evaluator mutation')
        with patch.object(ev.Evaluator, 'run', fail_after_work):
            with self.assertRaisesRegex(RuntimeError, 'synthetic process failure'):
                self.apply(runop('recoverable', 2))
        self.assertEqual(self.body(), before)
        self.assertEqual(len(self.store.read('coupon', self.program)['dues']), 0)
        self.assertEqual(self.apply(runop('recoverable', 2))['outcome']['status'], 'Ok')
        self.assertEqual(len(self.store.read('coupon', self.program)['dues']), 1)

    def test_sql_failure_after_staged_write_rolls_back_all_objects(self):
        original = self.store._write
        def fail_after_write(db, state, revision):
            original(db, state, revision)
            raise sqlite3.OperationalError('synthetic disk failure after UPDATE')
        before = self.body()
        with patch.object(self.store, '_write', fail_after_write):
            with self.assertRaises(sqlite3.OperationalError):
                self.apply(request('ask', 'coupon', 2))
        self.assertEqual(self.body(), before)
        self.assertEqual(self.apply(request('ask', 'coupon', 2))['outcome']['status'], 'Ok')

    def test_connection_closes_even_if_rollback_raises(self):
        real_connect = sqlite3.connect
        closed = []
        class FailingRollback:
            def __init__(proxy, *args, **kwargs):
                proxy.db = real_connect(*args, **kwargs)
            def __getattr__(proxy, name):
                return getattr(proxy.db, name)
            def rollback(proxy):
                raise sqlite3.OperationalError('synthetic rollback failure')
            def close(proxy):
                proxy.db.close()
                closed.append(True)
        with patch.object(sqlite3, 'connect', FailingRollback):
            with self.assertRaisesRegex(sqlite3.OperationalError, 'synthetic rollback failure'):
                with self.store._connection() as db:
                    db.execute('BEGIN IMMEDIATE')
        self.assertEqual(closed, [True])
        self.assertEqual(self.apply(request('after-cleanup', 'coupon', 2))['outcome']['status'], 'Ok')

    def test_complete_state_authentication_detects_ledger_and_revision_tampering(self):
        original = self.body()
        with self.assertRaisesRegex(StoreError, 'StateAuthenticationFailed'):
            DurableEvaluator(self.path, b'x' * 32)
        row = ev.decode(json.loads(original[1]))
        row['ledger']['_cash_bookings'] = (('forged', ('holder', 'USD', F(100))),)
        with sqlite3.connect(self.path) as db:
            db.execute('UPDATE state SET body=?', (ev.wire(row),))
        with self.assertRaisesRegex(StoreError, 'StateAuthenticationFailed'):
            self.store.read('coupon', self.program)
        with sqlite3.connect(self.path) as db:
            db.execute('UPDATE state SET body=?,revision=?', (original[1], original[0] + 1))
        with self.assertRaisesRegex(StoreError, 'StoreRevisionMismatch'):
            self.store.read('coupon', self.program)

    def test_read_snapshot_survives_commit_between_header_and_body(self):
        before = self.store.read('coupon', self.program)
        original = self.store._load
        fired = []
        other = DurableEvaluator(self.path, KEY)
        def interleaved(db):
            class Proxy:
                def execute(proxy, sql, *args):
                    cursor = db.execute(sql, *args)
                    if sql.startswith('SELECT revision,length(body)') and not fired:
                        fired.append(True)
                        h = other.handle('coupon', self.program)
                        other.apply(h, self.program, 'concurrent', 'evaluator', 'request', 'coupon', 2, context_id=CONTEXT)
                    return cursor
            return original(Proxy())
        with patch.object(self.store, '_load', interleaved):
            observed = self.store.read('coupon', self.program)
        self.assertEqual(observed['store_revision'], before['store_revision'])
        self.assertGreater(self.store.read('coupon', self.program)['store_revision'], observed['store_revision'])

    def test_read_reconstruction_never_restores_or_executes_the_engine(self):
        self.resolved_coupon()
        before = self.body()
        with patch.object(ev.Evaluator, 'restore', side_effect=RuntimeError('forbidden restore')):
            with patch.object(ev.Evaluator, 'run', side_effect=RuntimeError('forbidden execution')):
                snapshot = self.store.read('coupon', self.program)
        self.assertEqual(len(snapshot['dues']), 2)
        self.assertEqual(self.body(), before)

    def test_store_size_failure_does_not_accept_partial_work(self):
        before = self.body()
        self.store.max_snapshot_bytes = len(before[1]) + 1
        with self.assertRaisesRegex(StoreError, 'SnapshotSizeExceeded'):
            self.apply(request('too-large-for-store', 'coupon', 2))
        self.assertEqual(self.body(), before)
        self.store.max_snapshot_bytes = 32_000_000
        self.assertEqual(self.apply(request('too-large-for-store', 'coupon', 2))['outcome']['status'], 'Ok')

    def test_wrong_program_and_unordered_or_duplicate_ledger_maps_reject(self):
        with self.assertRaisesRegex(StoreError, 'ProgramOrContextMismatch'):
            self.store.create('coupon', multicurrency_program()[0])
        saved = ledger_dump(ent.EntitlementLedger())
        saved['_allocations'] = {'ordinary': 'dict'}
        with self.assertRaisesRegex(StoreError, 'UnorderedLedgerMap'):
            ledger_load(saved)
        saved['_allocations'] = (('same', 1), ('same', 2))
        with self.assertRaisesRegex(StoreError, 'DuplicateLedgerKey'):
            ledger_load(saved)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(DurableTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'tests_run': result.testsRun, 'failures': len(result.failures),
              'errors': len(result.errors), 'optimized': bool(sys.flags.optimize),
              'observations': OBSERVATIONS}
    target = HERE / ('observations-optimized.json' if sys.flags.optimize else 'observations-normal.json')
    target.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
