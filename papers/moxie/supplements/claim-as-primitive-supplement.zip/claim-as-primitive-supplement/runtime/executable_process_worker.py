"""Run one exact producer transaction in an independently restarted process."""
import json
import sys
from test_executable_producers import fixture_program, KEY, CONTEXT
from durable_evaluator import DurableEvaluator, Handle

path, revision, point = sys.argv[1:]
program = fixture_program()
store = DurableEvaluator(path, KEY)
handle = Handle("producer", int(revision), program.identity)
result = store.apply(handle, program, "resolve", "evaluator", "run",
                     now=3, context_id=CONTEXT, fault_at=None if point == "retry" else point)
print(json.dumps({"replayed": result["replayed"], "status": result["outcome"]["status"]}))
