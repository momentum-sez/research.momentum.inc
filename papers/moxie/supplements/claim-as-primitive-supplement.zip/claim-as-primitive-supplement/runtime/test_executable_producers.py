"""Execute producer bodies through the complete evaluator and durable ledger."""
import dataclasses as dc
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from evaluator import *
from causality import Manifest, Producer, Read, Cycle
from programs import CONTEXT, USD, EUR, finite, literal, observation, position, multicurrency_program
from durable_evaluator import DurableEvaluator, Handle

HERE = Path(__file__).resolve().parent
KEY = b"synthetic-executable-producer-store-key-000000"


def fixture_program():
    date = finite(3)
    money = ft.Theta(USD, F(1), INSTANCE_DUE)
    body = Claim("descriptive-name", date,
        (Case(date, Mul(Const("fraction"), Oracle("gross"))),),
        money, (literal("fraction", F(1, 10)),))
    consumer = Claim("fee", date, (Case(date, Oracle("computed-fee")),),
        money, positions=(position("producer-fee"),))
    manifest = Manifest((Producer("gross-source", "external", "fixture:balance-reader",
        "fixture:account-contract", (), date, "fixture:prior-posted-balance"),),
        (("gross", "gross-source"),))
    return Program((consumer,), tuple(OracleContract(s, money, "feed") for s in ("gross", "computed-fee")),
        CONTEXT, producer_manifest=manifest,
        executable_producers=(ExecutableProducer("computed-fee", "clearing", body, "fixture:fee-rule"),))


def funded_engine():
    engine = Evaluator(fixture_program())
    engine.request("fee", 3, context_id=CONTEXT)
    plain = observation("gross", 3, 100, at(engine.program.oracles["gross"].theta, 3))
    engine.offer(engine.bind_observation(plain), context_id=CONTEXT)
    return engine


class ExecutableProducerTests(unittest.TestCase):
    def test_actual_body_resolves_without_an_offered_publication(self):
        engine = funded_engine()
        source = engine.program.internal_producers["computed-fee"]
        self.assertIsNone(engine.publication("computed-fee", 3))
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Resolved")
        produced = engine.resolutions[(source, 3)]
        consumed = engine.resolutions[("fee", 3)]["value"]
        self.assertEqual(consumed.number.lower, 10)
        self.assertEqual([d.amount for d in engine.ledger.dues()], [10])
        self.assertEqual(engine.ledger._auxiliary[(source, 3)][0], 10)
        self.assertEqual(produced["bindings"], ())
        self.assertIn(HistoricalRead(source, 3, produced["identity"], produced["value"].theta), consumed.history)
        self.assertTrue(produced["value"].evidence <= consumed.evidence)
        self.assertNotIn(("computed-fee", 3), engine.observations)
        self.assertEqual(engine.publication("computed-fee", 3).declaration.value, 10)

    def test_owned_publication_rejects_caller_value_before_and_after_resolution(self):
        engine = funded_engine()
        forged = observation("computed-fee", 3, 999, at(engine.program.oracles["computed-fee"].theta, 3))
        for resolved in (False, True):
            if resolved:
                engine.run(now=3, context_id=CONTEXT)
            with self.assertRaisesRegex(Invalid, "ExecutableSourceRequiresResolution"):
                engine.bind_observation(forged)
            with self.assertRaisesRegex(Invalid, "ExecutableSourceRequiresResolution"):
                engine.offer(forged, context_id=CONTEXT)

    def test_hidden_body_cycle_uses_extracted_actual_read(self):
        date = finite(3)
        body = Claim("body", date, (Case(date, Oracle("own")),), ft.NEUTRAL)
        with self.assertRaises(Cycle) as error:
            Program((), (OracleContract("own", ft.NEUTRAL, "feed"),), CONTEXT,
                executable_producers=(ExecutableProducer("own", "risk", body, "fixture:rule"),))
        self.assertEqual(error.exception.path[0], error.exception.path[-1])
        self.assertTrue(any(n.startswith("claim:@producer:") for n in error.exception.path))

    def test_producer_cannot_issue_a_position_or_shadow_owned_source(self):
        date = finite(3)
        body = Claim("body", date, (Case(date, Const("one")),), ft.NEUTRAL, (literal("one", 1),))
        def admit(changed):
            return Program((), (OracleContract("own", ft.NEUTRAL, "feed"),), CONTEXT,
                executable_producers=(ExecutableProducer("own", "risk", changed, "fixture:rule"),))
        with self.assertRaisesRegex(Invalid, "ExecutableProducerCannotIssue"):
            admit(dc.replace(body, positions=(position("forbidden"),)))
        with self.assertRaisesRegex(Invalid, "ExecutableSourceCannotBeShadowed"):
            admit(dc.replace(body, declarations=body.declarations + (literal("own", 7),)))
        with self.assertRaisesRegex(Invalid, "ExecutableSourceCannotBeShadowed"):
            admit(dc.replace(body, rate_references=(("own", sched.Ref("external", 1)),)))

    def test_interval_refinement_commits_only_the_exact_producer_result(self):
        engine = Evaluator(fixture_program())
        engine.request("fee", 3, context_id=CONTEXT)
        theta = at(engine.program.oracles["gross"].theta, 3)
        first = observation("gross", 3, 90, theta, upper=110, identity="uncertain")
        engine.offer(engine.bind_observation(first), context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Pending")
        self.assertIsNone(engine.publication("computed-fee", 3))
        self.assertEqual(engine.ledger.dues(), ())
        final = observation("gross", 3, 100, theta, identity="exact")
        engine.offer(engine.bind_observation(final), context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Resolved")
        self.assertEqual(engine.publication("computed-fee", 3).declaration.value, 10)

    def test_window_body_preserves_financial_operators_and_conversion_witness(self):
        base, fx, witness = multicurrency_program()
        date, history = finite(6), finite(1, 3, 5)
        # Reuse the exact authored nine-constructor payoff body.
        # Reconstruct the authored AST from the existing source factory.
        import programs
        captured = []
        original_program = programs.Program
        def capture(claims, *args, **kwargs):
            captured.extend(claims)
            return original_program(claims, *args, **kwargs)
        programs.Program = capture
        try:
            programs.multicurrency_program()
        finally:
            programs.Program = original_program
        spot, payoff = captured
        body = dc.replace(payoff, positions=())
        consumer = Claim("consumer", date, (Case(date, Oracle("window-output")),), body.output,
                         positions=payoff.positions)
        producers = (Producer("prices", "external", "fixture:prices", "fixture:price-contract", (), history,
                              "fixture:market-observations"),
                     Producer("fx", "external", "fixture:fx", "fixture:fx-contract", (), date,
                              "fixture:fx-observation"))
        program = Program((spot, consumer), tuple(base.oracles.values()) +
            (OracleContract("window-output", body.output, "feed"),), CONTEXT,
            producer_manifest=Manifest(producers, (("euro-observation", "prices"), ("EURUSD", "fx"))),
            executable_producers=(ExecutableProducer("window-output", "risk", body, "fixture:payoff-rule"),))
        engine = Evaluator(program)
        engine.request("consumer", 6, context_id=CONTEXT)
        for height, value in ((1, 100), (3, 120), (5, 80)):
            engine.offer(engine.bind_observation(observation("euro-observation", height, value, ft.Theta(EUR))),
                         context_id=CONTEXT)
        engine.offer(engine.bind_observation(fx), context_id=CONTEXT)
        source = program.internal_producers["window-output"]
        engine.offer_witness(source, 6, witness, context_id=CONTEXT)
        self.assertEqual(engine.run(now=6, context_id=CONTEXT)["status"], "Resolved")
        value = engine.resolutions[("consumer", 6)]["value"]
        self.assertEqual(value.number.lower, -3750)
        self.assertIn(witness, value.witnesses)
        self.assertEqual({h.height for h in value.history}, {1, 3, 5, 6})
        self.assertEqual([(d.debtor, d.creditor, d.amount) for d in engine.ledger.dues()],
                         [("holder", "issuer", F(75, 2))])

    def test_computed_conversion_rate_retains_upstream_witness(self):
        date = finite(3)
        gbp = ft.Group.atom("GBP")
        source = ft.Theta(gbp / EUR)
        bridge = ft.Theta(USD / gbp, context=ft.due(3))
        rate_type = ft.Theta(USD / EUR, context=ft.due(3))
        euros, dollars = ft.Theta(EUR), ft.Theta(USD, context=ft.due(3))
        body = Claim("fx-body", date,
            (Case(date, Convert(Const("GBP-per-EUR"), "GBPUSD", rate_type, "upstream")),),
            rate_type, (literal("GBP-per-EUR", 2, source),))
        consumer = Claim("converted", date,
            (Case(date, Convert(Const("euros"), "computed-rate", dollars, "consumer")),),
            dollars, (literal("euros", 8, euros),), (position("computed-rate-consumer"),))
        program = Program((consumer,), (OracleContract("GBPUSD", bridge, "feed", True),
            OracleContract("computed-rate", rate_type, "feed", True)), CONTEXT,
            producer_manifest=Manifest((Producer("fx", "external", "fixture:fx", "fixture:fx-contract", (), date,
                "fixture:fx-observation"),), (("GBPUSD", "fx"),)),
            executable_producers=(ExecutableProducer("computed-rate", "oracle", body, "fixture:cross-rate"),))
        engine = Evaluator(program)
        engine.request("converted", 3, context_id=CONTEXT)
        observed = engine.bind_observation(observation("GBPUSD", 3, F(5, 8), bridge, rate=True))
        upstream = ft.Witness("upstream", source, rate_type, observed.declaration, ft.Use(3, "runtime", "claims", "resolution"))
        engine.offer(observed, context_id=CONTEXT)
        engine.offer_witness(program.internal_producers["computed-rate"], 3, upstream, context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Pending")
        publication = engine.publication("computed-rate", 3)
        current = ft.Witness("consumer", euros, dollars, publication.declaration, ft.Use(3, "runtime", "claims", "resolution"))
        engine.offer_witness("converted", 3, current, context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Resolved")
        value = engine.resolutions[("converted", 3)]["value"]
        self.assertEqual(value.number.lower, 10)
        self.assertEqual(value.witnesses, frozenset((upstream, current)))
        self.assertIn(observed, value.evidence)

    def test_real_process_exit_at_each_producer_transaction_boundary(self):
        program = fixture_program()
        for point in ("before_action", "after_action", "after_write", "before_commit", "after_commit"):
            with self.subTest(point=point), tempfile.TemporaryDirectory(prefix="producer-kill-", dir=HERE) as tmp:
                path = Path(tmp) / "state.sqlite"
                store = DurableEvaluator(path, KEY)
                store.create("producer", program)
                store.apply(store.handle("producer", program), program, "ask", "evaluator", "request",
                            "fee", 3, context_id=CONTEXT)
                observation_value = Evaluator(program).bind_observation(observation("gross", 3, 100,
                    at(program.oracles["gross"].theta, 3)))
                store.apply(store.handle("producer", program), program, "input", "evaluator", "offer",
                            observation_value, context_id=CONTEXT)
                revision = store.handle("producer", program).revision
                command = ([sys.executable] + (["-O"] if sys.flags.optimize else []) +
                    [str(HERE / "executable_process_worker.py"), str(path), str(revision), point])
                killed = subprocess.run(command, capture_output=True, timeout=30)
                self.assertEqual(killed.returncode, 77, killed.stderr.decode())
                command[-1] = "retry"
                retried = subprocess.run(command, capture_output=True, timeout=30)
                self.assertEqual(retried.returncode, 0, retried.stderr.decode())
                result = json.loads(retried.stdout)
                self.assertEqual(result["replayed"], point == "after_commit")
                state = DurableEvaluator(path, KEY).read("producer", program)
                self.assertEqual([d.amount for d in state["dues"]], [10])
                self.assertEqual(len(state["ledger"]["_auxiliary"]), 1)
                self.assertTrue(all(n == 1 for n in state["continuation"]["execution_counts"].values()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
