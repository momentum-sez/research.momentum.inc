# The Claim as Primitive: reference supplement

This supplement contains the reference implementations, tests, and input vectors supporting *The Claim as Primitive*. It lets a reader reproduce the paper's finite computational examples and check the declared arithmetic, schedule, entitlement, and evaluator rules.

The 30 reference files are preserved byte-for-byte. The accompanying `MANIFEST.sha256` records every packaged file except the manifest itself. Keep the directory structure intact: the evaluator imports its sibling reference modules and includes their exact source bytes in program identities.

The associated manuscript source has SHA-256 `f0ed6d1317878b247617efe7df0219e537ab61bbd1fdb4ce321a863e243c5f7a`. The implementation snapshot used by that manuscript corresponds to source SHA-256 `4d1129549167eae3b343f1c63aa1de5bc29aa1d8e024cb79bbd9f460c683d9a5`. These are file digests, not publication identifiers.

## Contents and scope

| Directory or file | What it exercises |
| --- | --- |
| `reference/types/` | Scalar dimensions, scales, economic contexts, declaration bindings, historical reads, and conversion witnesses. |
| `reference/numeric/` | Independent exact Python and JavaScript arithmetic against 122 common JSON vectors, including comparisons, interval knowledge, resource rejection, and settlement residuals. |
| `reference/schedules/` | Finite-prefix and periodic-tail schedule admission, historical windows, resource bounds, and readiness when observations are missing. |
| `reference/entitlements/` | Immutable dues, correction chains, physical-booking attribution, discharge, returns, current cash, and bounded funded-note identities. |
| `runtime/` | The complete payoff evaluator, persistent continuations, SQLite transactions, causal admission, executable internal producers, and the two worked programs. |
| `review/test_producer_adversary.py` | Ten boundary tests for producer ownership, namespace separation, recurrence, evidence retention, and durable replay. |
| `reference/check_math.py` | Exact finite checks of the cubic remainder and arithmetic-size examples, with local timing and allocation observations. |

The runtime suite contains 65 tests: 23 evaluator, 18 durable transaction, two nested-rate, 14 causality, and eight executable-producer tests. The separate producer boundary suite contains ten tests. Test inputs are synthetic and appear inline, apart from the 122 numerical cases in `golden-vectors.json`. No external dataset or network service is required.

These checks exercise the stated reference profile. They do not replace the paper's proofs or establish a mechanized correspondence proof, provider authentication, legal authority, custody, physical backing, external settlement, or distributed execution. Test evidence labels and authentication keys are fixtures. The SQLite profile assumes its documented filesystem and synchronization behavior; local interruption tests cannot establish those premises on every storage system.

## Units and numerical assumptions

Python uses arbitrary-precision integers and exact `Fraction` values; JavaScript uses `BigInt`. Rational input strings and integer pairs retain their exact values. Binary floating-point observations are not substituted for rational inputs. Numerical admission budgets can reject an intermediate even when a reduced result would fit. The numeric reference defaults to 256 bits and 10,000 charged steps; the integrated evaluator has its own explicit envelope. The component READMEs describe these bounds.

A scalar's scale gives physical units per represented number. For example, scale `1/100` for USD means cents. Conversion applies the input scale, rate scale, and target scale and requires the declared witness for that use. Calendar examples use positive integer heights; a height is an ordered event index, with no assumed seconds-per-height conversion.

The coupon example resolves USD amounts `0, 0, 30, 10`. A synthetic USD 35 payment leaves USD 5 outstanding. The sparse window uses EUR observations 100, 120, and 80 at heights 1, 3, and 5. Their average is EUR 100. Its signed payoff becomes EUR -30, then USD -37.50 at the exact rate `5/4` USD per EUR; the ledger directs a nonnegative USD 37.50 due between the specified parties. The funded-note checks use declared finite payoff bounds and separate funding reservations.

The numerical settlement primitive uses `u = floor(x/q)`, `a = u*q`, and residual `r = x-a` for positive quantum `q`. It retains `0 <= r < q`, including for negative amounts. Recording this arithmetic does not itself discharge an entitlement. Interval comparisons retain uncertainty until the applicable certification rule permits a result. The finite curvature checks use exact rational inputs in normalized coordinates; reported nanoseconds and traced bytes are local measurements, not throughput or whole-process memory guarantees.

## Prerequisites

Use Python 3.9 or later with its standard library, including `sqlite3`, and Node.js with ES modules, `BigInt`, `Object.hasOwn`, and the `node:fs` and `node:url` modules. No third-party Python or JavaScript packages are required. The source does not declare a minimum Node release. Packaging verification uses Python 3.14.6, Node v25.2.1, and SQLite 3.53.3. Other version and operating-system combinations require their own check.

Extract into a writable directory. The numeric runner writes verification receipts beside its inputs, and some runtime tests create temporary databases beside their test modules. Process-interruption tests start disposable child processes. The commands below assume a POSIX shell and `python3` and `node` on `PATH`.

## Reproduction

Start in the extracted `claim-as-primitive-supplement` directory. Keep temporary files in this extraction:

```sh
mkdir -p .tmp
export TMPDIR="$PWD/.tmp"
```

Run the worked examples and the integrated runtime tests:

```sh
python3 -B runtime/run_examples.py
(cd runtime && python3 -B -m unittest -v test_evaluator test_durable test_nested_rate test_causality test_executable_producers)
(cd runtime && python3 -B -O -m unittest -v test_evaluator test_durable test_nested_rate test_causality test_executable_producers)
python3 -B review/test_producer_adversary.py
python3 -B -O review/test_producer_adversary.py
```

Run the numerical, type, schedule, and entitlement checks:

```sh
(cd reference/numeric && python3 -B run_vectors.py)
(cd reference/numeric && python3 -O -B run_vectors.py)
(cd reference/types && python3 -B test_financial_types.py)
(cd reference/types && python3 -O -B test_financial_types.py)
(cd reference/schedules && python3 -B test_schedules.py)
(cd reference/schedules && python3 -O -B test_schedules.py)
(cd reference/entitlements && python3 -B -m unittest -v test_entitlements.py)
(cd reference/entitlements && python3 -B -O -m unittest -v test_entitlements.py)
python3 -B reference/check_math.py
```

Every check should exit with status zero. Each numerical runner checks all 122 expected results in ordinary Python, optimized Python, and Node, compares their complete outputs, and tests its own mismatch detector. Its generated `verification.json` or `verification-optimized.json` records the local interpreter command and source hashes. Those local receipts are outputs of reproduction and are not part of the supplied archive. Runtime tests use `unittest`; type and finite arithmetic checks use explicit exceptions, so their checks remain active under optimization. `check_math.py` reports 270 exact checks alongside measurements that vary between runs.

Historical execution logs, repair-development files, and subsequent implementation work are outside this snapshot. The archive supplies no publication URL or additional license terms. The paper and this local supplementary file can be associated by their digests when a delivery location is assigned.
