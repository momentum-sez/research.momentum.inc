"""Independent boundary tests for executable payoff-language producers."""
import dataclasses as dc
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "runtime"))
from evaluator import *
from causality import Cycle, Manifest, Producer
from programs import CONTEXT, EUR, USD, finite, literal, observation, position
from durable_evaluator import DurableEvaluator

KEY = b"independent-producer-checkpoint-key-20260905"


def owned(body, source="computed", kind="risk", authority="fixture:derived-authority"):
    return ExecutableProducer(source, kind, body, authority)


def constant_body(name="body", value=6, dates=None, theta=ft.NEUTRAL):
    dates = finite(3) if dates is None else dates
    return Claim(name, dates, (Case(dates, Const("value")),), theta,
                 (literal("value", value, theta),))


def owner_program(authority):
    date = finite(3)
    external = Manifest((Producer("external", "external", "fixed-input-code", authority,
        (), date, "independent-fixture"),), (("external", "external"),))
    return Program((), (OracleContract("computed", ft.NEUTRAL, "feed"),
        OracleContract("external", ft.NEUTRAL, "feed")), CONTEXT,
        producer_manifest=external, executable_producers=(owned(constant_body()),))


def recurrence_program():
    all_dates = sched.Descriptor(1, 1, R=frozenset((0,)))
    tail = sched.Descriptor(2, 1, R=frozenset((0,)))
    body = Claim("descriptive-memory-body", all_dates,
        (Case(finite(1), Const("zero")),
         Case(tail, LinComb(((Const("one"), Const("one")),
                            (Const("one"), Oracle("memory", 1)))))),
        ft.NEUTRAL, (literal("zero", 0), literal("one", 1)))
    consumer = Claim("consumer", all_dates, (Case(all_dates, Oracle("memory")),), ft.NEUTRAL)
    return Program((consumer,), (OracleContract("memory", ft.NEUTRAL, "feed"),), CONTEXT,
        executable_producers=(owned(body, "memory"),))


class ProducerAdversaryTests(unittest.TestCase):
    def test_external_authority_changes_auxiliary_namespace_on_shared_ledger(self):
        first, second = owner_program("authority-one"), owner_program("authority-two")
        self.assertNotEqual(first.identity, second.identity)
        self.assertNotEqual(first.internal_producers["computed"], second.internal_producers["computed"])
        ledger = ent.EntitlementLedger()
        for program in (first, second):
            engine = Evaluator(program, ledger)
            engine.request(program.internal_producers["computed"], 3, context_id=CONTEXT)
            self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Resolved")
        self.assertEqual(len(ledger._auxiliary), 2)
        self.assertEqual(ledger.dues(), ())

    def test_positive_delay_recursive_producer_computes_initialized_sequence(self):
        program = recurrence_program()
        engine = Evaluator(program)
        engine.request("consumer", 5, context_id=CONTEXT)
        self.assertEqual(engine.run(now=5, context_id=CONTEXT)["status"], "Resolved")
        self.assertEqual(engine.resolutions[("consumer", 5)]["value"].number.lower, 4)
        name = program.internal_producers["memory"]
        self.assertEqual([engine.resolutions[(name, h)]["value"].number.lower for h in range(1, 6)],
                         [0, 1, 2, 3, 4])
        self.assertTrue(all(count == 1 for count in engine.execution_counts.values()))
        self.assertEqual(engine.ledger.dues(), ())

    def test_inactive_branch_cannot_hide_same_event_cycle(self):
        date = finite(3)
        condition = Ind("==", Const("zero"), Const("one"))
        body = Claim("cycle-body", date,
            (Case(date, IfElse(condition, Oracle("computed"), Const("zero"))),), ft.NEUTRAL,
            (literal("zero", 0), literal("one", 1)))
        with self.assertRaises(Cycle) as raised:
            Program((), (OracleContract("computed", ft.NEUTRAL, "feed"),), CONTEXT,
                    executable_producers=(owned(body),))
        self.assertEqual(raised.exception.path[0], raised.exception.path[-1])
        self.assertTrue(any("@producer:" in x for x in raised.exception.path))

    def test_consumer_schedule_cannot_create_missing_producer_instances(self):
        body = constant_body(dates=finite(3))
        consumer = Claim("consumer", finite(3, 4),
            (Case(finite(3, 4), Oracle("computed")),), ft.NEUTRAL)
        with self.assertRaises(sched.Invalid):
            Program((consumer,), (OracleContract("computed", ft.NEUTRAL, "feed"),), CONTEXT,
                    executable_producers=(owned(body),))

    def test_internal_owner_rejects_literal_and_rate_reference_shadowing(self):
        body = constant_body()
        for consumer in (
            Claim("shadow", finite(3), (Case(finite(3), Const("computed")),), ft.NEUTRAL,
                  (literal("computed", 999),)),
            Claim("shadow", finite(3), (Case(finite(3), Const("one")),), ft.NEUTRAL,
                  (literal("one", 1),), rate_references=(("computed", sched.Ref("history", 1)),)),
        ):
            history = constant_body("history", dates=finite(2))
            with self.subTest(consumer=consumer):
                with self.assertRaises(Invalid):
                    Program((consumer, history), (OracleContract("computed", ft.NEUTRAL, "feed"),),
                            CONTEXT, executable_producers=(owned(body),))

    def test_external_binding_cannot_coown_computed_source(self):
        date = finite(3)
        manifest = Manifest((Producer("external", "external", "code", "authority", (), date,
            "independent"),), (("computed", "external"),))
        with self.assertRaisesRegex(Invalid, "ExecutableSourceHasExternalOwner"):
            Program((), (OracleContract("computed", ft.NEUTRAL, "feed"),), CONTEXT,
                    producer_manifest=manifest, executable_producers=(owned(constant_body()),))

    def test_owned_source_refuses_forged_observation_before_and_after_resolution(self):
        program = owner_program("external-authority")
        engine = Evaluator(program)
        forged = observation("computed", 3, 999)
        for resolved in (False, True):
            if resolved:
                engine.request(program.internal_producers["computed"], 3, context_id=CONTEXT)
                engine.run(now=3, context_id=CONTEXT)
            with self.assertRaisesRegex(Invalid, "ExecutableSourceRequiresResolution"):
                engine.bind_observation(forged)
            with self.assertRaisesRegex(Invalid, "ExecutableSourceRequiresResolution"):
                engine.offer(forged, context_id=CONTEXT)
        publication = engine.publication("computed", 3)
        self.assertEqual(publication.declaration.value, 6)
        self.assertNotIn(("computed", 3), engine.observations)

    def test_producer_cannot_issue_positions_or_bypass_output_dimensions(self):
        money = ft.Theta(USD, F(1), INSTANCE_DUE)
        funded = dc.replace(constant_body(theta=money), positions=(position("forbidden"),))
        with self.assertRaisesRegex(Invalid, "ExecutableProducerCannotIssue"):
            Program((), (OracleContract("computed", money, "feed"),), CONTEXT,
                    executable_producers=(owned(funded),))
        with self.assertRaisesRegex(Invalid, "ExecutableOutputTypeMismatch"):
            Program((), (OracleContract("computed", money, "feed"),), CONTEXT,
                    executable_producers=(owned(constant_body()),))

    def test_durable_recursion_preserves_each_internal_value_and_execution_count(self):
        program = recurrence_program()
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "state.sqlite"
            store = DurableEvaluator(path, KEY)
            store.create("recurrence", program)
            for command, method, args, keywords in (
                ("request", "request", ("consumer", 5), {}),
                ("run", "run", (), {"now": 5}),
            ):
                store = DurableEvaluator(path, KEY)
                result = store.apply(store.handle("recurrence", program), program, command,
                    "evaluator", method, *args, context_id=CONTEXT, **keywords)
                self.assertEqual(result["outcome"]["status"], "Ok")
            before = DurableEvaluator(path, KEY).read("recurrence", program)
            replay = store.apply(store.handle("recurrence", program), program, "run", "evaluator", "run",
                now=5, context_id=CONTEXT)
            after = DurableEvaluator(path, KEY).read("recurrence", program)
            self.assertEqual(before, after)
            self.assertEqual(after["continuation"]["resolutions"][("consumer", 5)]["value"].number.lower, 4)
            self.assertTrue(all(n == 1 for n in after["continuation"]["execution_counts"].values()))

    def test_conversion_keeps_internal_rate_body_witness_and_raw_evidence(self):
        date = finite(3)
        pounds = ft.Group.atom("GBP")
        source_rate = ft.Theta(pounds / EUR)
        bridge_rate = ft.Theta(USD / pounds, context=ft.due(3))
        final_rate = ft.Theta(USD / EUR, context=ft.due(3))
        euros = ft.Theta(EUR)
        dollars = ft.Theta(USD, context=ft.due(3))
        body = Claim("derived-fx-body", date,
            (Case(date, Convert(Const("GBP-per-EUR"), "GBPUSD", final_rate, "bridge-use")),),
            final_rate, (literal("GBP-per-EUR", 2, source_rate),))
        claim = Claim("consumer", date,
            (Case(date, Convert(Const("euros"), "EURUSD", dollars, "payoff-use")),),
            dollars, (literal("euros", 8, euros),), (position("independent-fx"),))
        external = Manifest((Producer("bank-fx", "external", "bank-fixture", "bank-authority", (), date,
            "independent-bank-quotation"),), (("GBPUSD", "bank-fx"),))
        program = Program((claim,), (OracleContract("GBPUSD", bridge_rate, "feed", True),
            OracleContract("EURUSD", final_rate, "feed", True)), CONTEXT,
            producer_manifest=external, executable_producers=(owned(body, "EURUSD"),))
        engine = Evaluator(program)
        raw = engine.bind_observation(observation("GBPUSD", 3, F(5, 8), bridge_rate, rate=True))
        engine.offer(raw, context_id=CONTEXT)
        upstream = ft.Witness("bridge-use", source_rate, final_rate, raw.declaration,
                              ft.Use(3, "runtime", "claims", "resolution"))
        producer = program.internal_producers["EURUSD"]
        engine.offer_witness(producer, 3, upstream, context_id=CONTEXT)
        engine.request("consumer", 3, context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Pending")
        publication = engine.publication("EURUSD", 3)
        self.assertEqual(publication.declaration.value, F(5, 4))
        downstream = ft.Witness("payoff-use", euros, dollars, publication.declaration,
                                ft.Use(3, "runtime", "claims", "resolution"))
        engine.offer_witness("consumer", 3, downstream, context_id=CONTEXT)
        self.assertEqual(engine.run(now=3, context_id=CONTEXT)["status"], "Resolved")
        value = engine.resolutions[("consumer", 3)]["value"]
        self.assertEqual(value.number.lower, 10)
        self.assertEqual(value.witnesses, frozenset((upstream, downstream)))
        self.assertIn(raw, value.evidence)
        self.assertIn(publication, value.evidence)
        self.assertTrue(any(h.claim == producer for h in value.history))
        self.assertEqual(tuple(d.amount for d in engine.ledger.dues()), (F(10),))


if __name__ == "__main__":
    unittest.main(verbosity=2)
