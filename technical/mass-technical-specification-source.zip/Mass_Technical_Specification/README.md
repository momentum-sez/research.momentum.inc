# Mass Technical Specification

Public reading edition, September 2026.

`Mass_Technical_Specification.md` contains the complete ordered manuscript. The same text is separated into 17 chapter files under `manuscript/chapters/`. `book.json` records their order and document metadata. The `manuscript/figures/` directory contains the illustrations and their drawing sources. `templates/momentum-book.json` records the typography and page geometry used for the supplied PDF and Word document.

The source package is the book manuscript. The product implementation, private verification records, and formal proof sources are separate artifacts. Implementation observations are dated 6 September 2026 and retain their stated limits. Configuration projections are reading specimens. Public language examples require the identified language distribution.
