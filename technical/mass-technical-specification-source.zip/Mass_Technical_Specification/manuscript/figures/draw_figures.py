#!/usr/bin/env python3
"""Render the book's contract schematics to SVG and 288-dpi PNG."""
from html import escape
import os
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BASE = Path(__file__).resolve().parent
NAVY, INK, MUTED, LINE, PALE = '#17324D', '#202A33', '#586777', '#879BAD', '#E8EEF5'
SCALE = 4


def font_path():
    configured = os.environ.get('MASS_FIGURE_FONT')
    if configured: return Path(configured).expanduser()
    candidates = [Path.home() / 'Library/Fonts/AdobeGaramondPro2v115.otf',
                  Path('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf')]
    for path in candidates:
        if path.exists(): return path
    raise SystemExit('Set MASS_FIGURE_FONT to an installed TrueType/OpenType serif font')


class Figure:
    def __init__(self, height):
        self.width, self.height = 468, height
        self.svg = []
        self.image = Image.new('RGB', (468*SCALE, height*SCALE), 'white')
        self.draw = ImageDraw.Draw(self.image)

    def text(self, x, y, text, size=11, color=INK, center=False):
        anchor = 'middle' if center else 'start'
        self.svg.append(f'<text x="{x}" y="{y}" font-family="Adobe Garamond Pro, Garamond, serif" font-size="{size}" fill="{color}" text-anchor="{anchor}">{escape(text)}</text>')
        font = ImageFont.truetype(str(font_path()), size*SCALE)
        self.draw.text((x*SCALE, y*SCALE), text, font=font, fill=color, anchor='ms' if center else 'ls')

    def box(self, x, y, w, h, fill=PALE):
        self.svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{fill}" stroke="{LINE}" stroke-width="0.7"/>')
        self.draw.rounded_rectangle((x*SCALE, y*SCALE, (x+w)*SCALE, (y+h)*SCALE), radius=4*SCALE, fill=fill, outline=LINE, width=3)

    def line(self, points, arrow=True, dashed=False):
        coords = ' '.join(f'{x},{y}' for x,y in points)
        dash = ' stroke-dasharray="3 3"' if dashed else ''
        self.svg.append(f'<polyline points="{coords}" fill="none" stroke="{LINE}" stroke-width="1"{dash}/>')
        pixels = [(x*SCALE,y*SCALE) for x,y in points]
        if dashed:
            for (x1,y1),(x2,y2) in zip(pixels,pixels[1:]):
                length=max(abs(x2-x1),abs(y2-y1)); steps=max(1,int(length/12))
                for i in range(0,steps,2):
                    a=i/steps; b=min(i+1,steps)/steps
                    self.draw.line((x1+(x2-x1)*a,y1+(y2-y1)*a,x1+(x2-x1)*b,y1+(y2-y1)*b),fill=LINE,width=4)
        else: self.draw.line(pixels, fill=LINE, width=4)
        if arrow:
            x,y=points[-1]; px,py=points[-2]
            if y>py: triangle=[(x,y),(x-3,y-5),(x+3,y-5)]
            elif y<py: triangle=[(x,y),(x-3,y+5),(x+3,y+5)]
            elif x>px: triangle=[(x,y),(x-5,y-3),(x-5,y+3)]
            else: triangle=[(x,y),(x+5,y-3),(x+5,y+3)]
            self.svg.append('<polygon points="'+' '.join(f'{a},{b}' for a,b in triangle)+f'" fill="{LINE}"/>')
            self.draw.polygon([(a*SCALE,b*SCALE) for a,b in triangle],fill=LINE)

    def save(self, stem):
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="6.5in" height="{self.height/72:.4f}in" viewBox="0 0 468 {self.height}"><rect width="468" height="{self.height}" fill="white"/>'+''.join(self.svg)+'</svg>\n'
        (BASE/(stem+'.svg')).write_text(svg)
        self.image.save(BASE/(stem+'.png'),dpi=(288,288))


def authority():
    f=Figure(302)
    f.text(234,15,'Authority belongs to an explicit boundary',14,NAVY,True)
    f.text(234,33,'Contract schematic; not deployed capability proof',10,MUTED,True)
    labels=[('Mass',['Organizational state','Authority and consent','Authorized local writes']),
            ('Moxie',['Economic claims','Settlement obligations','Evidence of finality']),
            ('Recourse',['Outcomes and remedies','Execution coordination','Recovery evidence'])]
    for x,(title,lines) in zip([3,163,323],labels):
        f.box(x,53,142,103)
        f.text(x+71,74,title,14,NAVY,True)
        for i,line in enumerate(lines): f.text(x+71,96+i*17,line,10.5,INK,True)
    # Separate contracts exchange instructions and evidence; neither arrow transfers ownership.
    f.line([(145,101),(163,101)])
    f.line([(163,112),(145,112)])
    f.line([(305,101),(323,101)])
    f.line([(323,112),(305,112)])
    f.text(234,178,'Cross-boundary requests require scoped authority and receipts.',11,INK,True)
    for x in [74,234,394]:
        f.line([(x-4,186),(x-4,211)])
        f.line([(x+4,211),(x+4,186)])
    f.box(3,211,462,59,'#F2F4F7')
    f.text(234,232,'Providers own external effects',13,NAVY,True)
    f.text(234,251,'Execution instructions cross the boundary; provider evidence returns.',10.5,INK,True)
    f.text(234,291,'A local record cannot substitute for a destination acknowledgement.',10.5,MUTED,True)
    f.save('authority-boundaries')


def transaction():
    f=Figure(327)
    f.text(234,15,'Commit locally; deliver and reconcile after commit',14,NAVY,True)
    f.text(234,33,'Contract schematic; not deployed capability proof',10,MUTED,True)
    f.box(15,50,438,115,'#F2F4F7')
    f.text(234,72,'One local atomic transaction',13,NAVY,True)
    parts=[('Business state',20),('Audit record',132),('Outbox intent',244),('Proof record',356)]
    for label,x in parts:
        f.box(x,88,92,38)
        f.text(x+46,110,label,10.5,INK,True)
    f.text(234,148,'Required records commit together, or no transition is accepted.',11,INK,True)
    f.line([(234,165),(234,179),(79,179),(79,193)])
    f.text(253,183,'after commit',10,MUTED)
    for x,heading,line in [(15,'Publish / deliver','Use the committed intent'),(170,'Observe','Collect destination receipts'),(325,'Reconcile','Compare durable evidence')]:
        f.box(x,193,128,69)
        f.text(x+64,216,heading,12,NAVY,True)
        if heading=='Observe':
            f.text(x+64,234,'Collect destination',10,INK,True); f.text(x+64,248,'receipts',10,INK,True)
        elif heading=='Publish / deliver':
            f.text(x+64,234,'Use the committed',10,INK,True); f.text(x+64,248,'intent',10,INK,True)
        else:
            f.text(x+64,234,'Compare durable',10,INK,True); f.text(x+64,248,'evidence',10,INK,True)
    f.line([(143,228),(170,228)]);f.line([(298,228),(325,228)])
    f.line([(389,262),(389,283),(79,283),(79,262)],dashed=True)
    f.text(234,301,'Uncertain delivery: retry or investigate from durable state.',10.5,MUTED,True)
    f.text(234,319,'Local commit is not an assertion of external completion.',10.5,MUTED,True)
    f.save('atomic-commit-and-delivery')


def evidence():
    f=Figure(382)
    f.text(234,15,'Required effects advance on evidence',14,NAVY,True)
    f.text(234,33,'Contract schematic; not deployed capability proof',10,MUTED,True)
    labels=[('Intent','The actor requests an authorized effect.'),
            ('Local acceptance','Durable local state accepts the request.'),
            ('Destination acceptance','The destination acknowledges its obligation.'),
            ('Native finality','The destination establishes the required final state.'),
            ('Reconciled recovery','Recovery agrees with authoritative effect evidence.')]
    for i,(title,detail) in enumerate(labels):
        y=49+i*59
        f.box(35,y,374,46)
        f.text(222,y+18,title,12,NAVY,True)
        f.text(222,y+35,detail,10.5,INK,True)
        if i<4:f.line([(222,y+46),(222,y+59)])
    for y in (118,177,236):
        f.line([(409,y),(437,y),(437,y+22),(409,y+22)],dashed=True)
    f.text(234,346,'Pending or uncertain: retain state, obtain evidence, and re-evaluate.',10.5,MUTED,True)
    f.text(234,365,'A timeout does not prove failure; local success does not prove finality.',10.5,MUTED,True)
    f.save('required-effect-evidence')


if __name__=='__main__':
    authority(); transaction(); evidence()
