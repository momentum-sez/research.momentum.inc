# Configuration and Pack Authoring Reference

This reference connects configuration fields to their consumers. It uses an illustrative teaching fixture and selected authored catalog entries. It does not certify current law, grant a license, or identify an operating sovereign deployment. The chapters on governing packs define the underlying authority and evidence requirements.

## Profile, zone, and lock specimen

The following fixture selects the existing reference legal-core module. That module describes itself as a placeholder model act. The profile and zone identifiers below are illustrative, and `zz` identifies no operating jurisdiction in this example. The shapes conform to the selected fields of the profile and zone schemas.

The profile selects one module, an explicit version, and a variant:

```yaml
profile_id: reference.single-module
stack_spec_version: 0.4.44
modules:
- module_id: org.momentum.mez.legal.core
  version: 0.1.0
  variant: commonlaw-minimal
```

The zone selects that profile and declares no corridor:

```yaml
zone_id: reference.zone
jurisdiction_id: zz
zone_name: Configuration teaching fixture
profile:
  profile_id: reference.single-module
  version: 0.4.44
corridors: []
lockfile_path: stack.lock
```

The decoded lock below follows the lock generator's object construction. Its two module hashes were computed from the inspected reference module using the generator's algorithms. This is a source-derived specimen, not evidence that the distribution was launched. The serialized lock uses canonical JSON, while this display uses indentation for reading.

```json
{
  "stack_spec_version": "0.4.44",
  "generated_at": "2026-09-06T00:00:00Z",
  "zone_id": "reference.zone",
  "profile": {
    "profile_id": "reference.single-module",
    "version": "0.4.44"
  },
  "modules": [
    {
      "module_id": "org.momentum.mez.legal.core",
      "version": "0.1.0",
      "variant": "commonlaw-minimal",
      "params": {},
      "manifest_sha256": "e13b4de77586bd4f214acc0cb0e46fdb423b53001c609a659fac1071510e4b61",
      "content_sha256": "f06a99964604d5fa7a9dbbfcc4ee96f1d8f1fdedb66fc3263d766c7cd77554cb",
      "provides": [
        {
          "interface": "mez.legal.akn.v0",
          "path": "src/akn/",
          "media_type": "application/xml"
        }
      ]
    }
  ],
  "lawpacks": [],
  "regpacks": [],
  "overlays": [],
  "corridors": []
}
```

The manifest hash covers the raw module manifest bytes. The content hash covers every module file in sorted relative-path order. The generator separates each path and file body with a zero byte. Neither hash establishes that the placeholder legal text has been adopted by an authority.

The `provides` entry declares an Akoma Ntoso interface and an artifact location inside the module package. It is a discovery contract. It does not establish an executable legal rule. The lock's empty `lawpacks` array is significant: this generator initializes that array empty, even when other configuration surfaces describe lawpacks.

### Resolution and defaults

| Field or behavior | Inspected rule | Consequence for an author |
|---|---|---|
| Profile selection | Find the matching `profile_id` | Ensure the intended profile is present and unique |
| Profile inheritance | No baseline or parent field in the profile schema | Express the complete module selection explicitly |
| Module version | Record the located module's version | Check it against the profile's requested version |
| Variant and parameters | Missing variant becomes `default`; missing parameters become `{}` | Inspect resolved values before use |
| Module parameter defaults | Lock construction copies profile parameters | Do not assume manifest defaults were merged into the lock |
| Zone overlays | Schema accepts `module_id` and a list of `patches` | Schema acceptance does not prove patch application |
| Lock overlays | Generator emits `overlays: []` | This path does not bind authored overlays into its output |
| Timestamp | Explicit value, retained timestamp, source epoch, then current time | Fix the timestamp for byte comparisons |
| Missing module | Warning and omission | Compare requested modules with resolved entries |
| Zero regulatory digest | Warning and omission | Build and verify real regulatory content before release |

The profile schema requires `profile_id`, `stack_spec_version`, and `modules`. Each selected module requires `module_id`, `version`, and `variant`. The zone schema requires zone identity, jurisdiction, display name, profile, and corridors. The illustrative fixture includes every required field.

An overlay declaration has a different status from a resolved override. A zone can pass a schema that permits patches while the lock generator leaves its overlay array empty. Do not infer inheritance, last-writer precedence, union semantics, or an applied patch from that schema alone. Inspect the component that actually consumes the configuration.

For a distribution that exposes the lock command, the reproducible comparison shape is:

```sh
mez lock zone.yaml --generated-at 2026-09-06T00:00:00Z --strict
mez lock zone.yaml --generated-at 2026-09-06T00:00:00Z --strict --check
```

These commands address local configuration and artifact resolution. The selected profile and module must be discoverable in the distribution. A successful comparison establishes matching computed lock bytes, subject to the generator's omission behavior. It does not establish complete pack adoption, successful execution, or recognized authority.

## Ordered source-to-operation authoring

A source-to-operation chain has independently checkable links. The following sequence uses an authored Texas reporting configuration as a diagnostic example. It deliberately stops where the inspected sources disagree. Legal dates, fees, and thresholds require current authoritative legal review before operational use.

1. Identify the source instrument and its effective scope. The selected lawpack names the Texas Securities Act and the federal covered-securities framework. Preserve source provenance and distinguish statutory text from executable interpretation.
2. Resolve each declared rule binding. The lawpack binds the securities-act and blue-sky-notice rule artifacts. A path that resolves establishes file availability, not semantic agreement.
3. Compare the bound rule with the obligation. The obligation identifies `us-tx.rule-506-form-d-notice` as a post-sale duty. The bound notice rule still contains the incompatible pre-sale clearance model. Stop admission at this mismatch.
4. Check the trigger and evidence contracts. The authored obligation uses `fundraiser_first_sale`, authority `tx_state_securities_board`, and submission channel `efd`. Its evidence identifiers include an EFD receipt and a counsel attestation.
5. Resolve the submission surface. Adapter `efd` declares authority identifier `did:mass:us_nasaa:efd` and fallback `counsel-fallback`. Its declaration explicitly withholds a live submission claim without the required implementation and credentials.
6. Author or select a procedure only after repairing the contradiction. Bind inputs, authorization, submission, waits, failure, and evidence to the actual supported consumer. A cure-path name in an obligation is not a resolved executable procedure.
7. Validate the completed family schemas and cross-references. Compile rules and procedure definitions using their actual consumers. Reject unknown accessors, missing actuators, conflicting definitions, and unresolved required evidence.
8. Compute canonical identities and retain the selected content. Apply the signature and recognition checks required by the specific admission path. The governance publication surface's provisional signature handling remains a separate unresolved assurance boundary.

This diagnostic example demonstrates why a plausible set of pack files cannot substitute for end-to-end authoring. The reference rule also declares pending prelude accessors. Until those accessors and the semantic contradiction are resolved, the chain does not establish an executable notice obligation.

The following is an exact field projection from the obligation definition. It is intentionally incomplete and is not a standalone pack submission:

```yaml
rule_id: us-tx.rule-506-form-d-notice
obligation_type: blue_sky_notice_post_sale
authority: tx_state_securities_board
submission_channel: efd
trigger:
  trigger_id: rule-506-offering-with-texas-sale
  kind: operational_fact
  fact_kinds: [fundraiser_first_sale]
blocking_conditions: ["actuator:efd_filing", manual_cycle_resolution]
cure_paths: [prepare_form_d_notice, file_via_efd, attach_efd_receipt]
```

The projection exposes the interfaces an author must reconcile. The omitted fields include source references, deadlines, recurrence, escalation, satisfying evidence, and automation. Their omission here does not make them optional in the complete contract.

For complete rule syntax and a full waiting operation, use *Worked Authoring: A Rule and a Waiting Operation*. That chapter separates a valid language fixture from institutional execution. Together, the two examples distinguish grammar validation from semantic agreement across packs.

## Module-family navigation

Use the following identifiers to locate representative module contracts in a distribution's catalog. An identifier denotes an authored interface, not verified runtime coverage. Pack family names identify typed content separately from module families.

| Family and representative identifier | Material to inspect | Related specification subject |
|---|---|---|
| Legal: `org.momentum.mez.legal.core` | Model text, source interfaces, variants | Lawpacks and legal interpretation |
| Regulatory: `org.momentum.mez.reg.aml-cft` | Screening and due-diligence parameters | Regulatory state and compliance |
| Licensing: `org.momentum.mez.lic.bank-sponsor` | Permission requirements and reporting artifacts | License categories and issuer evidence |
| Identity: `org.momentum.mez.identity` | Identity interfaces and credential requirements | Identity and delegated authority |
| Corporate: `org.momentum.mez.corporate` | Formation, ownership, secretarial artifacts | Entities, consent, and signing |
| Capital markets: `org.momentum.mez.capital-markets` | Issuance, clearing, post-trade interfaces | Claims and settlement |
| Financial: `financial.banking-adapter` | Banking connection contract | Payments and provider boundaries |
| Trade: `org.momentum.mez.trade` | Credit, documents, customs, insurance | Trade and logistics |
| Tax: `org.momentum.mez.tax` | Collection, withholding, reporting | Duties and tax evidence |
| Corridor: `org.momentum.mez.corridor.correspondent` | Cross-border interface declaration | Recognition and evidence exchange |
| Governance: `org.momentum.mez.governance.approval-voting` | Voting configuration | Authority and governance |
| Arbitration: `org.momentum.mez.arbitration.expert-determination` | Expert decision procedure | Disputes and recourse |
| Operational: `operational.audit-logging` | Audit interface and retention configuration | Evidence, operation, and recovery |
| Primitive integration: `org.momentum.mez.mass-primitives` | Institutional primitive interface declarations | Native ownership and mutation boundaries |

The pack index is complementary. Use lawpacks for source binding, regpacks for operational regulatory data, and licensepacks for permission data. Governancepacks declare internal decision constraints. Obligationpacks define duties, procedurepacks define executable procedures, and adapterpacks describe external systems. Corridorpacks define acceptance conditions. Templatepacks and modelpacks constrain plan authoring and model invocation.

Decision tables, fee data, claim-axis definitions, and smart-asset artifacts can accompany these modules. Their presence does not make each directory a separately executable module family. Follow the selected manifest interface and its consuming operation.

## Jurisdiction and institutional-act crosswalk

The following entries summarize authored configuration subjects. They are a navigation crosswalk, not statements that the listed permission exists today or that a particular entity holds it. Instrument names come from zone configuration. Authority and license identifiers come from license-category data. Representative acts identify the subject to investigate, with an executable operation name only where separately checked.

| Configuration scope and named instrument | Authored authority and permission identifier | Representative act and boundary |
|---|---|---|
| Pakistan: Companies Act 2017 | SECP; `secp_company_registration` | Company registration. Confirm the actual procedure and issuer receipt for the intended entity form |
| Pakistan: Income Tax Ordinance 2001 | FBR; `fbr_ntn` | Tax registration. A declared registration category does not establish an issued tax number |
| Seychelles: International Business Companies Act 2016 | FSA; `fsa_ibc` | `entity.incorporate` for `sc`; distinguish incorporation, annual maintenance, good standing, and restoration |
| Seychelles: IBC corporate lifecycle | FSA registration category; `fsa_ibc` | `entity.restore` for `sc` is a separate authored procedure. A renewal fee or good-standing document alone does not establish restoration |
| ADGM: Companies Regulations 2020 | Registration Authority; `adgm_commercial_license` and `adgm_registration_certificate` | `entity.incorporate` for `ae-abudhabi-adgm`; commercial permission and registration are distinct entries |
| ADGM: Financial Services and Markets Regulations | Financial Services Regulatory Authority; `fsra_category_1`, `fsra_category_4` | Financial-services permission review. Corporate registration does not establish permission for regulated financial activity |
| ADGM: Insolvency Regulations | Authority depends on the particular insolvency act | Winding-up or administration review. The named instrument alone supplies no license-to-act mapping |
| AIFC: Companies Regulations | Registrar of Companies; `aifc_company_registration` | Participant company registration. Do not substitute a domestic Kazakhstan registration |
| AIFC: Financial Services Framework Regulations | AFSA; `afsa_dealing_investments`, `afsa_custody` | Activity-specific permission review. Each category requires its own holder and evidence checks |
| AIFC: financial innovation testing | AFSA; `afsa_fintech_lab` | Sandbox authorization. A sandbox category does not establish unrestricted permission or graduation |

For Seychelles, good-standing, renewal, and restoration are separate questions even where a workflow groups their preparation. For ADGM, formation and insolvency have different decision and evidence requirements. For AIFC, participant status, regulated activity, and sandbox conditions remain separate from domestic Kazakhstan scope.

This crosswalk intentionally leaves missing links visible. The next authoring action is to resolve the exact act, authority, procedure, and receipt contract. A deployment should publish only the resulting verified capability, with any unavailable or manual stage still explicit.
