# Worked Authoring: A Rule and a Waiting Operation

A rule answers a question about supplied facts. An operation coordinates work whose answer may arrive later. Writing either artifact requires an account of its inputs and its acceptance conditions; connecting them requires an explicit adapter and evidence of execution. This chapter works through an admitted Lex rule, a current operation definition, and a mutation contract. They are separate specimens. The operation does not load the example Lex program, and checking that program does not authorize an entity mutation.

## A small rule with an observable boundary

The rule below is the director-count threshold fixture from the public Lex implementation. Its policy is deliberately small: counts below three fail; counts of three or more pass. The threshold is a test assumption, not a statement of any jurisdiction's law.

```lex
λ(ctx : IncorporationContext).
  match director_count ctx return ComplianceVerdict with
  | 0 => NonCompliant
  | 1 => NonCompliant
  | 2 => NonCompliant
  | _ => Compliant
```

The input is an `IncorporationContext` whose `director_count` observation has natural-number type. The program returns `ComplianceVerdict`. It does not discover directors, verify their appointments, resolve legal jurisdiction, or decide whether the count is an adequate legal test. Those are separate obligations of the fact producer and policy author. A missing observation cannot be justified by silently substituting zero: zero is a supplied fact with a defined result, not an encoding of uncertainty established by this example.

The wildcard makes the match cover the remaining natural numbers. It is not an exception escape hatch. After the explicit cases zero, one, and two, the remaining values fall into the compliant branch. Negative numbers are outside the declared input type. Whether a real policy should also test appointment validity, residency, independence, or board composition must be settled before this fixture is treated as a legal rule.

Save the program as `director-threshold.lex` in a checkout of the public Lex project. The following sequence builds the CLI, examines the parsed structure, and checks admission:

```sh
cargo build --locked -p lex-cli
./target/debug/lex parse director-threshold.lex --format json
./target/debug/lex check director-threshold.lex
```

The observed check succeeded and reported the source admissible. Parsing and admission are different observations: parsing establishes that the syntax can be represented; admission checks the elaborated program against the implementation's requirements. Neither result establishes that the supplied context describes a real company.

The implementation's existing threshold tests provide a second, narrower kind of evidence:

```sh
cargo test --locked -p lex-core --test nat_literal_thresholds directors_min_three_
```

The two selected tests passed. They cover admission and execution of this threshold fixture; the evaluation cases are:

| Supplied director count | Expected verdict |
| --- | --- |
| 0, 1, 2 | `NonCompliant` |
| 3, 7 | `Compliant` |

These finite cases falsify common boundary mistakes, including accepting two or rejecting three. They are not an exhaustive proof over every natural number. The test harness constructs the facts and runs the language implementation; it does not query an entity API or certify a persisted register of directors.

Elaboration is useful for inspection:

```sh
./target/debug/lex elaborate director-threshold.lex --output director-threshold.core.lex
```

That command succeeded in the checked build. Rechecking the emitted text, however, failed with a parse error, `expected ⇒, found _`. The emitted pretty representation must therefore be treated as diagnostic output for this specimen. Preserve the original admitted source; do not advertise the pretty output as an executable interchange format or a verified round trip.

A rejection is equally instructive. The public `examples/discretion-hole-frontier.lex` fixture contains an unresolved discretion hole. Running `lex check` on it returned a nonzero exit status with `admissibility violation: unfilled discretion hole`. That failure says the program has not discharged its admission obligation. It is not a compliant verdict, an operational deferral, or permission for a caller to fill the hole with an arbitrary identity.

## A definition that creates a signing wait

The current `fund.entity_lpa_presign` default definition coordinates officer presigning of an entity's Limited Partnership Agreement. Its authored entity identifier comes from the selected entity in the calling surface. The optional `source` value is audit context. Neither value grants officer authority: the executor derives the initiating caller's identity through its authenticated execution context.

The following is a contract-bearing projection of the current YAML. It omits descriptive prose and UI annotations while retaining parameters, dependencies, conditions, service and API declarations, compliance domains, failure policy, and wait configuration. This non-executable reading specimen preserves literal interface values. The `kernel` label denotes the native Mass runtime. The `templating-engine` label and submission path describe a compute-service interface, not a public service address. Execution requires an authorized registry, configured service resolution, and authenticated runtime context.

```yaml
operation: fund.entity_lpa_presign
jurisdiction: _default
version: 0.1.0
params:
  required:
  - name: entity_id
    type: string
    provided_by: url_path
    validation:
      max_length: 255
  optional:
  - name: source
    type: string
    default: operation
steps:
- id: entity_verification
  type: check.entity_status
  service: kernel
  api:
    method: GET
    path: /v1/entities/{params.entity_id}
  params:
    operationId: '{operation_id}'
    requestedBy: '{initiator_email}'
  compliance_domains:
  - corporate
  on_failure: cancel_operation
  query_params:
    required_status: ACTIVE
- id: sanctions_screening
  type: screening.sanctions
  service: kernel
  depends_on:
  - entity_verification
  api:
    method: POST
    path: /v1/internal/identity/screening/sanctions
  params:
    operationId: '{operation_id}'
    requestedBy: '{initiator_email}'
    verification_type: sanctions_screening
    subject_id: '{params.entity_id}'
    hard_block: true
  compliance_domains:
  - sanctions
  - aml
  on_failure: cancel_operation
- id: check_entity_lpa_signed
  type: check.entity_lpa_signed
  service: kernel
  depends_on:
  - sanctions_screening
  params:
    entity_id: '{params.entity_id}'
  compliance_domains:
  - corporate
  on_failure: cancel_operation
- id: entity_lpa_presign
  type: document.entity_lpa
  service: templating-engine
  depends_on:
  - sanctions_screening
  - check_entity_lpa_signed
  condition: steps.check_entity_lpa_signed.result.signed == false
  params:
    operationId: '{operation_id}'
    requestedBy: '{initiator_email}'
    entity_id: '{params.entity_id}'
    source: '{params.source}'
  api:
    method: POST
    path: /templating-engine/api/v1/submission/batch
  compliance_domains:
  - corporate
  - securities
  wait_for: document.signed
  timeout: 30d
  on_failure: cancel_operation
compensation:
  steps: []
```

Read the definition in dependency order. `entity_verification` requires an active entity. Sanctions screening follows it and declares a hard block. `check_entity_lpa_signed` then reads whether the entity already carries a signed agreement. The document step depends on both screening and that read, and runs only when the returned `signed` value is false.

The required `entity_id` is a string supplied by the URL path, with a maximum length of 255. A client should bind it to an entity the authenticated principal selected and may act for. The optional `source` defaults to `operation`; a UI may supply its calling-surface label. The placeholders `operation_id` and `initiator_email` are execution context, not extra user-editable authority fields. A caller cannot obtain officer powers by changing `requestedBy` in copied YAML.

The named compliance domains express the checks and subject matter attached to these steps. Their presence is not evidence that every jurisdiction-specific duty has been fulfilled. The `_default` jurisdiction identity also does not establish that the default procedure is legally sufficient in every jurisdiction. Jurisdiction selection, policy applicability, and the actual execution evidence remain distinct questions.

## Step kinds determine the execution path

A service label and an API annotation do not by themselves describe the final dispatch path. The executor has typed native handlers, including an early intercept for `document.entity_lpa`. Authors must inspect the selected step kind and its handler before reasoning about side effects or waits.

| Step kind in this example | Execution responsibility | Result needed by the following stage |
| -------------------------------- | ---------------------------------- | ---------------------------------- |
| `check.entity_status` | Resolve the entity and require the configured active status | Successful entity verification |
| `screening.sanctions` | Execute native sanctions screening with the hard-block policy | Screening succeeds without terminal sanctions rejection |
| `check.entity_lpa_signed` | Ask the investment service whether the entity LPA is signed | A result carrying `entity_id` and Boolean `signed` |
| `document.entity_lpa` | Invoke the native entity-LPA handler before generic API dispatch or passive parking | An existing or newly minted agreement outcome, or an explicit zero-effect skip |

The last row matters. The YAML retains `service: templating-engine` and a submission API annotation, but the typed handler runs first. It resolves the entity and initiating actor, performs sanctions preflight, obtains the required egress authority, and invokes the investment service's standalone presign method for this path. Templating is a document-production boundary; the label does not transfer investment business ownership to a generic HTTP dispatcher.

The native outcome vocabulary includes `existing`, `minted`, `skipped_non_lp`, and `skipped_lpa_not_required`, with optional agreement and submission identifiers. The handler returns the outcome beneath `entity_lpa`. It forces terminal completion for the two zero-effect skip outcomes so they do not wait for a document that will never be produced. There is a source-description discrepancy: the current YAML prose says non-LP organizations are refused with a typed error, whereas the native handler accepts the explicit `skipped_non_lp` outcome. The execution account here follows the handler and preserves that discrepancy as a documentation defect, rather than converting the prose into a runtime guarantee.

## Waiting is not completion

A signing session is an intermediate product. For an applicable unsatisfied agreement, the operation must dispatch the work and then wait for `document.signed`, subject to the configured thirty-day timeout and cancellation policy. Merely parking the step without creating or recovering a session would leave no causal path to completion. The early document-handler intercept exists to prevent that shape of stall.

The event name alone is insufficient evidence. The event validator checks the operation's selected step actually awaits `document.signed`. It checks submission correlation: an external identifier, when present, must equal the payload submission identifier; templating coordinates must agree with the payload. It resolves the document key against persisted templating ownership rather than trusting a caller's assertion that a document was signed.

For ordinary submission authority, the key must belong to an active terminal-signed submission, and the submission must have all signing parties terminal and a document key. Archived or declined submissions are rejected. Recipient-specific partial release is separately restricted to `invest.process_lpa`; it is not a general escape from the full-signature requirement for this example. Public callbacks cannot assert the runtime-only self-emission coordinates.

An author should therefore distinguish four observations: the step produced or reused a signing session; the operation persisted a wait for that step; a correlated event passed document-authority validation; and the operation durably advanced. A provider response showing a submission identifier establishes only the first of these. A transport acknowledgement does not establish the last. The available verification for this chapter did not execute the authenticated signing journey, deliver a callback, or inspect durable operation advancement.

Failure handling belongs in the definition and in the interpretation of results. An inactive entity prevents the later signing work. Sanctions rejection is terminal. Failure of the signed-agreement read cancels the operation under this definition. Malformed, uncorrelated, or unowned document evidence cannot legitimately release the wait. A timeout is not evidence of a signature. The empty compensation list declares no compensating steps; it supplies no promise that cancelling an operation can undo an externally signed agreement.

## A mutation contract is another boundary

For a concrete comparison, consider the current public entity-creation route, `POST /v1/entities`. Its handler authorizes the caller, requires a concrete jurisdiction classification, passes the authored organization request and authenticated user identity to the entity service, and subsequently constructs the response proof envelope. The effective `entity.created` mutation contract has this shape:

| Field | Effective value |
| --- | --- |
| Event and contract identity | `entity.created` |
| Minimum role | `EntityOperator` |
| Contract entity-scope rule | `None` |
| Entity metadata keys | `entity_id` |
| Durability | `PersistOrFailClosed` |
| Transition rule | `NotApplicable` |
| Resource and action | `entity`, exactly `create` |
| Irreversibility | `Irreversible` |
| Signed-verdict flag | `false` |

These are the values selected by the current lookup path, including its earlier public-entity branch. A later matching literal in a large registry is not sufficient evidence if an earlier branch already returns. The `None` scope rule in this contract does not mean unauthenticated creation: caller authorization is visible at the route, and the service separately requires the authenticated user identity and a configured firewall. Likewise, a false signed-verdict flag does not waive the route's proof-response obligations.

The entity service obtains that contract and uses the firewall's transaction callback to perform the organization write and produce its owned mutation audit event. The event binds the actual generated entity resource identifier, action, and metadata containing the entity identifier, user identifier, and authored legal name. This is the producer of the mutation's local audit evidence. The route then passes the returned aggregate to a separate proof-envelope operation. The visible sequence does not establish that the aggregate write, proof response, document provider, event delivery, and every projection share one transaction.

This gives the author a concrete tracing discipline: route authorization identifies the caller and requested action; the effective contract defines the mutation's role, identity, and durability obligations; the owning service produces the audit event from the actual write; the response-envelope producer has its own obligation to bind the resulting aggregate. For the signing operation, the analogous downstream evidence producer is the persisted templating submission and document-key authority, followed by the operation's durable advancement. A declared requirement and a producer that can satisfy it must both be present. Neither a contract row nor a document event label manufactures the evidence it names.

## Checks an author can repeat

The Lex build, CLI admission, negative admission case, and two threshold tests were executed for this chapter. The complete current operation family also passed strict source-registry YAML validation. That validation covered 43 definitions and reported no parse errors, skipped definitions, missing required parameters, unmapped steps, enum drift, or length drift. It did not boot the application or exercise signing.

For the printed YAML projection, a small local check can catch accidental transcription damage after saving the block as `entity-lpa.yaml` in an environment with PyYAML:

```python
from pathlib import Path
import yaml

operation = yaml.safe_load(Path("entity-lpa.yaml").read_text())
assert operation["operation"] == "fund.entity_lpa_presign"
steps = operation["steps"]
seen = set()
for step in steps:
    assert step["id"] not in seen
    assert set(step.get("depends_on", [])) <= seen
    seen.add(step["id"])
last = steps[-1]
assert last["type"] == "document.entity_lpa"
assert last["wait_for"] == "document.signed"
assert last["timeout"] == "30d"
assert last["on_failure"] == "cancel_operation"
assert operation["compensation"]["steps"] == []
```

This check was executed successfully against the projection. It checks ordering and a few preserved contract values, not registry admission, handler availability, legal validity, or durable execution. A complete acceptance run would bind one registry revision and application build to an authorized actor, entity, operation, submission, and document key, then observe the actual persisted transitions. Until those observations exist, the strongest supported conclusion is that the rule admits and passes its selected tests, and the operation specimen matches a source-validated definition with inspected execution and evidence boundaries.
