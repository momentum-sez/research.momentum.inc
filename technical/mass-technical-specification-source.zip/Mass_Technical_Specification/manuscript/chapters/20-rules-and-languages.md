# Compliance State and Evidence

An entity can satisfy a rule in one jurisdiction while the same domain lies outside another jurisdiction's scope. Combining those findings must preserve both meanings. A passing finding cannot disappear because another evaluator reports that its own rule does not apply.

Mass represents compliance as a structured assessment of a subject, proposed action, jurisdiction, time, and rule set. A subject can be an entity, person, instrument, transaction, or another identified object. The assessment concerns that context. It does not establish that the subject complies with every possible law.

The requirements in these chapters define the intended contract. Implementation boundaries identify the source mechanisms that support it and the obligations that remain. Formal statements apply to their stated models. Source inspection establishes neither deployment nor successful execution of a complete operation.

## Domains and assessment context

A compliance domain groups related obligations. It supplies a stable index for composition, evidence collection, and explanation. Domain membership does not supply the applicable law. The selected jurisdictional rules determine the obligations within each domain.

The domain vocabulary includes AML, anti-bribery, arbitration, banking, clearing, consumer protection, corporate, custody, data privacy, digital assets, and employment. It also includes immigration, insurance, intellectual property, KYC, licensing, payments, sanctions, securities, settlement, Sharia, tax, and trade. These names identify separate evaluation surfaces. For example, KYC establishes relevant identity evidence, while sanctions determines whether the proposed action involves a prohibited subject or relationship.

A domain can apply to one activity and remain irrelevant to another activity of the same organization. Banking requirements do not follow solely from the presence of a bank account. Securities obligations depend on the instrument, offering, participants, and governing rules. Sharia applicability requires an explicit legal or contractual basis. Evaluators must resolve these questions from the operation context and applicable rules.

Let an assessment context be

$$
\kappa=(s,a,j,t,P,F,A),
$$

where $s$ identifies the subject, $a$ the proposed action, and $j$ the jurisdiction. The remaining components identify assessment time $t$, pinned rules $P$, facts $F$, and presented authority $A$. This tuple is specification notation. A particular API can distribute its fields across several signed objects.

An evaluator must bind evidence to the relevant components of $\kappa$. Evidence about another entity does not discharge the present entity's obligation. An approval for one amendment does not authorize a different amendment. A current rule cannot silently replace the rule pinned to a historical decision.

Missing context produces a missing-evidence or invalid-input outcome. The implementation must not synthesize an entity identity, legal exemption, authority, or completed filing to make evaluation proceed.

## Applicability and compliance degree

Compliance degree has meaning only after a domain applies. Define the applicable degree set

$$
C=\{\mathrm{NonCompliant},\mathrm{Pending},\mathrm{Compliant}\},
$$

with the order

$$
\mathrm{NonCompliant}<\mathrm{Pending}<\mathrm{Compliant}.
$$

`NonCompliant` records a detected failure under the evaluated requirements. `Pending` records incomplete evaluation or required evidence that remains outstanding. `Compliant` records satisfaction of the evaluated requirements. These meanings depend on the pinned context and do not constitute permanent properties of the subject.

Applicability is a separate classification:

$$
A=\{\mathrm{Applicable},\mathrm{NotApplicable},\mathrm{Exempt}\}.
$$

`NotApplicable` means the requirement does not apply to the classified subject or action. `Exempt` means a rule removes an otherwise relevant requirement. An exemption needs its own legal basis, scope, and conditions. Neither value means that an applicable requirement has been satisfied.

A valid cell is a tagged value

$$
V=\mathrm{Applicable}(C)\;\sqcup\;\{\mathrm{NotApplicable},\mathrm{Exempt}\}.
$$

Equivalently, a cell pairs applicability with an optional degree. The representation invariant is

$$
\mathrm{applicability}=\mathrm{Applicable}
\quad\Longleftrightarrow\quad
\mathrm{degree}\text{ is present}.
$$

An applicable cell without a degree is invalid. An exempt cell with a degree mixes different judgments and is also invalid. Safe constructors enforce this distinction before composition.

`NotApplicable` and `Exempt` are incomparable classifications. An evaluator cannot select the more favorable label by comparing their numeric encodings. A change between them requires a rule or classification decision with evidence.

## Tensor and evidence record

A compliance tensor associates domains with cells under a fixed context:

$$
T_\kappa:D\longrightarrow V.
$$

A complete tensor addresses every required domain. A sparse transport representation may omit cells, but omission does not establish non-applicability. A consumer must know the required domain set before interpreting a sparse representation.

Each material cell needs supporting evidence. The evidence record should identify the subject, jurisdiction, rule digest, fact references, effective time, evaluator, and authority. It must preserve the reason for an exemption or non-applicability decision. The degree alone cannot distinguish expired identity evidence from an outstanding signature or a prohibited counterparty.

Consider an organization that proposes to issue an instrument. Its corporate assessment may pass because the organization exists and has the required authority. Its securities assessment may remain pending because an offering document lacks approval. A passing corporate cell cannot discharge that securities obligation. The tensor preserves the separate results and their separate producers.

The same principle applies within a domain. A domain can contain several rules, called fibers in the Lex composition interface. A fiber is a rule evaluated against a subject context. The domain result must account for every required fiber. A single required failure blocks the domain even when other fibers pass.

## Content identity and freshness

A tensor digest commits to encoded content. It does not establish the truth of the facts, the authority of the evaluator, or the completeness of the domain set. These properties require separate checks.

For a canonical encoding function $\operatorname{enc}$ and a specified digest function $H$, content identity takes the form

$$
\operatorname{id}(T)=H(\operatorname{enc}(T)).
$$

The encoding contract must specify field names, ordering, scalar representations, and excluded fields. Verifiers must use the declared encoding. A digest from one language representation cannot be substituted for a digest from another representation because both use the same hash algorithm.

Freshness also needs explicit semantics. A fact can have an event time, observation time, and expiry time. An assessment has its own evaluation time. A signed statement observed today can describe an event from an earlier period. A historical assessment must retain that distinction.

The verifier must check the validity window required by the operation. Evidence that satisfied an earlier decision may remain useful for historical verification while failing a new admission check. Reevaluation creates a new decision about the selected historical or current context. It does not rewrite the source event.

## Implementation boundary

The source contains both the orthogonal `TensorValue` representation and a flat `ComplianceState` representation. The flat representation orders `NotApplicable` and `Exempt` between `Pending` and `Compliant`. Its minimum operation remains available and appears in tensor methods.

An orthogonal composition helper converts flat states into structured values, composes them, then projects back. That projection drops provenance flags. It also resolves the non-applicable/exempt obstruction through the flat ordering. Consequently, storage and public responses do not yet uniformly preserve the full structured result.

The flat chain supports valid finite-lattice results within its own model. Those results do not establish that the flat model captures every legal classification. Consumers must identify which representation and composition operation produced a result. A generic statement that all Mass compliance uses a single total lattice exceeds the implemented boundary.

# Composition, Residuals, and Remediation

## Composition on applicable evidence

For two applicable degrees, conservative composition is the chain meet:

$$
a\wedge b=\min(a,b).
$$

Thus `Compliant` composed with `Pending` remains `Pending`. `NonCompliant` absorbs every applicable degree. These rules ensure that adding a passing assessment cannot erase an outstanding failure.

On the applicable chain, meet is commutative, associative, and idempotent. The join $a\vee b=\max(a,b)$ is its lattice dual. These algebraic facts follow from the finite total order. Their operational use still depends on the meaning of the operands.

Join can represent alternatives only where the governing rule permits alternatives. If either of two accredited attestations suffices, an evaluator may implement that rule using a join-like decision. A caller cannot use the same operation to choose between mandatory requirements. The legal rule determines conjunction or alternative satisfaction before the algebra evaluates it.

## Composition across applicability classes

The structured composition operator returns a value with provenance or an obstruction. Denote it by $\operatorname{compose}_V$. Its principal cases are:

| Inputs | Result | Required explanation |
|---|---|---|
| Applicable degrees $a,b$ | Applicable$(a\wedge b)$ | Both assessments contribute |
| Applicable$(a)$ and NotApplicable | Applicable$(a)$ | Preserve mixed applicability |
| Applicable$(a)$ and Exempt | Applicable$(a)$ | Preserve the exemption context |
| Matching out-of-scope classes | That class | Preserve their source bases |
| NotApplicable and Exempt | Obstruction | Reconcile different classifications |

The operator is symmetric in its inputs. Its output is not always another bare cell. A mixed-applicability result carries a provenance flag. An obstruction identifies a domain-context mismatch that the caller must resolve.

For example, jurisdiction $J_A$ can require a license and find the organization compliant. Jurisdiction $J_B$ can classify the same activity outside its licensing regime. Their composition retains the applicable finding from $J_A$ and the non-applicability finding from $J_B$. Returning only `NotApplicable` would conceal the evaluated license.

Suppose instead that two assessments disagree between non-applicability and exemption. The distinction can affect continuing conditions, reporting, or expiry. The structured operator reports that disagreement. It does not invent a legal ordering between the two reasons.

A tensor composition lifts this operation per domain. Its result therefore includes composed cells, provenance, and unresolved obstructions. Every required domain must either produce a valid composed cell or expose a blocking obligation. A consumer must not drop failed cells and present the remaining tensor as complete.

## Why the full structure is not a Heyting algebra

A Heyting algebra requires a total lattice structure with a right adjoint to meet. The applicable chain satisfies that requirement. The full applicability-aware structure does not inherit it merely because its carrier is finite.

The obstruction appears before implication. If `NotApplicable` is incomparable with applicable degrees, a lattice meet must lie below both operands. A signal-preserving composition that returns `Applicable(Compliant)` for that pair violates the lower-bound condition. The structured operation has a different purpose: retain relevant compliance evidence while exposing the applicability difference.

Adding a universal top and bottom creates a bounded lattice for the flat completion of the applicability classes. That construction contains a nondistributive diamond. It therefore does not supply the desired Heyting algebra. Imposing a total order instead destroys the intended incomparability of applicability classes.

The resulting specification is precise. Use lattice and adjunction laws on the applicable fragment. Use the structured composition contract for mixed applicability. Require an explicit reconciliation step when composition reports an obstruction. Do not apply distributivity or reassociation to a mixed result without a theorem for that exact result type and provenance semantics.

## The applicable-fragment residual

For applicable degrees, define the Heyting residual by

$$
a\Rightarrow b=
\begin{cases}
\top,&a\leq b,\\
b,&a>b,
\end{cases}
\qquad\top=\mathrm{Compliant}.
$$

It satisfies the adjunction

$$
a\wedge x\leq b
\quad\Longleftrightarrow\quad
x\leq(a\Rightarrow b).
$$

This formula answers an order-theoretic question. It identifies the greatest operand compatible with an upper bound on a meet. It does not calculate the evidence that raises a pending assessment to compliance.

For example, `Pending` implies `Compliant` equals `Compliant` under this ordering. Yet meeting `Pending` with `Compliant` still yields `Pending`. No operand can raise a fixed value through a minimum operation. Treating the residual as a direct upgrade instruction reverses the operational meaning of the order.

Remediation changes the evaluated facts, discharges an obligation, or changes the applicable rule through authorized evolution. The evaluator then produces a new state. It does not convert a failing conjunction into a passing one by adding an optimistic operand.

The structured residual API extends some cases beyond the applicable chain, but those cases do not establish a global adjunction. Matching out-of-scope classes retain their classification. Moving from an out-of-scope current class to an applicable target reports a cannot-lift obstruction. A non-applicable/exempt mismatch reports a context obstruction. Callers must preserve those distinctions in planning results.

## Planning over executable transitions

Let $S$ denote an assessment state with its relevant facts and obligations. A remediation operation $o$ induces a permitted transition only when its preconditions hold:

$$
S\xrightarrow{o,e}S',
$$

where $e$ records the evidence produced by successful execution. The transition can update evidence, request an approval, or receive an external acknowledgment. Its postcondition must identify what changed and what remains outstanding.

A remediation plan is a sequence of such transitions. Its target is an operation-specific acceptance predicate, not necessarily a tensor filled with `Compliant`. An explicitly exempt domain can satisfy an operation's requirements without becoming applicable. Forcing every domain to the applicable top would itself change the legal classification.

If a planner minimizes cost, it must specify the graph, edge weights, and constraints. A shortest path exists only when the target is reachable within those constraints. Nonnegative costs allow ordinary Dijkstra search for an unconstrained shortest-path problem. Additional cumulative constraints require an algorithm that preserves the necessary state at each search node.

Mass's current compliance manifold implementation stores jurisdiction nodes and corridor edges. Edges carry transfer fees, processing times, and related costs. The path finder excludes inactive routes and applies configured limits. It returns no path when the selected search cannot reach the target.

This implementation is not a search across every possible tensor state. It does not prove that a route can execute every legal or economic operation along its edges. It also does not establish a general optimality theorem for all combinations of cumulative constraints. A route recommendation must undergo current admission checks at each real execution boundary.

## Failure and implementation boundary

A planning result must distinguish missing evidence, prohibited action, classification obstruction, unavailable route, and exhausted search constraints. These outcomes require different responses. A sanctions failure cannot become an evidence-collection task unless the governing process permits correction of the underlying identification or facts.

The applicable algebra and structured operator have source implementations and scoped formal models. Their existence does not prove that every consumer preserves the same semantics. Legacy projection remains a material limitation. Verification must compare the actual operation's composition path with the algebra claimed for that operation.

# Jurisdictional Composition and Recognition

## Simultaneous jurisdictional state

An organization can maintain legal relationships in several jurisdictions at once. A harbor is an identified jurisdictional relationship with its own registration, authority, rules, and evidence. Adding a harbor does not remove the obligations of an existing harbor.

For active harbors $J$, let $T_j$ be the assessment under jurisdiction $j$. The composed decision must retain the jurisdictional assessments and their provenance. It must also identify which harbors govern the proposed action. Registration somewhere does not make every local rule applicable to every activity everywhere.

The acceptance condition is a conjunction of the required jurisdictional decisions, after permitted recognition and context translation. Where structured cell composition is defined, the system can compute a combined tensor. Where it is obstructed, it must preserve the separate decisions and name the unresolved relationship.

An empty jurisdiction set is not evidence of universal permission. The caller or operation contract must establish the intended jurisdiction and subject scope. A missing harbor record cannot silently become an unrestricted default jurisdiction.

## Recognition as an explicit admission rule

Recognition lets one jurisdiction admit specified evidence produced under another jurisdiction's authority. It needs a source authority, receiving authority, evidence class, subject scope, validity conditions, and legal basis. A corridor supplies the operational relationship through which such evidence can travel.

Let $R_{B\to A}$ be the recognition policy by which $A$ admits evidence from $B$. Let $\phi_{B\to A}$ be the permitted translation into $A$'s assessment context. The receiving decision uses

$$
\operatorname{compose}_V\bigl(T_A,\phi_{B\to A}(T_B)\bigr)
$$

only after the recognition gate accepts the evidence. This notation does not imply that every policy defines a total translation. Rejection, missing coverage, and undecidable applicability must remain explicit outcomes.

Recognition of identity evidence does not recognize a payment authorization. Recognition of one license does not recognize every license issued by the source. The receiving authority remains responsible for the meaning and permitted use of the imported evidence.

A translation must preserve required failures. It cannot map a sanctions rejection into a passing result because the receiving vocabulary lacks a matching category. When exact translation is unavailable, the receiving jurisdiction must require local evaluation or refuse the proposed use.

## Paths and transitive evidence

A path through several corridors does not automatically extend a bilateral recognition agreement. Each segment must permit the relevant evidence class and forwarding behavior. The operation must retain the original issuer and the transformations applied along the path.

The current corridor composition source defines per-domain transitive-evidence policies. Sanctions requires evaluation at each applicable hop rather than transitive trust. A path can fail because an intermediate jurisdiction lacks the required domain evidence, even when both endpoints pass their own checks.

No domain may receive broader recognition from path construction than its direct policies allow. In particular, a route optimizer must not create recognition rights. Cost and latency select among legally admissible routes. They do not determine admissibility.

## Provenance and conflict

A combined decision needs more than the name of a winning jurisdiction. Several jurisdictions can contribute the same restrictive degree for different reasons. A later correction may affect only one reason. Preserving only the minimum degree would prevent a verifier from reconstructing the remaining obligations.

A provenance record should retain the domain, source jurisdiction, rule and evidence references, original classification, translation policy, and composition result. Mixed applicability must remain visible. The result should also identify the subject and operation whose scope made each contribution relevant.

Conflict resolution proceeds within the authority and priority rules that govern the conflict. A more recent timestamp does not automatically defeat an older legal obligation. A larger number of agreeing evaluators does not repeal a controlling rule. A tribunal or regulator decision needs an authority witness and an applicable scope.

Sanctions rejection is terminal for the proposed action under the evaluated context. The execution path must refuse the mutation. Neither ordinary exceptions, market demand, nor another jurisdiction's passing assessment can override that rejection. An authorized correction of evidence produces a distinct evaluation with its own history.

## Reproduction and implementation boundary

A verifier can reproduce deterministic composition when it has the exact inputs and the same defined operations. Reproducing the upstream assessments additionally requires pinned rules, facts, authority evidence, external observations, and evaluator semantics. Determinism of a finite meet alone does not prove determinism of that complete pipeline.

Corridor state-machine code and formal models specify quorum, rejection, terminal states, and recovery behavior. Those models have explicit assumptions about signatures and verdict consistency. Their proofs do not establish delivery, persistence, or finality in a deployed network.

The operational acceptance test must bind the participating jurisdictions, admitted evidence, signed verdicts, durable state, and recovery outcome to one transaction. A configured corridor or a compiled model is insufficient evidence that a cross-jurisdictional operation completed.

# Lex: Rules, Time, and Authorized Judgment

Lex expresses jurisdictional rules as typed terms. It separates computable conditions, defeasible exceptions, temporal reasoning, and decisions that require an identified authority. Its public language reference governs the documented executable boundary. The parser's ability to represent a term does not establish that a checker, compiler, or runtime can execute it.

## Terms, types, and the prelude

A typing judgment has the form

$$
\Gamma\vdash t:\tau,
$$

where $\Gamma$ supplies the available bindings and assumptions. The judgment states that term $t$ has type $\tau$ under that context. Lex uses terms as types and includes dependent function and pair forms in its core syntax.

The language distinguishes ordinary type universes, propositions, rule universes, and temporal sorts. Level discipline prevents a rule from using an unauthorized self-reference through the same rule level. Explicit effect rows identify actions such as reading, writing, attesting, invoking an oracle, or requesting discretion.

A prelude supplies named domain types, constants, and operations. Its identity forms part of the interpretation context. A term that type-checks with one prelude cannot automatically execute against another prelude with different host meanings.

Elaboration resolves surface names into core terms and binding indices. Type checking establishes compatibility with the supplied context. Admissibility checking determines whether the term belongs to a supported fragment. These are distinct checks. An authoring command that performs admissibility checking does not thereby perform every typing or semantic check.

A legal-source reference must remain associated with the rule. The reference identifies the provision being encoded. It does not prove that the encoding correctly expresses the provision. Legal interpretation and technical checking address separate obligations, and both must have accountable owners.

## Defeasible rules

A defeasible rule specifies a default conclusion and exceptions that can defeat it. Each exception has a guard, result, and priority. A guard determines whether the exception applies in the current context. Priority determines which applicable exception controls when the admitted fragment permits several candidates.

For a base result $b$ and admitted exceptions $(g_i,e_i,p_i)$, the intended deterministic selection is

$$
\operatorname{result}=
\begin{cases}
e_k,&k\text{ is the selected highest-priority satisfied exception},\\
b,&\text{no exception is satisfied}.
\end{cases}
$$

The priority relation must have a defined resolution for every admitted overlap. Equal or incomplete priority data cannot be resolved by thread scheduling or hash-map iteration. The public compiler's compact input representation orders exceptions by descending priority and ascending source position. It rejects duplicated ordering keys.

The reference term evaluator propagates an unevaluable guard as an error. This behavior matters when evidence for an exception is missing. Treating the guard as false would silently discard a potentially controlling legal exception.

An exception is not an unrestricted override facility. Its authority and scope come from the admitted rule set. A general exception cannot override terminal sanctions rejection. A rule author must encode that boundary in the applicable admission and execution contracts.

## Frozen and derived time

Lex separates frozen source time from derived time. Frozen time records the historical transition context. Derived time represents a later interpretation, such as a permitted tolling or savings transformation.

The temporal interface exposes a directed lift from frozen time into derived reasoning. It does not expose an object-language coercion that rewrites derived time into frozen source time. The intended information flow is

$$
\mathrm{Time}_0\longrightarrow\mathrm{Time}_1.
$$

A derived assessment must retain the source event and the witness for the derivation. If a later rule changes the interpretation of a deadline, the original event remains unchanged. The new result states the governing rule and derived deadline used for the current decision.

The temporal checker examines explicit temporal forms and rejects invalid stratification. A temporal theorem concerns those forms and the modeled reduction relation. It does not prove that every database timestamp, external clock, or caller-provided string follows the same discipline.

Operational verification must therefore bind the formal temporal object to the event and rule history used by the host. A syntactically valid derived-time term cannot authenticate the external event that it describes.

## Authority-relative interpretation

Some conclusions depend on the authority or tribunal under which a rule is interpreted. Lex represents that context explicitly. A coercion between authority contexts requires a witness for the permitted bridge.

A bridge must identify the source context, receiving context, object being translated, and authority for the translation. A generic function that changes a label does not supply recognition. The receiving evaluator must check the witness and scope before using the result.

Formal bridge coherence can establish that defined translations compose consistently. It does not establish that a real tribunal recognizes the source authority. That external recognition remains an input grounded in the governing legal instrument and authenticated policy.

The same separation applies to model-assisted interpretation. A model can propose a rule or explanation. Its output acquires authority only through the applicable review, attestation, and admission process. Model confidence cannot replace an authority witness.

## Typed discretion holes

A discretion hole names a judgment that mechanical evaluation cannot supply by itself. Its type specifies the required result. Its authority identifies who may supply that result. Its scope restricts where the result can be used.

For example, a rule can require an authorized assessment of whether specified controls are adequate. The surrounding mechanical checks can establish document presence, identity, and signature scope. They cannot manufacture the substantive judgment merely because the operation needs it.

A fill must bind the hole identity, result, signer, subject, jurisdiction, and relevant temporal scope. Admission must verify both type compatibility and authority. A nonempty signature field is insufficient. Verification must authenticate the exact payload under the correct key and policy.

Public Lex distinguishes structural fill validation from cryptographic fill admission. The plain fill path checks witness structure. The verified fill path invokes a supplied `PCAuthVerifier`. The public implementation includes an HMAC verifier. A deployment requiring asymmetric signatures must supply the corresponding verifier and use the verified path.

An unfilled hole remains an obligation. The strict executable admissibility checker rejects hole and fill forms. The residualized admission mode accepts selected frontier forms only while recording obligations such as fill-time authority and signature verification. Acceptance in that mode cannot be reported as a fully mechanical verdict.

## Certificates and obligation discharge

A proof obligation is a condition that must be established before a rule can support the claimed result. The decision procedure can prove the condition, refute it, or leave it undecided. Only a proved result is a discharge.

The certificate builder records the rule digest, jurisdiction, legal basis, verdict, discharged obligations, issuance time, and optional subject and typed scope. The certificate digest commits to its canonical content. A consumer must verify the digest and the required scope bindings before relying on the certificate.

The public sealing interface rejects refuted and undecidable decision results. Its structured witnesses improve the construction boundary, but a serialized object remains untrusted input. Deserialization, transport, or a caller-supplied certificate must not bypass the checks required by the receiving host.

A certificate's type and digest do not provide public-key authentication by themselves. The issuer's signing layer must authenticate the claim where the operation requires an authoritative attestation. The verifier must also check that the certificate covers the exact rule and operation, including the subject and jurisdiction.

## Execution and formal boundary

Public Lex contains several distinct surfaces: parser and elaborator, strict and residualized admission, reference term reduction, runtime predicate evaluation, and frontier calculus types. Their scopes overlap but are not identical. The fiber-composition convenience function currently emits `Pending` results without certificates.

The formal development contains scoped closed results for temporal non-regression, pack reevaluation, receipt composition, quorum structure, and admission-envelope structure. Full-calculus progress remains conditional on confluence and match exhaustiveness. Preservation retains a substitution premise. Full unconditional type safety and normalization are not established by those conditional statements.

A theorem ending in a closed proof can still require an unproved premise. A model's lack of admitted proof commands does not discharge named propositions supplied as hypotheses. The specification preserves those hypotheses when describing the theorem's operational significance.

The canonical public contract and proof scope are available in the [Lex language reference](https://github.com/momentum-sez/lex/blob/master/docs/language-reference.md) and [formal documentation](https://github.com/momentum-sez/lex/blob/master/formal/README.md). A deployment must identify its actual dependency revision and admitted fragment.

# Op: Typed Economic Programs

Op describes workflows that perform economic actions through an embedding host. It gives those actions types, effects, ordering constraints, resource discipline, contracts, and gas accounting. The host supplies the concrete primitive behavior and durable execution services.

## Program and host boundary

An Op program contains statements, steps, expressions, metadata, and contracts. A typing judgment includes an effect row:

$$
\Gamma\vdash e:T\;!\;E.
$$

The result type $T$ describes the value or resource produced. The effect row $E$ describes effects that execution may perform. Combining expressions combines their effects according to the language rules.

The public host interface accepts a primitive call with named arguments and an ambient jurisdiction. It returns either a completed value or a waiting outcome with an event identifier and resume token. It can also reject a call for policy, argument, transient, or permanent failures.

A host must discharge declared safety predicates against the actual context. The default safety implementation refuses undischarged predicates. A test host that echoes arguments and accepts every predicate cannot establish production execution.

Host determinism requires recorded external observations. Given the same program, inputs, policy, and observation transcript, replay must reproduce the specified result. A live network call that returns a new answer is a new observation. The host cannot call that behavior deterministic replay of the earlier execution.

## Effect rows and sanctions dominance

Effect rows compose by set union. The public vocabulary includes sovereign writes, identity mutation, fiscal transfer, sanctions checks, governance requests, document generation, external reads, proof emission, and event waits.

Set membership alone does not establish safe order. A program that contains a sanctions check after a payment still contains both effects. The analyzer must establish that every reachable write-class effect has a dominating sanctions check on its execution path.

For a write site $w$ and required check $c$, dominance means that every admitted path to $w$ passes through $c$. Branch analysis must preserve that property. A check in one alternative does not protect a write in another alternative. A check on an unrelated subject does not satisfy the operation's runtime subject binding.

The public analyzer inspects both declared steps and expression-level primitive calls. Unknown primitives cannot default to pure behavior. A caller-provided signature cannot justify an effect absent from the canonical primitive contract.

Entity creation has a deferred-subject case because the final entity identifier does not yet exist. This exception requires the host to preserve the authorized creation context and subsequent checks. It does not permit an arbitrary existing subject to bypass screening by labeling the action as creation.

A source-level dominance check establishes program structure. Runtime admission must still verify the screening result, relevant subjects, freshness, and terminal rejection behavior. Neither layer replaces the other.

## Suspension and completion

A suspended step carries an awaited event and result type. Suspension is a valid execution state. It records that the required effect or external acknowledgment has not yet completed.

A durable continuation must bind the program and input identities, completed work, authority, waiting condition, and relevant state. The callback must identify the continuation it can resume. An unrelated event, expired authority, or mismatched subject must not advance the operation.

The distinction between completed and waiting outcomes must survive every adapter. An HTTP acceptance response can acknowledge a request while the underlying economic action remains pending. A provider job identifier proves only that a job was accepted unless the provider contract states otherwise.

The execution engine must record completion only after the required effects and acknowledgments exist. A document-generation job, signature ceremony, payment instruction, and regulator filing can each have different completion criteria. Op's type can carry those distinctions, but the host must implement them.

## Durable continuation contract

A durable continuation is the checked machine state at a suspension boundary. It must contain enough information to resume the remaining computation directly. Re-executing the source program from its root is not restoration, even when an implementation attempts to suppress repeated effects.

The required continuation binds the checked program and runtime profile to a host identity, instance identity, and nonce. It also binds the execution ordinal, logical work consumed, control state, environment, frames, signed history, accumulated effects, and pending request. These fields prevent a stored control position from being combined with another execution's authority or values.

Let $K$ be a checked continuation and $\operatorname{encode}_p$ its encoding under profile $p$. Before accepting transferred state, the receiving host must establish

$$
\operatorname{decode}_p(\operatorname{encode}_p(K))=K.
$$

The equality concerns the complete checked state. A digest match for an incomplete projection does not establish the required round trip. Profile identity must cover the semantics needed to interpret the state. A runtime-source digest alone does not attest the host adapter, build, key custody, or storage configuration.

Admission of a continuation event must authenticate the stored state and check current authority for the requested action. Historical authorization proves that earlier work was admitted. It does not authorize every future action after expiry, revocation, or transfer.

The host must atomically record authority consumption, the resulting continuation, and the command receipt. Invalid admission must leave pending work unconsumed. An exact retry returns the committed receipt without executing the runtime again. The retry identity must bind the command payload, so a different command cannot reuse that receipt.

Restoration and transfer must create no new dispatch or discharge. The restored history records what occurred. The pending request records what still requires admission. Economic effects need their original delivery identities, reservations, and acknowledgment states so that a transfer cannot duplicate an unacknowledged obligation.

When execution moves between hosts, the source must fence further initiation before the successor becomes active. The transfer must include admitted preparation changes and the exact authoritative state cut. Exactly one successor may own the execution generation. Every later action requires that generation and action-specific current authority.

This is the normative continuation contract. Reference constructions motivate it, but complete production refinement is not established here. Whole-state rollback requires an external monotonic freshness anchor. Cloned stores require exclusive custody or effective fencing. Authenticated storage without those properties cannot distinguish the latest legitimate state from a coherent older copy.

## Compensation and resource discipline

Compensation is an authorized action that addresses the consequences of an earlier effect. It is not a claim that history can be erased. Releasing a reservation can compensate for a failed allocation. A refund creates a new economic event rather than deleting the original transfer.

An Op step can declare a compensation branch where its effects permit compensation. The analyzer rejects compensation without a compensable effect. It also rejects a continue-on-failure policy that would conceal a failed sovereign write.

The host must preserve the order and outcome of compensation. A failed compensation remains a recorded obligation. Retrying it needs the original causal identity and an idempotency contract. Completion of the forward workflow cannot be inferred from successful compensation.

`Linear<T>` represents a resource whose permitted use is constrained by the type system. `Locked<T>` represents a resource reserved for a transfer decision. The modeled lock has explicit commit-transfer and release-lock eliminators. Copying a serialized handle must not create another spendable resource.

The public checker implements resource-use checks, while the formal full-AST linearity and lock-duality results remain open. Durable enforcement additionally requires the host's transactional ownership and lock state. A compile-time resource discipline alone does not prevent two independent requests from racing on the same database row.

## Structural and extensional gas

Structural gas accounts for the program's syntactic work. Extensional gas accounts for work that depends on runtime data, such as collection size or host-call volume. The program and host must identify which schedule governs each quantity.

A meter maintains consumed amounts and configured limits. A charge succeeds only when the resulting amount stays within the relevant limit. The public meter returns a gas-limit error when a charge would exceed the limit. That error does not itself establish a persisted suspension point or a resumable continuation.

A cardinality certificate can bind an assumed data-size bound. The host must check the certificate's origin, scope, and relationship to the actual data. A claimed list bound does not constrain an unrelated collection or later provider response.

A structural estimate is not a runtime cost proof for every host. The formal gas result establishes termination for an abstract relation with a strictly decreasing natural-number measure. Instantiating that relation with the complete Op semantics remains a separate obligation.

Gas accounting also differs from economic pricing. A deployment can charge money for execution, but price changes must not silently change the language's admission semantics. Program metadata must identify the schedule used when bounds and digests were produced.

## Contracts and proof bundles

Contracts attach requirements and guarantees to a program or step. A Lex rule reference identifies the rule and the structural discharge requirement expected from the program. The binding must include the relevant pack version and jurisdictional scope.

Structural discharge checks that the program carries the required witness shape. It does not prove that every host execution produces a legally sufficient certificate. Full joint Lex–Op discharge soundness remains an open formal obligation.

A proof bundle should bind the program, inputs, admitted authority, rules, execution transcript, resulting facts, and required evidence. The bundle must identify which parts support exact replay and which depend on attested external observations. Optional fields must remain absent when their producer has not run.

Two bundles can be compared only under a defined equivalence relation. Byte equality requires deterministic encoding and identical committed inputs, including time and external observations. A claim of semantic equivalence needs a separate definition. The book does not infer universal proof-bundle equality from compiler success.

## Implementation boundary

Public Op supplies the language structures, checker, effect analysis, gas primitives, compiler components, and host contract. Its core exports do not currently include the complete evaluator described by some module introductions. A separate reference interpreter covers the compiler's supported expressions.

Mass has an adapter evaluator and compilation path with its own representation. Its conformance profile explicitly retains migration residuals for canonical encoding, primitive-registry parity, and gas-schedule parity. Public language ownership therefore does not imply that every Mass-produced program is portable public Op without qualification.

The public formal development contains closed fragments for effect algebra, bundle append behavior, abstract gas decrease, and smaller calculi. It does not establish full-AST progress, preservation, parallel confluence, or compiler correctness. The [Op formal scope](https://github.com/momentum-sez/op/blob/main/formal/README.md) states these boundaries.

# From Rules to Executed Evidence

A complete regulated operation connects a rule to an authorized execution and a durable result. Each boundary must preserve the identities needed to verify the next boundary. A successful parser, signed payload, or persisted response establishes only its own part of that chain.

## Admission stages

The normative pipeline begins with the exact rule, program, subject, inputs, and authority presented for execution. It resolves the applicable rule set and checks content identities before evaluating their meaning. Unresolved references, unsupported encodings, or mismatched scope block admission.

Lex admission establishes the supported rule fragment and exposes any remaining discretion or proof obligations. Compilation then lowers only the admitted computational content. Op checking establishes the required types, resource rules, and effect constraints for the emitted program.

The host checks current authority and context before executing a material effect. It records the actual result and required acknowledgments. The mutation boundary must bind the authorized action to the durable change and its evidence. Completion depends on the operation's required effects, rather than the existence of a response envelope.

The stages are logically ordered but need not correspond to separate network calls. An implementation can combine checks in a transaction or reuse verified immutable artifacts. Reuse is valid only when the artifact's context, revision, authority, and freshness remain suitable for the new decision.

## Compilation boundaries

The public Lex-to-Op compiler consumes its own compact `LexTerm` representation. Its admitted forms include first-order values, variables, finite matches, defeasible rules, sanctions checks, filled holes, and registered prelude calls. Its constructor set excludes several full Lex forms by construction.

The compiler first checks admissibility, emits an Op program, and runs the public Op checker over that output. It returns a structured error for unsupported calls, unbound variables, unsuitable match coverage, or rejected output. These checks provide a concrete executable boundary for the represented fragment.

Mass also has a lowering path from the larger Lex term representation into its adapter expression representation. Some forms become named helper calls. Producing a call name does not establish that the host implements its semantics. Admission must resolve the helper against the actual host and reject an unsupported call.

The desired compiler contract is semantic preservation over the precisely admitted domain. If $L$ is an admitted rule and $\llbracket L\rrbracket$ its program, corresponding execution observations must agree under compatible contexts and hosts. The relation must include errors, authority requirements, suspension, and effects where those are in scope.

Current fragment results do not prove that contract for the full language pair. Extending an AST match to cover another constructor is not a proof of semantic preservation. The extension must supply the lowering rule, receiving-host meaning, admission conditions, and corresponding verification evidence.

## Verdict and proof roles

A verdict records the decision and its reasons. A proof envelope binds a claim and issuing context to evidence that a verifier can examine. The proof may embed a verdict or reference it by content identity. If both appear, the embedded verdict must reproduce the referenced digest.

The claim identity must remain distinct from the program identity. A program can execute repeatedly with different inputs and subjects. The resulting claims must bind those particular executions. Likewise, an authority-chain digest identifies the authority presented, rather than the truth of the result.

The implemented Mass proof structure carries subject, sovereign domain, issuing authority class, epoch, claim digest, optional verdict binding, and reproducibility class. It also carries an optional authority binding, admissibility fields, residuals, and signature. Transport fields can contain immediate consumer-facing output. The signature covers a defined canonical body rather than every transport field.

A verifier must identify that signed body. It must not treat an unsigned output field as authenticated merely because it appears beside a signature. A referenced artifact must be retrieved and checked against its digest before it contributes to the decision.

The source's admissibility helper checks structural conditions, including a verdict reference, complete sovereign domain, empty blocking fields, and a suitable signature representation. Cryptographic signature verification is a separate operation. Trust policy, scope, freshness, and referenced content checks remain necessary for reliance.

## Persistence and external acknowledgment

Durable mutation, authenticated inclusion, and external anchoring are separate events. A database commit proves that the database accepted a transaction under its configured durability contract. An inclusion proof establishes membership under a particular authenticated root. An external anchor supplies evidence about a root's submission and acceptance by another system.

An operation claiming all three must produce and bind all three. If an anchor remains pending, the response must report that state. It cannot use a locally recorded anchor object as evidence of completed external submission.

The public authenticated-storage components provide MMR operations, WAL replay, and disk recovery. Their typed graph API remains unimplemented. Migration-lens registration stores metadata and does not verify a transformation's bijection. Consequently, a schematic Lex–Op–storage diagram cannot establish complete graph persistence, historical query preservation, or recurring external anchoring.

The normative storage contract remains stronger: retain the original evidence and schema identity, verify claimed inclusion, preserve historical interpretation, and expose missing producers. A completed operation must satisfy the evidence requirements of its declared completion class. Implementation gaps remain explicit obligations against that contract.

## Reproduction classes and evidence limits

Exact replay requires the same admitted program, encoding, input facts, rule and prelude identities, host semantics, and observation transcript. Attested external facts can support verification without permitting independent reproduction of the underlying external event. A discretionary decision can be authenticated without becoming a mechanical derivation.

These distinctions must survive in the result. A verifier should be able to determine which statements it can recompute, which signatures it can verify, and which external authorities it must recognize. A proof envelope cannot improve the evidentiary class of its inputs by renaming them.

Execution evidence must identify the integrated program and runtime profile, configuration, subject, authority, causal request, and durable result. Tests against an echo host do not establish provider execution. Formal model proofs do not establish database behavior. A successful database write does not establish an externally accepted legal filing.

# Authoring Rules and Operations

## Establish the rule before the workflow

An author begins with a concrete obligation and its legal basis. The author identifies the relevant subject, action, jurisdiction, effective period, conditions, exceptions, and competent authority. The resulting rule must state what evidence establishes each condition.

Consider a hypothetical entity-record amendment. Its operation contract requires an authorized amendment request, the governing approval, a signed document, and an authority receipt where the selected rules require filing. This example specifies a workflow shape. It does not assert the legal requirements of any named jurisdiction.

The author must distinguish approval of the amendment from acknowledgment of the filing. A board approval cannot stand in for a regulator receipt. A generated document cannot stand in for the signers' executed document. An uploaded receipt cannot stand in for a verified receipt about the correct amendment.

These distinctions determine the types and predicates before the author chooses an operation sequence. Combining them into a generic success flag would remove the evidence needed to evaluate completion.

## Build a typed rule and its evidence requirements

The amendment rule binds an entity $s$, proposed amendment $m$, approval $a$, document $d$, and optional receipt $r$. Its required predicates are the conjunction of these three expressions:

$$
\operatorname{about}(a,s,m)\land\operatorname{authorized}(a,s,m)
$$

$$
\operatorname{documentMatches}(d,s,m)\land\operatorname{signaturesValid}(d)
$$

$$
\operatorname{screeningPasses}(s,m)\land\operatorname{receiptCondition}(r,s,m).
$$

This is specification notation, not executable Lex syntax. Each predicate needs a supported prelude operation or an explicit authority obligation. The receipt condition must distinguish a rule that does not require filing from a required receipt that remains absent.

The author then defines adversarial cases. An approval for another entity must fail. A signature over a different document digest must fail. A receipt with the wrong amendment identity must fail. An unknown screening result must remain pending or produce the specified error. A sanctions rejection must stop the proposed mutation.

If the rule includes discretion, the author declares the hole's type, authority, and scope. The operation must expose the outstanding decision to the responsible authority. It must not replace the hole with a default Boolean value.

## Use authoring tools within their scope

The public Lex CLI provides parsing, elaboration, admissibility checking, and authenticated source bundles. Its `check` command parses the source and calls the admissibility checker. It does not establish every full typing, legal interpretation, or execution property described in these chapters.

The CLI's `sign` operation currently uses HMAC-SHA256 over the source content digest. The verifier needs the corresponding shared secret. This provides symmetric authentication within that trust arrangement. It is not public-key signing for an independent verifier that holds only a public key.

Production rule publication must use the signing authority and cryptographic suite required by the deployment. Hardware custody, asymmetric verification, approval ceremonies, and publication authorization require their own implemented controls. They cannot be inferred from a command named `sign`.

Authors must record the exact toolchain, prelude, and admitted fragment used for a published rule. Compiler and runtime identities belong in the artifact's machine-readable metadata. The human specification names the contract without freezing a stale dependency revision into prose.

## Assemble the operation

The operation begins by resolving the subject and amendment under the caller's authority. It obtains the required governance decision, produces the correct document, waits for executed signatures, and obtains any required external receipt. Only then may it perform the final state change that the contract permits.

Independent read-only preparation can run concurrently. Dependent actions must wait for their required evidence. A filing step cannot proceed with an unsigned document merely because document generation completed. A final mutation cannot proceed because the filing request returned an acceptance identifier.

The operation definition must specify waiting outcomes, retries, compensation, and terminal failures. Each provider interaction must carry a stable causal identity. A timeout means that the outcome is unknown unless the provider contract proves otherwise. Retrying an unknown outcome requires an idempotency or reconciliation mechanism.

When an approval or receipt arrives, the engine must validate its subject, action, digest, authority, and current admissibility before resumption. It must restore the checked continuation under the durable continuation contract. It must not restart earlier effectful steps to rediscover the wait point.

## Publish, execute, and verify

Publication requires a content-addressed rule and program, compatible policy and prelude identities, validated operation contracts, and the authorized publisher's signature. The receiving deployment must verify those bindings before exposing the operation for execution.

A publication success response establishes catalog admission only. It does not establish that an organization completed the operation. Execution acceptance must cover the actual subject, authority, required effects, durable acknowledgments, and final decision.

Verification should follow the failure boundaries identified during authoring. Check a valid path and the material refusal paths. Preserve the original signed evidence and causal identifiers. Inspect the final durable state and required external acknowledgments before reporting completion.

For the amendment example, the acceptance record must connect the requested amendment to its approval, executed document, any required receipt, resulting entity state, and proof. If the receipt remains outstanding, the operation remains outstanding. If the evidence conflicts, the decision must expose that conflict and preserve the original records.

## Remaining proof obligations

The full design requires a semantics-preserving path from admitted Lex rules through Op execution to durable, authority-bound evidence. It also requires safe continuation transfer, complete provenance, and verification of every externally claimed acknowledgment. These remain requirements even where an implementation currently covers only a fragment.

The unresolved formal work includes full-calculus Lex confluence and preservation premises, full-AST Op type and effect soundness, joint discharge soundness, and host refinement. The unresolved operational work depends on the particular deployment and route. A bounded implementation result must state its scope while retaining the complete target contract.
