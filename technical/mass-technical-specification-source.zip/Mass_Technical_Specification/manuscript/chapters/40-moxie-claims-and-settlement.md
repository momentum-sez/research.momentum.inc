# Claims and admissible obligation transitions

An organization creates obligations when it issues shares, borrows, buys goods, promises a royalty, or accepts a contingent payment. Mass governs the organization and the authority under which it acts. Moxie prices, clears, and settles the claims that arise from those obligations. Their connection must preserve the issuer, governing terms, settlement asset, and evidence of performance through each transition.

These chapters define the required architecture with *shall*. An implementation boundary states the narrower behavior established by current implementation inspection. A defined record or algorithm does not establish a deployed service. Runtime acceptance requires execution evidence for the complete path, including durable effects and recovery after interruption.

## A claim has economic content and an institutional owner

A **claim** identifies a right to a specified payoff under specified conditions. Its economic description includes the settlement asset, payoff program, dependencies, valuation inputs, and period of validity. Its institutional description identifies the issuer, holder, instrument, and legal profile. The legal profile binds the applicable terms and authority requirements.

The claim identifier commits to its canonical content. A change to settlement mode, payoff, terms, or another committed field changes that content. A service shall preserve the distinction between an instrument's continuing identity and a particular claim description. It shall not edit an admitted claim while retaining a commitment to the original bytes.

The holder field alone cannot describe every beneficial position. A pooled claim may name an operator while a position ledger records individual entitlements. Transfer and redemption shall therefore bind the relevant position owner as well as the claim identifier. The operator's control of a pool shall not imply ownership of every entitlement within it.

Consider a supplier's receivable. The institutional record identifies the supplier, buyer, contract, and authority to issue the receivable. The payoff specifies the amount due when accepted delivery occurs. A valuation can discount that expected payment. An assignment can change who holds the entitlement. Settlement must consume the correct entitlement against the correct obligation, even when these records reach different systems at different times.

## Payoff programs and temporal dependencies

A **payoff program** computes a value from committed constants, authenticated evidence, and previously resolved claim values. The program shall use deterministic arithmetic and bounded evaluation. Its commitment binds the operations, operands, ordering, and output selection. An evaluator shall reject a missing input rather than substitute an estimate.

Within a program, each operation may reference only earlier operations. References to another claim's resolved value use a strictly earlier block. In the time-expanded dependency graph, every edge therefore points to an earlier observation:

$$
(c,h) \longrightarrow (c',h-\delta), \qquad \delta \geq 1.
$$

Here $c$ is the claim, $h$ is its evaluation block, and $\delta$ is the declared historical offset. This rule prevents current-block circular evaluation. A dependent payoff cannot require a value whose computation waits for that same payoff. Historical availability remains a separate requirement. Admission shall reject a dependency whose required history cannot survive until consumption.

Current payoff structures include constants, evidence inputs, claim references, arithmetic, caps, floors, conditions, and bounded historical reductions. A historical average and a terminal payment are different operations. The average consumes a declared sequence of observations. The payment consumes an entitlement after the terminal value has resolved.

The settlement mode makes this distinction explicit. **Path resolution** publishes a value indexed by block. **Terminal resolution** fixes one payoff value for subsequent holder redemptions. Repeated path observations shall not mint cash entitlements. Distinct holders may redeem against one terminal value, but each redemption must consume an entitlement that the system already recognizes.

## Probability-weighted discounted cash flows

A probability-weighted discounted cash-flow bundle, or **PDCF bundle**, records a valuation at an identified observation block. Each line contains a signed amount, payment block, probability weight, discount factor, and evidence commitment. The bundle also commits to its probability model, discount curve, and common settlement asset.

Its present value is the deterministic sum

$$
V_h = \sum_{i=1}^{m} a_i p_i d_i.
$$

The signed amount $a_i$ represents an inflow or outflow. The probability $p_i$ satisfies $0<p_i\leq1$. The discount factor $d_i$ is positive. A factor above one remains representable, including for negative-rate assumptions. All payment blocks must satisfy the bundle's temporal rules. Multiplication and accumulation shall detect overflow.

This equation defines a valuation representation. Its interpretation depends on the model that supplied the lines. A model must identify the information set, scenario construction, recovery assumptions, and treatment of mutually exclusive outcomes. Lines that represent separate payments need not have probabilities summing to one. Alternative outcomes of one payment require a model that avoids counting the same payment twice.

For an illustrative receivable, let the amount be 100 settlement units, the payment probability 0.90, and the discount factor 0.95. The bundle yields 85.5 units. That number is a model value. The contractual face remains 100 units unless the terms provide otherwise. Cash in custody remains whatever the custodian actually holds. A legal decision on entitlement requires its own authority and evidence.

A PDCF commitment permits another evaluator to reproduce the calculation from the same inputs. It does not certify the inputs' accuracy or the legal enforceability of the cash flow. A change in estimated probability can change valuation without changing contractual entitlement. A legal amendment can change entitlement and require a new payoff commitment, even if its estimated value stays constant.

## From an authored graph to a terminal contract

A **ClaimGraph** is the typed source representation used to author a product. It records parties, claims, obligations, conditions, and the relationships required by a claim program. A **template pack** supplies the admitted product family and its structural requirements. The compiler validates their agreement before lowering the graph.

The compiler produces an **admissible obligation transition**, or **AOT**. This is the terminal contract consumed by the clearing and settlement architecture. The graph remains available as provenance for the product's meaning. Consensus evaluates the admitted transition under generic rules rather than creating a separate consensus mechanism for each product family.

An AOT binds the following components:

| Component | Required binding | Purpose |
|---|---|---|
| Admission | Principal, signer, nonce, validity and authority | Identifies whose action can commit capital |
| Instrument and obligation | Terms, template, legal profile and graph | Identifies what the parties undertake |
| Compliance and evidence | Attestations, revocation state and source roots | Binds admissibility and observed conditions |
| Execution and reserve | Venue evidence, asset, custody and capital lock | Binds economic effects to funded capacity |
| Settlement and receipt | Job, batch, asset and receipt reference | Connects intent to its resulting execution |
| Release and reliance | Disposition, permitted parties and purposes | Controls subsequent use of the result |

An internally consistent AOT can still lack authority, funding, or available execution support. Admission shall validate each component against the current authoritative state. Equal hashes establish equality of committed descriptions. They do not grant a signer power over an account.

## Implementation boundary

The implementation contains typed claims, PDCF bundles, payoff programs, ClaimGraph validation, and deterministic AOT lowering. Path-resolved claims currently refuse payoff programs that require external oracle evidence. They also reject supplied evidence openings because this mode lacks persisted AOT evidence authority. The admission envelope currently binds signer to principal until authenticated AOT delegation exists. A delegated application must preserve that restriction at submission.

Product definitions and lowering support do not establish a complete issuance or trading service for every represented family. Each family also needs admitted authority, usable custody, settlement support, and evidence through its intended API. The custody and availability chapters specify current restrictions that remain material after compilation succeeds.

# Institutional authority, compliance and recognition

An executable payment needs a valid instruction from a party entitled to give it. A regulated payment also needs admissible counterparties, instruments, and destination conditions. Mass and Moxie carry these requirements across their boundary through typed records with explicit signatures, commitments, validity, and revocation state.

## Authority follows the action

Mass owns the institutional state and operation authority that it issues. Moxie owns admission to its execution state, consensus, clearing, settlement, and native finality. A bridge transfers statements between those authorities. It shall not merge their signing powers or imply that one system may write directly into the other's authoritative state.

An authority record shall bind the principal, signer, permitted action, object scope, validity, and relevant policy. A receiver must establish both signature authenticity and permission for the requested action. A correctly signed valuation report cannot authorize a custody debit. An institution's authority to issue a claim cannot authorize an unrelated party to liquidate it.

The receiver shall enforce replay protection in the authority's domain. Chain identifiers, account nonces, source heights, source nonces, and application idempotency keys have different meanings. An adapter shall preserve them as separate fields. Deriving one from another would conceal the distinction between a repeated request and a newer authoritative statement.

Current state checkpoints carry source height and source nonce as independent coordinates. Their admission checks require monotone progression and authenticated signatures. Reverification of an existing checkpoint must not consume a new nonce. A recovery process must be able to verify retained evidence without impersonating a fresh authority action.

## The product legal profile

A **product legal profile** commits to the jurisdiction and policies governing an instrument. It binds legal terms, eligibility, product boundaries, disputes, finality recognition, recovery, reporting, and permitted reliance. The profile also carries its validity period and revocation epoch.

This separation permits several products to use the same execution machinery while retaining different obligations. A trade receivable, an equity interest, and a loyalty entitlement can share deterministic settlement components. Their transfer rights, disclosures, eligible holders, and recovery rules remain different. A common token representation shall not erase those differences.

The admission process shall verify the specific product structure demanded by its profile. Where a profile requires a Shariah Supervisory Board attestation, the claim must carry the required issuance-specific commitment. The product structure must also match the declared family. A favorable Sharia compliance coordinate alone does not establish those structural or issuance requirements.

The same rule applies to other evidence. An identity attestation concerns its subject and validity period. It does not establish beneficial ownership of every position controlled through that subject's software. An instrument attestation concerns its declared object. It does not certify all future amendments or secondary transfers.

## Compliance is evaluated at the consuming transition

The compliance record covers the canonical 23 domains and distinguishes applicability from evaluation state. A receiver shall validate the canonical shape before combining domain results. It shall retain unknown, pending, expired, and revoked conditions where the contract requires them. Conversion between wire formats shall preserve their meaning.

Claim admission checks the claim's period of validity and the holder's attestation. It checks attestation expiry, subject revocation, jurisdiction agreement, and the legal profile's revocation epoch. A previously admitted attestation can therefore cease to support a later economic action. The resulting refusal does not erase the historical record of its earlier admission.

For an action $x$ at block $h$, the required decision has the conceptual form

$$
\operatorname{admit}(x,h)=
\operatorname{authority}(x,h)
\land \operatorname{eligible}(x,h)
\land \operatorname{funded}(x,h)
\land \operatorname{supported}(x,h).
$$

Each predicate names a distinct obligation. Their conjunction is an admission rule, not a claim that every deployed path currently performs every check. The settlement path shall repeat the checks whose truth can change between reservation and execution. A preflight result cannot carry authority across an intervening revocation.

Suppose an institution reserves funds while a holder's attestation is valid. Before execution, the issuing authority revokes that attestation. A retry using the original signed instruction must encounter the newer revocation state. Signature validity and an unchanged request identifier do not restore eligibility. The failed execution must leave the reserve disposition consistent with the applicable cancellation or recovery policy.

## Issuance provenance and the claim manifest

A **claim manifest** records the institutional origin of an issued claim. It binds the sovereign domain, entity envelope, terms program, and compliance state at issuance. It also names the signing-authority class, legal tradition, template and revision, replay class, and append-only interpretation reference. Its canonical content determines its address.

A downstream reliance record shall identify that manifest and preserve the issuance authority chain. The referenced entity envelope must identify the institution whose rights or obligations the claim represents. A clearing-layer record alone cannot supply missing institutional issuance authority. Later interpretations must retain their relationship to the original act and identify any separately authorized change to economic rights.

The current issuance-chain helper checks structural preconditions. It requires a Mass manifest anchor, consistent manifest references, and a syntactically valid entity-envelope reference. It also requires both the terminal authority link and manifest authority class to be `Zone`. These checks do not resolve every referenced record, authenticate every chain link, or establish deployed receiving-side acceptance. The caller must resolve the cited manifest before invoking the helper.

## Typed compliance assertions and verification scope

A compliance assertion binds the entity identifier, optional operation reference, participating jurisdictional contexts, tensor commitment, classification, and validity times. An optional instrument hint remains advisory. The receiver shall compare the signed subject and operation with the action it intends to admit. Signature verification alone does not establish that contextual match.

The current envelope helper checks protocol compatibility, maximum age, future-clock allowance, expiry, and tensor commitment. It recomputes the classification and rejects disagreement with the asserted tier. For a classified assertion, it also requires at least one explicit `Compliant` or `Exempt` domain. An assertion containing only declarations of non-applicability cannot pass that substance guard.

The helper verifies Ed25519 over the canonical assertion. Its ML-DSA result is explicitly unchecked: `ml_dsa_ok = None`. A present post-quantum signature therefore receives no verification credit from this helper. The deployment must demonstrate the required upstream verification before claiming hybrid authentication. These helper results also leave the refused REST admission paths unchanged.

## Source classification and receiving execution policy

**Temperature** names a compliance-related tier. The source classifier and receiving execution policy use different domain mappings. A bridge shall preserve those mappings explicitly rather than equate tiers by their names.

The Mass classifier requires explicit passing entries for KYC, AML, and sanctions to reach Cold. Warm additionally requires securities, corporate, and custody. Hot requires explicit passing entries across all 23 domains. A missing minimum entry yields Unclassified. In this classifier, passing includes `Compliant`, `Exempt`, and explicitly stated `NotApplicable`. The envelope's separate substance guard still applies.

The receiving temperature model uses a distinct projection:

| Receiving tier | Required active domains | Additional condition |
|---|---|---|
| Cold | Consumer protection and AML | Minimum trading surface remains satisfied |
| Warm | Cold domains plus KYC, securities, and qualified investor | Target-domain gate passes |
| Hot | Warm domains plus full registration, market surveillance, and disclosure | Target-domain gate passes |

These receiving labels do not certify registration, investor qualification, or any other legal status by themselves. They express which domain evidence the model demands. The admitted product profile and action-specific authority remain separate requirements.

The transition helper rejects a request whose source and target tier are equal. An upgrade requires every domain for the target tier. A direct Cold-to-Hot request can pass only with the full Hot set, which includes the Warm requirements. Downgrades pass this helper without an upgrade gate. The receiving consumer separately derives the highest supported regime and handles suspension when its minimum domains fail.

This receiving consumer is not an authoritative end-to-end producer path. Its richer internal observations have no direct public transaction carrier or live Mass producer. Current compound-cycle code derives default grades from cached legacy KYC data. That inference cannot establish the separate domain attestations demanded by the target contract.

The complete bridge shall bind the authentic source evidence to an explicit receiving projection and preserve jurisdiction, freshness, revocation, and missing-domain conditions. Until that projection has an authoritative producer and admitted execution path, a source classification cannot establish a receiving market entitlement. Trading activity itself cannot supply the missing compliance evidence.

## Advisory signals remain evidence

Market observations can inform a valuation or trigger a request for review. Their admission must retain the source, observation time, object, and permitted use. An advisory observation shall not become a compliance decision by passing through a differently named endpoint. A market price shall not become an instruction to move an organization's funds.

A receiver must authenticate the producer authorized for that signal type. It must also distinguish publication from consumption. A durable record that a signal arrived proves arrival. A later operation needs its own record showing how it used that signal, which policy applied, and who authorized the resulting action.

This principle also governs automated reasoning. An agent can prepare terms, estimate value, or propose a settlement. The receiving authority still evaluates the concrete action against its policy and state. Reproducible reasoning helps explain the proposal. Execution authority must come from the authenticated principal and the applicable delegation rules.

## Bilateral recognition and corridors

A **corridor** carries recognized evidence and coordinated obligations between deployments. Its recognition terms are directional. Let $R_{A\leftarrow B}$ describe the evidence classes that deployment $A$ accepts from $B$. Let $\phi_{A\leftarrow B}$ describe the permitted projection into $A$'s decision model.

Acceptance by $A$ does not imply acceptance by $B$. A corridor shall bind both directions explicitly when an operation needs bilateral recognition. The terms must identify accepted signing authorities, subject scope, compliance domains, validity, revocation behavior, and dispute procedures. Recognition of one domain shall not silently waive another domain's checks.

A cross-border claim needs additional economic bindings. Both sides must agree on the claim or obligation references, principals, assets, quantities, rates, and terminal effects. A payment confirmation on one side must refer to the same transaction that the other side reserved. An exchange-rate observation without bilateral acceptance cannot determine an enforceable redemption rate.

Coordination shall retain durable locks, fencing information, acknowledgements, and recovery decisions. A local timeout alone cannot establish that the remote side failed to commit. The recovery protocol must distinguish absence of a response from evidence of abort. Compensation requires its own authorized transition when an external effect has already become final.

The chapters on corridors and dispute resolution define the broader Mass protocol. For Moxie, recognition must also bind native finality to the permitted external purpose. Recourse may supply an outcome through an admitted execution contract. Its administrative record cannot substitute for Moxie consensus authority or proof that recovery occurred.

## Implementation boundary

The current REST boundary refuses three material write paths. `/api/v1/compliance/assert` can verify an envelope but lacks a consensus transaction that admits that assertion. `/api/v1/orders` therefore refuses the dependent order request. It does not allocate a nonce, build an order, sign it, or submit it.

The advisory route `/api/v1/compliance/signal` also refuses requests because governed proxy authority is absent. Native signed Mass attestation and revocation transactions exist separately. Their presence does not make these REST routes operational.

Corridor administration and redemption remain refused by the transaction availability policy. Redemption requires a typed bilateral certificate binding both principals, rate terms, and monotone revocation state. A general Recourse award certificate carrier also remains absent. Award verification, dispatch, finality verification, and recovery reconciliation require further implementation before an award can drive a complete Moxie execution path.

# Custody, clearing and settlement

Settlement must connect a valid obligation to value that the system can deliver. A receipt for an unfunded promise records the promise. It does not create the asset needed to discharge it. The clearing architecture therefore binds obligations to named assets, custody accounts, reserves, and authorized settlement intents.

## Separate the records that answer different questions

A **position** records exposure or entitlement in an instrument. A **balance** records an amount of an identified asset at an account. A **reserve** restricts value for a specified obligation or risk requirement. A **capital lock** binds the conditions under which that restricted value can support or leave an obligation.

These records can refer to the same economic activity without being interchangeable. A buyer may hold an entitlement while the settlement asset remains in shared custody. An issuer may retain a residual claim after funded holders redeem. The system shall identify which ledger answers each question and reconcile their common economic quantities.

For a custody-backed asset $a$, define $C_a$ as recorded custody and $L_a$ as aggregate funded nominal liabilities within the covered ledgers. The required coverage predicate is

$$
C_a \geq L_a.
$$

This is a nominal custody predicate. Marked-to-market solvency additionally depends on prices, exposures, liquidation costs, and recoverability. A reserve denominated in one token cannot cover a liability in another merely because their display names or estimated prices match.

Every reservation shall name the exact asset and custody account. Its amount must use canonical fixed-point units. Interfaces may display decimals, but signing and verification shall preserve raw values. Rounding rules belong to the contract. An adapter shall not select new rounding behavior during a retry.

## Clearing defines permissible offsets

**Clearing** determines the obligations that remain after applying permitted offsets and risk requirements. A clearing set identifies the obligations eligible for common treatment. A netting agreement identifies the authority and terms that permit offsetting. Economic correlation alone does not establish a right to net legal obligations.

Consider two positions that gain and lose equal amounts in a modeled scenario. They can reduce modeled market exposure. If different principals own them, or insolvency rules prevent offset, the clearing process must preserve the gross obligations. Recognition of a hedge requires the required legal and operational bindings as well as a favorable numerical result.

Risk snapshots bind the clearing set, netting agreement, publisher, covered markets, observation block, and expiry. They also carry expected shortfall, stress loss, margin, and haircut-adjusted collateral. An applicant shall not extend the snapshot's covered markets during admission. An empty coverage set grants no market-specific risk credit.

The reserve carried by an AOT must agree with these bindings. A correct reserve amount attached to the wrong clearing set is invalid. A current snapshot for a different market does not justify capital reuse. An expired snapshot requires the prescribed refresh or refusal behavior before the system opens additional risk.

## The settlement intent precedes the receipt

A **settlement intent** authorizes a specific job before execution. It binds the principal's admission, instrument, obligation graph, compliance reference, risk reserve, evidence, execution evidence, settlement job, asset, and reliance terms. The intent's commitment excludes the eventual receipt because that receipt does not exist at authorization time.

After execution, the result can bind the actual settlement batch and receipt to the same authorized body. This separation prevents an orchestrator from creating an arbitrary receipt and using it to justify a different obligation. It also permits a verifier to compare the completed effect against the principal's original authorization.

The conceptual lifecycle has five ordered stages:

1. Authorized intent.
2. Staged transport.
3. Validated effects.
4. Consumed intent and committed effects.
5. Verified receipt.

Transport staging is conditional work. It shall not pay a beneficiary or release a reserve. An implementation that splits a batch into chunks must bind the batch identifier, orchestrator, root, and chunk count consistently. Duplicate or contradictory chunks must fail before economic effects become visible.

## Atomic economic effects

At settlement, the executor shall authenticate the orchestrator and locate the principal-authorized intent for each resolved obligation. It shall recheck authority, validity, compliance, custody, and the bindings between intent and batch. Only then may it consume the intent and apply economic effects.

Intent consumption and its economic effects form one atomic transition. If an effect fails, the system must restore the state before consumption. Otherwise an unsuccessful debit could permanently consume the only authorization capable of completing the payment. The reverse error is equally serious: paying without consuming authorization permits repeated payment.

The current obligation-bound batch implementation snapshots state around these effects and restores that snapshot on error. Production execution with validator signature verification enabled requires an explicitly allowlisted orchestrator. An empty production allowlist refuses every batch. A development configuration with different verification settings must not become evidence for this production authority boundary.

A durable commit still requires a receipt and native finality verification before external reliance. The in-memory atomic transition and persistence after restart are separate acceptance conditions. A complete observation must show that balances, consumed intents, obligation state, and receipts recover together from the same committed state.

## Worked failure: a stale authorization in a complete batch

Assume a batch would pay 60 units to one holder and 40 units to another. Both intents name the same settlement asset and authorized custody account. The transport delivers all chunks and their commitments agree. Before execution, the compliance evidence bound to the second intent's principal expires.

The executor checks the current conditions before consuming either intent's final effects. The expired principal evidence causes refusal. Neither holder receives a partial payout through this batch. If validation discovers the failure after provisional mutation inside the atomic scope, rollback restores that scope. The observable result must preserve both cash and intent state.

This example exercises the implemented principal-compliance check. The payout loop does not independently recheck every recipient's attestation. Recipient-specific validation remains a separate requirement wherever the governing policy requires it.

The orchestrator cannot repair the request by changing the principal or beneficiary while retaining the original commitment. It must obtain the authority required for a changed intent. It also cannot treat the first holder's unpaid amount as recovered value. A retry must identify whether it repeats the same authorized action or proposes a different one.

Now assume the network response disappears after a successful commit. A client shall query the durable job and receipt identity before issuing another economic instruction. Reusing the same idempotency identity must not produce another payout. Selecting a new identifier merely because a response was lost would create a second intent rather than resolve uncertainty about the first.

## Continuing obligations during transfer

An administrator can stop accepting work while an economic duty remains live. The settlement architecture shall preserve that duty across administrative transfer. Its stable identity derives from the issuer's authoritative namespace, constituting act, and occurrence. Changing a template, representation, or administrator shall not create a new duty or discharge the original one.

The economic journal shall retain the beneficiary, debtor, asset, unit, conditions, priority, and disposition of each duty portion. It must distinguish reservation of a duty portion from reservation of cash. The first prevents two commands from satisfying the same portion. The second funds a command's possible expenditure. Transfer shall preserve both under their original identities.

For a partially performed duty, let $D$ be the outstanding amount. Let $P$ be completed performance awaiting attribution. Let $u_j$ bound additional performance still possible under each live command. The permitted new exposure is bounded by

$$
\max\left(0,D-P-\sum_j u_j\right).
$$

The quantities require a common allocation model. Overlapping exposure bounds cannot be counted as independent capacity. A delayed provider response shall update the original command and occurrence. It shall not create another payment simply because a successor received the response.

For example, assume a duty of 125 units has received 40 units. A live command can still deliver 85 units, backed by 85 reserved units. Transfer must carry the residual duty, command exposure, and funded reservation together. It permits no additional command for those same 85 units. A late credit of 60 reduces the residual duty and remaining exposure to 25.

Closing that command at its actual credited amount leaves any unpaid duty intact. A fresh instruction for the residual requires current authority. Revocation may block new dispatch while still permitting receipt of evidence and preservation of the beneficiary's claim. Authority to observe a result and authority to create a new economic effect must remain separate.

Transfer of suspended computation requires a complete, authenticated account of the handover state. It shall include live machine records, economic journals, funded resources, undelivered messages, future-action authority, and retained evidence. Every relevant namespace needs a complete prefix. An unacknowledged obligation-creation message must retain its original delivery identity.

A successor shall restore the checked continuation directly, including its pending request and prior effects. Reexecuting the program from its beginning would risk repeating dispatch. Before transfer commits, the receiving decoder must reproduce the exact checked state. An unavailable decoder leaves an explicit obstruction and an identified continuing custodian.

The ownership transition shall fence predecessor initiation and include every admitted preparation delta. It shall activate exactly one successor under a durable execution generation. Every later action needs that current generation and action-specific authority. Current authority, consumption, resulting continuation, and command receipt must commit atomically. Exact retries return the committed receipt without reexecuting the command.

These requirements define the economic continuation contract. They do not assert a completed distributed transfer implementation. Effective external fencing, authenticated freshness, funded custody, and valid institutional transfer require evidence at their respective boundaries. Copying a complete archive alone cannot establish them.

## Funded claim redemption

Terminal claim settlement fixes the payoff value and applies it to recognized holder entitlements. The current handler requires an immutable funding binding. It refuses redemption by the bound custody account and refuses a second terminal redemption by the same holder. It also verifies funded supply and holder history before consuming entitlement.

A holder can carry direct entitlement or an admitted wrapped representation. Redemption must account for both without counting the same entitlement twice. Current settlement requires removal of outstanding claim AMM liquidity before terminal redemption. The holder must therefore complete that liquidity transition before asking the settlement path to consume the entitlement.

An automated market maker, or **AMM**, holds reserves and quotes trades through a pricing rule. A central limit order book, or **CLOB**, matches explicit orders. Each venue needs its own custody and entitlement invariants. Successful matching shall not create an entitlement that settlement refuses to recognize.

The target market contract makes ordinary and liquidation routes share the same physical depth across accounts and certificate keys. Consumed reservation identities and inventory generations survive release; selecting another key cannot reserve inventory that remains encumbered. A quote alone reserves nothing.

A clearing batch shall bind input root, objective, constraints, rounding, tie-break rules, and work limit. Exhausting the work limit produces a deferred result with retained escrow and intermediate state. Infeasibility requires its own verified certificate. Timeout cancellation releases exact unused reservations once. Terminal settlement accounts for pending batches before releasing pool assets or holder entitlements.

A liquidity-provider withdrawal must check both net entitlement after senior liabilities and physical availability after disjoint backing and depth reservations. Each liability is counted once within each applicable calculation. Insufficient availability prevents both share burn and transfer. A valuation increase supplies no cash. These rules state the required market behavior; they do not activate a currently refused trading path.

## Implementation boundary

The obligation-bound settlement batch is the admitted carrier. The legacy unbound batch is retired and refused. Funded claim CLOB order submission remains disabled until entitlement escrow exists. General order implementation and schema support therefore do not establish funded-claim CLOB trading.

Direct ClubBond principal issuance, minting, transfer, and redemption are confined to controlled chain `421610`. Production chain `421600` refuses that lifecycle pending institutional AOT admission and an explicit activation boundary. Direct nonzero-coupon issuance is also refused because the required coupon authority and entitlement evidence remain incomplete. A represented coupon schedule cannot justify selling an interest-bearing product whose payment path is unavailable.

# Consensus, finality and permitted reliance

Consensus establishes which state transition the validator system commits. A recipient then verifies what that transition did and whether its result supports the recipient's intended action. These questions require related but distinct evidence. The finality contract must keep the committed execution, validator authority, receipt, and reliance policy bound together.

## Deterministic execution under an identified configuration

Let $S_h$ be committed state, $B_{h+1}$ the ordered block input, and $\theta$ the identified execution configuration. Deterministic execution requires

$$
F_\theta(S_h,B_{h+1})=(S_{h+1},\mathcal{R}_{h+1}).
$$

Independent evaluators with the same inputs must produce the same state and receipt sequence $\mathcal{R}_{h+1}$. The input includes the canonical timestamp and every admitted external observation. A validator shall not fetch a fresh price or generate a new model response while reproducing a committed transition.

Ordered collections, canonical serialization, fixed-point amounts, and explicit error rules support this requirement. Configuration is part of the comparison. Running different policy epochs or replaying history under incompatible semantics invalidates a claimed equality. A matching function name does not establish matching execution behavior.

Moxie execution assigns transactions to three ordered phases. The first contains oracle resolution and event settlement, including claim payoff settlement. The second contains trading and clearing. The third contains non-market transactions, including the obligation-bound settlement batch. Consensus ordering must agree with these transaction-specific assignments. Encrypted transaction handling adds another boundary: evidence must establish when plaintext became available relative to the committed order. A post-block balance inspection cannot reconstruct that timing.

## Complete event collections

The proposed event-collection contract fixes chain, parent, candidate domain, authorized sources, evidence rules, and closure policy. Validators persist the materialized objects before acknowledging them and persist a finite signed snapshot before announcing closure. A closure package contains snapshots from the required number of distinct admitted validators, together with their authenticated context.

Resolution operates on the canonical union of those snapshots and records exactly one accepted or deferred disposition for every candidate. Adverse evidence remains in the union. Conflicting admissible source assertions produce witnessed deferral. Invalid surplus evidence cannot defeat an independently admissible certificate. Changing a validator's private inventory after closure must not change the validity of the retained package.

Late evidence enters a durable queue for later collection and receives new acknowledgements under the applicable context. Capacity planning must preserve the complete mandatory candidate domain. An oversized mandatory package requires explicit refusal and a named capacity failure; truncation cannot be reported as a complete collection. Preparation votes remain separate from the complete BFT decision that binds the package.

These are proposed completeness and availability requirements. The existing phase and quorum vocabulary does not establish their implementation. Acceptance must exercise omitted deferrals, adverse and late evidence, missing materialized bytes, and capacity exhaustion through the claimed consensus path.

## Public BFT and sovereign committee modes

The consensus state machine includes event-attestation collection followed by Prepare, PreCommit, Commit, and Decide. Its public Byzantine fault tolerant mode, or **public BFT mode**, uses the conventional $3f+1$ committee envelope and a $2f+1$ quorum. The parameter $f$ is the admitted Byzantine-fault bound for that model.

The safety argument requires more than counting messages. Votes must authenticate distinct admitted validators and bind the same height, view, phase, proposal, and execution commitment. A duplicate signer must contribute once. A vote for another state cannot help certify the candidate state, even when the message has a valid signature.

A separate sovereign fast-path threshold model describes a contracted operator committee. Its certificate policy differs from public BFT. The model requires at least four-fifths of total weight for a direct fast certificate. Its slow path requires both certificate families, each reaching three-fifths of total weight.

These thresholds do not confer interchangeable security guarantees. A verifier shall pin the mode, committee profile, and finality policy for the transaction. It shall reject mixed public and sovereign certificate families. It shall not reinterpret a sovereign certificate as a public BFT quorum to satisfy a receiving institution's policy.

## The finality envelope binds the execution

A **settlement finality envelope** records the block and commitments needed to connect execution with consensus. The binding includes execution block hash, consensus block hash, decide-reveal root, state root, receipts root, certified digest, committee profile root, and finality policy root. Certificate evidence must authenticate the relevant statement under the admitted committee.

A receipt proof then establishes that the claimed receipt belongs to the bound receipts root. The receipt's semantic content identifies the job and effects that it acknowledges. A proof of inclusion for a failure receipt proves that the failure was recorded. It cannot support a claim that the intended payment succeeded.

The relying party shall compare the receipt with its own expected intent. Asset, amount, beneficiaries, job identity, and terminal status must match. A valid receipt for another account or another deployment does not satisfy that expectation. Chain identity and object identity must remain explicit throughout verification.

The following evidence levels answer different questions:

| Evidence | Question answered | Remaining requirement |
|---|---|---|
| Submission identifier | Which request entered a submission path? | Execution and durable result |
| Execution receipt | What result did the executor record? | Inclusion and native finality |
| Native finality evidence | Which execution did the committee commit? | Applicable recognition and reliance policy |
| Recognized disposition | What effect may the recipient treat as settled? | Any external performance or recovery evidence |

An external bank credit, registry amendment, or delivery acknowledgement has its own authority and persistence boundary. Moxie finality can prove a native commitment concerning that external action. The applicable adapter must still establish the external effect through the destination's evidence contract.

## Reliance has a named beneficiary and purpose

A **reliance envelope** restricts which parties may use a result and for which purposes. Examples include recognizing collateral, releasing capital, reporting a settled obligation, or accepting a recovery disposition. The same receipt can be sufficient for one purpose and insufficient for another.

The receiver shall verify its inclusion within the permitted parties and purposes. It shall also check the governing legal profile and current recognition conditions. Permission to inspect a receipt does not grant permission to recognize that receipt as regulatory capital. A value that remains subject to a recovery condition cannot become unrestricted liquidity through relabeling.

Capital release requires a bound authorization that identifies the relevant lock and disposition. A release policy must specify the terminal evidence it consumes and the remaining obligations it preserves. A newer authorization must not replay an older disposition against the same reserve. The system needs durable consumption state for the economic effect.

Recourse outcomes enter this structure through a separately admitted authority path. A case filing, adjudicator decision, submitted execution instruction, and measured recovery remain separate records. The adjudicator's authority must cover the disposition. Moxie must verify and execute the native instruction. The recovery record must then reconcile the actual effect for the entitled party.

## Safety and liveness under interruption

Safety means the system does not accept conflicting committed results under its stated fault assumptions. Liveness means an admissible action can progress under the specified network and availability assumptions. A timeout affects progress evidence. It does not authorize a conflicting commitment or prove that a remote action failed.

Recovery shall retain the committee and policy context that authenticated each commitment. A restarted process must restore nonce frontiers, consumed intents, settlement state, and the commitments needed for receipt verification. Reconstructing balances while losing consumed-intent state would reopen payment authority. Reconstructing receipts while losing the corresponding balances would misrepresent performance.

Operational acceptance must therefore exercise interruption across the actual persistence boundary. The observation must identify one integrated binary, configuration, validator topology, and intent. It must bind the recovered records to the same causal identifiers. An isolated restart test and an unrelated successful payment cannot jointly establish this property.

## Implementation boundary

The current certificate model separates public BFT from sovereign fast-path certificates and rejects mixed families. The node, proof API, and SDK verifier currently reject sovereign fast-path finality. This mode requires a separately committed sovereign roster and signature path. Its threshold model does not establish an executable finality mode. The sovereign slow path checks the presence and weights of both observations. Those observations do not yet structurally bind one certificate to the other or enforce their ordering. A fully linked slow-path proof remains a further obligation.

The configured default block interval is 2,000 milliseconds. That constant is a scheduling parameter, not measured finality latency. This specification asserts no throughput or latency result from it. Current performance and readiness require an identified production execution with a faithful, independently operated validator topology.

# Risk, oracles and execution availability

Clearing depends on assumptions about future loss and evidence about current conditions. The implementation must record both. A deterministic calculation can reproduce an incorrect assumption exactly. Risk controls therefore need authenticated inputs, declared coverage, expiry, conservative refusal behavior, and a clear connection to the economic action they protect.

## An oracle contributes a scoped observation

An **oracle** supplies an observation that execution cannot derive from its own committed state. A price report identifies its market, value, source, observation time, and receipt time. An event report additionally needs the event, resolution condition, and authority permitted to attest it. Price estimation and adjudication of contractual performance are different functions.

An oracle consumer shall verify the source authority and preserve the signed payload's exact meaning. It shall check freshness against the relevant time domain. Receipt time cannot replace observation time. A recently delivered report about an old market state remains old evidence.

The price aggregation implementation distinguishes institutional, validator-attested, and on-chain reports. It supports weighted median aggregation and outlier filtering. Its stale-result check measures time since aggregation. It does not enforce the age of the underlying observations. Reaggregating old reports can therefore produce a recently timestamped result from old observations. Observation-age validation remains a required correction at this price boundary. The separate event-attestation execution path rejects future observations and observations outside its permitted age. That event-specific check does not repair the price aggregator. Those mechanisms describe how admitted reports combine. They do not establish that every configured source is connected, independent, or authoritative for every instrument.

Source correlation matters. Several reports can share one upstream provider while presenting different transport identities. A quorum policy shall define the independence assumptions it requires. A record count alone cannot establish independent corroboration. The risk model must account for sources that fail or become misleading together.

Payoff evidence must also bind to the admitted obligation. An authenticated delivery report about another shipment cannot resolve the current receivable. A valid price at another observation block cannot silently replace the specified fixing. Missing evidence shall leave the relevant resolution incomplete or produce the contract's explicit refusal.

## Margin and stress are conditional estimates

**Margin** reserves resources against an exposure under a declared risk model. Initial margin constrains new risk. Maintenance margin identifies conditions requiring corrective action on existing risk. A haircut reduces the recognized collateral value to reflect its modeled liquidation or recovery limits.

Expected shortfall summarizes loss in the selected distribution's tail. Stress loss records exposure under specified adverse scenarios. Both depend on the scenario set, parameters, observations, and model interpretation. Their commitments must make those dependencies identifiable. A numerical margin result without its input image is insufficient for reproducible risk admission.

Cross-margining can recognize modeled offsets within an authorized portfolio. It must preserve a residual requirement for basis risk and respect legal netting boundaries. Capital savings depend on the portfolio, model, and constraints. This specification grants no universal multiplier from the existence of a cross-margin implementation.

Risk admission shall bind the snapshot publisher, markets, clearing set, netting agreement, validity, and collateral image. A consumer shall reject an unsupported market or stale snapshot. A favorable risk estimate must not bypass an independent sanctions, custody, authority, or product-boundary refusal.

Suppose a portfolio contains a receivable and a derivative that hedges its market price. The price hedge can reduce market-risk estimates. It does not necessarily hedge the buyer's default, a disputed delivery, currency controls, or a stay on enforcement. The model must preserve those residual exposures where they affect the reserve or recovery assumptions.

## Liquidation and recovery need executable authority

A liquidation rule identifies when an account needs corrective action and which actions can restore its required coverage. Detection alone does not perform liquidation. The executing path needs authority, executable liquidity, asset access, and atomic settlement of the selected effects.

A liquidation record shall bind the trigger, risk image, selected positions, prices, costs, and resulting balances. If the selected venue cannot execute, the system must retain the unresolved exposure. It must not report the modeled proceeds as recovered cash. A subsequent recovery process may need different authority and a different disposition.

Insurance and reserve funds also have bounded roles. A nominal fund balance does not prove that the fund covers every possible loss. Its permitted uses, priority, custody, and depletion behavior must be explicit. A breaker that stops new risk after drawdown preserves one boundary. It does not prove that all existing obligations remain solvent.

Release and recovery shall remain distinguishable. A release returns value because the relevant obligation permits it. A recovery records value obtained after a failure or adverse disposition. Both require reconciliation to the entitled party, asset, amount, costs, and source evidence. A legal award amount may exceed the value ultimately recovered.

## Availability is checked before and during execution

The transaction schema contains both supported and refused variants. An API can parse an object whose production semantics remain unavailable. The availability policy shall therefore apply at construction, estimation, external admission, proposer admission, and consensus execution where those surfaces exist.

Consensus must enforce the same deployment-specific restrictions as public ingress. Otherwise a proposer could insert a transaction that an ordinary client cannot submit. Metadata and gas estimation shall not advertise execution for a transaction that the canonical submission path refuses.

Availability can depend on the exact deployment domain. A controlled chain used for one bounded product lifecycle must not imply availability on every nonproduction chain. The policy shall specify the complete lifecycle's domain so that issuance cannot create an obligation whose matching redemption is refused there.

Current refusals include EVM execution, conditional orders, stop-event and parlay orders, corridor administration and redemption, ephemeral markets, personas, auctions, and tickets. Their missing properties differ. Some lack funded trigger settlement. Others lack issuer authority, asset escrow, terminal delivery, or a binding redemption certificate. A generic feature label cannot convey those requirements.

## Acceptance evidence for a product path

A product path shall identify its intended user action and required durable effects before it claims completion. Acceptance must exercise the actual API, admitted authority, and persistence boundary. It must include the first material refusal that could falsify the claimed path, such as expired authority or repeated settlement.

For a funded claim, the observation must connect issuance to custody, entitlement, execution, terminal resolution, and redemption. It must compare amounts and identifiers across the complete path. If the claim uses a bridge, the observation must include the destination's authoritative acknowledgement. A locally constructed proof request establishes only the request's construction.

The runtime invariant report distinguishes **Pass**, **Violation**, and **Skipped**. A skipped row means that the observation boundary lacked the state needed to evaluate the predicate. A report with no violations can still contain incomplete coverage. A post-block guard cannot establish encrypted-mempool timing, validator fault tolerance, or economic properties absent from its inputs.

Formal models require equally explicit scope. A bounded abstract compliance model can establish properties of its modeled transition. It does not establish equivalence to the deployed executor. An authority proof that abstracts hash validation leaves that cryptographic binding outside its result. A single-slot consensus model without an explicit message network cannot establish production liveness under partial synchrony.

## Implementation boundary

The implementation provides risk snapshots, margin calculations, oracle aggregation, custody checks, and explicit transaction refusals. These components require source-identified execution before they establish a complete operational claim. Current invariant coverage deliberately records several predicates as skipped because the guard cannot observe their required state.

No universal solvency, legal enforceability, cross-border atomicity, or automatic recovery claim follows from these component structures. Each product's acceptance record must name the assumptions and external obligations that remain. An unsupported transition shall remain visibly unavailable until its authority, economics, persistence, and receiving-party evidence are complete.
