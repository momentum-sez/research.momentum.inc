# Foundational assumptions and design obligations

## Assumptions belong to particular claims

A correctness claim must identify the assumptions that make it true. Cryptographic, computational, institutional, operational, and economic assumptions have different failure modes. A system can satisfy one class while failing another.

For example, an authentic signature can bind an unauthorized instruction. A deterministic executor can reproduce incorrect authored rules. A solvent ledger can coexist with inaccessible custody. A valid award can remain unperformed. The acceptance argument must address the particular property claimed.

The assumptions below organize the architecture. They are not assertions that every deployment currently satisfies them.

## Cryptographic assumptions

Commitment integrity requires the chosen digest construction to resist the relevant collision or preimage attack. Signature authenticity requires the configured verification policy and key material to satisfy its security assumptions. Combining signature algorithms changes the acceptance predicate. Its security follows that predicate, not the word hybrid.

Key ownership requires secure generation, custody, authorized use, rotation, and retirement. A valid historical signature can remain useful after the key retires. Current action authority must apply the current policy. Recovery must retain enough old public material to verify the records that still matter.

Randomized cryptographic operations require a suitable cryptographically secure random source. Nonces, proof randomness, keys, and protocol challenges have different uniqueness and secrecy requirements. Reusing a value can invalidate the corresponding security argument. An implementation must verify the randomness or deterministic-generation contract of each algorithm it actually uses.

Aggregate signatures require an admitted signer set and the verification conditions of the chosen aggregate scheme. A signature count cannot establish signer independence. Zero-knowledge claims require a defined relation, correctly bound public inputs, and an accepted proof system. Privacy cannot be inferred from an opaque proof field.

## Computational assumptions

Reproduction requires the same admitted inputs, interpretation rules, arithmetic, and execution configuration. A deterministic result is relative to those inputs. External observations and discretionary answers must enter through retained evidence rather than fresh ambient reads during replay.

Bounded execution requires limits at the actual consuming boundary. Parser size, recursion depth, instruction work, memory, database work, and external waits can need different limits. A gas counter that excludes an expensive host operation does not bound the entire action.

The compiler, interpreter, database adapter, and proof verifier must agree on the semantics that cross their interfaces. A theorem about a small language fragment does not establish this agreement for a larger implementation. The missing refinement obligation remains explicit until its full scope is discharged.

## Institutional assumptions

The system requires a valid basis for recognizing the relevant organization, office, agreement, rule, and deciding authority. That basis can differ across jurisdictions and instruments. Its representation must preserve provenance and the limits of recognition.

An authored rule set needs competent interpretation of its legal sources. A typechecker can reject malformed rules while accepting a substantively incorrect rule. The review procedure must address meaning, authority, effective time, and the consequences of amendment.

Legal tradition can affect the admissible sources, interpretive method, and deciding authority. The evaluation context must preserve those distinctions when the applicable procedure depends on them. A common compliance domain does not make two traditions' evidentiary or interpretive rules identical.

The deploying sovereign can also operate the software. That combination can correlate the producer of evidence with the authority judging its sufficiency. Where the recognition policy requires independent regulator or external attestation, the system must preserve distinct issuers and their roles. Two signatures under common control do not establish independent oversight.

Discretion requires an authorized decision about a defined question. A decision record must bind the deciding party, question, evidence, reasons where required, and permitted effect. Subsequent execution must preserve those limits.

Cross-jurisdictional recognition requires an explicit direction and scope. A local finding does not become universally recognized through transport. The receiving authority must decide what it accepts and retain the conditions that govern that acceptance.

The sovereign design shall not mandate one global trust anchor or one application through which all institutional action must pass. Each deployment must retain its authority over admitted roots, interfaces, data custody, and recognition. Common protocols can make these decisions interoperable without assigning them to a sole operator. A deployment that chooses shared infrastructure must still make its resulting concentration and exit conditions explicit.

Biometric evidence alone shall not determine a person's institutional eligibility or irrevocably deny access. Its error rates, presentation attacks, source authority, and corroborating evidence must remain visible to the decision procedure. Where an adverse decision depends on contested identity evidence, an authorized correction and review path must exist. These are design commitments; the book does not claim universal enforcement across every current interface.

## Economic assumptions

Recorded balances must correspond to value under the named custody and settlement arrangements. Funded liabilities require correctly denominated assets and enforceable access to them. A price estimate cannot create nominal settlement capacity.

Risk models require declared inputs, scenarios, horizons, netting rights, and liquidation assumptions. Their estimates remain conditional. They must coexist with independent authority, eligibility, sanctions, custody, and availability gates.

Claims must preserve the distinction between face amount, modeled value, entitlement, reserved resources, settlement, and recovered value. Partial performance must reduce the appropriate remaining exposure without erasing other duties. A command receipt must describe its actual effect.

## Operational assumptions

Durability requires correctly configured storage and recovery procedures. A committed outbox preserves an intention to deliver. Delivery additionally requires available workers, an admitted destination, bounded retry behavior, and a receiving acknowledgement.

Recovery requires coherent state. Restoring balances without consumed-intent records can reopen authority. Restoring receipts without their economic effects can overstate performance. Restoring a continuation without its duty and reservation state can lose obligations.

Distributed succession requires effective fencing or exclusive custody. A complete copy does not prevent the predecessor from acting. Freshness against coherent rollback can require an external monotonic anchor. The architecture must name where that protection lives.

Availability claims require stated fault assumptions and measured operating conditions. Timeout values, scheduling intervals, and configured ceilings do not establish latency, throughput, recovery time, or geographic resilience.

## Supply chain and deployment assumptions

A deployment must identify the binary, dependencies, build inputs, configuration, rule material, and keys relevant to its claim. A clean dependency scan answers a bounded question about known findings. It does not establish the absence of malicious or unknown behavior.

An image tag can move. A source branch can advance. A deployed observation must bind the actual image or binary and its inputs. Documentation and source metadata can help locate that identity but cannot replace it.

Provider profiles matter. The intended persistence and signing architecture must match the configured running services. An alternative profile can have a different storage or authority boundary even when the service name is unchanged.

## Human and governance assumptions

Human authority remains necessary where a constitution, agreement, law, or product contract requires it. The runtime must represent the missing decision rather than invent a substitute person or approval. Automation must preserve the action's existing authority limits.

Operators need enough information to distinguish waiting, failure, partial effects, and completed recovery. A useful incident record states the affected intent, authority, evidence, and remaining duty. Manual intervention must use an authorized transition and retain its own record.

Good faith is not an input-validation strategy. Pack authors, counterparties, providers, and operators can make mistakes or act adversarially. Admission should verify what it can and identify the trust that remains.

## Research and implementation

The research program supplies models for programmable organizations, multiple harbors, compliance composition, executable rules, workflows, evidence, claims, settlement, and dispute resolution. These models inform design. A model becomes an implementation contract only when its objects and obligations are mapped to concrete interfaces and state.

The Lex, Op, gstore, and Stack projects provide distinct reference surfaces. Their names do not establish complete interoperability or deployed use. A consuming implementation must identify the exact imported contract and the adaptations it makes.

Formal results must state their fragment, assumptions, and conclusion. A closed proof can depend on an explicit unproved premise. A theorem whose conclusion is structurally trivial does not establish the operational property suggested by its title. A model-checking run explores its configured model and bounds.

Reference execution can demonstrate a mechanism such as direct continuation restoration or exact retry. Production realization additionally requires authenticated host identity, secure keys, current institutional grants, durable storage, and authoritative adapters. The book carries those obligations into the target architecture.

## Formal-result navigation

The following index records selected source-inspected formal statements and their actual models. Closed proof bodies were inspected, but the proof assistants were not rerun for this edition. The table summarizes those dated inspections by property, model, and remaining obligation. The retained proof sources are required for independent verification. These bounded results and open obligations do not certify the corresponding deployed system.

| Property and statement | Model and strongest supported scope | Remaining obligation |
|---|---|---|
| Mixed-axis impossibility | Contradiction under the stated meet-semilattice, audit-fix, and antichain hypotheses | Do not generalize to every conceivable compliance model; specify which hypotheses the product requires |
| Applicable residual | The three-state applicable fragment satisfies its meet/residual adjunction | Preserve applicability and mixed-axis obstructions when mapping to actual evaluations |
| Post-flight monotonicity | In the five-chain domain-array model, pointwise meet cannot raise the aggregate above its pre-state | Establish that the actual transition uses the modeled rule; the result does not reverse already committed effects |
| Op effect bound | A small effect-tracking machine bounds its trace by initial, declared, and compensation rows | Relate concrete compiler and host emissions, errors, and retained effects to those constrained step constructors |
| Op local diamond | Independent increments of two disjoint natural-number slots commute | Prove the stronger conditions needed for real workflows, shared resources, and external effects |
| Lex sanctions preservation | A worked oracle example's defined override preserves an already propagated bottom result | Establish oracle accuracy, identity binding, freshness, and enforcement at every affected admission path |
| gstore append preservation | Abstract append statement whose proof is explicitly admitted | Supply the concrete carrier and completed proof; an admitted statement is an open obligation |

The conditional structure matters. For example, a machine whose transition constructors already restrict emitted effects can have a valid trace theorem. That theorem still needs a correspondence argument before it constrains a production adapter. Likewise, proving an exclusion from a particular algebraic design does not prove that every alternative institutional model is impossible.

## Architecture acceptance matrix

| Property | Necessary evidence | Frequent incomplete result |
|---|---|---|
| Authored intent | Bound input and authenticated principal | Convenient synthesized values |
| Action authority | Current grant for the exact action and object | A valid session alone |
| Rule admission | Pinned rules, evidence, evaluator result | Schema or typecheck success alone |
| Durable mutation | Committed effect and transaction evidence | A preflight verdict |
| Complete workflow | Every required effect and acknowledgement | Operation creation or one successful step |
| Historical reproduction | Retained inputs and matching interpretation | Re-evaluation under current rules |
| Financial settlement | Correct custody, consumed intent, balances and receipt | A submitted batch |
| Native finality | Bound execution and accepted committee evidence | An inclusion proof without accepted finality |
| Award execution | Accepted destination instruction and its effect | A signed outcome or local enforcement status |
| Recovery | Reconciled value, beneficiary, asset and residual duty | Award face amount |
| Succession | Complete cut, receiver validation and effective fences | A copied archive |
| Formal assurance | Exact theorem scope and discharged assumptions | A proof count or passing compilation |

## Verification campaigns and their first falsifiers

Verification should begin with a property and a counterexample capable of disproving it. The retained evidence must preserve enough context to reproduce that counterexample. The following matrix defines campaigns for the specified architecture; it does not report that every campaign has passed.

| Requirement and test class | First material falsifier | Evidence to retain |
|---|---|---|
| Canonical identity: cross-implementation vectors and properties | Equivalent admitted objects yield different bytes, or distinct required meanings collapse | Input domain, canonical bytes, schema and encoder identities |
| Receipt linkage: chain and mutation integration | A receipt verifies against the wrong predecessor, intent, or effect | Complete witnesses, roots, causal identifiers, committed records |
| Compliance composition: algebraic properties and boundary cases | A forbidden action becomes admissible through composition or loss of applicability | Typed operands, rule identity, result and obstruction |
| Pack admission: schema, resolution, and semantic fixtures | A missing module or conflicting rule is accepted as complete | Requested and resolved content, diagnostics, identities |
| Authority: authenticated API integration | Revoked, wrong-entity, or insufficient authority changes durable business state | Actor binding, request, refusal, before/after authoritative state |
| VM metering: adversarial resource tests | An admitted host operation exceeds its charged resource bound | Program, host configuration, counters, measured work and termination |
| Callback handling: replay and fault injection | Duplicate or changed delivery repeats an effect or applies to another submission | Exact authenticated payloads, identities, transitions and resulting balances |
| Local atomicity: crash injection at commit boundaries | Business effect survives without required audit, outbox, or proof, or vice versa | Failure point, transaction result, restart state and reconciliation |
| Continuation and succession: restart and stale-owner execution | A restored computation changes its next effect or an obsolete owner still acts | Decoder image, logical work, custody generation, reservations and receipts |
| Settlement and recovery: complete financial journey | A result reports paid or recovered value absent from destination evidence | Entitlement, reserves, destination records, finality and remaining duty |

A finite model checker enumerates reachable states under its chosen model and bounds. A refinement argument connects an implementation transition to the modeled transition, including errors and host effects. A runtime trace demonstrates one execution under identified conditions. These methods answer different questions and should be linked by the same requirement, rather than combined into one undifferentiated pass count.

### A replay and partial-performance vector

Use an illustrative duty with principal 100 units and an admitted command authorizing performance of 40 units. Before execution, its 40-unit reservation is unavailable to other commands. After authoritative performance of 40, residual principal is 60, the command's receipt is retained, and its consumed authority cannot be used again. The reservation's release or consumption follows the settlement contract.

An exact replay of that command must return its retained receipt with residual principal still 60. A request that reuses the command identity with a changed amount must be refused without a new effect. If another admitted payment later supplies 10 units, residual principal becomes 50 under the duty's allocation rules. Closing the original command still cannot discharge that remaining 50.

This vector is a specification fixture, not a transcript of product execution. An implementation check must run through the actual admission and persistence boundary, interrupt after a possible commit, restart, and compare the retained receipt and balances. An in-memory function that reproduces the arithmetic cannot establish durable replay safety.

## Architectural decisions and reconsideration conditions

| Decision and governing constraint | Cost or limitation | Evidence that could justify revision |
|---|---|---|
| Common mutation admission for shared authority and evidence | Coordination and composition-root complexity | A replacement preserves sanctions, authored intent, atomic effects, and audit across every affected route |
| Domain-owned services and persistence facades | Cross-domain work needs explicit orchestration | A boundary change reduces coupling while preserving one accountable owner and transaction semantics |
| SQL transactions for local institutional effects | External systems remain outside the transaction | A different persistence mechanism supplies equivalent admitted atomicity, recovery, and operational evidence |
| Identified packs and historical interpretations | Authors must retain versions and resolve compatibility | New composition semantics preserve authority, effective time, old meaning, and work already in progress |
| Append-oriented evidence with retained witnesses | Storage, privacy, and archival obligations grow | Verified archival preserves required verification and correction while meeting the retention contract |
| Formal reasoning over explicit fragments | Proof coverage can lag real host and adapter behavior | A broader model and checked refinement establish the stronger claim without concealing assumptions |

These are reasons for the specified design and criteria for evaluating alternatives. They are not a reconstructed history of every implementation choice. A revision must be judged against the institutional and economic effects it preserves.

# Terms and notation

## Organizational and authority terms

**Action.** A requested transition under specified authority, with an identity and required effects.

**Actor.** The authenticated party that presents or performs an action. The actor can act for a distinct principal under a valid grant.

**Principal.** The party whose authority supports the action and whose scope constrains delegation.

**Organization.** A legal entity or other recognized organizational arrangement with governed state, duties, and authorized actors.

**Harbor.** A jurisdictional presence that binds an organization to identified registration, licensing, rule, and continuing-duty conditions.

**Jurisdiction.** The legal and institutional domain relevant to an action. Its identifier must remain distinct from a deployment or chain identifier.

**Deployment.** A configured running instance of the relevant service or network, with its own software, keys, rules, and authority context.

**Capability.** A bounded grant of authority. A capability's admissible actions depend on its issuer, scope, constraints, and current status.

**Attenuation.** Derivation of authority that admits a subset of the parent grant's actions.

**Consent.** A decision record under a defined electorate and approval rule. It can be one prerequisite for a later signed instrument or effect.

**Discretion.** A question whose answer requires an identified authorized decision beyond the executable rule fragment.

**Credential.** An issuer's signed claims about a subject, interpreted under a specified verification and trust policy.

## Rules and execution terms

**Admissibility.** Satisfaction of the conditions that permit a particular action at a particular boundary.

**Applicability.** Whether and on what basis a rule or compliance concern applies to the evaluated subject and action.

**Compliance degree.** The evaluation result within the applicable compliance fragment. It remains distinct from applicability and exemption provenance.

**Obstruction.** A structured reason why a proposed composition or transition cannot currently produce the required result.

**Lawpack.** Identified legal source material and its associated interpretation contract.

**Regpack.** Regulatory requirements and executable evaluation material for the relevant scope.

**Licensepack.** Requirements and conditions associated with licensed activities and their authorization.

**Procedurepack.** Executable operation definitions and their declared requirements, steps, and evidence contracts.

**Template pack.** An identified template and associated structural or authority conditions. Its exact contract depends on the owning system.

**Profile.** A named configuration or policy selection. A profile name alone does not identify immutable content.

**Pin.** A binding to the exact content or revision used for an evaluation or operation.

**Lex.** The rule-language contract and its reference semantics, with explicit boundaries between executable fragments and residual obligations.

**Op.** The typed workflow-language contract that represents computations, effects, and host interactions.

**Host.** The runtime boundary that supplies the permitted effects and external interactions for an execution language.

**Smart asset.** An asset representation with authorized lifecycle behavior, state, and evidence. Its autonomy is bounded by its mandate.

**SAVM.** The smart-asset virtual machine that evaluates supported instructions within its configured authority and resource boundaries.

**Continuation.** The retained execution state needed to resume an admitted computation, including pending interactions and the state that gives them meaning.

**Idempotency.** Repeated use of the same admitted request identity returns the committed result without applying its effect again.

**Replay.** Reproduction or retrieval associated with earlier work. The contract must distinguish receipt retrieval from fresh execution.

**Compensation.** A new authorized action that addresses an earlier effect under the operation's recovery policy.

**Outbox.** Durable delivery work recorded with the relevant local state, for later dispatch and acknowledgement.

**Fence.** A condition enforced at an action boundary that prevents an obsolete owner or execution generation from initiating a conflicting action.

## Evidence and storage terms

**Canonical bytes.** The prescribed byte representation of an object under an identified encoding contract.

**Content digest.** A digest of identified canonical content under a specified scheme and domain.

**Commitment.** A cryptographic binding to content. Authenticity, authority, availability, and truth require additional evidence.

**Attestation.** An authority's statement about a defined subject, property, scope, and time.

**Verdict.** The result of evaluating a specified action or claim against identified rules and evidence.

**Proof envelope.** A structured carrier of a claim, its subject and context, supporting references, status, and authentication material.

**Receipt.** A record of the result acknowledged by a particular action boundary. Its meaning follows the recorded action and status.

**Witness.** The data required to check a specified statement under its verification procedure.

**Merkle mountain range.** An append-oriented collection of Merkle trees whose root commitment and proofs follow a defined protocol.

**Content-addressed store.** A store that retrieves objects through content identities. Retrieval still requires availability and integrity checks.

**Projection.** A derived view of authoritative facts for a defined purpose. Its freshness and repair rules remain explicit.

**Epoch.** A period or revision domain used by a specific authority, key, schema, or policy mechanism. Different epoch types are not interchangeable.

**Supersedence.** An explicit relationship through which a later record changes the current interpretation of an earlier record while preserving its history.

**Anchor.** Evidence binding a commitment to another admitted record or authority. An anchor request differs from confirmed external anchoring.

## Claims, disputes, and economic terms

**Claim.** A right to a specified payoff under specified conditions, with economic terms and an institutional basis.

**PDCF.** Probability-weighted discounted cash flow, a valuation representation under identified model assumptions.

**AOT.** An admissible obligation transition that binds admission, obligations, evidence, execution, reserve, settlement, and resulting receipt conditions.

**Position.** A recorded exposure or entitlement in an instrument.

**Custody.** Control and holding of a specified asset under identified account and institutional arrangements.

**Reserve.** Value restricted for a specified obligation or risk condition.

**Clearing.** Determination of obligations and permissible offsets under the admitted clearing and netting contract.

**Settlement.** Application of the economic effects that discharge specified obligations under the settlement contract.

**Finality.** The accepted commitment status of a result under an identified system and policy. Legal recognition and external performance can require further evidence.

**Reliance.** Use of a result by a specified party for an admitted purpose under the governing recognition policy.

**Head of claim.** A distinct claim within a case, with its own subject, relief, and procedural requirements.

**Outcome.** A recorded determination, award, or settlement under an identified procedure and authority.

**Stay.** An admitted restriction on specified action while its governing conditions apply.

**Execution intent.** A request to perform a particular authorized disposition at an identified destination.

**Recovery.** Value or another effect actually obtained and reconciled to the entitled party after the relevant failure or disposition.

**Duty occurrence.** A particular instance of an obligation whose identity persists across delivery, retry, transfer, and partial performance.

**Residual exposure.** The remaining obligation or command exposure after admitted performance and adjustments under the applicable rules.

## Mathematical notation

| Symbol | Meaning |
|---|---|
| $s$, $S$ | State, with scope defined in the chapter |
| $a$, $x$ | An action or input under evaluation |
| $t$, $h$ | Time or block coordinate |
| $H(m)$ | Digest of message $m$ under the stated scheme |
| $x\wedge y$ | Meet where the stated order admits it |
| $x\Rightarrow y$ | Residual under the stated adjunction |
| $A\subseteq B$ | Every member of $A$ is a member of $B$ |
| $\lceil x\rceil$, $\lfloor x\rfloor$ | Integer ceiling and floor |
| $\mathbb{N}$ | Nonnegative integers unless the local definition states otherwise |

Symbols are local to their definitions. A type name is not a claim of wire compatibility across systems. Before implementing a boundary, use its actual schema, encoding, authority, and error contract.

# Standards and reference surfaces {.unnumbered}

The following sources define supporting standards and public reference surfaces. Their inclusion does not certify that every Mass interface conforms to every feature they describe.

The DID syntax, data model, verification relationships, and method requirements follow the vocabulary of [Decentralized Identifiers v1.0](https://www.w3.org/TR/did-1.0/). DID method behavior determines resolution and control semantics.

The issuer, holder, verifier, and credential vocabulary can be compared with the [Verifiable Credentials Data Model v2.0](https://www.w3.org/TR/vc-data-model-2.0/). The actual credential format and securing mechanism must be identified for each implemented boundary.

The [JSON Canonicalization Scheme, RFC 8785](https://www.rfc-editor.org/rfc/rfc8785), provides a reference for canonical JSON. An implementation must specify its actual accepted value domain and canonicalization behavior. Similar terminology does not establish byte-for-byte conformance.

[HotStuff: BFT Consensus in the Lens of Blockchain](https://arxiv.org/abs/1803.05069) provides the consensus research reference. Moxie's extensions, certificate policies, execution bindings, and deployment assumptions require their own verification.

Public language references are [Lex](https://github.com/momentum-sez/lex) and [Op](https://github.com/momentum-sez/op). [Stack](https://github.com/momentum-sez/stack) supplies an operator configuration surface. The gstore descriptions record dated source inspection, with implementation and proof records required for independent verification. The implementation-boundary chapters identify material differences between these reference surfaces, adapters, and executable services.
