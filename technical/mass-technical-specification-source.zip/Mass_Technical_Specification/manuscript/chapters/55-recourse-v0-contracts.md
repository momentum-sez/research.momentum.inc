# Recourse protocol and operating contracts

Recourse administers consent-bound proceedings and carries their outcomes toward authorized execution. Independent deployments retain their own institutions, records, rules, keys, and acceptance policies. Network routing, practitioner matching, adjudication, and recovery each have distinct records. A signed referral can begin institutional review without opening a proceeding or authorizing payment.

The implementation reviewed on 6 September 2026 is committed with retained source hashes and verification output. The account below describes its contracts and the scope of those local checks. Synthetic execution evidence establishes neither sovereign operation nor authentic native economic effects. Checked computation transfer and destination-recognized award effects remain additional design and integration obligations.

## Identity, configuration, and exact authority

A deployment identity contains `network_id`, `node_id`, `jurisdiction`, and `operator_did`. Its institution configurations bind tenant, institution, authority profile, and protocol rules. The database retains the network and deployment identity. Startup rejects an attempt to reuse that database under another identity.

Deployment jurisdiction, arbitration seat, governing law, party jurisdiction, institution, Mass zone, and Moxie chain remain separate concepts. Configuration examples for candidate jurisdictions establish neither an operating institution nor adopted legal rules. Each institution must obtain the actual instruments and accepted principals for its functions.

HTTP authentication uses a bearer-token digest bound to a tenant and actor DID. A grant also carries read and write permissions, validity times, revocation, and optional case identifiers. Case checks then enforce local origin and current procedural access. A request body cannot choose a different tenant or authenticated actor.

Cryptographic authority uses an operator-supplied `AuthorityProfile`. Each trusted key identifies one principal, permitted roles, Ed25519 public bytes, validity period, and optional effective revocation. Duplicate key identifiers, duplicate public keys, weak keys, and duplicate role entries fail configuration validation. Key rotation can retain several keys for one principal, but that principal counts once toward a signature threshold.

`SignatureEnvelope` contains only a statement and signature entries. Each entry carries `key_id` and `signature_hex`. The statement has the following exact binding:

| Fields | Required meaning |
|---|---|
| `domain` | The fixed wire value `recourse.authority.v0`. |
| `network_id`, `node_id`, `tenant_id`, `institution_id` | The independently expected sovereign and institutional context. |
| `profile_id`, `profile_version` | The configured authority profile. |
| `case_id`, `purpose` | A non-nil case or context UUID and the operation-specific purpose. |
| `payload_sha256` | SHA-256 of the canonical typed payload. |
| `issued_at`, `expires_at` | The signed validity interval. |

Payload serialization uses RFC 8785 JSON Canonicalization Scheme. Numeric values must be integers within the exact interoperable JSON range. Larger counters and decimal amounts use schema-defined strings. The signature message is the domain's UTF-8 bytes, one zero byte, and the canonical statement bytes. Ed25519 signs that complete message without an additional caller-selected prehash.

Verification independently selects the expected context, purpose, role, and threshold. It checks every supplied signature, payload digest, validity interval, key status, and distinct principal. An invalid extra signature rejects the envelope even when other signatures satisfy the threshold. A signature cannot install its own trust root or confer case authority through an asserted role.

The authority envelope has no generic nonce field. Case actions prevent new replay through revision, predecessor-state digest, and unique action identity. HTTP idempotency separately preserves the result of an already admitted request. Native financial instructions retain the nonce required by their destination protocol.

Current verification applies effective revocation even to a previously issued signature. Stored verification evidence retains the historical act and its authentic bytes. Current reliance must separately assess later compromise and its effective scope. Retaining a historical receipt does not establish that every later use remains authorized.

## Preparing, admitting, and replaying an action

The client first calls `POST /v1/cases/{id}/actions/prepare` with `expected_revision`, `action`, `issued_at`, and `expires_at`. The operation requires write permission and applicable case access. It checks the current revision and signing interval, then returns a typed payload and complete signing statement. Preparation performs no protocol admission and reserves no revision.

The returned payload contains `expected_revision`, `previous_state_sha256`, and `action`. The predecessor digest commits the complete preceding `ProtocolState`, including requests, signatures, recording metadata, and rule snapshots. This binding prevents an omitted earlier challenge or stay from disappearing between ordinary case mutations.

The caller reviews the normalized payload and compares every statement field with independently accepted configuration. It then obtains the required external signatures. The submitted `ProtocolAction` adds `authority` to those exact payload fields. The server rejects unknown fields and evaluates the operation under the purpose derived from its action type.

An action encodes its name in `type` and its typed fields in `data`. Its signing purpose is `recourse.protocol.<action_name>`. For example, `confirm_consent` and `issue_outcome` have distinct purposes even when they reference the same agreement or proceeding.

Admission obtains the SQLite writer with `BEGIN IMMEDIATE` before checking current access, replay identity, revision, and protocol validity. A successful transaction commits the protocol resource, case revision, event, and original response together. The resource preserves the exact request, verified signers, actor, recording time, and rules snapshot. Failure leaves the successful state transition and response absent.

The replay namespace combines tenant, actor DID, route, and `Idempotency-Key`. The key permits 1–128 visible ASCII characters. A repeated identity and normalized body returns the saved result. A changed body produces `idempotency_mismatch`. Current access checks precede replay, while replay lookup precedes fresh revision evaluation.

This ordering permits an authorized exact retry after subsequent case changes. It also denies a revoked delegate access to a saved response. The replayed revision describes the original action. A separate read obtains current state. Protocol action responses contain the affected resource, while execution mutations use a smaller receipt that exposes no proof or recovery totals.

## Consent, representation, and custody

Consent binds both parties, every claim, agreement bytes, complete filing digest, institution, seat, governing law, and configured rules. The filing digest includes claim descriptions, amounts, and native object references. A replacement consent names its predecessor and requires new jurisdiction and procedure findings. Both parties must authorize consent directly or through specifically scoped representation.

Consent also names institution, review, service, execution, and reconciliation principals. Institution and review principals must differ from both parties and from each other. An active party representative cannot become a neutral institution principal, review principal, or tribunal member. These restrictions prevent a directory role or broad account grant from supplying adjudicative independence.

A delegation identifies its grantor, delegate, principal kind, claims, powers, instrument, effective time, and expiry. The original grantor signs revocation. Whole-case reads require coverage of every claim. A narrower submission can use action-specific authority without receiving the entire case. Provider permission to submit a fee receipt likewise supplies no general case access.

Artifact custody is separate from an evidence reference. `UploadArtifact` contains `expected_revision`, `artifact`, and `content_base64`. An artifact reference preserves digest algorithm, digest value, and media type. Upload accepts canonical padded base64, checks the exact bytes under the declared SHA-256 or BLAKE3 algorithm, and enforces a 4 MiB limit.

`ArtifactRecord` retains its UUID, artifact reference, byte count, uploader, and upload time. Signed actions can reference only artifacts already in custody. A recorder can therefore upload appointment or disclosure material before the appointed human signs the corresponding action. Digest equality establishes byte identity under the selected algorithm. Procedural admissibility still depends on competent decisions and any challenges.

An outcome also commits selected evidence records in an explicit order. `evidence_records_sha256` covers their identifiers, submitters, times, revisions, kinds, descriptions, and artifact references. Replacing metadata under an unchanged evidence UUID invalidates that commitment. Empty evidence selection commits the canonical empty array rather than an unspecified value.

## Procedure and retained obligations

A signed service record describes claimed delivery of an exact filing, notice, or outcome. A competent institution or tribunal then records the finding that makes service effective. Jurisdiction requires effective filing service to both parties. Notice and outcome deadlines use the latest effective delivery under the configured rules. Later invalidation restricts dependent proceedings and outcomes.

Procedure adoption names a proposal, jurisdiction finding, served notice, timetable, reasons, and predecessor. The evaluator prevents adoption below the highest required tier across the claim assessments. Contested record integrity, a hearing request, or an election for full proceedings requires the full tribunal proposal. Open challenges and applicable proceedings stays prevent adoption.

Tribunal appointment names a human, covered claims, instrument, qualifications, effective time, and expiry. The member signs acceptance and a disclosure after appointment. Subsequent disclosures form a predecessor chain. Appointment alone permits its acceptance or disclosure action. General tribunal access requires the additional acceptance and case-authority checks.

The outcome contract retains three distinct kinds. A determination requires record resolution and the consent-named institution. An award requires a tribunal procedure and the configured quorum of accepted human members for the covered claims. A settlement requires distinct signatures from both parties or their authorized settlement representatives.

`Outcome` binds its UUID, kind, claim identifiers, procedure, document, reasons, selected evidence, obligations, superseded outcomes, and issue time. Each `Obligation` has its own UUID, claim, obligor DID, beneficiary DID, performance artifact, and optional exact decimal amount. A successor outcome must explicitly supersede overlapping current outcomes and cover their claims. A determination cannot replace an award or settlement through relabeling.

Challenges can address consent, jurisdiction, service, procedure, evidence, appointments, disclosures, outcomes, and stays. A review signer cannot review their own challenged decision or appointment. An unresolved challenge restricts the affected claims. An upheld challenge invalidates the targeted resource for subsequent reliance while preserving the record.

Stay orders distinguish proceedings, execution, and both scopes. Imposition, variation, and lifting preserve the predecessor's claims and authority type. A future successor cannot lift an effective predecessor early. A contested lift preserves the preceding restriction, and an upheld challenge can restore it. A completed destination effect retains its evidence despite a later order.

The local outcome-readiness predicate checks consent, jurisdiction, procedure, effective service, challenge time, supersession, evidence restrictions, and execution stays. Award readiness requires a human appointment and acceptance that preceded the award and covered every outcome claim. The appointment must have been effective and unexpired when the award was recorded, and its authority must remain uncontested. Later appointment expiry does not invalidate the earlier award. A new appointment cannot repair an upheld challenge to its original authority. Destination reliance still requires its own current admission checks.

Disposition records whether proceedings closed, completed, were dismissed, or were superseded. The completed disposition means that proceedings are complete. Its current admission requires an outcome; economic recovery is not a precondition. Every disposition's `preserved_obligation_ids` retains all recorded obligations, including those from superseded outcomes. Closing proceedings leaves unpaid obligations, execution history, and recovery records intact. Debt disappears only through an independently established discharge rule.

Disposition ends proceedings in that case. The evaluator rejects later consent confirmation, jurisdiction findings, procedure proposals, procedure adoptions, outcomes, and repeated disposition. Permitted administrative actions retain their authority requirements and preserve the `disposed` status. These include review, stays, service, representation, fees, and appointments for continuing administrative duties. A rejected jurisdiction finding permits competent dismissal, while other disposition kinds require accepted jurisdiction.

## Matching, fees, and client access

The professional directory stores profiles and private representation matters separately from cases. Profiles contain declared jurisdictions, languages, specialties, availability, and biography. The server labels qualifications `self_claimed_unverified`. Matching requires availability and every requested qualification tag. Results explain the matched criteria without assessing professional quality.

A client initially has exclusive matter access. A contact request identifies both the lawyer UUID and the reviewed profile revision. The transaction rechecks availability, eligibility, profile revision, and matter revision before recording selection. Only the client and selected lawyer can then read the disclosed matter. A second selection cannot silently replace the recipient.

Lawyer acceptance changes the matter from `contact_requested` to `accepted`. It records acceptance of the contact request. Engagement terms, conflicts review, case delegation, fee acceptance, and tribunal appointment retain their own authority. A matching result exposes no unrelated proceeding or evidence.

Fee schedules pin amounts, providers, beneficiaries, and deployment or protocol attribution. A quote selects schedule items, payer, document, and expiry. The payer accepts before the institution charges an item. A provider signs each receipt with a unique provider reference. Exact decimal addition prevents receipts from exceeding the accepted charge through floating-point rounding.

HTTP, TypeScript, and MCP clients share these authority checks. The SDK provides generated operation types and explicit action-signing helpers. It takes caller-selected keys or signing callbacks and sends no private key to the service. Its independently supplied expected binding must constrain the returned preparation statement.

| Entry point | Contract exposed to the caller |
|---|---|
| `GET /v1/node` | Configured deployment profile and authenticated tenant and actor. |
| `POST /v1/cases` | Filing with stable caller-supplied idempotency identity. |
| `POST /v1/cases/{id}/actions` | Signed lifecycle action and its recorded resource receipt. |
| `PUT /v1/directory/lawyers/me` | The authenticated professional's own versioned profile. |
| `POST /v1/directory/matters` | A private client matter for representation matching. |
| `GET /v1/destination-profiles` | Public profile fields for configured execution destinations, under read authentication. |
| `POST /v1/cases/{id}/execution-intents` | Exact authorized instruction and durable outbox admission. |

Execution detail, observation, cancellation, and recovery routes share the intent's case and UUID. The four mutation forms return only `case_id`, `intent_id`, `resource_id`, and `recorded_at`. Read operations separately expose current delivery evidence and cumulative recovery. The worker has no public dispatch route.

The SDK preserves request identities and performs no automatic mutation retry. MCP exposes generated operations through a configured actor credential and has no signer. Capabilities and runtime OpenAPI identify enabled modules. Client metadata cannot activate an absent network or execution module. Retained HTTP checks exercise the workspace proxy and actual local service. Browser interaction, keyboard navigation, and visual layout remain unverified.

An `AiWork` action records the authenticated actor, delegation, covered claims, purpose, model provider, model identifier and version, and tool versions. It also binds input artifacts, output, provenance, and production time. The actor must supply the sole signature. A nonparty actor needs active delegation with both submission and AI-work powers for every covered claim. This record establishes accountable preparation without appointing the software to a tribunal.

## Referral, disclosure, and independent recognition

Network configuration pins the local authority profile, peer identities, fixed endpoints, exact source rules, and receiving policy. Received payloads cannot replace those settings. Peer discovery authenticates a description from a configured institution. It grants no authority over another deployment.

An initial `ReferralPayload` contains specified metadata, both source party DIDs, and all source claim UUIDs, with an empty artifact list. Both parties sign `network.disclosure`. The source institution separately signs `network.referral`. The source compares the stated parties and claims with its stored case before admitting the bundle.

Artifact transfer uses a new referral UUID and an accepted metadata referral as its parent. Source case, parties, claims, and both institutional identities must match that parent. The new signatures cover exact artifact identifiers, digests, media types, and bytes. The receiver independently verifies those bytes and applies its disclosure limits.

A receiving policy refusal records rejection and retains the received signed bundle. Consequently, policy rejection can still leave disclosed bytes in receiving storage. The sender must obtain disclosure authority before transmission. A receiver's willingness to accept material cannot substitute for that authority.

Before network transmission, the source commits an `unknown_delivery` observation. A matching HTTP receipt establishes `delivered_unconfirmed`. Only the receiving institution's verified decision establishes acceptance or rejection and binds its independent receiving UUID. An exact referral retry compares the complete signed bundle and preserves that receiving identity.

Withdrawal first becomes durable at the source. The receiver can authenticate and retain a withdrawal tombstone before the original referral arrives. Referral insertion checks the tombstone within the same writer transaction. A later admissible matching referral remains withdrawn and uses the tombstone's receiving UUID. Withdrawal cannot retrieve disclosed bytes or automatically cancel an independently opened case.

Opening a receiving case requires an accepted metadata referral, both source parties' signatures, and the local institution's signature. `CaseOpeningPayload` binds the source case, referral, receiving identity, bundle digest, both institutional identities, and complete new filing. One transaction records the new local case, filing event, immutable origin link, and replay response.

The receiving case has a new UUID and local origin. It begins with empty evidence, artifact custody, and protocol history. The source case UUID and referral receiving UUID remain separate. Local custody, consent, service, jurisdiction, and appointment must establish the new proceeding under local rules.

Recognition has a different object. `PortableOutcome` carries the complete source case, every artifact record and exact bytes, selected outcome, selected claims, destination, accepted referral, and expiry. Both source parties authorize the complete disclosure. The source institution authenticates the portable payload.

The receiver verifies byte custody and replays the protocol history against independently pinned source profiles and rules. Replay checks signatures, signer derivation, revisions, predecessor commitments, metadata, and the filing commitment. The implementation requires an exact trusted rules snapshot for the case history. Unconfigured profile or rule versions fail verification.

The receiving institution signs a `RecognitionPayload` binding the complete portable digest, receiving UUID, current policy version, and reasons. Insertion rechecks accepted referral state. Recognition concerns that disclosed snapshot. It proves no completeness of subsequent source events and creates no payment authority. Later execution requires fresh evidence for current restrictions and destination admission.

## Exact execution and the dispatch barrier

`CreateExecutionIntent` contains an `IntentPayload` and three authority envelopes. The consent-named executor signs `execution.intent`. The actual obligor signs `execution.voluntary_authority`. The actual beneficiary signs `execution.beneficiary_authority`. Every signature covers the complete payload, including account mapping and instruction bytes.

The payload binds its UUID, expected revision, outcome, obligation, exact claim, destination profile and version, native target, policy, account reference, and mandate. It also carries asset identifier, raw amount, instruction bytes, declared instruction digest, and expiry. Policy, mandate, and account artifacts must already be in case custody.

The destination fixes currency and decimal scale. Conversion from the outcome amount to raw units must be exact. Rounding, overflow, changed account mapping, and mismatched amounts fail admission. The record preserves both the declared digest algorithm and a separate SHA-256 commitment to the complete HTTP instruction bytes.

Intent admission atomically commits the intent, bytes, outbox entry, case revision, event, and replay response. Another active intent cannot reserve the same obligation. The destination configuration digest binds endpoint, profile, trust configuration, and credential reference. A changed configuration blocks the old instruction until its exact requirements are resolved.

The worker reserves an eligible unsent intent and commits an immutable attempt with a bounded lease. A second writer transaction forms the final dispatch barrier. It rechecks case authority, restrictions, destination identity, and remaining lease. The transaction stays open until response headers arrive or the bounded HTTP operation fails. A stay committed before this barrier prevents transmission.

The worker checks current case submission authority using the recorded creator's actor identity. It does not re-evaluate the original bearer grant's validity as a separate dispatch credential. Operator acceptance must therefore distinguish grant revocation from the current case authority that this worker actually checks.

A reserved attempt interrupted by a process failure becomes uncertain when its lease expires. Timeout, interrupted response, oversized response, and unsuccessful HTTP status also preserve uncertainty. The worker does not automatically repeat an attempted economic instruction. Cancellation requires executor and obligor signatures and is limited to an unsent intent or a durably prevented attempt.

`custodian_transfer` accepts exact bytes under `recourse.custodian-transfer.v0`. The instruction binds request, case, outcome, obligation, provider, obligor, beneficiary, account, asset, raw amount, policy, mandate, destination, and expiry. The custodian must separately accept its account mandate and requested effect.

`moxie_voluntary_transfer` accepts one exact `moxie_submitSigned` JSON-RPC request. Its request identifier equals the intent UUID. The native payload preserves transaction bytes, signature, signer, numeric chain identifier, and cryptographic epoch. The account artifact retains `from`, `to`, and decimal-string `nonce`. A configured native verifier checks the signed Transfer before enqueueing.

The configured effect kinds also name `kernel_award_enforcement` and `moxie_award`, but intent validation rejects those unsupported native award effects. A voluntary transfer supplies no general award carrier. Destination acceptance of Recourse authority, exact obligation, action scope, result identity, and portable proof remains an integration requirement.

The proposed Mass contract for [recognition and native effects](#recognition-native-effects) addresses that destination boundary. It must bind current action authority and the resulting native proof to the exact accepted Recourse obligation. Its adoption remains separate from the source capabilities described here.

## Effect evidence, recovery, and restart

Execution observations retain original evidence bytes and their digest. A failed proof can remain visible with `verified_effect: null` and `verification_error`. Successful verification produces `EffectEvidence`, which binds intent, outcome, obligation, exact instruction, native target, effect ID, asset, amount, beneficiary, account, and delivery status.

A custodian receipt uses an independently pinned evidence principal distinct from the parties and named executors. The principal signs the exact effect under `execution.custodian_receipt`. This record authenticates a provider statement. Its economic meaning remains bounded by the provider evidence profile and the accepted custody arrangement.

Native evidence contains an independently signed block expectation, native receipt, native events, and finality proof. The expectation fixes transaction hash, chain, epoch, block number, block hash, state root, and receipts root. The service supplies a fixed trust configuration and its expected SHA-256 to the verifier. Both processes check the digest, and the verifier parses the exact bytes that passed its check. The service rejects verifier responses whose SDK revision differs from its complete pinned native contract revision. The service closes the input pipe after writing the complete request. It compares returned native identities, effect, domain, and block coordinates with the persisted instruction and independent expectation.

These comparisons rely on the configured verifier implementation. The destination configuration digest does not itself authenticate executable bytes. Native acceptance evidence must therefore bind the actual verifier binary and its trust provenance to the exercised instruction and proof.

The delivery status `transport_accepted` records successful HTTP transport. Verified positive delivery establishes `finalized`, while a verified negative receipt preserves `uncertain`. A later transport response cannot overwrite that independent evidence. Recovery requires independently proved delivery and the authorized reconciliation record. Current recovery completion additionally requires zero outstanding amount and a `finalized` outbox state.

`RecordRecovery` binds expected revision, observation UUID, exact amount, and reconciliation artifact. A consent-named reconciler signs the payload under the intent-specific recovery purpose. Each recovery consumes one verified effect once. Raw-unit arithmetic preserves cumulative recovery and the outstanding balance without SQL numeric conversion or binary floating point.

Economic deduplication uses system, native target, and source effect identity. Destination aliases and profile versions cannot create a second allowance. Conflicting authenticated effects remain visible and mark affected intents `contradicted`. Verified effect evidence for a cancelled instruction also contradicts every intent for that case obligation. This blocks queued or reserved replacements and invalidates their current recovery completion. Earlier recovery receipts retain their authentic historical fields.

For an illustrative obligation of USD 120,000, a proved USD 70,000 delivery supports that partial recovery and leaves USD 50,000 outstanding. A stay can block further dispatch while retaining the credited amount. Fees, offsets, currency conversion, or another discharge basis need explicit terms and their own evidence. Administrative closure preserves this remaining debt.

The initial operating arrangement uses separate storage and configuration for each deployment. Execution defaults to `reconcile_only` when configured. Restoring a database requires preserved identity, authority profiles, rules, and external configuration, followed by reconciliation of effects after the backup. A restored queued record can describe an instruction that the original process later delivered.

When the snapshot retains the exact intent but lacks its later attempt, independently verified positive delivery can establish the effect and stop dispatch. The service preserves the proof without inventing an attempt or transport record. Invalid proofs, transport assertions, and negative receipts cannot use this exception. Recovery still requires the authorized reconciler's signature. An intent absent from the snapshot requires a separately authorized recovery path. Safe replacement after uncertainty also requires durable closure of the original instruction and prevention of delayed execution.

Live-state succession requires more than this backup procedure. Checked continuations, complete duties and occurrences, command exposure, portion and cash reservations, and unacknowledged deliveries need authenticated custody and effective predecessor fencing. Returned cross-store credit remains encumbered until the authoritative original ledger commits reopening and required current admissions pass. These requirements preserve the distinction between a local recovery record and accepted transfer of an institution's unfinished work.

## The retained local verification boundary

Initial retained local checks record 94 service-suite passes and one separately executed transport-crash test. Successor verification records 95 service-suite passes, including the crash test, and repeats the explicit native process and bounded verifier regression checks. They also record 11 native-verifier tests, one explicit API-to-verifier process test, 16 client tests, and one actual-service client journey. Workspace evidence records 36 tests and seven HTTP journeys. These are results from identified retained runs, inspected for this edition; this manuscript review did not rerun them.

The native process test uses synthetic finality and the actual service and verifier executables. It rejects a wrong block, corrupted quorum signature, and changed observer statement. It sends no instruction to a native destination and establishes no economic recovery. An earlier retained run exposed an input-pipe timeout; the explicit pipe closure and subsequent passing process and regression checks identify the repaired boundary.

The transport-crash test terminates the actual service after a local destination receives the complete instruction and before any HTTP response. Restart retains dispatch permission, the uncertain attempt, and the original instruction bytes while producing no duplicate send. Only separate signed synthetic delivery and authorized reconciliation complete recovery. Another restart preserves the original replay responses and accounting.

These observations leave general native award effects, permanent closure of uncertain commands, absent-intent restoration, and institutional continuation transfer open. Hosted operation also requires a reachable configured service, actual institutional authority, key custody, and destination acceptance. A successful local HTTP workspace journey does not establish those operating conditions or browser usability.
