# Causal evaluation and accountable performance

A coupon can resolve while its payment remains incomplete. Two missed USD 10 coupons followed by a successful trigger can create USD 30 due. If the provider pays USD 20, the remaining USD 10 survives the reset of the coupon calculation.

These chapters propose the economic requirements that connect calculation, authority, funding, and performance. **Shall** states a required property. A **reference construction** gives a mathematical model or bounded realization under stated assumptions. The cited papers supply constructions and proof obligations. Governing instruments and admitted implementation contracts determine which transitions a deployment may perform.

## Order every producer of an input

A **producer** supplies a typed value at a scheduled event. Claim calculations, oracle reports, clearing results, risk calculations, and settlement observations are producers. Its contract shall identify its output unit, schedule, authority, implementation or external semantics, and complete read set. A read set includes data dependencies and dependencies that control which branch executes.

The historical payoff profile orders claim references by earlier block heights. The reference construction in *The Claim as Primitive* also permits certified dependencies within one event. Let $h$ be a nonnegative integer event height and $N\geq1$ bound its active producer count. Give each producer $v$ a dimensionless integer rank $r_h(v)$ between zero and $N-1$. Its combined rank is

$$
R(v,h)=Nh+r_h(v).
$$

A same-event read shall use a producer with smaller local rank. A historical read shall name an admitted instance at an earlier height. Each dependency then decreases $R$. Finite read sets give a finite ancestor set. Completion additionally requires admissible external evidence, fair scheduling, and computation within the admitted resource limits.

For example, an account observation supplies USD 100. A gross calculation reads it, a fee calculation applies one tenth, and a net calculation subtracts the fee. Their ranks order the observation, gross amount, fee, and net amount. The resulting USD 10 fee and USD 90 net payment become obligations only through their respective position legs. An auxiliary rate or risk calculation creates its value and retained evidence without creating another payment entitlement.

The certificate shall cover all relevant reads, including conversion witnesses and both branches of a conditional. An external producer retains its explicit dependency-completeness assumption until its actual semantics establish those dependencies. An oracle that reads clearing, where clearing reads the consuming payoff, produces a cycle despite an acyclic local payoff program.

A rejection shall identify that cycle. A permitted historical lag can remove it when the earlier input exists and remains admissible. A simultaneous model instead needs an existence result, an admitted solution-selection rule, and certified numerical execution. Changing a producer's label or computation budget supplies none of those conditions.

## Preserve directed entitlements

A **directed entitlement** records an amount owed by a specified debtor to a specified creditor. Its stable origin identifies the issuance, position lot, resolution event, and contractual leg. It shall bind the original program, inputs, parties, asset, governing terms, payment window, and discharge route.

Let $q$ be a signed quantity in contracts and $v$ the resolved payoff in settlement units per contract. Their product $z=qv$ determines direction, while $A=|z|$ is the amount due. A positive $z$ makes the contractual counterparty owe the holder. A negative $z$ reverses those roles. Exact retries shall return the same origin record. Assignments change the effective owner through an authorized transition while retaining the original record.

For one entitlement, let $L$ be effective legal discharge and $B$ the unpaid balance, both in its settlement unit. The journal shall preserve

$$
A=L+B,\qquad 0\leq L\leq A.
$$

A payment increases $L$ only through a supported allocation or another expressly authorized discharge rule. A return can reduce $L$ through the governing reinstatement rule. A command's cancellation or completion does not determine these quantities.

A correction shall append a directed adjustment against the latest accepted correction. If $z_0$ is the original signed amount and $t_j$ the newly authorized target, define

$$
d_j=t_j-z_0-\sum_{i<j}d_i.
$$

All terms use the same asset and account orientation. Acceptance shall compare and advance the correction predecessor atomically. Targets of 100, then 80, then 70 require adjustments of minus 20 and minus 10. The original entitlement and each adjustment retain separate unpaid balances until payment or authorized setoff. Their algebraic sum alone supplies no setoff authority.

## Allocate actual performance once

A **physical occurrence** is one actual transfer or delivery under its authoritative provider identity. Repeated reports, reporting aliases, and different claim references shall resolve to that occurrence. A receipt records evidence about it. Its quantity becomes usable only under the admitted identity, beneficiary, asset, finality, and attribution rules.

Allocation shall use stable portions of that quantity. An implementation can represent monetary portions as intervals in an exact settlement unit. The portion identity retains its physical source when its owner changes. Across the affected products and accounts, every portion has one effective allocation history.

Exclusive allocation governs the specified cash or title resource. Shared performance evidence can support separately constituted rights without creating additional goods, title, or cash. For example, one accepted delivery can earn both supplier consideration and a separately contracted handling fee. Each payment still needs its own funded discharge.

At a reconciled evidence revision, let $Q$ be supported quantity and $U$ unallocated quantity. Let $R$ denote reserved quantity or reconciliation holds, and $S_c$ supported allocation to claim $c$. These disjoint quantities shall satisfy

$$
U+R+\sum_c S_c=Q,\qquad U,R,S_c\geq0.
$$

Disputed historical allocations remain recorded outside supported capacity. For a USD 100 receipt allocated USD 60 and USD 40, a correction to USD 90 exposes USD 10 of disputed support. The governing correction rule identifies the affected portions. Restoring the receipt to USD 100 restores those portions to their retained owner before any free capacity is calculated.

An evidence correction creates a new assertion about the same occurrence. An actual refund creates a distinct debit occurrence. Ordinary spending by the recipient changes current cash while preserving the original payment attribution. These operations shall retain separate identities and consequences.

Returned credit crossing stores shall remain `ReopenPending` and encumbered until the authoritative original ledger commits reopening and required current admissions verify. A destination's receipt of money alone shall not release that credit for another obligation. The retained record shall identify the original payment, its portions, the return, and the accepted reopening. Recovery must continue when either side has committed and the other side remains unresolved.

Reopening shall preserve consumption of the original payment's portions. Only the separately identified return can acquire new eligibility under its governing allocation rules and the required admissions.

Authentic historical receipts shall retain their exact bytes. Current reliance separately evaluates effective policy, revocation, and retroactive compromise. A changed reliance decision shall append its basis and affected consequences without replacing the historical receipt.

## Commit allocation with the obligations it changes

The joint transaction shall include affected occurrence revisions, portions, funding reservations, claim bases and versions, balances, and authority dependencies. It shall commit request nonces, consumed identifiers, command outcomes, and receipts with those changes. It shall also bind the policies that determine this complete footprint. A claim-local update cannot leave its payment portions available elsewhere.

One authoritative store can serialize this footprint in a durable transaction. Independent stores require a durable preparation, decision, and recovery protocol accepted by each authority. External delivery remains outside a local database transaction. An uncertain delivery retains its reservation until conclusive reconciliation. Exact committed retries shall return the retained receipt without another allocation or dispatch.

*Event-Collect BFT* supplies a narrower, useful allocation construction. A closed batch contains finite eligible occurrences and payable obligations in one divisible unit and direction class. An admitted compatibility relation specifies which occurrence can serve each obligation. Fixed allocations and reconciliation holds reduce available supply before optimization.

Consider two one-unit occurrences, $a$ and $b$, and two one-unit obligations, $x$ and $y$. Occurrence $a$ can serve either obligation, while $b$ can serve only $x$. Assigning $a$ to $y$ and $b$ to $x$ completes both. Assigning $a$ to $x$ first can leave one unit unusable.

The construction represents this problem as a capacity-constrained flow. A cut separates source and destination, and its outgoing capacity bounds every feasible flow. A feasible flow whose total equals a cut's capacity has maximum value. The reference orders compatible pairs by their pinned occurrence and obligation identifiers. Among maximum totals, it chooses the lexicographically greatest allocation vector, comparing the first unequal coordinate.

A residual graph records permitted increases and decreases to a proposed flow. Further cuts in that graph certify the canonical choice. The certificate shall bind current supply, demand, fixed portions, holds, compatibility evidence, authority, and predecessor state. Atomic application consumes the batch identity with its resulting allocations and receipt.

This theorem concerns the admitted closed batch. Binding priority, aggregate limits, indivisible lots, and all-or-nothing packages need explicit feasible-set constraints. Future arrivals can permit a better unrestricted allocation while existing legal assignments remain fixed. The paper's single-store realization assumes authentic acts, one authoritative ledger for shared physical roots, and durable transactions. Deployment refinement must establish those assumptions through the actual allocation and persistence boundaries.

# Capital sufficient to complete obligations

A plan that pays USD 100 before receiving USD 100 has zero net cash loss and needs USD 100 at the payment deadline. Completion requires cash at each permitted decision, with every resulting debt retained. A margin estimate answers a different, specified risk question.

## Calculate the cash needed by each continuation

*Central Counterparty Risk in Automated Markets* constructs a finite observable state graph. A state records the history available to the decision maker. It includes unpaid obligations, resource limits, encumbrances, provider conditions, and action authority. States may merge only when their retained information permits the same future continuations.

At state $s$, the permitted action set is $A(s)$. Selecting action $a$ first pays $d(s,a)$ and retains a cash floor $h(s,a)$. A subsequent observation selects a successor $z$ from $Z(s,a)$ and supplies signed cash increment $g(s,a,z)$. All cash quantities use one declared settlement unit. If current cash is $b$, the next cash balance is

$$
b'=b-d(s,a)+g(s,a,z).
$$

Each admitted action has a nonempty successor set and finite signed increments. Debits, floors, and terminal payments are finite and nonnegative. The action and outcome data depend on recorded noncash state. Cash affects their feasibility only through the specified requirements.

Every intermediate deadline and payment-order constraint shall have its own state. A facility draw must occur before a payment that needs its proceeds. Terminal state $t$ has payment requirement $m(t)$, including every remaining repayment, fee, and represented obligation.

Define $K(t)=m(t)$. The required cash for each action and state is

$$
T(s,a)=d(s,a)+\max\left\{h(s,a),\max_{z\in Z(s,a)}[K(z)-g(s,a,z)]\right\},
$$

$$
K(s)=\min_{a\in A(s)}T(s,a).
$$

The minimum of an empty action set is positive infinity. It identifies a state that finite cash cannot complete under the permitted actions.

For finite acyclic graphs with finite action sets, backward induction gives an exact result: a completing policy exists precisely when $b\geq K(s)$. The model assumes that retaining additional cash preserves permitted continuations. Necessity follows because the selected action must fund its immediate debit and every possible successor. Sufficiency follows by selecting a minimizing action and repeating the same argument at the observed successor.

The minimum precedes the maximum because the action is chosen before its outcome becomes known. Reversing their order would give the decision maker information from the future. Every provider-failure branch required by the stress contract shall appear among the successors. An omitted branch remains an omitted obligation of the model.

## Keep risk reserves and funding distinct

**Expected shortfall** averages loss over a specified upper tail of a probability distribution. Its tail fraction, information set, horizon, and loss model shall be explicit. For four equally likely losses of 0, 0, 0, and 100 settlement units, the worst-half average is 50 units. If an observation separates the first pair from the second, the conditional worst-half averages are 0 and 100 units. Their worst-half average is 100 units.

Conditional risk budgets can restrict permitted actions. The completion calculation still requires actual cash and the correct receipt order. Replacing its maximum over possible successors with expected shortfall changes the guarantee from every represented branch to the stated risk budget.

For a selected policy $\pi$, let $K_\pi$ be the completion recursion restricted to that policy's actions. An independently retained margin $M$, constant through terminal discharge, gives requirement $K_\pi(s)+M$. Margin already included in the floors or terminal obligations shall be counted once. A changed margin requires a current funding check. Released cash becomes available only through the governing release authority and encumbrance rules.

Degraded operation shall retain the maximum of the current floor, stress and physical-risk requirements and the immediately preceding committed required margin. Each committed update becomes the retained requirement for the next update, including across restart. If that preceding requirement is unavailable, collateral release remains blocked until it is reconstructed. An unknown legacy requirement cannot be replaced with zero or a fresh healthy calculation. An initialization rule must establish that no prior requirement exists; an absent record does not prove that condition.

Restored model health alone cannot clear degraded mode. Recovery requires a recorded decision, healthy checks, fresh synchronized inputs, completed repricing, and reconciled settlement obligations. New risk and withdrawals remain halted during degraded operation. Physical-risk coverage retains its declared uncertainty set and calibration assumptions.

## Retain facility repayments and shared capacity

Assume a facility supplies USD 60 before a USD 100 payment. It requires USD 65 repayment after a separate USD 65 receipt. Its draw limit permits one draw. Initial completion cash is USD 40. Adding independently retained margin of USD 30 gives this sequence:

| Event | Cash balance | Remaining constraint |
|---|---:|---|
| Admission | USD 70 | USD 30 margin remains reserved |
| Facility draw | USD 130 | USD 65 repayment becomes due |
| Payment | USD 30 | Margin remains intact |
| Separate receipt | USD 95 | Repayment still requires performance |
| Repayment | USD 30 | Margin awaits an authorized release |

For completion cash alone, removing the later receipt raises the draw route's initial requirement to USD 105, including repayment cost. An available cash-only route requires USD 100. Adding a facility-failure branch also raises the original route's root requirement to USD 100. The separate USD 30 margin remains additive in each case. These amounts follow from the stated timing and branch assumptions.

A draw shall consume remaining facility capacity and create its repayment liability. Mutually exclusive branches may share an undrawn limit. Concurrent plans require one joint resource state and aggregate reservation. Changing the product, claim, or service name shall not create another limit against the same account.

For workflow $f$, a durable cash projection can use

$$
C_f=b_f^0+F_f+R_f-P_f-W_f.
$$

Here $b_f^0$ is assigned initial cash, $F_f$ physical funding, $R_f$ returned cash, $P_f$ gross physical payments, and $W_f$ released cash. Each term uses unique physical occurrences in the same asset and unit. Returned cash in this projection remains subject to its reopening encumbrance. Facility promises enter capacity records and add cash only when their physical credits arrive.

Preparing a payment shall reserve both its duty portion and available cash. An unresolved command retains possible further expenditure. Graph progress shall wait for the required payments, observations, and reopened obligations. Repeated reports create no additional cash. A previously released amount remains subtracted even if an earlier payment later returns.

The finite reference correspondence covers one controlled durable store, integral settlement quantities, truthful admitted observations, current permissions, and represented resource capacities. Live timing, custody, facility enforceability, and complete provider behavior require independent evidence. Multiple currencies need separate balances and admitted conversion actions. Closing a workflow shall preserve any unpaid duty, outstanding command, or unsettled recovery obligation.

# Reserve instruments, title and market risk

A reserve market needs transferable instruments with defined owners and redeemable rights. A number produced by a payoff calculation acquires those properties through custody, title, funding, and redemption rules. Market pricing shall retain their separate economic roles.

## Account for physical title and redelivery

*Allocated Title* assigns permanent identities and quantity coordinates to physical lots. Reporting aliases, custody movement, and assay revisions retain those identities. Supported portions are free, reserved, allocated, or held for reconciliation across the participating accounts and custodians. Impaired evidence reduces usable support while retaining ownership and any resulting deficit. Restored support returns to its retained owner.

Registered title and beneficial ownership can belong to different parties. A transfer shall specify which interest changes, with current authority, required acknowledgments, and continuing restrictions. Redemption shall lock existing units and identify beneficiary, provider, quantity, delivery evidence, and remaining entitlement. Partial performance consumes only its supported portion. An exact committed retry returns its historical result without changing current locks or unpaid balances. Pending retries retain their original command identity.

Lending requires the holder's signed election and current product authority. The election shall bind borrower, quantity, term, fee, and security. Borrower acceptance and custody release convert present allocated title into the corresponding redelivery obligation. That claim supplies no present metal inventory.

Actual redelivery requires intake, assay, uniqueness, and capacity checks. A partial return leaves the remaining quantity due. A pledge preserves title while adding the admitted security interest. Redemption shall retain its restrictions until effective release or authorized enforcement.

Physical performance can itself earn payment. In the paper's proportional example, a 100-kilogram obligation carries USD 1,000 consideration. Accepted delivery of 40 kilograms earns USD 400 and leaves 60 kilograms undelivered. Acceptance shall bind the receiving party's reserved decision, exact physical portions, and every required measurement, custody, and delivery witness. It creates one original directed payment entitlement. Later corrections append their monetary consequences while preserving accepted performance and actual payments.

Continuing the same right through another execution cohort shall retain those allocations and current liabilities. A fresh program instance cannot refresh the underlying goods budget. Conditional title and the seller's funded settlement entitlement can share one legally operative durable decision under the required instruments. This construction requires exclusive metal and funded-asset reservations, rights that survive interruption, and authority at the decision stage. Physical handover and withdrawal still require their own performance evidence. Executed custody instruments, pledge perfection, measurement truth, and product-specific authority remain external obligations.

## Fund a signed payoff without losing its financing leg

The reserve construction in *The Claim as Primitive* handles a bounded signed payoff $f$ for one resolution, measured in settlement units. Suppose $-L\leq f\leq U$ throughout the declared funding domain, where $L,U\geq0$. Choose a positive buffer $\epsilon$ in the same unit. Set

$$
a=L+\epsilon,\quad b=U+\epsilon,
\qquad W^+=a+f,\quad W^-=b-f.
$$

Both note payouts are positive and their sum is $a+b$. A complementary pair therefore requires that many dedicated settlement units. Its net gains are $W^+-a=f$ and $W^--b=-f$. The transferred note and its principal contribution or financing debt shall remain separate records.

For $f\in[-2,3]$ and $\epsilon=1$, the notes pay $3+f$ and $4-f$ against seven units of backing. At $f=-2$, payouts are one and six, while net gains are minus two and plus two. Ten pairs require 70 dedicated units. A market's trading cash is a separate resource and cannot also be counted as that backing.

Recurring payouts need separately funded instances or explicit aggregate reservations for the admitted schedule. An unbounded signed payoff requires a margin and default construction, or successively funded intervals, because a finite shift cannot cover every possible payout. Failure to fund the next interval shall preserve existing entitlements and their recovery route.

## Finance changes to an automated market

An **automated market maker** maintains reserves under a pricing rule. Changing that rule can transfer economic value even when its asset inventory stays fixed. *One-Way Coupling of Prediction Markets to Automated Market Makers* gives a funded construction with a separate sponsor account.

Let $B$ be asset inventory, $B_*$ an anchor inventory, and $x=\log(B/B_*)$. Let $g>0$ be a dimensionless control and $K>0$ an anchor cash reserve. Pool cash obeys $M=Ke^{-gx}$. A control change to $g'$ at unchanged inventory requires

$$
\Delta=K(e^{-g'x}-e^{-gx}),\qquad M'=M+\Delta,\qquad C'=C-\Delta.
$$

The sponsor balance $C$ and transfer $\Delta$ use the same settlement unit as $M$. Admission requires funded $C'\geq0$, an allowed control interval, and an allowed inventory band. Pool and sponsor changes shall commit atomically. Concurrent control requests share the same sponsor reservation.

An asset trade at fixed $g$ exchanges the exact inventory and cash changes against the trader, while respecting the inventory band. Together, these rules conserve pool, sponsor, and trader cash, as well as their combined asset quantity.

Within this closed, fee-free construction, restoring initial inventory and control gives aggregate trader cash gain $C_0-C_T\leq C_0$. The bound identifies the financing source. Reporting incentives and outside portfolios require their own payoff contracts and enforceable funding. The construction supplies no independent claim of truthful signals or deployed sponsor custody.

## Express hedges in compatible units

A derivative profile shall bind contract multiplier, payoff asset, funding-payment rule, fee schedule, and payment clock. For an illustrative linear hedge, ten spot units offset five short contracts only when each contract represents two asset units. At USD 20 per asset unit, each side has USD 200 notional. The local price exposure cancels under those assumptions. Basis changes, periodic funding, liquidation costs, timing, and counterparty default remain in the obligation and risk models.

Cross-margining shall evaluate those legs in one full loss model. Candidate hedge discounts cannot subtract the same risk factor twice. In *Central Counterparty Risk in Automated Markets*, let $R_{\mathrm{full}}$ be the full portfolio loss charge, including nonlinear and numerical allowances. Let $m_{\mathrm{floor}}$ be its admitted minimum margin. Both are settlement-currency amounts. The required margin is

$$
m_{\mathrm{cross}}=\max\{R_{\mathrm{full}},m_{\mathrm{floor}}\}.
$$

Candidate discounts shall not reduce this result further. The derivative's actual periodic funding contract remains a required product input.

The proposed perpetual-position contract retains funding across position changes. Each generation binds account, market, signed size, entry price, settlement asset, margin, funding index, accrued funding, realized claims, and lifecycle. Before changing size or side, compute newly accrued funding using the old size and side. Add that delta to durable accrued funding and advance the index in the same transition.

Funding settlement reduces accrual only through supported committed performance. Insufficient margin leaves a residual. A zero-size generation remains while margin, funding, or another claim survives; reopening creates a fresh generation. Account equity includes every unsettled generation while counting shared collateral once. Changing the active-position pointer cannot hide a debt or credit.

Reductions, closes, liquidation, and automatic deleveraging follow the same preservation rule. A haircut can reduce an eligible profit claim under its governing contract. It cannot independently debit posted margin or create cash. These requirements prevent a position lifecycle change from being mistaken for settlement.

Pricing covariance also needs its stated interpretation. A log-partition cost is a scaled logarithm of a positive weighted sum of exponentials of portfolio payoffs. Its Hessian, the matrix of second derivatives, is proportional to payoff covariance under the associated pricing probability law. Physical loss forecasts require a separately justified observation model, horizon, and calibration.

*Parlay Identification of Ising Couplings* recovers a two-event interaction from a strictly positive joint probability table. A parlay pays when both named events occur. Singleton and parlay prices determine that table under the stated pricing interpretation. Inside a larger network, the inversion gives an effective pair interaction that can include other events' influence. Pairwise compatibility alone cannot establish a joint law for the whole portfolio.

Risk admission shall therefore retain the complete loss map, compatible probability evidence, parameter uncertainty, and information available at each decision. Those records support a funding decision only together with the authoritative cash, title, reservation, and obligation records defined above.
