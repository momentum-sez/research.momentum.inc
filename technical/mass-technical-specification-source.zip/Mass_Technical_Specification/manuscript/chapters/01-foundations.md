# Programmable organizations

## The unit of work

A company appoints a director, issues an investment instrument, receives a payment, or files a required return. Each action changes several related facts. An appointment can require an eligible person, a valid resolution, signed acceptance, updated records, and acknowledgement from a registrar. A message saying that the appointment succeeded cannot substitute for those effects.

Mass makes this work programmable. A program states the intended action, the organization concerned, the required authority, and the evidence on which execution depends. Rules determine which transitions are admissible. Services apply the permitted changes. Durable records preserve the result and any remaining obligation.

An organization is more than its registration record. Its operating state includes people, offices, ownership, agreements, assets, liabilities, permissions, and procedures. Some facts belong to the organization. Others belong to registrars, banks, custodians, counterparties, or courts. The system must preserve that division when it automates a process.

**Definition: organizational action.** An organizational action is a requested transition in organizational state, under specified authority, with a defined set of required effects. The action has an identity independent of the number of attempts used to complete it.

**Definition: required effect.** A required effect is an independently meaningful change promised by the action's contract. Its completion requires evidence from the authority that owns the change. Examples include an updated officer record, a signed instrument, a provider transfer, or a registrar acknowledgement.

A process that requires a signed instrument and a registry update remains incomplete when only the instrument exists. The correct state can be waiting, partially complete, failed, or compensating. The vocabulary must reflect the actual contract. Operators need the outstanding obligation and the next permissible action.

## Intent, authority, and admissibility

An instruction states what a principal wants. Authority states which actions the principal or its delegate may initiate. Admissibility states whether a particular action satisfies the applicable rules and current conditions. These are independent questions.

For example, an authenticated shareholder can request a share transfer. The request alone does not establish transfer authority, satisfaction of preemption rights, buyer eligibility, or settlement. The runtime must evaluate the declared action against the relevant ownership and rule state.

Use the following abstract admission relation:

$$
\operatorname{Admit}(a,s,r,e,k,t)\in\{\operatorname{Permit}(w),\operatorname{Refuse}(q),\operatorname{Wait}(o)\}.
$$

Here $a$ is authored intent, $s$ is state, $r$ is the pinned rule set, and $e$ is supporting evidence. The variables $k$ and $t$ specify current authority and evaluation time. A permit carries a witness $w$. A refusal carries reasons $q$. A wait carries unresolved obligations $o$.

This relation is a specification model, not a universal wire format. Individual APIs can use different response types. Each API must preserve the distinction between permission, refusal, and missing requirements. A parser or typechecker cannot create an authority that the principal lacks.

Authored values must remain attributable to authored input or authenticated identity. An absent signatory cannot become the requester merely because that value is convenient. A missing legal entity cannot become a newly synthesized identity. A required jurisdiction or instrument term must remain unresolved until its proper source supplies it.

## A state model for institutions

For design purposes, represent organizational state as

$$
S=(I,H,G,O,A,L,P,W,E).
$$

$I$ contains identity bindings. $H$ contains jurisdictional presences. $G$ contains governance rules and offices. $O$ contains ownership and control relations. $A$ and $L$ contain assets and liabilities. $P$ contains permissions. $W$ contains active work and duties. $E$ contains retained evidence.

The tuple describes information that the system must account for. It does not require one database row, one service, or one shared consensus process. Ownership of each component follows the relevant business domain and external authority.

A jurisdictional presence, called a **harbor**, binds an organization to a jurisdiction and the recognized basis for operating there. A harbor records its own registration, licenses, rules, and ongoing obligations. Simultaneous harbors can share organizational identity while retaining different legal and operational conditions.

Adding a harbor requires a new admissible relationship. It does not transfer every license, erase earlier duties, or automatically confer recognition elsewhere. If two harbors impose incompatible conditions, composition must return the incompatibility. The system cannot turn an unresolved legal conflict into a passing scalar score.

The operating model needs two notions of time. **Effective time** identifies when a fact applies in the modeled world. **Record time** identifies when the system recorded it. A late notice can change the interpretation of an earlier period without erasing what the system knew when it acted.

Programs must therefore bind the relevant time and rule state. Re-evaluation under current rules answers a different question from reproduction of a historical decision. A historical permission can remain valid evidence while current authority has expired or been revoked.

## Duties survive process boundaries

A duty identifies an obligation, its responsible party, its performance conditions, and its remaining exposure. A workflow instance is one mechanism for administering that duty. Restarting or transferring the workflow does not create a new duty or discharge the original one.

Represent a duty occurrence by a stable identifier and preserve its portions, cash reservations, and execution exposure. Late performance reduces the relevant residual exposure under the duty's rules. Closing a command does not prove that an unpaid debt has been satisfied.

This distinction controls migration and recovery. A receiving system needs enough state to continue the same work with the same obligations. It must not infer completion from the predecessor's last status string. The chapters on durable execution and Recourse develop the required continuation and transfer contracts.

## Design choices and their consequences

Mass uses a common admission and mutation boundary because business domains share authority and audit obligations. Native services retain domain ownership so that entity rules, investment rules, and identity rules remain explicit. The composition root supplies dependencies and assembles the public service.

Durable workflows support long-running action because external acknowledgement can arrive after the initiating request ends. Content identities bind rules and evidence because mutable names alone cannot reproduce a decision. Typed identifiers preserve distinctions because a valid byte string can still denote the wrong class of object.

Sovereign deployments retain authority over their own state. Corridors carry recognized evidence and bounded requests between deployments. Moxie adds a settlement authority for admitted claims. Recourse adds a dispute procedure and outcome authority. These boundaries make uncertainty and incomplete delivery explicit.

The product objective includes lower operating cost, reduced manual work, and autonomous execution of permitted actions. These outcomes require measurement against a defined process and service level. The architecture does not supply a universal headcount ratio, transaction-cost reduction, or deployment timetable.

## Implementation boundary

The current Mass source contains native organizational primitives, rule evaluation, operation execution, and proof and audit structures. It also contains incomplete authoring, civic, storage, and cross-system paths. Later chapters identify those paths directly.

The common mutation boundary is a required architecture, with known ordering exceptions in the examined implementation. Agentic corridor dispatch commits its database transition before runtime admission. Beneficial-ownership edge creation and termination also persist before proposing their runtime mutation. A later admission failure cannot roll back those earlier commits. These paths do not satisfy the required co-commitment of admitted business state and evidence.

The organization model is wider than the set of workflows demonstrated in a running environment. A conformance claim must identify the particular action, its required effects, and the evidence that joins them. This book preserves that distinction while specifying the complete intended operating model.

# System boundaries and native primitives

## Responsibilities of the connected systems

Mass owns institutional state transitions and their admission. Moxie owns native claim admission, market execution, clearing, settlement, and finality within its configured network. Recourse owns case administration and the records that establish a dispute procedure and its outcome.

An outcome can authorize a request to another system. The recipient must still check its own action-specific authority and current conditions. A Recourse award does not itself debit a Mass account or settle a Moxie claim. Those effects require the destination's accepted contract and durable acknowledgement.

| Boundary | Owning responsibility | Required distinction |
|---|---|---|
| Mass | Organizational records and regulated action | Local mutation versus external effect |
| Moxie | Claims, custody, clearing, settlement | Submission versus native finality |
| Recourse | Procedure, outcomes, execution coordination | Award versus recovered property |
| Provider | Signing, banking, registration, or other specialized service | Requested work versus provider acknowledgement |
| Application | Presentation, authored input, and observation | Displayed state versus authoritative state |

The application can be a browser, SDK consumer, or agent using the Model Context Protocol (MCP). It supplies intent and presents progress. It must carry the principal's identity and scope through the supported runtime interface. Client-side validation improves interaction but cannot replace server-side admission.

![Selected authority boundaries. Direct integration between other pairs must satisfy the same recipient admission and acknowledgement contract.](manuscript/figures/authority-boundaries.png){width=6.5in}

## Primitive ownership

The native primitive partition assigns business decisions and persistence to an owning domain. The API layer routes requests and composes services. A database facade performs domain persistence within the applicable transaction. An external adapter translates a provider contract without becoming a second owner of organizational truth.

**Identity** owns profiles, identity links, verification, accreditation, invitations, and related evidence. It distinguishes an editable profile from a provider verification decision. Identity work supplies facts that other domains evaluate under their own rules.

**Entity** owns organizational identity, incorporation and registration records, officers and relationships, jurisdictional presences, and provider registration interactions. Registration state and permission to conduct a licensed activity are separate records.

**Governance** owns resolutions, consents, ownership records, share classes, corporate actions, vesting, and related agreements. Its required contract applies the electorate and approval rule appropriate to the action. A board decision must not silently substitute for a shareholder decision. The current electorate and fallback limitations are described under Corporate consent.

**Investment** owns fundraising and investor participation contracts, agreement state, payment state, and related administration. Instrument families carry distinct authored terms. A subscription, a future-equity agreement, and a token agreement cannot become interchangeable because each raises money.

**Treasury and payment work** connects account authority, transaction records, fees, and provider operations. Permission to read an account differs from permission to transact. A recorded payment request differs from a confirmed provider transfer.

**Templating and signing** turn authored legal content and approved data into instrument bytes and signing submissions. The document's content identity, signatory authority, provider submission, and completed signature are separate facts. Rendering a PDF proves none of the remaining facts by itself.

Other native services support notifications, dynamic letters, service providers, and organizational intelligence. Their composition must retain the same authority and effect boundaries. A notification cannot become proof that its recipient accepted an agreement.

## External compute and provider boundaries

The configured Java compute boundary comprises treasury and templating services. Native Rust services own identity, entity, governance, and investment business logic. The eProspera provider adapter is a separate native provider boundary.

For the intended Mass deployment, institutional persistence belongs to the Mass runtime. Treasury compute and provider work return through supported persistence APIs. Templating compute and signing integration must run under the profile that directs institutional persistence through Mass.

The inspected templating source also contains a separate persistence profile. Consequently, deployment profile selection is a real acceptance condition. A statement about the intended Mass topology cannot establish the profile of an uninspected running service.

At every provider boundary, record the request identity, intended effect, provider reference, and response evidence. An ambiguous timeout leaves the effect uncertain until reconciliation resolves it. Blind repetition can create duplicate transfers, submissions, or filings.

## State machines compose through contracts

An entity, license, investment, signing submission, and workflow each have their own state machine. Their terminal states answer different questions. A dissolved entity can still have retained records and outstanding recovery obligations. A completed signing submission can coexist with an unpaid investment.

The source investment model separates payment status from investor signature. Its current-investment query treats a paid but unsigned investment as live. Within that predicate, consummation requires payment marked paid and the investor's signature. Other legal and operational conditions remain the responsibility of the enclosing instrument and workflow.

The signing state machine admits transitions from awaiting signatures to signed, declined, or archived. Repetition of the same state has no new transition effect. A terminal signing state cannot simply move back to awaiting signatures. A replacement instrument needs its own explicit identity and procedure.

These examples establish a general requirement: the enclosing process must derive completion from the required component facts. It must not choose whichever component first reports a terminal status.

## Identifier and document discipline

Identifiers belong to domains. An authenticated user identifier, an entity UUID, a document key, a content digest, a case UUID, and a native chain object identifier have different semantics. Adapters must validate the destination type and preserve the source association.

A document key identifies an object in the document store. A signed URL grants temporary retrieval access. A content digest commits to bytes under a specified encoding and digest scheme. A provider submission identifier denotes a signing process. None is a substitute for the others.

An update must distinguish omission, clearing, and replacement when the contract supports all three. For example, an omitted document-key field preserves the existing value. An explicit null can clear it. A supplied key replaces it. Flattening these states in a client can silently change the user's request.

Money must retain denomination, scale, sign convention, and representation. Human decimal amounts and native fixed-point integers require explicit conversion. A bridge must reject ambiguous units and overflow. It must not reuse a value merely because both APIs accept strings.

## Implementation boundary

The current source mounts public HTTP routes that call the owning native services. Physical route-file placement is an implementation detail. Domain ownership and the transaction contract are the architectural requirements.

The active investment web application invokes typed operations for incorporation, governance, investment, and related work. Those calling paths establish integration structure. A workflow's availability still depends on its pack, authority, provider configuration, and observed execution.

This specification does not certify every primitive route or provider deployment. It requires each supported action to preserve authored input, scope, domain ownership, and durable effect identity across the boundaries described above.

# Identity, governance, and consent

## Identity assertions and verified properties

An identifier names a subject. Authentication binds a presented credential to a caller. Verification records a checked property of a subject. Authorization permits a particular action under current conditions. Combining these into one flag makes review and recovery unreliable.

A decentralized identifier (DID) uses a method-specific identifier and resolution procedure. Its syntax does not imply that the identifier itself is content addressed. Resolution can associate keys and services with the subject. The verifier must apply the actual method and trust policy.

A verifiable credential records an issuer's claims about a subject. The verifier checks the signed content, issuer authority, subject binding, validity, and applicable status or revocation. A valid signature establishes the signing relationship under its assumptions. It does not establish the substantive truth of every asserted property.

Identity information can come from a person, an organization, or a provider. The record must preserve which source supplied it. A format-valid national identifier remains an assertion until an authorized process verifies the relevant binding. A registry-shaped type does not establish a live registry connection.

## Verification and accreditation lifecycles

The source identity service models verification states such as not started, started, pending, verified, rejected, expired, and reset. Its transition rule permits a provider approval to reach verified from any prior state. This accommodates a provider's later re-review of the same inquiry.

That transition rule relies on the caller supplying an authenticated, inquiry-scoped provider decision. It is a pure state predicate. It must not be exposed as permission for arbitrary callers to overwrite identity status.

Accreditation has a distinct lifecycle. Pending decisions can become verified or rejected. A verified accreditation can expire. Rejected or expired cases can return to pending with renewed evidence. An identity check and an accreditation decision therefore require separate state and provenance.

A jurisdiction or operation can require a set of verified properties. The requirement must identify the property, acceptable issuer, validity interval, evidence, and purpose. This specification does not prescribe a universal numerical KYC tier with the same legal meaning in every jurisdiction.

## Capability delegation

A capability grants bounded authority. Attenuation derives narrower authority from an existing grant. In set notation, if $A_i$ is the set of actions admitted by grant $i$, valid attenuation requires

$$
A_{i+1}\subseteq A_i.
$$

The subset relation is a semantic requirement. Comparing labels or attaching an additional text condition is insufficient if the resulting evaluator widens authority. The capability verifier must check the supported narrowing rules and reject unsupported combinations.

MassBiscuit provides a signed attenuation chain with caveats. The program-admission path checks the chain, its revocation state, and the program's capability binding. It also checks signer association and effective constraints such as operation family, jurisdiction, and time.

The epoch-witness verifier supplies a specific non-revocation mechanism. A trusted revocation authority signs an epoch, observation time, and commitment to its revoked-capability set. The proof must concern the presented capability and establish its exclusion from that committed set. The composed verifier checks chain integrity, capability identity, trusted witness signature, freshness, and the exclusion proof. Chain verification alone does not perform these witness checks.

The inspected witness verifier accepts timestamps within thirty seconds on either side of its clock and rejects larger offsets. This freshness and clock-skew allowance is distinct from token lifetime. A stale, missing, mismatched, or invalid witness cannot establish current authority. The proof-fetch interface can report that no fresh proof is available or that its cache is unconfigured; neither response establishes non-revocation. Deployments must identify the actual revocation path used at admission, its trusted roots, and its clock assumptions.

Entity delegation APIs expose grants, revocations, and subdelegation under entity-scoped authorization. The enclosing service must verify the current grant for each new action. Historical validity of an earlier action does not authorize a later action after revocation.

Authentication mechanisms remain distinct from this program authority. A bearer token can establish a session and coarse scope. The actual route contract determines whether it additionally requires a signed program, attenuated capability, governance approval, or provider authority.

## Corporate consent

A consent binds a proposed action to a defined electorate and decision rule. Its record must preserve the action, electorate snapshot, required threshold, authored instrument content, and votes. Later changes to the board must not silently reinterpret an already conducted vote.

The source distinguishes board, board-meeting, and shareholder electorates. Meeting attendance can govern a meeting resolution. A sole-director shortcut applicable to a board action does not automatically apply to a shareholder or meeting action.

The current persistence model retains the electorate count and rule, rather than a complete frozen voter set. Vote admission checks current director or administrator membership for every consent; share ownership alone does not authorize a vote. In addition, shareholder operation steps substitute board quorum when no cap table or active shareholder electorate exists. These behaviors limit the implementation's electorate guarantees and must not be mistaken for the stronger contract above.

For an electorate of $n$ voters, the implemented simple-majority threshold is

$$
m(n)=\lfloor n/2\rfloor+1.
$$

A percentage threshold $p$ uses $\lceil np/100\rceil$. A fractional threshold $a/b$ uses $\lceil na/b\rceil$. The source validates the authored ranges and requires at least one approval. A zero-electorate bootstrap requires an explicit policy at the enclosing consent boundary.

These thresholds are predicates over a specified electorate. They are not universal statements of corporate law. The applicable instrument or governance pack selects the rule and the authority that may use it.

For fixed thresholds, the implementation requires the same number of votes to reject as to approve. Consequently, all ballots can be cast while the consent remains pending. Four voters with a threshold of three and a two-to-two division are one example. A complete procedure needs an explicit rule for an exhausted electorate that reaches neither threshold; it must not infer that the implemented tally has resolved the motion.

The relative rule "votes for exceed votes against" has different semantics. Let $f$ and $a$ be votes for and against, and let $u$ be uncast ballots. Approval becomes irreversible when $f>a+u$. Rejection becomes irreversible when $a\geq f+u$. Otherwise the vote remains pending.

For example, consider five eligible voters with two votes for and one against. Two ballots remain. The result remains pending because either side can still determine it. With three votes for and none against, two remaining votes cannot reverse approval.

The source also models force approval as a separate tally outcome. Its arithmetic evaluator does not authorize the override. Caller and office checks belong to the service that records the vote. The override must preserve the acting authority and its legal basis.

## Approval, signing, and effect

Approval decides a motion under its governance rule. Signing records a person's execution of particular instrument bytes in a specified capacity. Applying the corporate action changes the relevant business state. Each stage has its own evidence.

A signing callback must bind the provider submission to the expected instrument and signers. The receiver authenticates the callback, checks replay identity, validates the state transition, and reconciles the final document. It then applies the authorized downstream effect through the owning mutation path.

Duplicate delivery must preserve the original result. A repeated signed event must not issue another security or repeat a payment. A changed payload under a previously accepted event identity must be treated as a conflict, not another valid retry.

Replacement or amendment needs explicit lineage. Changing template content after a signing submission begins cannot silently change what an existing signature means. The final artifact must remain bound to the bytes and capacities that the parties actually signed.

## Ownership and control

An ownership graph records economic and control relationships among subjects. Each edge needs its relationship type, validity interval, evidence, and relevant percentage or control attribute. Legal control can arise through mechanisms other than equity ownership.

For a simple equity chain, indirect participation multiplies the edge fractions. If one entity holds 60 percent of another, which holds 40 percent of a third, the path contributes 24 percent. Multiple paths, overlapping holdings, cycles, nominees, and non-equity control require additional rules.

The current control-graph traversal uses bounded breadth-first exploration and a visited set keyed by entity. This prevents repeated visits and terminates cycles. It does not by itself prove complete aggregation of all economic paths to a beneficial owner.

An ultimate-beneficial-owner conclusion therefore needs the jurisdiction's control rules and sufficient source evidence. An empty traversal result means that the inspected graph found no qualifying relationship within its model. It cannot prove that undisclosed beneficial ownership does not exist.

## Civic governance

Civic governance extends the authority model to citizens, ballots, offices, petitions, and public procedures. The required contract binds eligibility, notice, voting window, tally method, quorum, and certification. Constitutional amendments must satisfy the procedure authorized to change those rules.

An amendment contract shall identify eligible proposers, the exact proposed text, notice and deliberation periods, the electorate, and the required quorum and approval threshold. It shall distinguish amendable provisions from reserved matters and specify any additional chamber, referendum, or external assent. Admission of the replacement rules must bind the old authority, completed procedure, resulting text, effective time, and treatment of work already in progress. The amendment cannot authorize itself by invoking the new rule before that rule becomes effective.

Office eligibility shall apply the governing term limits and disqualification rules to the relevant service history. A new account or identity document must not reset a person's term history. Where eligibility depends on disputed facts, the procedure needs an authorized determination and a recorded result before seating the officeholder. These are required governance semantics, not a claim of a general implemented constitutional evaluator.

The source vocabulary includes direct and representative democracy, parliamentary and presidential forms, consultation, councils, technocratic forms, hybrids, and custom forms. These types describe configurable structures. Their presence does not establish a complete evaluator for each constitutional system.

Ballot secrecy and eligibility are separate properties. An opaque eligibility-proof field does not establish a zero-knowledge protocol. A correct tally requires an admitted ballot set, duplicate-vote controls, a defined counting rule, and certification by the proper authority.

Rotating authority across regions is a possible operating design. A valid realization needs a signed schedule, unambiguous time interpretation, handoff rules, and protection against simultaneous incompatible authority. This specification does not claim a general rotating-governance runtime is implemented.

## Implementation boundary

Corporate consent, verification, accreditation, and signing have concrete service and state-machine implementations. Their correctness still depends on the surrounding authentication, persistence, provider, and operation paths.

Civic types include ballots and tally results, but the inspected production source does not construct the general tally result. National-registry type definitions likewise do not establish operating registry channels. A deployment must close these specific integration obligations before claiming civic or registry functionality.

# Agents, observation, and authored decisions

## Delegated organizational work

An agent can prepare an action, monitor a condition, or initiate permitted work for an organization. Its authority must come from a current grant. The grant must identify the principal, permitted actions, scope, limits, and revocation conditions.

Autonomy means that the agent can act within this authorized envelope without a new human instruction for each instance. It does not give the agent authority to alter its own mandate, choose an absent signatory, or decide an unresolved legal question merely by producing text.

The runtime should separate observation, proposal, approval, and execution. An observation supplies information. A proposal supplies candidate intent. An approval satisfies a specified decision requirement. Execution performs the admitted effect. Each transition needs its own source and authority.

## Durable applications and work orders

The target application contract separates package publication from organizational installation. An immutable package record binds publisher, executable bytes, dependencies, requested capabilities, declared effects, and pricing. Each installation requires its own grant binding organization, package version, principal, permitted operations, data scope, budgets, expiry, and governing approval. Publishing a package does not authorize it to operate an organization. Expanding permissions requires a new admitted grant.

An upgrade must preserve the original package, authored parameters, and authority history of pending jobs. A failed upgrade retains the identity of the serving revision. Rollback requires evidence that the previous executable can interpret current persistent state; replacing executable bytes cannot reverse an admitted business effect.

Removal stops new submissions and enters a draining state. Eligible pending work can be cancelled under its recorded policy. Work already sent retains its execution and reconciliation obligations. A responsible institutional owner remains identified until termination or an authorized handoff is durable. Executable access may be removed only after the required termination or separately authorized handoff evidence is durable. Removal does not erase provider, dispute, or recovery duties.

A work order binds the authored outcome, immutable inputs, proposed plan, permitted actions, budget, acceptance conditions, and unresolved assumptions. An agent run records a particular attempt to advance that order. Finishing the run does not satisfy the order. Retrieved documents remain evidence and cannot change its permissions, signing principal, or acceptance conditions.

A scheduled firing binds the schedule, rule revision, occurrence coordinate, job, and command identity. Cancellation and dispatch contend on that same durable record. A lost commit response cannot create another firing. Later attempts preserve the occurrence and use current authority for their next permitted effect.

Learning proposals likewise separate evaluation, ratification, and application. Candidate and baseline must use the same evidence and frozen evaluation plan, with explicit observation window, thresholds, failures, and residuals. A material change creates a new proposal revision and invalidates stale evaluation or approval. Favorable shadow evaluation changes no operational rule. The exact proposed change requires separate ratification and current admission before use; historical decisions retain their original model and policy identities.

These application records are proposed requirements. They do not establish that the complete publication, installation, scheduling, removal, or governed-learning lifecycle is implemented by an existing interface.

## Triggered policies

The implemented policy vocabulary connects a trigger type, an optional condition, an action, a priority, a jurisdiction scope, and an authorization requirement. Matching first checks whether the policy is enabled and the trigger type agrees. It then checks scope and the condition against supplied event data.

Triggers cover regulatory updates, dispute events, corridor and settlement events, checkpoints, key rotation, governance, fiscal deadlines, and organizational lifecycle events. Policy actions include transfers, issuance and burning, binding changes, governance changes, corporate actions, halt and resume, and enforcement requests.

These are typed action categories. A matching policy has not yet proved that the corresponding executable operation is installed or authorized. Dispatch must resolve the actual operation and repeat the relevant current admission checks.

The examined immediate-action dispatcher does not inspect the policy's modeled authorization requirement before dispatch. For example, the corridor-failover policy specifies quorum, while the immediate halt and resume paths do not enforce that quorum requirement. Queued unsupported actions retain authorization metadata, which is a different behavior. Storing a requirement therefore does not establish the approval gate required by this specification.

Conditions use a typed predicate representation with comparisons, membership, field presence, conjunction, and disjunction. This representation should not be described as arbitrary Lex execution. Unsupported conditions must fail explicitly. Missing data must not become affirmative evidence through a convenience default.

Priority resolves conflicts only according to a declared policy. A higher-priority proposed action cannot override a sanctions rejection or widen a capability. Urgency changes scheduling. It does not change legal or financial authority.

## Model output and discretion

A language model can explain records, extract candidate facts, draft a document, or propose a rule. Its output remains a candidate artifact until the receiving contract admits it. A typed structure reduces ambiguity but does not establish that the model supplied truthful evidence.

The runtime must preserve model identity and configuration when reproducibility matters. It must also preserve the input evidence, retrieval cutoff, redactions, response, and any human decision. A cache can reproduce retained output. It cannot prove that a later fresh inference would return the same output.

Some work requires discretion. A discretion request must identify the question, acceptable deciding authority, relevant evidence, and permitted effect of the answer. Recording the answer resolves that specific requirement. It must not create a general permission to bypass further rules.

Historical validity and current authority remain separate here. An earlier approved interpretation can explain a completed action. A new action may require a fresh approval because the facts, rules, or delegation changed.

## Retrieval and provenance

An organizational query should identify the subject, purpose, access scope, and time of interest. Retrieval must respect those limits before it supplies context to a model. Redaction must apply to the actual outgoing context and preserve enough lineage for review.

The regulatory-inquiry library helper retrieves evidence as of a specified time, builds and redacts context, queries an adapter, and checks returned provenance. It can report fabricated digest references and discretion flags. These checks constrain the source references. They do not prove that every sentence is a correct legal interpretation.

The mounted inquiry endpoint uses a separate inline path with a mock model adapter. That path places retrieved text and the raw query into the prompt, and retains the full prompt in its audit draft. It does not invoke the library's redaction step. The helper's behavior must not be attributed to the mounted endpoint, and neither path establishes production model execution.

The evidence store and the model should remain separate authorities. A model must not create historical evidence by citing a digest it invented. A receiver should resolve cited evidence and verify the association before using the response in another action.

## Planning and execution

A remediation plan identifies candidate actions for unresolved conditions. Each action still needs a current executable operation, authored parameters, authority, and resources. The plan must expose missing prerequisites and distinguish simulation from admitted work.

The mounted agent `plan-and-execute` endpoint constructs plan-mode operation records and reports their identifiers as created. It does not persist those operation records; its later proof persistence records the audit result. The returned identifiers therefore do not establish resumable operations. The separate operation-plan endpoint does persist its operation record. Neither result establishes completed remediation. The user-facing process must distinguish candidate plans, durably submitted work, and outstanding effects.

Simulation has a similar boundary. A gas or throttle projection answers a resource question. Bytecode simulation answers a question about the modeled state and supported instructions. Neither can establish a future provider acknowledgement or legal decision that the simulation does not control.

## An illustrative filing process

Consider an organization whose annual filing deadline approaches. A time-based observation identifies the organization and applicable duty. The policy checks the deadline, current filing state, and its own scope. It proposes a filing operation using retained organizational records.

The operation retrieves the required accounts and identifies missing authored information. A model can prepare a draft explanation from admitted evidence. An authorized reviewer supplies any required interpretation and approves the instrument where the procedure requires approval.

The responsible signatory signs the exact filing artifact. The provider submission retains its delivery identity. A timeout after submission leaves acceptance uncertain. The runtime reconciles using that identity before initiating another delivery.

The duty closes only when the contract's completion evidence exists. If the registrar accepts the filing but a fee remains unpaid, that remaining duty stays visible. If a correction is required, the process preserves the original submission and records the corrective action under its own identity.

This is an illustrative contract trace. Availability of any particular tax or registry integration requires separate execution evidence.

For a tax calculation, the preparation stage needs an additional deterministic chain. Select transactions for the entity and reporting period, remove duplicates, retain reversals, and classify each line under the effective rule set. As a fictional arithmetic fixture, suppose admitted taxable receipts total 12,500 units, admitted deductions total 2,500, and the authored teaching rule applies ten percent to the difference. The calculation produces a 10,000-unit base and a 1,000-unit liability. These invented values illustrate computation; they describe no jurisdiction's tax law.

Retain the input lines, classification decisions, currency, rounding rule, effective rule identity, and computed report. Required human judgment must be recorded before the report becomes an authorized filing. A signature binds the approved report; a filing receipt acknowledges submission or acceptance according to its own contract. Payment and discharge of the computed liability require separate evidence. A model-generated explanation must not alter the retained calculation or create a missing receipt.

## Implementation boundary

The current ecosystem contains policy evaluation, entity delegation, operation planning, and advisory retrieval paths. A separate inference service exposes analysis and explanation, but its default or fallback engine is a mock unless a real model loads. A successful service response alone cannot establish real inference.

That service also contains typed proposal approval fields whose parser does not independently verify the claimed approval signature. Its parsed provenance can contain no input digests. Downstream consumers must therefore treat those fields as assertions until the actual admission boundary verifies them.

Application designs such as Sensoria can consume organizational identity, consent, measurement, and intervention contracts. Planning documents for such applications remain design material until executable implementations and evidence establish their behavior. They do not add authority to the underlying Mass or Moxie interfaces.

The required architecture keeps models off the final authority boundary. Any model-assisted action must still satisfy current intent, identity, rule, resource, and effect requirements. This remains true when the action is generated automatically and when its explanation is fluent.
