# Recognition and native effects {#recognition-native-effects}

This chapter proposes the destination contract required to connect Recourse outcomes and transferred checked work to native Mass actions. It specifies acceptance conditions for implementation and compatibility review. The record names below are design names; they do not identify deployed endpoints or agreed wire versions. An institution must separately authorize the rules under which an outcome can affect its registers, assets, or obligations.

The separate target-declaration implementation retains a commit preimage inside its journal but does not export the complete independently verifiable effect receipt specified here. Its submission replay still requires current execution admission and reevaluates the program before journal lookup. Historical read authorization, destination-recognized award effects, detached execution grants, returned-credit recovery, and complete checked-continuation transfer remain implementation obligations.

## The present authority-change boundary

The examined Mass delegation interface accepts `DELETE /v1/entities/{entity_id}/agents/{delegation_id}` without a typed request body. Its public write policy requires the entity operator role, `entities:write`, entity scope, and applicable credential caveats. The route returns HTTP 200 with a `MassProof`. It provides no field for a Recourse outcome, selected obligation, recognition policy, or exact signed instruction.

The public route requires `Idempotency-Key`. `X-Client-Intent-Id` is optional correlation; an absent or malformed value is treated as absent. At the default compatibility floor, an absent `X-Mass-Write-Contract` is accepted. A supplied mismatch, or absence under an elevated floor, is rejected. These headers have different functions and cannot be combined into a claim of outcome authority.

The mutation constructs an authority-revoked transition, performs admission preflight, and updates the active entity-scoped delegation. The update records the revocation actor and time. An already inactive or absent target produces no affected row and fails. The authority update and audit/outbox append share a database transaction. Fan-out follows its commit.

The returned proof has a narrower evidentiary meaning than an independently verifiable effect receipt. Its claim digest commits to five private fields: commit identifier, transition identifier, commit time, state hash, and observation identifier. Fresh commit and observation identifiers are not exported with the claim preimage. The state hash commits to the input transition; it is not a post-write database state root. The ordinary response therefore does not supply enough information to reconstruct the exact claim digest. Its output facts and response fields are absent on this path and are excluded from the general signing body.

Plain revoke uses preflight without a universal verdict. Its proof retains the missing-verdict residual and belongs to the partial signed profile. The durable proof writer returns without insertion when the verdict reference is absent. Calling that writer does not establish a retained, fully admissible proof for this route. A trusted verifier can check the envelope signature while still lacking independent evidence of the exact native action.

HTTP response replay is another boundary. The cache binds method, path and query, request body, and derived caller identity. Exact cached retries return the stored response; changed bytes conflict. Response storage occurs after the mutation handler and outside its transaction. The ordinary success cache lasts 24 hours. A crash or failed cache write can leave the effect unknown to the caller. This mechanism cannot supply permanent semantic deduplication or economic reconciliation.

## The destination-accepted carrier

A portable outcome preserves the source outcome kind: determination, award, or settlement. Recognition must retain that kind. A destination may recognize an authentic determination without granting it the powers of an award. It may also recognize an award's provenance while refusing the requested native action under its current law, policy, or authority rules.

The proposed request separates five records:

| Record | Required bindings |
|---|---|
| `OutcomeCarrier` | Source institution and case; outcome kind and identifier; exact outcome, obligation and selected-claims digests; consent and mandate; instruction bytes; source signatures; expiry and disclosed history cut |
| `RecognitionDecision` | Destination institution and store; carrier digest; exact recognized claims; policy identifier and version; decision; reasons and residuals; authority for recognition |
| `TargetAction` | Owning store, entity, native target, action and exact parameters; expected target version; original obligation and performed portions; required current grant |
| `AdmissionRecord` | Exact request digest; recognition and action bindings; admission policy and evidence cut; current authority decision; consumed identities and aggregate reservations |
| `EffectReceipt` | Admission identity; actual native effect and result identifiers; exact performed portions; postconditions; unresolved portions; signed claim preimage and verification context |

Digests must name their canonicalization and domain. The carrier preserves the exact authenticated source bytes even when Mass also decodes them into owning-domain types. A display projection cannot replace those bytes. Unknown or ambiguous action parameters fail before consumption. The destination derives its trust context from pinned policy and authenticated local state; it does not accept caller-supplied keys as their own authority.

The target action defines what success means. Revoking a delegation changes authority. Paying a beneficiary moves a specified asset. Allocating a receipt attributes an existing physical occurrence. Recognizing a discharge changes a legal obligation under the applicable rule. These actions require distinct result types and evidence. None may inherit financial completion merely because it shares a transport envelope with another action.

Outcome signatures and execution assent remain distinct. For a voluntary execution profile that requires the consent-named executor, obligor, and beneficiary, each signs the same exact payload binding outcome, obligation, target, policy, mandate, instruction, and expiry. The destination independently authenticates each named role and its scope. Award signatures cannot substitute for these execution signatures. A compulsory enforcement profile requires its own legally competent action authority and acceptance rule; it cannot silently reuse voluntary assent. Every profile remains subject to current native Mass authority.

## Detached execution authority

The proposed execution grant binds the owning store, constituting act, original obligation, action class, principal, target scope, and authority source. It also binds its generation, effective interval, revocation state, limits, and policy version. Attenuation narrows those permissions while preserving the original lineage. Shared limits require one aggregate counter across delegated children; copying a limit into each child creates excess authority.

Activation evaluates the tuple `(owner_store, act, obligation, authority)` against current destination state. An institution's authority to recognize an outcome is insufficient to execute every action that outcome requests. Recognition, custody, continuation restoration, external dispatch, and discharge each require the relevant permission. Source authority authenticates the source act; destination authority controls its local consequence.

A revoked execution grant blocks new execution. Historical retrieval uses current read authorization over the retained record. It does not reuse the old execution grant as a read credential, and it does not erase the record when that grant is revoked. Sensitive case bytes remain subject to their access and disclosure rules.

The grant also declares its required validity boundaries. A `LogicalSample` predicate evaluates authority at a specified logical sample. A `DurableEffect` predicate requires validity at the actual durable effect event. A `ProviderAcceptance` predicate requires it at the provider's accepted event. A profile can require several predicates together; each remains an independent obligation at its named boundary. These are proposed semantic profiles, not selected wire discriminants. Their receipts must identify every claimed boundary and its authenticated time evidence, including clock uncertainty.

Database locks protect records against conflicting writers; they do not stop time. A grant valid at a logical sample can expire before the database commit finishes. The sovereign allocation model's logical execution point therefore does not discharge a stronger premise about the actual durable event. The implementation must establish the selected stage through its temporal and effect protocol. A pre-commit clock check alone cannot establish `DurableEffect` or `ProviderAcceptance` validity.

## One local commit

For a local native action, admission and execution must use one authoritative transactional state. The commit includes the accepted carrier and recognition, action-specific authority check, exact consumed-use identity, deduplication record, reservations, native effect, result, signed proof or receipt, and required outbox entries. The authority and target versions checked during admission must be the versions protected by that transaction.

The transaction's footprint includes every record that determines the action's amount, permission, and remaining capacity. It includes shared parent budgets and original obligation portions where applicable. A compare-and-swap on one command row is insufficient when another command can spend the same funding or receipt slice. The owning store must serialize the complete footprint or use a verified equivalent protocol.

Rejected admission consumes nothing: no transfer token, funding, obligation portion, continuation generation, or external dispatch permission. It may produce a separately classified security diagnostic. That diagnostic must not appear as an accepted effect or alter the economic state being protected.

The successful response returns the exact retained receipt. Its signed claim includes the action, input and outcome bindings, actual result identifiers, performed portions, subject, issuer, policy and authority references, and committed record versions. It exports the claim preimage, canonicalization profile, signature profile, and trust context needed for independent verification. A digest whose required preimage is unavailable cannot satisfy this contract.

Permanent semantic deduplication binds a stable accepted-intent identity to the complete immutable accepted request. Its digest includes the exact action, outcome, obligation, selected claims, mandate, recognition decision, and required signed carriers. Reuse with any changed binding conflicts, even when the payment parameters are identical. Exact resubmission returns the original immutable receipt without rerunning the action. Receipt lookup by identity is a separate read operation. It requires current read permission but does not retroactively require the original execution grant or original request signature to remain live. A caller whose read access has been removed receives the applicable authorization failure; the historical receipt still exists.

An external provider cannot join this local database commit merely through an API call. Mass first commits the authorized intent and reservation with its outbox. Dispatch, provider acceptance, native effect evidence, reconciliation, and discharge remain distinct subsequent records. An unknown provider outcome retains its reservation and unresolved debt until independent evidence determines what occurred. Transport timeout alone cannot authorize another payment.

Replacing an uncertain original command requires a stronger closure record. It binds an authoritative complete source cut, zero remaining exposure under that command, a fence against delayed or replayed original execution, and exactly one successor binding. The relevant effect owners must enforce that fence. A signed `delivered=false` statement can report absence at its observation cut; it cannot prove that the original command will never execute later. Such a statement cannot release its reservation or authorize replacement by itself. Reopening and returned credit remain encumbered until the original ledger and every required current admission commit.

## Checked continuation and custody transfer

A checked continuation represents the complete suspended work, including what it already did and what remains owed. The proposed carrier binds program and checking-profile identities; host contract; instance identity; nonce and step ordinal; current work and control state; environment and frames; returned value indices; history and effect commitments; pending request; and the complete economic cut. That cut includes duties, occurrences, command reservations, exposures, performed portions, cash reservations, and unacknowledged deliveries.

Restoration must decode and validate the continuation directly. Reexecuting the original source program to reconstruct a superficially similar point can repeat effects or lose returned values. A decoder roundtrip establishes a representation property. Authenticated custody separately establishes that these are the authorized bytes for this transfer. Both conditions are required.

A constructor for resolved obligation portions preserves a narrower object. It can establish continuity of those constituted duties and allocations under its stated authority. It does not by itself migrate an arbitrary unresolved computation, its environments, pending effects, or future evidence requests. The complete checked-continuation carrier remains necessary for that broader transfer.

The predecessor must fence the transferred execution generation before its successor can execute. Preparation retains all deltas between the initial proposed cut and the exact admitted cut. The destination admission binds that current cut, the predecessor fence, one successor generation, durable custody, and action-specific authority. Local consumption, restoration, and receipt must commit together. Transfer and exact replay create neither dispatch nor discharge.

Independent stores need an explicit prepared-decision and recovery protocol. The source cannot release reservations because a destination acknowledgement is late. The destination cannot infer an unrecorded source fence from the same delay. An unresolved decision preserves custody and encumbrance until the protocol establishes the unique permitted executor for each transferred competence. Legitimate splits require disjoint assigned scopes and complete accounting of their shared dependencies.

Local database constraints cannot alone fence a cloned store, prevent an operator rollback, or establish that a remote history cut is current. Deployment must supply the separate anti-rollback, generation-fencing, and source-freshness evidence required by the chosen protocol. The book does not select a consensus provider, external witness, or transfer coordinator by naming these obligations.

## Returned credit and current debt

Command disposition describes an attempt: accepted, rejected, cancelled, or resolved under the relevant command protocol. It does not determine the remaining obligation. The original ledger retains payable, reserved, performed, returned, disputed, and discharged portions with their causal identities. Cancelling or closing a command leaves unpaid debt intact.

A returned payment is a new physical occurrence with a relation to the original payment. It does not erase that payment or recreate its already consumed receipt slices. The applicable obligation rule determines what must reopen. Cross-store credit remains `ReopenPending` and encumbered until the authoritative original ledger commits reopening and the required current admissions are verified. This prevents the receiving store from making credit available while the original store still records the debt as discharged.

For example, a 100-unit obligation may have authentic evidence of a completed 100-unit payment. A later return of 20 preserves that historical receipt. Pending reconciliation, the returned 20 is held. Once the original ledger admits the reopening, current outstanding debt becomes 20 under the applicable rule. A replacement payment consumes the current unpaid portion and current funding. Neither replaying the old receipt nor repeating the return report supplies another 20.

Previously released funds remain released. A later return cannot recover them by subtracting history from current balances. Funding equations must retain releases, repayments, fees, reservations, and any deficit. Recovery may create a fresh funding need even when the historical workflow once reached completion.

## Historical authenticity and current reliance

The receipt retains its original bytes, signature, issuer, key identifier, policy, and evidence cut. Verification of historical authenticity asks whether those bytes satisfied the applicable issuance conditions. Current reliance additionally asks whether a later compromise, reversal, stay, supersession, or authority change affects the proposed present use.

These decisions must be recorded separately. A retroactive compromise finding can prevent current reliance without rewriting authentic historical receipt bytes. Conversely, a valid old signature cannot establish current permission to execute again. The examined Mass proof retrieval route uses the current zone verification key; a general historical key resolver and separate current-reliance assessment remain requirements of this proposed seam.

## Acceptance witnesses and unresolved selections

| Witness | Required observable result |
|---|---|
| Valid source award, unauthorized local target action | Recognition can be recorded under its policy; native execution rejects without consumption |
| Crash after native commit before HTTP response | Exact retry retrieves the retained receipt and preserves one effect |
| Same intent identity with changed beneficiary or amount | Conflict; original receipt and effect remain intact |
| Same intent and action with changed outcome or obligation | Conflict against the complete accepted-request digest |
| Two commands sharing one budget or receipt slice | Aggregate serialization prevents excess use across both commands |
| Revoked execution grant and permitted historical reader | New execution rejects; retained receipt remains retrievable |
| Expired original envelope on receipt lookup | Authorized lookup returns historical bytes without new execution |
| Unknown external payment followed by retry | Reservation remains; reconciliation precedes any replacement dispatch |
| Signed absence observation while original delivery can still arrive | No replacement or release without complete-cut closure and an effective original-command fence |
| Grant expires between logical sample and durable commit | No claim of durable-event validity from the earlier sample alone |
| Returned 20 against a completed 100 across stores | Encumbrance remains until original-ledger reopening; duplicate return creates no credit |
| Invalid or stale continuation admission | No generation, cash, duty, or transfer token is consumed |
| Restored continuation and exact transfer replay | One restored generation; no replayed dispatch or discharge |
| Later compromise of a historical signing key | Original bytes remain; current-reliance decision records the separate finding |

These witnesses must run through the claimed API, authoritative persistence boundary, and effect provider where applicable. Shape checks, in-memory substitutes, and declared transaction helpers are insufficient evidence. The exact selected wire schema, state-version mechanism, historical key resolution, remote fencing protocol, and provider proof profile remain owner decisions. The proposed contract supplies their required semantics without representing those choices as deployed capabilities.
