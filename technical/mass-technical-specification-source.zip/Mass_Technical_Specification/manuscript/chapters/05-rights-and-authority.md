# Rights, corporate actions, and funded resources

A shareholder can retain registered title while another person receives part of the sale proceeds. A lender can hold security over the same shares. These rights concern one asset, but they authorize different acts. A program must retain each relationship when it changes ownership records, distributes proceeds, or moves an organization between jurisdictions.

The requirements in these chapters are normative design contracts. The equations establish the stated mathematical properties under explicit assumptions. Their implementation requires evidence from the actual admission, storage, and effect boundaries. The examples use assumed instruments and quantities.

## Identify the right before calculating its quantity

A **constituting act** is the instrument or authoritative event that creates a right. A **subject lot** identifies the assets covered by that act. A right record binds a stable right identity to its constituting act, subject lot, holder or beneficiary, and effective interval. It identifies any obligor and retains quantity, unit, priority, exercise conditions, transfer conditions, and amendments.

| Right kind | What the record identifies | Separate decision required |
|---|---|---|
| Registered holding | Title recorded for the named holder and lot | Effective transfer of that title |
| Economic participation | Contractual share of specified economic outputs | Authority to realize or distribute those outputs |
| Voting | Voting weight and matters within its scope | Eligibility for the particular decision |
| Security | Secured obligation, collateral, priority, and enforcement terms | Permitted enforcement and actual recovery |
| Proceeds | Beneficiary's entitlement to specified receipts | Receipt, allocation, and authorized payment |

An assignment can change the beneficiary through an authorized transition while preserving the right's lineage. A representation change preserves the existing beneficiary. A new administrator, identifier alias, or workflow instance cannot silently substitute another person.

Suppose Rowan holds 100 shares and their votes. An instrument grants Blair 40% of residual sale proceeds. A security instrument gives Casey priority up to 10 currency units. Assume all proceeds and claims use one currency. For received proceeds $z\geq0$, the allocations are

$$
c(z)=\min(10,z),\qquad
b(z)=0.4[z-c(z)],\qquad
r(z)=0.6[z-c(z)].
$$

At $z=100$, Casey receives 10, Blair receives 36, and Rowan receives 54 currency units. Their sum equals the received amount. Rowan's registered holding and votes retain their separate records. Blair's proceeds right supplies neither voting authority nor authority to debit Rowan's account.

Admission therefore binds the exact act: holding, offering, pledging, transferring, voting, or paying. Its context includes the right, persons and roles, amount and unit, destination, purpose, time, and applicable rules. Recognized foreign evidence can satisfy a named premise. Every reserved local decision remains necessary for that act. An unresolved determination of applicable scope remains an admission obligation.

## Preserve named entitlements through corporate actions

A two-for-one split converts 100 covered shares into 200 replacement shares. Suppose Blair's participation remains 40% of the covered lot. Measure that entitlement in old-share equivalents. Before the split, its coefficient is $2/5$. Each replacement share represents half an old share, so the successor coefficient is $1/5$. Both calculations give 40 old-share equivalents.

The coefficient changes because the unit changes. Blair's contractual percentage remains 40%. Keeping coefficient $2/5$ while interpreting the output in old-share equivalents would incorrectly produce 80.

For the general calculation, let $X\subseteq\mathbb Q_{\geq0}^{n}$ be a nonempty set of admitted positions. Each coordinate has a named lot and unit. Let $V=\operatorname{span}_{\mathbb Q}X$ be their rational span. A matrix $F$ with $k$ rows and $n$ columns computes $k$ selected entitlements from a position $x$.

Every row fixes its right identity, kind, beneficiary, governing act, and output unit. A permitted corporate action maps $x$ to $Px$, where $P$ has $m$ rows and $n$ columns. Its successor view $G$ has $k$ rows and $m$ columns. The rows of $G$ retain exactly the meanings of the rows of $F$. Matrix coefficients include the conversions between their named units.

The preservation condition is

$$
(GP-F)v=0\quad\text{for every }v\in V.
$$

This condition is equivalent to $GPx=Fx$ for every admitted position. A linear map vanishes on a set exactly when it vanishes on that set's span. When $X$ contains the full nonnegative orthant, the basis vectors give $GP=F$. A check on sample positions proves only those cases unless they span the admitted domain.

Composition preserves the same named rights. Suppose a second action has matrix $Q$ and successor view $H$. If $HQ=G$ on $P(V)$, then $HQPx=GPx=Fx$ for every $x\in X$.

These equations compare specified entitlements. They supply no conservation law for market value. A merger can preserve claims to replacement securities and cash while their prices change. Its rows must keep those units separate. Priority waterfalls, changing denominators, and other nonlinear terms require their own state-dependent functions. Equality of relabeled numbers cannot establish preservation of those rights.

## Fund the correct estate

A **legal estate** identifies the assets and obligations to which a resource belongs under the governing arrangements. Each funding pool identifies its estate, canonical account or custody allocation, asset, unit, and permitted uses. Account aliases resolve to the same resource. Separate estates using one account require supported disjoint allocations.

For a pool, let $c$ be recorded cash, $e$ its senior encumbrances, and $r$ its pending reservations. All quantities use the same asset and unit. With $(x)_+=\max(x,0)$, define free cash $f$ and shortfall $s$ by

$$
f=(c-e-r)_+,\qquad s=(e+r-c)_+.
$$

A new reservation $a\geq0$ requires $a\leq f$, permitted use, and current authority. The test and reservation must form one serialized transaction over the canonical resource. Consuming a reserved payment decreases cash and reservation equally. Releasing an unused reservation requires evidence that its command can no longer perform that amount. A timeout leaves that question unresolved.

If the pool initially covers its commitments, these transitions preserve coverage. Reservation consumes at most free cash. Performance decreases $c$ and $r$ equally, while a justified release reduces $r$. An authenticated external debit can reveal a shortfall. The record must then retain the commitments and show $s$.

An operator estate with 100 currency units cannot fund an 80-unit client payment from an empty client estate merely through shared control. An authorized loan can transfer 80 and record the corresponding receivable and liability. A prior operator reservation of 30 leaves only 70 free, so that transfer requires additional funding or an effective release. Transfers between providers retain separate debit and credit evidence. Expected destination cash becomes spendable only under its receiving ledger's credit rules.

# Authorized programs and viable continuations

An action can fit a delegate's permission and still damage another party's right or strand a promised delivery. Admission needs three additional accounts: actual effects on rights, aggregate delegated use, and the remaining route to the required outcome.

## Authorize the semantic effect

Changing one fee-schedule field can change amounts owed under many contracts. Permission to edit that field covers the storage action. Authority to amend the affected contracts depends on their governing terms.

Let $I$ be the complete registered set of relationships within the action's scope. For each $i\in I$, let $\rho_i(s)$ describe its rights in state $s$. The description includes holder, obligor, terms, performance, priority, maturity, and discharge conditions. Creation or removal uses an explicit absent value. The actual impact of a proposed transition is

$$
\mathcal I(s,s')=\{i\in I:\rho_i(s)\ne\rho_i(s')\}.
$$

The proposal declares a set $J$ covering this impact. Admission requires current amendment authority for every changed projection, binding its old terms, new terms, and effective time. The governing rule can require consent or identify another competent authority. The model preserves that distinction.

The membership of $I$, its generation, relevant rules, and selecting queries are protected dependencies. Admission must detect a newly affected contract before commitment. Under complete coverage and faithful projections, $\mathcal I(s,s')\subseteq J$ establishes authority for every changed relationship. Every relationship outside $J$ retains its projection. Discovering all relationships and correctly interpreting their terms remain substantive obligations. A list of written columns cannot prove either premise.

## Share delegated budget counters

Giving ten delegates individual limits of 100 can authorize 1,000 units of aggregate use. Scope attenuation alone cannot enforce a principal's total limit of 100. Every descendant must retain the same canonical budget account.

Fix resource coordinates with explicit units, purposes, and accounting windows. They can separately constrain lifetime expenditure, daily expenditure, and a project's exposure. A command charges every applicable coordinate. All budget, charge, and reservation vectors are nonnegative and use these coordinates. Let $B_c$ be capability $c$'s limit vector. A child narrows its parent's scope, validity interval, and coordinate limits.

Let $s_c$ be charge already attributed to $c$ and its descendants within those accounting rules. For command $k$, let $r_k$ be its unresolved reservation vector. Let $\operatorname{chain}(k)$ contain the authorizing capability and all its ancestors, each exactly once. Aggregate use is

$$
U_c=s_c+\sum_{k:\,c\in\operatorname{chain}(k)}r_k.
$$

Each command appears once in every applicable sum. Its initial bound $u_k$ must cover every permitted charged outcome. Admission reserves $u_k$ atomically with the immutable command and requires $U_c+u_k\leq B_c$ for every $c\in\operatorname{chain}(k)$. Exact retries return the original admission. They add no reservation.

Authenticated performance $0\leq d\leq r_k$ moves $d$ from reservation into consumed charge for every $c\in\operatorname{chain}(k)$. This leaves $U_c$ unchanged. A justified release decreases it. Starting from $0\leq U_c\leq B_c$, these cases preserve each limit by induction, assuming complete mediation and one authoritative account. Revocation retains consumed charges and unresolved reservations. Separate physical stores require a common allocation authority or a sound resource partition.

Two delegates can reserve 40 and 60 against a root limit of 100. Two reservations of 100 cannot both pass. A refund does not replenish a lifetime expenditure limit. Replenishment needs an explicit accounting rule and authenticated receipt. Cash availability, expenditure authority, and performance of an outstanding duty remain separate predicates.

## Retain the returned value during suspension

A program can receive an authenticated jurisdiction value and then request evidence whose type depends on that jurisdiction. Resumption must retain the returned jurisdiction with the evidence. Substituting a pending request or a newly selected jurisdiction would change the meaning of the result.

Let $A$ be the response value type and $B(a)$ a pure family of evidence types indexed by $a\in A$. Write $F_\rho A$ for a computation returning an $A$ value with effects within set $\rho$. If $m:F_\rho A$ and $k(a):F_\sigma B(a)$, dependent sequencing returns

$$
\operatorname{dbind}(m,k):F_{\rho\cup\sigma}
\left(\Sigma a:A.\,B(a)\right).
$$

The dependent pair contains the returned value $a$ and corresponding evidence $b:B(a)$. The effect set $\sigma$ bounds every permitted continuation. Execution runs $m$, uses its returned $a$ to run $k(a)$, and returns $(a,b)$. Suspension and refusal retain the observed prefix. A nonconstant result family retains its index, either in this pair or an enclosing dependent context.

A durable continuation must therefore retain the value environment and pending response type alongside control position, program, effects, history, and authority dependencies. Direct restoration must recover that same checked context. Current authority still governs the next effect after an answer arrives.

## Choose from available observations

Consider a delivery requiring 60 currency units after a preliminary purchase. With 100 available, a preliminary cost of 60 creates a funded dead end. A complete route costing 90 can remain admissible. A refund meets the goal only when the governing contract expressly permits that remedy.

Planning must also account for hidden state. An approval response can arrive after the delegate loses execution authority. If the response reports only approval, the program cannot assume that authority remains active.

Use a finite response model. Let $X$ contain all relevant states, $S\subseteq X$ the safe states, and $T\subseteq S$ the permitted terminal outcomes. A **belief** $B$ is the nonempty set of states consistent with the complete observed history. Its initial value must contain every possible starting state.

Let $\mathcal A$ be the finite set of command choices. For $a\in\mathcal A$, the model supplies finite response paths $\mathcal P(x,a)$ from each possible state $x$. Every path contains at least one transition and ends at the next program decision. Intermediate states carry the same rights, resources, and authority conditions as separately admitted acts.

Write $\operatorname{obs}(p)$ for the transcript actually exposed by path $p$. For a possible transcript $z$, update the belief by

$$
U(B,a,z)=\{\operatorname{last}(p):x\in B,
p\in\mathcal P(x,a),\operatorname{obs}(p)=z\}.
$$

An action is uniformly executable when every $x\in B$ has at least one response path. Let $Z(B,a)$ be the possible transcripts. Let $\mathcal W_h$ contain beliefs from which safety and known completion are guaranteed within $h$ decisions. Start with

$$
\mathcal W_0=\{B:\varnothing\ne B\subseteq T\}.
$$

Define $\operatorname{Good}_h(B,a)$ by three conditions: uniform execution, safety at every intermediate state, and $U(B,a,z)\in\mathcal W_h$ for every $z\in Z(B,a)$. Then

$$
\mathcal W_{h+1}=\mathcal W_0\cup
\{B:\varnothing\ne B\subseteq S,
\ \exists a\in\mathcal A\;\operatorname{Good}_h(B,a)\}.
$$

At a terminal belief, the program declares completion. Otherwise it chooses any retained action and decreases the remaining horizon after the response. Induction on the horizon proves the finite guarantee. Every possible observation leads to a shorter guaranteed continuation. Conversely, a policy that guarantees completion must satisfy those conditions before it sees the response.

This construction uses observed transcripts throughout. A guarded attempt can perform with live authority and return refusal with revoked authority. Both outcomes must have safe continuations. The refusal preserves outstanding duties and reservations. Another authorized actor can proceed only through a separately admitted transition.

The guarantee requires a complete finite model, including hidden memory and response obligations. Unknown transcripts require reassessment. Weak fairness alone supplies no finite deadline. A calendar bound additionally requires a duration bound for each complete decision round. Retries retain response counters and the original duty. Enlarging the terminal set after failure changes the contract and requires its own authority.

# Succession, recognition, and continuing authority

An institution can replace an operator, merge offices, or divide competence between lawful successors. Its records must preserve existing rights while assigning future acts. **Competence** means an institution's authority over named matters and acts. Technical control of a deployment and institutional competence need distinct records.

## Derive succession from the existing authority

A succession instrument identifies predecessor and successor offices, transferred competence, effective time, adoption authority, custodian, and the disposition of rights and duties. It binds the complete continuation inventory, prepared transactions, reservations, evidence custody, and future authority sources. Admission checks the instrument against the predecessor's effective authority structure and operative clauses. A proposed configuration cannot grant itself adoption power.

The instrument must allocate each competence explicitly. A lawful split can assign registration to one successor and licensing to another. Both can continue their disjoint acts. A shared decision requires its named joint rule. A single global successor flag would incorrectly suppress this lawful division.

The execution fence must instead enforce one active execution generation for each transferred scope. Shared resources also require a common decision and allocation boundary. A successor with registration competence cannot spend a licensing estate's reservation merely because both received records. Unresolved authority in one scope leaves that scope pending while unrelated authority continues.

## Activate custody without repeating work

The handoff cut identifies the exact admitted source state. Its inventory includes obligations, duty occurrences, portions, command exposure, cash reservations, checked continuations, and unacknowledged deliveries. Preparation changes form retained deltas and must appear in the final cut. Every claimed namespace requires authenticated completeness evidence.

The successor verifies custody and reconstructs existing reservations before conflicting writes. Its actual decoder must restore the checked continuation directly. Activation must bind the cut, predecessor fence, successor generation, and receipt atomically within each authoritative admission boundary. Invalid admission consumes nothing. An exact retry returns the receipt without evaluator execution.

Transfer itself creates no dispatch, discharge, or resource release. Later acts retain their original causal identities and require current action-specific authority. External effect owners must enforce the generation where a stale process could still act. A local fence cannot establish exclusivity over cloned stores or an external provider that ignores it.

Cross-store returned credit remains encumbered while reopening is pending. Reuse requires the authoritative original ledger's committed reopening and every required current admission. A successor's receipt of the return message does not supply that commitment.

## Preserve history and evaluate present reliance

A destination decides which successor acts it recognizes under its own instruments. Conformance listings and copied policy records supply evidence. Recognition requires the destination's authorized decision. An express adoption can permit continued use of a predecessor's statement while preserving its original issuer, signed bytes, scope, and occurrence identity.

Historical verification and present reliance need separate results. Ordinary key retirement can leave an earlier assertion authentic under the retained signing-time evidence. Later compromise evidence can require reassessment of that assertion. The reassessment appends its cutoff, authority evidence, and decision while retaining the earlier admission. Authentic bytes remain available even when current reliance refuses their use.

Every new effect checks authority at the stage required by its instrument. Admission, dispatch, provider acceptance, and durable commitment can occur at different times. An earlier signature and clock sample cannot establish authority at a later required stage.

## Assurance boundary

The named-right calculation, budget induction, and finite planning recurrence give explicit models that implementations can test against. The research manuscripts describe bounded reference constructions for rights, delegated use, observation-based planning, dependent execution, and guarded allocation. Their source descriptions do not establish production conformance.

Acceptance of an implementation requires faithful right projections, complete dependency guards, authoritative resource accounting, authenticated custody, and actual admission and effect evidence. Full language refinement, complete institutional mandates, external freshness, and effective distributed fencing remain separate obligations. Each must be established for the claimed operation and deployment.
