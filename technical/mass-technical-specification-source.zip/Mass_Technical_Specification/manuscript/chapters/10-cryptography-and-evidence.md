# Canonical content and cryptographic commitments

## What a commitment establishes

An organization needs evidence that retains its meaning when another party receives it. Mass therefore distinguishes an authored fact, its encoded representation, and the commitment to that representation. A digest can bind a representation. An authorized signature can attribute a commitment. A verified publication can establish that the commitment existed by a particular time. Each step has different inputs and trust assumptions.

Let $x$ be an accepted typed value, $C_v$ the canonical encoder at version $v$, and $H$ a specified hash function. Its content commitment is

$$d = H(C_v(x)).$$

The verifier needs the value, encoder version, and hash algorithm. It recomputes $d$ and compares the result with a commitment obtained through an authenticated channel. Agreement establishes consistency with that commitment, subject to the hash assumptions. The commitment alone does not identify its issuer or establish that the asserted facts are true.

For example, an identity provider can sign an incorrect date of birth. Signature verification attributes that statement to the provider. Content verification detects a changed date after signing. Correctness of the original date depends on the provider's evidence and the admission policy. An assurance system must preserve these separate conclusions through its API, storage, and user interface.

This distinction also applies to compliance evidence. A signed decision needs the applicable rules, admitted inputs, execution context, and decision procedure. Its digest binds the selected representation. The business conclusion depends on the complete derivation and its authorized interpretation.

## The implemented canonical form

The shared canonical library supplies a private byte wrapper with fallible constructors. Mass imports that library through a pinned dependency. The constructor converts a serializable value into JSON, applies recursive coercions, and emits compact JSON. Objects use the serializer's sorted map representation. Arrays retain their order.

The coercion rejects numbers that the JSON representation does not recognize as signed or unsigned integers. An ordinary decimal fraction therefore fails canonicalization. Financial schemas must select exact representations, such as a documented decimal string or scaled integer. They must also define currency, scale, rounding, and range. A string containing an amount has no arithmetic interpretation until its domain type supplies one.

A string that parses as an RFC 3339 datetime becomes UTC text with whole-second precision and a `Z` suffix. Other strings pass through unchanged. The inspected implementation performs neither general Unicode normalization nor automatic binary-to-base64 conversion. Binary fields use the owning type's serialization rules.

Consider these two input objects:

```json
{"recordedAt":"2026-09-06T15:00:00.250+07:00","amount":"12.30"}
{"amount":"12.30","recordedAt":"2026-09-06T08:00:00.900Z"}
```

Both become the following canonical object under the inspected coercion:

```json
{"amount":"12.30","recordedAt":"2026-09-06T08:00:00Z"}
```

Their fractional seconds differ, but normalization removes that difference. The encoder is therefore not injective over all input JSON values. Its contract must define equivalence after normalization. When subsecond order matters, an application needs an additional sequence or a representation that preserves the required precision.

The same issue affects a free-text field that happens to contain a parseable datetime. The constructor applies its string rule recursively without consulting field semantics. A schema author must account for this behavior before using the digest as the identity of an authored document. Original uploaded bytes need their own byte commitment when exact textual preservation matters.

The implementation describes its format in relation to JSON Canonicalization Scheme. Interoperability must nevertheless use exact executable vectors. The serializer's string ordering, integer range, escaping, and datetime coercion form part of the actual protocol. A general reference to canonical JSON cannot substitute for agreement on these details.

## Domain separation and preimages

A preimage is the exact byte sequence supplied to a cryptographic operation. Different objects can share a JSON shape while having different authority. An approval, a payment instruction, and a revocation must therefore bind their purposes. The normative contract requires a domain identifier and format version whenever a signature or digest crosses an authority boundary.

A schematic signed statement can bind the following tuple:

$$m = \operatorname{Encode}(\text{domain},\text{version},\text{issuer},\text{subject},\text{intent},d,\text{epoch}).$$

This formula describes a required binding, rather than a universal Mass wire encoding. Each concrete protocol must specify field order, lengths, optional fields, and excluded signature fields. Implementers must use that protocol's existing encoder. Replacing it with another plausible encoding changes the message being signed.

Raw hashing remains necessary for binary protocols. A Merkle parent hashes child digest bytes under its specified framing. A file commitment may hash original bytes. Such preimages differ from canonical JSON objects. The governing rule is to identify and reproduce the correct preimage, rather than claim that every hash consumes the same representation.

Algorithm identity belongs in a durable reference. A digest represented as hexadecimal text also needs an agreed case, length, and decoding rule. A typed digest prevents some representation mistakes within one program. It does not prove that an external caller supplied bytes from the intended algorithm or domain. Admission must validate both the type and the provenance.

## Equality, authenticity, and collision assumptions

Determinism and collision resistance are different properties. Determinism means that identical accepted inputs produce identical output bytes and digests. Collision resistance limits an adversary's ability to find distinct byte sequences with equal digests. Preimage resistance limits recovery of an input from a digest. Neither property supplies secrecy for a low-entropy value.

Hashing a short identifier can permit enumeration of all plausible identifiers. A content address can also reveal that two parties possess the same document. Privacy policy must therefore govern commitments as well as plaintext. Salted commitments, keyed constructions, and access controls address different disclosure problems and require distinct wire contracts.

An authenticated digest provides evidence of a particular commitment. An unauthenticated digest delivered beside attacker-controlled content provides only a consistency check. The attacker can replace both. A receiving service must obtain the expected digest from an authorized signature, a trusted transaction context, or an independently verified publication.

Comparison timing also needs a scoped claim. A constant-time comparison helper protects its own byte comparison. It does not establish constant-time parsing, allocation, database lookup, or error handling. Public digests usually do not require secret-dependent ordering. Secret authentication values require analysis of the full comparison path.

## Content-addressed artifacts

Content-addressed storage uses a content digest to locate an artifact. The inspected artifact store combines a validated artifact type with a digest. It writes JSON artifacts to a filesystem layout and recomputes their canonical digest during resolution. A mismatch produces an error.

The artifact type is part of the retrieval context. Its validation restricts characters and length, which also limits path construction. The digest identifies the canonical content under the chosen algorithm. A consumer must still validate the resolved artifact's schema and its suitability for the requested operation.

This implementation supports integrity checks on retrieved artifacts. A general claim that every database value lives in one content-addressed store would exceed its scope. Mass also uses domain database records, graph representations, event records, and binary evidence. Their identities and persistence contracts differ.

A missing artifact is an availability failure. A corrupted artifact is an integrity failure. An authentic artifact signed by an unauthorized issuer is an authority failure. Services should retain these distinctions in their evidence status, because remediation differs. Repeatedly fetching a missing object does not repair an invalid signature.

## Verification obligations

Canonical conformance requires vectors for reordered keys, nested objects, arrays, integer limits, decimal rejection, Unicode strings, and datetime normalization. It also requires rejection tests for unsupported representations. Two language implementations must compare exact bytes before comparing digests. Equal outputs on ordinary ASCII examples provide limited evidence about unusual keys and encodings.

A content verification test should change one committed field and require rejection. A domain-binding test should submit the same payload as another operation type and require rejection. Historical replay must use the original encoder and schema, or a verified conversion with an explicit relationship to the original commitment.

The implementation observations in this chapter come from source inspection. They establish concrete encoding behavior and storage checks. They do not establish universal route coverage, deployed configuration, or successful retrieval of a particular organization's evidence. Those claims require source-identified execution through the relevant API and persistence boundary.

# Signatures, key authority, and cryptographic epochs

## Signatures bind messages to keys

A digital signature allows a verifier to check a message against a public key. The authority associated with that key is a separate system fact. Mass needs both: cryptographic verification and a current, scoped relationship between the key, issuer, organization, and permitted action.

A valid signature under an unrecognized key supplies no organizational authority. A recognized key can also exceed its scope. A document issuer, an operation approver, and a deployment signer have distinct responsibilities. Their admission rules must specify which statements each can authorize.

The normative verification sequence resolves the issuer, selects an authenticated policy, checks the signature, and evaluates the statement's context. The context includes subject, intent, validity interval, replay protection, and any required approval threshold. The resulting authorization must remain attached to the exact statement used at the write boundary.

Key custody influences the threat model. Hardware-backed signing can reduce private-key extraction. It does not prevent a compromised application from requesting signatures that its account may request. Software key encryption protects stored material under its wrapping key. It does not hide unwrapped keys from a compromised process.

## The current hybrid suite

The inspected trust implementation combines Ed25519, ML-DSA-65, and SLH-DSA-SHA2-128f. The post-quantum features are enabled by default in that library. Actual deployed coverage still depends on the build, available keys, selected suite, and caller path. A library default cannot establish that every emitted artifact has every signature component.

Each component signature is called a limb. The versioned envelope identifies a suite and cryptographic epoch. Signing constructs a bound preimage containing a domain separator, suite tag, little-endian epoch, message bytes, and declared post-quantum limb count. Verification reconstructs the same preimage.

This binding prevents a verifier from treating the suite and epoch as unsigned annotations. Changing either field changes the signed preimage. A presentation that exposes an Ed25519 limb separately must also expose the exact bound preimage or a protocol that reconstructs it. Verifying that limb over the raw business payload would check a different message.

The implementation retains legacy support. Raw historical Ed25519 signatures and versioned Ed25519-only envelopes have different verification rules. A service must identify the permitted legacy population. It must not let an attacker select a weaker historical rule for a new operation.

The SLH parameter set matters operationally. The inspected signature constant is 17,088 bytes for SHA2-128f, while the ML-DSA-65 constant is 3,309 bytes. Ed25519 contributes 64 bytes. Envelope framing adds further bytes. The historical description of a SHA2-128s suite and an approximately eleven-kilobyte total therefore does not describe this implementation.

## AND and OR verification policies

Let $V_i(m,\sigma_i,pk_i)$ denote verification of limb $i$. Let $A$ be the authenticated set of required, supported limbs. Two possible policies are

$$V_{\mathrm{AND}} = \bigwedge_{i\in A}V_i,
\qquad
V_{\mathrm{OR}} = \bigvee_{i\in A}V_i.$$

The security difference follows directly from these predicates. Under AND, an attacker must satisfy every required verification. A surviving unforgeable required limb can therefore prevent a forgery. Under OR, a forgery accepted by any eligible limb satisfies the complete predicate.

Suppose an attacker can forge Ed25519 signatures and Ed25519 remains eligible under OR. The attacker signs a new unauthorized message with that limb and supplies invalid alternatives. OR accepts because the Ed25519 verification succeeds. Survival of other algorithms does not prevent this attack. Continued verification of an old legitimate signature is a different property from resistance to new forgeries.

The default trust verifier calls an AND policy. A separate OR verifier remains available. The inspected capability-chain verifier uses the AND policy over its relevant present, non-retired limbs. These call-site facts replace the historical claim that one universal OR policy protects all evidence.

The AND policy verifier checks suite completeness outside the test-only relaxation and rejects an effective empty check set. Feature configuration still matters because post-quantum verification branches are compiled conditionally. A deployment must demonstrate that every algorithm required by its admission policy is actually supported and checked. An envelope's declaration cannot compensate for an absent verifier.

The implementation combines verification outcomes through constant-time boolean operations. Parsing and algorithm branches remain visible parts of the function. This observation supports a narrow statement about result aggregation. It does not establish a complete side-channel theorem for the signature service.

## Retirement and bridging

A cryptographic epoch identifies a period governed by a signature policy. Retirement changes which algorithms a verifier may rely upon. The authority for this change must be authenticated independently of the artifact being checked. An attacker-controlled epoch field must never select its own acceptance rule.

The source contains retirement records, epoch-aware verification, and bridging certificate representations. A bridge connects old and new suites with the relevant epochs and commitments. The preferred certificate path supports signatures from both sides of the transition. A legacy helper also constructs a structural bridge without those dual signatures.

A structural certificate records intended continuity. It supplies no cryptographic evidence that the old and new authorities authorized that continuity. Admission must distinguish a certificate representation from a certificate whose signatures, key bindings, and policy transition have been verified.

For a planned transition, the deployment should retain the old policy, last accepted history commitment, new policy, new key identifiers, and authorized bridge. Historical verifiers need these records to explain why an older artifact remains acceptable. Current verifiers must apply the current retirement constraints where the protocol requires them.

Emergency retirement requires a different analysis. If an old key or algorithm is already compromised, its fresh signature cannot independently authorize recovery. Recovery then depends on previously established alternative authority, a trusted earlier commitment, or an explicit governance action. Calling the transition a bridge does not resolve that dependency.

Retirement should also preserve negative evidence. An artifact rejected because its only eligible algorithm was retired must retain that reason. A retry under a weaker policy would change the security decision. Historical readability and current authority need separate statuses.

## Key lifecycle and custody evidence

A complete key record includes purpose, public material, suite, issuer binding, activation, retirement, and replacement relationships. A deployment also needs a controlled signing interface and a record of who may invoke it. Private material must remain outside artifacts intended for verifiers.

Rotation tests must cover overlap windows and interrupted operations. A signature created before rotation may arrive afterward. The receiving policy must specify whether signing time, receipt time, or an authenticated sequence controls acceptance. An untrusted timestamp inside the message cannot settle that question alone.

Loss and compromise need distinct procedures. Lost keys can prevent new signatures while old signatures remain valid. Compromised keys can enable new unauthorized signatures. Backup restoration solves availability only when the restored material and authorization state remain trustworthy.

Long-term evidence requires preservation of algorithms, verification software, and historical policy. Renewal under a new algorithm can preserve an earlier commitment before its old protection becomes inadequate. Renewal after the old binding has failed requires additional evidence about which historical content was authentic.

## Acceptance evidence for signatures

A signature conformance suite must alter the message, suite, epoch, issuer, and each required limb independently. It must reject unauthorized policy downgrades and empty effective policies. It should also test the explicitly permitted historical forms and reject the same forms on new paths that require stronger suites.

An operational claim requires a real signing request, captured public envelope, independent verification, and durable association with the admitted operation. The record must identify the build features and key policy without disclosing private material. A successful primitive test does not prove that a public route invokes that primitive.

The present source supports hybrid signing and several explicit verification policies. The security argument depends on the selected policy and its authority. This specification makes no universal single-limb-compromise or forward-security claim across all Mass artifacts.

# Authenticated history, persistence, and retrieval

## Ordered commitments

An authenticated log commits to an ordered sequence. Its purpose is to make later changes detectable against a trusted earlier commitment. A Merkle Mountain Range, abbreviated MMR, organizes that sequence as a forest of complete binary trees. Each tree root is a peak.

Appending a leaf adds it at the right edge. Adjacent peaks of equal height merge until their heights differ. A specified peak-combination rule produces a root for the entire prefix. The root is meaningful only with the leaf count and exact hash protocol.

Leaf index and stored position differ. With zero-based indexing, a common MMR position formula is

$$p(i)=2i-\operatorname{popcount}(i).$$

The inspected graph-store implementation uses this formula. Internal hashes occupy intervening positions. A reader that treats a dense leaf index as a stored position can inspect an internal hash instead of the intended observation.

An inclusion proof establishes membership relative to one root. An extension proof establishes a relationship between two prefixes. Neither alone establishes global uniqueness of history. A writer can publish two incompatible roots to separate audiences unless the surrounding protocol detects or prevents equivocation.

## Exact MMR protocols

Mass contains distinct MMR implementations. The receipt-oriented cryptographic implementation uses domain-separated binary hashing:

$$L(d)=H(\texttt{0x00}\parallel d),$$

$$P(l,r)=H(\texttt{0x01}\parallel l\parallel r).$$

Here $d$, $l$, and $r$ are raw digest bytes. The prefixes distinguish leaves from parents. The implementation validates the expected hexadecimal representation before decoding it.

The graph store's memory implementation instead hashes concatenated hexadecimal strings for parent construction. Its persistent implementation hashes raw child bytes. These rules produce different roots for the same apparent digest strings. Consequently, a generic reference to the Mass MMR cannot serve as a wire specification.

The normative export contract must identify which implementation produced the root. It must fix leaf preparation, parent framing, peak order, empty-root behavior, and leaf-count interpretation. A conversion between protocols requires a separate authenticated binding. A reader must never infer compatibility from matching type names.

The inspected memory verifier checks the claimed value against its local stored position and compares the claimed root with its current root. It does not reconstruct a detached proof solely from the supplied siblings. This is a local membership check. A portable proof claim requires a verifier that receives no trusted local log and reconstructs the expected root from the proof.

A record carrying a field named `proof` therefore needs an explicit verification contract. It may contain useful local evidence without supporting independent remote verification. The distinction should remain visible in exported evidence status.

## Durable append and crash boundaries

A write-ahead log, or WAL, records intended changes before their application. The inspected graph writer appends a WAL operation before extending a persistent MMR. The persistent MMR uses fixed-size records and synchronizes writes. On opening, it removes an incomplete trailing record and derives its leaf count from stored structure.

These mechanisms address specific interruption points. They do not establish that every interrupted compound append reconstructs automatically. A crash can occur after the WAL record, after the leaf record, or after an intermediate parent. Recovery must relate these states to one admitted operation.

The inspected writer opens its WAL and MMR and reloads rollback markers. That opening path does not by itself replay every WAL append missing from the MMR. A complete recovery guarantee therefore requires the surrounding reconciliation path and crash tests. The historical statement that the WAL alone always restores the complete store exceeds this observed path.

Mass also distinguishes database-primary and graph-primary modes. In one mode, graph persistence can serve as a secondary projection. In the other, a graph write can precede the database commit. The latter path records a rollback marker if later work fails. Readers must honor such markers even though the authenticated log remains append-only.

This arrangement separates physical inclusion from business visibility. A committed log leaf can document an attempted operation later marked unsuccessful. The event remains useful evidence. It must not appear as a successful business mutation merely because it has an MMR position.

## Database projections and consistency

A projection is a derived view of authoritative events or records. It can support efficient queries without becoming the authority for the underlying business state. Its checkpoint identifies how far it has consumed the source sequence. Lag and divergence are different conditions.

Lag means the projection has not yet reached an admitted source event. Divergence means it represents that event incorrectly or inconsistently. A read contract should say whether it permits lag, requires a particular checkpoint, or falls back to the authoritative view. A successful HTTP response does not establish projection freshness.

The specification requires a reconciliation record when database and graph views disagree. That record should bind the observed source positions, affected subject, expected content, and actual content. Correction must preserve the evidence of divergence. Silently rebuilding a projection without recording the incident loses information relevant to audits.

A database transaction and a filesystem append have different commit mechanisms. Combining them requires ordering, idempotency, compensation, and explicit acknowledgment semantics. Documentation must identify the actual durable acknowledgment. A function return before the required persistence boundary cannot support a claim of completed evidence issuance.

## External anchoring

An external anchor publishes a commitment through another authority or consensus system. A useful anchor receipt binds root, leaf count, target, external reference, and confirmation evidence. The receiving auditor must verify the external reference against that target's protocol.

The inspected graph-store interface names Bitcoin, Ethereum, Certificate Transparency, and RFC 3161 target classes. Its production factory constructs a provider that explicitly returns an unimplemented error for live anchoring. Simulated providers exist behind test or mock configuration. Naming these targets therefore establishes an interface and intended integration, not live publication.

A locally computed binding digest checks consistency among receipt fields. It does not establish that the external system received the root. A timestamp string also supplies no independent time evidence. A real timestamp token needs its signature, authority chain, message imprint, and policy checked.

Multiple targets can improve resilience when their failures differ. Distinct names do not prove statistical independence. Shared operators, credentials, infrastructure, and legal control can create correlated failures. The precise conditional claim is that a retrievable authentic copy survives while at least one relevant target retains it under acceptable verification conditions.

An anchor preserves a root. It does not store every underlying document. Loss of all payload copies leaves the root intact but prevents reconstruction. Likewise, if the hash binding itself fails, publication of that hash does not restore uniqueness of its original preimage. Stronger historical conclusions require preserved content or another trustworthy commitment.

## Retrieval and evidence export

An export intended for independent verification needs the payload or authorized disclosure, schema, commitment protocol, signature policy, and relevant history proof. It also needs an authenticated expected root. When publication is claimed, it must include independently checkable publication evidence.

A retrieval drill should begin with an artifact selected by an auditor. The operator retrieves it through the actual storage tier, recomputes its commitment, and verifies its authorization and history. The drill should include missing objects, corrupted bytes, inaccessible keys, and stale indexes. Each failure must remain distinguishable.

Portable evidence also needs a freshness policy. A valid old root can omit later revocation or supersedence. A consumer deciding a current action must obtain the current evidence required by that action. A consumer reconstructing a historical decision instead needs the policy and state that applied at that time.

These are normative acceptance conditions. Source inspection establishes storage and verification mechanisms, including the limitations above. No live external anchor, independent recovery drill, or deployed storage availability is asserted by this chapter.

# Typed evidence graphs and long-term interpretation

## Graph records and their authority

An evidence graph connects typed records through typed relationships. An organization can connect a person, appointment, approval, document, operation, and resulting receipt. Such relationships support both business queries and reconstruction of why an action was admitted.

The inspected Mass graph implementation stores records in a map keyed by identifiers and relationships in a collection. A record carries a type label, content hash, and JSON payload. Relationship insertion checks that both endpoints exist. Record insertion can replace an existing identifier.

The implementation does not impose general acyclicity. It also accepts a supplied nonempty content hash without recomputing it in that low-level insertion method. When the hash is empty, it hashes serialized payload bytes. These facts constrain the guarantee available from the container alone.

The normative evidence graph requires stronger admission rules where authority depends on graph content. It must check type, expected digest, subject ownership, relationship meaning, and update policy. If a particular relation must be acyclic, its owning domain must enforce that condition. A graph container's generic type label supplies no such theorem.

## The gstore reference boundary

The inspected gstore project and the Mass graph-store component require separate implementation assessments. Mass declares its graph-store component as a local dependency. The inspected project's `TypedGraph` insertion and retrieval methods return `NotImplemented`. Similar names and related designs do not establish executable parity.

This distinction preserves the role of the reference design without attributing unavailable behavior to it. A consumer adopting that package needs the implemented API and its tests. A consumer assessing Mass needs the actual Mass integration and its persistence behavior. Evidence from one cannot silently substitute for the other.

The inspected formal companion contains statements about append behavior, replay, migration lenses, and anchoring. Several append and replay obligations remain admitted. Some anchor statements conclude `True` at their chosen abstraction. Those statements do not establish an executable storage refinement or adversarial durability result.

A formal result must identify its precise proposition and assumptions. A source implementation requires a separate relationship to that model. This chapter retains append preservation and deterministic replay as required properties while distinguishing them from discharged implementation proofs.

## Schema-pinned interpretation

A schema defines the structure and meaning of a record. Historical interpretation requires the schema applicable when the record was admitted. An epoch header can bind a schema identifier, version, digest, leaf count, and history root. A stored observation can retain its original schema version and bytes.

The inspected epoch registry represents these values. It also stores migration-lens records with forward and backward transformation hashes and an optional proof hash. Its lookup for a lens chain selects direct matching endpoints. It does not compute arbitrary multistep transitive composition.

A migration lens describes transformations between representations. If $f:X\rightarrow Y$ and $g:Y\rightarrow X$ claim reversible migration, the required laws include

$$g(f(x))=x\quad\text{for all admitted }x\in X,$$

and, when full bijection is claimed,

$$f(g(y))=y\quad\text{for all admitted }y\in Y.$$

A schema that discards an authored field cannot satisfy the first law without retaining that field elsewhere. A schema that introduces freely chosen new data cannot satisfy the second law over every new record. The migration must define its actual admitted subsets and preserved side information.

Storing a transformation hash and a proof hash records references. It does not execute the transformation or check the proof. A historical replay service must retrieve the pinned interpreter, validate its identity, select the proper schema, and reject missing dependencies. Replaying old bytes with the current schema can silently change their meaning.

## Facts, corrections, and supersedence

Evidence can remain authentic while its interpretation changes. A credential can expire. An appointment can end. A later decision can supersede an earlier one. The record of the earlier statement remains part of history, while current authority follows the applicable later state.

The normative correction model records a new statement that identifies what it changes and who authorized the change. It preserves the original commitment and reason for correction. A query must distinguish historical existence, current validity, and current operative effect.

For example, a director approved an operation while an appointment was active. A later resignation does not alter the signed approval bytes. Whether the approval remains effective depends on the operation's policy and timing. A query that shows only the current director list cannot decide this historical question.

Similarly, a withdrawn provider attestation can remain authentic evidence of what the provider previously asserted. Its use in a new operation may be forbidden. The graph should expose withdrawal as a relationship and state transition, rather than erase the original assertion from every view.

## Verification cores and full witnesses

A verification core retains compact references needed to identify and assess an observation. A full witness retains the data needed to reconstruct its derivation. The inspected archival types distinguish these objects and associate records with hot, pending, deleted-hot, verified-warm, and cold states.

The core representation includes the observation hash, MMR position, proof-term digest, verdict summary, cryptographic epoch, and suite identifier. It does not itself contain every artifact required for independent proof verification. The full witness representation includes proof bytes, graph delta, oracle inputs, optional capability chain, and replay versions.

These representations express an archival contract. They do not implement a storage lifecycle merely by existing. A successful transition to cold storage requires a verified durable copy, retrieval metadata, key availability, and retention policy. Deleting the hot copy before those conditions hold creates an availability risk.

The old approximation of a fixed-size core is unsuitable as a general capacity bound. The representation includes variable-length fields and a collection of verdict summaries. Even fixed-size cores require storage proportional to observation count. Compaction can reduce the coefficient or move costs between tiers. Retaining one core per observation remains linear in the number retained.

Deterministic replay also requires preserved external inputs. A current sanctions response, market price, or provider document cannot substitute for the response used originally. The replay record must bind exact inputs and their admissibility evidence. Calling a computation deterministic cannot recreate information that was never retained.

## Retention acceptance conditions

A long-term retention claim needs an inventory of retained objects and their dependencies. It must distinguish content integrity, interpretability, authorized access, and retrieval time. Encryption keys and schema interpreters can become unavailable while the ciphertext remains intact.

A useful acceptance drill reconstructs an old observation after a schema transition and a key rotation. It retrieves the original inputs, verifies their commitments, applies the correct interpreter, and compares the resulting decision. It also confirms the corresponding historical authorization state.

The storage protocol should record failed retrieval attempts and unresolved dependencies. A status named `Complete` must correspond to retrieved and verified evidence. An enum variant or a successful metadata update cannot establish that the witness is available. The current implementation observations support explicit representations and selected local operations, with broader archival execution remaining unverified here.

# Attestations, aggregation, and privacy

## What an attestation says

An attestation is an attributable statement about a subject. Its useful content includes issuer, subject, claim, scope, time, evidence references, and signature. Admission also needs a policy that recognizes the issuer for that claim. A watcher, identity provider, regulator, and company officer each speak within different authority.

Multiple attestations can concern the same fact without adding independent evidence. Several services can repeat one upstream response. Their signatures prove several issuers endorsed it, but their factual dependencies remain correlated. Quorum policy must account for eligible identities and evidence dependence.

An attestation should bind the exact statement that a receiving operation needs. Signing a broad status label can leave the applicable organization, jurisdiction, or observation time ambiguous. A statement used for settlement must identify the relevant intent and state version. A statement used for historical review needs its original validity context.

## BLS aggregation and quorum

BLS aggregation combines signatures over an agreed message into a compact group element. A verifier checks the aggregate against the participating public keys. The inspected aggregation implementation uses a BLS12-381 backend when its optional feature is enabled. Its compressed public keys and signatures have different fixed sizes.

The implementation also contains a structural fallback when that feature is absent. Structural signer-count validation is not cryptographic verification. Any admission path relying on aggregate authenticity must require the real backend and demonstrate that it ran.

Rogue-key attacks arise when an attacker chooses a public key algebraically related to honest keys. Proof of possession requires each participant to demonstrate knowledge of the corresponding secret key. The inspected PoP aggregator uses a separate domain tag for possession proofs and verifies them before aggregation.

Proof of possession establishes key control. It does not establish a director's appointment, shareholder voting weight, or independent identity. Quorum evaluation must resolve those facts separately. It must reject duplicate identities and enforce the threshold selected by the governing policy, rather than accept a threshold supplied solely by the submitter.

The aggregate message must bind the exact artifact digest and voting context. If every signer endorses one common message, fast aggregation can reduce repeated signature work. The complete verification still includes participant processing, authority checks, and any possession proofs not already authenticated. A claim of constant total cost independent of participant count would omit this work.

Aggregation also changes what evidence must be retained. An auditor needs the signer set, applicable policy, public keys, and key-authority bindings. A compact signature without the signer inventory cannot establish who formed the quorum. An aggregation API alone does not establish use on every watcher or corridor path.

## Zero-knowledge statements

A zero-knowledge proof concerns a defined relation $R(x,w)$ between public input $x$ and private witness $w$. Soundness means an accepted proof supports the existence of a suitable witness, under the proof system's assumptions. Zero knowledge limits what the proof reveals about that witness beyond the public statement.

The public statement determines the business claim. A proof of knowledge of arbitrary bytes does not establish that those bytes encode a valid license. A license claim needs constraints for issuer authenticity, subject binding, validity, and relevant authority. Those constraints must exist in the relation actually checked.

The inspected proof library offers a deterministic mock and a feature-gated Halo2 backend using an inner-product argument. The old description of an available Groth16 production backend is retired: the current library removed that backend. Its policy object rejects mock proofs in production mode, while environment selection can override the compile-time default mode.

The inspected generic Halo2 circuit constrains a sum-of-squares relation over witness elements. A real cryptographic proof of that relation does not automatically prove every named compliance, identity, migration, or settlement predicate. The business circuit needs its own verified constraint coverage and input binding.

Transparent parameters avoid secret setup material for the selected commitment scheme. They do not remove the need to identify the correct circuit and verification parameters. An attacker must not supply an unrelated easy statement and have its valid proof accepted as the required business statement.

Recursive folding combines evidence of multiple computation steps under a specified recursive relation. Its security depends on that relation, transcript binding, and the supported backend. The presence of folding interfaces and mock implementations provides no blanket proof that long operation histories have production recursive proofs.

## Nullifiers and repeat-use prevention

A nullifier is a deterministic public marker for one protected use of a record or entitlement. The protocol binds it to the private witness and the relevant use domain. A verifier can reject a repeated marker while the proof limits disclosure of the underlying identity.

Determinism alone does not prevent concurrent reuse. Two requests can both observe an absent marker before either records it. The normative admission contract requires an atomic check-and-insert at the authoritative persistence boundary. The business effect and marker consumption must also share the required transaction or recovery protocol.

The proof must prevent a caller from selecting another witness that produces a fresh marker for the same entitlement. It must bind ownership, entitlement identity, and use domain. A marker for one ballot or operation should not become an unintended stable identifier across unrelated activities. Domain separation and the precise witness relation govern that property.

An append-only marker set establishes at-most-once admission only under these binding and atomicity assumptions. Exactly-once completion additionally requires successful execution and recovery. A recorded marker followed by a failed effect can otherwise prevent a legitimate retry. The protocol must distinguish duplicate submission, incomplete execution, and final consumption.

These are protocol obligations for private repeat-use prevention. They do not assert that every Mass transaction uses a nullifier or that one generic proof backend implements the required relation.

## Privacy at rest

Field encryption protects selected data while stored outside authorized decryption contexts. The inspected encryptor uses AES-256-GCM with a fresh data-encryption key and nonce for each encryption. A provider wraps the data key. The stored envelope retains the version, nonce, ciphertext, authentication tag, and wrapped key material needed for decryption.

Authenticated encryption detects tampering with protected ciphertext under its key. It does not establish that the decrypted value belongs to the requested database row. The inspected field-encryption calls do not supply row-specific additional authenticated data. An application must therefore establish record binding through its owning storage and authorization contract.

Encryption coverage is a call-site property. A reusable encryptor does not establish that every personal field, replica, backup, search index, or log is encrypted. A deployment needs a field inventory and verification of actual stored representations. Key-provider selection and access control also require direct evidence.

Authorized applications necessarily encounter plaintext during some operations. The threat model must include process memory, error messages, exported documents, and telemetry. Encryption at rest does not prevent disclosure by a caller already authorized to decrypt. Purpose restrictions and least-privilege access govern that boundary.

## Differential privacy for aggregate queries

Differential privacy limits how much an aggregate release changes when one protected contribution changes. It requires a precise neighboring-data relation. For neighboring datasets $D$ and $D'$ and output set $S$, the required bound is

$$\Pr[M(D)\in S]\leq e^\varepsilon\Pr[M(D')\in S]+\delta.$$

The parameters $\varepsilon$ and $\delta$ have meaning only with the mechanism, adjacency definition, and release policy. Graph adjacency is especially important. Removing one relationship differs from removing one person and all their relationships. The sensitivity bound must match the protected contribution.

The inspected graph privacy library includes geometric and discrete-Gaussian noise mechanisms, accounting bands, and a privacy ledger. The ledger charges band upper bounds and maintains accounts keyed by entity and querier. It also provides a separate budget for noisy disclosure of the budget counter.

These are concrete accounting mechanisms. A system-level privacy claim requires proof that every relevant release passes through them. Concurrent requests, retries, alternate endpoints, and colluding queriers can affect composition. A fresh account for each caller is insufficient when the threat model permits one adversary to control several callers.

Parameter admission needs explicit bounds and rejection of invalid numerical inputs. The inspected generic mechanism treats nonpositive sensitivity as requiring no noise and supplies a default delta in one branch. A caller must establish a valid sensitivity and parameter regime before using its output as evidence of differential privacy.

Post-processing an already private output can preserve its privacy guarantee. Publishing extra raw counts, exact budget usage, or identifying metadata alongside it changes the released information. The complete response, logs, and error behavior belong in the privacy analysis.

## Combining privacy mechanisms

Encryption, zero knowledge, and differential privacy protect different observations. Encryption controls access to stored plaintext. Zero knowledge limits disclosure by a proof of a specified relation. Differential privacy bounds information from a randomized aggregate release.

Their composition requires analysis of their shared inputs and outputs. A public document digest can reveal equality even when its payload is encrypted. Repeated proofs can disclose stable identifiers. A private aggregate can become identifying when combined with an exact small-population count. A general compatibility theorem cannot follow merely from using all three mechanisms.

Acceptance evidence must therefore name the protected information, adversary, public outputs, and exact guarantee. It should include invalid-proof rejection, ciphertext tampering, unauthorized decryption attempts, budget exhaustion, concurrent releases, and metadata review. Current source establishes individual mechanisms and important limitations. Broad deployed privacy guarantees remain unverified in this specification.

# Security boundaries and an explicit assurance case

## Assets and adversaries

Mass protects authored intent, organizational authority, regulated state, personal information, cryptographic keys, and the evidence explaining admitted changes. Security review must identify which of these assets each mechanism protects. One control can preserve auditability while an attack still causes availability loss.

The baseline adversary can submit arbitrary requests, replay observed messages, control a tenant, and operate a malicious external endpoint. Separate scenarios grant compromise of a provider, application account, signing key, database credential, build environment, or host. Combining these powers changes which assumptions remain available.

A hostile provider can supply false facts with valid signatures. A hostile tenant can attempt to act on another organization's objects. A stolen signing key can authorize cryptographically valid messages within any policy that still trusts it. A privileged host attacker can alter process behavior and read available plaintext.

The assurance case must state which powers it excludes and why. It cannot assume that an operator workstation is compromised while also assuming its accessible credentials remain secret. It must identify the technical or organizational control that separates those conditions.

## Admission and the write boundary

Authentication identifies the caller under an accepted credential. Authorization decides whether that caller may perform the requested action on the specified subject. Business admission determines whether the action satisfies the operation's current constraints. These decisions must converge on the same intent before persistence.

The inspected authorization guard checks roles, entity scope, operation scope, and capability caveats. Write checks delegate into write authorization. A denied or failed predicate rejects the request. This provides concrete enforcement points, while route coverage remains an integration property that requires separate verification.

The normative write boundary must preserve exact subject binding. A valid approval for one organization cannot authorize another organization's mutation. A valid approval for one document version cannot silently authorize changed content. The admitted preimage and persisted effect must share causal identifiers and content commitments.

Sanctions rejection is terminal under Mass's admission contract. Evidence integrity preserves the decision and its inputs. It does not guarantee that upstream screening data is complete or correct. The assurance argument also needs the actual screening source, freshness rule, matching behavior, and failure policy.

An autonomous agent has the authority delegated to its credential. Its confidence, reasoning, or ability to draft a document cannot increase that authority. Tool output and retrieved text remain data. They cannot replace authenticated user intent or governing policy.

## Network and resource boundaries

An outbound request can become a server-side request forgery when attacker-controlled destinations reach internal services. The inspected webhook guard resolves candidate hosts and rejects forbidden address ranges. The allowed schemes include HTTP and HTTPS. Transport confidentiality therefore remains a separate deployment requirement.

Validation and connection must agree on the destination. DNS rebinding, redirects, proxy behavior, and later delivery retries require checks at the actual connection boundary. A successful URL validation test does not establish that every outbound client uses the validated address or disables unsafe redirects.

Inbound resource controls limit admitted work. The inspected scale guard uses backpressure and connection slots, with typed rejection responses. Its behavior depends on the configured scale state being present. The implementation passes through when that state is absent and exempts its health-probe path.

Resource safety therefore requires configuration and routing evidence. A per-request bound also needs limits on body size, execution time, recursion, query fan-out, and returned data. Per-instance limits do not automatically establish a global bound across replicas. Availability claims need measured behavior under the defined load and failure model.

## Logs, secrets, and operational evidence

The inspected logging formatter redacts values for a defined set of personal-data field names. That control improves structured logging when installed. It does not recognize every personal value embedded in free text, nested debug output, or an unfamiliar field name.

Logging policy should prefer stable causal identifiers and explicit non-sensitive fields. The operator must verify the rendered logs from real failure paths. Testing only a formatter in isolation cannot establish that every subscriber, exporter, and application log uses it.

Secret handling requires an inventory of key purposes and loading paths. Credentials in process memory inherit the host's security. Credentials in hardware-backed providers inherit provider access policies and invocation controls. Deployment evidence must identify the configured backend instead of infer custody from an available adapter.

Security monitoring should preserve attempted actions, denied authority, malformed evidence, and failed persistence acknowledgments. A useful alert names the affected subject and causal sequence without exposing protected content. Monitoring records must themselves have access and retention controls.

## Integrity, availability, and recovery

Append-only evidence can detect a changed history against a trusted earlier root. Detection requires access to that earlier root and a verifier that checks the relevant relationship. An attacker who replaces both local data and its only local commitment can evade a purely local comparison.

Backups preserve recoverability only when restoration works. An encrypted backup without its keys is unavailable. A database backup without associated artifact bytes may restore business rows while losing their evidence. An old backup can also omit revocations and permit replay unless recovery restores the corresponding authority state.

A recovery acceptance test must select an actual acknowledged operation and recover its business state, evidence, and current visibility. It must cover the interruption points between storage systems. Compensated attempts should remain visible as attempts, with their resulting business effect accurately marked.

Cross-deployment isolation requires separate authority and write credentials, plus validation of incoming evidence. A malicious counterparty can withhold cooperation or send false statements. Bilateral signatures establish agreement by keys, while local policy decides whether the receiving deployment may rely on that agreement.

## Proof status and release claims

An assurance case connects a claim to assumptions and evidence. Source inspection can establish that a branch checks a condition. A unit test can falsify an incorrect implementation of that branch. A formal proof can establish a proposition in a model. Runtime evidence can establish what an identified system did in a particular execution.

These forms of evidence support each other without becoming interchangeable. A proved list-append property does not establish filesystem crash recovery. A real signature does not establish authorized business effect. A deployment health response does not establish that its proof backend or external anchor is live.

The historical manuscript asserted general single-limb security, universal portable history proofs, completed external anchoring, and broad privacy compatibility. The stronger defensible account states the exact mechanisms, their current implementation boundaries, and the additional evidence each operational claim needs. The underlying architectural requirements remain explicit.

For a concrete release, the assurance record should bind one integrated build, configuration, principal, organization, intent, and persistence sequence. It should retain the first discriminating failure for every claimed boundary. Tests must include unauthorized and malformed cases, because acceptance-only examples leave the central security claim unexamined.

This chapter describes a source-grounded security design and its verification requirements. It does not claim an external security certification, a complete deployed audit, or proof that all residual obligations are discharged. Those conclusions require their own current evidence against the complete claimed scope.
