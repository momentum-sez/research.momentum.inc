# Client contracts and interface discovery {#client-contracts}

A Mass integration must preserve the distinction between submitting work, observing its progress, and verifying its result. An HTTP success establishes only the meaning assigned to that response by its contract. It does not establish that a filing reached a registry, a recipient signed, or a payment settled. Clients must carry those distinctions into application state and user messages.

The interface has three related surfaces. The Mass facade exposes programs, authority, verdicts, proofs, observations, and corridor messages. Resource routes expose particular business records and operation controls. The Model Context Protocol (MCP) exposes selected actions to agent clients. Each surface remains subject to the same authorization and mutation boundaries.

The descriptions below identify contracts present in the examined implementation. They do not certify a particular deployment. A deployment claim requires its running contract, authenticated execution, and the durable effects required by the selected journey.

## The Mass facade

The TypeScript package `@mass/primitives` exports `Mass` as its principal facade. The facade uses five central wire objects: `MassProgram`, `MassBiscuit`, `UniversalVerdict`, `MassProof`, and `CorridorMessage`. Their semantics belong to the execution and authority contracts elsewhere in this specification. The table describes the intended method contracts; the implementation qualifications below identify current transport incompatibilities.

| Method | Contract | Client obligation |
|---|---|---|
| `compile(source, biscuit?)` | Accept a supported source and obtain a `MassProgram` | Inspect unsupported-source residuals and retain authored input |
| `mintBiscuit(authority, scope)` | Request a capability with specified authority and scope | Supply the actual subject, caveats, and lifetime |
| `attenuate(biscuit, caveats)` | Narrow an existing capability locally | Current SDK helper cannot attenuate server-minted tokens; see below |
| `propose(biscuit, program)` | Submit a program and obtain a typed proof response | Inspect the proof, verdict reference, and unfinished obligations |
| `proofFor(verdictId)` | Resolve a proof associated with a verdict | Distinguish absence from transport or authorization failure |
| `verify(proof, profile?)` | Verify a proof under a selected profile | Evaluate the returned verdict and the proof's admissibility fields |
| `send(biscuit, message)` | Submit a corridor message | Preserve the message identity and peer acknowledgement requirements |
| `observe(biscuit, query)` | Request an observation through the authorized surface | Preserve query scope and interpret residuals |
| `stream(id, options?)` | Consume an event stream for a verdict or operation identifier | Persist returned event identifiers and reconcile durable state |

`compile` accepts an already formed `MassProgram` without submitting it. For other supported source forms, it calls the compilation route. A successful local shape check cannot establish that the resulting program will execute successfully. The program can still require authority, current evidence, a supported adapter, or an external acknowledgement.

`propose` sends a `POST` request to `/v1/programs/submit` using Biscuit authorization. Its request includes an idempotency key, a client intent identifier, and the write-contract header. The request body uses the contract's `massProgram` envelope. Integrators must use the schema of the selected endpoint rather than apply a global field-renaming rule.

The facade validates the returned proof shape. It rejects a response without a structurally valid, nonnull verdict reference. It does not resolve that reference during this check. A typed proof still requires interpretation and, where required, separate resolution. The proof's `admissible`, `non_admissible_reasons`, and residual fields carry information that a client must not replace with its own success flag.

`proofFor` returns `null` for an HTTP 404. Other failures remain errors. This distinction matters when a client recovers after a lost response. An absent lookup result does not authorize the client to invent a proof or mark the original intent complete.

`send` currently accepts the `corridor.propose_receipt` message kind. Other message kinds fail with an explicit residual. `observe` similarly checks its supported query kinds. Clients must discover the accepted shapes instead of treating these methods as unrestricted dispatch interfaces.

`stream` uses the configured bearer token and the operation stream route. Its compatibility events preserve raw event data and residuals. A locally assigned sequence for a frame without a durable identifier must not become a reconnect cursor.

The intended `verify` result is a `UniversalVerdict`. The server verification request accepts a trust root and proof-admissibility profile; its explicit profile enforcement covers `admissible_full`. This is distinct from a stream's disclosure profile. A shape-only or partial artifact cannot satisfy an acceptance condition that requires full admissibility.

Three current wire gaps prevent treating these methods as verified integration paths. First, the local attenuation helper decodes base64-encoded JSON, while the mint endpoint emits CBOR. Its legacy appended block also contains an unsigned placeholder rather than the signed block required by native chain verification. Second, `verify` sends `massProof`, while the server requires `mass_proof`. Third, the facade's verdict guard requires `admissibilityClass`, while the server emits `admissibility_class`; the observation endpoint returns that verdict structure directly. These paths have no intervening field conversion that resolves the differences. Client and server contracts must be reconciled and executed together before these methods support an interoperability claim.

## Resource clients and compatibility

The package also exports `UnsafeMassRawClient` and explicitly named `Unsafe*` resource clients. These expose existing routes for entities, ownership, fiscal work, identity, operations, governance, and other surfaces. Their names identify a compatibility boundary. They do not confer permission to bypass authorization or finalization.

A resource method may provide the appropriate interface for a mounted read or a specific lifecycle action. Its presence in the package does not establish that every related route exists. Integrators must verify the method's route against the running OpenAPI document. They must also inspect its response contract before treating the method as a proof-producing primitive.

The older `MassClient` class provides a narrower resource composition. It is not interchangeable with every example that uses a variable named `mass`. An integration must identify the imported class explicitly. This prevents examples from combining methods belonging to different client classes.

Go and Python client surfaces also exist. Their generated types and wrappers require separate compatibility checks. A TypeScript method does not establish equivalent coverage in either language. Package compilation establishes type consistency for that package, while a source-bound API call establishes behavior for a particular method.

## The route inventory

The running `/openapi.json` export is the canonical API contract for the selected deployment. Its operation identifiers, methods, paths, schemas, and security requirements form the basis of a client inventory. A source export supports preparation and contract comparison. It does not prove which binary serves a remote address.

Maintain route inventories as generated artifacts. Each entry should contain the HTTP method, path, operation identifier, security declaration, request schema, and response schemas. Record the export digest and the identity of the process that produced it. Preserve the complete document alongside any compact table.

A count of path objects differs from a count of HTTP operations. A path can carry several methods. Tags describe grouping and can overlap. Therefore, a route inventory must define its counting rule before publishing totals. This specification gives no fixed route total that can drift independently of its source.

The following table identifies representative source-mounted routes. It is a navigation aid, not the complete deployment inventory. Braces denote path parameters in the public contract.

| Method and path | Use | Required interpretation |
|---|---|---|
| `GET /openapi.json` | Retrieve the API description | Bind the export to the serving deployment |
| `POST /v1/programs/compile` | Compile a supported source | Compilation does not acknowledge external effects |
| `POST /v1/programs/submit` | Submit a program | Inspect the returned proof and verdict reference |
| `GET /v1/proofs/mass/{verdict_ref}` | Resolve a verdict's proof | Absence and access failure differ |
| `POST /v1/proofs/mass/verify` | Verify a Mass proof | Apply the requested verification profile |
| `GET /v1/operations/types` | Discover operation types | Registration does not prove executability |
| `POST /v1/operations/plan` | Request an operation plan | A plan is not completion |
| `GET /v1/operations/{id}` | Read operation state | Inspect step state and pending actions |
| `POST /v1/operations/{id}/advance` | Advance an eligible step | Authority and current state still apply |
| `POST /v1/operations/{id}/events` | Deliver an operation event | Event admission does not replace provider verification |
| `POST /v1/operations/{id}/cancel` | Request cancellation | Inspect compensation and terminal state |
| `GET /v1/operations/{id}/stream` | Receive progress events | Reconnect from returned event identifiers |
| `GET /v1/operations/{id}/proof` | Retrieve operation evidence | Inspect the proof's scope and residuals |

Generated inventories must compare mounted routes with documented routes. A handler annotation can exist without a matching mounted path. Conversely, a mounted path can lack a complete schema. The comparison must also detect duplicate method/path pairs, dangling schema references, and undocumented authentication requirements.

## Contract evolution

Compatibility includes more than JSON shape. A change can alter required authority, accepted jurisdiction, idempotency scope, timeout behavior, or terminal-status meaning. These changes require review even when a schema generator reports no difference.

Clients should tolerate additional optional fields where their schema permits them. They must fail explicitly on missing required evidence. They should preserve unknown residual details for diagnosis rather than discard them during conversion. A new enum member requires deliberate handling when exhaustive behavior affects financial or legal outcomes.

The `/v1/` prefix identifies the current route namespace. It does not establish a universal deprecation window or guarantee that another namespace runs concurrently. Each breaking change requires a published compatibility decision and evidence for the affected client journeys.

# Developer integration, callbacks, and replay {#developer-integration}

## Preserve one authored intent

An authored intent is the user's requested business action. A transport attempt is one effort to deliver that action. Several transport attempts can belong to one intent. The application must preserve this relationship across retries, refreshes, and resumptions.

The generic TypeScript HTTP client generates an idempotency key before its retry loop for a mutation. It reuses that key for retries within the call. It also sends `X-Client-Intent-Id`. A new method invocation can generate a new key. Therefore, repeating a method call after a browser restart is not automatically the same replay.

The `Mass.propose` implementation has its own request path. It creates request identifiers and applies a timeout, but it does not inherit every generic transport retry behavior. Integrators must inspect the actual method they use. A package-level statement such as “the SDK retries writes” is too broad.

Before submission, preserve the authored parameters, subject identity, jurisdiction, and any explicit intent identifier. After submission, preserve the returned operation and verdict references. If a response is lost, resolve durable state using the supported lookup contract. Submit a replacement only after determining whether the original intent committed.

Do not reuse an idempotency key for different authored content. Do not change an entity identifier during a retry. A retry with changed authority also requires review. The server must reject conflicts instead of accepting whichever payload reaches it last.

## Authentication and transport failures

Use the credential class required by the route. Bearer authentication and Biscuit authentication have different meanings. A process environment that contains both credentials does not establish which authority should act. The MCP stdio entry point explicitly rejects ambiguous caller authority.

The client must distinguish authorization failures from transient transport failures. Retrying a denied request without changing its authority cannot repair the denial. Sanctions rejection is terminal for the rejected action. A network timeout has a different meaning because the server may have committed before the response disappeared.

The generic HTTP client handles rate-limit responses separately and recognizes numeric `Retry-After` delays. Its implementation uses bounded retries and backoff. Applications should preserve the server response and request identifier when retries stop. They must not translate every failure into “try again later.”

Error handling should retain the HTTP status, typed error code, residual marker, and next action when provided. A missing producer, absent adapter, malformed input, and unavailable network require different recovery. User interfaces can explain those differences without exposing credentials or internal diagnostics.

## Long-running work

Operation state includes steps that can become ready, execute, wait for outside action, fail, or enter compensation. A client should show the current actionable state. A fixed spinner cannot represent a signature required from another person or a filing awaiting an authority response.

The operation client provides waiting and ready-step helpers. Their results distinguish terminal state, a waiting step, a ready step, and timeout. They also expose pending actions and possible next actions. A waiting helper's timeout ends the client's wait. It does not cancel the underlying operation.

A client should retain signing and submission identifiers returned for the exact operation step. It must not borrow a signing link from another operation with the same entity. A recipient's identity, the intended document, and the signing session must remain joined throughout the workflow.

Ready-step advancement also requires bounds. An application must stop when further progress requires new authored input, changed authority, or external action. It must not infer a missing signature from a notification delivery or infer consent from a viewed page.

## Durable event streams

The operation stream uses Server-Sent Events (SSE). Its source reads persisted operation events and then follows committed events after the replay boundary. Database notifications wake the reader. Periodic reads provide a fallback when a notification is missed or the listener is unavailable.

The reconnect contract uses `Last-Event-ID`. Clients must echo the last event identifier received from the server. They must not synthesize identifiers from an operation identifier or a local counter. The current handler treats an absent or invalid nonnegative numeric cursor as a fresh subscription.

The replay reader pages through the durable interval. A per-query page bound does not mean that only one page of history exists. A detected gap produces an error. The implementation also supplies current persisted state for applicable records without historical outbox frames.

A robust consumer performs three actions. It applies each event idempotently to its local projection. It persists its cursor after successful application. It reconciles its projection with the operation read endpoint after reconnect or a suspected gap. A browser event is evidence of receipt by that browser, not an acknowledgement from an external provider.

Stream disclosure has an authorization boundary. Redacted output is the default, while full disclosure requires the corresponding authority. A client must not treat a disclosure query parameter as permission. Logs, screenshots, and analytics should receive only the fields needed for their task.

## Outbound webhooks

Webhook delivery has its own durable lifecycle. The sender maintains delivery attempts and outcomes for subscribers. A successfully queued event does not establish receipt by the subscriber. An HTTP acknowledgement from the subscriber does not establish completion of the subscriber's downstream work.

The webhook sender redacts its payload before signing. The signature therefore covers the bytes transmitted. The current signing format binds a timestamp, event identity, and payload digest. Supported signing modes include HMAC-SHA256 and Ed25519. Receivers must implement the selected subscription's actual signing contract.

A receiver should verify the signature over the raw received bytes. It should check the timestamp against its accepted replay interval. It must record the event identifier durably before acknowledging an action whose duplicate execution would be harmful. Parsed JSON reserialization can change bytes and invalidate a correct signature.

Separate transport deduplication from business deduplication. The same business outcome can arrive through different provider events. Conversely, one provider event can affect several internal records. Use the provider's stable event identity and the exact operation subject to determine the permitted effects.

Delivery retries are bounded. A permanently failed delivery requires an explicit operational response. Replaying that delivery must preserve its identity and audit trail. Recreating the business operation solely to resend a notification can duplicate the underlying action.

## Agent integration through MCP

MCP exposes discoverable tools with typed arguments. Tool discovery establishes the registered tool schema. It does not establish that a tool can execute against a selected zone, actor, and dependency configuration. Registration labels must remain separate from runtime acceptance results.

The stdio server takes an explicit API origin and caller authority. Its implementation supports Firebase authority or a Biscuit token, subject to its binding checks. Tool modules share a registration path across transports. Each transport still requires independent verification of authentication, request forwarding, and error propagation.

MCP clients must preserve residuals returned by tools. They must not convert an unsupported operation into an unqualified success message. A tool that returns a signing link has prepared a signing action. It has not supplied the signer's approval.

File upload and download tools require particular care. Local staging roots restrict accessible files, while API authorization restricts product records. Neither boundary replaces the other. A local file path is not a document authorization, and an authorized document identifier does not authorize arbitrary filesystem access.

For acceptance, record the actual tool invocation, request arguments after secret redaction, authenticated actor, API operation, and resulting durable state. The tool name alone cannot join those observations. Use the returned operation and causal identifiers to demonstrate that the tool caused the claimed action.

# Sovereign boot and dependency composition {#sovereign-boot}

## The deployment unit

Mass runs its API and native primitive services in a Rust process. PostgreSQL stores durable state. Identity, entities, governance, investment, and payment responsibilities belong to native services. External Java compute remains limited to treasury and templating. The eProspera integration is a separate provider boundary.

A deployment manifest must identify these dependencies explicitly. It must not revive retired service names from a generic infrastructure template. A network address for an obsolete primitive does not create a supported egress path. The runtime's closed egress registry determines which services can be reached.

The executable is only one part of the deployment. A functioning zone also needs its database schema, jurisdiction configuration, admitted content, trust material, object storage, and required provider connections. An image that starts in a container is not sufficient evidence for a sovereign service.

The operator should maintain a dependency graph with typed edges. Each edge identifies the caller, service, credential class, data class, timeout, and acknowledgement semantics. Separate mandatory boot dependencies from dependencies needed only by a particular journey. Also identify background processes that can act on the same database.

## Boot sequence and rejection points

The examined entry point verifies the release attestation before it initializes external dependencies. It then initializes PostgreSQL and aggregates the native services' schema migrations. It constructs the permitted egress registry and checks external compute connectivity. It loads zone state, composes document storage, and wires services before starting daemons.

A missing or invalid database connection prevents normal boot. There is no database-free runtime mode. A compiler or unit test can operate without a database because it exercises a different boundary. That fact must not be presented as evidence that the deployed service can do the same.

Both external compute URLs are mandatory configuration. Their absence or invalid format prevents boot. Reachability has different behavior: the entry point records unavailable services and can continue toward readiness evaluation. Operators must distinguish a configuration rejection from a service that becomes unreachable after configuration succeeds.

Zone bootstrap resolves an explicit zone configuration or a selected jurisdiction. It loads content and validates dispatch contracts against the API route set supplied by the composition root. Operation compilation normally enforces valid executable content. A warning mode exists for controlled migration work, but it does not satisfy normal release acceptance.

Document storage composition requires `S3_URI` and `S3_AWS_REGION`. The storage client must also obtain the appropriate credentials through the deployment's credential mechanism. Successful configuration parsing does not prove bucket access. Acceptance must perform an authorized document write and retrieval when that journey requires document storage.

Services must be fully wired before daemons receive shared state. Otherwise, request handlers and background advancement could use different service compositions. The entry point explicitly composes the router and wired state before it spawns background tasks. A deployment test must exercise both request and daemon paths when the required outcome spans them.

## Configuration reference

The following configuration names are present in the examined source. They are a focused reference, not an exhaustive secret inventory. Operators must obtain the complete configuration schema and release requirements for their distribution.

| Configuration | Purpose | Operator requirement |
|--------------------------------------------|-------------------------|-------------------------------|
| `DATABASE_URL` | Primary PostgreSQL connection | Supply a valid authorized database target |
| `DATABASE_READ_URL` | Read connection in an unused multi-pool helper | Current executable startup does not wire this setting |
| `DB_POOL_MAX`, `DB_POOL_MIN` | Main connection pool bounds | Budget connections across every process |
| `DB_ACQUIRE_TIMEOUT_SECS` | Pool acquisition wait | Align failure handling with request budgets |
| `PORT`, `MEZ_BIND_ADDR` | Listener port and address | Bind only the intended network interface |
| `MAX_TCP_CONNECTIONS` | Concurrent TCP admission bound | Size against memory, proxy behavior, and streams |
| `TCP_REQUEST_HEADER_TIMEOUT_SECS` | Request-header deadline | Match the trusted ingress and supported clients |
| `MEZ_JURISDICTION`, `ZONE_CONFIG` | Zone selection | Verify the resolved jurisdiction and content |
| `MASS_TREASURY_INFO_URL` | Treasury compute address | Supply an explicit valid endpoint |
| `MASS_TEMPLATING_URL` | Templating compute address | Supply an explicit valid endpoint |
| `S3_URI`, `S3_AWS_REGION` | Document storage destination | Verify region, bucket access, and residency |
| `MEZ_DEPLOY_ENV` | Deployment classification | Use the intended production classification |
| `MEZ_CRASH_DOMAIN` | Daemon selection group | Verify the actual process behavior and assigned work |
| `MEZ_LEADER_TTL_SECS` | Daemon lease duration | Validate handover under the selected failure model |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Trace export destination | Control access and sensitive-data handling |

Secret material requires a separate custody record. Release verification also uses configured trust class, trusted signer fingerprint, minimum policy epoch, bundle location, and expected source identity. Some values deliberately sit outside the signed bundle. A bundle must not choose its own trust root.

Do not copy example credentials into a deployment. Do not infer a safe secret backend from an environment variable's existence. Verify which provider loads each key, how rotation works, and which service identity can read it. Record only secret identifiers and fingerprints in general support artifacts.

## Jurisdiction and content admission

A jurisdiction configuration selects the legal and operational content for that zone. It must identify actual authority, admitted packs, adapter declarations, and supported operation families. A jurisdiction label alone does not supply the governing law or a registry connection.

Content-addressed references make the selected bytes identifiable. Signatures establish statements by identified signers under a trust policy. Counsel and authority processes establish whether those bytes correctly express the applicable legal requirements. These are distinct acceptance questions.

Operation definitions require their actual parameters and declared effects. Executable registry admission must fail when required content cannot load. An empty executable catalog cannot be accepted merely because the process serves a health endpoint. The operator must exercise representative admitted operations after configuration changes.

External registry adapters need explicit capability records. Record supported actions, credential class, external environment, request and response identifiers, and the durable acknowledgement that ends the action. An adapter declaration without a live provider transaction supports configuration discovery only.

## Local verification and deployment profiles

A local verification environment must bind requests and background work to the same source and configuration. A second process connected to a shared database can hold a daemon lease and advance an operation. In that case, a response from the local API does not prove that its binary performed the subsequent work.

Use a dedicated test principal and purpose-built entities. Create feature state through authenticated product APIs. Separate intentionally isolated databases from shared development databases. Never use a production-connected process to manufacture test evidence.

The maintained local launcher prepares and verifies a local release attestation before starting the executable. A bare executable invocation can fail that gate. Operators using a supplied distribution should use its supported launcher and inspect its resolved configuration. Local attestation proves a different trust class from a production release.

Infrastructure definitions exist for container deployment, AWS environments, and Kubernetes packaging. Their existence establishes packaging options. Equivalent behavior across clouds requires an acceptance campaign on each selected topology. Neither a chart nor a successful infrastructure plan proves registry connectivity, legal admission, or recovery readiness.

# Operations, upgrades, and recovery {#operator-recovery}

## Establish the operating record

For each environment, retain the deployed artifact identity, configuration digest, schema state, content roots, key identifiers, and dependency endpoints. Record the responsible operator and the authority for changes. This record must be specific enough to reproduce an observation without storing plaintext credentials.

Health checks answer a narrow question about the process and its dependencies. They do not replace business acceptance. Monitor whether admitted operations reach their required terminal effects. A healthy listener can coexist with a failed webhook queue, an unavailable signing provider, or stalled operation advancement.

Alert rules should connect a signal to a response. Define the affected journey, the evidence to collect, the owner, and the threshold's basis. Useful signals include sustained operation age, repeated delivery failure, database acquisition delay, lost leadership renewal, and retrieval-integrity failure. Thresholds require measured workload behavior and a chosen service objective.

A queue-length alert alone can mislead. A brief large queue may drain normally, while one old legally significant filing may require immediate action. Track age and outcome class alongside volume. Preserve the exact operation and provider identifiers needed to investigate the affected work.

## Controlled upgrade

Before an upgrade, identify every compatibility boundary affected by the candidate. These include database migrations, operation definitions, proof verification, SDK schemas, authorization, and external adapters. Re-run the journeys whose contracts cross those boundaries. A successful image build is only one prerequisite.

Capture the current database recovery point and verify the candidate's migration behavior. Determine whether the previous executable can read the upgraded schema. A rollback plan that only replaces the image is incomplete when migrations have changed persistent state.

Long-running operations require explicit upgrade treatment. Preserve their recorded definition, authored parameters, authority bindings, and required evidence. Do not assume a content change rewrites an existing operation's legal basis. Determine which stored content and definition references the operation actually resolves after restart.

During replacement, remove draining instances from new traffic and allow bounded completion of admitted work. The implementation provides signal-triggered graceful drain and a readiness marker. The operator must align load-balancer deregistration, application drain, and container termination budgets. A premature hard termination can interrupt a response after a durable commit.

After replacement, verify the serving artifact and the current daemon holders. Read a previously completed operation, resume a permitted pending operation, and execute a new accepted journey. Check denials and idempotent replay. These checks test different compatibility obligations and cannot substitute for one another.

## Leadership and process controls

Daemon leadership uses PostgreSQL leases. Lease records carry holder and build information. Renewal and voluntary release support handover. These mechanisms identify the active worker, but they do not independently prove completion of a particular operation.

When advancement stalls, first inspect the relevant process and lease holder. Determine whether the holder is alive, renewing, and running the intended build. Inspect errors and durable operation state before changing infrastructure. A stale-looking ledger entry alone is insufficient to conclude that a worker has stopped.

Use supported process shutdown and orchestration controls for recovery. Allow normal lease expiry or voluntary release to transfer work. Direct deletion of lease rows can create overlapping workers and destroy useful evidence. It is not a routine recovery procedure.

The source exposes request, advancement, support, and combined daemon-selection modes. The selected mode controls which daemon classes start. Operators must verify the resulting listener and process behavior before claiming independent failure domains. A configuration enum alone does not establish network isolation, scheduling isolation, or a tested split deployment.

## Backup, restore, and retention

A recoverable Mass deployment needs more than a database dump. Preserve durable database state, required object bytes, content-addressed packs, release evidence, and the trust material needed to verify retained records. Key custody can use a separate recovery procedure, but its dependency must remain explicit.

Define the recovery point objective as the maximum accepted loss of committed data. Define the recovery time objective as the time allowed to restore the required service. Both are operator commitments that require measurement. This specification does not assign universal values to either objective.

A restore drill must use an isolated authorized target. Verify schema compatibility and integrity before allowing writes. Retrieve representative documents and verify their digests. Resolve an operation's proof and required historical content. Confirm that pending external work does not execute twice when the recovered service resumes.

Database recovery and provider recovery have different histories. A provider may have acknowledged an action after the restored database's recovery point. Reconciliation must discover that acknowledgement using stable external identifiers. Blindly replaying all pending requests can duplicate legally or financially effective actions.

Retention rules must distinguish event history, personal data, document objects, delivery records, telemetry, and backup copies. Each class needs an authority, purpose, access rule, and disposal condition. A general privacy statement does not establish that every copy has the same retention mechanism.

The event journal is append-only except under verified archival rules. Archival must preserve retrievability and the evidence necessary for verification. Deleting events to reduce storage cost can break replay, audit, and proof interpretation. Retention acceptance therefore includes retrieval after archival and verification after restoration.

## Incident handling

Begin with the affected user outcome. Identify the submitted intent, operation, current state, and missing acknowledgement. Determine whether the incident concerns authorization, execution, delivery, storage, or observation. This classification determines the next safe action.

Preserve source identity, configuration, causal identifiers, and relevant logs before restarting a service. Collect enough evidence to explain duplicate prevention and any irreversible effects. Redact secrets and unnecessary personal data. A support bundle should let another operator reconstruct the failure without receiving general access to the environment.

If the API is available but work remains pending, inspect the required external action and advancement owner. If callbacks fail, inspect signature verification and delivery identity. If streams disconnect, reconcile the durable operation before retrying business work. If proof verification fails, preserve the artifact and trust inputs instead of replacing them with newly generated evidence.

Recovery ends when the required effects and their acknowledgements are verified. Restoring a green dashboard is insufficient. Record any remaining partial outcome and its authorized recovery path. Keep the distinction between a repaired service and a completed customer operation visible.

# Capacity and scaling acceptance {#capacity-acceptance}

## Define the measured workload

Mass workloads differ substantially. Entity reads, compilation, document generation, signature waits, and settlement do not consume the same resources. Capacity must be measured against an explicit mixture of requests, operation durations, payload sizes, and dependency behavior.

Separate request acceptance rate from operation completion rate. A system can admit work faster than its external dependencies complete it. If the difference persists, queue age grows even while request latency remains low. A useful capacity report measures both rates and the resulting backlog.

Let $\lambda_a$ be the admitted operation rate and $\lambda_c$ the completed operation rate. Over an interval, backlog growth is approximately $(\lambda_a-\lambda_c)\Delta t$, subject to cancellation and rejection. This accounting identity does not predict either rate. A benchmark must observe them under the selected workload.

Long-lived streams also consume resources. They hold connections while ordinary requests continue. Load tests should include reconnects, slow consumers, authentication checks, and replay reads. A benchmark containing only short anonymous requests cannot establish capacity for authenticated agent fleets.

## Bound the actual resources

The executable enforces a TCP connection bound before normal HTTP processing. It also applies a request-header deadline. These controls protect resources at an earlier boundary than application operation limits. Their configured values are admission controls, not measured service capacity.

Database pools create another bound. Budget every pool actually initialized across all replicas. The examined startup initializes one primary pool; optional read and daemon accessors fall back to it because the multi-pool state is unset. Leave capacity for migrations, monitoring, and controlled recovery. Increasing replicas without revisiting that budget can exhaust the database before CPU becomes limiting.

If a future or separately configured deployment wires a read replica, it requires a consistency policy. Determine which reads tolerate replication lag and which follow a mutation immediately. Do not route an authorization or completion decision through stale data unless its contract explicitly permits that behavior. Setting `DATABASE_READ_URL` alone does not establish this topology in the examined executable.

The implementation includes scale configuration for concurrent operations, agent connections, backpressure, and entity-routing shards. Large default ceilings do not prove that the process can sustain those populations. A routing-shard count also does not establish distributed storage or cross-shard transaction behavior. Trace the actual callers and measure the deployed topology.

## Separate failure domains deliberately

Replica scaling and daemon scaling solve different problems. More request replicas can increase admission capacity while a single leased daemon still limits advancement. More support workers can improve delivery only if their ownership and queue semantics permit concurrent work.

A split topology needs explicit ownership of each daemon class. It also needs compatible artifact and content identities across processes. During a rolling change, determine whether old and new workers can safely share the persistent operation representation. Lease handover does not itself provide schema compatibility.

Dependency limits can dominate throughput. Templating, object storage, identity providers, notification services, and registry adapters each have their own capacity and failure model. Include their rate limits and acknowledgement delays in admission planning. A local simulator cannot establish the capacity of a live registry.

## Benchmark protocol

A defensible benchmark records the executable, configuration, hardware allocation, database size, content set, and provider mode. It states warm-up behavior, run duration, offered load, admitted load, and error distribution. It reports latency percentiles with the population they describe.

Use workloads that exercise the required financial and legal effects. Include repeated intents, denied requests, large valid payloads, callbacks, and restart recovery. Check persistent invariants after load. High throughput with duplicate effects is a failed benchmark.

Run overload tests separately from steady-state tests. Increase demand until admission limits activate, then verify recovery after demand falls. Confirm that rejected work does not leave ambiguous committed effects. Observe whether retries amplify load and whether queues return to the agreed age bound.

Publish capacity only for the tested configuration and workload. Extrapolation requires its own model and assumptions. Configuration switches, asymptotic arguments, and component timings may inform planning. They cannot establish an economy-wide throughput guarantee.

# Conformance and operator reference {#conformance-reference}

## Evidence classes

Conformance is a set of claims tied to evidence and acceptance rules. A percentage without a defined population can conceal missing journeys. A deployment must report which requirements passed, failed, were skipped, or were not exercised.

| Evidence class | What it can establish | What remains outside its scope |
|---|---|---|
| Schema validation | Payloads satisfy specified structural rules | Authority, external effects, and semantic correctness |
| Source inspection and static gates | Declared boundaries and detectable implementation properties | Behavior of an unobserved deployment |
| Unit and property tests | Selected component properties under test assumptions | Full authenticated journeys and real providers |
| API or MCP execution | Observed behavior for bound requests and actors | Unjoined future work or other configurations |
| Cryptographic verification | Artifact integrity and checked trust predicates | Truth of unsupported external assertions |
| Recovery and load campaigns | Tested failure and capacity behavior | Untested topologies or universal guarantees |

A conformance record should name the requirement, test population, source identity, environment, actor, result, and supporting artifacts. It should also identify exclusions and the first known failure. An average score must not hide a failed invariant such as duplicate payment or unauthorized mutation.

## Acceptance by complete journey

Freeze the required effects before testing. For a signing journey, these can include the intended document, authenticated signer, stored signature result, operation transition, and final retrievable artifact. A notification can be an additional required effect when the public contract promises it.

Bind every observation to the same intent and integrated deployment. Record operation, step, event, provider, document, and verdict identifiers where applicable. Do not combine a successful API request from one build with a callback from another and call the combined result a passed journey.

Test the relevant denial and recovery paths. These include insufficient authority, altered authored content, duplicate delivery, lost response, reconnect, cancellation, and restart. Select cases from the operation's actual contracts. A fixed generic checklist can omit the coupling that makes a particular workflow difficult.

A skipped test remains unexecuted. A stubbed provider supports a narrower integration claim. A registered MCP tool supports discovery. A generated proof-shaped document supports only the predicates actually verified. Reports must retain these distinctions in their headline result.

Formal results have explicit hypotheses and model boundaries. A mechanized theorem can establish a property of its formal model. Connecting that result to executable behavior requires a refinement argument or checked correspondence. A theorem count is not a count of deployed guarantees.

## Reproducible interface checks

For an authorized source distribution, the tooling includes OpenAPI export, SDK generation, SDK type checking, and SDK builds. These source-defined preparation commands require that distribution. They are not presented as tests executed for this specification.

```sh
make sdk-openapi
make sdk-generate
make sdk-typecheck
make sdk-build
```

The OpenAPI exporter uses the API composition root's generated contract. A deployed comparison additionally retrieves `/openapi.json` from the selected process. Compare operation sets and schemas, then run the authenticated client journeys affected by any difference.

SDK checks must include error paths and response interpretation. A regenerated type file can be consistent with an incorrect annotation. A compiling wrapper can call an unmounted route. Contract drift checks, route parity checks, and runtime examples answer different questions.

A source-generated module or dependency inventory should record its generation inputs. Group implementation components by responsibility: domain types, business services, persistence, transport, API composition, languages, storage, and verification. Count source artifacts only when the inventory needs those counts. File totals provide navigation, not assurance.

Dependency review must inspect the actual dependency graph and lock data. The composition root owns construction, primitive services own business behavior, and persistence facades own database access. External wire types remain confined to their adapter boundaries. A generated graph helps detect an illegal edge but cannot establish all semantic ownership rules.

## Command-line reference

The `mez` command provides validation, content handling, zone composition, and offline protocol utilities. The installed binary's help output defines its accepted options. The following command families exist in the examined parser.

| Family | Intended work | Evidence boundary |
|---|---|---|
| `validate`, `lock` | Validate content and produce or verify deterministic lock data | Content checks do not boot a zone |
| `artifact` | Store, resolve, and verify content-addressed artifacts | Integrity does not establish legal authority |
| `law`, `regpack` | Ingest and verify legal or regulatory content | Admission and counsel obligations remain explicit |
| `zone`, `init`, `deploy` | Compose zones and generate deployment material | Generated configuration is not deployed behavior |
| `corridor`, `audit` | Manage corridor artifacts and inspect receipt evidence | Offline verification does not prove live peer delivery |
| `asset` | Inspect asset lifecycle and state-chain operations | Effects depend on the selected command and target |
| `agent`, `arbitration` | Work with policy and dispute tooling | Local artifacts do not replace authorized product actions |
| `vc` | Generate keys and sign or verify credentials | Key custody and issuer authority require separate controls |
| `demo` | Run an offline corridor narrative | Demonstration output is not production execution evidence |

For a supplied content distribution, validate the complete selected content set before producing lock data. These source-defined commands illustrate that preparation sequence:

```sh
mez validate --all-modules --all-profiles --all-zones
mez lock zone.yaml --out zone.lock.json
mez lock zone.yaml --out zone.lock.json --check
```

Here `zone.yaml` denotes the operator-supplied zone configuration. It is an input placeholder, not a packaged example with assumed legal authority. Strict reproducibility also requires a pinned generation timestamp under the command's `--strict` and `--generated-at` options. Preserve the selected timestamp with the other generation inputs.

Use help before selecting a command whose flags differ across distributions. These source-defined discovery commands have no claim of fresh execution here:

```sh
mez --help
mez validate --help
mez lock --help
mez artifact --help
mez corridor --help
mez audit --help
```

Before a mutating command, identify whether it writes a local artifact, changes a service, or contacts an external authority. Verify its target and credentials. A command that generates infrastructure is distinct from applying that infrastructure. A signing command requires authority over the signing key and intended statement.

For offline verification, retain the input bytes, referenced content, trust roots, command options, and output. Verify that the command rejects an altered artifact. A zero exit status without the expected output and input binding is insufficient evidence.

## Release acceptance record

The release acceptance record must separate artifact verification from deployment acceptance. Artifact verification covers executable identity, dependency evidence, signatures, and required static or test results. Deployment acceptance covers configuration, live dependencies, authenticated journeys, and recovery behavior.

Supply-chain reports must use the current dependency lock data and advisory results. Record unresolved findings and their disposition. A previously clean audit cannot establish the status of changed dependencies. Automated checks do not remove the operator's obligation to assess reachable vulnerable behavior.

The final acceptance decision should identify every required journey and its terminal acknowledgement. It should name the exact unresolved obligations that prevent broader use. A narrow successful deployment can be described precisely without claiming that all jurisdictions, providers, or operation families are ready.
