# Integration and operator reference {#integration-operator-reference}

This reference connects interface discovery, credential selection, local preparation, and operational diagnosis. Commands identify source-defined interfaces. None establishes a newly executed deployment, test, filing, or recovery campaign. Example identifiers denote local test artifacts and confer no legal authority.

## Credential selection and admission

Select credentials by the route's trust boundary. A signed token proves possession of an accepted credential under its validation rules. Business authorization additionally depends on the actor, subject, scope, current authority state, and proposed action.

| Credential class | Validation boundary | Operational use |
|---|---|---|
| Firebase identity token | RS256 signature, configured project audience and issuer, required identity and time claims | Authenticated user sessions and dedicated test principals |
| Mass access JWT | Ed25519 signature, expected issuer and audience, expiry and issued-at checks | Scoped access issued through the OAuth client-credentials flow |
| Service JWT | Service issuer, service audience, signature, and time checks | Explicit service-to-service admission where the route accepts it |
| MassBiscuit | Accepted capability encoding, signatures, caveats, and current authority checks | Capability-bound actions supported by the selected interface |
| Internal shared credential | Configured internal authentication lane and route restrictions | Restricted service integration, without public-user authority |

The Firebase verifier requires `sub`, `iss`, `aud`, `exp`, and `iat`. It configures a 30-second clock allowance. It also checks subject consistency where duplicate identity fields occur. The presence of an email address in a payload does not establish verified identity.

The Mass JWT verifier rejects an expired token beyond its allowance. It rejects future issuance and issuance older than its maximum accepted lifetime. When an audience is expected, a missing audience fails. A different issuer or audience also fails. These are implemented checks, not a reason to tolerate unsynchronized infrastructure clocks.

`POST /oauth/token` accepts the client-credentials grant. The request provides `grant_type`, `client_secret`, optional `client_id`, and optional space-delimited `scope`. The handler checks the credential record and recognized scope names before issuing an access token. Token issuance also has an audited mutation path.

Scope computation has a compatibility exception. With nonempty allowed and requested sets, the helper returns their intersection. With no requested scopes, it returns the allowed set. With an empty allowed set, it can return requested scopes. Both sets empty produces no scopes. Operators must configure explicit allowed scopes and test rejection outside them.

`POST /v1/oauth/introspect` is an authenticated administrative surface. The examined guard requires the corresponding administrative role and compliance-read scope. Its active-status check includes JTI revocation. JTI means the token's unique identifier. The removed `/v1/oauth/revoke` route must not appear in new integration instructions.

The authentication path also checks JTI revocation against durable state. A database failure during authority resolution must not become unrestricted access. Entity membership resolution distinguishes an empty membership result from a failed lookup. The latter returns a retryable failure instead of silently admitting an empty scope.

JWT revocation, signing-key rotation, and capability epochs are different controls. JTI revocation addresses an individual issued token. Key rotation changes which signatures a verifier accepts. Capability authority and revocation state constrain delegated actions under their own current-state rules. Completion of one control does not prove completion of the others.

OAuth signing can use an independent configured key. The examined resolver can fall back to the zone signing key, including after a provider error. Therefore, setting an OAuth key variable does not establish independent key custody. Verify the actual signer fingerprint, accepted verification keys, and issued-token behavior before declaring rotation complete.

For capabilities, retain the accepted byte encoding and current authority requirements. A JSON-looking object is not interchangeable with an encoded capability token. Client attenuation and server verification must agree on the representation. Exercise the exact producer-to-consumer path before relying on an SDK method's name.

### Ingress order and route classes

The main authenticated route graph applies rate limiting and backpressure before authentication. Zone context and authenticated scale checks precede write-contract and idempotency handling. Outer layers also establish request identity, client-IP context, content handling, tracing, and drain behavior. Router composition determines the execution order because later layers wrap earlier layers.

Public token issuance has a separate rate-limit configuration. Health routes and restricted internal routes have their own composition. Do not infer a route's security from a neighboring prefix. Verify the specific mounted route and its guard, including middleware installed by its parent router.

| Route class | Credential and enforcement | Acknowledgement boundary |
|---|---|---|
| Public operation admission | Accepted caller credential, entity and action scope, write contract, idempotency, sanctions and applicable compliance checks | Durable admitted operation or proof response, interpreted with residuals |
| Public resource read | Route-specific identity, scope, and disclosure guard | Authorized representation of current or documented historical state |
| External compute call | Explicit service contract and permitted egress credential | Compute response only, until Mass validates and persists required effects |
| Internal persistence integration | Restricted internal credential and owning service contract | Authorized durable mutation, subject to the mutation boundary |
| Provider callback | Provider verification, event identity, and exact subject binding | Admitted callback or delivery acknowledgement, followed by required operation effects |

The public API generally uses its owning-domain schema. External compute can use a different private wire schema. The adapter owns that conversion. A callback's valid signature cannot replace entity binding, and an internal credential cannot make an arbitrary database write legitimate.

## API domain navigation

Use `/openapi.json` from the intended process to obtain methods, request schemas, response schemas, and security declarations. Match its routes to the source-mounted domain modules. The table below identifies verified navigation families without claiming a complete endpoint census.

| Owning route module | Mounted navigation family | Discovery question |
|---|---|---|
| Entity routes | `/v1/entities` | Which entity lifecycle and membership operations accept this actor? |
| Ownership routes | `/v1/ownership` | Which cap-table, security, and offer records belong to the subject entity? |
| Treasury routes | `/v1/treasury`, `/v1/fiscal` | Which actions require treasury compute or an external payment acknowledgement? |
| Identity routes | `/v1/identity` | Which identity action and evidence type does the selected controller accept? |
| Governance routes | `/v1/governance` | Which consent, meeting, or signing action is currently actionable? |
| Corridor routes | `/v1/corridors` | Which peer, state transition, receipt, or audit representation is requested? |
| Smart-asset routes | `/v1/assets` | Is the action validation, simulation, or a durable asset transition? |
| Arbitration routes | `/v1/disputes` | Which dispute phase permits the requested action? |
| Notification routes | `/v1/notifications` | Is the result a delivery record, search result, or restricted message detail? |

A domain can contain several prefixes, and one prefix can combine several services. The ownership route module, for example, does not make all ownership behavior a single database aggregate. Resolve the operation identifier and response schema before choosing a client wrapper.

Generated catalogs must retain mounted-path evidence. Source comments sometimes describe a former endpoint name. The OAuth introspection comment and mounted path illustrate why the router expression controls route discovery. Client methods also need comparison with the mounted contract, not just their generated types.

| Component | Owner and dependencies | Verification question |
|---|---|---|
| API composition | Constructs routes, middleware, services, and daemon state | Do requests and background work use the same wired services? |
| Primitive service | Owns domain behavior and calls its persistence facade | Does the action preserve authored fields and applicable invariants? |
| Persistence facade | Owns storage mapping and transactional database access | Do committed records represent the required effects atomically? |
| External adapter | Owns provider transport and wire conversion | Is the exact provider request joined to its acknowledgement? |
| Operation runtime | Coordinates steps, waits, and recovery | Are terminal outcomes supported by all required durable effects? |
| Client and MCP transport | Encodes requests and interprets responses | Does the real caller reach the expected route and retain residuals? |

## Linear local verification path

### Prepare the target

Obtain an authorized source distribution or a release artifact with its verification material. Identify a local PostgreSQL target, required external compute, object storage, and identity-provider configuration. Reserve an unused port. Determine which other processes can advance work against the same database.

For source builds, use the distribution's Rust toolchain. The local launcher also requires the supported Chrome or Chromium executable for document rendering. Docker is required when using the supplied local service containers. The web client requires its pinned Node and package-manager configuration when the test includes browser authentication.

These discovery commands inspect local processes and tools:

```sh
docker ps --format '{{.Names}}\t{{.Ports}}'
lsof -i :8080
rustc --version
cargo --version
```

The port shown is a diagnostic example. Select another free port when necessary. Do not stop an unknown process to obtain that port. A successful tool-version command only establishes that the tool can run.

### Configure and launch

Provide the authorized local environment file without printing its secrets. Set the database target, listener port, zone selection, compute URLs, object storage, and authentication configuration. Use a build directory dedicated to this source state. The launcher sources its environment file, so values inside that file can override inherited shell values.

The source launcher inspected on 6 September 2026 belongs to the authorized implementation distribution. It builds the API executable, prepares local attestation material, verifies that material, and starts the process. Operators need that distribution's launcher and environment contract to perform these actions. This reading edition describes the procedure without supplying a runnable launcher. Its local, untrusted attestation does not produce production release evidence.

The current launcher requires an operator-provided database. It defaults the listener to loopback only when `MEZ_BIND_ADDR` is absent. It supplies the `world` umbrella when neither jurisdiction nor zone configuration is set. Choose an explicit zone when the acceptance case depends on one jurisdiction. Its local attestation uses existing archived reports; the launcher does not rerun those verification campaigns.

In an authorized source distribution, use the supplied compute-service target when those containers belong to the local test environment:

```sh
make dev-services
make dev-status
```

The first command builds and starts services. The second probes fixed localhost ports and container names. Check the selected runtime separately when its addresses differ. Neither establishes that a business operation works through those services.

After launch, retrieve `/health/build`, `/health/readiness`, and `/openapi.json` from the selected origin. Preserve build identity and contract digest without exposing secrets. A readiness failure requires diagnosis before business verification. A healthy result permits the next test but does not complete it.

### Establish the dedicated actor

Use the dedicated E2E principal or its purpose-built alias. Do not use a personal account. Obtain its session through the supported identity-provider harness. Where a fresh environment requires platform administration, bind the dedicated verified UID through `MEZ_PLATFORM_ADMIN_UIDS` under the operator's authorization.

Create test entities, membership, and identity through authenticated APIs. For administrative identity creation, establish the target user's entity membership first: the route requires an owning entity to anchor its proof and rejects an absent anchor before writing. Supply the idempotency key required by the public write contract. Do not create missing product state with direct SQL.

Test notifications can cause real delivery. Use only approved test recipients and provider destinations. A fake email inside a request is not a supported substitute for authenticated identity. Verify which provider mode the environment actually uses.

### Exercise the first operation

First retrieve an authorized subject through the API. Then discover the admitted operation type and its required input schema. Choose a bounded operation whose authored inputs and required effects are available. Preserve one intent identifier across its transport attempts.

Submit through the selected public interface. Record the returned operation, step, and verdict references. Inspect pending actions before advancing work. If the operation requires a signer or provider acknowledgement, complete that actual boundary under the dedicated test authority.

The inspected implementation distribution supplies a live entity suite. After configuring the environment and credentials, an authorized operator runs that suite from its Cargo workspace, with output capture disabled and one test thread. Set `MEZ_TEST_BASE_URL` explicitly to the selected local origin. Configure the dedicated test email and authenticated credential inputs through the approved environment. This suite fails when `MEZ_TEST_BASE_URL` is unset. Its source and runner are required for execution and are not included in this reading edition. A skipped case remains unverified.

Retrieve the resulting operation proof through its mounted route. Check its subject, verdict reference, artifact bindings, and residuals. Use the server's accepted verification request schema. The client wrapper and server currently require explicit compatibility review for proof-field naming. Do not claim successful verification from a typed method signature.

The path is complete only when the required durable effects and verification result agree. If the selected verifier rejects the request shape, record that failure. Repairing the interface or using its documented accepted schema requires separate implementation verification. A locally constructed success object cannot close the test.

## Deployment responsibilities

| Surface | Present configuration mechanism | Operator responsibility |
|---|---|---|
| Executable | Container image and release-attestation inputs | Pin the actual artifact and verify the externally selected trust root |
| Workload identity | AWS task and execution roles, or selected platform equivalent | Separate image/secret access from application permissions |
| Network | Task security groups and ingress rules | Admit traffic only from intended ingress and required dependencies |
| TLS | Certificate and listener configuration, or Kubernetes ingress TLS settings | Validate certificate ownership, hostname, renewal, and termination boundary |
| Service account | Kubernetes chart service-account configuration | Supply required permissions without assuming token automount |
| Rollout | Container-service or Kubernetes rolling strategy | Align readiness, drain, termination, migrations, and daemon handover |
| Persistence | PostgreSQL, document storage, and retained content | Verify access, residency, backup consistency, and restoration |

The examined Kubernetes values contain example image, host, secret, and resource settings. They are not deployment recommendations. Some configuration templates can lag the executable's requirements. Compare rendered configuration with actual consumers before applying it.

The AWS source includes separate task and execution roles and a task ingress boundary tied to the load balancer. Those declarations require an applied-state check. A Terraform file cannot prove that the active security group, certificate, or role matches it.

## Coupled controls

The table separates active environment consumers from typed parameters and unproven deployment controls. Units matter: receipt counts, seconds, absolute deadlines, and currency exposure are different quantities.

| Control and unit | Consumer and validation | Coupling and acceptance |
|---|---|---|
| `MEZ_DAEMON_SYNC_SECS`, seconds | Corridor daemon interval, clamped to its minimum | Compare receipt production with peer delivery and queue age |
| `MEZ_DAEMON_HEARTBEAT_SECS`, seconds | Corridor heartbeat scheduling, clamped to its minimum | Probe delay interacts with missed-heartbeat classification |
| `REVOCATION_SYNC_INTERVAL_SECS`, seconds | Revocation synchronization configuration | Poll cadence does not guarantee peer reachability or fresh authority |
| `REVOCATION_SYNC_REQUEST_TIMEOUT_SECS`, seconds | Revocation peer request budget | Budget failed peers without starving other work |
| `refresh_interval`, `max_staleness`, seconds | Sanctions lawpack feed settings and freshness consumer | Source validation rejects staleness shorter than refresh interval |
| `freshness_days`, days | Required-receipt regime selector and receipt-check step | Must be positive and match the issuing authority's evidence contract |
| `checkpoint_frequency`, receipt count | Typed corridor receipt-chain parameter | No active API/daemon consumer was established in this review |
| `max_receipt_latency_secs`, seconds | Typed corridor receipt-chain parameter | A declared limit needs a demonstrated enforcement caller |
| Migration `timeout`, absolute UTC deadline | Migration protocol timeout check for nonterminal phases | Extend neither authority nor settlement finality by changing a local timer |
| Exposure limit, currency amount | Requires the owning transaction and risk-policy contract | No universal deployment environment knob was established here |
| Availability requirement | Depends on the selected provider, peer, or evidence contract | Health probes cannot establish receipt or artifact availability |

Do not turn typed fields into advertised tuning switches without a verified consumer. Checkpoint parameters illustrate the distinction. A serializable value can travel through content snapshots without controlling a running scheduler. Its presence does not prove a checkpoint every specified number of receipts.

Sanctions freshness and sanctions rejection also remain separate. Feed age can produce an evidence residual. It must not convert a sanctions rejection into an allowed action. Acceptance should test stale evidence, failed refresh, restored freshness, and the terminal rejection path independently.

`DATABASE_READ_URL` is parsed by a separate pool initializer, but the examined executable uses the single-pool initializer. The optional pool composition is not wired there. Therefore, setting this variable does not establish an active read replica. Verify the actual connection consumer before reporting read isolation or read scaling.

## Symptom, diagnosis, and recovery

| Symptom | Diagnostic evidence | Supported recovery direction |
|---|---|---|
| Process exits before binding | First startup error and attestation/configuration identity | Correct the rejected input and rerun the supported launcher |
| Missing compute URL | Named configuration failure | Provide the intended endpoint, then verify its connectivity |
| Readiness fails after startup | Dependency results and drain state | Restore the required dependency or complete controlled replacement |
| JWT rejected | Issuer, audience, time class, and revocation result without token disclosure | Correct credential selection or authorized issuance |
| OAuth scope differs from request | Credential's allowed scopes and granted response | Configure explicit allowed scopes and repeat denial checks |
| Operation remains waiting | Step type, exact subject, signer or provider identifier | Complete the required action through its supported boundary |
| No advancement | Current daemon holder, build identity, renewal, and errors | Repair the worker or use controlled process handover |
| Stream reconnect loses display state | Durable operation read and last received event identifier | Reconcile state and resume from the returned cursor |
| Callback repeatedly fails | Signature inputs, event identity, and subject binding | Repair verification or routing, then replay the same event safely |
| Document retrieval fails | Object identity, storage response, and recorded digest | Restore authorized access or bytes and verify integrity |
| Proof verification fails | Exact request schema, proof bytes, trust inputs, and residuals | Resolve the actual schema or evidence failure before claiming admissibility |

A diagnosis must preserve the original committed effects. Restarting a display client does not cancel an operation. Recreating an operation does not repair a failed notification. Changing a key does not retrospectively verify an artifact signed under another key. Recovery must use the causal identifiers of the affected work.

## Local CLI lifecycle examples

Run these commands from the supplied content working directory. Input files must contain the relevant schemas and authored content. The commands below prepare or inspect local artifacts. They do not submit transactions to the running Mass API.

### Corridor preparation

```sh
mez corridor create --id pk-rez--ae-difc \
  --jurisdiction-a pk-rez --jurisdiction-b ae-difc
mez corridor submit --id pk-rez--ae-difc \
  --agreement agreement.json --pack-trilogy pack-trilogy.json
mez corridor status --id pk-rez--ae-difc
```

The create command writes a local corridor record. Submit hashes available agreement and content bytes, but substitutes path-string bytes when a file is missing. It checks the local transition and records a pending state. The resulting digest therefore does not by itself establish artifact custody. The command does not submit to a regulator. The separate activation utility hashes supplied approval strings without authenticating regulatory signatures. Its local state is insufficient evidence for corridor admission.

### Asset artifacts

```sh
mez asset genesis-init --asset-id asset:example \
  --owner did:example:owner --out genesis.json
mez asset state verify --chain asset-chain.json
mez asset state checkpoint --chain asset-chain.json --out asset-checkpoint.json
```

The first command creates a local genesis envelope. The remaining commands require an independently supplied chain file. Genesis output alone does not provide that chain. None registers an asset through the service. The genesis initialization and genesis-hash handlers also hash different object shapes, so their digests must not be assumed equal.

### Regulatory content

```sh
mez regpack list
mez regpack build --jurisdiction pk --domain sanctions --store
mez regpack verify --jurisdiction pk --domain sanctions
```

Build uses the supplied regulatory data and stores a local content artifact. Verification without a file or digest follows a rebuild-validation path. These operations neither install content into a running zone nor establish current regulatory acceptance.

The file/digest verification path has a material limitation. A mismatch between canonical and declared digest can produce a warning while returning success. Therefore, a zero exit status on that path does not establish digest integrity. Retain diagnostics and verify the relevant digest with an independently checked verifier.

### Dispute preparation

```sh
mez arbitration institution-list
mez arbitration dispute-init \
  --claimant-did did:example:claimant \
  --respondent-did did:example:respondent \
  --jurisdiction sg --institution-id siac \
  --dispute-type payment-default \
  --claim-description "Payment remains outstanding" \
  --out dispute-init.json
mez arbitration dispute-file --init dispute-init.json --out filing-summary.json
```

The first command lists the built-in institution registry. Initialization creates an envelope, and filing stores a local dispute record. It does not file with the named institution. If an amount is supplied, the currency must also be supplied. Use an authorized product or institution interface for an actual filing and retain its acknowledgement.
