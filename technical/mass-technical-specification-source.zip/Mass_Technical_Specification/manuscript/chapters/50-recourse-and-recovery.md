# Cases, consent, and evidence

Recourse records disputes and specifies how authorized outcomes can reach the systems that control the affected records and assets. Its case model connects allegations, evidence, procedural decisions, and requested relief. Each connection must preserve who asserted a fact, who decided it, and which authority permits the next action.

Recourse owns case administration and its records. Mass controls changes to organizational and regulated state. Moxie controls consensus, claim pricing, clearing, and settlement. A custodian controls assets under its accepted mandate. These responsibilities require separate acknowledgements because each system applies its own admission rules.

The current implementation includes case intake, artifact custody, signed lifecycle actions, institutional procedure, and durable SQLite records. Configured modules add referrals, portable outcome recognition, execution instructions, native proof verification, and recovery reconciliation. Retained verification records demonstrate bounded local execution with synthetic institutions, destinations, and native proofs. Production acceptance and authentic native economic execution remain open. The following chapter gives the concrete operating contracts and evidence limits.

## A case and its claims

A case groups a dispute between parties under a submitted agreement. A *head of claim* identifies one allegation and its requested relief within that case. Its identifier remains stable when procedure, evidence, or destination mapping changes. A claim in this procedural sense can concern a Moxie financial claim, but the identifiers denote different objects.

The intake record includes claimant and respondent identifiers, legal names, and optional jurisdictions. It also includes the institution, governing law, arbitration seat, agreement, filing document, heads of claim, and related objects. The service rejects identical claimant and respondent identifiers. It records the other fields as submitted assertions, subject to structural validation.

A head includes a non-nil UUID, dispute type, description, optional monetary amount, and subject references. Subject references identify affected peer objects. Case-level related objects provide context. A filing accepts between one and one hundred heads with distinct identifiers. Each head permits up to one hundred subjects, and the case permits up to one hundred related objects.

These bounds constrain the current wire contract. They do not define institutional jurisdiction, a damages ceiling, or a threshold for tribunal procedure. An institution must derive those limits from the applicable instruments and its adopted rules.

The following notation summarizes the conceptual relationships. It is specification notation, not an additional request schema.

```text
Case = (case_id, filing, revision, evidence, events)
Head = (head_id, allegation, relief, subject_refs)
SubjectRef = (system, native_context, native_id, kind)
ArtifactRef = (digest_algorithm, digest_value, media_type)
```

A Mass subject retains its zone and native UUID. A Moxie subject retains its chain and native 32-byte identifier. The case UUID must not replace either identifier. Any adapter must retain the mapping between case, head, destination request, and destination object.

## Identity and authority

An authenticated account establishes who submitted a request under a configured grant. Tribunal authority requires separate evidence. The current service binds a bearer-token digest to a tenant, actor DID, validity period, optional case scope, and independent read and write permissions. It takes the tenant and actor from that grant. Request bodies cannot choose a different acting identity.

Case access also checks the local origin, filing parties, and current claim-scoped delegation or appointment. Whole-case reads require authority covering every claim. Protocol actions have separate checks for their submitted scope. Mutation responses return the relevant receipt, while complete records require current read access. Current access checks also precede saved-response replay.

Consent names the institution, review, service, execution, and reconciliation principals. Configured keys establish their cryptographic identities and permitted roles. Delegations bind the represented party, claims, powers, instrument, effective time, and expiry. Human tribunal members require appointment, signed acceptance, disclosures, covered claims, and current procedural authority.

Consent verification must connect the exact agreement bytes to the parties, covered claims, adopted rules, seat, and institution. The verification record must also establish representation authority where a representative acted. A supplied agreement digest identifies bytes for later checking. It does not establish that both parties accepted those bytes.

Institutional appointment requires the appointing body's decision, named tribunal members, claim scope, acceptance, disclosures, and appointment instrument. Registration in a directory provides discovery information. An appointment verifier must check the actual appointment and applicable conflict decisions before accepting a tribunal signature.

Legal effect depends on the applicable agreement, authority, procedure, and jurisdiction. The architecture records the evidence needed for those assessments. A software signature check establishes a cryptographic relationship under specified keys. The legal assessment must establish the signer's capacity and the effect of the signed act.

## Evidence contents and provenance

The service stores evidence references with a kind, description, expected case revision, authenticated submitter, and submission time. Available kinds include record extracts, agreements, submissions, expert reports, and service receipts. A separate upload operation verifies and stores exact artifact bytes. The evidence identifier and the custody identifier remain distinct records.

An artifact reference contains an explicit SHA-256 or BLAKE3 algorithm and a lowercase hexadecimal digest. Its media type accompanies the digest. A verifier must retain the algorithm rather than infer it from the digest length. Distinct algorithms can produce equally long strings while expressing different commitments.

The evidence contract preserves original bytes and custody metadata. Signed actions bind referenced artifacts to their prior custody records. The case must also preserve provenance, verification results, and the applicable trust profile. Retrieval, digest matching, signature verification, authority verification, and admissibility decisions are separate operations. Failure at one stage must remain visible even if another stage succeeds.

For example, an expert report can match its submitted digest while its signature belongs to an unauthorized person. A correctly signed report can still fall outside the expert's appointment scope. Conversely, a disputed document can remain relevant as an allegation or exhibit. The case record must distinguish admitted evidence from material retained for review.

Document custody must record transfers, access decisions, and any derived representations. A translation or redacted copy needs its own digest and a reference to the source. A retrieval failure must preserve the reference and report the unavailable bytes. It cannot silently replace the source with a later copy.

The disclosure policy must identify which parties and reviewers can access each artifact. A hash alone does not provide confidentiality, and a case event may itself disclose sensitive allegations. The current access model checks claim scope, while network transfers require signatures over the exact disclosed material. Recognition currently discloses a complete source case and its artifact custody. Cases requiring sealed deliberations or selective outcome disclosure need a supported disclosure profile before transfer.

## Service and time

Service establishes delivery under the applicable procedure. A signed service record binds the document, recipient, delivery method, evidence, and relevant times. A competent institution or tribunal then records the finding that makes delivery effective for protocol deadlines. The service must retain failed delivery attempts and disputed acknowledgements.

Deadline computation must preserve its triggering event, rules, calendar, time zone, and calculation. A UTC recording time identifies when the service stored a record. It cannot by itself establish when a recipient received notice or when a legal period started.

Uncertain service affects subsequent procedure. The institution must resolve the uncertainty or record a supported procedural decision before advancing an affected claim. A timer firing successfully proves that software observed a configured time. It does not prove effective service or expiration of a legally applicable challenge period.

## Local persistence and replay

The implemented service begins each case at revision one with a `case_filed` event. Evidence submission increments the revision and adds an `evidence_submitted` event. SQLite commits the snapshot, event, and successful response record together. The database obtains its writer lock before replay and revision checks.

The mutation identity is the tuple of tenant, authenticated actor, method and resource path, and idempotency key. The key accepts one to one hundred twenty-eight visible ASCII characters. The stored request digest uses SHA-256 over serialization of the parsed body. JSON spacing and object member order therefore do not create a different request.

A repeated identity with the same body returns the original successful response after current access checks. A different body produces an idempotency conflict. Replay lookup occurs before revision comparison, so an exact retry remains valid after later evidence changes. The caller retrieves the case separately when it needs the latest revision.

A fresh evidence request must state the current revision. Two requests cannot independently consume the same revision because the transaction acquires the SQLite writer first. A stale request receives a revision conflict. It must obtain the current record and reassess its intended change before using a new key.

Events have increasing revisions within a case. The event query uses an exclusive revision cursor and a bounded page size. Database triggers prohibit event update and deletion. These controls support local audit and polling. Signed protocol actions additionally bind the complete preceding protocol state. Their ordering remains local to the case.

The local configuration uses a write-ahead log and full synchronization. Durability still depends on SQLite, the operating system, and the storage device honoring their contracts. A successful local transaction establishes the recorded local mutation. Peer effects require their own authenticated acknowledgements and evidence.

# Procedure, outcomes, and stays

Resolution requires an adopted procedure for the affected claims. The case record must show the institution's authority, the parties' procedural rights, the evidence considered, and the decision-maker's reasons. A single case can require different treatment for separate heads of claim.

The current action contract implements record resolution, an expedited tribunal, and a full tribunal. Signed lifecycle actions record distinct determinations, awards, settlements, challenges, and stays. Their evaluator checks consent, jurisdiction, service, procedure, appointment, and signature requirements before returning a resource for atomic persistence.

## Selecting and adopting procedure

Record resolution addresses a question that the accepted record decides under the adopted rules. An expedited tribunal addresses matters eligible for a shorter adjudicative procedure. A full tribunal provides the procedure required by contested integrity, a hearing request, a party election, or other applicable conditions.

The implemented pure assessment function proposes a full tribunal when record integrity is contested, a hearing is requested, or a full tribunal is elected. For a legal or discretion question, it proposes an expedited tribunal only within the supplied aggregate ceiling condition. Otherwise, it proposes a full tribunal. If those conditions are absent, a decisive record produces a record-resolution proposal. The remaining input produces an expedited-tribunal proposal.

The function consumes assessment booleans. It does not establish their truth, calculate an institutional ceiling, or adopt a procedure. The institution must retain the supporting evidence, applicable rules, aggregate calculation, notices, objections, and adoption decision. A procedural proposal cannot serve as its own authority.

Pleadings identify the positions and relief that each party advances. The procedure must bind submissions to their authorized representatives and admitted claim scope. Amendments require an explicit record of the changed allegation or relief. Existing evidence and earlier positions must remain available for review.

A hearing record must identify its participants, scope, admitted submissions, and relevant procedural decisions. Transcript access and the treatment of deliberations follow the applicable disclosure policy. Automated record comparison can assist the tribunal. Any issue that requires judgment remains assigned to the authorized decision-maker.

## A case with several heads

Consider an illustrative dispute between a seller and a buyer. The seller alleges an ownership-record error, unpaid consideration of USD 120,000, and an incorrect event outcome affecting a financial claim. These are hypothetical facts used to explain the contract.

| Head | Subject and requested relief | Procedural question |
|---|---|---|
| Ownership record | A named Mass entity and a proposed record correction | Does the accepted signed record establish the requested ownership entry? |
| Unpaid consideration | A named payment obligation and USD 120,000 | What amount is due, and does a valid defense affect payment? |
| Event outcome | A Moxie event and affected financial claim | Which facts and authority profile can support a native outcome proposal? |

The filing preserves all three heads and their distinct identifiers. A corridor relevant to the ownership head belongs in that head's subjects. A corridor mentioned only in case context cannot automatically become the payment target. The Moxie event retains its chain context even if the same parties appear in the Mass records.

Suppose the parties accept the signed ownership record but dispute whether a delivery condition satisfied the payment obligation. The institution may assess the ownership question for record resolution under its rules. The payment issue requires the eligible tribunal procedure. A hearing request or contested record integrity changes the proposal accordingly.

The institution must calculate any aggregate ceiling under its actual rules. Splitting one economic dispute into several heads cannot silently reduce the amount used for that calculation. The filing amount field supports a nonnegative decimal string and a syntactically valid currency code. It performs no exchange-rate conversion or institutional aggregation.

The event-outcome head adds a destination constraint. Even a valid award must map into the authority and certificate requirements accepted by Moxie. The case can reach a supported legal outcome while its requested native effect remains unavailable. The record must expose that remaining obligation.

## Determinations, awards, and settlements

A determination records covered claims, the record considered, reasons, agreement, service receipts, and a challenge deadline. Its legal consequences depend on the adopted procedure. The service must preserve that type when later steps occur. A change of label cannot convert a determination into an award.

An award record identifies the exact signed instrument, tribunal appointment, signatures, verification profile, seat, issue time, and finality material. The configured verifier must connect each signature to the appointed human and the signed scope. It must also check relevant appointment validity, conflicts decisions, service, challenges, supersession, and stays.

A settlement record identifies covered claims, the signed agreement, and verified party consent. Each permitted effect requires its own scope and destination mapping. If an agreement settles only the payment head, the record must leave the ownership and event-outcome heads distinct.

The current outcome action supplies a unique identity and the exact signed outcome. Its protocol resource retains the action request, signatures, derived verified signers, recording time, revision, and rules snapshot. The evaluator checks the required institution, human tribunal quorum, or distinct party signatures before admission.

The outcome signature binds the document, reasons, claims, obligations, procedure, and selected evidence records in their explicit order. The evidence digest covers identifiers, submitters, times, revisions, kinds, descriptions, and artifact references. Historical verification retains its original profile and authenticated bytes. Current reliance must evaluate subsequent revocation, challenge, and compromise information separately.

A transport representation can carry the outcome as a credential or another structured document. Its representation must preserve the signed instrument and authority evidence. Credential serialization alone establishes neither tribunal appointment nor destination acceptance. Each consumer must verify the evidence required for its intended reliance.

## Stays, challenges, and supersession

A stay restricts specified actions under an authorized order. The signed stay action binds covered heads, order bytes, authority, scope, disposition, effective time, optional expiry, and its predecessor. Dispositions distinguish imposing, varying, and lifting a restriction.

A variation or lifting record must reference an existing order within the same scope. The active restriction derives from verified orders and their applicable times. An administrator cannot lift a stay by replacing a status field. The service must retain the earlier order and subsequent decisions.

Before dispatch, the execution service must check the latest case revision and effective restrictions for the requested heads. An unresolved order, contested authority, or uncertain timing blocks the affected request pending review. Unaffected heads can proceed only when their independence is established under the applicable decision.

A later stay cannot erase an effect already completed at its destination. The record must preserve submission, acceptance, completion, and order timing. Any remedial transfer or correction requires its own authority and destination operation. The remedy must not overwrite the completed effect's evidence.

# Execution, finality, and recovery

An outcome can require a record correction, custody instruction, asset transfer, payment, or native event proposal. Each effect needs a destination that supports it and authority that the destination accepts. Recourse must preserve the difference between the outcome, requested instruction, delivery attempt, acceptance, finality, and recovered asset.

The current execution module implements a durable outbox, bounded dispatch, independently checked effect observations, and signed recovery reconciliation. It accepts exact voluntary transfer instructions under configured custody or native transfer profiles. Native award enforcement and general institutional transfer remain separate integration requirements. The service holds no party, tribunal, or transaction signing key.

## Binding the requested effect

An execution intent must identify its case, verified outcome, covered heads, destination profile, native target, action, instruction, authority, policy, expected revision, and expiry. The destination profile resolves through trusted operator configuration. It must bind the endpoint, peer identity, network context, protocol, trusted keys, and proof requirements.

Target contracts distinguish a Mass zone and operation, a Moxie chain and event with legal-policy roots, and a custodian with account and mandate references. A generic asset identifier supplies insufficient account or mandate scope for a custody instruction. Each target must resolve to the exact effect that the outcome permits.

The conceptual admission condition is:

$$
\operatorname{Dispatchable}(i,r,t)=
V(i)\land A(i)\land S(i)\land D(i)
\land R(i,r)\land T(i,t)\land U(i).
$$

Here, $V$ means verified outcome scope, and $A$ means accepted execution authority. $S$ means that applicable stays permit the action. $D$ means the destination supports the exact action and profile. $R$ checks the required case revision, while $T$ checks expiry. $U$ requires reconciliation of prior delivery uncertainty and prior effects. This predicate states required controls, not a proven implementation theorem.

An unsupported action must fail before dispatch. A record-correction instruction must not become a generic dispute-state transition. A payment instruction must identify the intended beneficiary, currency, amount, and account scope. An action name grants no authority by itself.

## Native peer projections

The current Mass filing projection selects one head and an explicit target zone. It preserves party details, the head identifier, decimal money, institution, and filing digest. It requires a SHA-256 filing digest and rejects incompatible destination field limits. Corridor selection uses the selected head's subjects and rejects ambiguity within that zone.

The destination filing schema has no separate agreement, arbitration-seat, or complete subject-reference fields. Recourse must retain them and bind the returned dispute to the selected head. The projection maps governing law into the destination jurisdiction field. A future adapter must verify that the value is an accepted jurisdiction identifier.

A projected request is a pure transformation. It sends no HTTP request and creates no peer acknowledgement. An eventual Mass write adapter must supply destination authentication, contract version, stable idempotency identity, and client-intent correlation. The adapter must preserve the submitted artifact digest separately from the destination's signed commitment.

Current Moxie helpers construct receipt and finalized-block-proof queries. Native 32-byte identifiers, chain identity, BLAKE3 commitments, canonical transaction bytes, signature domains, and numeric encodings must survive the boundary. Recourse monetary strings express human decimal units. They cannot be passed directly as raw fixed-point amounts without an explicit, checked conversion.

General Recourse award execution remains unsupported at the inspected Moxie certificate boundary. A native event outcome requires its accepted authority certificate. Retired event-resolution submission cannot bypass that requirement. An institutional outcome adapter needs an agreed certificate and policy mapping before dispatch can become available.

## Durable delivery and uncertainty

The execution module commits an authorized intent, exact instruction bytes, case revision, event, replay response, and outbox entry in one local transaction. An *outbox* is the durable queue that records pending destination submissions. Its entry must survive a process restart before any network request occurs.

Each attempt must preserve the destination request identity, exact request digest, profile, attempt time, and response or uncertainty. Retries must retain the same economic meaning and peer deduplication identity. The worker must recheck authority and stays when it claims the entry. Material case or profile changes require reassessment before submission.

A network timeout can occur after a destination accepted the request. The service must record uncertainty and reconcile through the destination's authenticated status or receipt interface. Creating a new economic request merely because the first response was lost can duplicate the effect.

Local idempotency cannot establish exactly-once execution across independent systems. The destination has its own deduplication namespace and retention policy. The adapter must retain the local-to-peer mapping and determine whether a retry remains covered. Unknown history or expired deduplication requires explicit reconciliation before another economic effect.

Terminal rejection requires a recorded refusal and reason. A worker must not convert rejection into a fresh intent without a new authorized decision. If a destination accepted an instruction before a later stay, the case must retain both facts and their timing.

## Acceptance and native finality

Execution and recovery observations must distinguish the following evidence:

| Observation | Required binding | Meaning |
|---|---|---|
| Blocked or declined | Intent and supported reason | A control or destination prevents the requested action. |
| Submitted | Exact request and native operation identifier | The request entered a delivery path. |
| Accepted | Authenticated acknowledgement and request identity | The peer accepted the identified request. |
| Finalized | Native proof, trusted profile, and expected effect | The specified effect satisfies that proof profile. |
| Recovered | Independent recovery evidence and reconciled effect | The recorded asset or amount reached the specified recovery state. |

A Mass proof consumer must check the expected zone, signature, required admissibility class, and commitment to the relied-on effect. Transport response fields require reconciliation with signed commitments and authenticated audit data. A successful dispute transition to an enforcement state does not alone prove payment or asset movement.

A native authority-register operation can change authority and retain audit evidence while leaving economic recovery unproved. Recourse requires a destination-accepted carrier for its outcome, obligation, exact target action, and current action authority. The accepted result must expose the signed claim preimage, proof profile, trust context, and actual allocation or effect identifiers.

Moxie finality verification requires a native finalized-block proof, an independently trusted historical committee, the expected block coordinates, and the applicable reliance profile. Receipt inclusion must bind the exact receipt and its effect. A response cannot establish trust by supplying its own committee or policy as an authority.

Advisory settlement envelopes must remain distinct from authenticated finality evidence. A self-consistent envelope hash is insufficient when the signed block commitment does not bind that envelope. Native consensus finality also leaves any off-chain delivery obligation to the corresponding custodian or recovery process.

![Evidence progression for an execution or recovery instruction. Each acknowledgement has its own meaning; uncertainty preserves the last established state.](manuscript/figures/required-effect-evidence.png){width=6.5in}

## Duties, exposure, and reservations

A duty retains its issuer's authoritative namespace, constituting act, and occurrence index. A new administrator, template, or representation must preserve that identity. The economic journal must retain each duty's portions, beneficiary, debtor, asset, unit, condition, priority, and disposition. Changes to rights require their own authorized acts.

An outstanding amount alone cannot determine safe dispatch capacity. A previous instruction can remain capable of delivering value after a timeout or administrator change. Let $D$ denote the outstanding amount, $P$ completed performance awaiting attribution, and $u_j$ each live command's possible additional performance. New exposure must respect

$$
\operatorname{NewExposure}\leq
\max\left(0,D-P-\sum_j u_j\right).
$$

These quantities must use one allocation model. Overlapping bounds cannot become independent sources of capacity. Duty-portion reservations prevent two instructions from satisfying the same portion. Cash reservations secure the possible expenditure of a command. The service must preserve both reservations under their original identities.

An escrow instruction requires evidence of the actual hold, its owner, beneficiary scope, release policy, and accepted custodian authority. A case filing cannot create a hold by assertion. A verified ruling can supply one required release condition, while the custodian still applies its mandate and current restrictions.

Late performance reduces the original command's residual exposure. Closing that command at its actual credited amount leaves any unpaid duty outstanding. Protected client property must retain its ownership and restrictions during reconciliation or transfer. It cannot become an administrator's continuity reserve.

## Recovery after an uncertain payment

Continue the illustrative payment head. Assume a verified outcome and accepted mandate authorize a USD 120,000 payment through a configured custody adapter. The outbox worker submits the instruction, but the connection closes before it receives the response. The case now has a delivery attempt with an unknown outcome.

The operator retains the same request identity and obtains authenticated reconciliation evidence from the custodian. An authenticated acknowledgement confirms acceptance. That acknowledgement permits an accepted observation, while the expected beneficiary credit remains unresolved. The service must continue reconciliation rather than classify the case as recovered.

Suppose the custodian later confirms a USD 70,000 beneficiary credit and a held remainder. Recovery records must identify the credit, beneficiary, asset, time, and related instruction. The outstanding amount is USD 50,000 under these illustrative assumptions. Fees, currency conversion, offsets, or alternative discharge require explicit terms and separate evidence.

A stay then restricts further payment. The service records the completed credit and blocks the unresolved remainder under the verified order. It neither deletes the credit nor describes the whole award as recovered. A later lifting order can authorize reconsideration of the remaining obligation after current destination reconciliation.

## Preserving unfinished computation

A case can await an authorized answer, provider evidence, or an observation that determines a later payment. A *continuation* contains the remaining computation and the state needed to resume it. Closing an administrator's case list cannot discharge that pending work.

A durable continuation must bind the checked program and dependency profile, host identity, instance name, creation nonce, request ordinal, and remaining logical work. It must retain the control term, captured environment, continuation frames, signed history, admitted effects, and exact pending request. A request description alone omits the executable state.

The receiving runtime must restore checked continuation objects directly. It must recheck the program and resolve stored references without executing again from the program root. Captured functions retain their checked bodies and environments. Dependent values retain the shape required by earlier accepted values. Historical request order and effect history must remain complete.

Before committing a suspension, the service must apply the receiving decoder and require an exact round trip of the stored state and reconstructed request. A structurally valid decoding still needs authenticated provenance from an admitted execution. The durable record must authenticate instance identity, program profile, revision, complete state, and command receipts.

Current authority governs a new reply. The host must serialize its authority revision, reply consumption, resulting continuation, and command receipt in one atomic commit. Historical signature validity remains evidence of the earlier act. It cannot authorize a new use after revocation.

An invalid signature, value, scope, or effect must preserve the pending request and logical work. Failed-command records remain distinct from consumed replies. An exact command retry returns its committed receipt before runtime invocation, including after later commands. The historical receipt identifies its revision and does not replace the current state.

A local reference construction implements direct checked-state restoration, decoder checks, authenticated persistence, and serialized authority consumption for a bounded language fragment. That source evidence supports the specified mechanisms. It establishes neither production Recourse acceptance nor complete refinement from the mathematical model to a deployed implementation.

## Transferring custody of live work

Transfer requires a complete account from every relevant authoritative namespace. Define the continuation cut as

$$
C=(\mathcal N,V,M,J,R,O,G,E).
$$

Here, $\mathcal N$ identifies the namespaces and $V$ their authenticated complete prefixes. $M$ contains live machines, while $J$ contains the economic journal. $R$ records funded resources and reservations, and $O$ retains undelivered messages with their original identities. $G$ records authority for future actions. $E$ retains evidence, disclosure duties, and routes for subsequent notices.

The cut must include case administration, prepared decisions, external commands, claim evaluations, duties, deposits, and continuing disclosure obligations where relevant. Each source establishes the completeness of its contribution. An empty local list supplies no evidence that another namespace has no outstanding work.

A completed evaluation can create a duty whose delivery remains unacknowledged. The outbox must retain that message under its original delivery identity until the destination acknowledges it. Succession must neither discard the message nor regenerate the duty under a new identity. Physical occurrences likewise retain their identities across custodians.

The predecessor must fence new initiation at an identified execution generation. A *fence* rejects actions from an earlier generation at the actual execution boundary. Existing commands remain observable and reserved because a local fence cannot recall a provider instruction already sent.

The successor must receive the complete cut, establish decoder compatibility, and accept custody under current authority. It must also establish funding and custody for each retained resource. A final compare-and-swap must check current source revisions and the exact cut. Every admitted change during preparation must enter that cut before activation.

One durable ownership transition must activate exactly one successor and prevent the predecessor from initiating further work. Each later action checks both the current execution generation and its own authority. Custody grants no additional adjudicative, payment, or provider permission. Transfer and replay must preserve duties, reservations, pending messages, and execution evidence without dispatching or discharging anything.

A single serialized coordination domain can implement the ownership transition atomically. Independent institutions require an agreement and protocol that make their fences effective. Copying valid records into two active stores does not establish exclusive custody. An unavailable decoder leaves the machine with an identified continuing custodian or a recorded transfer obstruction.

Authenticated state also requires freshness. A current-state commitment detects an old record substituted into a newer committed set. Restoring the complete coherent set can evade that check unless a monotonic anchor exists outside the rollback domain. Production acceptance therefore requires an external freshness anchor or an equivalent storage premise, effective fencing, secure identity, and bounded resource admission.

Institutional transfer remains conditional on actual authority, custody, provider controls, and the applicable legal arrangements. The reference construction supplies local evidence for a restricted computation and persistence model. Its checks do not establish distributed institutional transfer, provider performance, or a machine-checked proof of the full construction.

## Evidence needed to enable execution

Resolution acceptance requires execution through authenticated APIs and durable storage. Retained local checks exercise signed proceedings, custody, two-deployment exchange, process restart, dispatch uncertainty, and synthetic recovery. This manuscript review inspected those records without rerunning the checks. The tests must challenge forged roles, mismatched claim scope, invalid appointment evidence, stale revisions, active stays, and caller-selected trust sources. Artifact retrieval and signature tests must bind the actual bytes and configured profile.

Dispatch verification must cover crashes around local commit and network submission, duplicate attempts, lost responses, peer rejection, and unavailable history. Tests must check the resulting destination effect and retained causal identifiers. A passing local replay test cannot establish peer deduplication or financial completion.

Recovery verification must reconcile the expected effect against independent destination evidence. Partial amounts, wrong beneficiaries, contradictory receipts, later stays, and duplicate observations require explicit outcomes. The case can close a procedural issue while recording an unresolved recovery obligation. Its final record must state which claims, effects, and amounts the evidence actually resolves.
