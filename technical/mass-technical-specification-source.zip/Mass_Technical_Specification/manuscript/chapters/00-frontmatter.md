# About this specification {.unnumbered}

Momentum builds the network. Mass runs companies, institutions, and deployments. Moxie prices and clears claims. Recourse runs dispute resolution and carries outcomes into execution.

Mass is the AI-native operating system for programmable organizations. It connects formation, ownership, governance, treasury, identity, consent, and continuing compliance. Its purpose is to make regulated operations executable under explicit authority, with records that explain what happened and why.

The product objective is autonomous operation with lower operating cost and fewer manual handoffs. Sovereign deployments apply the same architecture under their own rules and recognized authorities. These objectives require complete operating procedures, competent institutions, and verified provider integrations. This specification does not convert a product objective into measured savings or a deployment guarantee.

Mass governs organizational action and the claims that organizations originate. Moxie prices, clears, and settles claims under admitted financial and institutional constraints. Recourse administers dispute procedures and carries authorized outcomes toward execution. Each system retains its own authority, state, and evidence requirements.

This book specifies the systems individually and at their boundaries. It develops the required architecture from organizational duties, authored intent, authority, state transitions, evidence, and economic effects. It also records the current implementation boundaries that a complete realization must close.

## Reading the claims

Four kinds of statement have different force throughout the book.

| Statement | Meaning |
|---|---|
| Requirement | A condition that a conforming implementation must satisfy. It can exceed current functionality. |
| Source implementation | Behavior supported by inspected implementation paths. It does not establish deployment or successful execution in a particular environment. |
| Formal result | A mathematical result under stated hypotheses and within the defined model or formal fragment. |
| Execution observation | A result from an identified running system, with the configuration, actors, inputs, and durable effects needed to support it. |

The word **must** states a requirement. An **implementation boundary** names current functionality, incomplete integration, or an unresolved realization obligation. An illustrative trace explains a contract. It is not a report of a completed transaction.

Source inspection for this edition began on 6 September 2026. Implementations evolve independently. A later deployment must identify its own software, dependencies, rules, credentials, and evidence before claiming conformance. A compiled interface, registered operation, or passing model check cannot establish the completion of a business process.

## Scope and organization

The opening chapters define organizations, identities, governance, and delegated action. Cryptographic chapters establish byte identity, signatures, evidence, storage, and threat assumptions. The rule and language chapters define compliance composition, legal discretion, execution programs, and pack configuration.

The execution chapters specify transactional writes, durable workflows, smart assets, observation, and corridors. The Moxie chapters develop claims, custody, settlement, consensus, and reliance. The Recourse chapters develop case authority, procedure, outcomes, stays, continuation, and recovery. The final chapters provide developer, operator, and conformance references.

The systems share typed contracts rather than a universal transaction. A financial or legal effect belongs to the authority that can make it effective. The integration contract must preserve the identity of that effect across requests, local records, external acknowledgements, and recovery.

## Edition and use

This public reading edition presents the design and implementation boundaries reviewed on 6 September 2026. Descriptions of retained implementation sources and verification records are dated observations. Those records are not included, and publication does not establish deployed conformance.

The document is a technical specification. Legal rules enter through identified instruments, recognized authorities, and applicable procedures. A software verdict records the outcome of a defined evaluation. Its legal effect depends on those sources and the authority of the evaluating institution.
