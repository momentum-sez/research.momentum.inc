# Program admission and durable execution

An executable request carries an intended change, authority to request it, and evidence that permits the change. These objects have different lifetimes. Authority can expire while a workflow waits. A provider can accept a request before Mass receives its response. A committed change can precede its searchable evidence. The execution model must preserve these distinctions through failure and recovery.

This part specifies the required behavior and identifies the corresponding implementation mechanisms. Statements using **must** define requirements. Statements about the current implementation describe inspected source behavior. The worked example is an illustrative trace, not a report of an executed transaction. Deployment acceptance requires execution evidence for the selected routes, providers, configuration, and authority.

## Intent, admission, and effect

An **intent** identifies the change that a principal requests. It includes the governed subject, semantic operation, authored values, applicable jurisdiction, and replay identity. A **program** expresses the work required for that intent. An **admission decision** establishes that a particular program may enter a specified execution path under particular authority and rules.

An **effect** is an observable change outside the evaluator's temporary state. Examples include a stored organization record, a reserved balance, an accepted filing, and a delivered notification. Evaluation can produce a proposed effect without producing the effect itself. A provider request can also produce an effect before the caller receives an acknowledgment.

A **receipt** records a defined event or outcome. Its subject determines its meaning. A receipt for accepted work establishes acceptance. A receipt for a committed mutation establishes that mutation. A receipt for an operation's creation establishes the existence of the operation. Completion requires the operation's specified effects and acknowledgments.

For an intent $i$, let $E(i)$ be its required effects and $A(i)$ its required acknowledgments. Define completion by the contract:

$$
\operatorname{Complete}(i)
\iff
\left(\forall e\in E(i),\;\operatorname{Established}(e)\right)
\land
\left(\forall a\in A(i),\;\operatorname{Verified}(a)\right).
$$

The contract must specify what establishes each effect. A local insert can require a committed database record. A registry filing can require the registry's accepted response. A signing step can require a verified signature over the exact document. An emitted request alone satisfies none of these stronger conditions.

This definition permits intermediate proofs. An operation can carry a valid proof of creation while it waits for a signature. A client must interpret the proof subject and operation state together. A signed intermediate proof must not acquire a broader completion meaning through its presentation.

## Admission of an authored program

MassProgram is the authored envelope for program admission. Its bindings identify the program, entity, jurisdiction, semantic family, capability, evidence obligations, resource limit, signer, nonce, and validity period. The evaluator must recompute the payload identity using the selected encoding. It must compare that identity with the value covered by the author's signature.

The admitted intent must also distinguish one-shot from repeatable execution and bind the permitted multiplicity. A new command identifier cannot multiply one-shot authority. Repeatable work needs explicit occurrence and aggregate-use rules, with shared limits enforced across its commands.

MassBiscuit supplies attenuated authority. Admission must verify the capability chain and its current revocation state. It must establish that the presented capability matches the binding signed into the program. It must then evaluate the effective restrictions against the program's subject, operation family, jurisdiction, and time.

Cryptographic validity and authority have separate meanings. A signature can remain historically valid after its grant expires. A valid capability chain can authorize a different subject or operation. Admission must test the actual requested action against the effective grant. It must retain the authority version used for that decision.

The current program path performs capability verification, revocation checking, binding comparison, program admission, and signer binding. It derives caller identity from verified authority. It also creates a zone-signed verdict before the internal proposal path. The HTTP submission path distinguishes authority to submit a program from authority for its semantic operation.

Lex certificates and verdict bindings serve different purposes. A structural certificate can establish a property of the program under a rule. A commit verdict connects the actual action to the authority and evidence required at commitment. A submission path that requires a verdict must reject a structural certificate offered as its replacement.

Admission must fail explicitly when its required producer is unavailable. The current authoring endpoint validates an envelope and then refuses it because durable authoring storage is not implemented. The executable submission endpoint is separate. This separation prevents successful validation from masquerading as durable acceptance.

## Execution paths and their result contracts

The current executable submission path supports an operation reference and an Op program. An operation reference binds the operation type and its parameters. Submission admits that reference and enqueues work through the shared operation-creation path. Its immediate proof concerns creation of the operation. The returned operation identifier supports subsequent inspection.

The Op path typechecks and compiles the submitted program. Supported effects can lower into an allowlisted write plan. The write plan must retain the subject, authored values, evidence, and authority established by admission. Lowering must not broaden the admitted action or substitute a privileged transport identity for missing authority.

The internal proposal entry point also accepts a capability and program. Its current implementation admits the program and proposes a program-submission transition. That transition establishes the admitted submission event. Execution claims must follow the selected lowering and its actual effect producers.

The following result classes remain distinct throughout the API and client surfaces.

| Result | Established fact | Further evidence for completion |
|---|---|---|
| Compile or simulation result | Evaluation under the supplied inputs | An authorized execution and its effects |
| Program admission | The envelope passed the selected admission checks | Durable acceptance and execution |
| Operation creation proof | The operation was created | Required steps and acknowledgments |
| Mutation proof | The named mutation committed | Other effects required by the intent |
| Terminal operation record | The workflow reached its recorded terminal state | Contract effects consistent with that state |

An implementation must document each transaction boundary between these results. The current write-plan submission lane commits its lower-level plan before a later proposal for the program transition. An error from the later proposal can follow committed effects. A retry must inspect the earlier commitment through its replay identity.

A separately inspected implementation candidate adds a journal-backed completion path restricted to authored `CreateTarget` declarations for a current open native account. It retains the command, journal receipt, commit witness, and proof with the audit and outbox in one transaction. Current program admission and evaluation precede journal replay. Exact admitted retries recover the original journal result without another completion event; they do not provide historical retrieval after execution authority is revoked. This candidate remains separate from the source baseline described above. Provider funding, payment, return, and closure admission remain outstanding.

## Resource limits and delayed authority

Admission must bound the resources that a program can consume. The bound must identify its unit and enforcement point. Instruction gas, data-dependent work, elapsed time, provider charges, and reserved cash are different resources. A gas estimate must not imply that a provider has accepted a charge or reserved funds.

Scheduled work requires admission at creation and authority checks at execution. The current scheduler stores scheduled programs, claims due work, verifies authority at firing, and applies bounded retries. A stored program must not retain permission solely because its authority was valid when scheduled.

A failed scheduler-state update can leave a program in its firing state after work has run. The current scheduler requires operator intervention for some such cases. Recovery must inspect the committed outcome before re-arming the program.

The same rule applies after a human review or provider wait. Resumption must validate current authority for the next effect. It must preserve the original intent and completed effects. Changed inputs or broadened authority require a new admitted action with an explicit relation to the earlier request.

## Execution evidence

An execution claim must identify the program or operation definition, source version, configuration, principal, subject, intent, and causal identifiers. These bindings let a reviewer distinguish the claimed execution from a similar test or another deployment. Static registration establishes discoverability, not execution.

Acceptance must exercise the claimed boundary. A local transaction test can establish rollback behavior for that transaction. It cannot establish a provider's idempotency or a registrar's acceptance. A workflow test must inspect its terminal record and the contract-derived effects. It must also distinguish automatic recovery from an operator's manual repair.

# Mutation transactions and evidence delivery

Mass owns its durable business writes. Native domain services implement business rules and use owning persistence interfaces. The mutation firewall supplies the common authority, compliance, and evidence obligations around those writes. The transaction boundary determines which records become durable together.

## The mutation contract

A **mutation contract** declares the subject, action, required authority, evidence, durability, and permitted transition for a write. It also classifies irreversibility. The contract must identify a governed subject independently of a display label or transport path. A caller must not gain access by substituting an identifier from another entity.

The firewall must enforce current capability restrictions, entity scope, required role or delegated authority, and applicable halt controls. A contract that requires a signed verdict must reject a write without the required verdict. Sanctions rejection is terminal for the attempted action. A later recovery step must not reinterpret that rejection as permission.

The current firewall family includes legacy finalization, verdict-aware finalization, atomic business-write helpers, and validated write plans. Daemon-origin writes carry fencing information. Signed-contract, halt, delegation, and capability checks appear at their relevant entry points. Primitive services invoke this family through the supplied firewall interface.

This arrangement permits shared enforcement without moving business logic into a universal route handler. A domain service determines the valid business change. Its persistence interface owns the affected records. The composition layer supplies the transaction and enforcement dependencies. Verification must inspect this full call path.

### The verdict admitted at commitment

`VerifiedVerdict` is the evaluated verdict object admitted at the mutation boundary. It is distinct from the `MassProof` envelope used to transport or resolve evidence about a result. The verdict's field ledger separates evidence, attestation, authorization, composition, autonomy, cost, model identity, and Byzantine agreement. Each group carries the material and unresolved target requirements relevant to its responsibility.

The inspected commit-admissibility predicate rejects an unsigned projection, any remaining target residual in those groups, and commit-critical zero digests. The critical fields include lawpack and regpack identities, the issuing model commitment, and a filed obligation witness's proof digest. For a contract marked `must_be_signed`, the verdict-aware finalizer refuses a missing verdict, a projection-only verdict, or a verdict that fails this predicate. Other contract classes have different declared requirements and must not inherit a stronger claim from this lane.

This predicate checks structural admission conditions. It does not by itself verify every cryptographic signature, establish the truth of evidence, or grant sanctions permission. The calling path must authenticate the actual verdict and enforce the independent authority and sanctions requirements. A filled field ledger is therefore necessary where this contract requires it, but cannot substitute for the rest of admission.

## Co-commitment of business state and evidence

Let $B$ denote the business records changed by one atomic write. Let $J$ denote its audit record, $O$ its required outbox records, and $P$ its stored proof. For the atomic write lane, the required commitment is:

$$
\operatorname{commit}(B,J,O,P)
\quad\text{or}\quad
\operatorname{rollback}(B,J,O,P).
$$

The application must use the same database transaction for these records. A successful audit transaction beside a failed business transaction does not satisfy this requirement. Two successful transactions separated by a crash window also do not satisfy it.

The current atomic lanes support raw SQL and SeaORM transactions. The SeaORM lane borrows the configured database pool, begins a transaction, and runs the business closure. It appends the audit, observation, corpus, and proof records through that same transaction. It commits before invoking downstream fan-out.

An outbox stores a durable obligation to deliver information after commitment. Its insertion must fail the atomic write when that delivery record is required. The current atomic append helpers propagate required observation and corpus-outbox failures. They do not convert these failures into successful business writes.

The scope of this invariant is one selected transaction. A multi-step workflow can contain many such transactions. A provider can maintain its own transaction outside Mass. A complete execution trace must identify each boundary and the durable relationship between boundaries.

![Required local co-commitment and subsequent delivery. The known ordering exceptions described in the foundations do not satisfy this contract.](manuscript/figures/atomic-commit-and-delivery.png){width=6.5in}

## Delayed evidence and reconciliation

Some evidence derives from an already committed mutation. The current event-store append occurs in post-commit fan-out. A failure there can leave a committed business change with a delayed event record. The runtime records the gap, and a reconciliation daemon can reconstruct missing events from matching audit and outbox evidence.

The audit record and event record therefore have different roles. The former participates in the selected mutation transaction. The latter supports downstream history and correlation. A consumer must tolerate a temporary delay without inferring that the business change disappeared.

Reconciliation must preserve the causal identity of the original mutation. It must match the subject, event, action, request, and relevant time bounds. A repair must not append a new genesis entry merely because a chain-head read failed. A duplicate repair must converge on the same event rather than create a second history.

The current reconciliation mechanism also links organizational state events with mutation events. Its operation depends on the configured repair lag and search window. A missing event beyond the inspected window remains an unresolved obligation. The existence of a daemon does not establish that every historical gap has been repaired.

Observation delivery has its own outcomes. The current corpus delivery daemon records successful delivery, schedules retries, and moves exhausted or rejected work into dead-letter storage. A dead letter is durable evidence of incomplete delivery. It requires an authorized repair or replay procedure before the delivery obligation can close.

## Ordering and replay

Per-chain sequence, database commitment order, hybrid logical time, and external event time describe different orders. A hybrid logical clock combines physical time with logical advancement. It can support causal reasoning while replicas have different physical clocks. It does not by itself establish a universal strict order over all writers.

The current observation code tolerates bounded clock skew across replicas and rejects larger regressions under its normal enforcement mode. Its per-process sequence ranges can overlap after restart or scale-out. A consumer must use the documented ordering relation rather than sort all records into an assumed global sequence.

Replay must preserve identities and original evidence. Reconstructing an event from an outbox is evidence repair. Reissuing the underlying payment or filing is a new external dispatch. The repair procedure must identify which of these actions it performs and must retain the original dispatch identity when redelivery is authorized.

## Idempotency and failure windows

An **idempotency key** identifies an exact admitted request within a defined scope. The associated record must bind the key to the request content and outcome. Reusing the key with different content must fail. Repeating the same request must return the committed result or report that its outcome remains unresolved.

The current write-plan path stores an idempotency result within its transaction. Concurrent duplicate transactions converge on the committed winner. Duplicate effects from the losing transaction roll back. This establishes a local replay property for that path, subject to its request-binding contract.

Remote actions require a separate contract. Before dispatch, the runtime must persist the provider identity, exact request, authority, and replay key. After dispatch, it must persist the provider acknowledgment. A crash between these events requires provider lookup or an idempotent repeat. A new random key would turn recovery into a second action.

| Failure window | Durable knowledge | Required recovery |
|---|---|---|
| Before local commit | Transaction has no committed effect | Retry the admitted request |
| After commit, before response | Local effect may already exist | Resolve the stored replay outcome |
| After remote acceptance, before acknowledgment | External effect remains uncertain locally | Query or repeat with the original identity |
| After audit commit, before event fan-out | Mutation is durable, derived evidence is delayed | Reconcile evidence without repeating the mutation |

Runtime monitoring must expose these distinctions. Useful signals include old outbox entries, failed evidence repair, expired claims, repeated deterministic failures, and unresolved provider responses. A low HTTP error rate alone cannot establish successful execution or complete evidence delivery.

# Workflows, waiting, and compensation

A workflow connects effects whose prerequisites and completion times differ. The operation engine represents this work as a directed acyclic graph of steps. Each step has a defined action, dependencies, result, and failure policy. The persisted operation record holds the current execution state.

## Control and state

The current operation model has two execution modes. Execute mode allows the daemon to advance eligible steps. Plan mode requires explicit advancement. A direct primitive call uses the mutation path without an operation wrapper. It is not a third operation-mode value.

The operation lifecycle distinguishes creation, active work, waiting, success, failure, and compensation. Its current states are `Created`, `InProgress`, `Waiting`, `Completed`, `Failed`, `Compensating`, and `Compensated`. The completed, failed, and compensated states are terminal. A step has a separate state, including ready, executing, waiting, skipped, and compensated.

An operation can have a waiting step while its operation-level state still records work in progress. Scheduling and monitoring must therefore inspect relevant step states. A waiting step with a future deadline differs from a stranded executing step. They require different recovery actions.

The operation definition must specify what each dependency means. Completion of a document-generation step can permit a signing step. It cannot satisfy that signing step. A notification step can establish that a message was queued, accepted by a provider, or delivered. Its contract must select the required acknowledgment.

Step inputs must come from authored values, authenticated identity, or established predecessor results. The executor must reject missing required inputs. It must retain the definition used for an in-flight operation so a later catalog change cannot silently alter recovery.

## Work claims and fencing

A **work claim** gives a worker temporary responsibility for a persisted operation. A **fencing token** identifies the current execution generation. The current operation daemon uses database claims with leases. Expired claims allow recovery after a worker stops.

Lease expiry alone does not stop an old worker. A delayed worker can resume after another worker acquires the operation. The write boundary must therefore check a current fencing token or equivalent exclusive authority. A stale generation must fail before it produces another effect.

The worker must persist enough state before dispatch to distinguish ready work from work already sent. Recovery reads the database record, not the abandoned worker's memory. When an executing step exceeds its permitted interval, recovery must first resolve any external effect. It must not assume that elapsed time reversed that effect.

Notifications can accelerate execution, while periodic scans provide another opportunity to find eligible work. Neither mechanism replaces the persisted claim and transition checks. Duplicate wakeups must lead to one authorized transition. Missing wakeups must not permanently strand otherwise eligible work.

## Callback identity and acknowledgment

A callback is evidence delivered by another system or actor. Its envelope must bind the source, operation, subject, event type, event identity, and payload. The receiver must verify source authority and the relationship between the payload and waiting work. A caller-selected operation identifier is insufficient evidence of that relationship.

The current callback path compares immutable event content when an event identity already exists. An exact replay can follow the replay path. A changed payload under the same identity produces a conflict. This preserves the distinction between redelivery and a new assertion.

Callback storage, workflow advancement, and the HTTP response can have separate failure points. The current route can deliver an event successfully and then fail during follow-up advancement. The sender must retain the original event identity. A retry must resolve its stored disposition instead of creating another event.

Signing callbacks require exact document and signer bindings. A signature on a related document must not release the current wait. Grouped submissions require a verified membership relationship. A provider's successful transport response must not substitute for the required signature or completed signing session.

The target callback contract further separates a provider occurrence, its transport deliveries, and each admitted local effect. Changing a delivery timestamp or transport signature creates no additional occurrence. Admission freezes the effect plan. Each effect retains the identity `(occurrence, effect_plan_digest, ordinal)`. Subject-version checks remain admission conditions; revalidation after unrelated state changes must preserve that effect identity.

Consent and templating must share one signing submission for the exact document, signer set, and provider submission. Signature completion and custody of executed bytes are distinct states. A dependent step advances only after its required custody check. A durable custody job retries retrieval of the same executed bytes without regenerating the document or starting another signing submission. Its receipt binds object version, digest, storage profile, and the waiting step it releases. These are required recovery semantics, not a claim that the present callback path already implements every record.

## Retry and compensation

Retry repeats an action under a defined replay contract. Compensation performs another action intended to offset an established effect. Database rollback removes uncommitted local changes. These mechanisms have different authority requirements and different consequences.

The current operation model records retry counts, retry deadlines, and failure classifications. Deterministic failures can recur while their inputs or authority remain unchanged. Transient provider failures can justify bounded retries. Exhaustion must lead to an explicit failure or compensation policy, with diagnostics retained.

For a workflow graph $G$, compensation follows reverse dependency order over effects that actually occurred. Let $F$ be the established forward effects and $c_f$ the authorized compensation for effect $f$. A compensated outcome requires evidence for each applicable $c_f$, not merely a traversal of the reversed graph.

Even a successful compensation can leave history and costs. A refunded payment leaves its original payment and refund records. A withdrawn application can leave a registrar's record and a retained fee. An executed instrument can require a later amendment. The compensation contract must state the resulting business state rather than promise restoration of every prior fact.

The current compensation executor plans reverse topological actions and persists per-action outcomes. Its recovery daemon retains an attempt identity across retries. A downstream service must honor that identity for the repeated request to avoid duplicate effects. Exhausted attempts and missing operation definitions produce explicit failures for review.

An irreversible effect requires a specific recovery procedure. The runtime must retain the accepted external action, the failed dependent action, and the remaining obligation. It must not mark the operation compensated merely because reversible local steps completed. A responsible actor must receive the unresolved work with its supporting evidence.

## Durable checked continuations

A **continuation** is the execution state needed to resume suspended work. A **checked continuation** binds that state to the validated program and runtime profile that can interpret it. Its durable representation must carry control position, environment, frames, pending request, logical work, effects, and authenticated history.

The normative continuation contract requires direct restoration. The receiving runtime must restore the checked state without executing the program from its source entry point. Re-execution could repeat duty creation, consume resources again, or issue another provider request. A matching final value would not establish an equivalent execution history.

Before commitment, the receiver must round-trip the continuation through the exact decoder used for restoration. The restored object must preserve its program and profile bindings, instance identity, host binding, nonce, ordinal, and pending work. Successful serialization through a different utility is insufficient.

Current authority, consumption of pending work, resulting continuation, and command receipt must commit atomically under one serial order. An invalid admission must leave pending work unconsumed. An exact retry must return the committed command receipt without runtime re-execution. A changed request under an existing command identity must fail.

The host must authenticate the complete stored state and command receipts. A current-state commitment must bind instance heads and authority metadata. Each mutation must update its records and that commitment in the same transaction. An older authenticated record must fail against the current commitment.

This contract is stronger than a generic workflow checkpoint. A persisted step name does not capture a suspended evaluator's environment or pending effects. The current operation records and leases provide important recovery mechanisms. They do not, by their existence, establish conformance to this complete continuation contract.

## Duties and economic state during resumption

A **duty** identifies an obligation, its occurrence, and the portions still requiring performance. **Command exposure** is the remaining performance that a command can require. A **reservation** binds funded resources to a permitted future action. Resumption must preserve these objects under their original identities.

Duty identity binds the issuer's authoritative namespace, constituting act, and occurrence index. Changing the administrator, template, or rules version must not create another duty. The economic journal retains beneficiary, debtor, asset, unit, conditions, priority, amendments, and original command bindings. Reservations of duty portions and reservations of cash remain distinct.

Late performance can reduce residual command exposure. Closing a command does not discharge unpaid debt. A receipt for a closed command must therefore preserve the separate debt and performance records. Repeated delivery of the same duty-creation event must resolve to its original delivery identity.

Let $D$ be outstanding performance, $P$ completed performance awaiting attribution, and $u_j$ each live command's remaining possible performance. Additional command exposure must respect:

$$
\max\left(0,D-P-\sum_j u_j\right).
$$

These quantities must use a common allocation model. Overlapping bounds must not count as independent available capacity. A late provider credit reduces the original command's exposure and the corresponding reservation. It does not authorize another command for the earlier unpaid amount.

A durable continuation must carry the economic journal, funded resources, reservations, unacknowledged outbox work, and future-action authority. It must also identify the complete authoritative namespaces that these records cover. A partial export that omits a reservation could permit conflicting use of the same funds.

The continuation and duty requirements define the execution boundary shared with Recourse. The referenced local implementation work supports these design requirements. It does not establish production acceptance, provider execution, or distributed institutional transfer. Each production adapter must prove preservation of the required objects through its own receiving decoder and commitment path.

# Smart assets and the execution machine

A smart asset combines an identified asset with executable rules and recorded history. Its legal rights, registry bindings, and custody arrangements remain explicit. The Smart Asset Virtual Machine, or SAVM, evaluates bound programs. The host supplies authority, evidence, persistence, and external adapters.

## Asset identity and state

The current asset definition separates genesis, registry binding, manifest, receipt-chain reference, and lifecycle phase. It also carries compliance posture and an attestation portfolio. Genesis identifies the creator, creation jurisdiction, metadata digest, and creation time. Its canonical digest supplies a cross-zone identity distinct from a local database identifier.

The registry binding records the relevant jurisdiction, registry type, external reference, and binding credential digest. Before registration, that binding can be absent. The manifest declares capabilities, compliance domains, instrument configuration, triggers, and bound programs. A trigger must reference a program included in the binding set.

This structure permits explicit program changes. A new program binding must identify the old program, the new program, transition authority, and applicable state migration. The asset's identity must not silently change because its program changes. The current lifecycle API includes program upgrade, split, combine, and dissolution surfaces.

A split must preserve the relationship between the source asset and resulting assets. A combination must identify every consumed source and the resulting asset. Conservation requirements depend on the instrument's unit and contract. Receipt creation alone cannot prove conservation without the relevant quantities and accepted transitions.

## Lifecycle and compliance

The typed asset lifecycle includes genesis, registered, active, migrating, suspended, frozen, settled, and dissolved states. The current model treats frozen, settled, and dissolved as terminal within that lifecycle. A sanctions freeze is distinct from a temporary suspension. Ordinary resumption must not clear a terminal sanctions decision.

Economic events such as issuance, transfer, distribution, maturity, default, and recovery occur within instrument-specific procedures. They must bind the legal actor, affected right, quantity, evidence, and resulting state. The generic lifecycle enum does not establish that every such procedure is implemented for every asset class.

An asset program may impose additional restrictions or require more evidence. It must not override the runtime's mandatory authority or sanctions gates. A locally computed compliant value does not authorize an otherwise prohibited write. The host rechecks the applicable commitment requirements at the effect boundary.

Compliance posture records a decision under particular evidence and rules. It must retain its evaluation identity and time. A changed rule, revoked credential, or changed beneficial owner can require another evaluation. The old posture remains historical evidence of its earlier assessment.

## VM evaluation and limits

The SAVM uses fixed-width words, a stack, memory, storage, control instructions, and host interfaces. Its execution context binds the caller and jurisdiction. The interpreter records gas consumption, storage mutations, tensor updates, logs, deferred requests, and an outcome.

Current outcomes include success, revert, gas exhaustion, yield, wall-clock timeout, stack overflow, memory exhaustion, and version conflict. A yield preserves a resumption position and can carry an approval requirement. A failed evaluation can still produce a receipt that records the failed attempt.

Resource limits must be enforced at the level where work occurs. Instruction charging bounds interpreter work. Memory limits bound allocation. Wall-clock limits bound elapsed execution. External verification and provider calls require their own bounded admission and cancellation behavior.

The compliance coprocessor provides typed tensor access and controlled updates. It also exposes attestation and proof-verification interfaces. Reproducibility requires the same program, inputs, and coprocessor state. A changed evidence snapshot is a changed input, even when the bytecode remains identical.

## Deferred effects and their limits

Institutional write instructions produce deferred syscall requests. Each request identifies a primitive, target, selector, value, position, and request number. The host processes eligible requests through the mutation boundary after evaluation. VM success and syscall finalization therefore require separate inspection.

The current bridge records syscall audit events. Escrow lock and release requests on this bridge are audit-journaled. They do not establish a custodian hold, balance change, or treasury release. A successful result on that surface concerns the recorded syscall, not settled escrow.

A production materializer must bind each eligible request to an owning service or authoritative provider. It must record exact request identity, authority, resulting effect, and acknowledgment. An unsupported request must fail explicitly or remain a named unresolved effect. The receipt must preserve that distinction for downstream consumers.

The current rollback policy defaults to all-or-nothing eligibility for deferred requests after failed evaluation. Success and yield can leave requests eligible. A checkpoint policy can permit a recorded prefix of requests. This policy selects requests for commitment. It does not make multiple host transactions globally atomic.

Optimistic concurrency checks compare the entity version observed at execution with the current version before deferred mutation. A mismatch requires rejection or another admitted evaluation. This check must remain coupled to the write boundary to prevent a later race. A successful earlier read alone cannot reserve the state.

## Model-assisted replay

Model output is an external input to deterministic replay. Recording an output can make later evaluation reproducible without making fresh model calls deterministic. The retained record must bind the model identity, request inputs, returned decision, rationale reference, and charged resources.

The current replay-cache abstraction derives a key from dispatch input words and an optional model commitment. It retains the first response associated with that key. An in-memory cache supports a single process. Durable replay requires preservation of the cache data and all referenced content across restart and transfer.

A production profile must bind model identity explicitly. It must reject a replay request whose profile differs from the retained record. If two fresh calls race, the accepted historical response must remain singular and authenticated. A later provider response must not replace it under the same identity.

These requirements concern replay of recorded computation. An independently reproducible decision can still depend on incorrect evidence or an unauthorized model grant. Authority verification, evidence quality, and replay verification remain separate checks.

# Receipt chains and independent observation

A receipt chain records related transitions in an ordered, tamper-evident history. The chain binds each transition to its predecessor. An authenticated checkpoint commits to a particular prefix. Independent observation can make conflicting histories detectable when an operator presents different prefixes to different parties.

## Receipt types and commitments

Receipt types reflect different subjects. A SAVM execution receipt records evaluation, including failure and deferred requests. A corridor receipt records a corridor event and its policy bindings. An operation record connects steps, outcomes, and proofs. Their common use of digests does not make them one interchangeable wire type.

The current SAVM receipt contains an execution digest, predecessor digest, sequence, caller, jurisdiction, gas, storage mutations, tensor updates, deferred requests, logs, outcome, and time. It also carries concurrency and rollback information. Its canonical content digest identifies that record. Signature and external anchoring requirements belong to the consuming protocol.

A corridor receipt uses `prev_root` and `next_root`. The latter commits to the current receipt payload after excluding its proof and `next_root` fields. Policy digest sets are normalized before canonicalization. It does not commit to an unknown future receipt.

For corridor receipt $R_k$, define $Q(R_k)$ as that normalized commitment payload. Let $h_{-1}$ be the corridor's genesis root. The chain requires:

$$
R_k.\texttt{prev\_root}=h_{k-1},\qquad
h_k=H(Q(R_k)),\qquad
R_k.\texttt{next\_root}=h_k.
$$

The current chain append checks the expected sequence, predecessor root, and recomputed commitment. It then appends the new root to a Merkle mountain range, or MMR. An MMR is an append-oriented authenticated structure that supports inclusion proofs for its leaves.

## What a proof establishes

The entity **lawchain** is a separate hash-linked history design. Its intended granularity is terminal operations, with a block committing the operation's step-receipt evidence and linking the preceding block. Intermediate mutation events have their separate event history; they must not be described as individually lawchain-anchored. The current database module provides append and chain-verification helpers, but source inspection found no runtime caller that appends these blocks. Its introductory claim of daemon production therefore does not establish implemented terminal-operation anchoring.

An inclusion proof establishes that a specified leaf occurs at a specified position under a particular root and structure. Its meaning depends on the authenticated checkpoint that names that root. The verifier must check the receipt's own sequence and chain binding separately from the MMR path.

A single leaf proof does not establish that an operator disclosed every later receipt. Tail completeness requires an authoritative checkpoint or another accepted freshness reference. A historic checkpoint proves a historic prefix. Its signature does not establish that the prefix is current.

External anchoring can supply evidence that a commitment existed by an independently accepted time. The verifier must validate the anchor's actual record, finality assumptions, root binding, and timestamp semantics. A configured anchor target is insufficient. The claimed root must appear in a verified acknowledgment from that target.

Selective disclosure can reduce the evidence supplied to a reader. A reader can verify a disclosed receipt against a checkpoint without receiving every payload. The reader still needs the dependencies required for the substantive claim. Confidential input availability and cryptographic inclusion are separate obligations.

For reproducible evaluation, the evidence bundle must retain program bytes, evidence snapshots, rule versions, host profile, and recorded nondeterministic inputs. The verifier must compare the resulting claim with the signed commitment. Missing material must produce a precise verification limit rather than a reconstructed placeholder.

## Fork detection and recovery

A fork occurs when distinct transitions claim the same predecessor position under the same chain identity. Detection requires access to the conflicting commitments. A hash function makes a detected conflict tamper-evident. It does not force an operator to disclose both branches.

Independent checkpoints and signed observations can expose conflicting histories. The receiving policy must define whose statements count, their authority, their observation scope, and their validity period. Two copies from one administrative source must not count as independent evidence merely because they have different transport endpoints.

Recovery must preserve both conflicting records. It must identify the authority that selects a valid continuation and the evidence supporting that choice. Arrival time alone is insufficient unless the protocol explicitly accepts that time source and selection rule. The losing branch can contain external effects that require separate resolution.

The current corridor code provides fork, recovery, checkpoint, and observation mechanisms. Production acceptance must exercise their composition under conflicting messages and restart. A receipt-chain implementation alone does not establish that every asset, operation, and corridor shares a deployed fork-resolution service.

## Watchers and admissible observation

A **watcher** is an identified observer that signs a statement about a defined subject. Its statement must specify what it observed and the evidence available to it. The receiving party decides whether that statement satisfies an admissibility rule. A watcher signature does not itself confer authority over the observed institution.

A quorum policy must identify eligible observers, distinctness requirements, threshold, statement binding, and validity conditions. Aggregation can reduce signature size. Eligibility, duplicate rejection, key validation, and policy evaluation remain necessary work. No fixed quorum size follows solely from the use of aggregated signatures.

The current watcher state model represents registration, bonding, activation, slashing, unbonding, deactivation, and banning. It distinguishes equivocation, availability failure, false attestation, and collusion. The API records stake and ownership information and produces mutation proofs. Those records do not alone establish funded collateral at a custodian.

A funded watcher service must connect its recorded bond to an authoritative balance or custody record. Release must respect outstanding claims and the applicable unbonding period. Slashing must identify the offense, evidence, deciding authority, amount, and executed disposition. A bookkeeping reduction requires separate settlement evidence when money moves externally.

The economic argument is conditional. Let $g$ be the gain from a dishonest statement, $p$ its detection probability, and $L$ the enforceable loss. Let $V$ be the service income forfeited after detection. Deterrence requires assumptions sufficient to make dishonesty unattractive, such as:

$$
p(L+V)>g.
$$

This inequality is a design condition, not an observed property of the implementation. It depends on funded collateral, detection, enforceable sanctions, collusion behavior, and the watcher's alternatives. A high recorded reputation cannot establish these assumptions. A production watcher market requires operating evidence for each economic and institutional dependency.

The repudiation watcher is a separate operational mechanism. It reads configured notices that withdraw recognition or standing and triggers follow-up handling. The current daemon remains passive when its notice source is absent. Deployment must verify source authenticity, notice scope, processing, and the resulting restrictions before claiming active repudiation monitoring.

# Corridors and migration

A corridor connects deployments under explicit recognition and execution rules. It carries statements, evidence, requests, and receipts across administrative boundaries. Each receiving deployment retains responsibility for the authority and meaning it accepts. A network connection alone grants no recognition.

## Recognition and projection

For a directed corridor from deployment $A$ to deployment $B$, let $R_{AB}$ describe which statements $B$ recognizes from $A$. Let $\phi_{AB}$ map an accepted statement into the receiving decision model. The direction matters. Recognition from $A$ to $B$ does not imply the reverse relation.

The corridor contract must bind participating authorities, permitted subjects, operations, domains, evidence classes, signature acceptance, validity periods, and recovery rules. Recognition must preserve the source statement's conditions and limitations. A projection must not turn pending evidence into a completed requirement or broaden the recognized subject.

Mutual recognition applies to specified domains and acts. A receiver can accept one recognized determination and independently evaluate another. The resulting decision must retain the source and rule for each component. A configured recognition set is an input to evaluation, not evidence of institutional acceptance by the parties.

Multi-hop routing adds further obligations. Every hop must remain active and authorized for the proposed operation. The current bridge computes routes from directed edges using fees and settlement-time estimates. Its caller must supply eligible active corridors. Route selection does not establish successful settlement or preservation of recognition across the entire path.

## Local protocol states and external effects

The current three-phase orchestrator has `Init`, `Locked`, `Verified`, `Committed`, and `Aborted` states. It is a pure state machine driven by its caller. It validates transitions and collects verification verdicts. Actual storage, message delivery, resource locking, and provider settlement belong to the surrounding integration.

The authenticated path checks enrolled source authority, signed lock and verdict data, zone identity binding, and acceptable epochs. It rejects missing authority configuration. Verifier admission can restrict expensive work through configured resource controls. A successful transition establishes the state machine's permitted next state.

A deployed protocol must persist its state before sending messages that rely on that state. Its messages must bind corridor, operation, subject, generation, phase, policy versions, and replay identity. A receiver must reject conflicting or stale messages while preserving exact replays. A sender must recover unsent or unacknowledged messages from durable state.

Protocol commitment and external settlement must have separate receipts when they have separate authorities. A lock attestation must correspond to an enforceable reservation. A committed protocol decision must remain recoverable after a crash. A payment or title transfer must supply the acknowledgment required by its authoritative system.

Adding protocol phases does not remove network partitions. During a partition, a participant may lack evidence required to release a resource safely. The corridor must state when it waits, when it can abort, and which durable evidence permits commitment. Availability claims require the stated communication and failure assumptions.

## Recovery, time, and resource admission

The recovery model retains collected verdicts, expected participants, timeout information, fencing generation, finalization status, and refund status. Its current resolver preserves a recorded terminal decision. It rejects a committed state that conflicts with a verification rejection. Recovery advances the fencing generation and refuses overflow.

The host must make that generation effective at every later effect boundary. Merely incrementing a stored number cannot stop an old process from sending a provider request. The provider adapter, exclusive credential, or receiving service must enforce the relevant fence. Each action must also satisfy its current authority requirements.

Deadlines require an agreed time interpretation. The canonical-time mechanism combines authenticated time evidence under a selected acceptance rule. A deployment must bind the actual accepted sources and tolerance. Local wall time, an attested reference time, and a provider's acceptance time can support different decisions.

Verifier-gas admission limits resource abuse before expensive verification. The current model includes cost bounds, per-source token buckets, gas escrow records, and admission witnesses. Financial collateral requires a funded settlement path in addition to these resource records. A gas-bond refund must co-commit its release marker with the authoritative release to prevent double refunds.

## Asset migration and institutional presence

Asset migration transfers a defined asset state or custody relationship. Redomiciliation changes an entity's primary registered jurisdiction under the applicable procedures. Adding a harbor establishes another recognized presence while preserving the existing one. These changes can share workflow mechanisms while imposing different legal and operational requirements.

The current migration saga models initiation, compliance checking, attestation gathering, source locking, transit, destination verification, destination unlock, and completion. Its failure states include compensated, timed out, and cancelled. The separate asset-migration protocol models proposal, freezing, destination evaluation, commitment, and abort. These are distinct state models with different payloads.

The generic saga advances state and records compensation information. That behavior does not itself file an exit notice, reverse an accepted registration, or move custody. A production migration binds each phase to an authoritative producer and a durable acknowledgment. Its release decision must inspect those effects rather than infer them from phase names.

For institutional presence, let $J(E)$ be the set of jurisdictions where entity $E$ has an active recognized presence. Adding a harbor proposes $J(E)\cup\{j\}$. Removing a harbor proposes $\{k\in J(E)\mid k\ne j\}$. The accepted change depends on the required registry evidence, continuing obligations, and authority in each affected jurisdiction.

Compliance must evaluate the relevant activity under the applicable jurisdiction set. Adding a harbor does not erase source duties or automatically export every permission. An asset's existing restrictions can survive its movement. The accepted destination state must carry the source history and any unresolved obligations.

## Transfer of execution authority

Transfer of a running institution requires more than export of its visible records. The handoff must include authoritative namespaces, machine states, economic journal, funded resources, reservations, outbox work, future-action authority, and retained evidence. It must preserve duty identity, occurrence, portions, command exposure, and unacknowledged delivery identities.

A **transfer cut** identifies the exact source state admitted for handoff. Preparation can produce additional authorized records after the initial snapshot. These **preparation deltas** must be retained and admitted into the final cut. The receiver must verify current source revisions and reject an incomplete or inconsistent cut.

Each authoritative namespace must supply an authenticated complete prefix. Every cross-namespace effect must appear at its destination or remain in the retained outbox with its exact payload and identity. An empty local list does not prove source completeness.

The predecessor must lose authority to initiate new work before the successor gains that authority. The activation procedure must select exactly one successor generation through durable ownership and effective fences. The successor must restore checked continuations through its exact receiving decoder. It must not reconstruct progress by executing source programs again.

Every later action requires the current generation and action-specific authority. Transfer itself must not issue pending commands, discharge debts, release reservations, or create provider dispatches. Replay must return historical receipts without executing those actions. Pending outbox work remains pending under its original delivery identity until an authorized delivery occurs.

A coherent rollback of all local state can also roll back a locally stored freshness marker. Protection against that failure requires an external monotonic freshness reference or equivalent custody constraint. Cloned stores require exclusive custody or effective fencing. A matching database copy alone cannot establish unique execution authority.

The durable continuation reference work supports this stronger transfer specification. It remains distinct from production integration and distributed institutional transfer evidence. Acceptance requires an actual predecessor fence, exact admitted cut, receiving decode, unique successor activation, and attempted stale-generation rejection.

## Compensation across jurisdictions

A migration failure must leave an accurate account of each jurisdiction's accepted state. The system can reverse a local reservation when its contract permits release. An external registry can retain an accepted filing even after dependent work fails. The recovery record must preserve that fact and assign the remaining action.

Suppose source exit is accepted while destination entry fails. The resulting state may require reinstatement, another destination filing, or an alternative authorized procedure. A local compensated flag cannot establish reinstatement. Recovery closes only when its specified authoritative effects and acknowledgments exist.

Cross-jurisdiction compensation therefore provides controlled follow-up and explicit residual obligations. Atomicity applies to each local transaction. Broader guarantees require proved contracts from every participating service and authority. A specification must name those assumptions before claiming atomic movement.

# Worked example: adding a second harbor

This trace illustrates the required evidence and failure handling for a company that adds a second recognized presence. Jurisdictions $A$ and $B$ are abstract participants. The example assumes that the applicable procedures permit the proposed presence. It makes no claim about a named jurisdiction, configured corridor, or completed deployment.

## Initial state and authored request

Company $E$ has an active presence in $A$. Its record includes controllers, beneficial owners, issued interests, registry bindings, and continuing obligations. It has an unpaid supplier duty and a funded reservation for an authorized payment. These records retain their identities throughout the example.

The controllers request an additional presence in $B$ while preserving the presence in $A$. The authored request identifies $E$, the requested presence, required officers, registered agent information, and the supporting documents. It also identifies the authority approving the change and an exact replay identity.

The operation definition resolves the required work: verify authority, evaluate the proposed activity, prepare documents, collect signatures, submit the filing, and verify acceptance. The contract names the acknowledgment that establishes each completed step. It also names any costs and effects that survive cancellation.

## Admission and durable creation

Mass authenticates the principal and checks the effective grant for $E$ and the requested operation. It verifies the authored program's payload and authority bindings. It evaluates required evidence under the pinned rules for the relevant activity. A sanctions hard block rejects this attempted action before further authorized effects.

The admitted operation is created durably. Its creation proof identifies the operation and the decision supporting creation. The company still has only its established presence in $A$. The new presence becomes active only after the required acceptance and local commitment.

The client receives the operation identifier and observes its progress. It treats generated documents, requested signatures, submitted filings, and accepted filings as different events. A signed creation proof does not cause the interface to display the second harbor as active.

## Signature wait and restart

The document step produces a document with an exact digest. The signing step binds that document to authorized signers and records its pending request. The workflow enters a wait. Its claim can expire without invalidating the pending signing request.

A worker restarts during that wait. Recovery reads the persisted operation and provider request identity. It checks the provider's current response before sending another request. Any permitted redelivery retains the original identity. The workflow does not generate a replacement document merely to restart the step.

The provider callback identifies the signing request, document, signer, and completed action. Mass verifies those bindings and records the event. An exact duplicate callback resolves to the existing event. A changed document digest under the same event identity fails the immutable replay check.

If callback storage succeeds but advancement fails, the retry still uses the same event identity. The durable event remains available to the next worker. The operator can distinguish completed signing from delayed workflow advancement through the stored evidence.

## Filing and acceptance

The filing adapter persists its outgoing intent before dispatch. It binds the target registry, operation, company, document set, and provider replay identity. The registry accepts the request, but the response is lost. Mass records an unresolved external outcome rather than treating the filing as rejected.

Recovery queries the provider or repeats the request under the original identity, according to the provider contract. A verified acceptance returns the registry reference and accepted document relationship. Mass then commits the new presence, registry binding, and required local evidence through the selected atomic write path.

The company now has recognized presences in both $A$ and $B$, as established by the example's assumptions and receipts. Its continuing obligations remain jurisdiction-specific. The unpaid supplier duty and payment reservation preserve their original identities. Recognition of the second presence does not discharge them.

## Delayed evidence and completion

The local mutation commits, but downstream event emission fails. The operation's authoritative local state reflects the accepted presence. Its searchable event history temporarily lacks the derived event. Reconciliation reconstructs that event from the matching audit and outbox records without repeating the filing.

Completion inspection compares the operation with its contract. It verifies the required signature, registry acceptance, local presence record, and required acknowledgments. It records any delayed optional projections separately. If a required delivery remains in dead-letter storage, the delivery obligation remains open.

| Boundary | Required identity | Evidence retained |
|---|---|---|
| Program admission | Principal, company, program, capability | Admitted bindings and decision |
| Signature | Exact document and authorized signer | Verified signing acknowledgment |
| Registry filing | Provider request and company | Accepted registry response |
| Presence commitment | Operation and accepted registry binding | Business, audit, outbox, and proof records |
| Evidence repair | Original mutation and event identity | Reconciled event with causal relation |

## Failure and later transfer

If $B$ rejects the filing, $E$ retains its established presence in $A$. Compensation follows the contract for unused reservations, unsubmitted work, and cancellable provider requests. Accepted costs or retained registry records remain in the history. A new filing with changed information requires a newly admitted request.

If the institution later transfers its running execution to another deployment, the handoff uses an exact transfer cut. That cut includes the unpaid duty, reservation, pending deliveries, authority, and checked continuations. It also includes every admitted preparation delta.

The predecessor is fenced before the successor can initiate work. The successor verifies and directly restores each continuation through its receiving decoder. An exact retry returns a retained receipt without another dispatch. A stale predecessor's attempted payment must fail the current-generation check at the effective action boundary.

Acceptance of this trace requires execution through the selected services and persistence boundaries. The reviewer must inspect the actual provider acknowledgment and current records for the same intent. The illustrative ordering supplies the test contract. It does not supply the execution evidence.
