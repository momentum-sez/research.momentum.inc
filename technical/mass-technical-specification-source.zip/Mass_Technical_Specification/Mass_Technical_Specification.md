---
title: Mass Technical Specification
subtitle: Institutional execution, economic claims, and recourse
author: Momentum
date: September 2026
---

# About this specification {.unnumbered}

Momentum builds the network. Mass runs companies, institutions, and deployments. Moxie prices and clears claims. Recourse runs dispute resolution and carries outcomes into execution.

Mass is the AI-native operating system for programmable organizations. It connects formation, ownership, governance, treasury, identity, consent, and continuing compliance. Its purpose is to make regulated operations executable under explicit authority, with records that explain what happened and why.

The product objective is autonomous operation with lower operating cost and fewer manual handoffs. Sovereign deployments apply the same architecture under their own rules and recognized authorities. These objectives require complete operating procedures, competent institutions, and verified provider integrations. This specification does not convert a product objective into measured savings or a deployment guarantee.

Mass governs organizational action and the claims that organizations originate. Moxie prices, clears, and settles claims under admitted financial and institutional constraints. Recourse administers dispute procedures and carries authorized outcomes toward execution. Each system retains its own authority, state, and evidence requirements.

This book specifies the systems individually and at their boundaries. It develops the required architecture from organizational duties, authored intent, authority, state transitions, evidence, and economic effects. It also records the current implementation boundaries that a complete realization must close.

## Reading the claims

Four kinds of statement have different force throughout the book.

| Statement | Meaning |
|---|---|
| Requirement | A condition that a conforming implementation must satisfy. It can exceed current functionality. |
| Source implementation | Behavior supported by inspected implementation paths. It does not establish deployment or successful execution in a particular environment. |
| Formal result | A mathematical result under stated hypotheses and within the defined model or formal fragment. |
| Execution observation | A result from an identified running system, with the configuration, actors, inputs, and durable effects needed to support it. |

The word **must** states a requirement. An **implementation boundary** names current functionality, incomplete integration, or an unresolved realization obligation. An illustrative trace explains a contract. It is not a report of a completed transaction.

Source inspection for this edition began on 6 September 2026. Implementations evolve independently. A later deployment must identify its own software, dependencies, rules, credentials, and evidence before claiming conformance. A compiled interface, registered operation, or passing model check cannot establish the completion of a business process.

## Scope and organization

The opening chapters define organizations, identities, governance, and delegated action. Cryptographic chapters establish byte identity, signatures, evidence, storage, and threat assumptions. The rule and language chapters define compliance composition, legal discretion, execution programs, and pack configuration.

The execution chapters specify transactional writes, durable workflows, smart assets, observation, and corridors. The Moxie chapters develop claims, custody, settlement, consensus, and reliance. The Recourse chapters develop case authority, procedure, outcomes, stays, continuation, and recovery. The final chapters provide developer, operator, and conformance references.

The systems share typed contracts rather than a universal transaction. A financial or legal effect belongs to the authority that can make it effective. The integration contract must preserve the identity of that effect across requests, local records, external acknowledgements, and recovery.

## Edition and use

This public reading edition presents the design and implementation boundaries reviewed on 6 September 2026. Descriptions of retained implementation sources and verification records are dated observations. Those records are not included, and publication does not establish deployed conformance.

The document is a technical specification. Legal rules enter through identified instruments, recognized authorities, and applicable procedures. A software verdict records the outcome of a defined evaluation. Its legal effect depends on those sources and the authority of the evaluating institution.

# Programmable organizations

## The unit of work

A company appoints a director, issues an investment instrument, receives a payment, or files a required return. Each action changes several related facts. An appointment can require an eligible person, a valid resolution, signed acceptance, updated records, and acknowledgement from a registrar. A message saying that the appointment succeeded cannot substitute for those effects.

Mass makes this work programmable. A program states the intended action, the organization concerned, the required authority, and the evidence on which execution depends. Rules determine which transitions are admissible. Services apply the permitted changes. Durable records preserve the result and any remaining obligation.

An organization is more than its registration record. Its operating state includes people, offices, ownership, agreements, assets, liabilities, permissions, and procedures. Some facts belong to the organization. Others belong to registrars, banks, custodians, counterparties, or courts. The system must preserve that division when it automates a process.

**Definition: organizational action.** An organizational action is a requested transition in organizational state, under specified authority, with a defined set of required effects. The action has an identity independent of the number of attempts used to complete it.

**Definition: required effect.** A required effect is an independently meaningful change promised by the action's contract. Its completion requires evidence from the authority that owns the change. Examples include an updated officer record, a signed instrument, a provider transfer, or a registrar acknowledgement.

A process that requires a signed instrument and a registry update remains incomplete when only the instrument exists. The correct state can be waiting, partially complete, failed, or compensating. The vocabulary must reflect the actual contract. Operators need the outstanding obligation and the next permissible action.

## Intent, authority, and admissibility

An instruction states what a principal wants. Authority states which actions the principal or its delegate may initiate. Admissibility states whether a particular action satisfies the applicable rules and current conditions. These are independent questions.

For example, an authenticated shareholder can request a share transfer. The request alone does not establish transfer authority, satisfaction of preemption rights, buyer eligibility, or settlement. The runtime must evaluate the declared action against the relevant ownership and rule state.

Use the following abstract admission relation:

$$
\operatorname{Admit}(a,s,r,e,k,t)\in\{\operatorname{Permit}(w),\operatorname{Refuse}(q),\operatorname{Wait}(o)\}.
$$

Here $a$ is authored intent, $s$ is state, $r$ is the pinned rule set, and $e$ is supporting evidence. The variables $k$ and $t$ specify current authority and evaluation time. A permit carries a witness $w$. A refusal carries reasons $q$. A wait carries unresolved obligations $o$.

This relation is a specification model, not a universal wire format. Individual APIs can use different response types. Each API must preserve the distinction between permission, refusal, and missing requirements. A parser or typechecker cannot create an authority that the principal lacks.

Authored values must remain attributable to authored input or authenticated identity. An absent signatory cannot become the requester merely because that value is convenient. A missing legal entity cannot become a newly synthesized identity. A required jurisdiction or instrument term must remain unresolved until its proper source supplies it.

## A state model for institutions

For design purposes, represent organizational state as

$$
S=(I,H,G,O,A,L,P,W,E).
$$

$I$ contains identity bindings. $H$ contains jurisdictional presences. $G$ contains governance rules and offices. $O$ contains ownership and control relations. $A$ and $L$ contain assets and liabilities. $P$ contains permissions. $W$ contains active work and duties. $E$ contains retained evidence.

The tuple describes information that the system must account for. It does not require one database row, one service, or one shared consensus process. Ownership of each component follows the relevant business domain and external authority.

A jurisdictional presence, called a **harbor**, binds an organization to a jurisdiction and the recognized basis for operating there. A harbor records its own registration, licenses, rules, and ongoing obligations. Simultaneous harbors can share organizational identity while retaining different legal and operational conditions.

Adding a harbor requires a new admissible relationship. It does not transfer every license, erase earlier duties, or automatically confer recognition elsewhere. If two harbors impose incompatible conditions, composition must return the incompatibility. The system cannot turn an unresolved legal conflict into a passing scalar score.

The operating model needs two notions of time. **Effective time** identifies when a fact applies in the modeled world. **Record time** identifies when the system recorded it. A late notice can change the interpretation of an earlier period without erasing what the system knew when it acted.

Programs must therefore bind the relevant time and rule state. Re-evaluation under current rules answers a different question from reproduction of a historical decision. A historical permission can remain valid evidence while current authority has expired or been revoked.

## Duties survive process boundaries

A duty identifies an obligation, its responsible party, its performance conditions, and its remaining exposure. A workflow instance is one mechanism for administering that duty. Restarting or transferring the workflow does not create a new duty or discharge the original one.

Represent a duty occurrence by a stable identifier and preserve its portions, cash reservations, and execution exposure. Late performance reduces the relevant residual exposure under the duty's rules. Closing a command does not prove that an unpaid debt has been satisfied.

This distinction controls migration and recovery. A receiving system needs enough state to continue the same work with the same obligations. It must not infer completion from the predecessor's last status string. The chapters on durable execution and Recourse develop the required continuation and transfer contracts.

## Design choices and their consequences

Mass uses a common admission and mutation boundary because business domains share authority and audit obligations. Native services retain domain ownership so that entity rules, investment rules, and identity rules remain explicit. The composition root supplies dependencies and assembles the public service.

Durable workflows support long-running action because external acknowledgement can arrive after the initiating request ends. Content identities bind rules and evidence because mutable names alone cannot reproduce a decision. Typed identifiers preserve distinctions because a valid byte string can still denote the wrong class of object.

Sovereign deployments retain authority over their own state. Corridors carry recognized evidence and bounded requests between deployments. Moxie adds a settlement authority for admitted claims. Recourse adds a dispute procedure and outcome authority. These boundaries make uncertainty and incomplete delivery explicit.

The product objective includes lower operating cost, reduced manual work, and autonomous execution of permitted actions. These outcomes require measurement against a defined process and service level. The architecture does not supply a universal headcount ratio, transaction-cost reduction, or deployment timetable.

## Implementation boundary

The current Mass source contains native organizational primitives, rule evaluation, operation execution, and proof and audit structures. It also contains incomplete authoring, civic, storage, and cross-system paths. Later chapters identify those paths directly.

The common mutation boundary is a required architecture, with known ordering exceptions in the examined implementation. Agentic corridor dispatch commits its database transition before runtime admission. Beneficial-ownership edge creation and termination also persist before proposing their runtime mutation. A later admission failure cannot roll back those earlier commits. These paths do not satisfy the required co-commitment of admitted business state and evidence.

The organization model is wider than the set of workflows demonstrated in a running environment. A conformance claim must identify the particular action, its required effects, and the evidence that joins them. This book preserves that distinction while specifying the complete intended operating model.

# System boundaries and native primitives

## Responsibilities of the connected systems

Mass owns institutional state transitions and their admission. Moxie owns native claim admission, market execution, clearing, settlement, and finality within its configured network. Recourse owns case administration and the records that establish a dispute procedure and its outcome.

An outcome can authorize a request to another system. The recipient must still check its own action-specific authority and current conditions. A Recourse award does not itself debit a Mass account or settle a Moxie claim. Those effects require the destination's accepted contract and durable acknowledgement.

| Boundary | Owning responsibility | Required distinction |
|---|---|---|
| Mass | Organizational records and regulated action | Local mutation versus external effect |
| Moxie | Claims, custody, clearing, settlement | Submission versus native finality |
| Recourse | Procedure, outcomes, execution coordination | Award versus recovered property |
| Provider | Signing, banking, registration, or other specialized service | Requested work versus provider acknowledgement |
| Application | Presentation, authored input, and observation | Displayed state versus authoritative state |

The application can be a browser, SDK consumer, or agent using the Model Context Protocol (MCP). It supplies intent and presents progress. It must carry the principal's identity and scope through the supported runtime interface. Client-side validation improves interaction but cannot replace server-side admission.

![Selected authority boundaries. Direct integration between other pairs must satisfy the same recipient admission and acknowledgement contract.](manuscript/figures/authority-boundaries.png){width=6.5in}

## Primitive ownership

The native primitive partition assigns business decisions and persistence to an owning domain. The API layer routes requests and composes services. A database facade performs domain persistence within the applicable transaction. An external adapter translates a provider contract without becoming a second owner of organizational truth.

**Identity** owns profiles, identity links, verification, accreditation, invitations, and related evidence. It distinguishes an editable profile from a provider verification decision. Identity work supplies facts that other domains evaluate under their own rules.

**Entity** owns organizational identity, incorporation and registration records, officers and relationships, jurisdictional presences, and provider registration interactions. Registration state and permission to conduct a licensed activity are separate records.

**Governance** owns resolutions, consents, ownership records, share classes, corporate actions, vesting, and related agreements. Its required contract applies the electorate and approval rule appropriate to the action. A board decision must not silently substitute for a shareholder decision. The current electorate and fallback limitations are described under Corporate consent.

**Investment** owns fundraising and investor participation contracts, agreement state, payment state, and related administration. Instrument families carry distinct authored terms. A subscription, a future-equity agreement, and a token agreement cannot become interchangeable because each raises money.

**Treasury and payment work** connects account authority, transaction records, fees, and provider operations. Permission to read an account differs from permission to transact. A recorded payment request differs from a confirmed provider transfer.

**Templating and signing** turn authored legal content and approved data into instrument bytes and signing submissions. The document's content identity, signatory authority, provider submission, and completed signature are separate facts. Rendering a PDF proves none of the remaining facts by itself.

Other native services support notifications, dynamic letters, service providers, and organizational intelligence. Their composition must retain the same authority and effect boundaries. A notification cannot become proof that its recipient accepted an agreement.

## External compute and provider boundaries

The configured Java compute boundary comprises treasury and templating services. Native Rust services own identity, entity, governance, and investment business logic. The eProspera provider adapter is a separate native provider boundary.

For the intended Mass deployment, institutional persistence belongs to the Mass runtime. Treasury compute and provider work return through supported persistence APIs. Templating compute and signing integration must run under the profile that directs institutional persistence through Mass.

The inspected templating source also contains a separate persistence profile. Consequently, deployment profile selection is a real acceptance condition. A statement about the intended Mass topology cannot establish the profile of an uninspected running service.

At every provider boundary, record the request identity, intended effect, provider reference, and response evidence. An ambiguous timeout leaves the effect uncertain until reconciliation resolves it. Blind repetition can create duplicate transfers, submissions, or filings.

## State machines compose through contracts

An entity, license, investment, signing submission, and workflow each have their own state machine. Their terminal states answer different questions. A dissolved entity can still have retained records and outstanding recovery obligations. A completed signing submission can coexist with an unpaid investment.

The source investment model separates payment status from investor signature. Its current-investment query treats a paid but unsigned investment as live. Within that predicate, consummation requires payment marked paid and the investor's signature. Other legal and operational conditions remain the responsibility of the enclosing instrument and workflow.

The signing state machine admits transitions from awaiting signatures to signed, declined, or archived. Repetition of the same state has no new transition effect. A terminal signing state cannot simply move back to awaiting signatures. A replacement instrument needs its own explicit identity and procedure.

These examples establish a general requirement: the enclosing process must derive completion from the required component facts. It must not choose whichever component first reports a terminal status.

## Identifier and document discipline

Identifiers belong to domains. An authenticated user identifier, an entity UUID, a document key, a content digest, a case UUID, and a native chain object identifier have different semantics. Adapters must validate the destination type and preserve the source association.

A document key identifies an object in the document store. A signed URL grants temporary retrieval access. A content digest commits to bytes under a specified encoding and digest scheme. A provider submission identifier denotes a signing process. None is a substitute for the others.

An update must distinguish omission, clearing, and replacement when the contract supports all three. For example, an omitted document-key field preserves the existing value. An explicit null can clear it. A supplied key replaces it. Flattening these states in a client can silently change the user's request.

Money must retain denomination, scale, sign convention, and representation. Human decimal amounts and native fixed-point integers require explicit conversion. A bridge must reject ambiguous units and overflow. It must not reuse a value merely because both APIs accept strings.

## Implementation boundary

The current source mounts public HTTP routes that call the owning native services. Physical route-file placement is an implementation detail. Domain ownership and the transaction contract are the architectural requirements.

The active investment web application invokes typed operations for incorporation, governance, investment, and related work. Those calling paths establish integration structure. A workflow's availability still depends on its pack, authority, provider configuration, and observed execution.

This specification does not certify every primitive route or provider deployment. It requires each supported action to preserve authored input, scope, domain ownership, and durable effect identity across the boundaries described above.

# Identity, governance, and consent

## Identity assertions and verified properties

An identifier names a subject. Authentication binds a presented credential to a caller. Verification records a checked property of a subject. Authorization permits a particular action under current conditions. Combining these into one flag makes review and recovery unreliable.

A decentralized identifier (DID) uses a method-specific identifier and resolution procedure. Its syntax does not imply that the identifier itself is content addressed. Resolution can associate keys and services with the subject. The verifier must apply the actual method and trust policy.

A verifiable credential records an issuer's claims about a subject. The verifier checks the signed content, issuer authority, subject binding, validity, and applicable status or revocation. A valid signature establishes the signing relationship under its assumptions. It does not establish the substantive truth of every asserted property.

Identity information can come from a person, an organization, or a provider. The record must preserve which source supplied it. A format-valid national identifier remains an assertion until an authorized process verifies the relevant binding. A registry-shaped type does not establish a live registry connection.

## Verification and accreditation lifecycles

The source identity service models verification states such as not started, started, pending, verified, rejected, expired, and reset. Its transition rule permits a provider approval to reach verified from any prior state. This accommodates a provider's later re-review of the same inquiry.

That transition rule relies on the caller supplying an authenticated, inquiry-scoped provider decision. It is a pure state predicate. It must not be exposed as permission for arbitrary callers to overwrite identity status.

Accreditation has a distinct lifecycle. Pending decisions can become verified or rejected. A verified accreditation can expire. Rejected or expired cases can return to pending with renewed evidence. An identity check and an accreditation decision therefore require separate state and provenance.

A jurisdiction or operation can require a set of verified properties. The requirement must identify the property, acceptable issuer, validity interval, evidence, and purpose. This specification does not prescribe a universal numerical KYC tier with the same legal meaning in every jurisdiction.

## Capability delegation

A capability grants bounded authority. Attenuation derives narrower authority from an existing grant. In set notation, if $A_i$ is the set of actions admitted by grant $i$, valid attenuation requires

$$
A_{i+1}\subseteq A_i.
$$

The subset relation is a semantic requirement. Comparing labels or attaching an additional text condition is insufficient if the resulting evaluator widens authority. The capability verifier must check the supported narrowing rules and reject unsupported combinations.

MassBiscuit provides a signed attenuation chain with caveats. The program-admission path checks the chain, its revocation state, and the program's capability binding. It also checks signer association and effective constraints such as operation family, jurisdiction, and time.

The epoch-witness verifier supplies a specific non-revocation mechanism. A trusted revocation authority signs an epoch, observation time, and commitment to its revoked-capability set. The proof must concern the presented capability and establish its exclusion from that committed set. The composed verifier checks chain integrity, capability identity, trusted witness signature, freshness, and the exclusion proof. Chain verification alone does not perform these witness checks.

The inspected witness verifier accepts timestamps within thirty seconds on either side of its clock and rejects larger offsets. This freshness and clock-skew allowance is distinct from token lifetime. A stale, missing, mismatched, or invalid witness cannot establish current authority. The proof-fetch interface can report that no fresh proof is available or that its cache is unconfigured; neither response establishes non-revocation. Deployments must identify the actual revocation path used at admission, its trusted roots, and its clock assumptions.

Entity delegation APIs expose grants, revocations, and subdelegation under entity-scoped authorization. The enclosing service must verify the current grant for each new action. Historical validity of an earlier action does not authorize a later action after revocation.

Authentication mechanisms remain distinct from this program authority. A bearer token can establish a session and coarse scope. The actual route contract determines whether it additionally requires a signed program, attenuated capability, governance approval, or provider authority.

## Corporate consent

A consent binds a proposed action to a defined electorate and decision rule. Its record must preserve the action, electorate snapshot, required threshold, authored instrument content, and votes. Later changes to the board must not silently reinterpret an already conducted vote.

The source distinguishes board, board-meeting, and shareholder electorates. Meeting attendance can govern a meeting resolution. A sole-director shortcut applicable to a board action does not automatically apply to a shareholder or meeting action.

The current persistence model retains the electorate count and rule, rather than a complete frozen voter set. Vote admission checks current director or administrator membership for every consent; share ownership alone does not authorize a vote. In addition, shareholder operation steps substitute board quorum when no cap table or active shareholder electorate exists. These behaviors limit the implementation's electorate guarantees and must not be mistaken for the stronger contract above.

For an electorate of $n$ voters, the implemented simple-majority threshold is

$$
m(n)=\lfloor n/2\rfloor+1.
$$

A percentage threshold $p$ uses $\lceil np/100\rceil$. A fractional threshold $a/b$ uses $\lceil na/b\rceil$. The source validates the authored ranges and requires at least one approval. A zero-electorate bootstrap requires an explicit policy at the enclosing consent boundary.

These thresholds are predicates over a specified electorate. They are not universal statements of corporate law. The applicable instrument or governance pack selects the rule and the authority that may use it.

For fixed thresholds, the implementation requires the same number of votes to reject as to approve. Consequently, all ballots can be cast while the consent remains pending. Four voters with a threshold of three and a two-to-two division are one example. A complete procedure needs an explicit rule for an exhausted electorate that reaches neither threshold; it must not infer that the implemented tally has resolved the motion.

The relative rule "votes for exceed votes against" has different semantics. Let $f$ and $a$ be votes for and against, and let $u$ be uncast ballots. Approval becomes irreversible when $f>a+u$. Rejection becomes irreversible when $a\geq f+u$. Otherwise the vote remains pending.

For example, consider five eligible voters with two votes for and one against. Two ballots remain. The result remains pending because either side can still determine it. With three votes for and none against, two remaining votes cannot reverse approval.

The source also models force approval as a separate tally outcome. Its arithmetic evaluator does not authorize the override. Caller and office checks belong to the service that records the vote. The override must preserve the acting authority and its legal basis.

## Approval, signing, and effect

Approval decides a motion under its governance rule. Signing records a person's execution of particular instrument bytes in a specified capacity. Applying the corporate action changes the relevant business state. Each stage has its own evidence.

A signing callback must bind the provider submission to the expected instrument and signers. The receiver authenticates the callback, checks replay identity, validates the state transition, and reconciles the final document. It then applies the authorized downstream effect through the owning mutation path.

Duplicate delivery must preserve the original result. A repeated signed event must not issue another security or repeat a payment. A changed payload under a previously accepted event identity must be treated as a conflict, not another valid retry.

Replacement or amendment needs explicit lineage. Changing template content after a signing submission begins cannot silently change what an existing signature means. The final artifact must remain bound to the bytes and capacities that the parties actually signed.

## Ownership and control

An ownership graph records economic and control relationships among subjects. Each edge needs its relationship type, validity interval, evidence, and relevant percentage or control attribute. Legal control can arise through mechanisms other than equity ownership.

For a simple equity chain, indirect participation multiplies the edge fractions. If one entity holds 60 percent of another, which holds 40 percent of a third, the path contributes 24 percent. Multiple paths, overlapping holdings, cycles, nominees, and non-equity control require additional rules.

The current control-graph traversal uses bounded breadth-first exploration and a visited set keyed by entity. This prevents repeated visits and terminates cycles. It does not by itself prove complete aggregation of all economic paths to a beneficial owner.

An ultimate-beneficial-owner conclusion therefore needs the jurisdiction's control rules and sufficient source evidence. An empty traversal result means that the inspected graph found no qualifying relationship within its model. It cannot prove that undisclosed beneficial ownership does not exist.

## Civic governance

Civic governance extends the authority model to citizens, ballots, offices, petitions, and public procedures. The required contract binds eligibility, notice, voting window, tally method, quorum, and certification. Constitutional amendments must satisfy the procedure authorized to change those rules.

An amendment contract shall identify eligible proposers, the exact proposed text, notice and deliberation periods, the electorate, and the required quorum and approval threshold. It shall distinguish amendable provisions from reserved matters and specify any additional chamber, referendum, or external assent. Admission of the replacement rules must bind the old authority, completed procedure, resulting text, effective time, and treatment of work already in progress. The amendment cannot authorize itself by invoking the new rule before that rule becomes effective.

Office eligibility shall apply the governing term limits and disqualification rules to the relevant service history. A new account or identity document must not reset a person's term history. Where eligibility depends on disputed facts, the procedure needs an authorized determination and a recorded result before seating the officeholder. These are required governance semantics, not a claim of a general implemented constitutional evaluator.

The source vocabulary includes direct and representative democracy, parliamentary and presidential forms, consultation, councils, technocratic forms, hybrids, and custom forms. These types describe configurable structures. Their presence does not establish a complete evaluator for each constitutional system.

Ballot secrecy and eligibility are separate properties. An opaque eligibility-proof field does not establish a zero-knowledge protocol. A correct tally requires an admitted ballot set, duplicate-vote controls, a defined counting rule, and certification by the proper authority.

Rotating authority across regions is a possible operating design. A valid realization needs a signed schedule, unambiguous time interpretation, handoff rules, and protection against simultaneous incompatible authority. This specification does not claim a general rotating-governance runtime is implemented.

## Implementation boundary

Corporate consent, verification, accreditation, and signing have concrete service and state-machine implementations. Their correctness still depends on the surrounding authentication, persistence, provider, and operation paths.

Civic types include ballots and tally results, but the inspected production source does not construct the general tally result. National-registry type definitions likewise do not establish operating registry channels. A deployment must close these specific integration obligations before claiming civic or registry functionality.

# Agents, observation, and authored decisions

## Delegated organizational work

An agent can prepare an action, monitor a condition, or initiate permitted work for an organization. Its authority must come from a current grant. The grant must identify the principal, permitted actions, scope, limits, and revocation conditions.

Autonomy means that the agent can act within this authorized envelope without a new human instruction for each instance. It does not give the agent authority to alter its own mandate, choose an absent signatory, or decide an unresolved legal question merely by producing text.

The runtime should separate observation, proposal, approval, and execution. An observation supplies information. A proposal supplies candidate intent. An approval satisfies a specified decision requirement. Execution performs the admitted effect. Each transition needs its own source and authority.

## Durable applications and work orders

The target application contract separates package publication from organizational installation. An immutable package record binds publisher, executable bytes, dependencies, requested capabilities, declared effects, and pricing. Each installation requires its own grant binding organization, package version, principal, permitted operations, data scope, budgets, expiry, and governing approval. Publishing a package does not authorize it to operate an organization. Expanding permissions requires a new admitted grant.

An upgrade must preserve the original package, authored parameters, and authority history of pending jobs. A failed upgrade retains the identity of the serving revision. Rollback requires evidence that the previous executable can interpret current persistent state; replacing executable bytes cannot reverse an admitted business effect.

Removal stops new submissions and enters a draining state. Eligible pending work can be cancelled under its recorded policy. Work already sent retains its execution and reconciliation obligations. A responsible institutional owner remains identified until termination or an authorized handoff is durable. Executable access may be removed only after the required termination or separately authorized handoff evidence is durable. Removal does not erase provider, dispute, or recovery duties.

A work order binds the authored outcome, immutable inputs, proposed plan, permitted actions, budget, acceptance conditions, and unresolved assumptions. An agent run records a particular attempt to advance that order. Finishing the run does not satisfy the order. Retrieved documents remain evidence and cannot change its permissions, signing principal, or acceptance conditions.

A scheduled firing binds the schedule, rule revision, occurrence coordinate, job, and command identity. Cancellation and dispatch contend on that same durable record. A lost commit response cannot create another firing. Later attempts preserve the occurrence and use current authority for their next permitted effect.

Learning proposals likewise separate evaluation, ratification, and application. Candidate and baseline must use the same evidence and frozen evaluation plan, with explicit observation window, thresholds, failures, and residuals. A material change creates a new proposal revision and invalidates stale evaluation or approval. Favorable shadow evaluation changes no operational rule. The exact proposed change requires separate ratification and current admission before use; historical decisions retain their original model and policy identities.

These application records are proposed requirements. They do not establish that the complete publication, installation, scheduling, removal, or governed-learning lifecycle is implemented by an existing interface.

## Triggered policies

The implemented policy vocabulary connects a trigger type, an optional condition, an action, a priority, a jurisdiction scope, and an authorization requirement. Matching first checks whether the policy is enabled and the trigger type agrees. It then checks scope and the condition against supplied event data.

Triggers cover regulatory updates, dispute events, corridor and settlement events, checkpoints, key rotation, governance, fiscal deadlines, and organizational lifecycle events. Policy actions include transfers, issuance and burning, binding changes, governance changes, corporate actions, halt and resume, and enforcement requests.

These are typed action categories. A matching policy has not yet proved that the corresponding executable operation is installed or authorized. Dispatch must resolve the actual operation and repeat the relevant current admission checks.

The examined immediate-action dispatcher does not inspect the policy's modeled authorization requirement before dispatch. For example, the corridor-failover policy specifies quorum, while the immediate halt and resume paths do not enforce that quorum requirement. Queued unsupported actions retain authorization metadata, which is a different behavior. Storing a requirement therefore does not establish the approval gate required by this specification.

Conditions use a typed predicate representation with comparisons, membership, field presence, conjunction, and disjunction. This representation should not be described as arbitrary Lex execution. Unsupported conditions must fail explicitly. Missing data must not become affirmative evidence through a convenience default.

Priority resolves conflicts only according to a declared policy. A higher-priority proposed action cannot override a sanctions rejection or widen a capability. Urgency changes scheduling. It does not change legal or financial authority.

## Model output and discretion

A language model can explain records, extract candidate facts, draft a document, or propose a rule. Its output remains a candidate artifact until the receiving contract admits it. A typed structure reduces ambiguity but does not establish that the model supplied truthful evidence.

The runtime must preserve model identity and configuration when reproducibility matters. It must also preserve the input evidence, retrieval cutoff, redactions, response, and any human decision. A cache can reproduce retained output. It cannot prove that a later fresh inference would return the same output.

Some work requires discretion. A discretion request must identify the question, acceptable deciding authority, relevant evidence, and permitted effect of the answer. Recording the answer resolves that specific requirement. It must not create a general permission to bypass further rules.

Historical validity and current authority remain separate here. An earlier approved interpretation can explain a completed action. A new action may require a fresh approval because the facts, rules, or delegation changed.

## Retrieval and provenance

An organizational query should identify the subject, purpose, access scope, and time of interest. Retrieval must respect those limits before it supplies context to a model. Redaction must apply to the actual outgoing context and preserve enough lineage for review.

The regulatory-inquiry library helper retrieves evidence as of a specified time, builds and redacts context, queries an adapter, and checks returned provenance. It can report fabricated digest references and discretion flags. These checks constrain the source references. They do not prove that every sentence is a correct legal interpretation.

The mounted inquiry endpoint uses a separate inline path with a mock model adapter. That path places retrieved text and the raw query into the prompt, and retains the full prompt in its audit draft. It does not invoke the library's redaction step. The helper's behavior must not be attributed to the mounted endpoint, and neither path establishes production model execution.

The evidence store and the model should remain separate authorities. A model must not create historical evidence by citing a digest it invented. A receiver should resolve cited evidence and verify the association before using the response in another action.

## Planning and execution

A remediation plan identifies candidate actions for unresolved conditions. Each action still needs a current executable operation, authored parameters, authority, and resources. The plan must expose missing prerequisites and distinguish simulation from admitted work.

The mounted agent `plan-and-execute` endpoint constructs plan-mode operation records and reports their identifiers as created. It does not persist those operation records; its later proof persistence records the audit result. The returned identifiers therefore do not establish resumable operations. The separate operation-plan endpoint does persist its operation record. Neither result establishes completed remediation. The user-facing process must distinguish candidate plans, durably submitted work, and outstanding effects.

Simulation has a similar boundary. A gas or throttle projection answers a resource question. Bytecode simulation answers a question about the modeled state and supported instructions. Neither can establish a future provider acknowledgement or legal decision that the simulation does not control.

## An illustrative filing process

Consider an organization whose annual filing deadline approaches. A time-based observation identifies the organization and applicable duty. The policy checks the deadline, current filing state, and its own scope. It proposes a filing operation using retained organizational records.

The operation retrieves the required accounts and identifies missing authored information. A model can prepare a draft explanation from admitted evidence. An authorized reviewer supplies any required interpretation and approves the instrument where the procedure requires approval.

The responsible signatory signs the exact filing artifact. The provider submission retains its delivery identity. A timeout after submission leaves acceptance uncertain. The runtime reconciles using that identity before initiating another delivery.

The duty closes only when the contract's completion evidence exists. If the registrar accepts the filing but a fee remains unpaid, that remaining duty stays visible. If a correction is required, the process preserves the original submission and records the corrective action under its own identity.

This is an illustrative contract trace. Availability of any particular tax or registry integration requires separate execution evidence.

For a tax calculation, the preparation stage needs an additional deterministic chain. Select transactions for the entity and reporting period, remove duplicates, retain reversals, and classify each line under the effective rule set. As a fictional arithmetic fixture, suppose admitted taxable receipts total 12,500 units, admitted deductions total 2,500, and the authored teaching rule applies ten percent to the difference. The calculation produces a 10,000-unit base and a 1,000-unit liability. These invented values illustrate computation; they describe no jurisdiction's tax law.

Retain the input lines, classification decisions, currency, rounding rule, effective rule identity, and computed report. Required human judgment must be recorded before the report becomes an authorized filing. A signature binds the approved report; a filing receipt acknowledges submission or acceptance according to its own contract. Payment and discharge of the computed liability require separate evidence. A model-generated explanation must not alter the retained calculation or create a missing receipt.

## Implementation boundary

The current ecosystem contains policy evaluation, entity delegation, operation planning, and advisory retrieval paths. A separate inference service exposes analysis and explanation, but its default or fallback engine is a mock unless a real model loads. A successful service response alone cannot establish real inference.

That service also contains typed proposal approval fields whose parser does not independently verify the claimed approval signature. Its parsed provenance can contain no input digests. Downstream consumers must therefore treat those fields as assertions until the actual admission boundary verifies them.

Application designs such as Sensoria can consume organizational identity, consent, measurement, and intervention contracts. Planning documents for such applications remain design material until executable implementations and evidence establish their behavior. They do not add authority to the underlying Mass or Moxie interfaces.

The required architecture keeps models off the final authority boundary. Any model-assisted action must still satisfy current intent, identity, rule, resource, and effect requirements. This remains true when the action is generated automatically and when its explanation is fluent.

# Rights, corporate actions, and funded resources

A shareholder can retain registered title while another person receives part of the sale proceeds. A lender can hold security over the same shares. These rights concern one asset, but they authorize different acts. A program must retain each relationship when it changes ownership records, distributes proceeds, or moves an organization between jurisdictions.

The requirements in these chapters are normative design contracts. The equations establish the stated mathematical properties under explicit assumptions. Their implementation requires evidence from the actual admission, storage, and effect boundaries. The examples use assumed instruments and quantities.

## Identify the right before calculating its quantity

A **constituting act** is the instrument or authoritative event that creates a right. A **subject lot** identifies the assets covered by that act. A right record binds a stable right identity to its constituting act, subject lot, holder or beneficiary, and effective interval. It identifies any obligor and retains quantity, unit, priority, exercise conditions, transfer conditions, and amendments.

| Right kind | What the record identifies | Separate decision required |
|---|---|---|
| Registered holding | Title recorded for the named holder and lot | Effective transfer of that title |
| Economic participation | Contractual share of specified economic outputs | Authority to realize or distribute those outputs |
| Voting | Voting weight and matters within its scope | Eligibility for the particular decision |
| Security | Secured obligation, collateral, priority, and enforcement terms | Permitted enforcement and actual recovery |
| Proceeds | Beneficiary's entitlement to specified receipts | Receipt, allocation, and authorized payment |

An assignment can change the beneficiary through an authorized transition while preserving the right's lineage. A representation change preserves the existing beneficiary. A new administrator, identifier alias, or workflow instance cannot silently substitute another person.

Suppose Rowan holds 100 shares and their votes. An instrument grants Blair 40% of residual sale proceeds. A security instrument gives Casey priority up to 10 currency units. Assume all proceeds and claims use one currency. For received proceeds $z\geq0$, the allocations are

$$
c(z)=\min(10,z),\qquad
b(z)=0.4[z-c(z)],\qquad
r(z)=0.6[z-c(z)].
$$

At $z=100$, Casey receives 10, Blair receives 36, and Rowan receives 54 currency units. Their sum equals the received amount. Rowan's registered holding and votes retain their separate records. Blair's proceeds right supplies neither voting authority nor authority to debit Rowan's account.

Admission therefore binds the exact act: holding, offering, pledging, transferring, voting, or paying. Its context includes the right, persons and roles, amount and unit, destination, purpose, time, and applicable rules. Recognized foreign evidence can satisfy a named premise. Every reserved local decision remains necessary for that act. An unresolved determination of applicable scope remains an admission obligation.

## Preserve named entitlements through corporate actions

A two-for-one split converts 100 covered shares into 200 replacement shares. Suppose Blair's participation remains 40% of the covered lot. Measure that entitlement in old-share equivalents. Before the split, its coefficient is $2/5$. Each replacement share represents half an old share, so the successor coefficient is $1/5$. Both calculations give 40 old-share equivalents.

The coefficient changes because the unit changes. Blair's contractual percentage remains 40%. Keeping coefficient $2/5$ while interpreting the output in old-share equivalents would incorrectly produce 80.

For the general calculation, let $X\subseteq\mathbb Q_{\geq0}^{n}$ be a nonempty set of admitted positions. Each coordinate has a named lot and unit. Let $V=\operatorname{span}_{\mathbb Q}X$ be their rational span. A matrix $F$ with $k$ rows and $n$ columns computes $k$ selected entitlements from a position $x$.

Every row fixes its right identity, kind, beneficiary, governing act, and output unit. A permitted corporate action maps $x$ to $Px$, where $P$ has $m$ rows and $n$ columns. Its successor view $G$ has $k$ rows and $m$ columns. The rows of $G$ retain exactly the meanings of the rows of $F$. Matrix coefficients include the conversions between their named units.

The preservation condition is

$$
(GP-F)v=0\quad\text{for every }v\in V.
$$

This condition is equivalent to $GPx=Fx$ for every admitted position. A linear map vanishes on a set exactly when it vanishes on that set's span. When $X$ contains the full nonnegative orthant, the basis vectors give $GP=F$. A check on sample positions proves only those cases unless they span the admitted domain.

Composition preserves the same named rights. Suppose a second action has matrix $Q$ and successor view $H$. If $HQ=G$ on $P(V)$, then $HQPx=GPx=Fx$ for every $x\in X$.

These equations compare specified entitlements. They supply no conservation law for market value. A merger can preserve claims to replacement securities and cash while their prices change. Its rows must keep those units separate. Priority waterfalls, changing denominators, and other nonlinear terms require their own state-dependent functions. Equality of relabeled numbers cannot establish preservation of those rights.

## Fund the correct estate

A **legal estate** identifies the assets and obligations to which a resource belongs under the governing arrangements. Each funding pool identifies its estate, canonical account or custody allocation, asset, unit, and permitted uses. Account aliases resolve to the same resource. Separate estates using one account require supported disjoint allocations.

For a pool, let $c$ be recorded cash, $e$ its senior encumbrances, and $r$ its pending reservations. All quantities use the same asset and unit. With $(x)_+=\max(x,0)$, define free cash $f$ and shortfall $s$ by

$$
f=(c-e-r)_+,\qquad s=(e+r-c)_+.
$$

A new reservation $a\geq0$ requires $a\leq f$, permitted use, and current authority. The test and reservation must form one serialized transaction over the canonical resource. Consuming a reserved payment decreases cash and reservation equally. Releasing an unused reservation requires evidence that its command can no longer perform that amount. A timeout leaves that question unresolved.

If the pool initially covers its commitments, these transitions preserve coverage. Reservation consumes at most free cash. Performance decreases $c$ and $r$ equally, while a justified release reduces $r$. An authenticated external debit can reveal a shortfall. The record must then retain the commitments and show $s$.

An operator estate with 100 currency units cannot fund an 80-unit client payment from an empty client estate merely through shared control. An authorized loan can transfer 80 and record the corresponding receivable and liability. A prior operator reservation of 30 leaves only 70 free, so that transfer requires additional funding or an effective release. Transfers between providers retain separate debit and credit evidence. Expected destination cash becomes spendable only under its receiving ledger's credit rules.

# Authorized programs and viable continuations

An action can fit a delegate's permission and still damage another party's right or strand a promised delivery. Admission needs three additional accounts: actual effects on rights, aggregate delegated use, and the remaining route to the required outcome.

## Authorize the semantic effect

Changing one fee-schedule field can change amounts owed under many contracts. Permission to edit that field covers the storage action. Authority to amend the affected contracts depends on their governing terms.

Let $I$ be the complete registered set of relationships within the action's scope. For each $i\in I$, let $\rho_i(s)$ describe its rights in state $s$. The description includes holder, obligor, terms, performance, priority, maturity, and discharge conditions. Creation or removal uses an explicit absent value. The actual impact of a proposed transition is

$$
\mathcal I(s,s')=\{i\in I:\rho_i(s)\ne\rho_i(s')\}.
$$

The proposal declares a set $J$ covering this impact. Admission requires current amendment authority for every changed projection, binding its old terms, new terms, and effective time. The governing rule can require consent or identify another competent authority. The model preserves that distinction.

The membership of $I$, its generation, relevant rules, and selecting queries are protected dependencies. Admission must detect a newly affected contract before commitment. Under complete coverage and faithful projections, $\mathcal I(s,s')\subseteq J$ establishes authority for every changed relationship. Every relationship outside $J$ retains its projection. Discovering all relationships and correctly interpreting their terms remain substantive obligations. A list of written columns cannot prove either premise.

## Share delegated budget counters

Giving ten delegates individual limits of 100 can authorize 1,000 units of aggregate use. Scope attenuation alone cannot enforce a principal's total limit of 100. Every descendant must retain the same canonical budget account.

Fix resource coordinates with explicit units, purposes, and accounting windows. They can separately constrain lifetime expenditure, daily expenditure, and a project's exposure. A command charges every applicable coordinate. All budget, charge, and reservation vectors are nonnegative and use these coordinates. Let $B_c$ be capability $c$'s limit vector. A child narrows its parent's scope, validity interval, and coordinate limits.

Let $s_c$ be charge already attributed to $c$ and its descendants within those accounting rules. For command $k$, let $r_k$ be its unresolved reservation vector. Let $\operatorname{chain}(k)$ contain the authorizing capability and all its ancestors, each exactly once. Aggregate use is

$$
U_c=s_c+\sum_{k:\,c\in\operatorname{chain}(k)}r_k.
$$

Each command appears once in every applicable sum. Its initial bound $u_k$ must cover every permitted charged outcome. Admission reserves $u_k$ atomically with the immutable command and requires $U_c+u_k\leq B_c$ for every $c\in\operatorname{chain}(k)$. Exact retries return the original admission. They add no reservation.

Authenticated performance $0\leq d\leq r_k$ moves $d$ from reservation into consumed charge for every $c\in\operatorname{chain}(k)$. This leaves $U_c$ unchanged. A justified release decreases it. Starting from $0\leq U_c\leq B_c$, these cases preserve each limit by induction, assuming complete mediation and one authoritative account. Revocation retains consumed charges and unresolved reservations. Separate physical stores require a common allocation authority or a sound resource partition.

Two delegates can reserve 40 and 60 against a root limit of 100. Two reservations of 100 cannot both pass. A refund does not replenish a lifetime expenditure limit. Replenishment needs an explicit accounting rule and authenticated receipt. Cash availability, expenditure authority, and performance of an outstanding duty remain separate predicates.

## Retain the returned value during suspension

A program can receive an authenticated jurisdiction value and then request evidence whose type depends on that jurisdiction. Resumption must retain the returned jurisdiction with the evidence. Substituting a pending request or a newly selected jurisdiction would change the meaning of the result.

Let $A$ be the response value type and $B(a)$ a pure family of evidence types indexed by $a\in A$. Write $F_\rho A$ for a computation returning an $A$ value with effects within set $\rho$. If $m:F_\rho A$ and $k(a):F_\sigma B(a)$, dependent sequencing returns

$$
\operatorname{dbind}(m,k):F_{\rho\cup\sigma}
\left(\Sigma a:A.\,B(a)\right).
$$

The dependent pair contains the returned value $a$ and corresponding evidence $b:B(a)$. The effect set $\sigma$ bounds every permitted continuation. Execution runs $m$, uses its returned $a$ to run $k(a)$, and returns $(a,b)$. Suspension and refusal retain the observed prefix. A nonconstant result family retains its index, either in this pair or an enclosing dependent context.

A durable continuation must therefore retain the value environment and pending response type alongside control position, program, effects, history, and authority dependencies. Direct restoration must recover that same checked context. Current authority still governs the next effect after an answer arrives.

## Choose from available observations

Consider a delivery requiring 60 currency units after a preliminary purchase. With 100 available, a preliminary cost of 60 creates a funded dead end. A complete route costing 90 can remain admissible. A refund meets the goal only when the governing contract expressly permits that remedy.

Planning must also account for hidden state. An approval response can arrive after the delegate loses execution authority. If the response reports only approval, the program cannot assume that authority remains active.

Use a finite response model. Let $X$ contain all relevant states, $S\subseteq X$ the safe states, and $T\subseteq S$ the permitted terminal outcomes. A **belief** $B$ is the nonempty set of states consistent with the complete observed history. Its initial value must contain every possible starting state.

Let $\mathcal A$ be the finite set of command choices. For $a\in\mathcal A$, the model supplies finite response paths $\mathcal P(x,a)$ from each possible state $x$. Every path contains at least one transition and ends at the next program decision. Intermediate states carry the same rights, resources, and authority conditions as separately admitted acts.

Write $\operatorname{obs}(p)$ for the transcript actually exposed by path $p$. For a possible transcript $z$, update the belief by

$$
U(B,a,z)=\{\operatorname{last}(p):x\in B,
p\in\mathcal P(x,a),\operatorname{obs}(p)=z\}.
$$

An action is uniformly executable when every $x\in B$ has at least one response path. Let $Z(B,a)$ be the possible transcripts. Let $\mathcal W_h$ contain beliefs from which safety and known completion are guaranteed within $h$ decisions. Start with

$$
\mathcal W_0=\{B:\varnothing\ne B\subseteq T\}.
$$

Define $\operatorname{Good}_h(B,a)$ by three conditions: uniform execution, safety at every intermediate state, and $U(B,a,z)\in\mathcal W_h$ for every $z\in Z(B,a)$. Then

$$
\mathcal W_{h+1}=\mathcal W_0\cup
\{B:\varnothing\ne B\subseteq S,
\ \exists a\in\mathcal A\;\operatorname{Good}_h(B,a)\}.
$$

At a terminal belief, the program declares completion. Otherwise it chooses any retained action and decreases the remaining horizon after the response. Induction on the horizon proves the finite guarantee. Every possible observation leads to a shorter guaranteed continuation. Conversely, a policy that guarantees completion must satisfy those conditions before it sees the response.

This construction uses observed transcripts throughout. A guarded attempt can perform with live authority and return refusal with revoked authority. Both outcomes must have safe continuations. The refusal preserves outstanding duties and reservations. Another authorized actor can proceed only through a separately admitted transition.

The guarantee requires a complete finite model, including hidden memory and response obligations. Unknown transcripts require reassessment. Weak fairness alone supplies no finite deadline. A calendar bound additionally requires a duration bound for each complete decision round. Retries retain response counters and the original duty. Enlarging the terminal set after failure changes the contract and requires its own authority.

# Succession, recognition, and continuing authority

An institution can replace an operator, merge offices, or divide competence between lawful successors. Its records must preserve existing rights while assigning future acts. **Competence** means an institution's authority over named matters and acts. Technical control of a deployment and institutional competence need distinct records.

## Derive succession from the existing authority

A succession instrument identifies predecessor and successor offices, transferred competence, effective time, adoption authority, custodian, and the disposition of rights and duties. It binds the complete continuation inventory, prepared transactions, reservations, evidence custody, and future authority sources. Admission checks the instrument against the predecessor's effective authority structure and operative clauses. A proposed configuration cannot grant itself adoption power.

The instrument must allocate each competence explicitly. A lawful split can assign registration to one successor and licensing to another. Both can continue their disjoint acts. A shared decision requires its named joint rule. A single global successor flag would incorrectly suppress this lawful division.

The execution fence must instead enforce one active execution generation for each transferred scope. Shared resources also require a common decision and allocation boundary. A successor with registration competence cannot spend a licensing estate's reservation merely because both received records. Unresolved authority in one scope leaves that scope pending while unrelated authority continues.

## Activate custody without repeating work

The handoff cut identifies the exact admitted source state. Its inventory includes obligations, duty occurrences, portions, command exposure, cash reservations, checked continuations, and unacknowledged deliveries. Preparation changes form retained deltas and must appear in the final cut. Every claimed namespace requires authenticated completeness evidence.

The successor verifies custody and reconstructs existing reservations before conflicting writes. Its actual decoder must restore the checked continuation directly. Activation must bind the cut, predecessor fence, successor generation, and receipt atomically within each authoritative admission boundary. Invalid admission consumes nothing. An exact retry returns the receipt without evaluator execution.

Transfer itself creates no dispatch, discharge, or resource release. Later acts retain their original causal identities and require current action-specific authority. External effect owners must enforce the generation where a stale process could still act. A local fence cannot establish exclusivity over cloned stores or an external provider that ignores it.

Cross-store returned credit remains encumbered while reopening is pending. Reuse requires the authoritative original ledger's committed reopening and every required current admission. A successor's receipt of the return message does not supply that commitment.

## Preserve history and evaluate present reliance

A destination decides which successor acts it recognizes under its own instruments. Conformance listings and copied policy records supply evidence. Recognition requires the destination's authorized decision. An express adoption can permit continued use of a predecessor's statement while preserving its original issuer, signed bytes, scope, and occurrence identity.

Historical verification and present reliance need separate results. Ordinary key retirement can leave an earlier assertion authentic under the retained signing-time evidence. Later compromise evidence can require reassessment of that assertion. The reassessment appends its cutoff, authority evidence, and decision while retaining the earlier admission. Authentic bytes remain available even when current reliance refuses their use.

Every new effect checks authority at the stage required by its instrument. Admission, dispatch, provider acceptance, and durable commitment can occur at different times. An earlier signature and clock sample cannot establish authority at a later required stage.

## Assurance boundary

The named-right calculation, budget induction, and finite planning recurrence give explicit models that implementations can test against. The research manuscripts describe bounded reference constructions for rights, delegated use, observation-based planning, dependent execution, and guarded allocation. Their source descriptions do not establish production conformance.

Acceptance of an implementation requires faithful right projections, complete dependency guards, authoritative resource accounting, authenticated custody, and actual admission and effect evidence. Full language refinement, complete institutional mandates, external freshness, and effective distributed fencing remain separate obligations. Each must be established for the claimed operation and deployment.

# Canonical content and cryptographic commitments

## What a commitment establishes

An organization needs evidence that retains its meaning when another party receives it. Mass therefore distinguishes an authored fact, its encoded representation, and the commitment to that representation. A digest can bind a representation. An authorized signature can attribute a commitment. A verified publication can establish that the commitment existed by a particular time. Each step has different inputs and trust assumptions.

Let $x$ be an accepted typed value, $C_v$ the canonical encoder at version $v$, and $H$ a specified hash function. Its content commitment is

$$d = H(C_v(x)).$$

The verifier needs the value, encoder version, and hash algorithm. It recomputes $d$ and compares the result with a commitment obtained through an authenticated channel. Agreement establishes consistency with that commitment, subject to the hash assumptions. The commitment alone does not identify its issuer or establish that the asserted facts are true.

For example, an identity provider can sign an incorrect date of birth. Signature verification attributes that statement to the provider. Content verification detects a changed date after signing. Correctness of the original date depends on the provider's evidence and the admission policy. An assurance system must preserve these separate conclusions through its API, storage, and user interface.

This distinction also applies to compliance evidence. A signed decision needs the applicable rules, admitted inputs, execution context, and decision procedure. Its digest binds the selected representation. The business conclusion depends on the complete derivation and its authorized interpretation.

## The implemented canonical form

The shared canonical library supplies a private byte wrapper with fallible constructors. Mass imports that library through a pinned dependency. The constructor converts a serializable value into JSON, applies recursive coercions, and emits compact JSON. Objects use the serializer's sorted map representation. Arrays retain their order.

The coercion rejects numbers that the JSON representation does not recognize as signed or unsigned integers. An ordinary decimal fraction therefore fails canonicalization. Financial schemas must select exact representations, such as a documented decimal string or scaled integer. They must also define currency, scale, rounding, and range. A string containing an amount has no arithmetic interpretation until its domain type supplies one.

A string that parses as an RFC 3339 datetime becomes UTC text with whole-second precision and a `Z` suffix. Other strings pass through unchanged. The inspected implementation performs neither general Unicode normalization nor automatic binary-to-base64 conversion. Binary fields use the owning type's serialization rules.

Consider these two input objects:

```json
{"recordedAt":"2026-09-06T15:00:00.250+07:00","amount":"12.30"}
{"amount":"12.30","recordedAt":"2026-09-06T08:00:00.900Z"}
```

Both become the following canonical object under the inspected coercion:

```json
{"amount":"12.30","recordedAt":"2026-09-06T08:00:00Z"}
```

Their fractional seconds differ, but normalization removes that difference. The encoder is therefore not injective over all input JSON values. Its contract must define equivalence after normalization. When subsecond order matters, an application needs an additional sequence or a representation that preserves the required precision.

The same issue affects a free-text field that happens to contain a parseable datetime. The constructor applies its string rule recursively without consulting field semantics. A schema author must account for this behavior before using the digest as the identity of an authored document. Original uploaded bytes need their own byte commitment when exact textual preservation matters.

The implementation describes its format in relation to JSON Canonicalization Scheme. Interoperability must nevertheless use exact executable vectors. The serializer's string ordering, integer range, escaping, and datetime coercion form part of the actual protocol. A general reference to canonical JSON cannot substitute for agreement on these details.

## Domain separation and preimages

A preimage is the exact byte sequence supplied to a cryptographic operation. Different objects can share a JSON shape while having different authority. An approval, a payment instruction, and a revocation must therefore bind their purposes. The normative contract requires a domain identifier and format version whenever a signature or digest crosses an authority boundary.

A schematic signed statement can bind the following tuple:

$$m = \operatorname{Encode}(\text{domain},\text{version},\text{issuer},\text{subject},\text{intent},d,\text{epoch}).$$

This formula describes a required binding, rather than a universal Mass wire encoding. Each concrete protocol must specify field order, lengths, optional fields, and excluded signature fields. Implementers must use that protocol's existing encoder. Replacing it with another plausible encoding changes the message being signed.

Raw hashing remains necessary for binary protocols. A Merkle parent hashes child digest bytes under its specified framing. A file commitment may hash original bytes. Such preimages differ from canonical JSON objects. The governing rule is to identify and reproduce the correct preimage, rather than claim that every hash consumes the same representation.

Algorithm identity belongs in a durable reference. A digest represented as hexadecimal text also needs an agreed case, length, and decoding rule. A typed digest prevents some representation mistakes within one program. It does not prove that an external caller supplied bytes from the intended algorithm or domain. Admission must validate both the type and the provenance.

## Equality, authenticity, and collision assumptions

Determinism and collision resistance are different properties. Determinism means that identical accepted inputs produce identical output bytes and digests. Collision resistance limits an adversary's ability to find distinct byte sequences with equal digests. Preimage resistance limits recovery of an input from a digest. Neither property supplies secrecy for a low-entropy value.

Hashing a short identifier can permit enumeration of all plausible identifiers. A content address can also reveal that two parties possess the same document. Privacy policy must therefore govern commitments as well as plaintext. Salted commitments, keyed constructions, and access controls address different disclosure problems and require distinct wire contracts.

An authenticated digest provides evidence of a particular commitment. An unauthenticated digest delivered beside attacker-controlled content provides only a consistency check. The attacker can replace both. A receiving service must obtain the expected digest from an authorized signature, a trusted transaction context, or an independently verified publication.

Comparison timing also needs a scoped claim. A constant-time comparison helper protects its own byte comparison. It does not establish constant-time parsing, allocation, database lookup, or error handling. Public digests usually do not require secret-dependent ordering. Secret authentication values require analysis of the full comparison path.

## Content-addressed artifacts

Content-addressed storage uses a content digest to locate an artifact. The inspected artifact store combines a validated artifact type with a digest. It writes JSON artifacts to a filesystem layout and recomputes their canonical digest during resolution. A mismatch produces an error.

The artifact type is part of the retrieval context. Its validation restricts characters and length, which also limits path construction. The digest identifies the canonical content under the chosen algorithm. A consumer must still validate the resolved artifact's schema and its suitability for the requested operation.

This implementation supports integrity checks on retrieved artifacts. A general claim that every database value lives in one content-addressed store would exceed its scope. Mass also uses domain database records, graph representations, event records, and binary evidence. Their identities and persistence contracts differ.

A missing artifact is an availability failure. A corrupted artifact is an integrity failure. An authentic artifact signed by an unauthorized issuer is an authority failure. Services should retain these distinctions in their evidence status, because remediation differs. Repeatedly fetching a missing object does not repair an invalid signature.

## Verification obligations

Canonical conformance requires vectors for reordered keys, nested objects, arrays, integer limits, decimal rejection, Unicode strings, and datetime normalization. It also requires rejection tests for unsupported representations. Two language implementations must compare exact bytes before comparing digests. Equal outputs on ordinary ASCII examples provide limited evidence about unusual keys and encodings.

A content verification test should change one committed field and require rejection. A domain-binding test should submit the same payload as another operation type and require rejection. Historical replay must use the original encoder and schema, or a verified conversion with an explicit relationship to the original commitment.

The implementation observations in this chapter come from source inspection. They establish concrete encoding behavior and storage checks. They do not establish universal route coverage, deployed configuration, or successful retrieval of a particular organization's evidence. Those claims require source-identified execution through the relevant API and persistence boundary.

# Signatures, key authority, and cryptographic epochs

## Signatures bind messages to keys

A digital signature allows a verifier to check a message against a public key. The authority associated with that key is a separate system fact. Mass needs both: cryptographic verification and a current, scoped relationship between the key, issuer, organization, and permitted action.

A valid signature under an unrecognized key supplies no organizational authority. A recognized key can also exceed its scope. A document issuer, an operation approver, and a deployment signer have distinct responsibilities. Their admission rules must specify which statements each can authorize.

The normative verification sequence resolves the issuer, selects an authenticated policy, checks the signature, and evaluates the statement's context. The context includes subject, intent, validity interval, replay protection, and any required approval threshold. The resulting authorization must remain attached to the exact statement used at the write boundary.

Key custody influences the threat model. Hardware-backed signing can reduce private-key extraction. It does not prevent a compromised application from requesting signatures that its account may request. Software key encryption protects stored material under its wrapping key. It does not hide unwrapped keys from a compromised process.

## The current hybrid suite

The inspected trust implementation combines Ed25519, ML-DSA-65, and SLH-DSA-SHA2-128f. The post-quantum features are enabled by default in that library. Actual deployed coverage still depends on the build, available keys, selected suite, and caller path. A library default cannot establish that every emitted artifact has every signature component.

Each component signature is called a limb. The versioned envelope identifies a suite and cryptographic epoch. Signing constructs a bound preimage containing a domain separator, suite tag, little-endian epoch, message bytes, and declared post-quantum limb count. Verification reconstructs the same preimage.

This binding prevents a verifier from treating the suite and epoch as unsigned annotations. Changing either field changes the signed preimage. A presentation that exposes an Ed25519 limb separately must also expose the exact bound preimage or a protocol that reconstructs it. Verifying that limb over the raw business payload would check a different message.

The implementation retains legacy support. Raw historical Ed25519 signatures and versioned Ed25519-only envelopes have different verification rules. A service must identify the permitted legacy population. It must not let an attacker select a weaker historical rule for a new operation.

The SLH parameter set matters operationally. The inspected signature constant is 17,088 bytes for SHA2-128f, while the ML-DSA-65 constant is 3,309 bytes. Ed25519 contributes 64 bytes. Envelope framing adds further bytes. The historical description of a SHA2-128s suite and an approximately eleven-kilobyte total therefore does not describe this implementation.

## AND and OR verification policies

Let $V_i(m,\sigma_i,pk_i)$ denote verification of limb $i$. Let $A$ be the authenticated set of required, supported limbs. Two possible policies are

$$V_{\mathrm{AND}} = \bigwedge_{i\in A}V_i,
\qquad
V_{\mathrm{OR}} = \bigvee_{i\in A}V_i.$$

The security difference follows directly from these predicates. Under AND, an attacker must satisfy every required verification. A surviving unforgeable required limb can therefore prevent a forgery. Under OR, a forgery accepted by any eligible limb satisfies the complete predicate.

Suppose an attacker can forge Ed25519 signatures and Ed25519 remains eligible under OR. The attacker signs a new unauthorized message with that limb and supplies invalid alternatives. OR accepts because the Ed25519 verification succeeds. Survival of other algorithms does not prevent this attack. Continued verification of an old legitimate signature is a different property from resistance to new forgeries.

The default trust verifier calls an AND policy. A separate OR verifier remains available. The inspected capability-chain verifier uses the AND policy over its relevant present, non-retired limbs. These call-site facts replace the historical claim that one universal OR policy protects all evidence.

The AND policy verifier checks suite completeness outside the test-only relaxation and rejects an effective empty check set. Feature configuration still matters because post-quantum verification branches are compiled conditionally. A deployment must demonstrate that every algorithm required by its admission policy is actually supported and checked. An envelope's declaration cannot compensate for an absent verifier.

The implementation combines verification outcomes through constant-time boolean operations. Parsing and algorithm branches remain visible parts of the function. This observation supports a narrow statement about result aggregation. It does not establish a complete side-channel theorem for the signature service.

## Retirement and bridging

A cryptographic epoch identifies a period governed by a signature policy. Retirement changes which algorithms a verifier may rely upon. The authority for this change must be authenticated independently of the artifact being checked. An attacker-controlled epoch field must never select its own acceptance rule.

The source contains retirement records, epoch-aware verification, and bridging certificate representations. A bridge connects old and new suites with the relevant epochs and commitments. The preferred certificate path supports signatures from both sides of the transition. A legacy helper also constructs a structural bridge without those dual signatures.

A structural certificate records intended continuity. It supplies no cryptographic evidence that the old and new authorities authorized that continuity. Admission must distinguish a certificate representation from a certificate whose signatures, key bindings, and policy transition have been verified.

For a planned transition, the deployment should retain the old policy, last accepted history commitment, new policy, new key identifiers, and authorized bridge. Historical verifiers need these records to explain why an older artifact remains acceptable. Current verifiers must apply the current retirement constraints where the protocol requires them.

Emergency retirement requires a different analysis. If an old key or algorithm is already compromised, its fresh signature cannot independently authorize recovery. Recovery then depends on previously established alternative authority, a trusted earlier commitment, or an explicit governance action. Calling the transition a bridge does not resolve that dependency.

Retirement should also preserve negative evidence. An artifact rejected because its only eligible algorithm was retired must retain that reason. A retry under a weaker policy would change the security decision. Historical readability and current authority need separate statuses.

## Key lifecycle and custody evidence

A complete key record includes purpose, public material, suite, issuer binding, activation, retirement, and replacement relationships. A deployment also needs a controlled signing interface and a record of who may invoke it. Private material must remain outside artifacts intended for verifiers.

Rotation tests must cover overlap windows and interrupted operations. A signature created before rotation may arrive afterward. The receiving policy must specify whether signing time, receipt time, or an authenticated sequence controls acceptance. An untrusted timestamp inside the message cannot settle that question alone.

Loss and compromise need distinct procedures. Lost keys can prevent new signatures while old signatures remain valid. Compromised keys can enable new unauthorized signatures. Backup restoration solves availability only when the restored material and authorization state remain trustworthy.

Long-term evidence requires preservation of algorithms, verification software, and historical policy. Renewal under a new algorithm can preserve an earlier commitment before its old protection becomes inadequate. Renewal after the old binding has failed requires additional evidence about which historical content was authentic.

## Acceptance evidence for signatures

A signature conformance suite must alter the message, suite, epoch, issuer, and each required limb independently. It must reject unauthorized policy downgrades and empty effective policies. It should also test the explicitly permitted historical forms and reject the same forms on new paths that require stronger suites.

An operational claim requires a real signing request, captured public envelope, independent verification, and durable association with the admitted operation. The record must identify the build features and key policy without disclosing private material. A successful primitive test does not prove that a public route invokes that primitive.

The present source supports hybrid signing and several explicit verification policies. The security argument depends on the selected policy and its authority. This specification makes no universal single-limb-compromise or forward-security claim across all Mass artifacts.

# Authenticated history, persistence, and retrieval

## Ordered commitments

An authenticated log commits to an ordered sequence. Its purpose is to make later changes detectable against a trusted earlier commitment. A Merkle Mountain Range, abbreviated MMR, organizes that sequence as a forest of complete binary trees. Each tree root is a peak.

Appending a leaf adds it at the right edge. Adjacent peaks of equal height merge until their heights differ. A specified peak-combination rule produces a root for the entire prefix. The root is meaningful only with the leaf count and exact hash protocol.

Leaf index and stored position differ. With zero-based indexing, a common MMR position formula is

$$p(i)=2i-\operatorname{popcount}(i).$$

The inspected graph-store implementation uses this formula. Internal hashes occupy intervening positions. A reader that treats a dense leaf index as a stored position can inspect an internal hash instead of the intended observation.

An inclusion proof establishes membership relative to one root. An extension proof establishes a relationship between two prefixes. Neither alone establishes global uniqueness of history. A writer can publish two incompatible roots to separate audiences unless the surrounding protocol detects or prevents equivocation.

## Exact MMR protocols

Mass contains distinct MMR implementations. The receipt-oriented cryptographic implementation uses domain-separated binary hashing:

$$L(d)=H(\texttt{0x00}\parallel d),$$

$$P(l,r)=H(\texttt{0x01}\parallel l\parallel r).$$

Here $d$, $l$, and $r$ are raw digest bytes. The prefixes distinguish leaves from parents. The implementation validates the expected hexadecimal representation before decoding it.

The graph store's memory implementation instead hashes concatenated hexadecimal strings for parent construction. Its persistent implementation hashes raw child bytes. These rules produce different roots for the same apparent digest strings. Consequently, a generic reference to the Mass MMR cannot serve as a wire specification.

The normative export contract must identify which implementation produced the root. It must fix leaf preparation, parent framing, peak order, empty-root behavior, and leaf-count interpretation. A conversion between protocols requires a separate authenticated binding. A reader must never infer compatibility from matching type names.

The inspected memory verifier checks the claimed value against its local stored position and compares the claimed root with its current root. It does not reconstruct a detached proof solely from the supplied siblings. This is a local membership check. A portable proof claim requires a verifier that receives no trusted local log and reconstructs the expected root from the proof.

A record carrying a field named `proof` therefore needs an explicit verification contract. It may contain useful local evidence without supporting independent remote verification. The distinction should remain visible in exported evidence status.

## Durable append and crash boundaries

A write-ahead log, or WAL, records intended changes before their application. The inspected graph writer appends a WAL operation before extending a persistent MMR. The persistent MMR uses fixed-size records and synchronizes writes. On opening, it removes an incomplete trailing record and derives its leaf count from stored structure.

These mechanisms address specific interruption points. They do not establish that every interrupted compound append reconstructs automatically. A crash can occur after the WAL record, after the leaf record, or after an intermediate parent. Recovery must relate these states to one admitted operation.

The inspected writer opens its WAL and MMR and reloads rollback markers. That opening path does not by itself replay every WAL append missing from the MMR. A complete recovery guarantee therefore requires the surrounding reconciliation path and crash tests. The historical statement that the WAL alone always restores the complete store exceeds this observed path.

Mass also distinguishes database-primary and graph-primary modes. In one mode, graph persistence can serve as a secondary projection. In the other, a graph write can precede the database commit. The latter path records a rollback marker if later work fails. Readers must honor such markers even though the authenticated log remains append-only.

This arrangement separates physical inclusion from business visibility. A committed log leaf can document an attempted operation later marked unsuccessful. The event remains useful evidence. It must not appear as a successful business mutation merely because it has an MMR position.

## Database projections and consistency

A projection is a derived view of authoritative events or records. It can support efficient queries without becoming the authority for the underlying business state. Its checkpoint identifies how far it has consumed the source sequence. Lag and divergence are different conditions.

Lag means the projection has not yet reached an admitted source event. Divergence means it represents that event incorrectly or inconsistently. A read contract should say whether it permits lag, requires a particular checkpoint, or falls back to the authoritative view. A successful HTTP response does not establish projection freshness.

The specification requires a reconciliation record when database and graph views disagree. That record should bind the observed source positions, affected subject, expected content, and actual content. Correction must preserve the evidence of divergence. Silently rebuilding a projection without recording the incident loses information relevant to audits.

A database transaction and a filesystem append have different commit mechanisms. Combining them requires ordering, idempotency, compensation, and explicit acknowledgment semantics. Documentation must identify the actual durable acknowledgment. A function return before the required persistence boundary cannot support a claim of completed evidence issuance.

## External anchoring

An external anchor publishes a commitment through another authority or consensus system. A useful anchor receipt binds root, leaf count, target, external reference, and confirmation evidence. The receiving auditor must verify the external reference against that target's protocol.

The inspected graph-store interface names Bitcoin, Ethereum, Certificate Transparency, and RFC 3161 target classes. Its production factory constructs a provider that explicitly returns an unimplemented error for live anchoring. Simulated providers exist behind test or mock configuration. Naming these targets therefore establishes an interface and intended integration, not live publication.

A locally computed binding digest checks consistency among receipt fields. It does not establish that the external system received the root. A timestamp string also supplies no independent time evidence. A real timestamp token needs its signature, authority chain, message imprint, and policy checked.

Multiple targets can improve resilience when their failures differ. Distinct names do not prove statistical independence. Shared operators, credentials, infrastructure, and legal control can create correlated failures. The precise conditional claim is that a retrievable authentic copy survives while at least one relevant target retains it under acceptable verification conditions.

An anchor preserves a root. It does not store every underlying document. Loss of all payload copies leaves the root intact but prevents reconstruction. Likewise, if the hash binding itself fails, publication of that hash does not restore uniqueness of its original preimage. Stronger historical conclusions require preserved content or another trustworthy commitment.

## Retrieval and evidence export

An export intended for independent verification needs the payload or authorized disclosure, schema, commitment protocol, signature policy, and relevant history proof. It also needs an authenticated expected root. When publication is claimed, it must include independently checkable publication evidence.

A retrieval drill should begin with an artifact selected by an auditor. The operator retrieves it through the actual storage tier, recomputes its commitment, and verifies its authorization and history. The drill should include missing objects, corrupted bytes, inaccessible keys, and stale indexes. Each failure must remain distinguishable.

Portable evidence also needs a freshness policy. A valid old root can omit later revocation or supersedence. A consumer deciding a current action must obtain the current evidence required by that action. A consumer reconstructing a historical decision instead needs the policy and state that applied at that time.

These are normative acceptance conditions. Source inspection establishes storage and verification mechanisms, including the limitations above. No live external anchor, independent recovery drill, or deployed storage availability is asserted by this chapter.

# Typed evidence graphs and long-term interpretation

## Graph records and their authority

An evidence graph connects typed records through typed relationships. An organization can connect a person, appointment, approval, document, operation, and resulting receipt. Such relationships support both business queries and reconstruction of why an action was admitted.

The inspected Mass graph implementation stores records in a map keyed by identifiers and relationships in a collection. A record carries a type label, content hash, and JSON payload. Relationship insertion checks that both endpoints exist. Record insertion can replace an existing identifier.

The implementation does not impose general acyclicity. It also accepts a supplied nonempty content hash without recomputing it in that low-level insertion method. When the hash is empty, it hashes serialized payload bytes. These facts constrain the guarantee available from the container alone.

The normative evidence graph requires stronger admission rules where authority depends on graph content. It must check type, expected digest, subject ownership, relationship meaning, and update policy. If a particular relation must be acyclic, its owning domain must enforce that condition. A graph container's generic type label supplies no such theorem.

## The gstore reference boundary

The inspected gstore project and the Mass graph-store component require separate implementation assessments. Mass declares its graph-store component as a local dependency. The inspected project's `TypedGraph` insertion and retrieval methods return `NotImplemented`. Similar names and related designs do not establish executable parity.

This distinction preserves the role of the reference design without attributing unavailable behavior to it. A consumer adopting that package needs the implemented API and its tests. A consumer assessing Mass needs the actual Mass integration and its persistence behavior. Evidence from one cannot silently substitute for the other.

The inspected formal companion contains statements about append behavior, replay, migration lenses, and anchoring. Several append and replay obligations remain admitted. Some anchor statements conclude `True` at their chosen abstraction. Those statements do not establish an executable storage refinement or adversarial durability result.

A formal result must identify its precise proposition and assumptions. A source implementation requires a separate relationship to that model. This chapter retains append preservation and deterministic replay as required properties while distinguishing them from discharged implementation proofs.

## Schema-pinned interpretation

A schema defines the structure and meaning of a record. Historical interpretation requires the schema applicable when the record was admitted. An epoch header can bind a schema identifier, version, digest, leaf count, and history root. A stored observation can retain its original schema version and bytes.

The inspected epoch registry represents these values. It also stores migration-lens records with forward and backward transformation hashes and an optional proof hash. Its lookup for a lens chain selects direct matching endpoints. It does not compute arbitrary multistep transitive composition.

A migration lens describes transformations between representations. If $f:X\rightarrow Y$ and $g:Y\rightarrow X$ claim reversible migration, the required laws include

$$g(f(x))=x\quad\text{for all admitted }x\in X,$$

and, when full bijection is claimed,

$$f(g(y))=y\quad\text{for all admitted }y\in Y.$$

A schema that discards an authored field cannot satisfy the first law without retaining that field elsewhere. A schema that introduces freely chosen new data cannot satisfy the second law over every new record. The migration must define its actual admitted subsets and preserved side information.

Storing a transformation hash and a proof hash records references. It does not execute the transformation or check the proof. A historical replay service must retrieve the pinned interpreter, validate its identity, select the proper schema, and reject missing dependencies. Replaying old bytes with the current schema can silently change their meaning.

## Facts, corrections, and supersedence

Evidence can remain authentic while its interpretation changes. A credential can expire. An appointment can end. A later decision can supersede an earlier one. The record of the earlier statement remains part of history, while current authority follows the applicable later state.

The normative correction model records a new statement that identifies what it changes and who authorized the change. It preserves the original commitment and reason for correction. A query must distinguish historical existence, current validity, and current operative effect.

For example, a director approved an operation while an appointment was active. A later resignation does not alter the signed approval bytes. Whether the approval remains effective depends on the operation's policy and timing. A query that shows only the current director list cannot decide this historical question.

Similarly, a withdrawn provider attestation can remain authentic evidence of what the provider previously asserted. Its use in a new operation may be forbidden. The graph should expose withdrawal as a relationship and state transition, rather than erase the original assertion from every view.

## Verification cores and full witnesses

A verification core retains compact references needed to identify and assess an observation. A full witness retains the data needed to reconstruct its derivation. The inspected archival types distinguish these objects and associate records with hot, pending, deleted-hot, verified-warm, and cold states.

The core representation includes the observation hash, MMR position, proof-term digest, verdict summary, cryptographic epoch, and suite identifier. It does not itself contain every artifact required for independent proof verification. The full witness representation includes proof bytes, graph delta, oracle inputs, optional capability chain, and replay versions.

These representations express an archival contract. They do not implement a storage lifecycle merely by existing. A successful transition to cold storage requires a verified durable copy, retrieval metadata, key availability, and retention policy. Deleting the hot copy before those conditions hold creates an availability risk.

The old approximation of a fixed-size core is unsuitable as a general capacity bound. The representation includes variable-length fields and a collection of verdict summaries. Even fixed-size cores require storage proportional to observation count. Compaction can reduce the coefficient or move costs between tiers. Retaining one core per observation remains linear in the number retained.

Deterministic replay also requires preserved external inputs. A current sanctions response, market price, or provider document cannot substitute for the response used originally. The replay record must bind exact inputs and their admissibility evidence. Calling a computation deterministic cannot recreate information that was never retained.

## Retention acceptance conditions

A long-term retention claim needs an inventory of retained objects and their dependencies. It must distinguish content integrity, interpretability, authorized access, and retrieval time. Encryption keys and schema interpreters can become unavailable while the ciphertext remains intact.

A useful acceptance drill reconstructs an old observation after a schema transition and a key rotation. It retrieves the original inputs, verifies their commitments, applies the correct interpreter, and compares the resulting decision. It also confirms the corresponding historical authorization state.

The storage protocol should record failed retrieval attempts and unresolved dependencies. A status named `Complete` must correspond to retrieved and verified evidence. An enum variant or a successful metadata update cannot establish that the witness is available. The current implementation observations support explicit representations and selected local operations, with broader archival execution remaining unverified here.

# Attestations, aggregation, and privacy

## What an attestation says

An attestation is an attributable statement about a subject. Its useful content includes issuer, subject, claim, scope, time, evidence references, and signature. Admission also needs a policy that recognizes the issuer for that claim. A watcher, identity provider, regulator, and company officer each speak within different authority.

Multiple attestations can concern the same fact without adding independent evidence. Several services can repeat one upstream response. Their signatures prove several issuers endorsed it, but their factual dependencies remain correlated. Quorum policy must account for eligible identities and evidence dependence.

An attestation should bind the exact statement that a receiving operation needs. Signing a broad status label can leave the applicable organization, jurisdiction, or observation time ambiguous. A statement used for settlement must identify the relevant intent and state version. A statement used for historical review needs its original validity context.

## BLS aggregation and quorum

BLS aggregation combines signatures over an agreed message into a compact group element. A verifier checks the aggregate against the participating public keys. The inspected aggregation implementation uses a BLS12-381 backend when its optional feature is enabled. Its compressed public keys and signatures have different fixed sizes.

The implementation also contains a structural fallback when that feature is absent. Structural signer-count validation is not cryptographic verification. Any admission path relying on aggregate authenticity must require the real backend and demonstrate that it ran.

Rogue-key attacks arise when an attacker chooses a public key algebraically related to honest keys. Proof of possession requires each participant to demonstrate knowledge of the corresponding secret key. The inspected PoP aggregator uses a separate domain tag for possession proofs and verifies them before aggregation.

Proof of possession establishes key control. It does not establish a director's appointment, shareholder voting weight, or independent identity. Quorum evaluation must resolve those facts separately. It must reject duplicate identities and enforce the threshold selected by the governing policy, rather than accept a threshold supplied solely by the submitter.

The aggregate message must bind the exact artifact digest and voting context. If every signer endorses one common message, fast aggregation can reduce repeated signature work. The complete verification still includes participant processing, authority checks, and any possession proofs not already authenticated. A claim of constant total cost independent of participant count would omit this work.

Aggregation also changes what evidence must be retained. An auditor needs the signer set, applicable policy, public keys, and key-authority bindings. A compact signature without the signer inventory cannot establish who formed the quorum. An aggregation API alone does not establish use on every watcher or corridor path.

## Zero-knowledge statements

A zero-knowledge proof concerns a defined relation $R(x,w)$ between public input $x$ and private witness $w$. Soundness means an accepted proof supports the existence of a suitable witness, under the proof system's assumptions. Zero knowledge limits what the proof reveals about that witness beyond the public statement.

The public statement determines the business claim. A proof of knowledge of arbitrary bytes does not establish that those bytes encode a valid license. A license claim needs constraints for issuer authenticity, subject binding, validity, and relevant authority. Those constraints must exist in the relation actually checked.

The inspected proof library offers a deterministic mock and a feature-gated Halo2 backend using an inner-product argument. The old description of an available Groth16 production backend is retired: the current library removed that backend. Its policy object rejects mock proofs in production mode, while environment selection can override the compile-time default mode.

The inspected generic Halo2 circuit constrains a sum-of-squares relation over witness elements. A real cryptographic proof of that relation does not automatically prove every named compliance, identity, migration, or settlement predicate. The business circuit needs its own verified constraint coverage and input binding.

Transparent parameters avoid secret setup material for the selected commitment scheme. They do not remove the need to identify the correct circuit and verification parameters. An attacker must not supply an unrelated easy statement and have its valid proof accepted as the required business statement.

Recursive folding combines evidence of multiple computation steps under a specified recursive relation. Its security depends on that relation, transcript binding, and the supported backend. The presence of folding interfaces and mock implementations provides no blanket proof that long operation histories have production recursive proofs.

## Nullifiers and repeat-use prevention

A nullifier is a deterministic public marker for one protected use of a record or entitlement. The protocol binds it to the private witness and the relevant use domain. A verifier can reject a repeated marker while the proof limits disclosure of the underlying identity.

Determinism alone does not prevent concurrent reuse. Two requests can both observe an absent marker before either records it. The normative admission contract requires an atomic check-and-insert at the authoritative persistence boundary. The business effect and marker consumption must also share the required transaction or recovery protocol.

The proof must prevent a caller from selecting another witness that produces a fresh marker for the same entitlement. It must bind ownership, entitlement identity, and use domain. A marker for one ballot or operation should not become an unintended stable identifier across unrelated activities. Domain separation and the precise witness relation govern that property.

An append-only marker set establishes at-most-once admission only under these binding and atomicity assumptions. Exactly-once completion additionally requires successful execution and recovery. A recorded marker followed by a failed effect can otherwise prevent a legitimate retry. The protocol must distinguish duplicate submission, incomplete execution, and final consumption.

These are protocol obligations for private repeat-use prevention. They do not assert that every Mass transaction uses a nullifier or that one generic proof backend implements the required relation.

## Privacy at rest

Field encryption protects selected data while stored outside authorized decryption contexts. The inspected encryptor uses AES-256-GCM with a fresh data-encryption key and nonce for each encryption. A provider wraps the data key. The stored envelope retains the version, nonce, ciphertext, authentication tag, and wrapped key material needed for decryption.

Authenticated encryption detects tampering with protected ciphertext under its key. It does not establish that the decrypted value belongs to the requested database row. The inspected field-encryption calls do not supply row-specific additional authenticated data. An application must therefore establish record binding through its owning storage and authorization contract.

Encryption coverage is a call-site property. A reusable encryptor does not establish that every personal field, replica, backup, search index, or log is encrypted. A deployment needs a field inventory and verification of actual stored representations. Key-provider selection and access control also require direct evidence.

Authorized applications necessarily encounter plaintext during some operations. The threat model must include process memory, error messages, exported documents, and telemetry. Encryption at rest does not prevent disclosure by a caller already authorized to decrypt. Purpose restrictions and least-privilege access govern that boundary.

## Differential privacy for aggregate queries

Differential privacy limits how much an aggregate release changes when one protected contribution changes. It requires a precise neighboring-data relation. For neighboring datasets $D$ and $D'$ and output set $S$, the required bound is

$$\Pr[M(D)\in S]\leq e^\varepsilon\Pr[M(D')\in S]+\delta.$$

The parameters $\varepsilon$ and $\delta$ have meaning only with the mechanism, adjacency definition, and release policy. Graph adjacency is especially important. Removing one relationship differs from removing one person and all their relationships. The sensitivity bound must match the protected contribution.

The inspected graph privacy library includes geometric and discrete-Gaussian noise mechanisms, accounting bands, and a privacy ledger. The ledger charges band upper bounds and maintains accounts keyed by entity and querier. It also provides a separate budget for noisy disclosure of the budget counter.

These are concrete accounting mechanisms. A system-level privacy claim requires proof that every relevant release passes through them. Concurrent requests, retries, alternate endpoints, and colluding queriers can affect composition. A fresh account for each caller is insufficient when the threat model permits one adversary to control several callers.

Parameter admission needs explicit bounds and rejection of invalid numerical inputs. The inspected generic mechanism treats nonpositive sensitivity as requiring no noise and supplies a default delta in one branch. A caller must establish a valid sensitivity and parameter regime before using its output as evidence of differential privacy.

Post-processing an already private output can preserve its privacy guarantee. Publishing extra raw counts, exact budget usage, or identifying metadata alongside it changes the released information. The complete response, logs, and error behavior belong in the privacy analysis.

## Combining privacy mechanisms

Encryption, zero knowledge, and differential privacy protect different observations. Encryption controls access to stored plaintext. Zero knowledge limits disclosure by a proof of a specified relation. Differential privacy bounds information from a randomized aggregate release.

Their composition requires analysis of their shared inputs and outputs. A public document digest can reveal equality even when its payload is encrypted. Repeated proofs can disclose stable identifiers. A private aggregate can become identifying when combined with an exact small-population count. A general compatibility theorem cannot follow merely from using all three mechanisms.

Acceptance evidence must therefore name the protected information, adversary, public outputs, and exact guarantee. It should include invalid-proof rejection, ciphertext tampering, unauthorized decryption attempts, budget exhaustion, concurrent releases, and metadata review. Current source establishes individual mechanisms and important limitations. Broad deployed privacy guarantees remain unverified in this specification.

# Security boundaries and an explicit assurance case

## Assets and adversaries

Mass protects authored intent, organizational authority, regulated state, personal information, cryptographic keys, and the evidence explaining admitted changes. Security review must identify which of these assets each mechanism protects. One control can preserve auditability while an attack still causes availability loss.

The baseline adversary can submit arbitrary requests, replay observed messages, control a tenant, and operate a malicious external endpoint. Separate scenarios grant compromise of a provider, application account, signing key, database credential, build environment, or host. Combining these powers changes which assumptions remain available.

A hostile provider can supply false facts with valid signatures. A hostile tenant can attempt to act on another organization's objects. A stolen signing key can authorize cryptographically valid messages within any policy that still trusts it. A privileged host attacker can alter process behavior and read available plaintext.

The assurance case must state which powers it excludes and why. It cannot assume that an operator workstation is compromised while also assuming its accessible credentials remain secret. It must identify the technical or organizational control that separates those conditions.

## Admission and the write boundary

Authentication identifies the caller under an accepted credential. Authorization decides whether that caller may perform the requested action on the specified subject. Business admission determines whether the action satisfies the operation's current constraints. These decisions must converge on the same intent before persistence.

The inspected authorization guard checks roles, entity scope, operation scope, and capability caveats. Write checks delegate into write authorization. A denied or failed predicate rejects the request. This provides concrete enforcement points, while route coverage remains an integration property that requires separate verification.

The normative write boundary must preserve exact subject binding. A valid approval for one organization cannot authorize another organization's mutation. A valid approval for one document version cannot silently authorize changed content. The admitted preimage and persisted effect must share causal identifiers and content commitments.

Sanctions rejection is terminal under Mass's admission contract. Evidence integrity preserves the decision and its inputs. It does not guarantee that upstream screening data is complete or correct. The assurance argument also needs the actual screening source, freshness rule, matching behavior, and failure policy.

An autonomous agent has the authority delegated to its credential. Its confidence, reasoning, or ability to draft a document cannot increase that authority. Tool output and retrieved text remain data. They cannot replace authenticated user intent or governing policy.

## Network and resource boundaries

An outbound request can become a server-side request forgery when attacker-controlled destinations reach internal services. The inspected webhook guard resolves candidate hosts and rejects forbidden address ranges. The allowed schemes include HTTP and HTTPS. Transport confidentiality therefore remains a separate deployment requirement.

Validation and connection must agree on the destination. DNS rebinding, redirects, proxy behavior, and later delivery retries require checks at the actual connection boundary. A successful URL validation test does not establish that every outbound client uses the validated address or disables unsafe redirects.

Inbound resource controls limit admitted work. The inspected scale guard uses backpressure and connection slots, with typed rejection responses. Its behavior depends on the configured scale state being present. The implementation passes through when that state is absent and exempts its health-probe path.

Resource safety therefore requires configuration and routing evidence. A per-request bound also needs limits on body size, execution time, recursion, query fan-out, and returned data. Per-instance limits do not automatically establish a global bound across replicas. Availability claims need measured behavior under the defined load and failure model.

## Logs, secrets, and operational evidence

The inspected logging formatter redacts values for a defined set of personal-data field names. That control improves structured logging when installed. It does not recognize every personal value embedded in free text, nested debug output, or an unfamiliar field name.

Logging policy should prefer stable causal identifiers and explicit non-sensitive fields. The operator must verify the rendered logs from real failure paths. Testing only a formatter in isolation cannot establish that every subscriber, exporter, and application log uses it.

Secret handling requires an inventory of key purposes and loading paths. Credentials in process memory inherit the host's security. Credentials in hardware-backed providers inherit provider access policies and invocation controls. Deployment evidence must identify the configured backend instead of infer custody from an available adapter.

Security monitoring should preserve attempted actions, denied authority, malformed evidence, and failed persistence acknowledgments. A useful alert names the affected subject and causal sequence without exposing protected content. Monitoring records must themselves have access and retention controls.

## Integrity, availability, and recovery

Append-only evidence can detect a changed history against a trusted earlier root. Detection requires access to that earlier root and a verifier that checks the relevant relationship. An attacker who replaces both local data and its only local commitment can evade a purely local comparison.

Backups preserve recoverability only when restoration works. An encrypted backup without its keys is unavailable. A database backup without associated artifact bytes may restore business rows while losing their evidence. An old backup can also omit revocations and permit replay unless recovery restores the corresponding authority state.

A recovery acceptance test must select an actual acknowledged operation and recover its business state, evidence, and current visibility. It must cover the interruption points between storage systems. Compensated attempts should remain visible as attempts, with their resulting business effect accurately marked.

Cross-deployment isolation requires separate authority and write credentials, plus validation of incoming evidence. A malicious counterparty can withhold cooperation or send false statements. Bilateral signatures establish agreement by keys, while local policy decides whether the receiving deployment may rely on that agreement.

## Proof status and release claims

An assurance case connects a claim to assumptions and evidence. Source inspection can establish that a branch checks a condition. A unit test can falsify an incorrect implementation of that branch. A formal proof can establish a proposition in a model. Runtime evidence can establish what an identified system did in a particular execution.

These forms of evidence support each other without becoming interchangeable. A proved list-append property does not establish filesystem crash recovery. A real signature does not establish authorized business effect. A deployment health response does not establish that its proof backend or external anchor is live.

The historical manuscript asserted general single-limb security, universal portable history proofs, completed external anchoring, and broad privacy compatibility. The stronger defensible account states the exact mechanisms, their current implementation boundaries, and the additional evidence each operational claim needs. The underlying architectural requirements remain explicit.

For a concrete release, the assurance record should bind one integrated build, configuration, principal, organization, intent, and persistence sequence. It should retain the first discriminating failure for every claimed boundary. Tests must include unauthorized and malformed cases, because acceptance-only examples leave the central security claim unexamined.

This chapter describes a source-grounded security design and its verification requirements. It does not claim an external security certification, a complete deployed audit, or proof that all residual obligations are discharged. Those conclusions require their own current evidence against the complete claimed scope.

# Compliance State and Evidence

An entity can satisfy a rule in one jurisdiction while the same domain lies outside another jurisdiction's scope. Combining those findings must preserve both meanings. A passing finding cannot disappear because another evaluator reports that its own rule does not apply.

Mass represents compliance as a structured assessment of a subject, proposed action, jurisdiction, time, and rule set. A subject can be an entity, person, instrument, transaction, or another identified object. The assessment concerns that context. It does not establish that the subject complies with every possible law.

The requirements in these chapters define the intended contract. Implementation boundaries identify the source mechanisms that support it and the obligations that remain. Formal statements apply to their stated models. Source inspection establishes neither deployment nor successful execution of a complete operation.

## Domains and assessment context

A compliance domain groups related obligations. It supplies a stable index for composition, evidence collection, and explanation. Domain membership does not supply the applicable law. The selected jurisdictional rules determine the obligations within each domain.

The domain vocabulary includes AML, anti-bribery, arbitration, banking, clearing, consumer protection, corporate, custody, data privacy, digital assets, and employment. It also includes immigration, insurance, intellectual property, KYC, licensing, payments, sanctions, securities, settlement, Sharia, tax, and trade. These names identify separate evaluation surfaces. For example, KYC establishes relevant identity evidence, while sanctions determines whether the proposed action involves a prohibited subject or relationship.

A domain can apply to one activity and remain irrelevant to another activity of the same organization. Banking requirements do not follow solely from the presence of a bank account. Securities obligations depend on the instrument, offering, participants, and governing rules. Sharia applicability requires an explicit legal or contractual basis. Evaluators must resolve these questions from the operation context and applicable rules.

Let an assessment context be

$$
\kappa=(s,a,j,t,P,F,A),
$$

where $s$ identifies the subject, $a$ the proposed action, and $j$ the jurisdiction. The remaining components identify assessment time $t$, pinned rules $P$, facts $F$, and presented authority $A$. This tuple is specification notation. A particular API can distribute its fields across several signed objects.

An evaluator must bind evidence to the relevant components of $\kappa$. Evidence about another entity does not discharge the present entity's obligation. An approval for one amendment does not authorize a different amendment. A current rule cannot silently replace the rule pinned to a historical decision.

Missing context produces a missing-evidence or invalid-input outcome. The implementation must not synthesize an entity identity, legal exemption, authority, or completed filing to make evaluation proceed.

## Applicability and compliance degree

Compliance degree has meaning only after a domain applies. Define the applicable degree set

$$
C=\{\mathrm{NonCompliant},\mathrm{Pending},\mathrm{Compliant}\},
$$

with the order

$$
\mathrm{NonCompliant}<\mathrm{Pending}<\mathrm{Compliant}.
$$

`NonCompliant` records a detected failure under the evaluated requirements. `Pending` records incomplete evaluation or required evidence that remains outstanding. `Compliant` records satisfaction of the evaluated requirements. These meanings depend on the pinned context and do not constitute permanent properties of the subject.

Applicability is a separate classification:

$$
A=\{\mathrm{Applicable},\mathrm{NotApplicable},\mathrm{Exempt}\}.
$$

`NotApplicable` means the requirement does not apply to the classified subject or action. `Exempt` means a rule removes an otherwise relevant requirement. An exemption needs its own legal basis, scope, and conditions. Neither value means that an applicable requirement has been satisfied.

A valid cell is a tagged value

$$
V=\mathrm{Applicable}(C)\;\sqcup\;\{\mathrm{NotApplicable},\mathrm{Exempt}\}.
$$

Equivalently, a cell pairs applicability with an optional degree. The representation invariant is

$$
\mathrm{applicability}=\mathrm{Applicable}
\quad\Longleftrightarrow\quad
\mathrm{degree}\text{ is present}.
$$

An applicable cell without a degree is invalid. An exempt cell with a degree mixes different judgments and is also invalid. Safe constructors enforce this distinction before composition.

`NotApplicable` and `Exempt` are incomparable classifications. An evaluator cannot select the more favorable label by comparing their numeric encodings. A change between them requires a rule or classification decision with evidence.

## Tensor and evidence record

A compliance tensor associates domains with cells under a fixed context:

$$
T_\kappa:D\longrightarrow V.
$$

A complete tensor addresses every required domain. A sparse transport representation may omit cells, but omission does not establish non-applicability. A consumer must know the required domain set before interpreting a sparse representation.

Each material cell needs supporting evidence. The evidence record should identify the subject, jurisdiction, rule digest, fact references, effective time, evaluator, and authority. It must preserve the reason for an exemption or non-applicability decision. The degree alone cannot distinguish expired identity evidence from an outstanding signature or a prohibited counterparty.

Consider an organization that proposes to issue an instrument. Its corporate assessment may pass because the organization exists and has the required authority. Its securities assessment may remain pending because an offering document lacks approval. A passing corporate cell cannot discharge that securities obligation. The tensor preserves the separate results and their separate producers.

The same principle applies within a domain. A domain can contain several rules, called fibers in the Lex composition interface. A fiber is a rule evaluated against a subject context. The domain result must account for every required fiber. A single required failure blocks the domain even when other fibers pass.

## Content identity and freshness

A tensor digest commits to encoded content. It does not establish the truth of the facts, the authority of the evaluator, or the completeness of the domain set. These properties require separate checks.

For a canonical encoding function $\operatorname{enc}$ and a specified digest function $H$, content identity takes the form

$$
\operatorname{id}(T)=H(\operatorname{enc}(T)).
$$

The encoding contract must specify field names, ordering, scalar representations, and excluded fields. Verifiers must use the declared encoding. A digest from one language representation cannot be substituted for a digest from another representation because both use the same hash algorithm.

Freshness also needs explicit semantics. A fact can have an event time, observation time, and expiry time. An assessment has its own evaluation time. A signed statement observed today can describe an event from an earlier period. A historical assessment must retain that distinction.

The verifier must check the validity window required by the operation. Evidence that satisfied an earlier decision may remain useful for historical verification while failing a new admission check. Reevaluation creates a new decision about the selected historical or current context. It does not rewrite the source event.

## Implementation boundary

The source contains both the orthogonal `TensorValue` representation and a flat `ComplianceState` representation. The flat representation orders `NotApplicable` and `Exempt` between `Pending` and `Compliant`. Its minimum operation remains available and appears in tensor methods.

An orthogonal composition helper converts flat states into structured values, composes them, then projects back. That projection drops provenance flags. It also resolves the non-applicable/exempt obstruction through the flat ordering. Consequently, storage and public responses do not yet uniformly preserve the full structured result.

The flat chain supports valid finite-lattice results within its own model. Those results do not establish that the flat model captures every legal classification. Consumers must identify which representation and composition operation produced a result. A generic statement that all Mass compliance uses a single total lattice exceeds the implemented boundary.

# Composition, Residuals, and Remediation

## Composition on applicable evidence

For two applicable degrees, conservative composition is the chain meet:

$$
a\wedge b=\min(a,b).
$$

Thus `Compliant` composed with `Pending` remains `Pending`. `NonCompliant` absorbs every applicable degree. These rules ensure that adding a passing assessment cannot erase an outstanding failure.

On the applicable chain, meet is commutative, associative, and idempotent. The join $a\vee b=\max(a,b)$ is its lattice dual. These algebraic facts follow from the finite total order. Their operational use still depends on the meaning of the operands.

Join can represent alternatives only where the governing rule permits alternatives. If either of two accredited attestations suffices, an evaluator may implement that rule using a join-like decision. A caller cannot use the same operation to choose between mandatory requirements. The legal rule determines conjunction or alternative satisfaction before the algebra evaluates it.

## Composition across applicability classes

The structured composition operator returns a value with provenance or an obstruction. Denote it by $\operatorname{compose}_V$. Its principal cases are:

| Inputs | Result | Required explanation |
|---|---|---|
| Applicable degrees $a,b$ | Applicable$(a\wedge b)$ | Both assessments contribute |
| Applicable$(a)$ and NotApplicable | Applicable$(a)$ | Preserve mixed applicability |
| Applicable$(a)$ and Exempt | Applicable$(a)$ | Preserve the exemption context |
| Matching out-of-scope classes | That class | Preserve their source bases |
| NotApplicable and Exempt | Obstruction | Reconcile different classifications |

The operator is symmetric in its inputs. Its output is not always another bare cell. A mixed-applicability result carries a provenance flag. An obstruction identifies a domain-context mismatch that the caller must resolve.

For example, jurisdiction $J_A$ can require a license and find the organization compliant. Jurisdiction $J_B$ can classify the same activity outside its licensing regime. Their composition retains the applicable finding from $J_A$ and the non-applicability finding from $J_B$. Returning only `NotApplicable` would conceal the evaluated license.

Suppose instead that two assessments disagree between non-applicability and exemption. The distinction can affect continuing conditions, reporting, or expiry. The structured operator reports that disagreement. It does not invent a legal ordering between the two reasons.

A tensor composition lifts this operation per domain. Its result therefore includes composed cells, provenance, and unresolved obstructions. Every required domain must either produce a valid composed cell or expose a blocking obligation. A consumer must not drop failed cells and present the remaining tensor as complete.

## Why the full structure is not a Heyting algebra

A Heyting algebra requires a total lattice structure with a right adjoint to meet. The applicable chain satisfies that requirement. The full applicability-aware structure does not inherit it merely because its carrier is finite.

The obstruction appears before implication. If `NotApplicable` is incomparable with applicable degrees, a lattice meet must lie below both operands. A signal-preserving composition that returns `Applicable(Compliant)` for that pair violates the lower-bound condition. The structured operation has a different purpose: retain relevant compliance evidence while exposing the applicability difference.

Adding a universal top and bottom creates a bounded lattice for the flat completion of the applicability classes. That construction contains a nondistributive diamond. It therefore does not supply the desired Heyting algebra. Imposing a total order instead destroys the intended incomparability of applicability classes.

The resulting specification is precise. Use lattice and adjunction laws on the applicable fragment. Use the structured composition contract for mixed applicability. Require an explicit reconciliation step when composition reports an obstruction. Do not apply distributivity or reassociation to a mixed result without a theorem for that exact result type and provenance semantics.

## The applicable-fragment residual

For applicable degrees, define the Heyting residual by

$$
a\Rightarrow b=
\begin{cases}
\top,&a\leq b,\\
b,&a>b,
\end{cases}
\qquad\top=\mathrm{Compliant}.
$$

It satisfies the adjunction

$$
a\wedge x\leq b
\quad\Longleftrightarrow\quad
x\leq(a\Rightarrow b).
$$

This formula answers an order-theoretic question. It identifies the greatest operand compatible with an upper bound on a meet. It does not calculate the evidence that raises a pending assessment to compliance.

For example, `Pending` implies `Compliant` equals `Compliant` under this ordering. Yet meeting `Pending` with `Compliant` still yields `Pending`. No operand can raise a fixed value through a minimum operation. Treating the residual as a direct upgrade instruction reverses the operational meaning of the order.

Remediation changes the evaluated facts, discharges an obligation, or changes the applicable rule through authorized evolution. The evaluator then produces a new state. It does not convert a failing conjunction into a passing one by adding an optimistic operand.

The structured residual API extends some cases beyond the applicable chain, but those cases do not establish a global adjunction. Matching out-of-scope classes retain their classification. Moving from an out-of-scope current class to an applicable target reports a cannot-lift obstruction. A non-applicable/exempt mismatch reports a context obstruction. Callers must preserve those distinctions in planning results.

## Planning over executable transitions

Let $S$ denote an assessment state with its relevant facts and obligations. A remediation operation $o$ induces a permitted transition only when its preconditions hold:

$$
S\xrightarrow{o,e}S',
$$

where $e$ records the evidence produced by successful execution. The transition can update evidence, request an approval, or receive an external acknowledgment. Its postcondition must identify what changed and what remains outstanding.

A remediation plan is a sequence of such transitions. Its target is an operation-specific acceptance predicate, not necessarily a tensor filled with `Compliant`. An explicitly exempt domain can satisfy an operation's requirements without becoming applicable. Forcing every domain to the applicable top would itself change the legal classification.

If a planner minimizes cost, it must specify the graph, edge weights, and constraints. A shortest path exists only when the target is reachable within those constraints. Nonnegative costs allow ordinary Dijkstra search for an unconstrained shortest-path problem. Additional cumulative constraints require an algorithm that preserves the necessary state at each search node.

Mass's current compliance manifold implementation stores jurisdiction nodes and corridor edges. Edges carry transfer fees, processing times, and related costs. The path finder excludes inactive routes and applies configured limits. It returns no path when the selected search cannot reach the target.

This implementation is not a search across every possible tensor state. It does not prove that a route can execute every legal or economic operation along its edges. It also does not establish a general optimality theorem for all combinations of cumulative constraints. A route recommendation must undergo current admission checks at each real execution boundary.

## Failure and implementation boundary

A planning result must distinguish missing evidence, prohibited action, classification obstruction, unavailable route, and exhausted search constraints. These outcomes require different responses. A sanctions failure cannot become an evidence-collection task unless the governing process permits correction of the underlying identification or facts.

The applicable algebra and structured operator have source implementations and scoped formal models. Their existence does not prove that every consumer preserves the same semantics. Legacy projection remains a material limitation. Verification must compare the actual operation's composition path with the algebra claimed for that operation.

# Jurisdictional Composition and Recognition

## Simultaneous jurisdictional state

An organization can maintain legal relationships in several jurisdictions at once. A harbor is an identified jurisdictional relationship with its own registration, authority, rules, and evidence. Adding a harbor does not remove the obligations of an existing harbor.

For active harbors $J$, let $T_j$ be the assessment under jurisdiction $j$. The composed decision must retain the jurisdictional assessments and their provenance. It must also identify which harbors govern the proposed action. Registration somewhere does not make every local rule applicable to every activity everywhere.

The acceptance condition is a conjunction of the required jurisdictional decisions, after permitted recognition and context translation. Where structured cell composition is defined, the system can compute a combined tensor. Where it is obstructed, it must preserve the separate decisions and name the unresolved relationship.

An empty jurisdiction set is not evidence of universal permission. The caller or operation contract must establish the intended jurisdiction and subject scope. A missing harbor record cannot silently become an unrestricted default jurisdiction.

## Recognition as an explicit admission rule

Recognition lets one jurisdiction admit specified evidence produced under another jurisdiction's authority. It needs a source authority, receiving authority, evidence class, subject scope, validity conditions, and legal basis. A corridor supplies the operational relationship through which such evidence can travel.

Let $R_{B\to A}$ be the recognition policy by which $A$ admits evidence from $B$. Let $\phi_{B\to A}$ be the permitted translation into $A$'s assessment context. The receiving decision uses

$$
\operatorname{compose}_V\bigl(T_A,\phi_{B\to A}(T_B)\bigr)
$$

only after the recognition gate accepts the evidence. This notation does not imply that every policy defines a total translation. Rejection, missing coverage, and undecidable applicability must remain explicit outcomes.

Recognition of identity evidence does not recognize a payment authorization. Recognition of one license does not recognize every license issued by the source. The receiving authority remains responsible for the meaning and permitted use of the imported evidence.

A translation must preserve required failures. It cannot map a sanctions rejection into a passing result because the receiving vocabulary lacks a matching category. When exact translation is unavailable, the receiving jurisdiction must require local evaluation or refuse the proposed use.

## Paths and transitive evidence

A path through several corridors does not automatically extend a bilateral recognition agreement. Each segment must permit the relevant evidence class and forwarding behavior. The operation must retain the original issuer and the transformations applied along the path.

The current corridor composition source defines per-domain transitive-evidence policies. Sanctions requires evaluation at each applicable hop rather than transitive trust. A path can fail because an intermediate jurisdiction lacks the required domain evidence, even when both endpoints pass their own checks.

No domain may receive broader recognition from path construction than its direct policies allow. In particular, a route optimizer must not create recognition rights. Cost and latency select among legally admissible routes. They do not determine admissibility.

## Provenance and conflict

A combined decision needs more than the name of a winning jurisdiction. Several jurisdictions can contribute the same restrictive degree for different reasons. A later correction may affect only one reason. Preserving only the minimum degree would prevent a verifier from reconstructing the remaining obligations.

A provenance record should retain the domain, source jurisdiction, rule and evidence references, original classification, translation policy, and composition result. Mixed applicability must remain visible. The result should also identify the subject and operation whose scope made each contribution relevant.

Conflict resolution proceeds within the authority and priority rules that govern the conflict. A more recent timestamp does not automatically defeat an older legal obligation. A larger number of agreeing evaluators does not repeal a controlling rule. A tribunal or regulator decision needs an authority witness and an applicable scope.

Sanctions rejection is terminal for the proposed action under the evaluated context. The execution path must refuse the mutation. Neither ordinary exceptions, market demand, nor another jurisdiction's passing assessment can override that rejection. An authorized correction of evidence produces a distinct evaluation with its own history.

## Reproduction and implementation boundary

A verifier can reproduce deterministic composition when it has the exact inputs and the same defined operations. Reproducing the upstream assessments additionally requires pinned rules, facts, authority evidence, external observations, and evaluator semantics. Determinism of a finite meet alone does not prove determinism of that complete pipeline.

Corridor state-machine code and formal models specify quorum, rejection, terminal states, and recovery behavior. Those models have explicit assumptions about signatures and verdict consistency. Their proofs do not establish delivery, persistence, or finality in a deployed network.

The operational acceptance test must bind the participating jurisdictions, admitted evidence, signed verdicts, durable state, and recovery outcome to one transaction. A configured corridor or a compiled model is insufficient evidence that a cross-jurisdictional operation completed.

# Lex: Rules, Time, and Authorized Judgment

Lex expresses jurisdictional rules as typed terms. It separates computable conditions, defeasible exceptions, temporal reasoning, and decisions that require an identified authority. Its public language reference governs the documented executable boundary. The parser's ability to represent a term does not establish that a checker, compiler, or runtime can execute it.

## Terms, types, and the prelude

A typing judgment has the form

$$
\Gamma\vdash t:\tau,
$$

where $\Gamma$ supplies the available bindings and assumptions. The judgment states that term $t$ has type $\tau$ under that context. Lex uses terms as types and includes dependent function and pair forms in its core syntax.

The language distinguishes ordinary type universes, propositions, rule universes, and temporal sorts. Level discipline prevents a rule from using an unauthorized self-reference through the same rule level. Explicit effect rows identify actions such as reading, writing, attesting, invoking an oracle, or requesting discretion.

A prelude supplies named domain types, constants, and operations. Its identity forms part of the interpretation context. A term that type-checks with one prelude cannot automatically execute against another prelude with different host meanings.

Elaboration resolves surface names into core terms and binding indices. Type checking establishes compatibility with the supplied context. Admissibility checking determines whether the term belongs to a supported fragment. These are distinct checks. An authoring command that performs admissibility checking does not thereby perform every typing or semantic check.

A legal-source reference must remain associated with the rule. The reference identifies the provision being encoded. It does not prove that the encoding correctly expresses the provision. Legal interpretation and technical checking address separate obligations, and both must have accountable owners.

## Defeasible rules

A defeasible rule specifies a default conclusion and exceptions that can defeat it. Each exception has a guard, result, and priority. A guard determines whether the exception applies in the current context. Priority determines which applicable exception controls when the admitted fragment permits several candidates.

For a base result $b$ and admitted exceptions $(g_i,e_i,p_i)$, the intended deterministic selection is

$$
\operatorname{result}=
\begin{cases}
e_k,&k\text{ is the selected highest-priority satisfied exception},\\
b,&\text{no exception is satisfied}.
\end{cases}
$$

The priority relation must have a defined resolution for every admitted overlap. Equal or incomplete priority data cannot be resolved by thread scheduling or hash-map iteration. The public compiler's compact input representation orders exceptions by descending priority and ascending source position. It rejects duplicated ordering keys.

The reference term evaluator propagates an unevaluable guard as an error. This behavior matters when evidence for an exception is missing. Treating the guard as false would silently discard a potentially controlling legal exception.

An exception is not an unrestricted override facility. Its authority and scope come from the admitted rule set. A general exception cannot override terminal sanctions rejection. A rule author must encode that boundary in the applicable admission and execution contracts.

## Frozen and derived time

Lex separates frozen source time from derived time. Frozen time records the historical transition context. Derived time represents a later interpretation, such as a permitted tolling or savings transformation.

The temporal interface exposes a directed lift from frozen time into derived reasoning. It does not expose an object-language coercion that rewrites derived time into frozen source time. The intended information flow is

$$
\mathrm{Time}_0\longrightarrow\mathrm{Time}_1.
$$

A derived assessment must retain the source event and the witness for the derivation. If a later rule changes the interpretation of a deadline, the original event remains unchanged. The new result states the governing rule and derived deadline used for the current decision.

The temporal checker examines explicit temporal forms and rejects invalid stratification. A temporal theorem concerns those forms and the modeled reduction relation. It does not prove that every database timestamp, external clock, or caller-provided string follows the same discipline.

Operational verification must therefore bind the formal temporal object to the event and rule history used by the host. A syntactically valid derived-time term cannot authenticate the external event that it describes.

## Authority-relative interpretation

Some conclusions depend on the authority or tribunal under which a rule is interpreted. Lex represents that context explicitly. A coercion between authority contexts requires a witness for the permitted bridge.

A bridge must identify the source context, receiving context, object being translated, and authority for the translation. A generic function that changes a label does not supply recognition. The receiving evaluator must check the witness and scope before using the result.

Formal bridge coherence can establish that defined translations compose consistently. It does not establish that a real tribunal recognizes the source authority. That external recognition remains an input grounded in the governing legal instrument and authenticated policy.

The same separation applies to model-assisted interpretation. A model can propose a rule or explanation. Its output acquires authority only through the applicable review, attestation, and admission process. Model confidence cannot replace an authority witness.

## Typed discretion holes

A discretion hole names a judgment that mechanical evaluation cannot supply by itself. Its type specifies the required result. Its authority identifies who may supply that result. Its scope restricts where the result can be used.

For example, a rule can require an authorized assessment of whether specified controls are adequate. The surrounding mechanical checks can establish document presence, identity, and signature scope. They cannot manufacture the substantive judgment merely because the operation needs it.

A fill must bind the hole identity, result, signer, subject, jurisdiction, and relevant temporal scope. Admission must verify both type compatibility and authority. A nonempty signature field is insufficient. Verification must authenticate the exact payload under the correct key and policy.

Public Lex distinguishes structural fill validation from cryptographic fill admission. The plain fill path checks witness structure. The verified fill path invokes a supplied `PCAuthVerifier`. The public implementation includes an HMAC verifier. A deployment requiring asymmetric signatures must supply the corresponding verifier and use the verified path.

An unfilled hole remains an obligation. The strict executable admissibility checker rejects hole and fill forms. The residualized admission mode accepts selected frontier forms only while recording obligations such as fill-time authority and signature verification. Acceptance in that mode cannot be reported as a fully mechanical verdict.

## Certificates and obligation discharge

A proof obligation is a condition that must be established before a rule can support the claimed result. The decision procedure can prove the condition, refute it, or leave it undecided. Only a proved result is a discharge.

The certificate builder records the rule digest, jurisdiction, legal basis, verdict, discharged obligations, issuance time, and optional subject and typed scope. The certificate digest commits to its canonical content. A consumer must verify the digest and the required scope bindings before relying on the certificate.

The public sealing interface rejects refuted and undecidable decision results. Its structured witnesses improve the construction boundary, but a serialized object remains untrusted input. Deserialization, transport, or a caller-supplied certificate must not bypass the checks required by the receiving host.

A certificate's type and digest do not provide public-key authentication by themselves. The issuer's signing layer must authenticate the claim where the operation requires an authoritative attestation. The verifier must also check that the certificate covers the exact rule and operation, including the subject and jurisdiction.

## Execution and formal boundary

Public Lex contains several distinct surfaces: parser and elaborator, strict and residualized admission, reference term reduction, runtime predicate evaluation, and frontier calculus types. Their scopes overlap but are not identical. The fiber-composition convenience function currently emits `Pending` results without certificates.

The formal development contains scoped closed results for temporal non-regression, pack reevaluation, receipt composition, quorum structure, and admission-envelope structure. Full-calculus progress remains conditional on confluence and match exhaustiveness. Preservation retains a substitution premise. Full unconditional type safety and normalization are not established by those conditional statements.

A theorem ending in a closed proof can still require an unproved premise. A model's lack of admitted proof commands does not discharge named propositions supplied as hypotheses. The specification preserves those hypotheses when describing the theorem's operational significance.

The canonical public contract and proof scope are available in the [Lex language reference](https://github.com/momentum-sez/lex/blob/master/docs/language-reference.md) and [formal documentation](https://github.com/momentum-sez/lex/blob/master/formal/README.md). A deployment must identify its actual dependency revision and admitted fragment.

# Op: Typed Economic Programs

Op describes workflows that perform economic actions through an embedding host. It gives those actions types, effects, ordering constraints, resource discipline, contracts, and gas accounting. The host supplies the concrete primitive behavior and durable execution services.

## Program and host boundary

An Op program contains statements, steps, expressions, metadata, and contracts. A typing judgment includes an effect row:

$$
\Gamma\vdash e:T\;!\;E.
$$

The result type $T$ describes the value or resource produced. The effect row $E$ describes effects that execution may perform. Combining expressions combines their effects according to the language rules.

The public host interface accepts a primitive call with named arguments and an ambient jurisdiction. It returns either a completed value or a waiting outcome with an event identifier and resume token. It can also reject a call for policy, argument, transient, or permanent failures.

A host must discharge declared safety predicates against the actual context. The default safety implementation refuses undischarged predicates. A test host that echoes arguments and accepts every predicate cannot establish production execution.

Host determinism requires recorded external observations. Given the same program, inputs, policy, and observation transcript, replay must reproduce the specified result. A live network call that returns a new answer is a new observation. The host cannot call that behavior deterministic replay of the earlier execution.

## Effect rows and sanctions dominance

Effect rows compose by set union. The public vocabulary includes sovereign writes, identity mutation, fiscal transfer, sanctions checks, governance requests, document generation, external reads, proof emission, and event waits.

Set membership alone does not establish safe order. A program that contains a sanctions check after a payment still contains both effects. The analyzer must establish that every reachable write-class effect has a dominating sanctions check on its execution path.

For a write site $w$ and required check $c$, dominance means that every admitted path to $w$ passes through $c$. Branch analysis must preserve that property. A check in one alternative does not protect a write in another alternative. A check on an unrelated subject does not satisfy the operation's runtime subject binding.

The public analyzer inspects both declared steps and expression-level primitive calls. Unknown primitives cannot default to pure behavior. A caller-provided signature cannot justify an effect absent from the canonical primitive contract.

Entity creation has a deferred-subject case because the final entity identifier does not yet exist. This exception requires the host to preserve the authorized creation context and subsequent checks. It does not permit an arbitrary existing subject to bypass screening by labeling the action as creation.

A source-level dominance check establishes program structure. Runtime admission must still verify the screening result, relevant subjects, freshness, and terminal rejection behavior. Neither layer replaces the other.

## Suspension and completion

A suspended step carries an awaited event and result type. Suspension is a valid execution state. It records that the required effect or external acknowledgment has not yet completed.

A durable continuation must bind the program and input identities, completed work, authority, waiting condition, and relevant state. The callback must identify the continuation it can resume. An unrelated event, expired authority, or mismatched subject must not advance the operation.

The distinction between completed and waiting outcomes must survive every adapter. An HTTP acceptance response can acknowledge a request while the underlying economic action remains pending. A provider job identifier proves only that a job was accepted unless the provider contract states otherwise.

The execution engine must record completion only after the required effects and acknowledgments exist. A document-generation job, signature ceremony, payment instruction, and regulator filing can each have different completion criteria. Op's type can carry those distinctions, but the host must implement them.

## Durable continuation contract

A durable continuation is the checked machine state at a suspension boundary. It must contain enough information to resume the remaining computation directly. Re-executing the source program from its root is not restoration, even when an implementation attempts to suppress repeated effects.

The required continuation binds the checked program and runtime profile to a host identity, instance identity, and nonce. It also binds the execution ordinal, logical work consumed, control state, environment, frames, signed history, accumulated effects, and pending request. These fields prevent a stored control position from being combined with another execution's authority or values.

Let $K$ be a checked continuation and $\operatorname{encode}_p$ its encoding under profile $p$. Before accepting transferred state, the receiving host must establish

$$
\operatorname{decode}_p(\operatorname{encode}_p(K))=K.
$$

The equality concerns the complete checked state. A digest match for an incomplete projection does not establish the required round trip. Profile identity must cover the semantics needed to interpret the state. A runtime-source digest alone does not attest the host adapter, build, key custody, or storage configuration.

Admission of a continuation event must authenticate the stored state and check current authority for the requested action. Historical authorization proves that earlier work was admitted. It does not authorize every future action after expiry, revocation, or transfer.

The host must atomically record authority consumption, the resulting continuation, and the command receipt. Invalid admission must leave pending work unconsumed. An exact retry returns the committed receipt without executing the runtime again. The retry identity must bind the command payload, so a different command cannot reuse that receipt.

Restoration and transfer must create no new dispatch or discharge. The restored history records what occurred. The pending request records what still requires admission. Economic effects need their original delivery identities, reservations, and acknowledgment states so that a transfer cannot duplicate an unacknowledged obligation.

When execution moves between hosts, the source must fence further initiation before the successor becomes active. The transfer must include admitted preparation changes and the exact authoritative state cut. Exactly one successor may own the execution generation. Every later action requires that generation and action-specific current authority.

This is the normative continuation contract. Reference constructions motivate it, but complete production refinement is not established here. Whole-state rollback requires an external monotonic freshness anchor. Cloned stores require exclusive custody or effective fencing. Authenticated storage without those properties cannot distinguish the latest legitimate state from a coherent older copy.

## Compensation and resource discipline

Compensation is an authorized action that addresses the consequences of an earlier effect. It is not a claim that history can be erased. Releasing a reservation can compensate for a failed allocation. A refund creates a new economic event rather than deleting the original transfer.

An Op step can declare a compensation branch where its effects permit compensation. The analyzer rejects compensation without a compensable effect. It also rejects a continue-on-failure policy that would conceal a failed sovereign write.

The host must preserve the order and outcome of compensation. A failed compensation remains a recorded obligation. Retrying it needs the original causal identity and an idempotency contract. Completion of the forward workflow cannot be inferred from successful compensation.

`Linear<T>` represents a resource whose permitted use is constrained by the type system. `Locked<T>` represents a resource reserved for a transfer decision. The modeled lock has explicit commit-transfer and release-lock eliminators. Copying a serialized handle must not create another spendable resource.

The public checker implements resource-use checks, while the formal full-AST linearity and lock-duality results remain open. Durable enforcement additionally requires the host's transactional ownership and lock state. A compile-time resource discipline alone does not prevent two independent requests from racing on the same database row.

## Structural and extensional gas

Structural gas accounts for the program's syntactic work. Extensional gas accounts for work that depends on runtime data, such as collection size or host-call volume. The program and host must identify which schedule governs each quantity.

A meter maintains consumed amounts and configured limits. A charge succeeds only when the resulting amount stays within the relevant limit. The public meter returns a gas-limit error when a charge would exceed the limit. That error does not itself establish a persisted suspension point or a resumable continuation.

A cardinality certificate can bind an assumed data-size bound. The host must check the certificate's origin, scope, and relationship to the actual data. A claimed list bound does not constrain an unrelated collection or later provider response.

A structural estimate is not a runtime cost proof for every host. The formal gas result establishes termination for an abstract relation with a strictly decreasing natural-number measure. Instantiating that relation with the complete Op semantics remains a separate obligation.

Gas accounting also differs from economic pricing. A deployment can charge money for execution, but price changes must not silently change the language's admission semantics. Program metadata must identify the schedule used when bounds and digests were produced.

## Contracts and proof bundles

Contracts attach requirements and guarantees to a program or step. A Lex rule reference identifies the rule and the structural discharge requirement expected from the program. The binding must include the relevant pack version and jurisdictional scope.

Structural discharge checks that the program carries the required witness shape. It does not prove that every host execution produces a legally sufficient certificate. Full joint Lex–Op discharge soundness remains an open formal obligation.

A proof bundle should bind the program, inputs, admitted authority, rules, execution transcript, resulting facts, and required evidence. The bundle must identify which parts support exact replay and which depend on attested external observations. Optional fields must remain absent when their producer has not run.

Two bundles can be compared only under a defined equivalence relation. Byte equality requires deterministic encoding and identical committed inputs, including time and external observations. A claim of semantic equivalence needs a separate definition. The book does not infer universal proof-bundle equality from compiler success.

## Implementation boundary

Public Op supplies the language structures, checker, effect analysis, gas primitives, compiler components, and host contract. Its core exports do not currently include the complete evaluator described by some module introductions. A separate reference interpreter covers the compiler's supported expressions.

Mass has an adapter evaluator and compilation path with its own representation. Its conformance profile explicitly retains migration residuals for canonical encoding, primitive-registry parity, and gas-schedule parity. Public language ownership therefore does not imply that every Mass-produced program is portable public Op without qualification.

The public formal development contains closed fragments for effect algebra, bundle append behavior, abstract gas decrease, and smaller calculi. It does not establish full-AST progress, preservation, parallel confluence, or compiler correctness. The [Op formal scope](https://github.com/momentum-sez/op/blob/main/formal/README.md) states these boundaries.

# From Rules to Executed Evidence

A complete regulated operation connects a rule to an authorized execution and a durable result. Each boundary must preserve the identities needed to verify the next boundary. A successful parser, signed payload, or persisted response establishes only its own part of that chain.

## Admission stages

The normative pipeline begins with the exact rule, program, subject, inputs, and authority presented for execution. It resolves the applicable rule set and checks content identities before evaluating their meaning. Unresolved references, unsupported encodings, or mismatched scope block admission.

Lex admission establishes the supported rule fragment and exposes any remaining discretion or proof obligations. Compilation then lowers only the admitted computational content. Op checking establishes the required types, resource rules, and effect constraints for the emitted program.

The host checks current authority and context before executing a material effect. It records the actual result and required acknowledgments. The mutation boundary must bind the authorized action to the durable change and its evidence. Completion depends on the operation's required effects, rather than the existence of a response envelope.

The stages are logically ordered but need not correspond to separate network calls. An implementation can combine checks in a transaction or reuse verified immutable artifacts. Reuse is valid only when the artifact's context, revision, authority, and freshness remain suitable for the new decision.

## Compilation boundaries

The public Lex-to-Op compiler consumes its own compact `LexTerm` representation. Its admitted forms include first-order values, variables, finite matches, defeasible rules, sanctions checks, filled holes, and registered prelude calls. Its constructor set excludes several full Lex forms by construction.

The compiler first checks admissibility, emits an Op program, and runs the public Op checker over that output. It returns a structured error for unsupported calls, unbound variables, unsuitable match coverage, or rejected output. These checks provide a concrete executable boundary for the represented fragment.

Mass also has a lowering path from the larger Lex term representation into its adapter expression representation. Some forms become named helper calls. Producing a call name does not establish that the host implements its semantics. Admission must resolve the helper against the actual host and reject an unsupported call.

The desired compiler contract is semantic preservation over the precisely admitted domain. If $L$ is an admitted rule and $\llbracket L\rrbracket$ its program, corresponding execution observations must agree under compatible contexts and hosts. The relation must include errors, authority requirements, suspension, and effects where those are in scope.

Current fragment results do not prove that contract for the full language pair. Extending an AST match to cover another constructor is not a proof of semantic preservation. The extension must supply the lowering rule, receiving-host meaning, admission conditions, and corresponding verification evidence.

## Verdict and proof roles

A verdict records the decision and its reasons. A proof envelope binds a claim and issuing context to evidence that a verifier can examine. The proof may embed a verdict or reference it by content identity. If both appear, the embedded verdict must reproduce the referenced digest.

The claim identity must remain distinct from the program identity. A program can execute repeatedly with different inputs and subjects. The resulting claims must bind those particular executions. Likewise, an authority-chain digest identifies the authority presented, rather than the truth of the result.

The implemented Mass proof structure carries subject, sovereign domain, issuing authority class, epoch, claim digest, optional verdict binding, and reproducibility class. It also carries an optional authority binding, admissibility fields, residuals, and signature. Transport fields can contain immediate consumer-facing output. The signature covers a defined canonical body rather than every transport field.

A verifier must identify that signed body. It must not treat an unsigned output field as authenticated merely because it appears beside a signature. A referenced artifact must be retrieved and checked against its digest before it contributes to the decision.

The source's admissibility helper checks structural conditions, including a verdict reference, complete sovereign domain, empty blocking fields, and a suitable signature representation. Cryptographic signature verification is a separate operation. Trust policy, scope, freshness, and referenced content checks remain necessary for reliance.

## Persistence and external acknowledgment

Durable mutation, authenticated inclusion, and external anchoring are separate events. A database commit proves that the database accepted a transaction under its configured durability contract. An inclusion proof establishes membership under a particular authenticated root. An external anchor supplies evidence about a root's submission and acceptance by another system.

An operation claiming all three must produce and bind all three. If an anchor remains pending, the response must report that state. It cannot use a locally recorded anchor object as evidence of completed external submission.

The public authenticated-storage components provide MMR operations, WAL replay, and disk recovery. Their typed graph API remains unimplemented. Migration-lens registration stores metadata and does not verify a transformation's bijection. Consequently, a schematic Lex–Op–storage diagram cannot establish complete graph persistence, historical query preservation, or recurring external anchoring.

The normative storage contract remains stronger: retain the original evidence and schema identity, verify claimed inclusion, preserve historical interpretation, and expose missing producers. A completed operation must satisfy the evidence requirements of its declared completion class. Implementation gaps remain explicit obligations against that contract.

## Reproduction classes and evidence limits

Exact replay requires the same admitted program, encoding, input facts, rule and prelude identities, host semantics, and observation transcript. Attested external facts can support verification without permitting independent reproduction of the underlying external event. A discretionary decision can be authenticated without becoming a mechanical derivation.

These distinctions must survive in the result. A verifier should be able to determine which statements it can recompute, which signatures it can verify, and which external authorities it must recognize. A proof envelope cannot improve the evidentiary class of its inputs by renaming them.

Execution evidence must identify the integrated program and runtime profile, configuration, subject, authority, causal request, and durable result. Tests against an echo host do not establish provider execution. Formal model proofs do not establish database behavior. A successful database write does not establish an externally accepted legal filing.

# Authoring Rules and Operations

## Establish the rule before the workflow

An author begins with a concrete obligation and its legal basis. The author identifies the relevant subject, action, jurisdiction, effective period, conditions, exceptions, and competent authority. The resulting rule must state what evidence establishes each condition.

Consider a hypothetical entity-record amendment. Its operation contract requires an authorized amendment request, the governing approval, a signed document, and an authority receipt where the selected rules require filing. This example specifies a workflow shape. It does not assert the legal requirements of any named jurisdiction.

The author must distinguish approval of the amendment from acknowledgment of the filing. A board approval cannot stand in for a regulator receipt. A generated document cannot stand in for the signers' executed document. An uploaded receipt cannot stand in for a verified receipt about the correct amendment.

These distinctions determine the types and predicates before the author chooses an operation sequence. Combining them into a generic success flag would remove the evidence needed to evaluate completion.

## Build a typed rule and its evidence requirements

The amendment rule binds an entity $s$, proposed amendment $m$, approval $a$, document $d$, and optional receipt $r$. Its required predicates are the conjunction of these three expressions:

$$
\operatorname{about}(a,s,m)\land\operatorname{authorized}(a,s,m)
$$

$$
\operatorname{documentMatches}(d,s,m)\land\operatorname{signaturesValid}(d)
$$

$$
\operatorname{screeningPasses}(s,m)\land\operatorname{receiptCondition}(r,s,m).
$$

This is specification notation, not executable Lex syntax. Each predicate needs a supported prelude operation or an explicit authority obligation. The receipt condition must distinguish a rule that does not require filing from a required receipt that remains absent.

The author then defines adversarial cases. An approval for another entity must fail. A signature over a different document digest must fail. A receipt with the wrong amendment identity must fail. An unknown screening result must remain pending or produce the specified error. A sanctions rejection must stop the proposed mutation.

If the rule includes discretion, the author declares the hole's type, authority, and scope. The operation must expose the outstanding decision to the responsible authority. It must not replace the hole with a default Boolean value.

## Use authoring tools within their scope

The public Lex CLI provides parsing, elaboration, admissibility checking, and authenticated source bundles. Its `check` command parses the source and calls the admissibility checker. It does not establish every full typing, legal interpretation, or execution property described in these chapters.

The CLI's `sign` operation currently uses HMAC-SHA256 over the source content digest. The verifier needs the corresponding shared secret. This provides symmetric authentication within that trust arrangement. It is not public-key signing for an independent verifier that holds only a public key.

Production rule publication must use the signing authority and cryptographic suite required by the deployment. Hardware custody, asymmetric verification, approval ceremonies, and publication authorization require their own implemented controls. They cannot be inferred from a command named `sign`.

Authors must record the exact toolchain, prelude, and admitted fragment used for a published rule. Compiler and runtime identities belong in the artifact's machine-readable metadata. The human specification names the contract without freezing a stale dependency revision into prose.

## Assemble the operation

The operation begins by resolving the subject and amendment under the caller's authority. It obtains the required governance decision, produces the correct document, waits for executed signatures, and obtains any required external receipt. Only then may it perform the final state change that the contract permits.

Independent read-only preparation can run concurrently. Dependent actions must wait for their required evidence. A filing step cannot proceed with an unsigned document merely because document generation completed. A final mutation cannot proceed because the filing request returned an acceptance identifier.

The operation definition must specify waiting outcomes, retries, compensation, and terminal failures. Each provider interaction must carry a stable causal identity. A timeout means that the outcome is unknown unless the provider contract proves otherwise. Retrying an unknown outcome requires an idempotency or reconciliation mechanism.

When an approval or receipt arrives, the engine must validate its subject, action, digest, authority, and current admissibility before resumption. It must restore the checked continuation under the durable continuation contract. It must not restart earlier effectful steps to rediscover the wait point.

## Publish, execute, and verify

Publication requires a content-addressed rule and program, compatible policy and prelude identities, validated operation contracts, and the authorized publisher's signature. The receiving deployment must verify those bindings before exposing the operation for execution.

A publication success response establishes catalog admission only. It does not establish that an organization completed the operation. Execution acceptance must cover the actual subject, authority, required effects, durable acknowledgments, and final decision.

Verification should follow the failure boundaries identified during authoring. Check a valid path and the material refusal paths. Preserve the original signed evidence and causal identifiers. Inspect the final durable state and required external acknowledgments before reporting completion.

For the amendment example, the acceptance record must connect the requested amendment to its approval, executed document, any required receipt, resulting entity state, and proof. If the receipt remains outstanding, the operation remains outstanding. If the evidence conflicts, the decision must expose that conflict and preserve the original records.

## Remaining proof obligations

The full design requires a semantics-preserving path from admitted Lex rules through Op execution to durable, authority-bound evidence. It also requires safe continuation transfer, complete provenance, and verification of every externally claimed acknowledgment. These remain requirements even where an implementation currently covers only a fragment.

The unresolved formal work includes full-calculus Lex confluence and preservation premises, full-AST Op type and effect soundness, joint discharge soundness, and host refinement. The unresolved operational work depends on the particular deployment and route. A bounded implementation result must state its scope while retaining the complete target contract.

# Modules and governing packs

A regulated operation needs an identifiable basis for every decision. It needs the applicable rule, the authorized decision maker, and the evidence that satisfies the rule. Mass packages these inputs so an organization can select, review, and retain the configuration that governs its work. A pack connects authored institutional content to a typed consumer. Its presence alone does not establish legal authority or operational completion.

The configuration model distinguishes a module, a pack, a profile, and a zone. A **module** groups related institutional artifacts behind a manifest. A **pack** supplies content with a family-specific interpretation and identity. A **profile** selects modules, versions, variants, and parameters for a deployment class. A **zone** binds an operational deployment to its jurisdiction, profile, trust configuration, and corridor relationships.

These objects solve different problems. A corporate module can contain forms, reporting schemas, and legal text. A procedurepack can describe an executable share issue. A profile can select the module for a financial center. A zone can bind the resulting operation to a particular authority and evidence policy. None of these substitutions makes a form an issued instrument.

## Module interfaces

The module manifest requires an identifier, version, kind, and description. It can declare variants, dependencies, provided interfaces, and typed parameters. An interface declaration can include its artifact location, media type, description, and operation identifiers. Dependencies can use a module identifier alone or an object with a version constraint and explanatory notes.

The manifest schema recognizes parameter types such as string, integer, boolean, enumeration, object, array, duration, money, and jurisdiction reference. Defaults and allowed enumeration values can accompany these types. A module author must distinguish a default configuration value from an authored transaction value. A default reporting window can be valid configuration. A fabricated shareholder identity cannot satisfy an operation's required input.

The manifest gives discovery tools a common structure. It does not prove that every declared interface has an executable handler. The manifest schema permits additional top-level properties, while several nested structures reject unknown fields. A parser can therefore accept an extension that no consumer interprets. Acceptance requires checking the actual consumer for each field that carries legal or operational meaning.

Dependencies also require semantic review. A declaration that names an identity module cannot establish that an identity verification has occurred. It states a dependency on a capability. A concrete operation still needs an authenticated subject, the required verification evidence, and the applicable validity interval.

## Pack families

Mass uses several pack families because legislation, operational rules, evidence, and procedures have different meanings and update cycles. The version registry recognizes the following family names.

| Family | Principal content | Consumer obligation |
|---|---|---|
| Lawpack | Legal sources, provenance, rule bindings | Identify the text and rules that support a decision |
| Regpack | Regulatory data, deadlines, regime selectors | Apply selected data with its scope and freshness |
| Licensepack | License types, categories, registry records | Distinguish requirements from verified holder status |
| Governancepack | Authority, delegation, quorum, notice, reserved matters | Resolve who can decide and under which conditions |
| Obligationpack | Triggers, deadlines, escalation, discharge evidence | Track the duty through satisfaction |
| Adapterpack | Systems, transport, authentication, evidence contracts | Bind dispatch to a supported external effect |
| Procedurepack | Steps, parameters, waits, gates, compensation | Execute the declared operation contract |
| Corridorpack | Recognition, portability, exchange, migration terms | Apply the receiving party's acceptance conditions |
| Templatepack | Typed slots and an endorsed plan structure | Validate values and the expected template authority |
| Modelpack | Model identity, output schemas, replay declarations | Apply invocation policy without inventing reproducibility |

This table defines family responsibilities. It does not impose one universal binary envelope or signature scheme. Each loader and compiler has its own contract. The common design principles are explicit identity, structured content, declared provenance, and controlled interpretation.

## Lawpacks: source text and executable interpretation

A lawpack associates a jurisdiction and legal domain with a dated source set. Its manifest records source documents, normalization information, rule references, capability sidecars, and statutory citations. A capability sidecar supplies metadata paired with a rule. The rule-binding helper resolves declared rule and sidecar files and fails when a declared file is absent.

Akoma Ntoso provides a structured representation for legislative documents. Sections, subsections, schedules, and identifiers remain available to the authoring process. Structure matters because a rule should identify the provision from which it derives. It also lets an author distinguish the original source, a normalized representation, and an executable interpretation.

These representations have different evidentiary roles. The original publication establishes what the authority published. Normalization establishes a reproducible machine representation. An executable rule establishes how Mass evaluates a specified condition. A citation and a rule reference make the relationship inspectable. They do not prove that the interpretation covers every exception or reflects current law.

A lawpack lock records the pack digest, artifact digest, component digests, and provenance. Components include the manifest, index, legislative documents, and source manifest. The artifact digest identifies the packaged file. The content digest identifies the canonical file set under the lawpack digest protocol. Repacking identical content can therefore raise a different question from changing the content itself.

Lawpack content addressing uses a domain prefix and sorted file paths. Each path and canonical file body has an explicit separator. This protocol differs from hashing a single JSON object. A verifier must use the digest protocol for the relevant artifact. It must not substitute a generic serialization hash merely because both produce SHA-256 values.

A missing executable interpretation leaves a real coverage gap. Legal text can remain valuable reference material without providing an automated decision. The author must identify the gap and specify the evidence or human decision that the operation requires.

## Regulatory state and licenses

A regpack supplies operational regulatory data. Its typed sections include regulator profiles, sanctions entries or snapshots, compliance deadlines, reporting requirements, compositional rules, and regime selectors. Extension fields can preserve additional authored data. Preserving such data does not ensure that a runtime predicate consumes it.

A regime selector defines named alternatives within a regulatory configuration. The selector validator checks unique identifiers, meaningful names, and exactly one fallback. Where a regime requires a receipt, its declaration identifies the receipt type, parameter, issuing authority, authority identifier, and freshness window. Signature requirements are explicit. These checks establish a well-formed catalog, while the operation's receipt gate must establish the evidence.

A fallback selects the default regime when the selector contract permits it. It cannot substitute for a missing approval required by another regime. An author must keep selection conditions separate from the proof that an authority approved the selection.

License data also has separate layers. A license category describes a kind of permission, its activities, prerequisites, authority, and possible renewal terms. A holder record concerns a particular party and permission. A receipt concerns the issuer's action or acknowledgement. Listing a category does not give an entity that permission.

The operational license loader supports category definitions and extensions as well as typed regulator and license-type data. Consequently, an implementation can load a useful license taxonomy before it has a live issuer integration. Product status must preserve that distinction. An unverified record must not become a claim of issuance because its category exists in a pack.

## Procedure, obligation, and adapter contracts

Procedurepacks supply executable operation definitions. They can declare parameters, step dependencies, conditions, evidence, waits, manual gates, and compensation behavior. The procedure loader validates the family schema, deserializes the typed definition, compiles it, and checks its resulting digest. The operation registry then converts the compiled representation into its runtime definition.

The registry loads procedurepacks before legacy operation definitions. Procedurepacks take precedence when both sources use the same operation and jurisdiction key. Some operation families reject this duplicate outright. Other overlaps produce a warning about the shadowed definition. Authors must know which definition the runtime resolves. Editing a shadowed document has no effect on the selected procedure.

An obligationpack answers a different question: what duty follows from a fact or state? Its rule can identify an authority, submission channel, triggering event, deadline, responsible actors, blocking conditions, cure paths, and satisfying evidence. Deadline forms include calendar dates, expiry offsets, event offsets, and dependencies on another obligation's satisfaction. A recurring window can add lead and grace periods.

The obligation declaration does not discharge itself. A scheduled wake can initiate work, but a filing requires the specified evidence of submission or acceptance. Expiry, rejection, resubmission, and satisfaction must remain distinguishable. Otherwise a scheduler can make a duty appear complete merely by attempting it.

Adapterpacks declare the external systems that a procedure can use. They describe transport, authentication, supported actions, callbacks, evidence, fallback, and rate limits. Cross-validation can check whether a procedure's actuator reference resolves to a declared system with the relevant step support. This resolves a configuration dependency. A separate execution path must authenticate, submit, and verify returned evidence.

Governancepacks and corridorpacks constrain these operations at different boundaries. Governance content identifies eligible decision makers and required approvals within an organization or authority. Corridor content identifies conditions for accepting another jurisdiction's evidence. Neither family can confer a power that the relevant institution has not granted.

## Templates and model declarations

A templatepack endorses a plan structure with typed slots. Its definition includes a template identifier, zone, required capabilities, slot schemas, plan body, author, signing time, and signature. Cost and gas estimates are advisory fields. The template identity combines the zone and template identifiers so different zones can use the same local name.

Slot filling gives an agent a constrained authoring task. It supplies permitted values to an established structure. The consumer must validate slot values before compiling the completed plan. It must also check whether the initiating principal holds the required capabilities. A plausible plan or a valid slot type cannot supply a missing authorization.

Template authority verification is a separate function from loading. It compares the expected zone and author, clears the signature field in the signing body, and verifies an Ed25519 signature. Opaque authority metadata inside a template is authoring metadata. It does not select the trusted verification key.

The recursive template loader selects documents with the canonical format marker. It skips other template-shaped documents. A directory inventory can therefore exceed the canonical registry. Readiness evidence must identify the selected representation and the authority verification performed by its consumer.

Modelpacks declare a provider, model identity, pinned version information, supported output schemas, and reproducibility class. The classes distinguish exact replay, constrained probabilistic behavior, and non-reproducible output. A model declaration cannot turn hosted inference into deterministic computation. Where replay is unavailable, retained response evidence must carry the reliance burden.

# Composition, pinning, and reproducible configuration

A deployment must answer which content governed an operation at a particular time. Mutable names cannot answer this question alone. The answer needs pack identities, schema identities, selected procedure content, and the configuration that resolved them. A profile name is useful for selection, but the resolved content supplies the evidence.

Let an operation's governing set be a finite collection of typed references:

$$
P = \{(k_i, j_i, d_i)\}_{i=1}^{n},
$$

where $k_i$ is a pack family, $j_i$ is its jurisdictional scope, and $d_i$ identifies its content. This notation expresses the required binding. It does not claim that every API serializes the set in this exact form. Additional fields can identify a legal domain, effective interval, or recognition record.

## Different identities answer different questions

An artifact digest answers whether retrieved bytes match an expected artifact. A pack digest answers whether its canonical content matches the family protocol. A regime digest summarizes selected pack versions. A composition digest can identify the assignment of domains to jurisdiction layers. These identities must not be treated as interchangeable.

The composition helper sorts layers by jurisdiction and domain names before hashing its structural description. Its digest covers the zone identifier and each layer's jurisdiction and domains. It does not cover all pack references, overrides, arbitration settings, or corridor settings. Two configurations can therefore share that structural digest while selecting different pack bytes.

A security decision that depends on actual legal content must bind the selected pack digests separately. A deployment release should retain its complete resolved configuration with corresponding artifact identities. Structural equality alone cannot establish equivalent rules or equivalent authority.

## Zone composition

A jurisdiction layer contributes a declared set of compliance domains. It can attach lawpack, regpack, and licensepack references, together with module overrides. The composition validator checks identifiers, nonempty layer domain lists, digest syntax, and conflicting domain assignments. It rejects a domain claimed more than once across the supplied layers.

This is a configuration rule for that composer. It does not eliminate legal situations where several jurisdictions apply simultaneously. The broader compliance model must evaluate concurrent obligations according to the relevant recognition and conflict rules. A deployment cannot evade an applicable constraint by assigning its domain to a more convenient layer.

Consider an illustrative zone that selects corporate rules from one layer and financial activity rules from another. Its configuration must state each source, content pin, and scope. It must also identify the authority that permits the arrangement. The example demonstrates composition mechanics. It does not assert that a government recognizes the resulting legal combination.

A layer's format can be valid while its legal arrangement is unsupported. Likewise, a declaration of arbitration mode does not establish a valid arbitration agreement. Configuration validation detects structural defects. Institutional authorization and legal applicability require their own evidence.

## Lockfiles

The lock tool resolves a zone's profile and records selected modules. Each module entry includes its identifier, version, variant, parameters, manifest digest, content digest, and provided interfaces. It also incorporates supported pack references from the zone configuration. Canonical JSON gives repeated builds a stable encoding when their inputs are stable.

Time is an input. A generated timestamp changes output bytes even when module content remains identical. The lock tool offers an explicit timestamp and a strict mode that requires deterministic time selection. A byte comparison must hold this input constant. Comparing two files with different timestamps does not isolate a content change.

Lock generation is not a complete admission gate. The implementation can warn and skip an unresolved module. It also filters zero-filled regulatory digest references. A successful output file can therefore omit intended content. Review must compare the requested selection with the resolved entries and reject unexplained omissions before release.

A lockfile also needs semantic agreement with its profile. The tool records the located module's version and content. The author must verify that these resolve the intended profile version constraints and dependencies. The existence of a content digest proves neither dependency satisfaction nor compatibility with the selected operation.

The useful acceptance question is whether another installation can obtain and validate the complete selected configuration. That requires artifact availability, correct digest verification, compatible consumers, and equivalent trust inputs. Reproducing a lockfile without retrieving its governed content does not answer it.

## Temporal version selection

A pack version record identifies its family, jurisdiction, digest, version label, effective date, optional sunset date, and predecessor. It can carry compatibility metadata and activation status. The registry groups records by canonical jurisdiction and family and orders them by effective date.

Active selection finds an effective, non-sunset record whose status is active. Effective dates are inclusive. A sunset date excludes the version on that date and afterward. The registry's datetime helper converts its input to a calendar date. It does not distinguish two activation instants within that day.

The registry can summarize an active regime by hashing an ordered family-and-digest list. Families without an active version are omitted. An empty regime returns an empty result rather than a digest of an invented default regime. Consumers must distinguish this condition from a complete applicable pack set.

Historical lookup needs careful interpretation. A lookup against today's registry status can differ from a historical operation's retained binding. A record marked superseded is excluded from active selection even when queried with an earlier date. A stored operation pin therefore has a different evidentiary role from recomputing a past date against a mutable registry.

The governing rule for an operation should remain identifiable throughout its lifetime. A later pack can require reevaluation, termination, or migration, but those are explicit transitions. Silently substituting the latest pack destroys the ability to explain why the original operation was admitted.

## Publication and recognition

Publication records a pack version. Recognition records a zone's acceptance of a published digest. Revocation ends an active recognition record. These are separate authority acts, and their persistence must retain their separate evidence.

The governance write surface requires authorized callers and performs sanctions preflight. It validates bounded identifiers, digest shape, and signature-envelope shape. For an inline body, publication checks its canonical JSON digest against the declared value. A body reference alone receives deferred digest verification. A publication response must therefore preserve which verification occurred.

The same surface stores supplied signatures as opaque hexadecimal data. It does not currently verify each declared signer against a zone trust anchor. Recognition also retains a ceremony envelope without complete ceremony-certificate verification. The persisted record establishes receipt and attribution through the authenticated route. It does not establish cryptographically verified institutional ratification.

Publication through this route creates a pending-activation version. Other registration paths and configuration can have different activation defaults. A deployment must identify its actual activation path and recognition setting. It must not infer universal recognition enforcement from the existence of the recognition API.

Pack signature types define a canonical body containing jurisdiction, digest, family, signer identifier, and signing time. Their declared scheme is Ed25519. Other cryptographic protocols in Mass can have different signature contracts. A verifier must use the scheme and message binding of this particular surface.

# Schema evolution and historical meaning

A schema determines how bytes acquire typed meaning. A legal amendment changes which rule applies. A new authority key changes who can authenticate a statement. These changes can occur together, but they require separate treatment. A version label alone cannot describe their combined effect.

A safe upgrade preserves the evidence needed to interpret old records and the authority needed to admit new ones. It must also handle operations that started before the change. An operation may remain valid, require additional evidence, or become impossible to complete. The upgrade contract must state which case applies.

## Compatibility declarations

Pack compatibility metadata can list breaking changes, additive changes, removed rules, accepted prior digests, and a migration procedure identifier. Explicit digest compatibility binds a claim to particular content. A statement that a release is generally backward compatible is less precise.

The registry's compatibility helper checks membership in the declared compatible-digest list. It does not prove semantic equivalence. A migration procedure identifier similarly names an intended mechanism. It does not prove that the procedure exists, terminates, preserves authority, or has run for every affected record.

Semantic versioning remains useful author discipline. A patch should preserve the declared interface. An additive change should preserve existing valid inputs under the stated conditions. A breaking change should identify affected consumers and a transition method. These are review obligations unless the specific admission path enforces them. The publication route's bounded version string is not a universal semantic-version proof.

An apparently additive field can change meaning. Adding a default authority field can redirect an existing procedure's decision maker. Adding an optional deadline field can become breaking if the consumer treats absence as immediate expiry. Authors must compare behavior and defaults, including missing-value behavior.

## Migration functions and their conditions

Let $A$ and $B$ be the sets of valid records under two schemas. A reversible migration consists of total functions $f:A\rightarrow B$ and $b:B\rightarrow A$ satisfying

$$
b\circ f=\mathrm{id}_A,
\qquad
f\circ b=\mathrm{id}_B.
$$

These equations define a bijection. They are assumptions that require evidence for the chosen record sets and functions. A round-trip test over examples can falsify the equations. It cannot prove them over every possible record unless the domain is finite and exhaustively covered.

Reversible migrations compose. If $(f_1,b_1)$ connects $A$ to $B$ and $(f_2,b_2)$ connects $B$ to $C$, the composed pair is

$$
(f_2\circ f_1,\;b_1\circ b_2).
$$

The reverse-forward composition reduces to the identity by the two supplied inverse laws. The forward-reverse composition follows the same substitution. This mathematical result requires no implementation assumption. Applying it to a deployment requires implementations that realize those functions and preserve their domains.

Many practical schema changes are not bijections over unrestricted record sets. Adding a freely chosen field increases the information that a record can hold. Removing a field discards information unless retained elsewhere. An upgrade can preserve historical meaning by retaining original bytes, using a restricted image, or storing an explicit extension record. The specification must name the chosen method.

A migration must preserve the distinction between factual absence and a manufactured default. If an older schema did not record an approval, the new representation must not invent one. It can represent the approval as unknown or require a new authorized act. A syntactically complete migrated record is insufficient when its values lack evidence.

## Schema-pinned epochs

The storage model defines epoch headers with a schema identifier, schema version, schema digest, leaf count, and authenticated root. A pinned observation stores its schema identity, version, and serialized bytes. These fields support interpretation under the schema associated with the original record.

The migration-lens record stores source and target versions, hashes of forward and backward transformations, and an optional proof hash. Registering this record does not execute its transformations or check its proof. The epoch registry's lens lookup returns direct source-to-target matches. It does not construct arbitrary multi-step migration chains.

These limits matter for an archive. A record of transformation hashes can identify intended code, but an auditor still needs that code and its execution semantics. A proof hash can identify an artifact, but the artifact must be available and checked against the transformation. Retained bytes and schemas remain necessary even when a migration catalog exists.

Historical replay and current projection should produce distinguishable results. Historical replay asks what the record meant under its original schema and rule set. Current projection asks how the retained information maps into today's representation. A projection must not overwrite the evidence that answers the first question.

## Pack changes and affected entities

The pack evolution component detects changed active pack identities and constructs a cascade plan. The plan starts with affected compliance domains and follows declared propagation edges. It records a run with its change, domain set, timing, status, and counters. This supplies useful bookkeeping for an upgrade's impact.

Its execution path currently loads a bounded set of compliance passports, selects the affected jurisdiction, and emits advisory signals. It does not itself rebuild each passport or materialize the resulting obligations. A completed bookkeeping run therefore cannot establish that all affected entities have been reevaluated.

An actual upgrade claim needs durable evidence from the components that performed the affected work. It needs selected entities, original and resulting bindings, changed verdicts, and resulting obligations. A bounded scan must also establish complete coverage, including pagination or another enumeration method where necessary.

The operational upgrade contract follows from these distinctions. Retain old content and schema identities. Establish new content and authority checks. Determine which bound operations can continue and which need a transition. Execute required transitions through the authorized mutation path. Verify resulting state and evidence before declaring the upgrade complete.

# Authoring profiles and sovereign deployments

A sovereign deployment gives its operator control over configuration, credentials, data handling, and accepted evidence. This is an architectural deployment property. State authority, regulatory permission, and the legal effect of an instrument still come from the relevant institutions and law.

The deployment can support an organization, a jurisdictional authority, or a bounded institutional service. The technical model does not require one global administrator to decide every operation. It does require each deployment to define who controls its rules, which principals can act, and which external statements it accepts.

## Authoring begins with an institutional act

An author should start with the act the system must support. Examples include granting a license, changing a director, accepting a customs declaration, or recording a tax filing. Each act has a subject, an authority, inputs, conditions, and evidence of completion. Pack families then allocate those elements to typed content.

Legal source review must precede executable rule authoring. The author identifies the authoritative publication, effective interval, territorial scope, and relevant exceptions. The author then records which conditions are executable and which require professional or official judgment. A decision reserved to an authority remains reserved even if an agent can prepare its supporting material.

A complete authoring dossier should connect source text to rules, procedures, and evidence contracts. It should identify responsible reviewers and the limits of their review. Technical validation concerns shape and behavior. Legal review concerns applicability and interpretation. A signature records an act by a key holder under a defined message contract. None of these roles replaces the others.

The development loop should test the first plausible failure as well as the successful case. If the operation requires an issuer receipt, an unsigned or wrong-issuer receipt must not satisfy it. If a deadline depends on a fact, the procedure must not start the clock from an unrelated timestamp. If a rule has an exception, the author must specify its proof requirements.

## Illustrative duty authoring

Consider a fictional reporting duty triggered by the first qualifying sale. The following description illustrates a contract and does not state any jurisdiction's law.

| Element | Illustrative declaration | Required interpretation |
|---|---|---|
| Trigger | First qualifying sale for an entity | Identify the fact and exclude duplicate triggering |
| Deadline | A specified interval after the event | Use the declared event time and calendar rule |
| Authority | Named reporting authority | Bind the destination and accepted issuer |
| Satisfaction | Verified acceptance receipt | Preserve its relation to the filing |
| Cure | Authorized resubmission after rejection | Keep the rejection and subsequent result distinct |

The lawpack identifies the source basis for the duty. The obligationpack describes its trigger and satisfaction condition. The procedurepack declares preparation, authorization, submission, wait, and failure steps. The adapterpack identifies the supported submission interface and evidence contract. A governancepack can specify who may authorize the filing.

A simulation can exercise these contracts with clearly identified test evidence. It cannot establish that a regulator accepted a real filing. Before operational use, the author must bind the procedure to the actual authority and verify the supported receipt path.

## Profiles and zone manifests

A profile selects modules by identifier, version, variant, and parameters. It can declare corridor identifiers. The profile schema requires a profile identifier, stack specification version, and module list. A profile describes a reusable selection. It does not supply every deployment-specific credential or authority decision.

Profile families include minimal configurations, financial centers, digital free zones, charter-city configurations, sovereign configurations, and synthetic compositions. A synthetic composition is useful for design and testing. Its name does not establish that participating governments adopted its combination.

A zone manifest adds the jurisdictional and operational context. Its typed representation includes zone and jurisdiction identifiers, a profile, jurisdiction stack, lawpack domains, corridors, peers, trust anchors, key policy, and compliance domains. Deployment settings and proof-key declarations can accompany these fields.

Parsers accept some historical representations and supply defaults for some omitted fields. A parser's default can ease configuration loading while leaving a material deployment decision unresolved. Before use, the operator must inspect resolved configuration, including default key intervals, missing profile details, and omitted domain lists.

A jurisdiction identifier names a selection scope. It is not a certificate of sovereignty, a license, or evidence of operational readiness. A directory containing a zone manifest establishes an authored configuration artifact. A running deployment requires loaded configuration, controlled keys, operational services, and evidence from its claimed user paths.

## Control, recognition, and limits

The operator's control includes pack adoption, zone signing policy, credential custody, data retention, and external evidence acceptance. These controls need explicit authority assignments. The technical administrator who deploys software need not hold the legal authority to recognize a rule or issue a license.

Recognition between deployments is directional. If deployment A accepts specified evidence from B, B does not thereby accept all evidence from A. Acceptance also has scope. It can apply to a particular issuer, claim class, domain, validity interval, or evidence format.

Represent an acceptance policy as a directed relation whose edges carry those conditions. A path through several recognizing parties does not imply unrestricted transitive recognition. A accepts C through B only when A's policy explicitly permits that derivation and its evidence conditions hold.

The receiving deployment retains responsibility for its own mutation decision. Incoming evidence supplies a fact or credential under the corridor contract. It does not grant the sender unrestricted database access. A corridor's terms must also identify suspension, revocation, disagreement, and dispute handling.

Independent deployment needs concrete operational isolation. Separate identities on a shared database do not alone prove independent custody or administrative control. Network topology generators can produce shared infrastructure for testing or coordinated operation. Production isolation claims require evidence about actual credentials, storage, operators, and recovery access.

Several design commitments follow. Trust configuration should permit the operator to identify and review accepted anchors. Probabilistic identity evidence must retain its uncertainty and required corroboration. Application interfaces should expose only the powers of authenticated principals. These are acceptance requirements for the deployed arrangement, not consequences of naming a profile sovereign.

A local configuration cannot establish another party's consent or the enforceability of a dispute outcome. Arbitration mode, appeal policy, or forum identifiers must correspond to an actual agreement and supported process. The dispute and recourse chapters define the resulting evidence and enforcement boundaries.

# Sector configuration and jurisdiction templates

Sector modules organize work that crosses legal, operational, and financial boundaries. Their purpose is reuse with explicit specialization. A reusable step can serve several jurisdictions when its inputs and effects are equivalent. A change in authority, legal condition, or required evidence demands a corresponding change in the contract.

A module catalog therefore needs more than a list of names. It should distinguish authored material, validated definitions, selected executable definitions, supported external connections, and verified operational outcomes. Each category answers a different procurement or engineering question.

## Corporate and capital markets

Corporate configuration covers formation, beneficial ownership, registered agents, secretarial work, and capitalization. The corporate module supplies associated forms and schemas. Procedures connect these artifacts to owning primitive services and required approvals. The entity chapter defines the underlying entity model.

A share issue illustrates the cross-boundary dependencies. The procedure needs the issuer's identity, authorized share structure, recipient, consideration, and decision authority. It can require instrument preparation, consent, payment evidence, and durable ownership effects. A successful document render establishes only one part of that operation.

Capital markets modules cover issuance, trading, corporate actions, clearing, central securities depository functions, post-trade work, and delivery or payment conditions. Selecting a clearing module does not establish a clearinghouse license or external settlement membership. Those permissions and connections require evidence specific to the deploying operator.

The Mass and Moxie boundary remains explicit. Mass creates and governs organizational claims and their supporting state. Moxie provides the claims-and-derivatives clearing layer. A configuration can bind the interface between them, but their records, authority decisions, and finality evidence must remain distinguishable.

## Trade and logistics

Trade modules include letters of credit, trade documents, customs, trade insurance, and supply-chain finance. These workflows connect parties, goods, instruments, and external authorities. Their configuration must identify which event represents commercial agreement, document acceptance, goods movement, and financial settlement.

For an illustrative letter of credit, document presentation can precede acceptance, rejection, or a discrepancy process. A transport acknowledgement only establishes receipt of a message at that interface. It does not prove that documents comply, goods arrived, or payment became final. Each effect needs its own evidence contract.

Customs configuration has comparable distinctions. A declaration prepared for submission differs from an accepted declaration. Release of goods differs from payment of duties. A pack can describe required forms and conditions while an adapter remains unavailable. The procedure must preserve the resulting pending state and permitted manual path.

## Tax, payments, and settlement

Tax modules cover collection, withholding, transfer pricing, treaty management, and fee schedules. These subjects depend on effective dates, classification, and source authority. Example rates or thresholds in a configuration must carry their provenance and validity. They must not become undocumented global constants.

A treaty reference does not prove that an entity qualifies for its benefits. A withholding calculation does not establish payment to the authority. A calendar entry does not prove filing. Procedures must connect each claimed effect to appropriate facts, authorized actions, and evidence.

Financial modules include treasury, domestic banking and payments, lending, cards, foreign exchange, safeguarding, payment adapters, and settlement adapters. Their configuration describes supported interfaces and policies. It does not confer a banking authorization or guarantee that a payment rail accepted a transfer.

Settlement is a particularly strict boundary. An internal receipt, a transport acknowledgement, a timestamp, and an external settlement confirmation have different meanings. Anchoring evidence can establish that a record existed or remained unchanged under the chosen protocol. It does not independently establish discharge of a financial obligation.

A settlement configuration must identify the responsible system and finality condition that the operation consumes. Timeout, rejection, reversal, and reconciliation remain explicit outcomes. If the external system permits reversal, the receiving procedure must not describe its first acknowledgement as irrevocable finality.

## Operational modules

Operational modules provide audit logging, data classification, telemetry, regulator-facing views, and related controls. These modules help an operator observe and govern the deployment. Their interfaces should distinguish a measured fact from a configured target.

A regulator-facing display can show a declared obligation before its discharge adapter is live. It must display actual status and evidence. A telemetry event can show that a step ran without proving its intended external effect. Metrics should therefore bind to outcome definitions that match the product claim.

Catalog statistics also require defined units. A module manifest, a YAML file, an operation key, and a runtime execution are different units. Counting all YAML files cannot establish the number of executable or operationally verified capabilities. This specification uses subject coverage instead of converting directory size into deployment claims.

## Jurisdiction templates as scoped starting points

The maintained configuration includes templates associated with Pakistan, Seychelles, Abu Dhabi Global Market, and the Astana International Financial Centre. These names identify source and configuration scopes. They do not establish current legal completeness, active government deployments, or regulatory adoption.

A Pakistan-oriented selection can organize corporate registration, tax, foreign exchange, customs, and economic-zone subjects. A Seychelles-oriented selection can organize corporate administration, beneficial ownership, financial licensing, and reporting. An ADGM-oriented selection can organize company and financial-services procedures. An AIFC-oriented selection can distinguish financial-center scope from domestic requirements.

The author must verify actual content and applicability for the intended operation. A national regime and a special-zone regime can involve different authorities and territorial limits. A named profile cannot resolve these distinctions automatically. The zone, governing packs, and operation inputs must establish the relevant perimeter.

For each template, operational acceptance requires several specific answers. Which sources and effective dates govern the selected acts? Which procedures resolve in the executable registry? Which authorities issue the required evidence? Which integrations have verified outcomes? Which residual duties require a manual decision or remain unavailable?

A new jurisdiction can often reuse existing types and procedures through authored data. This is possible when its rules, evidence, and effects fit supported contracts. A novel authority mechanism, primitive effect, or external protocol can require implementation work. Adding a folder cannot supply a missing consumer.

## A complete sector configuration

Consider a fictional port enterprise that forms an entity, imports equipment, finances inventory, and pays a supplier. Corporate content governs formation and authority. Trade content governs import documentation and goods events. Tax content governs duties and reporting. Financial content governs payment and financing effects.

The operation's configuration must retain each applicable pack and the evidence that connects the steps. A customs rejection can block a financing condition. A payment receipt can satisfy a financial step while leaving a filing duty open. A director's approval can authorize an act without establishing that an external authority accepted it.

This composition becomes operational only when required paths produce their specified durable effects. The final record must identify applicable content, authorized actors, completed effects, and unresolved obligations. That is the acceptance standard for extending Mass to a new sector or jurisdiction.

# Program admission and durable execution

An executable request carries an intended change, authority to request it, and evidence that permits the change. These objects have different lifetimes. Authority can expire while a workflow waits. A provider can accept a request before Mass receives its response. A committed change can precede its searchable evidence. The execution model must preserve these distinctions through failure and recovery.

This part specifies the required behavior and identifies the corresponding implementation mechanisms. Statements using **must** define requirements. Statements about the current implementation describe inspected source behavior. The worked example is an illustrative trace, not a report of an executed transaction. Deployment acceptance requires execution evidence for the selected routes, providers, configuration, and authority.

## Intent, admission, and effect

An **intent** identifies the change that a principal requests. It includes the governed subject, semantic operation, authored values, applicable jurisdiction, and replay identity. A **program** expresses the work required for that intent. An **admission decision** establishes that a particular program may enter a specified execution path under particular authority and rules.

An **effect** is an observable change outside the evaluator's temporary state. Examples include a stored organization record, a reserved balance, an accepted filing, and a delivered notification. Evaluation can produce a proposed effect without producing the effect itself. A provider request can also produce an effect before the caller receives an acknowledgment.

A **receipt** records a defined event or outcome. Its subject determines its meaning. A receipt for accepted work establishes acceptance. A receipt for a committed mutation establishes that mutation. A receipt for an operation's creation establishes the existence of the operation. Completion requires the operation's specified effects and acknowledgments.

For an intent $i$, let $E(i)$ be its required effects and $A(i)$ its required acknowledgments. Define completion by the contract:

$$
\operatorname{Complete}(i)
\iff
\left(\forall e\in E(i),\;\operatorname{Established}(e)\right)
\land
\left(\forall a\in A(i),\;\operatorname{Verified}(a)\right).
$$

The contract must specify what establishes each effect. A local insert can require a committed database record. A registry filing can require the registry's accepted response. A signing step can require a verified signature over the exact document. An emitted request alone satisfies none of these stronger conditions.

This definition permits intermediate proofs. An operation can carry a valid proof of creation while it waits for a signature. A client must interpret the proof subject and operation state together. A signed intermediate proof must not acquire a broader completion meaning through its presentation.

## Admission of an authored program

MassProgram is the authored envelope for program admission. Its bindings identify the program, entity, jurisdiction, semantic family, capability, evidence obligations, resource limit, signer, nonce, and validity period. The evaluator must recompute the payload identity using the selected encoding. It must compare that identity with the value covered by the author's signature.

The admitted intent must also distinguish one-shot from repeatable execution and bind the permitted multiplicity. A new command identifier cannot multiply one-shot authority. Repeatable work needs explicit occurrence and aggregate-use rules, with shared limits enforced across its commands.

MassBiscuit supplies attenuated authority. Admission must verify the capability chain and its current revocation state. It must establish that the presented capability matches the binding signed into the program. It must then evaluate the effective restrictions against the program's subject, operation family, jurisdiction, and time.

Cryptographic validity and authority have separate meanings. A signature can remain historically valid after its grant expires. A valid capability chain can authorize a different subject or operation. Admission must test the actual requested action against the effective grant. It must retain the authority version used for that decision.

The current program path performs capability verification, revocation checking, binding comparison, program admission, and signer binding. It derives caller identity from verified authority. It also creates a zone-signed verdict before the internal proposal path. The HTTP submission path distinguishes authority to submit a program from authority for its semantic operation.

Lex certificates and verdict bindings serve different purposes. A structural certificate can establish a property of the program under a rule. A commit verdict connects the actual action to the authority and evidence required at commitment. A submission path that requires a verdict must reject a structural certificate offered as its replacement.

Admission must fail explicitly when its required producer is unavailable. The current authoring endpoint validates an envelope and then refuses it because durable authoring storage is not implemented. The executable submission endpoint is separate. This separation prevents successful validation from masquerading as durable acceptance.

## Execution paths and their result contracts

The current executable submission path supports an operation reference and an Op program. An operation reference binds the operation type and its parameters. Submission admits that reference and enqueues work through the shared operation-creation path. Its immediate proof concerns creation of the operation. The returned operation identifier supports subsequent inspection.

The Op path typechecks and compiles the submitted program. Supported effects can lower into an allowlisted write plan. The write plan must retain the subject, authored values, evidence, and authority established by admission. Lowering must not broaden the admitted action or substitute a privileged transport identity for missing authority.

The internal proposal entry point also accepts a capability and program. Its current implementation admits the program and proposes a program-submission transition. That transition establishes the admitted submission event. Execution claims must follow the selected lowering and its actual effect producers.

The following result classes remain distinct throughout the API and client surfaces.

| Result | Established fact | Further evidence for completion |
|---|---|---|
| Compile or simulation result | Evaluation under the supplied inputs | An authorized execution and its effects |
| Program admission | The envelope passed the selected admission checks | Durable acceptance and execution |
| Operation creation proof | The operation was created | Required steps and acknowledgments |
| Mutation proof | The named mutation committed | Other effects required by the intent |
| Terminal operation record | The workflow reached its recorded terminal state | Contract effects consistent with that state |

An implementation must document each transaction boundary between these results. The current write-plan submission lane commits its lower-level plan before a later proposal for the program transition. An error from the later proposal can follow committed effects. A retry must inspect the earlier commitment through its replay identity.

A separately inspected implementation candidate adds a journal-backed completion path restricted to authored `CreateTarget` declarations for a current open native account. It retains the command, journal receipt, commit witness, and proof with the audit and outbox in one transaction. Current program admission and evaluation precede journal replay. Exact admitted retries recover the original journal result without another completion event; they do not provide historical retrieval after execution authority is revoked. This candidate remains separate from the source baseline described above. Provider funding, payment, return, and closure admission remain outstanding.

## Resource limits and delayed authority

Admission must bound the resources that a program can consume. The bound must identify its unit and enforcement point. Instruction gas, data-dependent work, elapsed time, provider charges, and reserved cash are different resources. A gas estimate must not imply that a provider has accepted a charge or reserved funds.

Scheduled work requires admission at creation and authority checks at execution. The current scheduler stores scheduled programs, claims due work, verifies authority at firing, and applies bounded retries. A stored program must not retain permission solely because its authority was valid when scheduled.

A failed scheduler-state update can leave a program in its firing state after work has run. The current scheduler requires operator intervention for some such cases. Recovery must inspect the committed outcome before re-arming the program.

The same rule applies after a human review or provider wait. Resumption must validate current authority for the next effect. It must preserve the original intent and completed effects. Changed inputs or broadened authority require a new admitted action with an explicit relation to the earlier request.

## Execution evidence

An execution claim must identify the program or operation definition, source version, configuration, principal, subject, intent, and causal identifiers. These bindings let a reviewer distinguish the claimed execution from a similar test or another deployment. Static registration establishes discoverability, not execution.

Acceptance must exercise the claimed boundary. A local transaction test can establish rollback behavior for that transaction. It cannot establish a provider's idempotency or a registrar's acceptance. A workflow test must inspect its terminal record and the contract-derived effects. It must also distinguish automatic recovery from an operator's manual repair.

# Mutation transactions and evidence delivery

Mass owns its durable business writes. Native domain services implement business rules and use owning persistence interfaces. The mutation firewall supplies the common authority, compliance, and evidence obligations around those writes. The transaction boundary determines which records become durable together.

## The mutation contract

A **mutation contract** declares the subject, action, required authority, evidence, durability, and permitted transition for a write. It also classifies irreversibility. The contract must identify a governed subject independently of a display label or transport path. A caller must not gain access by substituting an identifier from another entity.

The firewall must enforce current capability restrictions, entity scope, required role or delegated authority, and applicable halt controls. A contract that requires a signed verdict must reject a write without the required verdict. Sanctions rejection is terminal for the attempted action. A later recovery step must not reinterpret that rejection as permission.

The current firewall family includes legacy finalization, verdict-aware finalization, atomic business-write helpers, and validated write plans. Daemon-origin writes carry fencing information. Signed-contract, halt, delegation, and capability checks appear at their relevant entry points. Primitive services invoke this family through the supplied firewall interface.

This arrangement permits shared enforcement without moving business logic into a universal route handler. A domain service determines the valid business change. Its persistence interface owns the affected records. The composition layer supplies the transaction and enforcement dependencies. Verification must inspect this full call path.

### The verdict admitted at commitment

`VerifiedVerdict` is the evaluated verdict object admitted at the mutation boundary. It is distinct from the `MassProof` envelope used to transport or resolve evidence about a result. The verdict's field ledger separates evidence, attestation, authorization, composition, autonomy, cost, model identity, and Byzantine agreement. Each group carries the material and unresolved target requirements relevant to its responsibility.

The inspected commit-admissibility predicate rejects an unsigned projection, any remaining target residual in those groups, and commit-critical zero digests. The critical fields include lawpack and regpack identities, the issuing model commitment, and a filed obligation witness's proof digest. For a contract marked `must_be_signed`, the verdict-aware finalizer refuses a missing verdict, a projection-only verdict, or a verdict that fails this predicate. Other contract classes have different declared requirements and must not inherit a stronger claim from this lane.

This predicate checks structural admission conditions. It does not by itself verify every cryptographic signature, establish the truth of evidence, or grant sanctions permission. The calling path must authenticate the actual verdict and enforce the independent authority and sanctions requirements. A filled field ledger is therefore necessary where this contract requires it, but cannot substitute for the rest of admission.

## Co-commitment of business state and evidence

Let $B$ denote the business records changed by one atomic write. Let $J$ denote its audit record, $O$ its required outbox records, and $P$ its stored proof. For the atomic write lane, the required commitment is:

$$
\operatorname{commit}(B,J,O,P)
\quad\text{or}\quad
\operatorname{rollback}(B,J,O,P).
$$

The application must use the same database transaction for these records. A successful audit transaction beside a failed business transaction does not satisfy this requirement. Two successful transactions separated by a crash window also do not satisfy it.

The current atomic lanes support raw SQL and SeaORM transactions. The SeaORM lane borrows the configured database pool, begins a transaction, and runs the business closure. It appends the audit, observation, corpus, and proof records through that same transaction. It commits before invoking downstream fan-out.

An outbox stores a durable obligation to deliver information after commitment. Its insertion must fail the atomic write when that delivery record is required. The current atomic append helpers propagate required observation and corpus-outbox failures. They do not convert these failures into successful business writes.

The scope of this invariant is one selected transaction. A multi-step workflow can contain many such transactions. A provider can maintain its own transaction outside Mass. A complete execution trace must identify each boundary and the durable relationship between boundaries.

![Required local co-commitment and subsequent delivery. The known ordering exceptions described in the foundations do not satisfy this contract.](manuscript/figures/atomic-commit-and-delivery.png){width=6.5in}

## Delayed evidence and reconciliation

Some evidence derives from an already committed mutation. The current event-store append occurs in post-commit fan-out. A failure there can leave a committed business change with a delayed event record. The runtime records the gap, and a reconciliation daemon can reconstruct missing events from matching audit and outbox evidence.

The audit record and event record therefore have different roles. The former participates in the selected mutation transaction. The latter supports downstream history and correlation. A consumer must tolerate a temporary delay without inferring that the business change disappeared.

Reconciliation must preserve the causal identity of the original mutation. It must match the subject, event, action, request, and relevant time bounds. A repair must not append a new genesis entry merely because a chain-head read failed. A duplicate repair must converge on the same event rather than create a second history.

The current reconciliation mechanism also links organizational state events with mutation events. Its operation depends on the configured repair lag and search window. A missing event beyond the inspected window remains an unresolved obligation. The existence of a daemon does not establish that every historical gap has been repaired.

Observation delivery has its own outcomes. The current corpus delivery daemon records successful delivery, schedules retries, and moves exhausted or rejected work into dead-letter storage. A dead letter is durable evidence of incomplete delivery. It requires an authorized repair or replay procedure before the delivery obligation can close.

## Ordering and replay

Per-chain sequence, database commitment order, hybrid logical time, and external event time describe different orders. A hybrid logical clock combines physical time with logical advancement. It can support causal reasoning while replicas have different physical clocks. It does not by itself establish a universal strict order over all writers.

The current observation code tolerates bounded clock skew across replicas and rejects larger regressions under its normal enforcement mode. Its per-process sequence ranges can overlap after restart or scale-out. A consumer must use the documented ordering relation rather than sort all records into an assumed global sequence.

Replay must preserve identities and original evidence. Reconstructing an event from an outbox is evidence repair. Reissuing the underlying payment or filing is a new external dispatch. The repair procedure must identify which of these actions it performs and must retain the original dispatch identity when redelivery is authorized.

## Idempotency and failure windows

An **idempotency key** identifies an exact admitted request within a defined scope. The associated record must bind the key to the request content and outcome. Reusing the key with different content must fail. Repeating the same request must return the committed result or report that its outcome remains unresolved.

The current write-plan path stores an idempotency result within its transaction. Concurrent duplicate transactions converge on the committed winner. Duplicate effects from the losing transaction roll back. This establishes a local replay property for that path, subject to its request-binding contract.

Remote actions require a separate contract. Before dispatch, the runtime must persist the provider identity, exact request, authority, and replay key. After dispatch, it must persist the provider acknowledgment. A crash between these events requires provider lookup or an idempotent repeat. A new random key would turn recovery into a second action.

| Failure window | Durable knowledge | Required recovery |
|---|---|---|
| Before local commit | Transaction has no committed effect | Retry the admitted request |
| After commit, before response | Local effect may already exist | Resolve the stored replay outcome |
| After remote acceptance, before acknowledgment | External effect remains uncertain locally | Query or repeat with the original identity |
| After audit commit, before event fan-out | Mutation is durable, derived evidence is delayed | Reconcile evidence without repeating the mutation |

Runtime monitoring must expose these distinctions. Useful signals include old outbox entries, failed evidence repair, expired claims, repeated deterministic failures, and unresolved provider responses. A low HTTP error rate alone cannot establish successful execution or complete evidence delivery.

# Workflows, waiting, and compensation

A workflow connects effects whose prerequisites and completion times differ. The operation engine represents this work as a directed acyclic graph of steps. Each step has a defined action, dependencies, result, and failure policy. The persisted operation record holds the current execution state.

## Control and state

The current operation model has two execution modes. Execute mode allows the daemon to advance eligible steps. Plan mode requires explicit advancement. A direct primitive call uses the mutation path without an operation wrapper. It is not a third operation-mode value.

The operation lifecycle distinguishes creation, active work, waiting, success, failure, and compensation. Its current states are `Created`, `InProgress`, `Waiting`, `Completed`, `Failed`, `Compensating`, and `Compensated`. The completed, failed, and compensated states are terminal. A step has a separate state, including ready, executing, waiting, skipped, and compensated.

An operation can have a waiting step while its operation-level state still records work in progress. Scheduling and monitoring must therefore inspect relevant step states. A waiting step with a future deadline differs from a stranded executing step. They require different recovery actions.

The operation definition must specify what each dependency means. Completion of a document-generation step can permit a signing step. It cannot satisfy that signing step. A notification step can establish that a message was queued, accepted by a provider, or delivered. Its contract must select the required acknowledgment.

Step inputs must come from authored values, authenticated identity, or established predecessor results. The executor must reject missing required inputs. It must retain the definition used for an in-flight operation so a later catalog change cannot silently alter recovery.

## Work claims and fencing

A **work claim** gives a worker temporary responsibility for a persisted operation. A **fencing token** identifies the current execution generation. The current operation daemon uses database claims with leases. Expired claims allow recovery after a worker stops.

Lease expiry alone does not stop an old worker. A delayed worker can resume after another worker acquires the operation. The write boundary must therefore check a current fencing token or equivalent exclusive authority. A stale generation must fail before it produces another effect.

The worker must persist enough state before dispatch to distinguish ready work from work already sent. Recovery reads the database record, not the abandoned worker's memory. When an executing step exceeds its permitted interval, recovery must first resolve any external effect. It must not assume that elapsed time reversed that effect.

Notifications can accelerate execution, while periodic scans provide another opportunity to find eligible work. Neither mechanism replaces the persisted claim and transition checks. Duplicate wakeups must lead to one authorized transition. Missing wakeups must not permanently strand otherwise eligible work.

## Callback identity and acknowledgment

A callback is evidence delivered by another system or actor. Its envelope must bind the source, operation, subject, event type, event identity, and payload. The receiver must verify source authority and the relationship between the payload and waiting work. A caller-selected operation identifier is insufficient evidence of that relationship.

The current callback path compares immutable event content when an event identity already exists. An exact replay can follow the replay path. A changed payload under the same identity produces a conflict. This preserves the distinction between redelivery and a new assertion.

Callback storage, workflow advancement, and the HTTP response can have separate failure points. The current route can deliver an event successfully and then fail during follow-up advancement. The sender must retain the original event identity. A retry must resolve its stored disposition instead of creating another event.

Signing callbacks require exact document and signer bindings. A signature on a related document must not release the current wait. Grouped submissions require a verified membership relationship. A provider's successful transport response must not substitute for the required signature or completed signing session.

The target callback contract further separates a provider occurrence, its transport deliveries, and each admitted local effect. Changing a delivery timestamp or transport signature creates no additional occurrence. Admission freezes the effect plan. Each effect retains the identity `(occurrence, effect_plan_digest, ordinal)`. Subject-version checks remain admission conditions; revalidation after unrelated state changes must preserve that effect identity.

Consent and templating must share one signing submission for the exact document, signer set, and provider submission. Signature completion and custody of executed bytes are distinct states. A dependent step advances only after its required custody check. A durable custody job retries retrieval of the same executed bytes without regenerating the document or starting another signing submission. Its receipt binds object version, digest, storage profile, and the waiting step it releases. These are required recovery semantics, not a claim that the present callback path already implements every record.

## Retry and compensation

Retry repeats an action under a defined replay contract. Compensation performs another action intended to offset an established effect. Database rollback removes uncommitted local changes. These mechanisms have different authority requirements and different consequences.

The current operation model records retry counts, retry deadlines, and failure classifications. Deterministic failures can recur while their inputs or authority remain unchanged. Transient provider failures can justify bounded retries. Exhaustion must lead to an explicit failure or compensation policy, with diagnostics retained.

For a workflow graph $G$, compensation follows reverse dependency order over effects that actually occurred. Let $F$ be the established forward effects and $c_f$ the authorized compensation for effect $f$. A compensated outcome requires evidence for each applicable $c_f$, not merely a traversal of the reversed graph.

Even a successful compensation can leave history and costs. A refunded payment leaves its original payment and refund records. A withdrawn application can leave a registrar's record and a retained fee. An executed instrument can require a later amendment. The compensation contract must state the resulting business state rather than promise restoration of every prior fact.

The current compensation executor plans reverse topological actions and persists per-action outcomes. Its recovery daemon retains an attempt identity across retries. A downstream service must honor that identity for the repeated request to avoid duplicate effects. Exhausted attempts and missing operation definitions produce explicit failures for review.

An irreversible effect requires a specific recovery procedure. The runtime must retain the accepted external action, the failed dependent action, and the remaining obligation. It must not mark the operation compensated merely because reversible local steps completed. A responsible actor must receive the unresolved work with its supporting evidence.

## Durable checked continuations

A **continuation** is the execution state needed to resume suspended work. A **checked continuation** binds that state to the validated program and runtime profile that can interpret it. Its durable representation must carry control position, environment, frames, pending request, logical work, effects, and authenticated history.

The normative continuation contract requires direct restoration. The receiving runtime must restore the checked state without executing the program from its source entry point. Re-execution could repeat duty creation, consume resources again, or issue another provider request. A matching final value would not establish an equivalent execution history.

Before commitment, the receiver must round-trip the continuation through the exact decoder used for restoration. The restored object must preserve its program and profile bindings, instance identity, host binding, nonce, ordinal, and pending work. Successful serialization through a different utility is insufficient.

Current authority, consumption of pending work, resulting continuation, and command receipt must commit atomically under one serial order. An invalid admission must leave pending work unconsumed. An exact retry must return the committed command receipt without runtime re-execution. A changed request under an existing command identity must fail.

The host must authenticate the complete stored state and command receipts. A current-state commitment must bind instance heads and authority metadata. Each mutation must update its records and that commitment in the same transaction. An older authenticated record must fail against the current commitment.

This contract is stronger than a generic workflow checkpoint. A persisted step name does not capture a suspended evaluator's environment or pending effects. The current operation records and leases provide important recovery mechanisms. They do not, by their existence, establish conformance to this complete continuation contract.

## Duties and economic state during resumption

A **duty** identifies an obligation, its occurrence, and the portions still requiring performance. **Command exposure** is the remaining performance that a command can require. A **reservation** binds funded resources to a permitted future action. Resumption must preserve these objects under their original identities.

Duty identity binds the issuer's authoritative namespace, constituting act, and occurrence index. Changing the administrator, template, or rules version must not create another duty. The economic journal retains beneficiary, debtor, asset, unit, conditions, priority, amendments, and original command bindings. Reservations of duty portions and reservations of cash remain distinct.

Late performance can reduce residual command exposure. Closing a command does not discharge unpaid debt. A receipt for a closed command must therefore preserve the separate debt and performance records. Repeated delivery of the same duty-creation event must resolve to its original delivery identity.

Let $D$ be outstanding performance, $P$ completed performance awaiting attribution, and $u_j$ each live command's remaining possible performance. Additional command exposure must respect:

$$
\max\left(0,D-P-\sum_j u_j\right).
$$

These quantities must use a common allocation model. Overlapping bounds must not count as independent available capacity. A late provider credit reduces the original command's exposure and the corresponding reservation. It does not authorize another command for the earlier unpaid amount.

A durable continuation must carry the economic journal, funded resources, reservations, unacknowledged outbox work, and future-action authority. It must also identify the complete authoritative namespaces that these records cover. A partial export that omits a reservation could permit conflicting use of the same funds.

The continuation and duty requirements define the execution boundary shared with Recourse. The referenced local implementation work supports these design requirements. It does not establish production acceptance, provider execution, or distributed institutional transfer. Each production adapter must prove preservation of the required objects through its own receiving decoder and commitment path.

# Smart assets and the execution machine

A smart asset combines an identified asset with executable rules and recorded history. Its legal rights, registry bindings, and custody arrangements remain explicit. The Smart Asset Virtual Machine, or SAVM, evaluates bound programs. The host supplies authority, evidence, persistence, and external adapters.

## Asset identity and state

The current asset definition separates genesis, registry binding, manifest, receipt-chain reference, and lifecycle phase. It also carries compliance posture and an attestation portfolio. Genesis identifies the creator, creation jurisdiction, metadata digest, and creation time. Its canonical digest supplies a cross-zone identity distinct from a local database identifier.

The registry binding records the relevant jurisdiction, registry type, external reference, and binding credential digest. Before registration, that binding can be absent. The manifest declares capabilities, compliance domains, instrument configuration, triggers, and bound programs. A trigger must reference a program included in the binding set.

This structure permits explicit program changes. A new program binding must identify the old program, the new program, transition authority, and applicable state migration. The asset's identity must not silently change because its program changes. The current lifecycle API includes program upgrade, split, combine, and dissolution surfaces.

A split must preserve the relationship between the source asset and resulting assets. A combination must identify every consumed source and the resulting asset. Conservation requirements depend on the instrument's unit and contract. Receipt creation alone cannot prove conservation without the relevant quantities and accepted transitions.

## Lifecycle and compliance

The typed asset lifecycle includes genesis, registered, active, migrating, suspended, frozen, settled, and dissolved states. The current model treats frozen, settled, and dissolved as terminal within that lifecycle. A sanctions freeze is distinct from a temporary suspension. Ordinary resumption must not clear a terminal sanctions decision.

Economic events such as issuance, transfer, distribution, maturity, default, and recovery occur within instrument-specific procedures. They must bind the legal actor, affected right, quantity, evidence, and resulting state. The generic lifecycle enum does not establish that every such procedure is implemented for every asset class.

An asset program may impose additional restrictions or require more evidence. It must not override the runtime's mandatory authority or sanctions gates. A locally computed compliant value does not authorize an otherwise prohibited write. The host rechecks the applicable commitment requirements at the effect boundary.

Compliance posture records a decision under particular evidence and rules. It must retain its evaluation identity and time. A changed rule, revoked credential, or changed beneficial owner can require another evaluation. The old posture remains historical evidence of its earlier assessment.

## VM evaluation and limits

The SAVM uses fixed-width words, a stack, memory, storage, control instructions, and host interfaces. Its execution context binds the caller and jurisdiction. The interpreter records gas consumption, storage mutations, tensor updates, logs, deferred requests, and an outcome.

Current outcomes include success, revert, gas exhaustion, yield, wall-clock timeout, stack overflow, memory exhaustion, and version conflict. A yield preserves a resumption position and can carry an approval requirement. A failed evaluation can still produce a receipt that records the failed attempt.

Resource limits must be enforced at the level where work occurs. Instruction charging bounds interpreter work. Memory limits bound allocation. Wall-clock limits bound elapsed execution. External verification and provider calls require their own bounded admission and cancellation behavior.

The compliance coprocessor provides typed tensor access and controlled updates. It also exposes attestation and proof-verification interfaces. Reproducibility requires the same program, inputs, and coprocessor state. A changed evidence snapshot is a changed input, even when the bytecode remains identical.

## Deferred effects and their limits

Institutional write instructions produce deferred syscall requests. Each request identifies a primitive, target, selector, value, position, and request number. The host processes eligible requests through the mutation boundary after evaluation. VM success and syscall finalization therefore require separate inspection.

The current bridge records syscall audit events. Escrow lock and release requests on this bridge are audit-journaled. They do not establish a custodian hold, balance change, or treasury release. A successful result on that surface concerns the recorded syscall, not settled escrow.

A production materializer must bind each eligible request to an owning service or authoritative provider. It must record exact request identity, authority, resulting effect, and acknowledgment. An unsupported request must fail explicitly or remain a named unresolved effect. The receipt must preserve that distinction for downstream consumers.

The current rollback policy defaults to all-or-nothing eligibility for deferred requests after failed evaluation. Success and yield can leave requests eligible. A checkpoint policy can permit a recorded prefix of requests. This policy selects requests for commitment. It does not make multiple host transactions globally atomic.

Optimistic concurrency checks compare the entity version observed at execution with the current version before deferred mutation. A mismatch requires rejection or another admitted evaluation. This check must remain coupled to the write boundary to prevent a later race. A successful earlier read alone cannot reserve the state.

## Model-assisted replay

Model output is an external input to deterministic replay. Recording an output can make later evaluation reproducible without making fresh model calls deterministic. The retained record must bind the model identity, request inputs, returned decision, rationale reference, and charged resources.

The current replay-cache abstraction derives a key from dispatch input words and an optional model commitment. It retains the first response associated with that key. An in-memory cache supports a single process. Durable replay requires preservation of the cache data and all referenced content across restart and transfer.

A production profile must bind model identity explicitly. It must reject a replay request whose profile differs from the retained record. If two fresh calls race, the accepted historical response must remain singular and authenticated. A later provider response must not replace it under the same identity.

These requirements concern replay of recorded computation. An independently reproducible decision can still depend on incorrect evidence or an unauthorized model grant. Authority verification, evidence quality, and replay verification remain separate checks.

# Receipt chains and independent observation

A receipt chain records related transitions in an ordered, tamper-evident history. The chain binds each transition to its predecessor. An authenticated checkpoint commits to a particular prefix. Independent observation can make conflicting histories detectable when an operator presents different prefixes to different parties.

## Receipt types and commitments

Receipt types reflect different subjects. A SAVM execution receipt records evaluation, including failure and deferred requests. A corridor receipt records a corridor event and its policy bindings. An operation record connects steps, outcomes, and proofs. Their common use of digests does not make them one interchangeable wire type.

The current SAVM receipt contains an execution digest, predecessor digest, sequence, caller, jurisdiction, gas, storage mutations, tensor updates, deferred requests, logs, outcome, and time. It also carries concurrency and rollback information. Its canonical content digest identifies that record. Signature and external anchoring requirements belong to the consuming protocol.

A corridor receipt uses `prev_root` and `next_root`. The latter commits to the current receipt payload after excluding its proof and `next_root` fields. Policy digest sets are normalized before canonicalization. It does not commit to an unknown future receipt.

For corridor receipt $R_k$, define $Q(R_k)$ as that normalized commitment payload. Let $h_{-1}$ be the corridor's genesis root. The chain requires:

$$
R_k.\texttt{prev\_root}=h_{k-1},\qquad
h_k=H(Q(R_k)),\qquad
R_k.\texttt{next\_root}=h_k.
$$

The current chain append checks the expected sequence, predecessor root, and recomputed commitment. It then appends the new root to a Merkle mountain range, or MMR. An MMR is an append-oriented authenticated structure that supports inclusion proofs for its leaves.

## What a proof establishes

The entity **lawchain** is a separate hash-linked history design. Its intended granularity is terminal operations, with a block committing the operation's step-receipt evidence and linking the preceding block. Intermediate mutation events have their separate event history; they must not be described as individually lawchain-anchored. The current database module provides append and chain-verification helpers, but source inspection found no runtime caller that appends these blocks. Its introductory claim of daemon production therefore does not establish implemented terminal-operation anchoring.

An inclusion proof establishes that a specified leaf occurs at a specified position under a particular root and structure. Its meaning depends on the authenticated checkpoint that names that root. The verifier must check the receipt's own sequence and chain binding separately from the MMR path.

A single leaf proof does not establish that an operator disclosed every later receipt. Tail completeness requires an authoritative checkpoint or another accepted freshness reference. A historic checkpoint proves a historic prefix. Its signature does not establish that the prefix is current.

External anchoring can supply evidence that a commitment existed by an independently accepted time. The verifier must validate the anchor's actual record, finality assumptions, root binding, and timestamp semantics. A configured anchor target is insufficient. The claimed root must appear in a verified acknowledgment from that target.

Selective disclosure can reduce the evidence supplied to a reader. A reader can verify a disclosed receipt against a checkpoint without receiving every payload. The reader still needs the dependencies required for the substantive claim. Confidential input availability and cryptographic inclusion are separate obligations.

For reproducible evaluation, the evidence bundle must retain program bytes, evidence snapshots, rule versions, host profile, and recorded nondeterministic inputs. The verifier must compare the resulting claim with the signed commitment. Missing material must produce a precise verification limit rather than a reconstructed placeholder.

## Fork detection and recovery

A fork occurs when distinct transitions claim the same predecessor position under the same chain identity. Detection requires access to the conflicting commitments. A hash function makes a detected conflict tamper-evident. It does not force an operator to disclose both branches.

Independent checkpoints and signed observations can expose conflicting histories. The receiving policy must define whose statements count, their authority, their observation scope, and their validity period. Two copies from one administrative source must not count as independent evidence merely because they have different transport endpoints.

Recovery must preserve both conflicting records. It must identify the authority that selects a valid continuation and the evidence supporting that choice. Arrival time alone is insufficient unless the protocol explicitly accepts that time source and selection rule. The losing branch can contain external effects that require separate resolution.

The current corridor code provides fork, recovery, checkpoint, and observation mechanisms. Production acceptance must exercise their composition under conflicting messages and restart. A receipt-chain implementation alone does not establish that every asset, operation, and corridor shares a deployed fork-resolution service.

## Watchers and admissible observation

A **watcher** is an identified observer that signs a statement about a defined subject. Its statement must specify what it observed and the evidence available to it. The receiving party decides whether that statement satisfies an admissibility rule. A watcher signature does not itself confer authority over the observed institution.

A quorum policy must identify eligible observers, distinctness requirements, threshold, statement binding, and validity conditions. Aggregation can reduce signature size. Eligibility, duplicate rejection, key validation, and policy evaluation remain necessary work. No fixed quorum size follows solely from the use of aggregated signatures.

The current watcher state model represents registration, bonding, activation, slashing, unbonding, deactivation, and banning. It distinguishes equivocation, availability failure, false attestation, and collusion. The API records stake and ownership information and produces mutation proofs. Those records do not alone establish funded collateral at a custodian.

A funded watcher service must connect its recorded bond to an authoritative balance or custody record. Release must respect outstanding claims and the applicable unbonding period. Slashing must identify the offense, evidence, deciding authority, amount, and executed disposition. A bookkeeping reduction requires separate settlement evidence when money moves externally.

The economic argument is conditional. Let $g$ be the gain from a dishonest statement, $p$ its detection probability, and $L$ the enforceable loss. Let $V$ be the service income forfeited after detection. Deterrence requires assumptions sufficient to make dishonesty unattractive, such as:

$$
p(L+V)>g.
$$

This inequality is a design condition, not an observed property of the implementation. It depends on funded collateral, detection, enforceable sanctions, collusion behavior, and the watcher's alternatives. A high recorded reputation cannot establish these assumptions. A production watcher market requires operating evidence for each economic and institutional dependency.

The repudiation watcher is a separate operational mechanism. It reads configured notices that withdraw recognition or standing and triggers follow-up handling. The current daemon remains passive when its notice source is absent. Deployment must verify source authenticity, notice scope, processing, and the resulting restrictions before claiming active repudiation monitoring.

# Corridors and migration

A corridor connects deployments under explicit recognition and execution rules. It carries statements, evidence, requests, and receipts across administrative boundaries. Each receiving deployment retains responsibility for the authority and meaning it accepts. A network connection alone grants no recognition.

## Recognition and projection

For a directed corridor from deployment $A$ to deployment $B$, let $R_{AB}$ describe which statements $B$ recognizes from $A$. Let $\phi_{AB}$ map an accepted statement into the receiving decision model. The direction matters. Recognition from $A$ to $B$ does not imply the reverse relation.

The corridor contract must bind participating authorities, permitted subjects, operations, domains, evidence classes, signature acceptance, validity periods, and recovery rules. Recognition must preserve the source statement's conditions and limitations. A projection must not turn pending evidence into a completed requirement or broaden the recognized subject.

Mutual recognition applies to specified domains and acts. A receiver can accept one recognized determination and independently evaluate another. The resulting decision must retain the source and rule for each component. A configured recognition set is an input to evaluation, not evidence of institutional acceptance by the parties.

Multi-hop routing adds further obligations. Every hop must remain active and authorized for the proposed operation. The current bridge computes routes from directed edges using fees and settlement-time estimates. Its caller must supply eligible active corridors. Route selection does not establish successful settlement or preservation of recognition across the entire path.

## Local protocol states and external effects

The current three-phase orchestrator has `Init`, `Locked`, `Verified`, `Committed`, and `Aborted` states. It is a pure state machine driven by its caller. It validates transitions and collects verification verdicts. Actual storage, message delivery, resource locking, and provider settlement belong to the surrounding integration.

The authenticated path checks enrolled source authority, signed lock and verdict data, zone identity binding, and acceptable epochs. It rejects missing authority configuration. Verifier admission can restrict expensive work through configured resource controls. A successful transition establishes the state machine's permitted next state.

A deployed protocol must persist its state before sending messages that rely on that state. Its messages must bind corridor, operation, subject, generation, phase, policy versions, and replay identity. A receiver must reject conflicting or stale messages while preserving exact replays. A sender must recover unsent or unacknowledged messages from durable state.

Protocol commitment and external settlement must have separate receipts when they have separate authorities. A lock attestation must correspond to an enforceable reservation. A committed protocol decision must remain recoverable after a crash. A payment or title transfer must supply the acknowledgment required by its authoritative system.

Adding protocol phases does not remove network partitions. During a partition, a participant may lack evidence required to release a resource safely. The corridor must state when it waits, when it can abort, and which durable evidence permits commitment. Availability claims require the stated communication and failure assumptions.

## Recovery, time, and resource admission

The recovery model retains collected verdicts, expected participants, timeout information, fencing generation, finalization status, and refund status. Its current resolver preserves a recorded terminal decision. It rejects a committed state that conflicts with a verification rejection. Recovery advances the fencing generation and refuses overflow.

The host must make that generation effective at every later effect boundary. Merely incrementing a stored number cannot stop an old process from sending a provider request. The provider adapter, exclusive credential, or receiving service must enforce the relevant fence. Each action must also satisfy its current authority requirements.

Deadlines require an agreed time interpretation. The canonical-time mechanism combines authenticated time evidence under a selected acceptance rule. A deployment must bind the actual accepted sources and tolerance. Local wall time, an attested reference time, and a provider's acceptance time can support different decisions.

Verifier-gas admission limits resource abuse before expensive verification. The current model includes cost bounds, per-source token buckets, gas escrow records, and admission witnesses. Financial collateral requires a funded settlement path in addition to these resource records. A gas-bond refund must co-commit its release marker with the authoritative release to prevent double refunds.

## Asset migration and institutional presence

Asset migration transfers a defined asset state or custody relationship. Redomiciliation changes an entity's primary registered jurisdiction under the applicable procedures. Adding a harbor establishes another recognized presence while preserving the existing one. These changes can share workflow mechanisms while imposing different legal and operational requirements.

The current migration saga models initiation, compliance checking, attestation gathering, source locking, transit, destination verification, destination unlock, and completion. Its failure states include compensated, timed out, and cancelled. The separate asset-migration protocol models proposal, freezing, destination evaluation, commitment, and abort. These are distinct state models with different payloads.

The generic saga advances state and records compensation information. That behavior does not itself file an exit notice, reverse an accepted registration, or move custody. A production migration binds each phase to an authoritative producer and a durable acknowledgment. Its release decision must inspect those effects rather than infer them from phase names.

For institutional presence, let $J(E)$ be the set of jurisdictions where entity $E$ has an active recognized presence. Adding a harbor proposes $J(E)\cup\{j\}$. Removing a harbor proposes $\{k\in J(E)\mid k\ne j\}$. The accepted change depends on the required registry evidence, continuing obligations, and authority in each affected jurisdiction.

Compliance must evaluate the relevant activity under the applicable jurisdiction set. Adding a harbor does not erase source duties or automatically export every permission. An asset's existing restrictions can survive its movement. The accepted destination state must carry the source history and any unresolved obligations.

## Transfer of execution authority

Transfer of a running institution requires more than export of its visible records. The handoff must include authoritative namespaces, machine states, economic journal, funded resources, reservations, outbox work, future-action authority, and retained evidence. It must preserve duty identity, occurrence, portions, command exposure, and unacknowledged delivery identities.

A **transfer cut** identifies the exact source state admitted for handoff. Preparation can produce additional authorized records after the initial snapshot. These **preparation deltas** must be retained and admitted into the final cut. The receiver must verify current source revisions and reject an incomplete or inconsistent cut.

Each authoritative namespace must supply an authenticated complete prefix. Every cross-namespace effect must appear at its destination or remain in the retained outbox with its exact payload and identity. An empty local list does not prove source completeness.

The predecessor must lose authority to initiate new work before the successor gains that authority. The activation procedure must select exactly one successor generation through durable ownership and effective fences. The successor must restore checked continuations through its exact receiving decoder. It must not reconstruct progress by executing source programs again.

Every later action requires the current generation and action-specific authority. Transfer itself must not issue pending commands, discharge debts, release reservations, or create provider dispatches. Replay must return historical receipts without executing those actions. Pending outbox work remains pending under its original delivery identity until an authorized delivery occurs.

A coherent rollback of all local state can also roll back a locally stored freshness marker. Protection against that failure requires an external monotonic freshness reference or equivalent custody constraint. Cloned stores require exclusive custody or effective fencing. A matching database copy alone cannot establish unique execution authority.

The durable continuation reference work supports this stronger transfer specification. It remains distinct from production integration and distributed institutional transfer evidence. Acceptance requires an actual predecessor fence, exact admitted cut, receiving decode, unique successor activation, and attempted stale-generation rejection.

## Compensation across jurisdictions

A migration failure must leave an accurate account of each jurisdiction's accepted state. The system can reverse a local reservation when its contract permits release. An external registry can retain an accepted filing even after dependent work fails. The recovery record must preserve that fact and assign the remaining action.

Suppose source exit is accepted while destination entry fails. The resulting state may require reinstatement, another destination filing, or an alternative authorized procedure. A local compensated flag cannot establish reinstatement. Recovery closes only when its specified authoritative effects and acknowledgments exist.

Cross-jurisdiction compensation therefore provides controlled follow-up and explicit residual obligations. Atomicity applies to each local transaction. Broader guarantees require proved contracts from every participating service and authority. A specification must name those assumptions before claiming atomic movement.

# Worked example: adding a second harbor

This trace illustrates the required evidence and failure handling for a company that adds a second recognized presence. Jurisdictions $A$ and $B$ are abstract participants. The example assumes that the applicable procedures permit the proposed presence. It makes no claim about a named jurisdiction, configured corridor, or completed deployment.

## Initial state and authored request

Company $E$ has an active presence in $A$. Its record includes controllers, beneficial owners, issued interests, registry bindings, and continuing obligations. It has an unpaid supplier duty and a funded reservation for an authorized payment. These records retain their identities throughout the example.

The controllers request an additional presence in $B$ while preserving the presence in $A$. The authored request identifies $E$, the requested presence, required officers, registered agent information, and the supporting documents. It also identifies the authority approving the change and an exact replay identity.

The operation definition resolves the required work: verify authority, evaluate the proposed activity, prepare documents, collect signatures, submit the filing, and verify acceptance. The contract names the acknowledgment that establishes each completed step. It also names any costs and effects that survive cancellation.

## Admission and durable creation

Mass authenticates the principal and checks the effective grant for $E$ and the requested operation. It verifies the authored program's payload and authority bindings. It evaluates required evidence under the pinned rules for the relevant activity. A sanctions hard block rejects this attempted action before further authorized effects.

The admitted operation is created durably. Its creation proof identifies the operation and the decision supporting creation. The company still has only its established presence in $A$. The new presence becomes active only after the required acceptance and local commitment.

The client receives the operation identifier and observes its progress. It treats generated documents, requested signatures, submitted filings, and accepted filings as different events. A signed creation proof does not cause the interface to display the second harbor as active.

## Signature wait and restart

The document step produces a document with an exact digest. The signing step binds that document to authorized signers and records its pending request. The workflow enters a wait. Its claim can expire without invalidating the pending signing request.

A worker restarts during that wait. Recovery reads the persisted operation and provider request identity. It checks the provider's current response before sending another request. Any permitted redelivery retains the original identity. The workflow does not generate a replacement document merely to restart the step.

The provider callback identifies the signing request, document, signer, and completed action. Mass verifies those bindings and records the event. An exact duplicate callback resolves to the existing event. A changed document digest under the same event identity fails the immutable replay check.

If callback storage succeeds but advancement fails, the retry still uses the same event identity. The durable event remains available to the next worker. The operator can distinguish completed signing from delayed workflow advancement through the stored evidence.

## Filing and acceptance

The filing adapter persists its outgoing intent before dispatch. It binds the target registry, operation, company, document set, and provider replay identity. The registry accepts the request, but the response is lost. Mass records an unresolved external outcome rather than treating the filing as rejected.

Recovery queries the provider or repeats the request under the original identity, according to the provider contract. A verified acceptance returns the registry reference and accepted document relationship. Mass then commits the new presence, registry binding, and required local evidence through the selected atomic write path.

The company now has recognized presences in both $A$ and $B$, as established by the example's assumptions and receipts. Its continuing obligations remain jurisdiction-specific. The unpaid supplier duty and payment reservation preserve their original identities. Recognition of the second presence does not discharge them.

## Delayed evidence and completion

The local mutation commits, but downstream event emission fails. The operation's authoritative local state reflects the accepted presence. Its searchable event history temporarily lacks the derived event. Reconciliation reconstructs that event from the matching audit and outbox records without repeating the filing.

Completion inspection compares the operation with its contract. It verifies the required signature, registry acceptance, local presence record, and required acknowledgments. It records any delayed optional projections separately. If a required delivery remains in dead-letter storage, the delivery obligation remains open.

| Boundary | Required identity | Evidence retained |
|---|---|---|
| Program admission | Principal, company, program, capability | Admitted bindings and decision |
| Signature | Exact document and authorized signer | Verified signing acknowledgment |
| Registry filing | Provider request and company | Accepted registry response |
| Presence commitment | Operation and accepted registry binding | Business, audit, outbox, and proof records |
| Evidence repair | Original mutation and event identity | Reconciled event with causal relation |

## Failure and later transfer

If $B$ rejects the filing, $E$ retains its established presence in $A$. Compensation follows the contract for unused reservations, unsubmitted work, and cancellable provider requests. Accepted costs or retained registry records remain in the history. A new filing with changed information requires a newly admitted request.

If the institution later transfers its running execution to another deployment, the handoff uses an exact transfer cut. That cut includes the unpaid duty, reservation, pending deliveries, authority, and checked continuations. It also includes every admitted preparation delta.

The predecessor is fenced before the successor can initiate work. The successor verifies and directly restores each continuation through its receiving decoder. An exact retry returns a retained receipt without another dispatch. A stale predecessor's attempted payment must fail the current-generation check at the effective action boundary.

Acceptance of this trace requires execution through the selected services and persistence boundaries. The reviewer must inspect the actual provider acknowledgment and current records for the same intent. The illustrative ordering supplies the test contract. It does not supply the execution evidence.

# Claims and admissible obligation transitions

An organization creates obligations when it issues shares, borrows, buys goods, promises a royalty, or accepts a contingent payment. Mass governs the organization and the authority under which it acts. Moxie prices, clears, and settles the claims that arise from those obligations. Their connection must preserve the issuer, governing terms, settlement asset, and evidence of performance through each transition.

These chapters define the required architecture with *shall*. An implementation boundary states the narrower behavior established by current implementation inspection. A defined record or algorithm does not establish a deployed service. Runtime acceptance requires execution evidence for the complete path, including durable effects and recovery after interruption.

## A claim has economic content and an institutional owner

A **claim** identifies a right to a specified payoff under specified conditions. Its economic description includes the settlement asset, payoff program, dependencies, valuation inputs, and period of validity. Its institutional description identifies the issuer, holder, instrument, and legal profile. The legal profile binds the applicable terms and authority requirements.

The claim identifier commits to its canonical content. A change to settlement mode, payoff, terms, or another committed field changes that content. A service shall preserve the distinction between an instrument's continuing identity and a particular claim description. It shall not edit an admitted claim while retaining a commitment to the original bytes.

The holder field alone cannot describe every beneficial position. A pooled claim may name an operator while a position ledger records individual entitlements. Transfer and redemption shall therefore bind the relevant position owner as well as the claim identifier. The operator's control of a pool shall not imply ownership of every entitlement within it.

Consider a supplier's receivable. The institutional record identifies the supplier, buyer, contract, and authority to issue the receivable. The payoff specifies the amount due when accepted delivery occurs. A valuation can discount that expected payment. An assignment can change who holds the entitlement. Settlement must consume the correct entitlement against the correct obligation, even when these records reach different systems at different times.

## Payoff programs and temporal dependencies

A **payoff program** computes a value from committed constants, authenticated evidence, and previously resolved claim values. The program shall use deterministic arithmetic and bounded evaluation. Its commitment binds the operations, operands, ordering, and output selection. An evaluator shall reject a missing input rather than substitute an estimate.

Within a program, each operation may reference only earlier operations. References to another claim's resolved value use a strictly earlier block. In the time-expanded dependency graph, every edge therefore points to an earlier observation:

$$
(c,h) \longrightarrow (c',h-\delta), \qquad \delta \geq 1.
$$

Here $c$ is the claim, $h$ is its evaluation block, and $\delta$ is the declared historical offset. This rule prevents current-block circular evaluation. A dependent payoff cannot require a value whose computation waits for that same payoff. Historical availability remains a separate requirement. Admission shall reject a dependency whose required history cannot survive until consumption.

Current payoff structures include constants, evidence inputs, claim references, arithmetic, caps, floors, conditions, and bounded historical reductions. A historical average and a terminal payment are different operations. The average consumes a declared sequence of observations. The payment consumes an entitlement after the terminal value has resolved.

The settlement mode makes this distinction explicit. **Path resolution** publishes a value indexed by block. **Terminal resolution** fixes one payoff value for subsequent holder redemptions. Repeated path observations shall not mint cash entitlements. Distinct holders may redeem against one terminal value, but each redemption must consume an entitlement that the system already recognizes.

## Probability-weighted discounted cash flows

A probability-weighted discounted cash-flow bundle, or **PDCF bundle**, records a valuation at an identified observation block. Each line contains a signed amount, payment block, probability weight, discount factor, and evidence commitment. The bundle also commits to its probability model, discount curve, and common settlement asset.

Its present value is the deterministic sum

$$
V_h = \sum_{i=1}^{m} a_i p_i d_i.
$$

The signed amount $a_i$ represents an inflow or outflow. The probability $p_i$ satisfies $0<p_i\leq1$. The discount factor $d_i$ is positive. A factor above one remains representable, including for negative-rate assumptions. All payment blocks must satisfy the bundle's temporal rules. Multiplication and accumulation shall detect overflow.

This equation defines a valuation representation. Its interpretation depends on the model that supplied the lines. A model must identify the information set, scenario construction, recovery assumptions, and treatment of mutually exclusive outcomes. Lines that represent separate payments need not have probabilities summing to one. Alternative outcomes of one payment require a model that avoids counting the same payment twice.

For an illustrative receivable, let the amount be 100 settlement units, the payment probability 0.90, and the discount factor 0.95. The bundle yields 85.5 units. That number is a model value. The contractual face remains 100 units unless the terms provide otherwise. Cash in custody remains whatever the custodian actually holds. A legal decision on entitlement requires its own authority and evidence.

A PDCF commitment permits another evaluator to reproduce the calculation from the same inputs. It does not certify the inputs' accuracy or the legal enforceability of the cash flow. A change in estimated probability can change valuation without changing contractual entitlement. A legal amendment can change entitlement and require a new payoff commitment, even if its estimated value stays constant.

## From an authored graph to a terminal contract

A **ClaimGraph** is the typed source representation used to author a product. It records parties, claims, obligations, conditions, and the relationships required by a claim program. A **template pack** supplies the admitted product family and its structural requirements. The compiler validates their agreement before lowering the graph.

The compiler produces an **admissible obligation transition**, or **AOT**. This is the terminal contract consumed by the clearing and settlement architecture. The graph remains available as provenance for the product's meaning. Consensus evaluates the admitted transition under generic rules rather than creating a separate consensus mechanism for each product family.

An AOT binds the following components:

| Component | Required binding | Purpose |
|---|---|---|
| Admission | Principal, signer, nonce, validity and authority | Identifies whose action can commit capital |
| Instrument and obligation | Terms, template, legal profile and graph | Identifies what the parties undertake |
| Compliance and evidence | Attestations, revocation state and source roots | Binds admissibility and observed conditions |
| Execution and reserve | Venue evidence, asset, custody and capital lock | Binds economic effects to funded capacity |
| Settlement and receipt | Job, batch, asset and receipt reference | Connects intent to its resulting execution |
| Release and reliance | Disposition, permitted parties and purposes | Controls subsequent use of the result |

An internally consistent AOT can still lack authority, funding, or available execution support. Admission shall validate each component against the current authoritative state. Equal hashes establish equality of committed descriptions. They do not grant a signer power over an account.

## Implementation boundary

The implementation contains typed claims, PDCF bundles, payoff programs, ClaimGraph validation, and deterministic AOT lowering. Path-resolved claims currently refuse payoff programs that require external oracle evidence. They also reject supplied evidence openings because this mode lacks persisted AOT evidence authority. The admission envelope currently binds signer to principal until authenticated AOT delegation exists. A delegated application must preserve that restriction at submission.

Product definitions and lowering support do not establish a complete issuance or trading service for every represented family. Each family also needs admitted authority, usable custody, settlement support, and evidence through its intended API. The custody and availability chapters specify current restrictions that remain material after compilation succeeds.

# Institutional authority, compliance and recognition

An executable payment needs a valid instruction from a party entitled to give it. A regulated payment also needs admissible counterparties, instruments, and destination conditions. Mass and Moxie carry these requirements across their boundary through typed records with explicit signatures, commitments, validity, and revocation state.

## Authority follows the action

Mass owns the institutional state and operation authority that it issues. Moxie owns admission to its execution state, consensus, clearing, settlement, and native finality. A bridge transfers statements between those authorities. It shall not merge their signing powers or imply that one system may write directly into the other's authoritative state.

An authority record shall bind the principal, signer, permitted action, object scope, validity, and relevant policy. A receiver must establish both signature authenticity and permission for the requested action. A correctly signed valuation report cannot authorize a custody debit. An institution's authority to issue a claim cannot authorize an unrelated party to liquidate it.

The receiver shall enforce replay protection in the authority's domain. Chain identifiers, account nonces, source heights, source nonces, and application idempotency keys have different meanings. An adapter shall preserve them as separate fields. Deriving one from another would conceal the distinction between a repeated request and a newer authoritative statement.

Current state checkpoints carry source height and source nonce as independent coordinates. Their admission checks require monotone progression and authenticated signatures. Reverification of an existing checkpoint must not consume a new nonce. A recovery process must be able to verify retained evidence without impersonating a fresh authority action.

## The product legal profile

A **product legal profile** commits to the jurisdiction and policies governing an instrument. It binds legal terms, eligibility, product boundaries, disputes, finality recognition, recovery, reporting, and permitted reliance. The profile also carries its validity period and revocation epoch.

This separation permits several products to use the same execution machinery while retaining different obligations. A trade receivable, an equity interest, and a loyalty entitlement can share deterministic settlement components. Their transfer rights, disclosures, eligible holders, and recovery rules remain different. A common token representation shall not erase those differences.

The admission process shall verify the specific product structure demanded by its profile. Where a profile requires a Shariah Supervisory Board attestation, the claim must carry the required issuance-specific commitment. The product structure must also match the declared family. A favorable Sharia compliance coordinate alone does not establish those structural or issuance requirements.

The same rule applies to other evidence. An identity attestation concerns its subject and validity period. It does not establish beneficial ownership of every position controlled through that subject's software. An instrument attestation concerns its declared object. It does not certify all future amendments or secondary transfers.

## Compliance is evaluated at the consuming transition

The compliance record covers the canonical 23 domains and distinguishes applicability from evaluation state. A receiver shall validate the canonical shape before combining domain results. It shall retain unknown, pending, expired, and revoked conditions where the contract requires them. Conversion between wire formats shall preserve their meaning.

Claim admission checks the claim's period of validity and the holder's attestation. It checks attestation expiry, subject revocation, jurisdiction agreement, and the legal profile's revocation epoch. A previously admitted attestation can therefore cease to support a later economic action. The resulting refusal does not erase the historical record of its earlier admission.

For an action $x$ at block $h$, the required decision has the conceptual form

$$
\operatorname{admit}(x,h)=
\operatorname{authority}(x,h)
\land \operatorname{eligible}(x,h)
\land \operatorname{funded}(x,h)
\land \operatorname{supported}(x,h).
$$

Each predicate names a distinct obligation. Their conjunction is an admission rule, not a claim that every deployed path currently performs every check. The settlement path shall repeat the checks whose truth can change between reservation and execution. A preflight result cannot carry authority across an intervening revocation.

Suppose an institution reserves funds while a holder's attestation is valid. Before execution, the issuing authority revokes that attestation. A retry using the original signed instruction must encounter the newer revocation state. Signature validity and an unchanged request identifier do not restore eligibility. The failed execution must leave the reserve disposition consistent with the applicable cancellation or recovery policy.

## Issuance provenance and the claim manifest

A **claim manifest** records the institutional origin of an issued claim. It binds the sovereign domain, entity envelope, terms program, and compliance state at issuance. It also names the signing-authority class, legal tradition, template and revision, replay class, and append-only interpretation reference. Its canonical content determines its address.

A downstream reliance record shall identify that manifest and preserve the issuance authority chain. The referenced entity envelope must identify the institution whose rights or obligations the claim represents. A clearing-layer record alone cannot supply missing institutional issuance authority. Later interpretations must retain their relationship to the original act and identify any separately authorized change to economic rights.

The current issuance-chain helper checks structural preconditions. It requires a Mass manifest anchor, consistent manifest references, and a syntactically valid entity-envelope reference. It also requires both the terminal authority link and manifest authority class to be `Zone`. These checks do not resolve every referenced record, authenticate every chain link, or establish deployed receiving-side acceptance. The caller must resolve the cited manifest before invoking the helper.

## Typed compliance assertions and verification scope

A compliance assertion binds the entity identifier, optional operation reference, participating jurisdictional contexts, tensor commitment, classification, and validity times. An optional instrument hint remains advisory. The receiver shall compare the signed subject and operation with the action it intends to admit. Signature verification alone does not establish that contextual match.

The current envelope helper checks protocol compatibility, maximum age, future-clock allowance, expiry, and tensor commitment. It recomputes the classification and rejects disagreement with the asserted tier. For a classified assertion, it also requires at least one explicit `Compliant` or `Exempt` domain. An assertion containing only declarations of non-applicability cannot pass that substance guard.

The helper verifies Ed25519 over the canonical assertion. Its ML-DSA result is explicitly unchecked: `ml_dsa_ok = None`. A present post-quantum signature therefore receives no verification credit from this helper. The deployment must demonstrate the required upstream verification before claiming hybrid authentication. These helper results also leave the refused REST admission paths unchanged.

## Source classification and receiving execution policy

**Temperature** names a compliance-related tier. The source classifier and receiving execution policy use different domain mappings. A bridge shall preserve those mappings explicitly rather than equate tiers by their names.

The Mass classifier requires explicit passing entries for KYC, AML, and sanctions to reach Cold. Warm additionally requires securities, corporate, and custody. Hot requires explicit passing entries across all 23 domains. A missing minimum entry yields Unclassified. In this classifier, passing includes `Compliant`, `Exempt`, and explicitly stated `NotApplicable`. The envelope's separate substance guard still applies.

The receiving temperature model uses a distinct projection:

| Receiving tier | Required active domains | Additional condition |
|---|---|---|
| Cold | Consumer protection and AML | Minimum trading surface remains satisfied |
| Warm | Cold domains plus KYC, securities, and qualified investor | Target-domain gate passes |
| Hot | Warm domains plus full registration, market surveillance, and disclosure | Target-domain gate passes |

These receiving labels do not certify registration, investor qualification, or any other legal status by themselves. They express which domain evidence the model demands. The admitted product profile and action-specific authority remain separate requirements.

The transition helper rejects a request whose source and target tier are equal. An upgrade requires every domain for the target tier. A direct Cold-to-Hot request can pass only with the full Hot set, which includes the Warm requirements. Downgrades pass this helper without an upgrade gate. The receiving consumer separately derives the highest supported regime and handles suspension when its minimum domains fail.

This receiving consumer is not an authoritative end-to-end producer path. Its richer internal observations have no direct public transaction carrier or live Mass producer. Current compound-cycle code derives default grades from cached legacy KYC data. That inference cannot establish the separate domain attestations demanded by the target contract.

The complete bridge shall bind the authentic source evidence to an explicit receiving projection and preserve jurisdiction, freshness, revocation, and missing-domain conditions. Until that projection has an authoritative producer and admitted execution path, a source classification cannot establish a receiving market entitlement. Trading activity itself cannot supply the missing compliance evidence.

## Advisory signals remain evidence

Market observations can inform a valuation or trigger a request for review. Their admission must retain the source, observation time, object, and permitted use. An advisory observation shall not become a compliance decision by passing through a differently named endpoint. A market price shall not become an instruction to move an organization's funds.

A receiver must authenticate the producer authorized for that signal type. It must also distinguish publication from consumption. A durable record that a signal arrived proves arrival. A later operation needs its own record showing how it used that signal, which policy applied, and who authorized the resulting action.

This principle also governs automated reasoning. An agent can prepare terms, estimate value, or propose a settlement. The receiving authority still evaluates the concrete action against its policy and state. Reproducible reasoning helps explain the proposal. Execution authority must come from the authenticated principal and the applicable delegation rules.

## Bilateral recognition and corridors

A **corridor** carries recognized evidence and coordinated obligations between deployments. Its recognition terms are directional. Let $R_{A\leftarrow B}$ describe the evidence classes that deployment $A$ accepts from $B$. Let $\phi_{A\leftarrow B}$ describe the permitted projection into $A$'s decision model.

Acceptance by $A$ does not imply acceptance by $B$. A corridor shall bind both directions explicitly when an operation needs bilateral recognition. The terms must identify accepted signing authorities, subject scope, compliance domains, validity, revocation behavior, and dispute procedures. Recognition of one domain shall not silently waive another domain's checks.

A cross-border claim needs additional economic bindings. Both sides must agree on the claim or obligation references, principals, assets, quantities, rates, and terminal effects. A payment confirmation on one side must refer to the same transaction that the other side reserved. An exchange-rate observation without bilateral acceptance cannot determine an enforceable redemption rate.

Coordination shall retain durable locks, fencing information, acknowledgements, and recovery decisions. A local timeout alone cannot establish that the remote side failed to commit. The recovery protocol must distinguish absence of a response from evidence of abort. Compensation requires its own authorized transition when an external effect has already become final.

The chapters on corridors and dispute resolution define the broader Mass protocol. For Moxie, recognition must also bind native finality to the permitted external purpose. Recourse may supply an outcome through an admitted execution contract. Its administrative record cannot substitute for Moxie consensus authority or proof that recovery occurred.

## Implementation boundary

The current REST boundary refuses three material write paths. `/api/v1/compliance/assert` can verify an envelope but lacks a consensus transaction that admits that assertion. `/api/v1/orders` therefore refuses the dependent order request. It does not allocate a nonce, build an order, sign it, or submit it.

The advisory route `/api/v1/compliance/signal` also refuses requests because governed proxy authority is absent. Native signed Mass attestation and revocation transactions exist separately. Their presence does not make these REST routes operational.

Corridor administration and redemption remain refused by the transaction availability policy. Redemption requires a typed bilateral certificate binding both principals, rate terms, and monotone revocation state. A general Recourse award certificate carrier also remains absent. Award verification, dispatch, finality verification, and recovery reconciliation require further implementation before an award can drive a complete Moxie execution path.

# Custody, clearing and settlement

Settlement must connect a valid obligation to value that the system can deliver. A receipt for an unfunded promise records the promise. It does not create the asset needed to discharge it. The clearing architecture therefore binds obligations to named assets, custody accounts, reserves, and authorized settlement intents.

## Separate the records that answer different questions

A **position** records exposure or entitlement in an instrument. A **balance** records an amount of an identified asset at an account. A **reserve** restricts value for a specified obligation or risk requirement. A **capital lock** binds the conditions under which that restricted value can support or leave an obligation.

These records can refer to the same economic activity without being interchangeable. A buyer may hold an entitlement while the settlement asset remains in shared custody. An issuer may retain a residual claim after funded holders redeem. The system shall identify which ledger answers each question and reconcile their common economic quantities.

For a custody-backed asset $a$, define $C_a$ as recorded custody and $L_a$ as aggregate funded nominal liabilities within the covered ledgers. The required coverage predicate is

$$
C_a \geq L_a.
$$

This is a nominal custody predicate. Marked-to-market solvency additionally depends on prices, exposures, liquidation costs, and recoverability. A reserve denominated in one token cannot cover a liability in another merely because their display names or estimated prices match.

Every reservation shall name the exact asset and custody account. Its amount must use canonical fixed-point units. Interfaces may display decimals, but signing and verification shall preserve raw values. Rounding rules belong to the contract. An adapter shall not select new rounding behavior during a retry.

## Clearing defines permissible offsets

**Clearing** determines the obligations that remain after applying permitted offsets and risk requirements. A clearing set identifies the obligations eligible for common treatment. A netting agreement identifies the authority and terms that permit offsetting. Economic correlation alone does not establish a right to net legal obligations.

Consider two positions that gain and lose equal amounts in a modeled scenario. They can reduce modeled market exposure. If different principals own them, or insolvency rules prevent offset, the clearing process must preserve the gross obligations. Recognition of a hedge requires the required legal and operational bindings as well as a favorable numerical result.

Risk snapshots bind the clearing set, netting agreement, publisher, covered markets, observation block, and expiry. They also carry expected shortfall, stress loss, margin, and haircut-adjusted collateral. An applicant shall not extend the snapshot's covered markets during admission. An empty coverage set grants no market-specific risk credit.

The reserve carried by an AOT must agree with these bindings. A correct reserve amount attached to the wrong clearing set is invalid. A current snapshot for a different market does not justify capital reuse. An expired snapshot requires the prescribed refresh or refusal behavior before the system opens additional risk.

## The settlement intent precedes the receipt

A **settlement intent** authorizes a specific job before execution. It binds the principal's admission, instrument, obligation graph, compliance reference, risk reserve, evidence, execution evidence, settlement job, asset, and reliance terms. The intent's commitment excludes the eventual receipt because that receipt does not exist at authorization time.

After execution, the result can bind the actual settlement batch and receipt to the same authorized body. This separation prevents an orchestrator from creating an arbitrary receipt and using it to justify a different obligation. It also permits a verifier to compare the completed effect against the principal's original authorization.

The conceptual lifecycle has five ordered stages:

1. Authorized intent.
2. Staged transport.
3. Validated effects.
4. Consumed intent and committed effects.
5. Verified receipt.

Transport staging is conditional work. It shall not pay a beneficiary or release a reserve. An implementation that splits a batch into chunks must bind the batch identifier, orchestrator, root, and chunk count consistently. Duplicate or contradictory chunks must fail before economic effects become visible.

## Atomic economic effects

At settlement, the executor shall authenticate the orchestrator and locate the principal-authorized intent for each resolved obligation. It shall recheck authority, validity, compliance, custody, and the bindings between intent and batch. Only then may it consume the intent and apply economic effects.

Intent consumption and its economic effects form one atomic transition. If an effect fails, the system must restore the state before consumption. Otherwise an unsuccessful debit could permanently consume the only authorization capable of completing the payment. The reverse error is equally serious: paying without consuming authorization permits repeated payment.

The current obligation-bound batch implementation snapshots state around these effects and restores that snapshot on error. Production execution with validator signature verification enabled requires an explicitly allowlisted orchestrator. An empty production allowlist refuses every batch. A development configuration with different verification settings must not become evidence for this production authority boundary.

A durable commit still requires a receipt and native finality verification before external reliance. The in-memory atomic transition and persistence after restart are separate acceptance conditions. A complete observation must show that balances, consumed intents, obligation state, and receipts recover together from the same committed state.

## Worked failure: a stale authorization in a complete batch

Assume a batch would pay 60 units to one holder and 40 units to another. Both intents name the same settlement asset and authorized custody account. The transport delivers all chunks and their commitments agree. Before execution, the compliance evidence bound to the second intent's principal expires.

The executor checks the current conditions before consuming either intent's final effects. The expired principal evidence causes refusal. Neither holder receives a partial payout through this batch. If validation discovers the failure after provisional mutation inside the atomic scope, rollback restores that scope. The observable result must preserve both cash and intent state.

This example exercises the implemented principal-compliance check. The payout loop does not independently recheck every recipient's attestation. Recipient-specific validation remains a separate requirement wherever the governing policy requires it.

The orchestrator cannot repair the request by changing the principal or beneficiary while retaining the original commitment. It must obtain the authority required for a changed intent. It also cannot treat the first holder's unpaid amount as recovered value. A retry must identify whether it repeats the same authorized action or proposes a different one.

Now assume the network response disappears after a successful commit. A client shall query the durable job and receipt identity before issuing another economic instruction. Reusing the same idempotency identity must not produce another payout. Selecting a new identifier merely because a response was lost would create a second intent rather than resolve uncertainty about the first.

## Continuing obligations during transfer

An administrator can stop accepting work while an economic duty remains live. The settlement architecture shall preserve that duty across administrative transfer. Its stable identity derives from the issuer's authoritative namespace, constituting act, and occurrence. Changing a template, representation, or administrator shall not create a new duty or discharge the original one.

The economic journal shall retain the beneficiary, debtor, asset, unit, conditions, priority, and disposition of each duty portion. It must distinguish reservation of a duty portion from reservation of cash. The first prevents two commands from satisfying the same portion. The second funds a command's possible expenditure. Transfer shall preserve both under their original identities.

For a partially performed duty, let $D$ be the outstanding amount. Let $P$ be completed performance awaiting attribution. Let $u_j$ bound additional performance still possible under each live command. The permitted new exposure is bounded by

$$
\max\left(0,D-P-\sum_j u_j\right).
$$

The quantities require a common allocation model. Overlapping exposure bounds cannot be counted as independent capacity. A delayed provider response shall update the original command and occurrence. It shall not create another payment simply because a successor received the response.

For example, assume a duty of 125 units has received 40 units. A live command can still deliver 85 units, backed by 85 reserved units. Transfer must carry the residual duty, command exposure, and funded reservation together. It permits no additional command for those same 85 units. A late credit of 60 reduces the residual duty and remaining exposure to 25.

Closing that command at its actual credited amount leaves any unpaid duty intact. A fresh instruction for the residual requires current authority. Revocation may block new dispatch while still permitting receipt of evidence and preservation of the beneficiary's claim. Authority to observe a result and authority to create a new economic effect must remain separate.

Transfer of suspended computation requires a complete, authenticated account of the handover state. It shall include live machine records, economic journals, funded resources, undelivered messages, future-action authority, and retained evidence. Every relevant namespace needs a complete prefix. An unacknowledged obligation-creation message must retain its original delivery identity.

A successor shall restore the checked continuation directly, including its pending request and prior effects. Reexecuting the program from its beginning would risk repeating dispatch. Before transfer commits, the receiving decoder must reproduce the exact checked state. An unavailable decoder leaves an explicit obstruction and an identified continuing custodian.

The ownership transition shall fence predecessor initiation and include every admitted preparation delta. It shall activate exactly one successor under a durable execution generation. Every later action needs that current generation and action-specific authority. Current authority, consumption, resulting continuation, and command receipt must commit atomically. Exact retries return the committed receipt without reexecuting the command.

These requirements define the economic continuation contract. They do not assert a completed distributed transfer implementation. Effective external fencing, authenticated freshness, funded custody, and valid institutional transfer require evidence at their respective boundaries. Copying a complete archive alone cannot establish them.

## Funded claim redemption

Terminal claim settlement fixes the payoff value and applies it to recognized holder entitlements. The current handler requires an immutable funding binding. It refuses redemption by the bound custody account and refuses a second terminal redemption by the same holder. It also verifies funded supply and holder history before consuming entitlement.

A holder can carry direct entitlement or an admitted wrapped representation. Redemption must account for both without counting the same entitlement twice. Current settlement requires removal of outstanding claim AMM liquidity before terminal redemption. The holder must therefore complete that liquidity transition before asking the settlement path to consume the entitlement.

An automated market maker, or **AMM**, holds reserves and quotes trades through a pricing rule. A central limit order book, or **CLOB**, matches explicit orders. Each venue needs its own custody and entitlement invariants. Successful matching shall not create an entitlement that settlement refuses to recognize.

The target market contract makes ordinary and liquidation routes share the same physical depth across accounts and certificate keys. Consumed reservation identities and inventory generations survive release; selecting another key cannot reserve inventory that remains encumbered. A quote alone reserves nothing.

A clearing batch shall bind input root, objective, constraints, rounding, tie-break rules, and work limit. Exhausting the work limit produces a deferred result with retained escrow and intermediate state. Infeasibility requires its own verified certificate. Timeout cancellation releases exact unused reservations once. Terminal settlement accounts for pending batches before releasing pool assets or holder entitlements.

A liquidity-provider withdrawal must check both net entitlement after senior liabilities and physical availability after disjoint backing and depth reservations. Each liability is counted once within each applicable calculation. Insufficient availability prevents both share burn and transfer. A valuation increase supplies no cash. These rules state the required market behavior; they do not activate a currently refused trading path.

## Implementation boundary

The obligation-bound settlement batch is the admitted carrier. The legacy unbound batch is retired and refused. Funded claim CLOB order submission remains disabled until entitlement escrow exists. General order implementation and schema support therefore do not establish funded-claim CLOB trading.

Direct ClubBond principal issuance, minting, transfer, and redemption are confined to controlled chain `421610`. Production chain `421600` refuses that lifecycle pending institutional AOT admission and an explicit activation boundary. Direct nonzero-coupon issuance is also refused because the required coupon authority and entitlement evidence remain incomplete. A represented coupon schedule cannot justify selling an interest-bearing product whose payment path is unavailable.

# Consensus, finality and permitted reliance

Consensus establishes which state transition the validator system commits. A recipient then verifies what that transition did and whether its result supports the recipient's intended action. These questions require related but distinct evidence. The finality contract must keep the committed execution, validator authority, receipt, and reliance policy bound together.

## Deterministic execution under an identified configuration

Let $S_h$ be committed state, $B_{h+1}$ the ordered block input, and $\theta$ the identified execution configuration. Deterministic execution requires

$$
F_\theta(S_h,B_{h+1})=(S_{h+1},\mathcal{R}_{h+1}).
$$

Independent evaluators with the same inputs must produce the same state and receipt sequence $\mathcal{R}_{h+1}$. The input includes the canonical timestamp and every admitted external observation. A validator shall not fetch a fresh price or generate a new model response while reproducing a committed transition.

Ordered collections, canonical serialization, fixed-point amounts, and explicit error rules support this requirement. Configuration is part of the comparison. Running different policy epochs or replaying history under incompatible semantics invalidates a claimed equality. A matching function name does not establish matching execution behavior.

Moxie execution assigns transactions to three ordered phases. The first contains oracle resolution and event settlement, including claim payoff settlement. The second contains trading and clearing. The third contains non-market transactions, including the obligation-bound settlement batch. Consensus ordering must agree with these transaction-specific assignments. Encrypted transaction handling adds another boundary: evidence must establish when plaintext became available relative to the committed order. A post-block balance inspection cannot reconstruct that timing.

## Complete event collections

The proposed event-collection contract fixes chain, parent, candidate domain, authorized sources, evidence rules, and closure policy. Validators persist the materialized objects before acknowledging them and persist a finite signed snapshot before announcing closure. A closure package contains snapshots from the required number of distinct admitted validators, together with their authenticated context.

Resolution operates on the canonical union of those snapshots and records exactly one accepted or deferred disposition for every candidate. Adverse evidence remains in the union. Conflicting admissible source assertions produce witnessed deferral. Invalid surplus evidence cannot defeat an independently admissible certificate. Changing a validator's private inventory after closure must not change the validity of the retained package.

Late evidence enters a durable queue for later collection and receives new acknowledgements under the applicable context. Capacity planning must preserve the complete mandatory candidate domain. An oversized mandatory package requires explicit refusal and a named capacity failure; truncation cannot be reported as a complete collection. Preparation votes remain separate from the complete BFT decision that binds the package.

These are proposed completeness and availability requirements. The existing phase and quorum vocabulary does not establish their implementation. Acceptance must exercise omitted deferrals, adverse and late evidence, missing materialized bytes, and capacity exhaustion through the claimed consensus path.

## Public BFT and sovereign committee modes

The consensus state machine includes event-attestation collection followed by Prepare, PreCommit, Commit, and Decide. Its public Byzantine fault tolerant mode, or **public BFT mode**, uses the conventional $3f+1$ committee envelope and a $2f+1$ quorum. The parameter $f$ is the admitted Byzantine-fault bound for that model.

The safety argument requires more than counting messages. Votes must authenticate distinct admitted validators and bind the same height, view, phase, proposal, and execution commitment. A duplicate signer must contribute once. A vote for another state cannot help certify the candidate state, even when the message has a valid signature.

A separate sovereign fast-path threshold model describes a contracted operator committee. Its certificate policy differs from public BFT. The model requires at least four-fifths of total weight for a direct fast certificate. Its slow path requires both certificate families, each reaching three-fifths of total weight.

These thresholds do not confer interchangeable security guarantees. A verifier shall pin the mode, committee profile, and finality policy for the transaction. It shall reject mixed public and sovereign certificate families. It shall not reinterpret a sovereign certificate as a public BFT quorum to satisfy a receiving institution's policy.

## The finality envelope binds the execution

A **settlement finality envelope** records the block and commitments needed to connect execution with consensus. The binding includes execution block hash, consensus block hash, decide-reveal root, state root, receipts root, certified digest, committee profile root, and finality policy root. Certificate evidence must authenticate the relevant statement under the admitted committee.

A receipt proof then establishes that the claimed receipt belongs to the bound receipts root. The receipt's semantic content identifies the job and effects that it acknowledges. A proof of inclusion for a failure receipt proves that the failure was recorded. It cannot support a claim that the intended payment succeeded.

The relying party shall compare the receipt with its own expected intent. Asset, amount, beneficiaries, job identity, and terminal status must match. A valid receipt for another account or another deployment does not satisfy that expectation. Chain identity and object identity must remain explicit throughout verification.

The following evidence levels answer different questions:

| Evidence | Question answered | Remaining requirement |
|---|---|---|
| Submission identifier | Which request entered a submission path? | Execution and durable result |
| Execution receipt | What result did the executor record? | Inclusion and native finality |
| Native finality evidence | Which execution did the committee commit? | Applicable recognition and reliance policy |
| Recognized disposition | What effect may the recipient treat as settled? | Any external performance or recovery evidence |

An external bank credit, registry amendment, or delivery acknowledgement has its own authority and persistence boundary. Moxie finality can prove a native commitment concerning that external action. The applicable adapter must still establish the external effect through the destination's evidence contract.

## Reliance has a named beneficiary and purpose

A **reliance envelope** restricts which parties may use a result and for which purposes. Examples include recognizing collateral, releasing capital, reporting a settled obligation, or accepting a recovery disposition. The same receipt can be sufficient for one purpose and insufficient for another.

The receiver shall verify its inclusion within the permitted parties and purposes. It shall also check the governing legal profile and current recognition conditions. Permission to inspect a receipt does not grant permission to recognize that receipt as regulatory capital. A value that remains subject to a recovery condition cannot become unrestricted liquidity through relabeling.

Capital release requires a bound authorization that identifies the relevant lock and disposition. A release policy must specify the terminal evidence it consumes and the remaining obligations it preserves. A newer authorization must not replay an older disposition against the same reserve. The system needs durable consumption state for the economic effect.

Recourse outcomes enter this structure through a separately admitted authority path. A case filing, adjudicator decision, submitted execution instruction, and measured recovery remain separate records. The adjudicator's authority must cover the disposition. Moxie must verify and execute the native instruction. The recovery record must then reconcile the actual effect for the entitled party.

## Safety and liveness under interruption

Safety means the system does not accept conflicting committed results under its stated fault assumptions. Liveness means an admissible action can progress under the specified network and availability assumptions. A timeout affects progress evidence. It does not authorize a conflicting commitment or prove that a remote action failed.

Recovery shall retain the committee and policy context that authenticated each commitment. A restarted process must restore nonce frontiers, consumed intents, settlement state, and the commitments needed for receipt verification. Reconstructing balances while losing consumed-intent state would reopen payment authority. Reconstructing receipts while losing the corresponding balances would misrepresent performance.

Operational acceptance must therefore exercise interruption across the actual persistence boundary. The observation must identify one integrated binary, configuration, validator topology, and intent. It must bind the recovered records to the same causal identifiers. An isolated restart test and an unrelated successful payment cannot jointly establish this property.

## Implementation boundary

The current certificate model separates public BFT from sovereign fast-path certificates and rejects mixed families. The node, proof API, and SDK verifier currently reject sovereign fast-path finality. This mode requires a separately committed sovereign roster and signature path. Its threshold model does not establish an executable finality mode. The sovereign slow path checks the presence and weights of both observations. Those observations do not yet structurally bind one certificate to the other or enforce their ordering. A fully linked slow-path proof remains a further obligation.

The configured default block interval is 2,000 milliseconds. That constant is a scheduling parameter, not measured finality latency. This specification asserts no throughput or latency result from it. Current performance and readiness require an identified production execution with a faithful, independently operated validator topology.

# Risk, oracles and execution availability

Clearing depends on assumptions about future loss and evidence about current conditions. The implementation must record both. A deterministic calculation can reproduce an incorrect assumption exactly. Risk controls therefore need authenticated inputs, declared coverage, expiry, conservative refusal behavior, and a clear connection to the economic action they protect.

## An oracle contributes a scoped observation

An **oracle** supplies an observation that execution cannot derive from its own committed state. A price report identifies its market, value, source, observation time, and receipt time. An event report additionally needs the event, resolution condition, and authority permitted to attest it. Price estimation and adjudication of contractual performance are different functions.

An oracle consumer shall verify the source authority and preserve the signed payload's exact meaning. It shall check freshness against the relevant time domain. Receipt time cannot replace observation time. A recently delivered report about an old market state remains old evidence.

The price aggregation implementation distinguishes institutional, validator-attested, and on-chain reports. It supports weighted median aggregation and outlier filtering. Its stale-result check measures time since aggregation. It does not enforce the age of the underlying observations. Reaggregating old reports can therefore produce a recently timestamped result from old observations. Observation-age validation remains a required correction at this price boundary. The separate event-attestation execution path rejects future observations and observations outside its permitted age. That event-specific check does not repair the price aggregator. Those mechanisms describe how admitted reports combine. They do not establish that every configured source is connected, independent, or authoritative for every instrument.

Source correlation matters. Several reports can share one upstream provider while presenting different transport identities. A quorum policy shall define the independence assumptions it requires. A record count alone cannot establish independent corroboration. The risk model must account for sources that fail or become misleading together.

Payoff evidence must also bind to the admitted obligation. An authenticated delivery report about another shipment cannot resolve the current receivable. A valid price at another observation block cannot silently replace the specified fixing. Missing evidence shall leave the relevant resolution incomplete or produce the contract's explicit refusal.

## Margin and stress are conditional estimates

**Margin** reserves resources against an exposure under a declared risk model. Initial margin constrains new risk. Maintenance margin identifies conditions requiring corrective action on existing risk. A haircut reduces the recognized collateral value to reflect its modeled liquidation or recovery limits.

Expected shortfall summarizes loss in the selected distribution's tail. Stress loss records exposure under specified adverse scenarios. Both depend on the scenario set, parameters, observations, and model interpretation. Their commitments must make those dependencies identifiable. A numerical margin result without its input image is insufficient for reproducible risk admission.

Cross-margining can recognize modeled offsets within an authorized portfolio. It must preserve a residual requirement for basis risk and respect legal netting boundaries. Capital savings depend on the portfolio, model, and constraints. This specification grants no universal multiplier from the existence of a cross-margin implementation.

Risk admission shall bind the snapshot publisher, markets, clearing set, netting agreement, validity, and collateral image. A consumer shall reject an unsupported market or stale snapshot. A favorable risk estimate must not bypass an independent sanctions, custody, authority, or product-boundary refusal.

Suppose a portfolio contains a receivable and a derivative that hedges its market price. The price hedge can reduce market-risk estimates. It does not necessarily hedge the buyer's default, a disputed delivery, currency controls, or a stay on enforcement. The model must preserve those residual exposures where they affect the reserve or recovery assumptions.

## Liquidation and recovery need executable authority

A liquidation rule identifies when an account needs corrective action and which actions can restore its required coverage. Detection alone does not perform liquidation. The executing path needs authority, executable liquidity, asset access, and atomic settlement of the selected effects.

A liquidation record shall bind the trigger, risk image, selected positions, prices, costs, and resulting balances. If the selected venue cannot execute, the system must retain the unresolved exposure. It must not report the modeled proceeds as recovered cash. A subsequent recovery process may need different authority and a different disposition.

Insurance and reserve funds also have bounded roles. A nominal fund balance does not prove that the fund covers every possible loss. Its permitted uses, priority, custody, and depletion behavior must be explicit. A breaker that stops new risk after drawdown preserves one boundary. It does not prove that all existing obligations remain solvent.

Release and recovery shall remain distinguishable. A release returns value because the relevant obligation permits it. A recovery records value obtained after a failure or adverse disposition. Both require reconciliation to the entitled party, asset, amount, costs, and source evidence. A legal award amount may exceed the value ultimately recovered.

## Availability is checked before and during execution

The transaction schema contains both supported and refused variants. An API can parse an object whose production semantics remain unavailable. The availability policy shall therefore apply at construction, estimation, external admission, proposer admission, and consensus execution where those surfaces exist.

Consensus must enforce the same deployment-specific restrictions as public ingress. Otherwise a proposer could insert a transaction that an ordinary client cannot submit. Metadata and gas estimation shall not advertise execution for a transaction that the canonical submission path refuses.

Availability can depend on the exact deployment domain. A controlled chain used for one bounded product lifecycle must not imply availability on every nonproduction chain. The policy shall specify the complete lifecycle's domain so that issuance cannot create an obligation whose matching redemption is refused there.

Current refusals include EVM execution, conditional orders, stop-event and parlay orders, corridor administration and redemption, ephemeral markets, personas, auctions, and tickets. Their missing properties differ. Some lack funded trigger settlement. Others lack issuer authority, asset escrow, terminal delivery, or a binding redemption certificate. A generic feature label cannot convey those requirements.

## Acceptance evidence for a product path

A product path shall identify its intended user action and required durable effects before it claims completion. Acceptance must exercise the actual API, admitted authority, and persistence boundary. It must include the first material refusal that could falsify the claimed path, such as expired authority or repeated settlement.

For a funded claim, the observation must connect issuance to custody, entitlement, execution, terminal resolution, and redemption. It must compare amounts and identifiers across the complete path. If the claim uses a bridge, the observation must include the destination's authoritative acknowledgement. A locally constructed proof request establishes only the request's construction.

The runtime invariant report distinguishes **Pass**, **Violation**, and **Skipped**. A skipped row means that the observation boundary lacked the state needed to evaluate the predicate. A report with no violations can still contain incomplete coverage. A post-block guard cannot establish encrypted-mempool timing, validator fault tolerance, or economic properties absent from its inputs.

Formal models require equally explicit scope. A bounded abstract compliance model can establish properties of its modeled transition. It does not establish equivalence to the deployed executor. An authority proof that abstracts hash validation leaves that cryptographic binding outside its result. A single-slot consensus model without an explicit message network cannot establish production liveness under partial synchrony.

## Implementation boundary

The implementation provides risk snapshots, margin calculations, oracle aggregation, custody checks, and explicit transaction refusals. These components require source-identified execution before they establish a complete operational claim. Current invariant coverage deliberately records several predicates as skipped because the guard cannot observe their required state.

No universal solvency, legal enforceability, cross-border atomicity, or automatic recovery claim follows from these component structures. Each product's acceptance record must name the assumptions and external obligations that remain. An unsupported transition shall remain visibly unavailable until its authority, economics, persistence, and receiving-party evidence are complete.

# Causal evaluation and accountable performance

A coupon can resolve while its payment remains incomplete. Two missed USD 10 coupons followed by a successful trigger can create USD 30 due. If the provider pays USD 20, the remaining USD 10 survives the reset of the coupon calculation.

These chapters propose the economic requirements that connect calculation, authority, funding, and performance. **Shall** states a required property. A **reference construction** gives a mathematical model or bounded realization under stated assumptions. The cited papers supply constructions and proof obligations. Governing instruments and admitted implementation contracts determine which transitions a deployment may perform.

## Order every producer of an input

A **producer** supplies a typed value at a scheduled event. Claim calculations, oracle reports, clearing results, risk calculations, and settlement observations are producers. Its contract shall identify its output unit, schedule, authority, implementation or external semantics, and complete read set. A read set includes data dependencies and dependencies that control which branch executes.

The historical payoff profile orders claim references by earlier block heights. The reference construction in *The Claim as Primitive* also permits certified dependencies within one event. Let $h$ be a nonnegative integer event height and $N\geq1$ bound its active producer count. Give each producer $v$ a dimensionless integer rank $r_h(v)$ between zero and $N-1$. Its combined rank is

$$
R(v,h)=Nh+r_h(v).
$$

A same-event read shall use a producer with smaller local rank. A historical read shall name an admitted instance at an earlier height. Each dependency then decreases $R$. Finite read sets give a finite ancestor set. Completion additionally requires admissible external evidence, fair scheduling, and computation within the admitted resource limits.

For example, an account observation supplies USD 100. A gross calculation reads it, a fee calculation applies one tenth, and a net calculation subtracts the fee. Their ranks order the observation, gross amount, fee, and net amount. The resulting USD 10 fee and USD 90 net payment become obligations only through their respective position legs. An auxiliary rate or risk calculation creates its value and retained evidence without creating another payment entitlement.

The certificate shall cover all relevant reads, including conversion witnesses and both branches of a conditional. An external producer retains its explicit dependency-completeness assumption until its actual semantics establish those dependencies. An oracle that reads clearing, where clearing reads the consuming payoff, produces a cycle despite an acyclic local payoff program.

A rejection shall identify that cycle. A permitted historical lag can remove it when the earlier input exists and remains admissible. A simultaneous model instead needs an existence result, an admitted solution-selection rule, and certified numerical execution. Changing a producer's label or computation budget supplies none of those conditions.

## Preserve directed entitlements

A **directed entitlement** records an amount owed by a specified debtor to a specified creditor. Its stable origin identifies the issuance, position lot, resolution event, and contractual leg. It shall bind the original program, inputs, parties, asset, governing terms, payment window, and discharge route.

Let $q$ be a signed quantity in contracts and $v$ the resolved payoff in settlement units per contract. Their product $z=qv$ determines direction, while $A=|z|$ is the amount due. A positive $z$ makes the contractual counterparty owe the holder. A negative $z$ reverses those roles. Exact retries shall return the same origin record. Assignments change the effective owner through an authorized transition while retaining the original record.

For one entitlement, let $L$ be effective legal discharge and $B$ the unpaid balance, both in its settlement unit. The journal shall preserve

$$
A=L+B,\qquad 0\leq L\leq A.
$$

A payment increases $L$ only through a supported allocation or another expressly authorized discharge rule. A return can reduce $L$ through the governing reinstatement rule. A command's cancellation or completion does not determine these quantities.

A correction shall append a directed adjustment against the latest accepted correction. If $z_0$ is the original signed amount and $t_j$ the newly authorized target, define

$$
d_j=t_j-z_0-\sum_{i<j}d_i.
$$

All terms use the same asset and account orientation. Acceptance shall compare and advance the correction predecessor atomically. Targets of 100, then 80, then 70 require adjustments of minus 20 and minus 10. The original entitlement and each adjustment retain separate unpaid balances until payment or authorized setoff. Their algebraic sum alone supplies no setoff authority.

## Allocate actual performance once

A **physical occurrence** is one actual transfer or delivery under its authoritative provider identity. Repeated reports, reporting aliases, and different claim references shall resolve to that occurrence. A receipt records evidence about it. Its quantity becomes usable only under the admitted identity, beneficiary, asset, finality, and attribution rules.

Allocation shall use stable portions of that quantity. An implementation can represent monetary portions as intervals in an exact settlement unit. The portion identity retains its physical source when its owner changes. Across the affected products and accounts, every portion has one effective allocation history.

Exclusive allocation governs the specified cash or title resource. Shared performance evidence can support separately constituted rights without creating additional goods, title, or cash. For example, one accepted delivery can earn both supplier consideration and a separately contracted handling fee. Each payment still needs its own funded discharge.

At a reconciled evidence revision, let $Q$ be supported quantity and $U$ unallocated quantity. Let $R$ denote reserved quantity or reconciliation holds, and $S_c$ supported allocation to claim $c$. These disjoint quantities shall satisfy

$$
U+R+\sum_c S_c=Q,\qquad U,R,S_c\geq0.
$$

Disputed historical allocations remain recorded outside supported capacity. For a USD 100 receipt allocated USD 60 and USD 40, a correction to USD 90 exposes USD 10 of disputed support. The governing correction rule identifies the affected portions. Restoring the receipt to USD 100 restores those portions to their retained owner before any free capacity is calculated.

An evidence correction creates a new assertion about the same occurrence. An actual refund creates a distinct debit occurrence. Ordinary spending by the recipient changes current cash while preserving the original payment attribution. These operations shall retain separate identities and consequences.

Returned credit crossing stores shall remain `ReopenPending` and encumbered until the authoritative original ledger commits reopening and required current admissions verify. A destination's receipt of money alone shall not release that credit for another obligation. The retained record shall identify the original payment, its portions, the return, and the accepted reopening. Recovery must continue when either side has committed and the other side remains unresolved.

Reopening shall preserve consumption of the original payment's portions. Only the separately identified return can acquire new eligibility under its governing allocation rules and the required admissions.

Authentic historical receipts shall retain their exact bytes. Current reliance separately evaluates effective policy, revocation, and retroactive compromise. A changed reliance decision shall append its basis and affected consequences without replacing the historical receipt.

## Commit allocation with the obligations it changes

The joint transaction shall include affected occurrence revisions, portions, funding reservations, claim bases and versions, balances, and authority dependencies. It shall commit request nonces, consumed identifiers, command outcomes, and receipts with those changes. It shall also bind the policies that determine this complete footprint. A claim-local update cannot leave its payment portions available elsewhere.

One authoritative store can serialize this footprint in a durable transaction. Independent stores require a durable preparation, decision, and recovery protocol accepted by each authority. External delivery remains outside a local database transaction. An uncertain delivery retains its reservation until conclusive reconciliation. Exact committed retries shall return the retained receipt without another allocation or dispatch.

*Event-Collect BFT* supplies a narrower, useful allocation construction. A closed batch contains finite eligible occurrences and payable obligations in one divisible unit and direction class. An admitted compatibility relation specifies which occurrence can serve each obligation. Fixed allocations and reconciliation holds reduce available supply before optimization.

Consider two one-unit occurrences, $a$ and $b$, and two one-unit obligations, $x$ and $y$. Occurrence $a$ can serve either obligation, while $b$ can serve only $x$. Assigning $a$ to $y$ and $b$ to $x$ completes both. Assigning $a$ to $x$ first can leave one unit unusable.

The construction represents this problem as a capacity-constrained flow. A cut separates source and destination, and its outgoing capacity bounds every feasible flow. A feasible flow whose total equals a cut's capacity has maximum value. The reference orders compatible pairs by their pinned occurrence and obligation identifiers. Among maximum totals, it chooses the lexicographically greatest allocation vector, comparing the first unequal coordinate.

A residual graph records permitted increases and decreases to a proposed flow. Further cuts in that graph certify the canonical choice. The certificate shall bind current supply, demand, fixed portions, holds, compatibility evidence, authority, and predecessor state. Atomic application consumes the batch identity with its resulting allocations and receipt.

This theorem concerns the admitted closed batch. Binding priority, aggregate limits, indivisible lots, and all-or-nothing packages need explicit feasible-set constraints. Future arrivals can permit a better unrestricted allocation while existing legal assignments remain fixed. The paper's single-store realization assumes authentic acts, one authoritative ledger for shared physical roots, and durable transactions. Deployment refinement must establish those assumptions through the actual allocation and persistence boundaries.

# Capital sufficient to complete obligations

A plan that pays USD 100 before receiving USD 100 has zero net cash loss and needs USD 100 at the payment deadline. Completion requires cash at each permitted decision, with every resulting debt retained. A margin estimate answers a different, specified risk question.

## Calculate the cash needed by each continuation

*Central Counterparty Risk in Automated Markets* constructs a finite observable state graph. A state records the history available to the decision maker. It includes unpaid obligations, resource limits, encumbrances, provider conditions, and action authority. States may merge only when their retained information permits the same future continuations.

At state $s$, the permitted action set is $A(s)$. Selecting action $a$ first pays $d(s,a)$ and retains a cash floor $h(s,a)$. A subsequent observation selects a successor $z$ from $Z(s,a)$ and supplies signed cash increment $g(s,a,z)$. All cash quantities use one declared settlement unit. If current cash is $b$, the next cash balance is

$$
b'=b-d(s,a)+g(s,a,z).
$$

Each admitted action has a nonempty successor set and finite signed increments. Debits, floors, and terminal payments are finite and nonnegative. The action and outcome data depend on recorded noncash state. Cash affects their feasibility only through the specified requirements.

Every intermediate deadline and payment-order constraint shall have its own state. A facility draw must occur before a payment that needs its proceeds. Terminal state $t$ has payment requirement $m(t)$, including every remaining repayment, fee, and represented obligation.

Define $K(t)=m(t)$. The required cash for each action and state is

$$
T(s,a)=d(s,a)+\max\left\{h(s,a),\max_{z\in Z(s,a)}[K(z)-g(s,a,z)]\right\},
$$

$$
K(s)=\min_{a\in A(s)}T(s,a).
$$

The minimum of an empty action set is positive infinity. It identifies a state that finite cash cannot complete under the permitted actions.

For finite acyclic graphs with finite action sets, backward induction gives an exact result: a completing policy exists precisely when $b\geq K(s)$. The model assumes that retaining additional cash preserves permitted continuations. Necessity follows because the selected action must fund its immediate debit and every possible successor. Sufficiency follows by selecting a minimizing action and repeating the same argument at the observed successor.

The minimum precedes the maximum because the action is chosen before its outcome becomes known. Reversing their order would give the decision maker information from the future. Every provider-failure branch required by the stress contract shall appear among the successors. An omitted branch remains an omitted obligation of the model.

## Keep risk reserves and funding distinct

**Expected shortfall** averages loss over a specified upper tail of a probability distribution. Its tail fraction, information set, horizon, and loss model shall be explicit. For four equally likely losses of 0, 0, 0, and 100 settlement units, the worst-half average is 50 units. If an observation separates the first pair from the second, the conditional worst-half averages are 0 and 100 units. Their worst-half average is 100 units.

Conditional risk budgets can restrict permitted actions. The completion calculation still requires actual cash and the correct receipt order. Replacing its maximum over possible successors with expected shortfall changes the guarantee from every represented branch to the stated risk budget.

For a selected policy $\pi$, let $K_\pi$ be the completion recursion restricted to that policy's actions. An independently retained margin $M$, constant through terminal discharge, gives requirement $K_\pi(s)+M$. Margin already included in the floors or terminal obligations shall be counted once. A changed margin requires a current funding check. Released cash becomes available only through the governing release authority and encumbrance rules.

Degraded operation shall retain the maximum of the current floor, stress and physical-risk requirements and the immediately preceding committed required margin. Each committed update becomes the retained requirement for the next update, including across restart. If that preceding requirement is unavailable, collateral release remains blocked until it is reconstructed. An unknown legacy requirement cannot be replaced with zero or a fresh healthy calculation. An initialization rule must establish that no prior requirement exists; an absent record does not prove that condition.

Restored model health alone cannot clear degraded mode. Recovery requires a recorded decision, healthy checks, fresh synchronized inputs, completed repricing, and reconciled settlement obligations. New risk and withdrawals remain halted during degraded operation. Physical-risk coverage retains its declared uncertainty set and calibration assumptions.

## Retain facility repayments and shared capacity

Assume a facility supplies USD 60 before a USD 100 payment. It requires USD 65 repayment after a separate USD 65 receipt. Its draw limit permits one draw. Initial completion cash is USD 40. Adding independently retained margin of USD 30 gives this sequence:

| Event | Cash balance | Remaining constraint |
|---|---:|---|
| Admission | USD 70 | USD 30 margin remains reserved |
| Facility draw | USD 130 | USD 65 repayment becomes due |
| Payment | USD 30 | Margin remains intact |
| Separate receipt | USD 95 | Repayment still requires performance |
| Repayment | USD 30 | Margin awaits an authorized release |

For completion cash alone, removing the later receipt raises the draw route's initial requirement to USD 105, including repayment cost. An available cash-only route requires USD 100. Adding a facility-failure branch also raises the original route's root requirement to USD 100. The separate USD 30 margin remains additive in each case. These amounts follow from the stated timing and branch assumptions.

A draw shall consume remaining facility capacity and create its repayment liability. Mutually exclusive branches may share an undrawn limit. Concurrent plans require one joint resource state and aggregate reservation. Changing the product, claim, or service name shall not create another limit against the same account.

For workflow $f$, a durable cash projection can use

$$
C_f=b_f^0+F_f+R_f-P_f-W_f.
$$

Here $b_f^0$ is assigned initial cash, $F_f$ physical funding, $R_f$ returned cash, $P_f$ gross physical payments, and $W_f$ released cash. Each term uses unique physical occurrences in the same asset and unit. Returned cash in this projection remains subject to its reopening encumbrance. Facility promises enter capacity records and add cash only when their physical credits arrive.

Preparing a payment shall reserve both its duty portion and available cash. An unresolved command retains possible further expenditure. Graph progress shall wait for the required payments, observations, and reopened obligations. Repeated reports create no additional cash. A previously released amount remains subtracted even if an earlier payment later returns.

The finite reference correspondence covers one controlled durable store, integral settlement quantities, truthful admitted observations, current permissions, and represented resource capacities. Live timing, custody, facility enforceability, and complete provider behavior require independent evidence. Multiple currencies need separate balances and admitted conversion actions. Closing a workflow shall preserve any unpaid duty, outstanding command, or unsettled recovery obligation.

# Reserve instruments, title and market risk

A reserve market needs transferable instruments with defined owners and redeemable rights. A number produced by a payoff calculation acquires those properties through custody, title, funding, and redemption rules. Market pricing shall retain their separate economic roles.

## Account for physical title and redelivery

*Allocated Title* assigns permanent identities and quantity coordinates to physical lots. Reporting aliases, custody movement, and assay revisions retain those identities. Supported portions are free, reserved, allocated, or held for reconciliation across the participating accounts and custodians. Impaired evidence reduces usable support while retaining ownership and any resulting deficit. Restored support returns to its retained owner.

Registered title and beneficial ownership can belong to different parties. A transfer shall specify which interest changes, with current authority, required acknowledgments, and continuing restrictions. Redemption shall lock existing units and identify beneficiary, provider, quantity, delivery evidence, and remaining entitlement. Partial performance consumes only its supported portion. An exact committed retry returns its historical result without changing current locks or unpaid balances. Pending retries retain their original command identity.

Lending requires the holder's signed election and current product authority. The election shall bind borrower, quantity, term, fee, and security. Borrower acceptance and custody release convert present allocated title into the corresponding redelivery obligation. That claim supplies no present metal inventory.

Actual redelivery requires intake, assay, uniqueness, and capacity checks. A partial return leaves the remaining quantity due. A pledge preserves title while adding the admitted security interest. Redemption shall retain its restrictions until effective release or authorized enforcement.

Physical performance can itself earn payment. In the paper's proportional example, a 100-kilogram obligation carries USD 1,000 consideration. Accepted delivery of 40 kilograms earns USD 400 and leaves 60 kilograms undelivered. Acceptance shall bind the receiving party's reserved decision, exact physical portions, and every required measurement, custody, and delivery witness. It creates one original directed payment entitlement. Later corrections append their monetary consequences while preserving accepted performance and actual payments.

Continuing the same right through another execution cohort shall retain those allocations and current liabilities. A fresh program instance cannot refresh the underlying goods budget. Conditional title and the seller's funded settlement entitlement can share one legally operative durable decision under the required instruments. This construction requires exclusive metal and funded-asset reservations, rights that survive interruption, and authority at the decision stage. Physical handover and withdrawal still require their own performance evidence. Executed custody instruments, pledge perfection, measurement truth, and product-specific authority remain external obligations.

## Fund a signed payoff without losing its financing leg

The reserve construction in *The Claim as Primitive* handles a bounded signed payoff $f$ for one resolution, measured in settlement units. Suppose $-L\leq f\leq U$ throughout the declared funding domain, where $L,U\geq0$. Choose a positive buffer $\epsilon$ in the same unit. Set

$$
a=L+\epsilon,\quad b=U+\epsilon,
\qquad W^+=a+f,\quad W^-=b-f.
$$

Both note payouts are positive and their sum is $a+b$. A complementary pair therefore requires that many dedicated settlement units. Its net gains are $W^+-a=f$ and $W^--b=-f$. The transferred note and its principal contribution or financing debt shall remain separate records.

For $f\in[-2,3]$ and $\epsilon=1$, the notes pay $3+f$ and $4-f$ against seven units of backing. At $f=-2$, payouts are one and six, while net gains are minus two and plus two. Ten pairs require 70 dedicated units. A market's trading cash is a separate resource and cannot also be counted as that backing.

Recurring payouts need separately funded instances or explicit aggregate reservations for the admitted schedule. An unbounded signed payoff requires a margin and default construction, or successively funded intervals, because a finite shift cannot cover every possible payout. Failure to fund the next interval shall preserve existing entitlements and their recovery route.

## Finance changes to an automated market

An **automated market maker** maintains reserves under a pricing rule. Changing that rule can transfer economic value even when its asset inventory stays fixed. *One-Way Coupling of Prediction Markets to Automated Market Makers* gives a funded construction with a separate sponsor account.

Let $B$ be asset inventory, $B_*$ an anchor inventory, and $x=\log(B/B_*)$. Let $g>0$ be a dimensionless control and $K>0$ an anchor cash reserve. Pool cash obeys $M=Ke^{-gx}$. A control change to $g'$ at unchanged inventory requires

$$
\Delta=K(e^{-g'x}-e^{-gx}),\qquad M'=M+\Delta,\qquad C'=C-\Delta.
$$

The sponsor balance $C$ and transfer $\Delta$ use the same settlement unit as $M$. Admission requires funded $C'\geq0$, an allowed control interval, and an allowed inventory band. Pool and sponsor changes shall commit atomically. Concurrent control requests share the same sponsor reservation.

An asset trade at fixed $g$ exchanges the exact inventory and cash changes against the trader, while respecting the inventory band. Together, these rules conserve pool, sponsor, and trader cash, as well as their combined asset quantity.

Within this closed, fee-free construction, restoring initial inventory and control gives aggregate trader cash gain $C_0-C_T\leq C_0$. The bound identifies the financing source. Reporting incentives and outside portfolios require their own payoff contracts and enforceable funding. The construction supplies no independent claim of truthful signals or deployed sponsor custody.

## Express hedges in compatible units

A derivative profile shall bind contract multiplier, payoff asset, funding-payment rule, fee schedule, and payment clock. For an illustrative linear hedge, ten spot units offset five short contracts only when each contract represents two asset units. At USD 20 per asset unit, each side has USD 200 notional. The local price exposure cancels under those assumptions. Basis changes, periodic funding, liquidation costs, timing, and counterparty default remain in the obligation and risk models.

Cross-margining shall evaluate those legs in one full loss model. Candidate hedge discounts cannot subtract the same risk factor twice. In *Central Counterparty Risk in Automated Markets*, let $R_{\mathrm{full}}$ be the full portfolio loss charge, including nonlinear and numerical allowances. Let $m_{\mathrm{floor}}$ be its admitted minimum margin. Both are settlement-currency amounts. The required margin is

$$
m_{\mathrm{cross}}=\max\{R_{\mathrm{full}},m_{\mathrm{floor}}\}.
$$

Candidate discounts shall not reduce this result further. The derivative's actual periodic funding contract remains a required product input.

The proposed perpetual-position contract retains funding across position changes. Each generation binds account, market, signed size, entry price, settlement asset, margin, funding index, accrued funding, realized claims, and lifecycle. Before changing size or side, compute newly accrued funding using the old size and side. Add that delta to durable accrued funding and advance the index in the same transition.

Funding settlement reduces accrual only through supported committed performance. Insufficient margin leaves a residual. A zero-size generation remains while margin, funding, or another claim survives; reopening creates a fresh generation. Account equity includes every unsettled generation while counting shared collateral once. Changing the active-position pointer cannot hide a debt or credit.

Reductions, closes, liquidation, and automatic deleveraging follow the same preservation rule. A haircut can reduce an eligible profit claim under its governing contract. It cannot independently debit posted margin or create cash. These requirements prevent a position lifecycle change from being mistaken for settlement.

Pricing covariance also needs its stated interpretation. A log-partition cost is a scaled logarithm of a positive weighted sum of exponentials of portfolio payoffs. Its Hessian, the matrix of second derivatives, is proportional to payoff covariance under the associated pricing probability law. Physical loss forecasts require a separately justified observation model, horizon, and calibration.

*Parlay Identification of Ising Couplings* recovers a two-event interaction from a strictly positive joint probability table. A parlay pays when both named events occur. Singleton and parlay prices determine that table under the stated pricing interpretation. Inside a larger network, the inversion gives an effective pair interaction that can include other events' influence. Pairwise compatibility alone cannot establish a joint law for the whole portfolio.

Risk admission shall therefore retain the complete loss map, compatible probability evidence, parameter uncertainty, and information available at each decision. Those records support a funding decision only together with the authoritative cash, title, reservation, and obligation records defined above.

# Cases, consent, and evidence

Recourse records disputes and specifies how authorized outcomes can reach the systems that control the affected records and assets. Its case model connects allegations, evidence, procedural decisions, and requested relief. Each connection must preserve who asserted a fact, who decided it, and which authority permits the next action.

Recourse owns case administration and its records. Mass controls changes to organizational and regulated state. Moxie controls consensus, claim pricing, clearing, and settlement. A custodian controls assets under its accepted mandate. These responsibilities require separate acknowledgements because each system applies its own admission rules.

The current implementation includes case intake, artifact custody, signed lifecycle actions, institutional procedure, and durable SQLite records. Configured modules add referrals, portable outcome recognition, execution instructions, native proof verification, and recovery reconciliation. Retained verification records demonstrate bounded local execution with synthetic institutions, destinations, and native proofs. Production acceptance and authentic native economic execution remain open. The following chapter gives the concrete operating contracts and evidence limits.

## A case and its claims

A case groups a dispute between parties under a submitted agreement. A *head of claim* identifies one allegation and its requested relief within that case. Its identifier remains stable when procedure, evidence, or destination mapping changes. A claim in this procedural sense can concern a Moxie financial claim, but the identifiers denote different objects.

The intake record includes claimant and respondent identifiers, legal names, and optional jurisdictions. It also includes the institution, governing law, arbitration seat, agreement, filing document, heads of claim, and related objects. The service rejects identical claimant and respondent identifiers. It records the other fields as submitted assertions, subject to structural validation.

A head includes a non-nil UUID, dispute type, description, optional monetary amount, and subject references. Subject references identify affected peer objects. Case-level related objects provide context. A filing accepts between one and one hundred heads with distinct identifiers. Each head permits up to one hundred subjects, and the case permits up to one hundred related objects.

These bounds constrain the current wire contract. They do not define institutional jurisdiction, a damages ceiling, or a threshold for tribunal procedure. An institution must derive those limits from the applicable instruments and its adopted rules.

The following notation summarizes the conceptual relationships. It is specification notation, not an additional request schema.

```text
Case = (case_id, filing, revision, evidence, events)
Head = (head_id, allegation, relief, subject_refs)
SubjectRef = (system, native_context, native_id, kind)
ArtifactRef = (digest_algorithm, digest_value, media_type)
```

A Mass subject retains its zone and native UUID. A Moxie subject retains its chain and native 32-byte identifier. The case UUID must not replace either identifier. Any adapter must retain the mapping between case, head, destination request, and destination object.

## Identity and authority

An authenticated account establishes who submitted a request under a configured grant. Tribunal authority requires separate evidence. The current service binds a bearer-token digest to a tenant, actor DID, validity period, optional case scope, and independent read and write permissions. It takes the tenant and actor from that grant. Request bodies cannot choose a different acting identity.

Case access also checks the local origin, filing parties, and current claim-scoped delegation or appointment. Whole-case reads require authority covering every claim. Protocol actions have separate checks for their submitted scope. Mutation responses return the relevant receipt, while complete records require current read access. Current access checks also precede saved-response replay.

Consent names the institution, review, service, execution, and reconciliation principals. Configured keys establish their cryptographic identities and permitted roles. Delegations bind the represented party, claims, powers, instrument, effective time, and expiry. Human tribunal members require appointment, signed acceptance, disclosures, covered claims, and current procedural authority.

Consent verification must connect the exact agreement bytes to the parties, covered claims, adopted rules, seat, and institution. The verification record must also establish representation authority where a representative acted. A supplied agreement digest identifies bytes for later checking. It does not establish that both parties accepted those bytes.

Institutional appointment requires the appointing body's decision, named tribunal members, claim scope, acceptance, disclosures, and appointment instrument. Registration in a directory provides discovery information. An appointment verifier must check the actual appointment and applicable conflict decisions before accepting a tribunal signature.

Legal effect depends on the applicable agreement, authority, procedure, and jurisdiction. The architecture records the evidence needed for those assessments. A software signature check establishes a cryptographic relationship under specified keys. The legal assessment must establish the signer's capacity and the effect of the signed act.

## Evidence contents and provenance

The service stores evidence references with a kind, description, expected case revision, authenticated submitter, and submission time. Available kinds include record extracts, agreements, submissions, expert reports, and service receipts. A separate upload operation verifies and stores exact artifact bytes. The evidence identifier and the custody identifier remain distinct records.

An artifact reference contains an explicit SHA-256 or BLAKE3 algorithm and a lowercase hexadecimal digest. Its media type accompanies the digest. A verifier must retain the algorithm rather than infer it from the digest length. Distinct algorithms can produce equally long strings while expressing different commitments.

The evidence contract preserves original bytes and custody metadata. Signed actions bind referenced artifacts to their prior custody records. The case must also preserve provenance, verification results, and the applicable trust profile. Retrieval, digest matching, signature verification, authority verification, and admissibility decisions are separate operations. Failure at one stage must remain visible even if another stage succeeds.

For example, an expert report can match its submitted digest while its signature belongs to an unauthorized person. A correctly signed report can still fall outside the expert's appointment scope. Conversely, a disputed document can remain relevant as an allegation or exhibit. The case record must distinguish admitted evidence from material retained for review.

Document custody must record transfers, access decisions, and any derived representations. A translation or redacted copy needs its own digest and a reference to the source. A retrieval failure must preserve the reference and report the unavailable bytes. It cannot silently replace the source with a later copy.

The disclosure policy must identify which parties and reviewers can access each artifact. A hash alone does not provide confidentiality, and a case event may itself disclose sensitive allegations. The current access model checks claim scope, while network transfers require signatures over the exact disclosed material. Recognition currently discloses a complete source case and its artifact custody. Cases requiring sealed deliberations or selective outcome disclosure need a supported disclosure profile before transfer.

## Service and time

Service establishes delivery under the applicable procedure. A signed service record binds the document, recipient, delivery method, evidence, and relevant times. A competent institution or tribunal then records the finding that makes delivery effective for protocol deadlines. The service must retain failed delivery attempts and disputed acknowledgements.

Deadline computation must preserve its triggering event, rules, calendar, time zone, and calculation. A UTC recording time identifies when the service stored a record. It cannot by itself establish when a recipient received notice or when a legal period started.

Uncertain service affects subsequent procedure. The institution must resolve the uncertainty or record a supported procedural decision before advancing an affected claim. A timer firing successfully proves that software observed a configured time. It does not prove effective service or expiration of a legally applicable challenge period.

## Local persistence and replay

The implemented service begins each case at revision one with a `case_filed` event. Evidence submission increments the revision and adds an `evidence_submitted` event. SQLite commits the snapshot, event, and successful response record together. The database obtains its writer lock before replay and revision checks.

The mutation identity is the tuple of tenant, authenticated actor, method and resource path, and idempotency key. The key accepts one to one hundred twenty-eight visible ASCII characters. The stored request digest uses SHA-256 over serialization of the parsed body. JSON spacing and object member order therefore do not create a different request.

A repeated identity with the same body returns the original successful response after current access checks. A different body produces an idempotency conflict. Replay lookup occurs before revision comparison, so an exact retry remains valid after later evidence changes. The caller retrieves the case separately when it needs the latest revision.

A fresh evidence request must state the current revision. Two requests cannot independently consume the same revision because the transaction acquires the SQLite writer first. A stale request receives a revision conflict. It must obtain the current record and reassess its intended change before using a new key.

Events have increasing revisions within a case. The event query uses an exclusive revision cursor and a bounded page size. Database triggers prohibit event update and deletion. These controls support local audit and polling. Signed protocol actions additionally bind the complete preceding protocol state. Their ordering remains local to the case.

The local configuration uses a write-ahead log and full synchronization. Durability still depends on SQLite, the operating system, and the storage device honoring their contracts. A successful local transaction establishes the recorded local mutation. Peer effects require their own authenticated acknowledgements and evidence.

# Procedure, outcomes, and stays

Resolution requires an adopted procedure for the affected claims. The case record must show the institution's authority, the parties' procedural rights, the evidence considered, and the decision-maker's reasons. A single case can require different treatment for separate heads of claim.

The current action contract implements record resolution, an expedited tribunal, and a full tribunal. Signed lifecycle actions record distinct determinations, awards, settlements, challenges, and stays. Their evaluator checks consent, jurisdiction, service, procedure, appointment, and signature requirements before returning a resource for atomic persistence.

## Selecting and adopting procedure

Record resolution addresses a question that the accepted record decides under the adopted rules. An expedited tribunal addresses matters eligible for a shorter adjudicative procedure. A full tribunal provides the procedure required by contested integrity, a hearing request, a party election, or other applicable conditions.

The implemented pure assessment function proposes a full tribunal when record integrity is contested, a hearing is requested, or a full tribunal is elected. For a legal or discretion question, it proposes an expedited tribunal only within the supplied aggregate ceiling condition. Otherwise, it proposes a full tribunal. If those conditions are absent, a decisive record produces a record-resolution proposal. The remaining input produces an expedited-tribunal proposal.

The function consumes assessment booleans. It does not establish their truth, calculate an institutional ceiling, or adopt a procedure. The institution must retain the supporting evidence, applicable rules, aggregate calculation, notices, objections, and adoption decision. A procedural proposal cannot serve as its own authority.

Pleadings identify the positions and relief that each party advances. The procedure must bind submissions to their authorized representatives and admitted claim scope. Amendments require an explicit record of the changed allegation or relief. Existing evidence and earlier positions must remain available for review.

A hearing record must identify its participants, scope, admitted submissions, and relevant procedural decisions. Transcript access and the treatment of deliberations follow the applicable disclosure policy. Automated record comparison can assist the tribunal. Any issue that requires judgment remains assigned to the authorized decision-maker.

## A case with several heads

Consider an illustrative dispute between a seller and a buyer. The seller alleges an ownership-record error, unpaid consideration of USD 120,000, and an incorrect event outcome affecting a financial claim. These are hypothetical facts used to explain the contract.

| Head | Subject and requested relief | Procedural question |
|---|---|---|
| Ownership record | A named Mass entity and a proposed record correction | Does the accepted signed record establish the requested ownership entry? |
| Unpaid consideration | A named payment obligation and USD 120,000 | What amount is due, and does a valid defense affect payment? |
| Event outcome | A Moxie event and affected financial claim | Which facts and authority profile can support a native outcome proposal? |

The filing preserves all three heads and their distinct identifiers. A corridor relevant to the ownership head belongs in that head's subjects. A corridor mentioned only in case context cannot automatically become the payment target. The Moxie event retains its chain context even if the same parties appear in the Mass records.

Suppose the parties accept the signed ownership record but dispute whether a delivery condition satisfied the payment obligation. The institution may assess the ownership question for record resolution under its rules. The payment issue requires the eligible tribunal procedure. A hearing request or contested record integrity changes the proposal accordingly.

The institution must calculate any aggregate ceiling under its actual rules. Splitting one economic dispute into several heads cannot silently reduce the amount used for that calculation. The filing amount field supports a nonnegative decimal string and a syntactically valid currency code. It performs no exchange-rate conversion or institutional aggregation.

The event-outcome head adds a destination constraint. Even a valid award must map into the authority and certificate requirements accepted by Moxie. The case can reach a supported legal outcome while its requested native effect remains unavailable. The record must expose that remaining obligation.

## Determinations, awards, and settlements

A determination records covered claims, the record considered, reasons, agreement, service receipts, and a challenge deadline. Its legal consequences depend on the adopted procedure. The service must preserve that type when later steps occur. A change of label cannot convert a determination into an award.

An award record identifies the exact signed instrument, tribunal appointment, signatures, verification profile, seat, issue time, and finality material. The configured verifier must connect each signature to the appointed human and the signed scope. It must also check relevant appointment validity, conflicts decisions, service, challenges, supersession, and stays.

A settlement record identifies covered claims, the signed agreement, and verified party consent. Each permitted effect requires its own scope and destination mapping. If an agreement settles only the payment head, the record must leave the ownership and event-outcome heads distinct.

The current outcome action supplies a unique identity and the exact signed outcome. Its protocol resource retains the action request, signatures, derived verified signers, recording time, revision, and rules snapshot. The evaluator checks the required institution, human tribunal quorum, or distinct party signatures before admission.

The outcome signature binds the document, reasons, claims, obligations, procedure, and selected evidence records in their explicit order. The evidence digest covers identifiers, submitters, times, revisions, kinds, descriptions, and artifact references. Historical verification retains its original profile and authenticated bytes. Current reliance must evaluate subsequent revocation, challenge, and compromise information separately.

A transport representation can carry the outcome as a credential or another structured document. Its representation must preserve the signed instrument and authority evidence. Credential serialization alone establishes neither tribunal appointment nor destination acceptance. Each consumer must verify the evidence required for its intended reliance.

## Stays, challenges, and supersession

A stay restricts specified actions under an authorized order. The signed stay action binds covered heads, order bytes, authority, scope, disposition, effective time, optional expiry, and its predecessor. Dispositions distinguish imposing, varying, and lifting a restriction.

A variation or lifting record must reference an existing order within the same scope. The active restriction derives from verified orders and their applicable times. An administrator cannot lift a stay by replacing a status field. The service must retain the earlier order and subsequent decisions.

Before dispatch, the execution service must check the latest case revision and effective restrictions for the requested heads. An unresolved order, contested authority, or uncertain timing blocks the affected request pending review. Unaffected heads can proceed only when their independence is established under the applicable decision.

A later stay cannot erase an effect already completed at its destination. The record must preserve submission, acceptance, completion, and order timing. Any remedial transfer or correction requires its own authority and destination operation. The remedy must not overwrite the completed effect's evidence.

# Execution, finality, and recovery

An outcome can require a record correction, custody instruction, asset transfer, payment, or native event proposal. Each effect needs a destination that supports it and authority that the destination accepts. Recourse must preserve the difference between the outcome, requested instruction, delivery attempt, acceptance, finality, and recovered asset.

The current execution module implements a durable outbox, bounded dispatch, independently checked effect observations, and signed recovery reconciliation. It accepts exact voluntary transfer instructions under configured custody or native transfer profiles. Native award enforcement and general institutional transfer remain separate integration requirements. The service holds no party, tribunal, or transaction signing key.

## Binding the requested effect

An execution intent must identify its case, verified outcome, covered heads, destination profile, native target, action, instruction, authority, policy, expected revision, and expiry. The destination profile resolves through trusted operator configuration. It must bind the endpoint, peer identity, network context, protocol, trusted keys, and proof requirements.

Target contracts distinguish a Mass zone and operation, a Moxie chain and event with legal-policy roots, and a custodian with account and mandate references. A generic asset identifier supplies insufficient account or mandate scope for a custody instruction. Each target must resolve to the exact effect that the outcome permits.

The conceptual admission condition is:

$$
\operatorname{Dispatchable}(i,r,t)=
V(i)\land A(i)\land S(i)\land D(i)
\land R(i,r)\land T(i,t)\land U(i).
$$

Here, $V$ means verified outcome scope, and $A$ means accepted execution authority. $S$ means that applicable stays permit the action. $D$ means the destination supports the exact action and profile. $R$ checks the required case revision, while $T$ checks expiry. $U$ requires reconciliation of prior delivery uncertainty and prior effects. This predicate states required controls, not a proven implementation theorem.

An unsupported action must fail before dispatch. A record-correction instruction must not become a generic dispute-state transition. A payment instruction must identify the intended beneficiary, currency, amount, and account scope. An action name grants no authority by itself.

## Native peer projections

The current Mass filing projection selects one head and an explicit target zone. It preserves party details, the head identifier, decimal money, institution, and filing digest. It requires a SHA-256 filing digest and rejects incompatible destination field limits. Corridor selection uses the selected head's subjects and rejects ambiguity within that zone.

The destination filing schema has no separate agreement, arbitration-seat, or complete subject-reference fields. Recourse must retain them and bind the returned dispute to the selected head. The projection maps governing law into the destination jurisdiction field. A future adapter must verify that the value is an accepted jurisdiction identifier.

A projected request is a pure transformation. It sends no HTTP request and creates no peer acknowledgement. An eventual Mass write adapter must supply destination authentication, contract version, stable idempotency identity, and client-intent correlation. The adapter must preserve the submitted artifact digest separately from the destination's signed commitment.

Current Moxie helpers construct receipt and finalized-block-proof queries. Native 32-byte identifiers, chain identity, BLAKE3 commitments, canonical transaction bytes, signature domains, and numeric encodings must survive the boundary. Recourse monetary strings express human decimal units. They cannot be passed directly as raw fixed-point amounts without an explicit, checked conversion.

General Recourse award execution remains unsupported at the inspected Moxie certificate boundary. A native event outcome requires its accepted authority certificate. Retired event-resolution submission cannot bypass that requirement. An institutional outcome adapter needs an agreed certificate and policy mapping before dispatch can become available.

## Durable delivery and uncertainty

The execution module commits an authorized intent, exact instruction bytes, case revision, event, replay response, and outbox entry in one local transaction. An *outbox* is the durable queue that records pending destination submissions. Its entry must survive a process restart before any network request occurs.

Each attempt must preserve the destination request identity, exact request digest, profile, attempt time, and response or uncertainty. Retries must retain the same economic meaning and peer deduplication identity. The worker must recheck authority and stays when it claims the entry. Material case or profile changes require reassessment before submission.

A network timeout can occur after a destination accepted the request. The service must record uncertainty and reconcile through the destination's authenticated status or receipt interface. Creating a new economic request merely because the first response was lost can duplicate the effect.

Local idempotency cannot establish exactly-once execution across independent systems. The destination has its own deduplication namespace and retention policy. The adapter must retain the local-to-peer mapping and determine whether a retry remains covered. Unknown history or expired deduplication requires explicit reconciliation before another economic effect.

Terminal rejection requires a recorded refusal and reason. A worker must not convert rejection into a fresh intent without a new authorized decision. If a destination accepted an instruction before a later stay, the case must retain both facts and their timing.

## Acceptance and native finality

Execution and recovery observations must distinguish the following evidence:

| Observation | Required binding | Meaning |
|---|---|---|
| Blocked or declined | Intent and supported reason | A control or destination prevents the requested action. |
| Submitted | Exact request and native operation identifier | The request entered a delivery path. |
| Accepted | Authenticated acknowledgement and request identity | The peer accepted the identified request. |
| Finalized | Native proof, trusted profile, and expected effect | The specified effect satisfies that proof profile. |
| Recovered | Independent recovery evidence and reconciled effect | The recorded asset or amount reached the specified recovery state. |

A Mass proof consumer must check the expected zone, signature, required admissibility class, and commitment to the relied-on effect. Transport response fields require reconciliation with signed commitments and authenticated audit data. A successful dispute transition to an enforcement state does not alone prove payment or asset movement.

A native authority-register operation can change authority and retain audit evidence while leaving economic recovery unproved. Recourse requires a destination-accepted carrier for its outcome, obligation, exact target action, and current action authority. The accepted result must expose the signed claim preimage, proof profile, trust context, and actual allocation or effect identifiers.

Moxie finality verification requires a native finalized-block proof, an independently trusted historical committee, the expected block coordinates, and the applicable reliance profile. Receipt inclusion must bind the exact receipt and its effect. A response cannot establish trust by supplying its own committee or policy as an authority.

Advisory settlement envelopes must remain distinct from authenticated finality evidence. A self-consistent envelope hash is insufficient when the signed block commitment does not bind that envelope. Native consensus finality also leaves any off-chain delivery obligation to the corresponding custodian or recovery process.

![Evidence progression for an execution or recovery instruction. Each acknowledgement has its own meaning; uncertainty preserves the last established state.](manuscript/figures/required-effect-evidence.png){width=6.5in}

## Duties, exposure, and reservations

A duty retains its issuer's authoritative namespace, constituting act, and occurrence index. A new administrator, template, or representation must preserve that identity. The economic journal must retain each duty's portions, beneficiary, debtor, asset, unit, condition, priority, and disposition. Changes to rights require their own authorized acts.

An outstanding amount alone cannot determine safe dispatch capacity. A previous instruction can remain capable of delivering value after a timeout or administrator change. Let $D$ denote the outstanding amount, $P$ completed performance awaiting attribution, and $u_j$ each live command's possible additional performance. New exposure must respect

$$
\operatorname{NewExposure}\leq
\max\left(0,D-P-\sum_j u_j\right).
$$

These quantities must use one allocation model. Overlapping bounds cannot become independent sources of capacity. Duty-portion reservations prevent two instructions from satisfying the same portion. Cash reservations secure the possible expenditure of a command. The service must preserve both reservations under their original identities.

An escrow instruction requires evidence of the actual hold, its owner, beneficiary scope, release policy, and accepted custodian authority. A case filing cannot create a hold by assertion. A verified ruling can supply one required release condition, while the custodian still applies its mandate and current restrictions.

Late performance reduces the original command's residual exposure. Closing that command at its actual credited amount leaves any unpaid duty outstanding. Protected client property must retain its ownership and restrictions during reconciliation or transfer. It cannot become an administrator's continuity reserve.

## Recovery after an uncertain payment

Continue the illustrative payment head. Assume a verified outcome and accepted mandate authorize a USD 120,000 payment through a configured custody adapter. The outbox worker submits the instruction, but the connection closes before it receives the response. The case now has a delivery attempt with an unknown outcome.

The operator retains the same request identity and obtains authenticated reconciliation evidence from the custodian. An authenticated acknowledgement confirms acceptance. That acknowledgement permits an accepted observation, while the expected beneficiary credit remains unresolved. The service must continue reconciliation rather than classify the case as recovered.

Suppose the custodian later confirms a USD 70,000 beneficiary credit and a held remainder. Recovery records must identify the credit, beneficiary, asset, time, and related instruction. The outstanding amount is USD 50,000 under these illustrative assumptions. Fees, currency conversion, offsets, or alternative discharge require explicit terms and separate evidence.

A stay then restricts further payment. The service records the completed credit and blocks the unresolved remainder under the verified order. It neither deletes the credit nor describes the whole award as recovered. A later lifting order can authorize reconsideration of the remaining obligation after current destination reconciliation.

## Preserving unfinished computation

A case can await an authorized answer, provider evidence, or an observation that determines a later payment. A *continuation* contains the remaining computation and the state needed to resume it. Closing an administrator's case list cannot discharge that pending work.

A durable continuation must bind the checked program and dependency profile, host identity, instance name, creation nonce, request ordinal, and remaining logical work. It must retain the control term, captured environment, continuation frames, signed history, admitted effects, and exact pending request. A request description alone omits the executable state.

The receiving runtime must restore checked continuation objects directly. It must recheck the program and resolve stored references without executing again from the program root. Captured functions retain their checked bodies and environments. Dependent values retain the shape required by earlier accepted values. Historical request order and effect history must remain complete.

Before committing a suspension, the service must apply the receiving decoder and require an exact round trip of the stored state and reconstructed request. A structurally valid decoding still needs authenticated provenance from an admitted execution. The durable record must authenticate instance identity, program profile, revision, complete state, and command receipts.

Current authority governs a new reply. The host must serialize its authority revision, reply consumption, resulting continuation, and command receipt in one atomic commit. Historical signature validity remains evidence of the earlier act. It cannot authorize a new use after revocation.

An invalid signature, value, scope, or effect must preserve the pending request and logical work. Failed-command records remain distinct from consumed replies. An exact command retry returns its committed receipt before runtime invocation, including after later commands. The historical receipt identifies its revision and does not replace the current state.

A local reference construction implements direct checked-state restoration, decoder checks, authenticated persistence, and serialized authority consumption for a bounded language fragment. That source evidence supports the specified mechanisms. It establishes neither production Recourse acceptance nor complete refinement from the mathematical model to a deployed implementation.

## Transferring custody of live work

Transfer requires a complete account from every relevant authoritative namespace. Define the continuation cut as

$$
C=(\mathcal N,V,M,J,R,O,G,E).
$$

Here, $\mathcal N$ identifies the namespaces and $V$ their authenticated complete prefixes. $M$ contains live machines, while $J$ contains the economic journal. $R$ records funded resources and reservations, and $O$ retains undelivered messages with their original identities. $G$ records authority for future actions. $E$ retains evidence, disclosure duties, and routes for subsequent notices.

The cut must include case administration, prepared decisions, external commands, claim evaluations, duties, deposits, and continuing disclosure obligations where relevant. Each source establishes the completeness of its contribution. An empty local list supplies no evidence that another namespace has no outstanding work.

A completed evaluation can create a duty whose delivery remains unacknowledged. The outbox must retain that message under its original delivery identity until the destination acknowledges it. Succession must neither discard the message nor regenerate the duty under a new identity. Physical occurrences likewise retain their identities across custodians.

The predecessor must fence new initiation at an identified execution generation. A *fence* rejects actions from an earlier generation at the actual execution boundary. Existing commands remain observable and reserved because a local fence cannot recall a provider instruction already sent.

The successor must receive the complete cut, establish decoder compatibility, and accept custody under current authority. It must also establish funding and custody for each retained resource. A final compare-and-swap must check current source revisions and the exact cut. Every admitted change during preparation must enter that cut before activation.

One durable ownership transition must activate exactly one successor and prevent the predecessor from initiating further work. Each later action checks both the current execution generation and its own authority. Custody grants no additional adjudicative, payment, or provider permission. Transfer and replay must preserve duties, reservations, pending messages, and execution evidence without dispatching or discharging anything.

A single serialized coordination domain can implement the ownership transition atomically. Independent institutions require an agreement and protocol that make their fences effective. Copying valid records into two active stores does not establish exclusive custody. An unavailable decoder leaves the machine with an identified continuing custodian or a recorded transfer obstruction.

Authenticated state also requires freshness. A current-state commitment detects an old record substituted into a newer committed set. Restoring the complete coherent set can evade that check unless a monotonic anchor exists outside the rollback domain. Production acceptance therefore requires an external freshness anchor or an equivalent storage premise, effective fencing, secure identity, and bounded resource admission.

Institutional transfer remains conditional on actual authority, custody, provider controls, and the applicable legal arrangements. The reference construction supplies local evidence for a restricted computation and persistence model. Its checks do not establish distributed institutional transfer, provider performance, or a machine-checked proof of the full construction.

## Evidence needed to enable execution

Resolution acceptance requires execution through authenticated APIs and durable storage. Retained local checks exercise signed proceedings, custody, two-deployment exchange, process restart, dispatch uncertainty, and synthetic recovery. This manuscript review inspected those records without rerunning the checks. The tests must challenge forged roles, mismatched claim scope, invalid appointment evidence, stale revisions, active stays, and caller-selected trust sources. Artifact retrieval and signature tests must bind the actual bytes and configured profile.

Dispatch verification must cover crashes around local commit and network submission, duplicate attempts, lost responses, peer rejection, and unavailable history. Tests must check the resulting destination effect and retained causal identifiers. A passing local replay test cannot establish peer deduplication or financial completion.

Recovery verification must reconcile the expected effect against independent destination evidence. Partial amounts, wrong beneficiaries, contradictory receipts, later stays, and duplicate observations require explicit outcomes. The case can close a procedural issue while recording an unresolved recovery obligation. Its final record must state which claims, effects, and amounts the evidence actually resolves.

# Recourse protocol and operating contracts

Recourse administers consent-bound proceedings and carries their outcomes toward authorized execution. Independent deployments retain their own institutions, records, rules, keys, and acceptance policies. Network routing, practitioner matching, adjudication, and recovery each have distinct records. A signed referral can begin institutional review without opening a proceeding or authorizing payment.

The implementation reviewed on 6 September 2026 is committed with retained source hashes and verification output. The account below describes its contracts and the scope of those local checks. Synthetic execution evidence establishes neither sovereign operation nor authentic native economic effects. Checked computation transfer and destination-recognized award effects remain additional design and integration obligations.

## Identity, configuration, and exact authority

A deployment identity contains `network_id`, `node_id`, `jurisdiction`, and `operator_did`. Its institution configurations bind tenant, institution, authority profile, and protocol rules. The database retains the network and deployment identity. Startup rejects an attempt to reuse that database under another identity.

Deployment jurisdiction, arbitration seat, governing law, party jurisdiction, institution, Mass zone, and Moxie chain remain separate concepts. Configuration examples for candidate jurisdictions establish neither an operating institution nor adopted legal rules. Each institution must obtain the actual instruments and accepted principals for its functions.

HTTP authentication uses a bearer-token digest bound to a tenant and actor DID. A grant also carries read and write permissions, validity times, revocation, and optional case identifiers. Case checks then enforce local origin and current procedural access. A request body cannot choose a different tenant or authenticated actor.

Cryptographic authority uses an operator-supplied `AuthorityProfile`. Each trusted key identifies one principal, permitted roles, Ed25519 public bytes, validity period, and optional effective revocation. Duplicate key identifiers, duplicate public keys, weak keys, and duplicate role entries fail configuration validation. Key rotation can retain several keys for one principal, but that principal counts once toward a signature threshold.

`SignatureEnvelope` contains only a statement and signature entries. Each entry carries `key_id` and `signature_hex`. The statement has the following exact binding:

| Fields | Required meaning |
|---|---|
| `domain` | The fixed wire value `recourse.authority.v0`. |
| `network_id`, `node_id`, `tenant_id`, `institution_id` | The independently expected sovereign and institutional context. |
| `profile_id`, `profile_version` | The configured authority profile. |
| `case_id`, `purpose` | A non-nil case or context UUID and the operation-specific purpose. |
| `payload_sha256` | SHA-256 of the canonical typed payload. |
| `issued_at`, `expires_at` | The signed validity interval. |

Payload serialization uses RFC 8785 JSON Canonicalization Scheme. Numeric values must be integers within the exact interoperable JSON range. Larger counters and decimal amounts use schema-defined strings. The signature message is the domain's UTF-8 bytes, one zero byte, and the canonical statement bytes. Ed25519 signs that complete message without an additional caller-selected prehash.

Verification independently selects the expected context, purpose, role, and threshold. It checks every supplied signature, payload digest, validity interval, key status, and distinct principal. An invalid extra signature rejects the envelope even when other signatures satisfy the threshold. A signature cannot install its own trust root or confer case authority through an asserted role.

The authority envelope has no generic nonce field. Case actions prevent new replay through revision, predecessor-state digest, and unique action identity. HTTP idempotency separately preserves the result of an already admitted request. Native financial instructions retain the nonce required by their destination protocol.

Current verification applies effective revocation even to a previously issued signature. Stored verification evidence retains the historical act and its authentic bytes. Current reliance must separately assess later compromise and its effective scope. Retaining a historical receipt does not establish that every later use remains authorized.

## Preparing, admitting, and replaying an action

The client first calls `POST /v1/cases/{id}/actions/prepare` with `expected_revision`, `action`, `issued_at`, and `expires_at`. The operation requires write permission and applicable case access. It checks the current revision and signing interval, then returns a typed payload and complete signing statement. Preparation performs no protocol admission and reserves no revision.

The returned payload contains `expected_revision`, `previous_state_sha256`, and `action`. The predecessor digest commits the complete preceding `ProtocolState`, including requests, signatures, recording metadata, and rule snapshots. This binding prevents an omitted earlier challenge or stay from disappearing between ordinary case mutations.

The caller reviews the normalized payload and compares every statement field with independently accepted configuration. It then obtains the required external signatures. The submitted `ProtocolAction` adds `authority` to those exact payload fields. The server rejects unknown fields and evaluates the operation under the purpose derived from its action type.

An action encodes its name in `type` and its typed fields in `data`. Its signing purpose is `recourse.protocol.<action_name>`. For example, `confirm_consent` and `issue_outcome` have distinct purposes even when they reference the same agreement or proceeding.

Admission obtains the SQLite writer with `BEGIN IMMEDIATE` before checking current access, replay identity, revision, and protocol validity. A successful transaction commits the protocol resource, case revision, event, and original response together. The resource preserves the exact request, verified signers, actor, recording time, and rules snapshot. Failure leaves the successful state transition and response absent.

The replay namespace combines tenant, actor DID, route, and `Idempotency-Key`. The key permits 1–128 visible ASCII characters. A repeated identity and normalized body returns the saved result. A changed body produces `idempotency_mismatch`. Current access checks precede replay, while replay lookup precedes fresh revision evaluation.

This ordering permits an authorized exact retry after subsequent case changes. It also denies a revoked delegate access to a saved response. The replayed revision describes the original action. A separate read obtains current state. Protocol action responses contain the affected resource, while execution mutations use a smaller receipt that exposes no proof or recovery totals.

## Consent, representation, and custody

Consent binds both parties, every claim, agreement bytes, complete filing digest, institution, seat, governing law, and configured rules. The filing digest includes claim descriptions, amounts, and native object references. A replacement consent names its predecessor and requires new jurisdiction and procedure findings. Both parties must authorize consent directly or through specifically scoped representation.

Consent also names institution, review, service, execution, and reconciliation principals. Institution and review principals must differ from both parties and from each other. An active party representative cannot become a neutral institution principal, review principal, or tribunal member. These restrictions prevent a directory role or broad account grant from supplying adjudicative independence.

A delegation identifies its grantor, delegate, principal kind, claims, powers, instrument, effective time, and expiry. The original grantor signs revocation. Whole-case reads require coverage of every claim. A narrower submission can use action-specific authority without receiving the entire case. Provider permission to submit a fee receipt likewise supplies no general case access.

Artifact custody is separate from an evidence reference. `UploadArtifact` contains `expected_revision`, `artifact`, and `content_base64`. An artifact reference preserves digest algorithm, digest value, and media type. Upload accepts canonical padded base64, checks the exact bytes under the declared SHA-256 or BLAKE3 algorithm, and enforces a 4 MiB limit.

`ArtifactRecord` retains its UUID, artifact reference, byte count, uploader, and upload time. Signed actions can reference only artifacts already in custody. A recorder can therefore upload appointment or disclosure material before the appointed human signs the corresponding action. Digest equality establishes byte identity under the selected algorithm. Procedural admissibility still depends on competent decisions and any challenges.

An outcome also commits selected evidence records in an explicit order. `evidence_records_sha256` covers their identifiers, submitters, times, revisions, kinds, descriptions, and artifact references. Replacing metadata under an unchanged evidence UUID invalidates that commitment. Empty evidence selection commits the canonical empty array rather than an unspecified value.

## Procedure and retained obligations

A signed service record describes claimed delivery of an exact filing, notice, or outcome. A competent institution or tribunal then records the finding that makes service effective. Jurisdiction requires effective filing service to both parties. Notice and outcome deadlines use the latest effective delivery under the configured rules. Later invalidation restricts dependent proceedings and outcomes.

Procedure adoption names a proposal, jurisdiction finding, served notice, timetable, reasons, and predecessor. The evaluator prevents adoption below the highest required tier across the claim assessments. Contested record integrity, a hearing request, or an election for full proceedings requires the full tribunal proposal. Open challenges and applicable proceedings stays prevent adoption.

Tribunal appointment names a human, covered claims, instrument, qualifications, effective time, and expiry. The member signs acceptance and a disclosure after appointment. Subsequent disclosures form a predecessor chain. Appointment alone permits its acceptance or disclosure action. General tribunal access requires the additional acceptance and case-authority checks.

The outcome contract retains three distinct kinds. A determination requires record resolution and the consent-named institution. An award requires a tribunal procedure and the configured quorum of accepted human members for the covered claims. A settlement requires distinct signatures from both parties or their authorized settlement representatives.

`Outcome` binds its UUID, kind, claim identifiers, procedure, document, reasons, selected evidence, obligations, superseded outcomes, and issue time. Each `Obligation` has its own UUID, claim, obligor DID, beneficiary DID, performance artifact, and optional exact decimal amount. A successor outcome must explicitly supersede overlapping current outcomes and cover their claims. A determination cannot replace an award or settlement through relabeling.

Challenges can address consent, jurisdiction, service, procedure, evidence, appointments, disclosures, outcomes, and stays. A review signer cannot review their own challenged decision or appointment. An unresolved challenge restricts the affected claims. An upheld challenge invalidates the targeted resource for subsequent reliance while preserving the record.

Stay orders distinguish proceedings, execution, and both scopes. Imposition, variation, and lifting preserve the predecessor's claims and authority type. A future successor cannot lift an effective predecessor early. A contested lift preserves the preceding restriction, and an upheld challenge can restore it. A completed destination effect retains its evidence despite a later order.

The local outcome-readiness predicate checks consent, jurisdiction, procedure, effective service, challenge time, supersession, evidence restrictions, and execution stays. Award readiness requires a human appointment and acceptance that preceded the award and covered every outcome claim. The appointment must have been effective and unexpired when the award was recorded, and its authority must remain uncontested. Later appointment expiry does not invalidate the earlier award. A new appointment cannot repair an upheld challenge to its original authority. Destination reliance still requires its own current admission checks.

Disposition records whether proceedings closed, completed, were dismissed, or were superseded. The completed disposition means that proceedings are complete. Its current admission requires an outcome; economic recovery is not a precondition. Every disposition's `preserved_obligation_ids` retains all recorded obligations, including those from superseded outcomes. Closing proceedings leaves unpaid obligations, execution history, and recovery records intact. Debt disappears only through an independently established discharge rule.

Disposition ends proceedings in that case. The evaluator rejects later consent confirmation, jurisdiction findings, procedure proposals, procedure adoptions, outcomes, and repeated disposition. Permitted administrative actions retain their authority requirements and preserve the `disposed` status. These include review, stays, service, representation, fees, and appointments for continuing administrative duties. A rejected jurisdiction finding permits competent dismissal, while other disposition kinds require accepted jurisdiction.

## Matching, fees, and client access

The professional directory stores profiles and private representation matters separately from cases. Profiles contain declared jurisdictions, languages, specialties, availability, and biography. The server labels qualifications `self_claimed_unverified`. Matching requires availability and every requested qualification tag. Results explain the matched criteria without assessing professional quality.

A client initially has exclusive matter access. A contact request identifies both the lawyer UUID and the reviewed profile revision. The transaction rechecks availability, eligibility, profile revision, and matter revision before recording selection. Only the client and selected lawyer can then read the disclosed matter. A second selection cannot silently replace the recipient.

Lawyer acceptance changes the matter from `contact_requested` to `accepted`. It records acceptance of the contact request. Engagement terms, conflicts review, case delegation, fee acceptance, and tribunal appointment retain their own authority. A matching result exposes no unrelated proceeding or evidence.

Fee schedules pin amounts, providers, beneficiaries, and deployment or protocol attribution. A quote selects schedule items, payer, document, and expiry. The payer accepts before the institution charges an item. A provider signs each receipt with a unique provider reference. Exact decimal addition prevents receipts from exceeding the accepted charge through floating-point rounding.

HTTP, TypeScript, and MCP clients share these authority checks. The SDK provides generated operation types and explicit action-signing helpers. It takes caller-selected keys or signing callbacks and sends no private key to the service. Its independently supplied expected binding must constrain the returned preparation statement.

| Entry point | Contract exposed to the caller |
|---|---|
| `GET /v1/node` | Configured deployment profile and authenticated tenant and actor. |
| `POST /v1/cases` | Filing with stable caller-supplied idempotency identity. |
| `POST /v1/cases/{id}/actions` | Signed lifecycle action and its recorded resource receipt. |
| `PUT /v1/directory/lawyers/me` | The authenticated professional's own versioned profile. |
| `POST /v1/directory/matters` | A private client matter for representation matching. |
| `GET /v1/destination-profiles` | Public profile fields for configured execution destinations, under read authentication. |
| `POST /v1/cases/{id}/execution-intents` | Exact authorized instruction and durable outbox admission. |

Execution detail, observation, cancellation, and recovery routes share the intent's case and UUID. The four mutation forms return only `case_id`, `intent_id`, `resource_id`, and `recorded_at`. Read operations separately expose current delivery evidence and cumulative recovery. The worker has no public dispatch route.

The SDK preserves request identities and performs no automatic mutation retry. MCP exposes generated operations through a configured actor credential and has no signer. Capabilities and runtime OpenAPI identify enabled modules. Client metadata cannot activate an absent network or execution module. Retained HTTP checks exercise the workspace proxy and actual local service. Browser interaction, keyboard navigation, and visual layout remain unverified.

An `AiWork` action records the authenticated actor, delegation, covered claims, purpose, model provider, model identifier and version, and tool versions. It also binds input artifacts, output, provenance, and production time. The actor must supply the sole signature. A nonparty actor needs active delegation with both submission and AI-work powers for every covered claim. This record establishes accountable preparation without appointing the software to a tribunal.

## Referral, disclosure, and independent recognition

Network configuration pins the local authority profile, peer identities, fixed endpoints, exact source rules, and receiving policy. Received payloads cannot replace those settings. Peer discovery authenticates a description from a configured institution. It grants no authority over another deployment.

An initial `ReferralPayload` contains specified metadata, both source party DIDs, and all source claim UUIDs, with an empty artifact list. Both parties sign `network.disclosure`. The source institution separately signs `network.referral`. The source compares the stated parties and claims with its stored case before admitting the bundle.

Artifact transfer uses a new referral UUID and an accepted metadata referral as its parent. Source case, parties, claims, and both institutional identities must match that parent. The new signatures cover exact artifact identifiers, digests, media types, and bytes. The receiver independently verifies those bytes and applies its disclosure limits.

A receiving policy refusal records rejection and retains the received signed bundle. Consequently, policy rejection can still leave disclosed bytes in receiving storage. The sender must obtain disclosure authority before transmission. A receiver's willingness to accept material cannot substitute for that authority.

Before network transmission, the source commits an `unknown_delivery` observation. A matching HTTP receipt establishes `delivered_unconfirmed`. Only the receiving institution's verified decision establishes acceptance or rejection and binds its independent receiving UUID. An exact referral retry compares the complete signed bundle and preserves that receiving identity.

Withdrawal first becomes durable at the source. The receiver can authenticate and retain a withdrawal tombstone before the original referral arrives. Referral insertion checks the tombstone within the same writer transaction. A later admissible matching referral remains withdrawn and uses the tombstone's receiving UUID. Withdrawal cannot retrieve disclosed bytes or automatically cancel an independently opened case.

Opening a receiving case requires an accepted metadata referral, both source parties' signatures, and the local institution's signature. `CaseOpeningPayload` binds the source case, referral, receiving identity, bundle digest, both institutional identities, and complete new filing. One transaction records the new local case, filing event, immutable origin link, and replay response.

The receiving case has a new UUID and local origin. It begins with empty evidence, artifact custody, and protocol history. The source case UUID and referral receiving UUID remain separate. Local custody, consent, service, jurisdiction, and appointment must establish the new proceeding under local rules.

Recognition has a different object. `PortableOutcome` carries the complete source case, every artifact record and exact bytes, selected outcome, selected claims, destination, accepted referral, and expiry. Both source parties authorize the complete disclosure. The source institution authenticates the portable payload.

The receiver verifies byte custody and replays the protocol history against independently pinned source profiles and rules. Replay checks signatures, signer derivation, revisions, predecessor commitments, metadata, and the filing commitment. The implementation requires an exact trusted rules snapshot for the case history. Unconfigured profile or rule versions fail verification.

The receiving institution signs a `RecognitionPayload` binding the complete portable digest, receiving UUID, current policy version, and reasons. Insertion rechecks accepted referral state. Recognition concerns that disclosed snapshot. It proves no completeness of subsequent source events and creates no payment authority. Later execution requires fresh evidence for current restrictions and destination admission.

## Exact execution and the dispatch barrier

`CreateExecutionIntent` contains an `IntentPayload` and three authority envelopes. The consent-named executor signs `execution.intent`. The actual obligor signs `execution.voluntary_authority`. The actual beneficiary signs `execution.beneficiary_authority`. Every signature covers the complete payload, including account mapping and instruction bytes.

The payload binds its UUID, expected revision, outcome, obligation, exact claim, destination profile and version, native target, policy, account reference, and mandate. It also carries asset identifier, raw amount, instruction bytes, declared instruction digest, and expiry. Policy, mandate, and account artifacts must already be in case custody.

The destination fixes currency and decimal scale. Conversion from the outcome amount to raw units must be exact. Rounding, overflow, changed account mapping, and mismatched amounts fail admission. The record preserves both the declared digest algorithm and a separate SHA-256 commitment to the complete HTTP instruction bytes.

Intent admission atomically commits the intent, bytes, outbox entry, case revision, event, and replay response. Another active intent cannot reserve the same obligation. The destination configuration digest binds endpoint, profile, trust configuration, and credential reference. A changed configuration blocks the old instruction until its exact requirements are resolved.

The worker reserves an eligible unsent intent and commits an immutable attempt with a bounded lease. A second writer transaction forms the final dispatch barrier. It rechecks case authority, restrictions, destination identity, and remaining lease. The transaction stays open until response headers arrive or the bounded HTTP operation fails. A stay committed before this barrier prevents transmission.

The worker checks current case submission authority using the recorded creator's actor identity. It does not re-evaluate the original bearer grant's validity as a separate dispatch credential. Operator acceptance must therefore distinguish grant revocation from the current case authority that this worker actually checks.

A reserved attempt interrupted by a process failure becomes uncertain when its lease expires. Timeout, interrupted response, oversized response, and unsuccessful HTTP status also preserve uncertainty. The worker does not automatically repeat an attempted economic instruction. Cancellation requires executor and obligor signatures and is limited to an unsent intent or a durably prevented attempt.

`custodian_transfer` accepts exact bytes under `recourse.custodian-transfer.v0`. The instruction binds request, case, outcome, obligation, provider, obligor, beneficiary, account, asset, raw amount, policy, mandate, destination, and expiry. The custodian must separately accept its account mandate and requested effect.

`moxie_voluntary_transfer` accepts one exact `moxie_submitSigned` JSON-RPC request. Its request identifier equals the intent UUID. The native payload preserves transaction bytes, signature, signer, numeric chain identifier, and cryptographic epoch. The account artifact retains `from`, `to`, and decimal-string `nonce`. A configured native verifier checks the signed Transfer before enqueueing.

The configured effect kinds also name `kernel_award_enforcement` and `moxie_award`, but intent validation rejects those unsupported native award effects. A voluntary transfer supplies no general award carrier. Destination acceptance of Recourse authority, exact obligation, action scope, result identity, and portable proof remains an integration requirement.

The proposed Mass contract for [recognition and native effects](#recognition-native-effects) addresses that destination boundary. It must bind current action authority and the resulting native proof to the exact accepted Recourse obligation. Its adoption remains separate from the source capabilities described here.

## Effect evidence, recovery, and restart

Execution observations retain original evidence bytes and their digest. A failed proof can remain visible with `verified_effect: null` and `verification_error`. Successful verification produces `EffectEvidence`, which binds intent, outcome, obligation, exact instruction, native target, effect ID, asset, amount, beneficiary, account, and delivery status.

A custodian receipt uses an independently pinned evidence principal distinct from the parties and named executors. The principal signs the exact effect under `execution.custodian_receipt`. This record authenticates a provider statement. Its economic meaning remains bounded by the provider evidence profile and the accepted custody arrangement.

Native evidence contains an independently signed block expectation, native receipt, native events, and finality proof. The expectation fixes transaction hash, chain, epoch, block number, block hash, state root, and receipts root. The service supplies a fixed trust configuration and its expected SHA-256 to the verifier. Both processes check the digest, and the verifier parses the exact bytes that passed its check. The service rejects verifier responses whose SDK revision differs from its complete pinned native contract revision. The service closes the input pipe after writing the complete request. It compares returned native identities, effect, domain, and block coordinates with the persisted instruction and independent expectation.

These comparisons rely on the configured verifier implementation. The destination configuration digest does not itself authenticate executable bytes. Native acceptance evidence must therefore bind the actual verifier binary and its trust provenance to the exercised instruction and proof.

The delivery status `transport_accepted` records successful HTTP transport. Verified positive delivery establishes `finalized`, while a verified negative receipt preserves `uncertain`. A later transport response cannot overwrite that independent evidence. Recovery requires independently proved delivery and the authorized reconciliation record. Current recovery completion additionally requires zero outstanding amount and a `finalized` outbox state.

`RecordRecovery` binds expected revision, observation UUID, exact amount, and reconciliation artifact. A consent-named reconciler signs the payload under the intent-specific recovery purpose. Each recovery consumes one verified effect once. Raw-unit arithmetic preserves cumulative recovery and the outstanding balance without SQL numeric conversion or binary floating point.

Economic deduplication uses system, native target, and source effect identity. Destination aliases and profile versions cannot create a second allowance. Conflicting authenticated effects remain visible and mark affected intents `contradicted`. Verified effect evidence for a cancelled instruction also contradicts every intent for that case obligation. This blocks queued or reserved replacements and invalidates their current recovery completion. Earlier recovery receipts retain their authentic historical fields.

For an illustrative obligation of USD 120,000, a proved USD 70,000 delivery supports that partial recovery and leaves USD 50,000 outstanding. A stay can block further dispatch while retaining the credited amount. Fees, offsets, currency conversion, or another discharge basis need explicit terms and their own evidence. Administrative closure preserves this remaining debt.

The initial operating arrangement uses separate storage and configuration for each deployment. Execution defaults to `reconcile_only` when configured. Restoring a database requires preserved identity, authority profiles, rules, and external configuration, followed by reconciliation of effects after the backup. A restored queued record can describe an instruction that the original process later delivered.

When the snapshot retains the exact intent but lacks its later attempt, independently verified positive delivery can establish the effect and stop dispatch. The service preserves the proof without inventing an attempt or transport record. Invalid proofs, transport assertions, and negative receipts cannot use this exception. Recovery still requires the authorized reconciler's signature. An intent absent from the snapshot requires a separately authorized recovery path. Safe replacement after uncertainty also requires durable closure of the original instruction and prevention of delayed execution.

Live-state succession requires more than this backup procedure. Checked continuations, complete duties and occurrences, command exposure, portion and cash reservations, and unacknowledged deliveries need authenticated custody and effective predecessor fencing. Returned cross-store credit remains encumbered until the authoritative original ledger commits reopening and required current admissions pass. These requirements preserve the distinction between a local recovery record and accepted transfer of an institution's unfinished work.

## The retained local verification boundary

Initial retained local checks record 94 service-suite passes and one separately executed transport-crash test. Successor verification records 95 service-suite passes, including the crash test, and repeats the explicit native process and bounded verifier regression checks. They also record 11 native-verifier tests, one explicit API-to-verifier process test, 16 client tests, and one actual-service client journey. Workspace evidence records 36 tests and seven HTTP journeys. These are results from identified retained runs, inspected for this edition; this manuscript review did not rerun them.

The native process test uses synthetic finality and the actual service and verifier executables. It rejects a wrong block, corrupted quorum signature, and changed observer statement. It sends no instruction to a native destination and establishes no economic recovery. An earlier retained run exposed an input-pipe timeout; the explicit pipe closure and subsequent passing process and regression checks identify the repaired boundary.

The transport-crash test terminates the actual service after a local destination receives the complete instruction and before any HTTP response. Restart retains dispatch permission, the uncertain attempt, and the original instruction bytes while producing no duplicate send. Only separate signed synthetic delivery and authorized reconciliation complete recovery. Another restart preserves the original replay responses and accounting.

These observations leave general native award effects, permanent closure of uncertain commands, absent-intent restoration, and institutional continuation transfer open. Hosted operation also requires a reachable configured service, actual institutional authority, key custody, and destination acceptance. A successful local HTTP workspace journey does not establish those operating conditions or browser usability.

# Recognition and native effects {#recognition-native-effects}

This chapter proposes the destination contract required to connect Recourse outcomes and transferred checked work to native Mass actions. It specifies acceptance conditions for implementation and compatibility review. The record names below are design names; they do not identify deployed endpoints or agreed wire versions. An institution must separately authorize the rules under which an outcome can affect its registers, assets, or obligations.

The separate target-declaration implementation retains a commit preimage inside its journal but does not export the complete independently verifiable effect receipt specified here. Its submission replay still requires current execution admission and reevaluates the program before journal lookup. Historical read authorization, destination-recognized award effects, detached execution grants, returned-credit recovery, and complete checked-continuation transfer remain implementation obligations.

## The present authority-change boundary

The examined Mass delegation interface accepts `DELETE /v1/entities/{entity_id}/agents/{delegation_id}` without a typed request body. Its public write policy requires the entity operator role, `entities:write`, entity scope, and applicable credential caveats. The route returns HTTP 200 with a `MassProof`. It provides no field for a Recourse outcome, selected obligation, recognition policy, or exact signed instruction.

The public route requires `Idempotency-Key`. `X-Client-Intent-Id` is optional correlation; an absent or malformed value is treated as absent. At the default compatibility floor, an absent `X-Mass-Write-Contract` is accepted. A supplied mismatch, or absence under an elevated floor, is rejected. These headers have different functions and cannot be combined into a claim of outcome authority.

The mutation constructs an authority-revoked transition, performs admission preflight, and updates the active entity-scoped delegation. The update records the revocation actor and time. An already inactive or absent target produces no affected row and fails. The authority update and audit/outbox append share a database transaction. Fan-out follows its commit.

The returned proof has a narrower evidentiary meaning than an independently verifiable effect receipt. Its claim digest commits to five private fields: commit identifier, transition identifier, commit time, state hash, and observation identifier. Fresh commit and observation identifiers are not exported with the claim preimage. The state hash commits to the input transition; it is not a post-write database state root. The ordinary response therefore does not supply enough information to reconstruct the exact claim digest. Its output facts and response fields are absent on this path and are excluded from the general signing body.

Plain revoke uses preflight without a universal verdict. Its proof retains the missing-verdict residual and belongs to the partial signed profile. The durable proof writer returns without insertion when the verdict reference is absent. Calling that writer does not establish a retained, fully admissible proof for this route. A trusted verifier can check the envelope signature while still lacking independent evidence of the exact native action.

HTTP response replay is another boundary. The cache binds method, path and query, request body, and derived caller identity. Exact cached retries return the stored response; changed bytes conflict. Response storage occurs after the mutation handler and outside its transaction. The ordinary success cache lasts 24 hours. A crash or failed cache write can leave the effect unknown to the caller. This mechanism cannot supply permanent semantic deduplication or economic reconciliation.

## The destination-accepted carrier

A portable outcome preserves the source outcome kind: determination, award, or settlement. Recognition must retain that kind. A destination may recognize an authentic determination without granting it the powers of an award. It may also recognize an award's provenance while refusing the requested native action under its current law, policy, or authority rules.

The proposed request separates five records:

| Record | Required bindings |
|---|---|
| `OutcomeCarrier` | Source institution and case; outcome kind and identifier; exact outcome, obligation and selected-claims digests; consent and mandate; instruction bytes; source signatures; expiry and disclosed history cut |
| `RecognitionDecision` | Destination institution and store; carrier digest; exact recognized claims; policy identifier and version; decision; reasons and residuals; authority for recognition |
| `TargetAction` | Owning store, entity, native target, action and exact parameters; expected target version; original obligation and performed portions; required current grant |
| `AdmissionRecord` | Exact request digest; recognition and action bindings; admission policy and evidence cut; current authority decision; consumed identities and aggregate reservations |
| `EffectReceipt` | Admission identity; actual native effect and result identifiers; exact performed portions; postconditions; unresolved portions; signed claim preimage and verification context |

Digests must name their canonicalization and domain. The carrier preserves the exact authenticated source bytes even when Mass also decodes them into owning-domain types. A display projection cannot replace those bytes. Unknown or ambiguous action parameters fail before consumption. The destination derives its trust context from pinned policy and authenticated local state; it does not accept caller-supplied keys as their own authority.

The target action defines what success means. Revoking a delegation changes authority. Paying a beneficiary moves a specified asset. Allocating a receipt attributes an existing physical occurrence. Recognizing a discharge changes a legal obligation under the applicable rule. These actions require distinct result types and evidence. None may inherit financial completion merely because it shares a transport envelope with another action.

Outcome signatures and execution assent remain distinct. For a voluntary execution profile that requires the consent-named executor, obligor, and beneficiary, each signs the same exact payload binding outcome, obligation, target, policy, mandate, instruction, and expiry. The destination independently authenticates each named role and its scope. Award signatures cannot substitute for these execution signatures. A compulsory enforcement profile requires its own legally competent action authority and acceptance rule; it cannot silently reuse voluntary assent. Every profile remains subject to current native Mass authority.

## Detached execution authority

The proposed execution grant binds the owning store, constituting act, original obligation, action class, principal, target scope, and authority source. It also binds its generation, effective interval, revocation state, limits, and policy version. Attenuation narrows those permissions while preserving the original lineage. Shared limits require one aggregate counter across delegated children; copying a limit into each child creates excess authority.

Activation evaluates the tuple `(owner_store, act, obligation, authority)` against current destination state. An institution's authority to recognize an outcome is insufficient to execute every action that outcome requests. Recognition, custody, continuation restoration, external dispatch, and discharge each require the relevant permission. Source authority authenticates the source act; destination authority controls its local consequence.

A revoked execution grant blocks new execution. Historical retrieval uses current read authorization over the retained record. It does not reuse the old execution grant as a read credential, and it does not erase the record when that grant is revoked. Sensitive case bytes remain subject to their access and disclosure rules.

The grant also declares its required validity boundaries. A `LogicalSample` predicate evaluates authority at a specified logical sample. A `DurableEffect` predicate requires validity at the actual durable effect event. A `ProviderAcceptance` predicate requires it at the provider's accepted event. A profile can require several predicates together; each remains an independent obligation at its named boundary. These are proposed semantic profiles, not selected wire discriminants. Their receipts must identify every claimed boundary and its authenticated time evidence, including clock uncertainty.

Database locks protect records against conflicting writers; they do not stop time. A grant valid at a logical sample can expire before the database commit finishes. The sovereign allocation model's logical execution point therefore does not discharge a stronger premise about the actual durable event. The implementation must establish the selected stage through its temporal and effect protocol. A pre-commit clock check alone cannot establish `DurableEffect` or `ProviderAcceptance` validity.

## One local commit

For a local native action, admission and execution must use one authoritative transactional state. The commit includes the accepted carrier and recognition, action-specific authority check, exact consumed-use identity, deduplication record, reservations, native effect, result, signed proof or receipt, and required outbox entries. The authority and target versions checked during admission must be the versions protected by that transaction.

The transaction's footprint includes every record that determines the action's amount, permission, and remaining capacity. It includes shared parent budgets and original obligation portions where applicable. A compare-and-swap on one command row is insufficient when another command can spend the same funding or receipt slice. The owning store must serialize the complete footprint or use a verified equivalent protocol.

Rejected admission consumes nothing: no transfer token, funding, obligation portion, continuation generation, or external dispatch permission. It may produce a separately classified security diagnostic. That diagnostic must not appear as an accepted effect or alter the economic state being protected.

The successful response returns the exact retained receipt. Its signed claim includes the action, input and outcome bindings, actual result identifiers, performed portions, subject, issuer, policy and authority references, and committed record versions. It exports the claim preimage, canonicalization profile, signature profile, and trust context needed for independent verification. A digest whose required preimage is unavailable cannot satisfy this contract.

Permanent semantic deduplication binds a stable accepted-intent identity to the complete immutable accepted request. Its digest includes the exact action, outcome, obligation, selected claims, mandate, recognition decision, and required signed carriers. Reuse with any changed binding conflicts, even when the payment parameters are identical. Exact resubmission returns the original immutable receipt without rerunning the action. Receipt lookup by identity is a separate read operation. It requires current read permission but does not retroactively require the original execution grant or original request signature to remain live. A caller whose read access has been removed receives the applicable authorization failure; the historical receipt still exists.

An external provider cannot join this local database commit merely through an API call. Mass first commits the authorized intent and reservation with its outbox. Dispatch, provider acceptance, native effect evidence, reconciliation, and discharge remain distinct subsequent records. An unknown provider outcome retains its reservation and unresolved debt until independent evidence determines what occurred. Transport timeout alone cannot authorize another payment.

Replacing an uncertain original command requires a stronger closure record. It binds an authoritative complete source cut, zero remaining exposure under that command, a fence against delayed or replayed original execution, and exactly one successor binding. The relevant effect owners must enforce that fence. A signed `delivered=false` statement can report absence at its observation cut; it cannot prove that the original command will never execute later. Such a statement cannot release its reservation or authorize replacement by itself. Reopening and returned credit remain encumbered until the original ledger and every required current admission commit.

## Checked continuation and custody transfer

A checked continuation represents the complete suspended work, including what it already did and what remains owed. The proposed carrier binds program and checking-profile identities; host contract; instance identity; nonce and step ordinal; current work and control state; environment and frames; returned value indices; history and effect commitments; pending request; and the complete economic cut. That cut includes duties, occurrences, command reservations, exposures, performed portions, cash reservations, and unacknowledged deliveries.

Restoration must decode and validate the continuation directly. Reexecuting the original source program to reconstruct a superficially similar point can repeat effects or lose returned values. A decoder roundtrip establishes a representation property. Authenticated custody separately establishes that these are the authorized bytes for this transfer. Both conditions are required.

A constructor for resolved obligation portions preserves a narrower object. It can establish continuity of those constituted duties and allocations under its stated authority. It does not by itself migrate an arbitrary unresolved computation, its environments, pending effects, or future evidence requests. The complete checked-continuation carrier remains necessary for that broader transfer.

The predecessor must fence the transferred execution generation before its successor can execute. Preparation retains all deltas between the initial proposed cut and the exact admitted cut. The destination admission binds that current cut, the predecessor fence, one successor generation, durable custody, and action-specific authority. Local consumption, restoration, and receipt must commit together. Transfer and exact replay create neither dispatch nor discharge.

Independent stores need an explicit prepared-decision and recovery protocol. The source cannot release reservations because a destination acknowledgement is late. The destination cannot infer an unrecorded source fence from the same delay. An unresolved decision preserves custody and encumbrance until the protocol establishes the unique permitted executor for each transferred competence. Legitimate splits require disjoint assigned scopes and complete accounting of their shared dependencies.

Local database constraints cannot alone fence a cloned store, prevent an operator rollback, or establish that a remote history cut is current. Deployment must supply the separate anti-rollback, generation-fencing, and source-freshness evidence required by the chosen protocol. The book does not select a consensus provider, external witness, or transfer coordinator by naming these obligations.

## Returned credit and current debt

Command disposition describes an attempt: accepted, rejected, cancelled, or resolved under the relevant command protocol. It does not determine the remaining obligation. The original ledger retains payable, reserved, performed, returned, disputed, and discharged portions with their causal identities. Cancelling or closing a command leaves unpaid debt intact.

A returned payment is a new physical occurrence with a relation to the original payment. It does not erase that payment or recreate its already consumed receipt slices. The applicable obligation rule determines what must reopen. Cross-store credit remains `ReopenPending` and encumbered until the authoritative original ledger commits reopening and the required current admissions are verified. This prevents the receiving store from making credit available while the original store still records the debt as discharged.

For example, a 100-unit obligation may have authentic evidence of a completed 100-unit payment. A later return of 20 preserves that historical receipt. Pending reconciliation, the returned 20 is held. Once the original ledger admits the reopening, current outstanding debt becomes 20 under the applicable rule. A replacement payment consumes the current unpaid portion and current funding. Neither replaying the old receipt nor repeating the return report supplies another 20.

Previously released funds remain released. A later return cannot recover them by subtracting history from current balances. Funding equations must retain releases, repayments, fees, reservations, and any deficit. Recovery may create a fresh funding need even when the historical workflow once reached completion.

## Historical authenticity and current reliance

The receipt retains its original bytes, signature, issuer, key identifier, policy, and evidence cut. Verification of historical authenticity asks whether those bytes satisfied the applicable issuance conditions. Current reliance additionally asks whether a later compromise, reversal, stay, supersession, or authority change affects the proposed present use.

These decisions must be recorded separately. A retroactive compromise finding can prevent current reliance without rewriting authentic historical receipt bytes. Conversely, a valid old signature cannot establish current permission to execute again. The examined Mass proof retrieval route uses the current zone verification key; a general historical key resolver and separate current-reliance assessment remain requirements of this proposed seam.

## Acceptance witnesses and unresolved selections

| Witness | Required observable result |
|---|---|
| Valid source award, unauthorized local target action | Recognition can be recorded under its policy; native execution rejects without consumption |
| Crash after native commit before HTTP response | Exact retry retrieves the retained receipt and preserves one effect |
| Same intent identity with changed beneficiary or amount | Conflict; original receipt and effect remain intact |
| Same intent and action with changed outcome or obligation | Conflict against the complete accepted-request digest |
| Two commands sharing one budget or receipt slice | Aggregate serialization prevents excess use across both commands |
| Revoked execution grant and permitted historical reader | New execution rejects; retained receipt remains retrievable |
| Expired original envelope on receipt lookup | Authorized lookup returns historical bytes without new execution |
| Unknown external payment followed by retry | Reservation remains; reconciliation precedes any replacement dispatch |
| Signed absence observation while original delivery can still arrive | No replacement or release without complete-cut closure and an effective original-command fence |
| Grant expires between logical sample and durable commit | No claim of durable-event validity from the earlier sample alone |
| Returned 20 against a completed 100 across stores | Encumbrance remains until original-ledger reopening; duplicate return creates no credit |
| Invalid or stale continuation admission | No generation, cash, duty, or transfer token is consumed |
| Restored continuation and exact transfer replay | One restored generation; no replayed dispatch or discharge |
| Later compromise of a historical signing key | Original bytes remain; current-reliance decision records the separate finding |

These witnesses must run through the claimed API, authoritative persistence boundary, and effect provider where applicable. Shape checks, in-memory substitutes, and declared transaction helpers are insufficient evidence. The exact selected wire schema, state-version mechanism, historical key resolution, remote fencing protocol, and provider proof profile remain owner decisions. The proposed contract supplies their required semantics without representing those choices as deployed capabilities.

# Client contracts and interface discovery {#client-contracts}

A Mass integration must preserve the distinction between submitting work, observing its progress, and verifying its result. An HTTP success establishes only the meaning assigned to that response by its contract. It does not establish that a filing reached a registry, a recipient signed, or a payment settled. Clients must carry those distinctions into application state and user messages.

The interface has three related surfaces. The Mass facade exposes programs, authority, verdicts, proofs, observations, and corridor messages. Resource routes expose particular business records and operation controls. The Model Context Protocol (MCP) exposes selected actions to agent clients. Each surface remains subject to the same authorization and mutation boundaries.

The descriptions below identify contracts present in the examined implementation. They do not certify a particular deployment. A deployment claim requires its running contract, authenticated execution, and the durable effects required by the selected journey.

## The Mass facade

The TypeScript package `@mass/primitives` exports `Mass` as its principal facade. The facade uses five central wire objects: `MassProgram`, `MassBiscuit`, `UniversalVerdict`, `MassProof`, and `CorridorMessage`. Their semantics belong to the execution and authority contracts elsewhere in this specification. The table describes the intended method contracts; the implementation qualifications below identify current transport incompatibilities.

| Method | Contract | Client obligation |
|---|---|---|
| `compile(source, biscuit?)` | Accept a supported source and obtain a `MassProgram` | Inspect unsupported-source residuals and retain authored input |
| `mintBiscuit(authority, scope)` | Request a capability with specified authority and scope | Supply the actual subject, caveats, and lifetime |
| `attenuate(biscuit, caveats)` | Narrow an existing capability locally | Current SDK helper cannot attenuate server-minted tokens; see below |
| `propose(biscuit, program)` | Submit a program and obtain a typed proof response | Inspect the proof, verdict reference, and unfinished obligations |
| `proofFor(verdictId)` | Resolve a proof associated with a verdict | Distinguish absence from transport or authorization failure |
| `verify(proof, profile?)` | Verify a proof under a selected profile | Evaluate the returned verdict and the proof's admissibility fields |
| `send(biscuit, message)` | Submit a corridor message | Preserve the message identity and peer acknowledgement requirements |
| `observe(biscuit, query)` | Request an observation through the authorized surface | Preserve query scope and interpret residuals |
| `stream(id, options?)` | Consume an event stream for a verdict or operation identifier | Persist returned event identifiers and reconcile durable state |

`compile` accepts an already formed `MassProgram` without submitting it. For other supported source forms, it calls the compilation route. A successful local shape check cannot establish that the resulting program will execute successfully. The program can still require authority, current evidence, a supported adapter, or an external acknowledgement.

`propose` sends a `POST` request to `/v1/programs/submit` using Biscuit authorization. Its request includes an idempotency key, a client intent identifier, and the write-contract header. The request body uses the contract's `massProgram` envelope. Integrators must use the schema of the selected endpoint rather than apply a global field-renaming rule.

The facade validates the returned proof shape. It rejects a response without a structurally valid, nonnull verdict reference. It does not resolve that reference during this check. A typed proof still requires interpretation and, where required, separate resolution. The proof's `admissible`, `non_admissible_reasons`, and residual fields carry information that a client must not replace with its own success flag.

`proofFor` returns `null` for an HTTP 404. Other failures remain errors. This distinction matters when a client recovers after a lost response. An absent lookup result does not authorize the client to invent a proof or mark the original intent complete.

`send` currently accepts the `corridor.propose_receipt` message kind. Other message kinds fail with an explicit residual. `observe` similarly checks its supported query kinds. Clients must discover the accepted shapes instead of treating these methods as unrestricted dispatch interfaces.

`stream` uses the configured bearer token and the operation stream route. Its compatibility events preserve raw event data and residuals. A locally assigned sequence for a frame without a durable identifier must not become a reconnect cursor.

The intended `verify` result is a `UniversalVerdict`. The server verification request accepts a trust root and proof-admissibility profile; its explicit profile enforcement covers `admissible_full`. This is distinct from a stream's disclosure profile. A shape-only or partial artifact cannot satisfy an acceptance condition that requires full admissibility.

Three current wire gaps prevent treating these methods as verified integration paths. First, the local attenuation helper decodes base64-encoded JSON, while the mint endpoint emits CBOR. Its legacy appended block also contains an unsigned placeholder rather than the signed block required by native chain verification. Second, `verify` sends `massProof`, while the server requires `mass_proof`. Third, the facade's verdict guard requires `admissibilityClass`, while the server emits `admissibility_class`; the observation endpoint returns that verdict structure directly. These paths have no intervening field conversion that resolves the differences. Client and server contracts must be reconciled and executed together before these methods support an interoperability claim.

## Resource clients and compatibility

The package also exports `UnsafeMassRawClient` and explicitly named `Unsafe*` resource clients. These expose existing routes for entities, ownership, fiscal work, identity, operations, governance, and other surfaces. Their names identify a compatibility boundary. They do not confer permission to bypass authorization or finalization.

A resource method may provide the appropriate interface for a mounted read or a specific lifecycle action. Its presence in the package does not establish that every related route exists. Integrators must verify the method's route against the running OpenAPI document. They must also inspect its response contract before treating the method as a proof-producing primitive.

The older `MassClient` class provides a narrower resource composition. It is not interchangeable with every example that uses a variable named `mass`. An integration must identify the imported class explicitly. This prevents examples from combining methods belonging to different client classes.

Go and Python client surfaces also exist. Their generated types and wrappers require separate compatibility checks. A TypeScript method does not establish equivalent coverage in either language. Package compilation establishes type consistency for that package, while a source-bound API call establishes behavior for a particular method.

## The route inventory

The running `/openapi.json` export is the canonical API contract for the selected deployment. Its operation identifiers, methods, paths, schemas, and security requirements form the basis of a client inventory. A source export supports preparation and contract comparison. It does not prove which binary serves a remote address.

Maintain route inventories as generated artifacts. Each entry should contain the HTTP method, path, operation identifier, security declaration, request schema, and response schemas. Record the export digest and the identity of the process that produced it. Preserve the complete document alongside any compact table.

A count of path objects differs from a count of HTTP operations. A path can carry several methods. Tags describe grouping and can overlap. Therefore, a route inventory must define its counting rule before publishing totals. This specification gives no fixed route total that can drift independently of its source.

The following table identifies representative source-mounted routes. It is a navigation aid, not the complete deployment inventory. Braces denote path parameters in the public contract.

| Method and path | Use | Required interpretation |
|---|---|---|
| `GET /openapi.json` | Retrieve the API description | Bind the export to the serving deployment |
| `POST /v1/programs/compile` | Compile a supported source | Compilation does not acknowledge external effects |
| `POST /v1/programs/submit` | Submit a program | Inspect the returned proof and verdict reference |
| `GET /v1/proofs/mass/{verdict_ref}` | Resolve a verdict's proof | Absence and access failure differ |
| `POST /v1/proofs/mass/verify` | Verify a Mass proof | Apply the requested verification profile |
| `GET /v1/operations/types` | Discover operation types | Registration does not prove executability |
| `POST /v1/operations/plan` | Request an operation plan | A plan is not completion |
| `GET /v1/operations/{id}` | Read operation state | Inspect step state and pending actions |
| `POST /v1/operations/{id}/advance` | Advance an eligible step | Authority and current state still apply |
| `POST /v1/operations/{id}/events` | Deliver an operation event | Event admission does not replace provider verification |
| `POST /v1/operations/{id}/cancel` | Request cancellation | Inspect compensation and terminal state |
| `GET /v1/operations/{id}/stream` | Receive progress events | Reconnect from returned event identifiers |
| `GET /v1/operations/{id}/proof` | Retrieve operation evidence | Inspect the proof's scope and residuals |

Generated inventories must compare mounted routes with documented routes. A handler annotation can exist without a matching mounted path. Conversely, a mounted path can lack a complete schema. The comparison must also detect duplicate method/path pairs, dangling schema references, and undocumented authentication requirements.

## Contract evolution

Compatibility includes more than JSON shape. A change can alter required authority, accepted jurisdiction, idempotency scope, timeout behavior, or terminal-status meaning. These changes require review even when a schema generator reports no difference.

Clients should tolerate additional optional fields where their schema permits them. They must fail explicitly on missing required evidence. They should preserve unknown residual details for diagnosis rather than discard them during conversion. A new enum member requires deliberate handling when exhaustive behavior affects financial or legal outcomes.

The `/v1/` prefix identifies the current route namespace. It does not establish a universal deprecation window or guarantee that another namespace runs concurrently. Each breaking change requires a published compatibility decision and evidence for the affected client journeys.

# Developer integration, callbacks, and replay {#developer-integration}

## Preserve one authored intent

An authored intent is the user's requested business action. A transport attempt is one effort to deliver that action. Several transport attempts can belong to one intent. The application must preserve this relationship across retries, refreshes, and resumptions.

The generic TypeScript HTTP client generates an idempotency key before its retry loop for a mutation. It reuses that key for retries within the call. It also sends `X-Client-Intent-Id`. A new method invocation can generate a new key. Therefore, repeating a method call after a browser restart is not automatically the same replay.

The `Mass.propose` implementation has its own request path. It creates request identifiers and applies a timeout, but it does not inherit every generic transport retry behavior. Integrators must inspect the actual method they use. A package-level statement such as “the SDK retries writes” is too broad.

Before submission, preserve the authored parameters, subject identity, jurisdiction, and any explicit intent identifier. After submission, preserve the returned operation and verdict references. If a response is lost, resolve durable state using the supported lookup contract. Submit a replacement only after determining whether the original intent committed.

Do not reuse an idempotency key for different authored content. Do not change an entity identifier during a retry. A retry with changed authority also requires review. The server must reject conflicts instead of accepting whichever payload reaches it last.

## Authentication and transport failures

Use the credential class required by the route. Bearer authentication and Biscuit authentication have different meanings. A process environment that contains both credentials does not establish which authority should act. The MCP stdio entry point explicitly rejects ambiguous caller authority.

The client must distinguish authorization failures from transient transport failures. Retrying a denied request without changing its authority cannot repair the denial. Sanctions rejection is terminal for the rejected action. A network timeout has a different meaning because the server may have committed before the response disappeared.

The generic HTTP client handles rate-limit responses separately and recognizes numeric `Retry-After` delays. Its implementation uses bounded retries and backoff. Applications should preserve the server response and request identifier when retries stop. They must not translate every failure into “try again later.”

Error handling should retain the HTTP status, typed error code, residual marker, and next action when provided. A missing producer, absent adapter, malformed input, and unavailable network require different recovery. User interfaces can explain those differences without exposing credentials or internal diagnostics.

## Long-running work

Operation state includes steps that can become ready, execute, wait for outside action, fail, or enter compensation. A client should show the current actionable state. A fixed spinner cannot represent a signature required from another person or a filing awaiting an authority response.

The operation client provides waiting and ready-step helpers. Their results distinguish terminal state, a waiting step, a ready step, and timeout. They also expose pending actions and possible next actions. A waiting helper's timeout ends the client's wait. It does not cancel the underlying operation.

A client should retain signing and submission identifiers returned for the exact operation step. It must not borrow a signing link from another operation with the same entity. A recipient's identity, the intended document, and the signing session must remain joined throughout the workflow.

Ready-step advancement also requires bounds. An application must stop when further progress requires new authored input, changed authority, or external action. It must not infer a missing signature from a notification delivery or infer consent from a viewed page.

## Durable event streams

The operation stream uses Server-Sent Events (SSE). Its source reads persisted operation events and then follows committed events after the replay boundary. Database notifications wake the reader. Periodic reads provide a fallback when a notification is missed or the listener is unavailable.

The reconnect contract uses `Last-Event-ID`. Clients must echo the last event identifier received from the server. They must not synthesize identifiers from an operation identifier or a local counter. The current handler treats an absent or invalid nonnegative numeric cursor as a fresh subscription.

The replay reader pages through the durable interval. A per-query page bound does not mean that only one page of history exists. A detected gap produces an error. The implementation also supplies current persisted state for applicable records without historical outbox frames.

A robust consumer performs three actions. It applies each event idempotently to its local projection. It persists its cursor after successful application. It reconciles its projection with the operation read endpoint after reconnect or a suspected gap. A browser event is evidence of receipt by that browser, not an acknowledgement from an external provider.

Stream disclosure has an authorization boundary. Redacted output is the default, while full disclosure requires the corresponding authority. A client must not treat a disclosure query parameter as permission. Logs, screenshots, and analytics should receive only the fields needed for their task.

## Outbound webhooks

Webhook delivery has its own durable lifecycle. The sender maintains delivery attempts and outcomes for subscribers. A successfully queued event does not establish receipt by the subscriber. An HTTP acknowledgement from the subscriber does not establish completion of the subscriber's downstream work.

The webhook sender redacts its payload before signing. The signature therefore covers the bytes transmitted. The current signing format binds a timestamp, event identity, and payload digest. Supported signing modes include HMAC-SHA256 and Ed25519. Receivers must implement the selected subscription's actual signing contract.

A receiver should verify the signature over the raw received bytes. It should check the timestamp against its accepted replay interval. It must record the event identifier durably before acknowledging an action whose duplicate execution would be harmful. Parsed JSON reserialization can change bytes and invalidate a correct signature.

Separate transport deduplication from business deduplication. The same business outcome can arrive through different provider events. Conversely, one provider event can affect several internal records. Use the provider's stable event identity and the exact operation subject to determine the permitted effects.

Delivery retries are bounded. A permanently failed delivery requires an explicit operational response. Replaying that delivery must preserve its identity and audit trail. Recreating the business operation solely to resend a notification can duplicate the underlying action.

## Agent integration through MCP

MCP exposes discoverable tools with typed arguments. Tool discovery establishes the registered tool schema. It does not establish that a tool can execute against a selected zone, actor, and dependency configuration. Registration labels must remain separate from runtime acceptance results.

The stdio server takes an explicit API origin and caller authority. Its implementation supports Firebase authority or a Biscuit token, subject to its binding checks. Tool modules share a registration path across transports. Each transport still requires independent verification of authentication, request forwarding, and error propagation.

MCP clients must preserve residuals returned by tools. They must not convert an unsupported operation into an unqualified success message. A tool that returns a signing link has prepared a signing action. It has not supplied the signer's approval.

File upload and download tools require particular care. Local staging roots restrict accessible files, while API authorization restricts product records. Neither boundary replaces the other. A local file path is not a document authorization, and an authorized document identifier does not authorize arbitrary filesystem access.

For acceptance, record the actual tool invocation, request arguments after secret redaction, authenticated actor, API operation, and resulting durable state. The tool name alone cannot join those observations. Use the returned operation and causal identifiers to demonstrate that the tool caused the claimed action.

# Sovereign boot and dependency composition {#sovereign-boot}

## The deployment unit

Mass runs its API and native primitive services in a Rust process. PostgreSQL stores durable state. Identity, entities, governance, investment, and payment responsibilities belong to native services. External Java compute remains limited to treasury and templating. The eProspera integration is a separate provider boundary.

A deployment manifest must identify these dependencies explicitly. It must not revive retired service names from a generic infrastructure template. A network address for an obsolete primitive does not create a supported egress path. The runtime's closed egress registry determines which services can be reached.

The executable is only one part of the deployment. A functioning zone also needs its database schema, jurisdiction configuration, admitted content, trust material, object storage, and required provider connections. An image that starts in a container is not sufficient evidence for a sovereign service.

The operator should maintain a dependency graph with typed edges. Each edge identifies the caller, service, credential class, data class, timeout, and acknowledgement semantics. Separate mandatory boot dependencies from dependencies needed only by a particular journey. Also identify background processes that can act on the same database.

## Boot sequence and rejection points

The examined entry point verifies the release attestation before it initializes external dependencies. It then initializes PostgreSQL and aggregates the native services' schema migrations. It constructs the permitted egress registry and checks external compute connectivity. It loads zone state, composes document storage, and wires services before starting daemons.

A missing or invalid database connection prevents normal boot. There is no database-free runtime mode. A compiler or unit test can operate without a database because it exercises a different boundary. That fact must not be presented as evidence that the deployed service can do the same.

Both external compute URLs are mandatory configuration. Their absence or invalid format prevents boot. Reachability has different behavior: the entry point records unavailable services and can continue toward readiness evaluation. Operators must distinguish a configuration rejection from a service that becomes unreachable after configuration succeeds.

Zone bootstrap resolves an explicit zone configuration or a selected jurisdiction. It loads content and validates dispatch contracts against the API route set supplied by the composition root. Operation compilation normally enforces valid executable content. A warning mode exists for controlled migration work, but it does not satisfy normal release acceptance.

Document storage composition requires `S3_URI` and `S3_AWS_REGION`. The storage client must also obtain the appropriate credentials through the deployment's credential mechanism. Successful configuration parsing does not prove bucket access. Acceptance must perform an authorized document write and retrieval when that journey requires document storage.

Services must be fully wired before daemons receive shared state. Otherwise, request handlers and background advancement could use different service compositions. The entry point explicitly composes the router and wired state before it spawns background tasks. A deployment test must exercise both request and daemon paths when the required outcome spans them.

## Configuration reference

The following configuration names are present in the examined source. They are a focused reference, not an exhaustive secret inventory. Operators must obtain the complete configuration schema and release requirements for their distribution.

| Configuration | Purpose | Operator requirement |
|--------------------------------------------|-------------------------|-------------------------------|
| `DATABASE_URL` | Primary PostgreSQL connection | Supply a valid authorized database target |
| `DATABASE_READ_URL` | Read connection in an unused multi-pool helper | Current executable startup does not wire this setting |
| `DB_POOL_MAX`, `DB_POOL_MIN` | Main connection pool bounds | Budget connections across every process |
| `DB_ACQUIRE_TIMEOUT_SECS` | Pool acquisition wait | Align failure handling with request budgets |
| `PORT`, `MEZ_BIND_ADDR` | Listener port and address | Bind only the intended network interface |
| `MAX_TCP_CONNECTIONS` | Concurrent TCP admission bound | Size against memory, proxy behavior, and streams |
| `TCP_REQUEST_HEADER_TIMEOUT_SECS` | Request-header deadline | Match the trusted ingress and supported clients |
| `MEZ_JURISDICTION`, `ZONE_CONFIG` | Zone selection | Verify the resolved jurisdiction and content |
| `MASS_TREASURY_INFO_URL` | Treasury compute address | Supply an explicit valid endpoint |
| `MASS_TEMPLATING_URL` | Templating compute address | Supply an explicit valid endpoint |
| `S3_URI`, `S3_AWS_REGION` | Document storage destination | Verify region, bucket access, and residency |
| `MEZ_DEPLOY_ENV` | Deployment classification | Use the intended production classification |
| `MEZ_CRASH_DOMAIN` | Daemon selection group | Verify the actual process behavior and assigned work |
| `MEZ_LEADER_TTL_SECS` | Daemon lease duration | Validate handover under the selected failure model |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | Trace export destination | Control access and sensitive-data handling |

Secret material requires a separate custody record. Release verification also uses configured trust class, trusted signer fingerprint, minimum policy epoch, bundle location, and expected source identity. Some values deliberately sit outside the signed bundle. A bundle must not choose its own trust root.

Do not copy example credentials into a deployment. Do not infer a safe secret backend from an environment variable's existence. Verify which provider loads each key, how rotation works, and which service identity can read it. Record only secret identifiers and fingerprints in general support artifacts.

## Jurisdiction and content admission

A jurisdiction configuration selects the legal and operational content for that zone. It must identify actual authority, admitted packs, adapter declarations, and supported operation families. A jurisdiction label alone does not supply the governing law or a registry connection.

Content-addressed references make the selected bytes identifiable. Signatures establish statements by identified signers under a trust policy. Counsel and authority processes establish whether those bytes correctly express the applicable legal requirements. These are distinct acceptance questions.

Operation definitions require their actual parameters and declared effects. Executable registry admission must fail when required content cannot load. An empty executable catalog cannot be accepted merely because the process serves a health endpoint. The operator must exercise representative admitted operations after configuration changes.

External registry adapters need explicit capability records. Record supported actions, credential class, external environment, request and response identifiers, and the durable acknowledgement that ends the action. An adapter declaration without a live provider transaction supports configuration discovery only.

## Local verification and deployment profiles

A local verification environment must bind requests and background work to the same source and configuration. A second process connected to a shared database can hold a daemon lease and advance an operation. In that case, a response from the local API does not prove that its binary performed the subsequent work.

Use a dedicated test principal and purpose-built entities. Create feature state through authenticated product APIs. Separate intentionally isolated databases from shared development databases. Never use a production-connected process to manufacture test evidence.

The maintained local launcher prepares and verifies a local release attestation before starting the executable. A bare executable invocation can fail that gate. Operators using a supplied distribution should use its supported launcher and inspect its resolved configuration. Local attestation proves a different trust class from a production release.

Infrastructure definitions exist for container deployment, AWS environments, and Kubernetes packaging. Their existence establishes packaging options. Equivalent behavior across clouds requires an acceptance campaign on each selected topology. Neither a chart nor a successful infrastructure plan proves registry connectivity, legal admission, or recovery readiness.

# Operations, upgrades, and recovery {#operator-recovery}

## Establish the operating record

For each environment, retain the deployed artifact identity, configuration digest, schema state, content roots, key identifiers, and dependency endpoints. Record the responsible operator and the authority for changes. This record must be specific enough to reproduce an observation without storing plaintext credentials.

Health checks answer a narrow question about the process and its dependencies. They do not replace business acceptance. Monitor whether admitted operations reach their required terminal effects. A healthy listener can coexist with a failed webhook queue, an unavailable signing provider, or stalled operation advancement.

Alert rules should connect a signal to a response. Define the affected journey, the evidence to collect, the owner, and the threshold's basis. Useful signals include sustained operation age, repeated delivery failure, database acquisition delay, lost leadership renewal, and retrieval-integrity failure. Thresholds require measured workload behavior and a chosen service objective.

A queue-length alert alone can mislead. A brief large queue may drain normally, while one old legally significant filing may require immediate action. Track age and outcome class alongside volume. Preserve the exact operation and provider identifiers needed to investigate the affected work.

## Controlled upgrade

Before an upgrade, identify every compatibility boundary affected by the candidate. These include database migrations, operation definitions, proof verification, SDK schemas, authorization, and external adapters. Re-run the journeys whose contracts cross those boundaries. A successful image build is only one prerequisite.

Capture the current database recovery point and verify the candidate's migration behavior. Determine whether the previous executable can read the upgraded schema. A rollback plan that only replaces the image is incomplete when migrations have changed persistent state.

Long-running operations require explicit upgrade treatment. Preserve their recorded definition, authored parameters, authority bindings, and required evidence. Do not assume a content change rewrites an existing operation's legal basis. Determine which stored content and definition references the operation actually resolves after restart.

During replacement, remove draining instances from new traffic and allow bounded completion of admitted work. The implementation provides signal-triggered graceful drain and a readiness marker. The operator must align load-balancer deregistration, application drain, and container termination budgets. A premature hard termination can interrupt a response after a durable commit.

After replacement, verify the serving artifact and the current daemon holders. Read a previously completed operation, resume a permitted pending operation, and execute a new accepted journey. Check denials and idempotent replay. These checks test different compatibility obligations and cannot substitute for one another.

## Leadership and process controls

Daemon leadership uses PostgreSQL leases. Lease records carry holder and build information. Renewal and voluntary release support handover. These mechanisms identify the active worker, but they do not independently prove completion of a particular operation.

When advancement stalls, first inspect the relevant process and lease holder. Determine whether the holder is alive, renewing, and running the intended build. Inspect errors and durable operation state before changing infrastructure. A stale-looking ledger entry alone is insufficient to conclude that a worker has stopped.

Use supported process shutdown and orchestration controls for recovery. Allow normal lease expiry or voluntary release to transfer work. Direct deletion of lease rows can create overlapping workers and destroy useful evidence. It is not a routine recovery procedure.

The source exposes request, advancement, support, and combined daemon-selection modes. The selected mode controls which daemon classes start. Operators must verify the resulting listener and process behavior before claiming independent failure domains. A configuration enum alone does not establish network isolation, scheduling isolation, or a tested split deployment.

## Backup, restore, and retention

A recoverable Mass deployment needs more than a database dump. Preserve durable database state, required object bytes, content-addressed packs, release evidence, and the trust material needed to verify retained records. Key custody can use a separate recovery procedure, but its dependency must remain explicit.

Define the recovery point objective as the maximum accepted loss of committed data. Define the recovery time objective as the time allowed to restore the required service. Both are operator commitments that require measurement. This specification does not assign universal values to either objective.

A restore drill must use an isolated authorized target. Verify schema compatibility and integrity before allowing writes. Retrieve representative documents and verify their digests. Resolve an operation's proof and required historical content. Confirm that pending external work does not execute twice when the recovered service resumes.

Database recovery and provider recovery have different histories. A provider may have acknowledged an action after the restored database's recovery point. Reconciliation must discover that acknowledgement using stable external identifiers. Blindly replaying all pending requests can duplicate legally or financially effective actions.

Retention rules must distinguish event history, personal data, document objects, delivery records, telemetry, and backup copies. Each class needs an authority, purpose, access rule, and disposal condition. A general privacy statement does not establish that every copy has the same retention mechanism.

The event journal is append-only except under verified archival rules. Archival must preserve retrievability and the evidence necessary for verification. Deleting events to reduce storage cost can break replay, audit, and proof interpretation. Retention acceptance therefore includes retrieval after archival and verification after restoration.

## Incident handling

Begin with the affected user outcome. Identify the submitted intent, operation, current state, and missing acknowledgement. Determine whether the incident concerns authorization, execution, delivery, storage, or observation. This classification determines the next safe action.

Preserve source identity, configuration, causal identifiers, and relevant logs before restarting a service. Collect enough evidence to explain duplicate prevention and any irreversible effects. Redact secrets and unnecessary personal data. A support bundle should let another operator reconstruct the failure without receiving general access to the environment.

If the API is available but work remains pending, inspect the required external action and advancement owner. If callbacks fail, inspect signature verification and delivery identity. If streams disconnect, reconcile the durable operation before retrying business work. If proof verification fails, preserve the artifact and trust inputs instead of replacing them with newly generated evidence.

Recovery ends when the required effects and their acknowledgements are verified. Restoring a green dashboard is insufficient. Record any remaining partial outcome and its authorized recovery path. Keep the distinction between a repaired service and a completed customer operation visible.

# Capacity and scaling acceptance {#capacity-acceptance}

## Define the measured workload

Mass workloads differ substantially. Entity reads, compilation, document generation, signature waits, and settlement do not consume the same resources. Capacity must be measured against an explicit mixture of requests, operation durations, payload sizes, and dependency behavior.

Separate request acceptance rate from operation completion rate. A system can admit work faster than its external dependencies complete it. If the difference persists, queue age grows even while request latency remains low. A useful capacity report measures both rates and the resulting backlog.

Let $\lambda_a$ be the admitted operation rate and $\lambda_c$ the completed operation rate. Over an interval, backlog growth is approximately $(\lambda_a-\lambda_c)\Delta t$, subject to cancellation and rejection. This accounting identity does not predict either rate. A benchmark must observe them under the selected workload.

Long-lived streams also consume resources. They hold connections while ordinary requests continue. Load tests should include reconnects, slow consumers, authentication checks, and replay reads. A benchmark containing only short anonymous requests cannot establish capacity for authenticated agent fleets.

## Bound the actual resources

The executable enforces a TCP connection bound before normal HTTP processing. It also applies a request-header deadline. These controls protect resources at an earlier boundary than application operation limits. Their configured values are admission controls, not measured service capacity.

Database pools create another bound. Budget every pool actually initialized across all replicas. The examined startup initializes one primary pool; optional read and daemon accessors fall back to it because the multi-pool state is unset. Leave capacity for migrations, monitoring, and controlled recovery. Increasing replicas without revisiting that budget can exhaust the database before CPU becomes limiting.

If a future or separately configured deployment wires a read replica, it requires a consistency policy. Determine which reads tolerate replication lag and which follow a mutation immediately. Do not route an authorization or completion decision through stale data unless its contract explicitly permits that behavior. Setting `DATABASE_READ_URL` alone does not establish this topology in the examined executable.

The implementation includes scale configuration for concurrent operations, agent connections, backpressure, and entity-routing shards. Large default ceilings do not prove that the process can sustain those populations. A routing-shard count also does not establish distributed storage or cross-shard transaction behavior. Trace the actual callers and measure the deployed topology.

## Separate failure domains deliberately

Replica scaling and daemon scaling solve different problems. More request replicas can increase admission capacity while a single leased daemon still limits advancement. More support workers can improve delivery only if their ownership and queue semantics permit concurrent work.

A split topology needs explicit ownership of each daemon class. It also needs compatible artifact and content identities across processes. During a rolling change, determine whether old and new workers can safely share the persistent operation representation. Lease handover does not itself provide schema compatibility.

Dependency limits can dominate throughput. Templating, object storage, identity providers, notification services, and registry adapters each have their own capacity and failure model. Include their rate limits and acknowledgement delays in admission planning. A local simulator cannot establish the capacity of a live registry.

## Benchmark protocol

A defensible benchmark records the executable, configuration, hardware allocation, database size, content set, and provider mode. It states warm-up behavior, run duration, offered load, admitted load, and error distribution. It reports latency percentiles with the population they describe.

Use workloads that exercise the required financial and legal effects. Include repeated intents, denied requests, large valid payloads, callbacks, and restart recovery. Check persistent invariants after load. High throughput with duplicate effects is a failed benchmark.

Run overload tests separately from steady-state tests. Increase demand until admission limits activate, then verify recovery after demand falls. Confirm that rejected work does not leave ambiguous committed effects. Observe whether retries amplify load and whether queues return to the agreed age bound.

Publish capacity only for the tested configuration and workload. Extrapolation requires its own model and assumptions. Configuration switches, asymptotic arguments, and component timings may inform planning. They cannot establish an economy-wide throughput guarantee.

# Conformance and operator reference {#conformance-reference}

## Evidence classes

Conformance is a set of claims tied to evidence and acceptance rules. A percentage without a defined population can conceal missing journeys. A deployment must report which requirements passed, failed, were skipped, or were not exercised.

| Evidence class | What it can establish | What remains outside its scope |
|---|---|---|
| Schema validation | Payloads satisfy specified structural rules | Authority, external effects, and semantic correctness |
| Source inspection and static gates | Declared boundaries and detectable implementation properties | Behavior of an unobserved deployment |
| Unit and property tests | Selected component properties under test assumptions | Full authenticated journeys and real providers |
| API or MCP execution | Observed behavior for bound requests and actors | Unjoined future work or other configurations |
| Cryptographic verification | Artifact integrity and checked trust predicates | Truth of unsupported external assertions |
| Recovery and load campaigns | Tested failure and capacity behavior | Untested topologies or universal guarantees |

A conformance record should name the requirement, test population, source identity, environment, actor, result, and supporting artifacts. It should also identify exclusions and the first known failure. An average score must not hide a failed invariant such as duplicate payment or unauthorized mutation.

## Acceptance by complete journey

Freeze the required effects before testing. For a signing journey, these can include the intended document, authenticated signer, stored signature result, operation transition, and final retrievable artifact. A notification can be an additional required effect when the public contract promises it.

Bind every observation to the same intent and integrated deployment. Record operation, step, event, provider, document, and verdict identifiers where applicable. Do not combine a successful API request from one build with a callback from another and call the combined result a passed journey.

Test the relevant denial and recovery paths. These include insufficient authority, altered authored content, duplicate delivery, lost response, reconnect, cancellation, and restart. Select cases from the operation's actual contracts. A fixed generic checklist can omit the coupling that makes a particular workflow difficult.

A skipped test remains unexecuted. A stubbed provider supports a narrower integration claim. A registered MCP tool supports discovery. A generated proof-shaped document supports only the predicates actually verified. Reports must retain these distinctions in their headline result.

Formal results have explicit hypotheses and model boundaries. A mechanized theorem can establish a property of its formal model. Connecting that result to executable behavior requires a refinement argument or checked correspondence. A theorem count is not a count of deployed guarantees.

## Reproducible interface checks

For an authorized source distribution, the tooling includes OpenAPI export, SDK generation, SDK type checking, and SDK builds. These source-defined preparation commands require that distribution. They are not presented as tests executed for this specification.

```sh
make sdk-openapi
make sdk-generate
make sdk-typecheck
make sdk-build
```

The OpenAPI exporter uses the API composition root's generated contract. A deployed comparison additionally retrieves `/openapi.json` from the selected process. Compare operation sets and schemas, then run the authenticated client journeys affected by any difference.

SDK checks must include error paths and response interpretation. A regenerated type file can be consistent with an incorrect annotation. A compiling wrapper can call an unmounted route. Contract drift checks, route parity checks, and runtime examples answer different questions.

A source-generated module or dependency inventory should record its generation inputs. Group implementation components by responsibility: domain types, business services, persistence, transport, API composition, languages, storage, and verification. Count source artifacts only when the inventory needs those counts. File totals provide navigation, not assurance.

Dependency review must inspect the actual dependency graph and lock data. The composition root owns construction, primitive services own business behavior, and persistence facades own database access. External wire types remain confined to their adapter boundaries. A generated graph helps detect an illegal edge but cannot establish all semantic ownership rules.

## Command-line reference

The `mez` command provides validation, content handling, zone composition, and offline protocol utilities. The installed binary's help output defines its accepted options. The following command families exist in the examined parser.

| Family | Intended work | Evidence boundary |
|---|---|---|
| `validate`, `lock` | Validate content and produce or verify deterministic lock data | Content checks do not boot a zone |
| `artifact` | Store, resolve, and verify content-addressed artifacts | Integrity does not establish legal authority |
| `law`, `regpack` | Ingest and verify legal or regulatory content | Admission and counsel obligations remain explicit |
| `zone`, `init`, `deploy` | Compose zones and generate deployment material | Generated configuration is not deployed behavior |
| `corridor`, `audit` | Manage corridor artifacts and inspect receipt evidence | Offline verification does not prove live peer delivery |
| `asset` | Inspect asset lifecycle and state-chain operations | Effects depend on the selected command and target |
| `agent`, `arbitration` | Work with policy and dispute tooling | Local artifacts do not replace authorized product actions |
| `vc` | Generate keys and sign or verify credentials | Key custody and issuer authority require separate controls |
| `demo` | Run an offline corridor narrative | Demonstration output is not production execution evidence |

For a supplied content distribution, validate the complete selected content set before producing lock data. These source-defined commands illustrate that preparation sequence:

```sh
mez validate --all-modules --all-profiles --all-zones
mez lock zone.yaml --out zone.lock.json
mez lock zone.yaml --out zone.lock.json --check
```

Here `zone.yaml` denotes the operator-supplied zone configuration. It is an input placeholder, not a packaged example with assumed legal authority. Strict reproducibility also requires a pinned generation timestamp under the command's `--strict` and `--generated-at` options. Preserve the selected timestamp with the other generation inputs.

Use help before selecting a command whose flags differ across distributions. These source-defined discovery commands have no claim of fresh execution here:

```sh
mez --help
mez validate --help
mez lock --help
mez artifact --help
mez corridor --help
mez audit --help
```

Before a mutating command, identify whether it writes a local artifact, changes a service, or contacts an external authority. Verify its target and credentials. A command that generates infrastructure is distinct from applying that infrastructure. A signing command requires authority over the signing key and intended statement.

For offline verification, retain the input bytes, referenced content, trust roots, command options, and output. Verify that the command rejects an altered artifact. A zero exit status without the expected output and input binding is insufficient evidence.

## Release acceptance record

The release acceptance record must separate artifact verification from deployment acceptance. Artifact verification covers executable identity, dependency evidence, signatures, and required static or test results. Deployment acceptance covers configuration, live dependencies, authenticated journeys, and recovery behavior.

Supply-chain reports must use the current dependency lock data and advisory results. Record unresolved findings and their disposition. A previously clean audit cannot establish the status of changed dependencies. Automated checks do not remove the operator's obligation to assess reachable vulnerable behavior.

The final acceptance decision should identify every required journey and its terminal acknowledgement. It should name the exact unresolved obligations that prevent broader use. A narrow successful deployment can be described precisely without claiming that all jurisdictions, providers, or operation families are ready.

# Worked Authoring: A Rule and a Waiting Operation

A rule answers a question about supplied facts. An operation coordinates work whose answer may arrive later. Writing either artifact requires an account of its inputs and its acceptance conditions; connecting them requires an explicit adapter and evidence of execution. This chapter works through an admitted Lex rule, a current operation definition, and a mutation contract. They are separate specimens. The operation does not load the example Lex program, and checking that program does not authorize an entity mutation.

## A small rule with an observable boundary

The rule below is the director-count threshold fixture from the public Lex implementation. Its policy is deliberately small: counts below three fail; counts of three or more pass. The threshold is a test assumption, not a statement of any jurisdiction's law.

```lex
λ(ctx : IncorporationContext).
  match director_count ctx return ComplianceVerdict with
  | 0 => NonCompliant
  | 1 => NonCompliant
  | 2 => NonCompliant
  | _ => Compliant
```

The input is an `IncorporationContext` whose `director_count` observation has natural-number type. The program returns `ComplianceVerdict`. It does not discover directors, verify their appointments, resolve legal jurisdiction, or decide whether the count is an adequate legal test. Those are separate obligations of the fact producer and policy author. A missing observation cannot be justified by silently substituting zero: zero is a supplied fact with a defined result, not an encoding of uncertainty established by this example.

The wildcard makes the match cover the remaining natural numbers. It is not an exception escape hatch. After the explicit cases zero, one, and two, the remaining values fall into the compliant branch. Negative numbers are outside the declared input type. Whether a real policy should also test appointment validity, residency, independence, or board composition must be settled before this fixture is treated as a legal rule.

Save the program as `director-threshold.lex` in a checkout of the public Lex project. The following sequence builds the CLI, examines the parsed structure, and checks admission:

```sh
cargo build --locked -p lex-cli
./target/debug/lex parse director-threshold.lex --format json
./target/debug/lex check director-threshold.lex
```

The observed check succeeded and reported the source admissible. Parsing and admission are different observations: parsing establishes that the syntax can be represented; admission checks the elaborated program against the implementation's requirements. Neither result establishes that the supplied context describes a real company.

The implementation's existing threshold tests provide a second, narrower kind of evidence:

```sh
cargo test --locked -p lex-core --test nat_literal_thresholds directors_min_three_
```

The two selected tests passed. They cover admission and execution of this threshold fixture; the evaluation cases are:

| Supplied director count | Expected verdict |
| --- | --- |
| 0, 1, 2 | `NonCompliant` |
| 3, 7 | `Compliant` |

These finite cases falsify common boundary mistakes, including accepting two or rejecting three. They are not an exhaustive proof over every natural number. The test harness constructs the facts and runs the language implementation; it does not query an entity API or certify a persisted register of directors.

Elaboration is useful for inspection:

```sh
./target/debug/lex elaborate director-threshold.lex --output director-threshold.core.lex
```

That command succeeded in the checked build. Rechecking the emitted text, however, failed with a parse error, `expected ⇒, found _`. The emitted pretty representation must therefore be treated as diagnostic output for this specimen. Preserve the original admitted source; do not advertise the pretty output as an executable interchange format or a verified round trip.

A rejection is equally instructive. The public `examples/discretion-hole-frontier.lex` fixture contains an unresolved discretion hole. Running `lex check` on it returned a nonzero exit status with `admissibility violation: unfilled discretion hole`. That failure says the program has not discharged its admission obligation. It is not a compliant verdict, an operational deferral, or permission for a caller to fill the hole with an arbitrary identity.

## A definition that creates a signing wait

The current `fund.entity_lpa_presign` default definition coordinates officer presigning of an entity's Limited Partnership Agreement. Its authored entity identifier comes from the selected entity in the calling surface. The optional `source` value is audit context. Neither value grants officer authority: the executor derives the initiating caller's identity through its authenticated execution context.

The following is a contract-bearing projection of the current YAML. It omits descriptive prose and UI annotations while retaining parameters, dependencies, conditions, service and API declarations, compliance domains, failure policy, and wait configuration. This non-executable reading specimen preserves literal interface values. The `kernel` label denotes the native Mass runtime. The `templating-engine` label and submission path describe a compute-service interface, not a public service address. Execution requires an authorized registry, configured service resolution, and authenticated runtime context.

```yaml
operation: fund.entity_lpa_presign
jurisdiction: _default
version: 0.1.0
params:
  required:
  - name: entity_id
    type: string
    provided_by: url_path
    validation:
      max_length: 255
  optional:
  - name: source
    type: string
    default: operation
steps:
- id: entity_verification
  type: check.entity_status
  service: kernel
  api:
    method: GET
    path: /v1/entities/{params.entity_id}
  params:
    operationId: '{operation_id}'
    requestedBy: '{initiator_email}'
  compliance_domains:
  - corporate
  on_failure: cancel_operation
  query_params:
    required_status: ACTIVE
- id: sanctions_screening
  type: screening.sanctions
  service: kernel
  depends_on:
  - entity_verification
  api:
    method: POST
    path: /v1/internal/identity/screening/sanctions
  params:
    operationId: '{operation_id}'
    requestedBy: '{initiator_email}'
    verification_type: sanctions_screening
    subject_id: '{params.entity_id}'
    hard_block: true
  compliance_domains:
  - sanctions
  - aml
  on_failure: cancel_operation
- id: check_entity_lpa_signed
  type: check.entity_lpa_signed
  service: kernel
  depends_on:
  - sanctions_screening
  params:
    entity_id: '{params.entity_id}'
  compliance_domains:
  - corporate
  on_failure: cancel_operation
- id: entity_lpa_presign
  type: document.entity_lpa
  service: templating-engine
  depends_on:
  - sanctions_screening
  - check_entity_lpa_signed
  condition: steps.check_entity_lpa_signed.result.signed == false
  params:
    operationId: '{operation_id}'
    requestedBy: '{initiator_email}'
    entity_id: '{params.entity_id}'
    source: '{params.source}'
  api:
    method: POST
    path: /templating-engine/api/v1/submission/batch
  compliance_domains:
  - corporate
  - securities
  wait_for: document.signed
  timeout: 30d
  on_failure: cancel_operation
compensation:
  steps: []
```

Read the definition in dependency order. `entity_verification` requires an active entity. Sanctions screening follows it and declares a hard block. `check_entity_lpa_signed` then reads whether the entity already carries a signed agreement. The document step depends on both screening and that read, and runs only when the returned `signed` value is false.

The required `entity_id` is a string supplied by the URL path, with a maximum length of 255. A client should bind it to an entity the authenticated principal selected and may act for. The optional `source` defaults to `operation`; a UI may supply its calling-surface label. The placeholders `operation_id` and `initiator_email` are execution context, not extra user-editable authority fields. A caller cannot obtain officer powers by changing `requestedBy` in copied YAML.

The named compliance domains express the checks and subject matter attached to these steps. Their presence is not evidence that every jurisdiction-specific duty has been fulfilled. The `_default` jurisdiction identity also does not establish that the default procedure is legally sufficient in every jurisdiction. Jurisdiction selection, policy applicability, and the actual execution evidence remain distinct questions.

## Step kinds determine the execution path

A service label and an API annotation do not by themselves describe the final dispatch path. The executor has typed native handlers, including an early intercept for `document.entity_lpa`. Authors must inspect the selected step kind and its handler before reasoning about side effects or waits.

| Step kind in this example | Execution responsibility | Result needed by the following stage |
| -------------------------------- | ---------------------------------- | ---------------------------------- |
| `check.entity_status` | Resolve the entity and require the configured active status | Successful entity verification |
| `screening.sanctions` | Execute native sanctions screening with the hard-block policy | Screening succeeds without terminal sanctions rejection |
| `check.entity_lpa_signed` | Ask the investment service whether the entity LPA is signed | A result carrying `entity_id` and Boolean `signed` |
| `document.entity_lpa` | Invoke the native entity-LPA handler before generic API dispatch or passive parking | An existing or newly minted agreement outcome, or an explicit zero-effect skip |

The last row matters. The YAML retains `service: templating-engine` and a submission API annotation, but the typed handler runs first. It resolves the entity and initiating actor, performs sanctions preflight, obtains the required egress authority, and invokes the investment service's standalone presign method for this path. Templating is a document-production boundary; the label does not transfer investment business ownership to a generic HTTP dispatcher.

The native outcome vocabulary includes `existing`, `minted`, `skipped_non_lp`, and `skipped_lpa_not_required`, with optional agreement and submission identifiers. The handler returns the outcome beneath `entity_lpa`. It forces terminal completion for the two zero-effect skip outcomes so they do not wait for a document that will never be produced. There is a source-description discrepancy: the current YAML prose says non-LP organizations are refused with a typed error, whereas the native handler accepts the explicit `skipped_non_lp` outcome. The execution account here follows the handler and preserves that discrepancy as a documentation defect, rather than converting the prose into a runtime guarantee.

## Waiting is not completion

A signing session is an intermediate product. For an applicable unsatisfied agreement, the operation must dispatch the work and then wait for `document.signed`, subject to the configured thirty-day timeout and cancellation policy. Merely parking the step without creating or recovering a session would leave no causal path to completion. The early document-handler intercept exists to prevent that shape of stall.

The event name alone is insufficient evidence. The event validator checks the operation's selected step actually awaits `document.signed`. It checks submission correlation: an external identifier, when present, must equal the payload submission identifier; templating coordinates must agree with the payload. It resolves the document key against persisted templating ownership rather than trusting a caller's assertion that a document was signed.

For ordinary submission authority, the key must belong to an active terminal-signed submission, and the submission must have all signing parties terminal and a document key. Archived or declined submissions are rejected. Recipient-specific partial release is separately restricted to `invest.process_lpa`; it is not a general escape from the full-signature requirement for this example. Public callbacks cannot assert the runtime-only self-emission coordinates.

An author should therefore distinguish four observations: the step produced or reused a signing session; the operation persisted a wait for that step; a correlated event passed document-authority validation; and the operation durably advanced. A provider response showing a submission identifier establishes only the first of these. A transport acknowledgement does not establish the last. The available verification for this chapter did not execute the authenticated signing journey, deliver a callback, or inspect durable operation advancement.

Failure handling belongs in the definition and in the interpretation of results. An inactive entity prevents the later signing work. Sanctions rejection is terminal. Failure of the signed-agreement read cancels the operation under this definition. Malformed, uncorrelated, or unowned document evidence cannot legitimately release the wait. A timeout is not evidence of a signature. The empty compensation list declares no compensating steps; it supplies no promise that cancelling an operation can undo an externally signed agreement.

## A mutation contract is another boundary

For a concrete comparison, consider the current public entity-creation route, `POST /v1/entities`. Its handler authorizes the caller, requires a concrete jurisdiction classification, passes the authored organization request and authenticated user identity to the entity service, and subsequently constructs the response proof envelope. The effective `entity.created` mutation contract has this shape:

| Field | Effective value |
| --- | --- |
| Event and contract identity | `entity.created` |
| Minimum role | `EntityOperator` |
| Contract entity-scope rule | `None` |
| Entity metadata keys | `entity_id` |
| Durability | `PersistOrFailClosed` |
| Transition rule | `NotApplicable` |
| Resource and action | `entity`, exactly `create` |
| Irreversibility | `Irreversible` |
| Signed-verdict flag | `false` |

These are the values selected by the current lookup path, including its earlier public-entity branch. A later matching literal in a large registry is not sufficient evidence if an earlier branch already returns. The `None` scope rule in this contract does not mean unauthenticated creation: caller authorization is visible at the route, and the service separately requires the authenticated user identity and a configured firewall. Likewise, a false signed-verdict flag does not waive the route's proof-response obligations.

The entity service obtains that contract and uses the firewall's transaction callback to perform the organization write and produce its owned mutation audit event. The event binds the actual generated entity resource identifier, action, and metadata containing the entity identifier, user identifier, and authored legal name. This is the producer of the mutation's local audit evidence. The route then passes the returned aggregate to a separate proof-envelope operation. The visible sequence does not establish that the aggregate write, proof response, document provider, event delivery, and every projection share one transaction.

This gives the author a concrete tracing discipline: route authorization identifies the caller and requested action; the effective contract defines the mutation's role, identity, and durability obligations; the owning service produces the audit event from the actual write; the response-envelope producer has its own obligation to bind the resulting aggregate. For the signing operation, the analogous downstream evidence producer is the persisted templating submission and document-key authority, followed by the operation's durable advancement. A declared requirement and a producer that can satisfy it must both be present. Neither a contract row nor a document event label manufactures the evidence it names.

## Checks an author can repeat

The Lex build, CLI admission, negative admission case, and two threshold tests were executed for this chapter. The complete current operation family also passed strict source-registry YAML validation. That validation covered 43 definitions and reported no parse errors, skipped definitions, missing required parameters, unmapped steps, enum drift, or length drift. It did not boot the application or exercise signing.

For the printed YAML projection, a small local check can catch accidental transcription damage after saving the block as `entity-lpa.yaml` in an environment with PyYAML:

```python
from pathlib import Path
import yaml

operation = yaml.safe_load(Path("entity-lpa.yaml").read_text())
assert operation["operation"] == "fund.entity_lpa_presign"
steps = operation["steps"]
seen = set()
for step in steps:
    assert step["id"] not in seen
    assert set(step.get("depends_on", [])) <= seen
    seen.add(step["id"])
last = steps[-1]
assert last["type"] == "document.entity_lpa"
assert last["wait_for"] == "document.signed"
assert last["timeout"] == "30d"
assert last["on_failure"] == "cancel_operation"
assert operation["compensation"]["steps"] == []
```

This check was executed successfully against the projection. It checks ordering and a few preserved contract values, not registry admission, handler availability, legal validity, or durable execution. A complete acceptance run would bind one registry revision and application build to an authorized actor, entity, operation, submission, and document key, then observe the actual persisted transitions. Until those observations exist, the strongest supported conclusion is that the rule admits and passes its selected tests, and the operation specimen matches a source-validated definition with inspected execution and evidence boundaries.

# Configuration and Pack Authoring Reference

This reference connects configuration fields to their consumers. It uses an illustrative teaching fixture and selected authored catalog entries. It does not certify current law, grant a license, or identify an operating sovereign deployment. The chapters on governing packs define the underlying authority and evidence requirements.

## Profile, zone, and lock specimen

The following fixture selects the existing reference legal-core module. That module describes itself as a placeholder model act. The profile and zone identifiers below are illustrative, and `zz` identifies no operating jurisdiction in this example. The shapes conform to the selected fields of the profile and zone schemas.

The profile selects one module, an explicit version, and a variant:

```yaml
profile_id: reference.single-module
stack_spec_version: 0.4.44
modules:
- module_id: org.momentum.mez.legal.core
  version: 0.1.0
  variant: commonlaw-minimal
```

The zone selects that profile and declares no corridor:

```yaml
zone_id: reference.zone
jurisdiction_id: zz
zone_name: Configuration teaching fixture
profile:
  profile_id: reference.single-module
  version: 0.4.44
corridors: []
lockfile_path: stack.lock
```

The decoded lock below follows the lock generator's object construction. Its two module hashes were computed from the inspected reference module using the generator's algorithms. This is a source-derived specimen, not evidence that the distribution was launched. The serialized lock uses canonical JSON, while this display uses indentation for reading.

```json
{
  "stack_spec_version": "0.4.44",
  "generated_at": "2026-09-06T00:00:00Z",
  "zone_id": "reference.zone",
  "profile": {
    "profile_id": "reference.single-module",
    "version": "0.4.44"
  },
  "modules": [
    {
      "module_id": "org.momentum.mez.legal.core",
      "version": "0.1.0",
      "variant": "commonlaw-minimal",
      "params": {},
      "manifest_sha256": "e13b4de77586bd4f214acc0cb0e46fdb423b53001c609a659fac1071510e4b61",
      "content_sha256": "f06a99964604d5fa7a9dbbfcc4ee96f1d8f1fdedb66fc3263d766c7cd77554cb",
      "provides": [
        {
          "interface": "mez.legal.akn.v0",
          "path": "src/akn/",
          "media_type": "application/xml"
        }
      ]
    }
  ],
  "lawpacks": [],
  "regpacks": [],
  "overlays": [],
  "corridors": []
}
```

The manifest hash covers the raw module manifest bytes. The content hash covers every module file in sorted relative-path order. The generator separates each path and file body with a zero byte. Neither hash establishes that the placeholder legal text has been adopted by an authority.

The `provides` entry declares an Akoma Ntoso interface and an artifact location inside the module package. It is a discovery contract. It does not establish an executable legal rule. The lock's empty `lawpacks` array is significant: this generator initializes that array empty, even when other configuration surfaces describe lawpacks.

### Resolution and defaults

| Field or behavior | Inspected rule | Consequence for an author |
|---|---|---|
| Profile selection | Find the matching `profile_id` | Ensure the intended profile is present and unique |
| Profile inheritance | No baseline or parent field in the profile schema | Express the complete module selection explicitly |
| Module version | Record the located module's version | Check it against the profile's requested version |
| Variant and parameters | Missing variant becomes `default`; missing parameters become `{}` | Inspect resolved values before use |
| Module parameter defaults | Lock construction copies profile parameters | Do not assume manifest defaults were merged into the lock |
| Zone overlays | Schema accepts `module_id` and a list of `patches` | Schema acceptance does not prove patch application |
| Lock overlays | Generator emits `overlays: []` | This path does not bind authored overlays into its output |
| Timestamp | Explicit value, retained timestamp, source epoch, then current time | Fix the timestamp for byte comparisons |
| Missing module | Warning and omission | Compare requested modules with resolved entries |
| Zero regulatory digest | Warning and omission | Build and verify real regulatory content before release |

The profile schema requires `profile_id`, `stack_spec_version`, and `modules`. Each selected module requires `module_id`, `version`, and `variant`. The zone schema requires zone identity, jurisdiction, display name, profile, and corridors. The illustrative fixture includes every required field.

An overlay declaration has a different status from a resolved override. A zone can pass a schema that permits patches while the lock generator leaves its overlay array empty. Do not infer inheritance, last-writer precedence, union semantics, or an applied patch from that schema alone. Inspect the component that actually consumes the configuration.

For a distribution that exposes the lock command, the reproducible comparison shape is:

```sh
mez lock zone.yaml --generated-at 2026-09-06T00:00:00Z --strict
mez lock zone.yaml --generated-at 2026-09-06T00:00:00Z --strict --check
```

These commands address local configuration and artifact resolution. The selected profile and module must be discoverable in the distribution. A successful comparison establishes matching computed lock bytes, subject to the generator's omission behavior. It does not establish complete pack adoption, successful execution, or recognized authority.

## Ordered source-to-operation authoring

A source-to-operation chain has independently checkable links. The following sequence uses an authored Texas reporting configuration as a diagnostic example. It deliberately stops where the inspected sources disagree. Legal dates, fees, and thresholds require current authoritative legal review before operational use.

1. Identify the source instrument and its effective scope. The selected lawpack names the Texas Securities Act and the federal covered-securities framework. Preserve source provenance and distinguish statutory text from executable interpretation.
2. Resolve each declared rule binding. The lawpack binds the securities-act and blue-sky-notice rule artifacts. A path that resolves establishes file availability, not semantic agreement.
3. Compare the bound rule with the obligation. The obligation identifies `us-tx.rule-506-form-d-notice` as a post-sale duty. The bound notice rule still contains the incompatible pre-sale clearance model. Stop admission at this mismatch.
4. Check the trigger and evidence contracts. The authored obligation uses `fundraiser_first_sale`, authority `tx_state_securities_board`, and submission channel `efd`. Its evidence identifiers include an EFD receipt and a counsel attestation.
5. Resolve the submission surface. Adapter `efd` declares authority identifier `did:mass:us_nasaa:efd` and fallback `counsel-fallback`. Its declaration explicitly withholds a live submission claim without the required implementation and credentials.
6. Author or select a procedure only after repairing the contradiction. Bind inputs, authorization, submission, waits, failure, and evidence to the actual supported consumer. A cure-path name in an obligation is not a resolved executable procedure.
7. Validate the completed family schemas and cross-references. Compile rules and procedure definitions using their actual consumers. Reject unknown accessors, missing actuators, conflicting definitions, and unresolved required evidence.
8. Compute canonical identities and retain the selected content. Apply the signature and recognition checks required by the specific admission path. The governance publication surface's provisional signature handling remains a separate unresolved assurance boundary.

This diagnostic example demonstrates why a plausible set of pack files cannot substitute for end-to-end authoring. The reference rule also declares pending prelude accessors. Until those accessors and the semantic contradiction are resolved, the chain does not establish an executable notice obligation.

The following is an exact field projection from the obligation definition. It is intentionally incomplete and is not a standalone pack submission:

```yaml
rule_id: us-tx.rule-506-form-d-notice
obligation_type: blue_sky_notice_post_sale
authority: tx_state_securities_board
submission_channel: efd
trigger:
  trigger_id: rule-506-offering-with-texas-sale
  kind: operational_fact
  fact_kinds: [fundraiser_first_sale]
blocking_conditions: ["actuator:efd_filing", manual_cycle_resolution]
cure_paths: [prepare_form_d_notice, file_via_efd, attach_efd_receipt]
```

The projection exposes the interfaces an author must reconcile. The omitted fields include source references, deadlines, recurrence, escalation, satisfying evidence, and automation. Their omission here does not make them optional in the complete contract.

For complete rule syntax and a full waiting operation, use *Worked Authoring: A Rule and a Waiting Operation*. That chapter separates a valid language fixture from institutional execution. Together, the two examples distinguish grammar validation from semantic agreement across packs.

## Module-family navigation

Use the following identifiers to locate representative module contracts in a distribution's catalog. An identifier denotes an authored interface, not verified runtime coverage. Pack family names identify typed content separately from module families.

| Family and representative identifier | Material to inspect | Related specification subject |
|---|---|---|
| Legal: `org.momentum.mez.legal.core` | Model text, source interfaces, variants | Lawpacks and legal interpretation |
| Regulatory: `org.momentum.mez.reg.aml-cft` | Screening and due-diligence parameters | Regulatory state and compliance |
| Licensing: `org.momentum.mez.lic.bank-sponsor` | Permission requirements and reporting artifacts | License categories and issuer evidence |
| Identity: `org.momentum.mez.identity` | Identity interfaces and credential requirements | Identity and delegated authority |
| Corporate: `org.momentum.mez.corporate` | Formation, ownership, secretarial artifacts | Entities, consent, and signing |
| Capital markets: `org.momentum.mez.capital-markets` | Issuance, clearing, post-trade interfaces | Claims and settlement |
| Financial: `financial.banking-adapter` | Banking connection contract | Payments and provider boundaries |
| Trade: `org.momentum.mez.trade` | Credit, documents, customs, insurance | Trade and logistics |
| Tax: `org.momentum.mez.tax` | Collection, withholding, reporting | Duties and tax evidence |
| Corridor: `org.momentum.mez.corridor.correspondent` | Cross-border interface declaration | Recognition and evidence exchange |
| Governance: `org.momentum.mez.governance.approval-voting` | Voting configuration | Authority and governance |
| Arbitration: `org.momentum.mez.arbitration.expert-determination` | Expert decision procedure | Disputes and recourse |
| Operational: `operational.audit-logging` | Audit interface and retention configuration | Evidence, operation, and recovery |
| Primitive integration: `org.momentum.mez.mass-primitives` | Institutional primitive interface declarations | Native ownership and mutation boundaries |

The pack index is complementary. Use lawpacks for source binding, regpacks for operational regulatory data, and licensepacks for permission data. Governancepacks declare internal decision constraints. Obligationpacks define duties, procedurepacks define executable procedures, and adapterpacks describe external systems. Corridorpacks define acceptance conditions. Templatepacks and modelpacks constrain plan authoring and model invocation.

Decision tables, fee data, claim-axis definitions, and smart-asset artifacts can accompany these modules. Their presence does not make each directory a separately executable module family. Follow the selected manifest interface and its consuming operation.

## Jurisdiction and institutional-act crosswalk

The following entries summarize authored configuration subjects. They are a navigation crosswalk, not statements that the listed permission exists today or that a particular entity holds it. Instrument names come from zone configuration. Authority and license identifiers come from license-category data. Representative acts identify the subject to investigate, with an executable operation name only where separately checked.

| Configuration scope and named instrument | Authored authority and permission identifier | Representative act and boundary |
|---|---|---|
| Pakistan: Companies Act 2017 | SECP; `secp_company_registration` | Company registration. Confirm the actual procedure and issuer receipt for the intended entity form |
| Pakistan: Income Tax Ordinance 2001 | FBR; `fbr_ntn` | Tax registration. A declared registration category does not establish an issued tax number |
| Seychelles: International Business Companies Act 2016 | FSA; `fsa_ibc` | `entity.incorporate` for `sc`; distinguish incorporation, annual maintenance, good standing, and restoration |
| Seychelles: IBC corporate lifecycle | FSA registration category; `fsa_ibc` | `entity.restore` for `sc` is a separate authored procedure. A renewal fee or good-standing document alone does not establish restoration |
| ADGM: Companies Regulations 2020 | Registration Authority; `adgm_commercial_license` and `adgm_registration_certificate` | `entity.incorporate` for `ae-abudhabi-adgm`; commercial permission and registration are distinct entries |
| ADGM: Financial Services and Markets Regulations | Financial Services Regulatory Authority; `fsra_category_1`, `fsra_category_4` | Financial-services permission review. Corporate registration does not establish permission for regulated financial activity |
| ADGM: Insolvency Regulations | Authority depends on the particular insolvency act | Winding-up or administration review. The named instrument alone supplies no license-to-act mapping |
| AIFC: Companies Regulations | Registrar of Companies; `aifc_company_registration` | Participant company registration. Do not substitute a domestic Kazakhstan registration |
| AIFC: Financial Services Framework Regulations | AFSA; `afsa_dealing_investments`, `afsa_custody` | Activity-specific permission review. Each category requires its own holder and evidence checks |
| AIFC: financial innovation testing | AFSA; `afsa_fintech_lab` | Sandbox authorization. A sandbox category does not establish unrestricted permission or graduation |

For Seychelles, good-standing, renewal, and restoration are separate questions even where a workflow groups their preparation. For ADGM, formation and insolvency have different decision and evidence requirements. For AIFC, participant status, regulated activity, and sandbox conditions remain separate from domestic Kazakhstan scope.

This crosswalk intentionally leaves missing links visible. The next authoring action is to resolve the exact act, authority, procedure, and receipt contract. A deployment should publish only the resulting verified capability, with any unavailable or manual stage still explicit.

# Integration and operator reference {#integration-operator-reference}

This reference connects interface discovery, credential selection, local preparation, and operational diagnosis. Commands identify source-defined interfaces. None establishes a newly executed deployment, test, filing, or recovery campaign. Example identifiers denote local test artifacts and confer no legal authority.

## Credential selection and admission

Select credentials by the route's trust boundary. A signed token proves possession of an accepted credential under its validation rules. Business authorization additionally depends on the actor, subject, scope, current authority state, and proposed action.

| Credential class | Validation boundary | Operational use |
|---|---|---|
| Firebase identity token | RS256 signature, configured project audience and issuer, required identity and time claims | Authenticated user sessions and dedicated test principals |
| Mass access JWT | Ed25519 signature, expected issuer and audience, expiry and issued-at checks | Scoped access issued through the OAuth client-credentials flow |
| Service JWT | Service issuer, service audience, signature, and time checks | Explicit service-to-service admission where the route accepts it |
| MassBiscuit | Accepted capability encoding, signatures, caveats, and current authority checks | Capability-bound actions supported by the selected interface |
| Internal shared credential | Configured internal authentication lane and route restrictions | Restricted service integration, without public-user authority |

The Firebase verifier requires `sub`, `iss`, `aud`, `exp`, and `iat`. It configures a 30-second clock allowance. It also checks subject consistency where duplicate identity fields occur. The presence of an email address in a payload does not establish verified identity.

The Mass JWT verifier rejects an expired token beyond its allowance. It rejects future issuance and issuance older than its maximum accepted lifetime. When an audience is expected, a missing audience fails. A different issuer or audience also fails. These are implemented checks, not a reason to tolerate unsynchronized infrastructure clocks.

`POST /oauth/token` accepts the client-credentials grant. The request provides `grant_type`, `client_secret`, optional `client_id`, and optional space-delimited `scope`. The handler checks the credential record and recognized scope names before issuing an access token. Token issuance also has an audited mutation path.

Scope computation has a compatibility exception. With nonempty allowed and requested sets, the helper returns their intersection. With no requested scopes, it returns the allowed set. With an empty allowed set, it can return requested scopes. Both sets empty produces no scopes. Operators must configure explicit allowed scopes and test rejection outside them.

`POST /v1/oauth/introspect` is an authenticated administrative surface. The examined guard requires the corresponding administrative role and compliance-read scope. Its active-status check includes JTI revocation. JTI means the token's unique identifier. The removed `/v1/oauth/revoke` route must not appear in new integration instructions.

The authentication path also checks JTI revocation against durable state. A database failure during authority resolution must not become unrestricted access. Entity membership resolution distinguishes an empty membership result from a failed lookup. The latter returns a retryable failure instead of silently admitting an empty scope.

JWT revocation, signing-key rotation, and capability epochs are different controls. JTI revocation addresses an individual issued token. Key rotation changes which signatures a verifier accepts. Capability authority and revocation state constrain delegated actions under their own current-state rules. Completion of one control does not prove completion of the others.

OAuth signing can use an independent configured key. The examined resolver can fall back to the zone signing key, including after a provider error. Therefore, setting an OAuth key variable does not establish independent key custody. Verify the actual signer fingerprint, accepted verification keys, and issued-token behavior before declaring rotation complete.

For capabilities, retain the accepted byte encoding and current authority requirements. A JSON-looking object is not interchangeable with an encoded capability token. Client attenuation and server verification must agree on the representation. Exercise the exact producer-to-consumer path before relying on an SDK method's name.

### Ingress order and route classes

The main authenticated route graph applies rate limiting and backpressure before authentication. Zone context and authenticated scale checks precede write-contract and idempotency handling. Outer layers also establish request identity, client-IP context, content handling, tracing, and drain behavior. Router composition determines the execution order because later layers wrap earlier layers.

Public token issuance has a separate rate-limit configuration. Health routes and restricted internal routes have their own composition. Do not infer a route's security from a neighboring prefix. Verify the specific mounted route and its guard, including middleware installed by its parent router.

| Route class | Credential and enforcement | Acknowledgement boundary |
|---|---|---|
| Public operation admission | Accepted caller credential, entity and action scope, write contract, idempotency, sanctions and applicable compliance checks | Durable admitted operation or proof response, interpreted with residuals |
| Public resource read | Route-specific identity, scope, and disclosure guard | Authorized representation of current or documented historical state |
| External compute call | Explicit service contract and permitted egress credential | Compute response only, until Mass validates and persists required effects |
| Internal persistence integration | Restricted internal credential and owning service contract | Authorized durable mutation, subject to the mutation boundary |
| Provider callback | Provider verification, event identity, and exact subject binding | Admitted callback or delivery acknowledgement, followed by required operation effects |

The public API generally uses its owning-domain schema. External compute can use a different private wire schema. The adapter owns that conversion. A callback's valid signature cannot replace entity binding, and an internal credential cannot make an arbitrary database write legitimate.

## API domain navigation

Use `/openapi.json` from the intended process to obtain methods, request schemas, response schemas, and security declarations. Match its routes to the source-mounted domain modules. The table below identifies verified navigation families without claiming a complete endpoint census.

| Owning route module | Mounted navigation family | Discovery question |
|---|---|---|
| Entity routes | `/v1/entities` | Which entity lifecycle and membership operations accept this actor? |
| Ownership routes | `/v1/ownership` | Which cap-table, security, and offer records belong to the subject entity? |
| Treasury routes | `/v1/treasury`, `/v1/fiscal` | Which actions require treasury compute or an external payment acknowledgement? |
| Identity routes | `/v1/identity` | Which identity action and evidence type does the selected controller accept? |
| Governance routes | `/v1/governance` | Which consent, meeting, or signing action is currently actionable? |
| Corridor routes | `/v1/corridors` | Which peer, state transition, receipt, or audit representation is requested? |
| Smart-asset routes | `/v1/assets` | Is the action validation, simulation, or a durable asset transition? |
| Arbitration routes | `/v1/disputes` | Which dispute phase permits the requested action? |
| Notification routes | `/v1/notifications` | Is the result a delivery record, search result, or restricted message detail? |

A domain can contain several prefixes, and one prefix can combine several services. The ownership route module, for example, does not make all ownership behavior a single database aggregate. Resolve the operation identifier and response schema before choosing a client wrapper.

Generated catalogs must retain mounted-path evidence. Source comments sometimes describe a former endpoint name. The OAuth introspection comment and mounted path illustrate why the router expression controls route discovery. Client methods also need comparison with the mounted contract, not just their generated types.

| Component | Owner and dependencies | Verification question |
|---|---|---|
| API composition | Constructs routes, middleware, services, and daemon state | Do requests and background work use the same wired services? |
| Primitive service | Owns domain behavior and calls its persistence facade | Does the action preserve authored fields and applicable invariants? |
| Persistence facade | Owns storage mapping and transactional database access | Do committed records represent the required effects atomically? |
| External adapter | Owns provider transport and wire conversion | Is the exact provider request joined to its acknowledgement? |
| Operation runtime | Coordinates steps, waits, and recovery | Are terminal outcomes supported by all required durable effects? |
| Client and MCP transport | Encodes requests and interprets responses | Does the real caller reach the expected route and retain residuals? |

## Linear local verification path

### Prepare the target

Obtain an authorized source distribution or a release artifact with its verification material. Identify a local PostgreSQL target, required external compute, object storage, and identity-provider configuration. Reserve an unused port. Determine which other processes can advance work against the same database.

For source builds, use the distribution's Rust toolchain. The local launcher also requires the supported Chrome or Chromium executable for document rendering. Docker is required when using the supplied local service containers. The web client requires its pinned Node and package-manager configuration when the test includes browser authentication.

These discovery commands inspect local processes and tools:

```sh
docker ps --format '{{.Names}}\t{{.Ports}}'
lsof -i :8080
rustc --version
cargo --version
```

The port shown is a diagnostic example. Select another free port when necessary. Do not stop an unknown process to obtain that port. A successful tool-version command only establishes that the tool can run.

### Configure and launch

Provide the authorized local environment file without printing its secrets. Set the database target, listener port, zone selection, compute URLs, object storage, and authentication configuration. Use a build directory dedicated to this source state. The launcher sources its environment file, so values inside that file can override inherited shell values.

The source launcher inspected on 6 September 2026 belongs to the authorized implementation distribution. It builds the API executable, prepares local attestation material, verifies that material, and starts the process. Operators need that distribution's launcher and environment contract to perform these actions. This reading edition describes the procedure without supplying a runnable launcher. Its local, untrusted attestation does not produce production release evidence.

The current launcher requires an operator-provided database. It defaults the listener to loopback only when `MEZ_BIND_ADDR` is absent. It supplies the `world` umbrella when neither jurisdiction nor zone configuration is set. Choose an explicit zone when the acceptance case depends on one jurisdiction. Its local attestation uses existing archived reports; the launcher does not rerun those verification campaigns.

In an authorized source distribution, use the supplied compute-service target when those containers belong to the local test environment:

```sh
make dev-services
make dev-status
```

The first command builds and starts services. The second probes fixed localhost ports and container names. Check the selected runtime separately when its addresses differ. Neither establishes that a business operation works through those services.

After launch, retrieve `/health/build`, `/health/readiness`, and `/openapi.json` from the selected origin. Preserve build identity and contract digest without exposing secrets. A readiness failure requires diagnosis before business verification. A healthy result permits the next test but does not complete it.

### Establish the dedicated actor

Use the dedicated E2E principal or its purpose-built alias. Do not use a personal account. Obtain its session through the supported identity-provider harness. Where a fresh environment requires platform administration, bind the dedicated verified UID through `MEZ_PLATFORM_ADMIN_UIDS` under the operator's authorization.

Create test entities, membership, and identity through authenticated APIs. For administrative identity creation, establish the target user's entity membership first: the route requires an owning entity to anchor its proof and rejects an absent anchor before writing. Supply the idempotency key required by the public write contract. Do not create missing product state with direct SQL.

Test notifications can cause real delivery. Use only approved test recipients and provider destinations. A fake email inside a request is not a supported substitute for authenticated identity. Verify which provider mode the environment actually uses.

### Exercise the first operation

First retrieve an authorized subject through the API. Then discover the admitted operation type and its required input schema. Choose a bounded operation whose authored inputs and required effects are available. Preserve one intent identifier across its transport attempts.

Submit through the selected public interface. Record the returned operation, step, and verdict references. Inspect pending actions before advancing work. If the operation requires a signer or provider acknowledgement, complete that actual boundary under the dedicated test authority.

The inspected implementation distribution supplies a live entity suite. After configuring the environment and credentials, an authorized operator runs that suite from its Cargo workspace, with output capture disabled and one test thread. Set `MEZ_TEST_BASE_URL` explicitly to the selected local origin. Configure the dedicated test email and authenticated credential inputs through the approved environment. This suite fails when `MEZ_TEST_BASE_URL` is unset. Its source and runner are required for execution and are not included in this reading edition. A skipped case remains unverified.

Retrieve the resulting operation proof through its mounted route. Check its subject, verdict reference, artifact bindings, and residuals. Use the server's accepted verification request schema. The client wrapper and server currently require explicit compatibility review for proof-field naming. Do not claim successful verification from a typed method signature.

The path is complete only when the required durable effects and verification result agree. If the selected verifier rejects the request shape, record that failure. Repairing the interface or using its documented accepted schema requires separate implementation verification. A locally constructed success object cannot close the test.

## Deployment responsibilities

| Surface | Present configuration mechanism | Operator responsibility |
|---|---|---|
| Executable | Container image and release-attestation inputs | Pin the actual artifact and verify the externally selected trust root |
| Workload identity | AWS task and execution roles, or selected platform equivalent | Separate image/secret access from application permissions |
| Network | Task security groups and ingress rules | Admit traffic only from intended ingress and required dependencies |
| TLS | Certificate and listener configuration, or Kubernetes ingress TLS settings | Validate certificate ownership, hostname, renewal, and termination boundary |
| Service account | Kubernetes chart service-account configuration | Supply required permissions without assuming token automount |
| Rollout | Container-service or Kubernetes rolling strategy | Align readiness, drain, termination, migrations, and daemon handover |
| Persistence | PostgreSQL, document storage, and retained content | Verify access, residency, backup consistency, and restoration |

The examined Kubernetes values contain example image, host, secret, and resource settings. They are not deployment recommendations. Some configuration templates can lag the executable's requirements. Compare rendered configuration with actual consumers before applying it.

The AWS source includes separate task and execution roles and a task ingress boundary tied to the load balancer. Those declarations require an applied-state check. A Terraform file cannot prove that the active security group, certificate, or role matches it.

## Coupled controls

The table separates active environment consumers from typed parameters and unproven deployment controls. Units matter: receipt counts, seconds, absolute deadlines, and currency exposure are different quantities.

| Control and unit | Consumer and validation | Coupling and acceptance |
|---|---|---|
| `MEZ_DAEMON_SYNC_SECS`, seconds | Corridor daemon interval, clamped to its minimum | Compare receipt production with peer delivery and queue age |
| `MEZ_DAEMON_HEARTBEAT_SECS`, seconds | Corridor heartbeat scheduling, clamped to its minimum | Probe delay interacts with missed-heartbeat classification |
| `REVOCATION_SYNC_INTERVAL_SECS`, seconds | Revocation synchronization configuration | Poll cadence does not guarantee peer reachability or fresh authority |
| `REVOCATION_SYNC_REQUEST_TIMEOUT_SECS`, seconds | Revocation peer request budget | Budget failed peers without starving other work |
| `refresh_interval`, `max_staleness`, seconds | Sanctions lawpack feed settings and freshness consumer | Source validation rejects staleness shorter than refresh interval |
| `freshness_days`, days | Required-receipt regime selector and receipt-check step | Must be positive and match the issuing authority's evidence contract |
| `checkpoint_frequency`, receipt count | Typed corridor receipt-chain parameter | No active API/daemon consumer was established in this review |
| `max_receipt_latency_secs`, seconds | Typed corridor receipt-chain parameter | A declared limit needs a demonstrated enforcement caller |
| Migration `timeout`, absolute UTC deadline | Migration protocol timeout check for nonterminal phases | Extend neither authority nor settlement finality by changing a local timer |
| Exposure limit, currency amount | Requires the owning transaction and risk-policy contract | No universal deployment environment knob was established here |
| Availability requirement | Depends on the selected provider, peer, or evidence contract | Health probes cannot establish receipt or artifact availability |

Do not turn typed fields into advertised tuning switches without a verified consumer. Checkpoint parameters illustrate the distinction. A serializable value can travel through content snapshots without controlling a running scheduler. Its presence does not prove a checkpoint every specified number of receipts.

Sanctions freshness and sanctions rejection also remain separate. Feed age can produce an evidence residual. It must not convert a sanctions rejection into an allowed action. Acceptance should test stale evidence, failed refresh, restored freshness, and the terminal rejection path independently.

`DATABASE_READ_URL` is parsed by a separate pool initializer, but the examined executable uses the single-pool initializer. The optional pool composition is not wired there. Therefore, setting this variable does not establish an active read replica. Verify the actual connection consumer before reporting read isolation or read scaling.

## Symptom, diagnosis, and recovery

| Symptom | Diagnostic evidence | Supported recovery direction |
|---|---|---|
| Process exits before binding | First startup error and attestation/configuration identity | Correct the rejected input and rerun the supported launcher |
| Missing compute URL | Named configuration failure | Provide the intended endpoint, then verify its connectivity |
| Readiness fails after startup | Dependency results and drain state | Restore the required dependency or complete controlled replacement |
| JWT rejected | Issuer, audience, time class, and revocation result without token disclosure | Correct credential selection or authorized issuance |
| OAuth scope differs from request | Credential's allowed scopes and granted response | Configure explicit allowed scopes and repeat denial checks |
| Operation remains waiting | Step type, exact subject, signer or provider identifier | Complete the required action through its supported boundary |
| No advancement | Current daemon holder, build identity, renewal, and errors | Repair the worker or use controlled process handover |
| Stream reconnect loses display state | Durable operation read and last received event identifier | Reconcile state and resume from the returned cursor |
| Callback repeatedly fails | Signature inputs, event identity, and subject binding | Repair verification or routing, then replay the same event safely |
| Document retrieval fails | Object identity, storage response, and recorded digest | Restore authorized access or bytes and verify integrity |
| Proof verification fails | Exact request schema, proof bytes, trust inputs, and residuals | Resolve the actual schema or evidence failure before claiming admissibility |

A diagnosis must preserve the original committed effects. Restarting a display client does not cancel an operation. Recreating an operation does not repair a failed notification. Changing a key does not retrospectively verify an artifact signed under another key. Recovery must use the causal identifiers of the affected work.

## Local CLI lifecycle examples

Run these commands from the supplied content working directory. Input files must contain the relevant schemas and authored content. The commands below prepare or inspect local artifacts. They do not submit transactions to the running Mass API.

### Corridor preparation

```sh
mez corridor create --id pk-rez--ae-difc \
  --jurisdiction-a pk-rez --jurisdiction-b ae-difc
mez corridor submit --id pk-rez--ae-difc \
  --agreement agreement.json --pack-trilogy pack-trilogy.json
mez corridor status --id pk-rez--ae-difc
```

The create command writes a local corridor record. Submit hashes available agreement and content bytes, but substitutes path-string bytes when a file is missing. It checks the local transition and records a pending state. The resulting digest therefore does not by itself establish artifact custody. The command does not submit to a regulator. The separate activation utility hashes supplied approval strings without authenticating regulatory signatures. Its local state is insufficient evidence for corridor admission.

### Asset artifacts

```sh
mez asset genesis-init --asset-id asset:example \
  --owner did:example:owner --out genesis.json
mez asset state verify --chain asset-chain.json
mez asset state checkpoint --chain asset-chain.json --out asset-checkpoint.json
```

The first command creates a local genesis envelope. The remaining commands require an independently supplied chain file. Genesis output alone does not provide that chain. None registers an asset through the service. The genesis initialization and genesis-hash handlers also hash different object shapes, so their digests must not be assumed equal.

### Regulatory content

```sh
mez regpack list
mez regpack build --jurisdiction pk --domain sanctions --store
mez regpack verify --jurisdiction pk --domain sanctions
```

Build uses the supplied regulatory data and stores a local content artifact. Verification without a file or digest follows a rebuild-validation path. These operations neither install content into a running zone nor establish current regulatory acceptance.

The file/digest verification path has a material limitation. A mismatch between canonical and declared digest can produce a warning while returning success. Therefore, a zero exit status on that path does not establish digest integrity. Retain diagnostics and verify the relevant digest with an independently checked verifier.

### Dispute preparation

```sh
mez arbitration institution-list
mez arbitration dispute-init \
  --claimant-did did:example:claimant \
  --respondent-did did:example:respondent \
  --jurisdiction sg --institution-id siac \
  --dispute-type payment-default \
  --claim-description "Payment remains outstanding" \
  --out dispute-init.json
mez arbitration dispute-file --init dispute-init.json --out filing-summary.json
```

The first command lists the built-in institution registry. Initialization creates an envelope, and filing stores a local dispute record. It does not file with the named institution. If an amount is supplied, the currency must also be supplied. Use an authorized product or institution interface for an actual filing and retain its acknowledgement.

# Foundational assumptions and design obligations

## Assumptions belong to particular claims

A correctness claim must identify the assumptions that make it true. Cryptographic, computational, institutional, operational, and economic assumptions have different failure modes. A system can satisfy one class while failing another.

For example, an authentic signature can bind an unauthorized instruction. A deterministic executor can reproduce incorrect authored rules. A solvent ledger can coexist with inaccessible custody. A valid award can remain unperformed. The acceptance argument must address the particular property claimed.

The assumptions below organize the architecture. They are not assertions that every deployment currently satisfies them.

## Cryptographic assumptions

Commitment integrity requires the chosen digest construction to resist the relevant collision or preimage attack. Signature authenticity requires the configured verification policy and key material to satisfy its security assumptions. Combining signature algorithms changes the acceptance predicate. Its security follows that predicate, not the word hybrid.

Key ownership requires secure generation, custody, authorized use, rotation, and retirement. A valid historical signature can remain useful after the key retires. Current action authority must apply the current policy. Recovery must retain enough old public material to verify the records that still matter.

Randomized cryptographic operations require a suitable cryptographically secure random source. Nonces, proof randomness, keys, and protocol challenges have different uniqueness and secrecy requirements. Reusing a value can invalidate the corresponding security argument. An implementation must verify the randomness or deterministic-generation contract of each algorithm it actually uses.

Aggregate signatures require an admitted signer set and the verification conditions of the chosen aggregate scheme. A signature count cannot establish signer independence. Zero-knowledge claims require a defined relation, correctly bound public inputs, and an accepted proof system. Privacy cannot be inferred from an opaque proof field.

## Computational assumptions

Reproduction requires the same admitted inputs, interpretation rules, arithmetic, and execution configuration. A deterministic result is relative to those inputs. External observations and discretionary answers must enter through retained evidence rather than fresh ambient reads during replay.

Bounded execution requires limits at the actual consuming boundary. Parser size, recursion depth, instruction work, memory, database work, and external waits can need different limits. A gas counter that excludes an expensive host operation does not bound the entire action.

The compiler, interpreter, database adapter, and proof verifier must agree on the semantics that cross their interfaces. A theorem about a small language fragment does not establish this agreement for a larger implementation. The missing refinement obligation remains explicit until its full scope is discharged.

## Institutional assumptions

The system requires a valid basis for recognizing the relevant organization, office, agreement, rule, and deciding authority. That basis can differ across jurisdictions and instruments. Its representation must preserve provenance and the limits of recognition.

An authored rule set needs competent interpretation of its legal sources. A typechecker can reject malformed rules while accepting a substantively incorrect rule. The review procedure must address meaning, authority, effective time, and the consequences of amendment.

Legal tradition can affect the admissible sources, interpretive method, and deciding authority. The evaluation context must preserve those distinctions when the applicable procedure depends on them. A common compliance domain does not make two traditions' evidentiary or interpretive rules identical.

The deploying sovereign can also operate the software. That combination can correlate the producer of evidence with the authority judging its sufficiency. Where the recognition policy requires independent regulator or external attestation, the system must preserve distinct issuers and their roles. Two signatures under common control do not establish independent oversight.

Discretion requires an authorized decision about a defined question. A decision record must bind the deciding party, question, evidence, reasons where required, and permitted effect. Subsequent execution must preserve those limits.

Cross-jurisdictional recognition requires an explicit direction and scope. A local finding does not become universally recognized through transport. The receiving authority must decide what it accepts and retain the conditions that govern that acceptance.

The sovereign design shall not mandate one global trust anchor or one application through which all institutional action must pass. Each deployment must retain its authority over admitted roots, interfaces, data custody, and recognition. Common protocols can make these decisions interoperable without assigning them to a sole operator. A deployment that chooses shared infrastructure must still make its resulting concentration and exit conditions explicit.

Biometric evidence alone shall not determine a person's institutional eligibility or irrevocably deny access. Its error rates, presentation attacks, source authority, and corroborating evidence must remain visible to the decision procedure. Where an adverse decision depends on contested identity evidence, an authorized correction and review path must exist. These are design commitments; the book does not claim universal enforcement across every current interface.

## Economic assumptions

Recorded balances must correspond to value under the named custody and settlement arrangements. Funded liabilities require correctly denominated assets and enforceable access to them. A price estimate cannot create nominal settlement capacity.

Risk models require declared inputs, scenarios, horizons, netting rights, and liquidation assumptions. Their estimates remain conditional. They must coexist with independent authority, eligibility, sanctions, custody, and availability gates.

Claims must preserve the distinction between face amount, modeled value, entitlement, reserved resources, settlement, and recovered value. Partial performance must reduce the appropriate remaining exposure without erasing other duties. A command receipt must describe its actual effect.

## Operational assumptions

Durability requires correctly configured storage and recovery procedures. A committed outbox preserves an intention to deliver. Delivery additionally requires available workers, an admitted destination, bounded retry behavior, and a receiving acknowledgement.

Recovery requires coherent state. Restoring balances without consumed-intent records can reopen authority. Restoring receipts without their economic effects can overstate performance. Restoring a continuation without its duty and reservation state can lose obligations.

Distributed succession requires effective fencing or exclusive custody. A complete copy does not prevent the predecessor from acting. Freshness against coherent rollback can require an external monotonic anchor. The architecture must name where that protection lives.

Availability claims require stated fault assumptions and measured operating conditions. Timeout values, scheduling intervals, and configured ceilings do not establish latency, throughput, recovery time, or geographic resilience.

## Supply chain and deployment assumptions

A deployment must identify the binary, dependencies, build inputs, configuration, rule material, and keys relevant to its claim. A clean dependency scan answers a bounded question about known findings. It does not establish the absence of malicious or unknown behavior.

An image tag can move. A source branch can advance. A deployed observation must bind the actual image or binary and its inputs. Documentation and source metadata can help locate that identity but cannot replace it.

Provider profiles matter. The intended persistence and signing architecture must match the configured running services. An alternative profile can have a different storage or authority boundary even when the service name is unchanged.

## Human and governance assumptions

Human authority remains necessary where a constitution, agreement, law, or product contract requires it. The runtime must represent the missing decision rather than invent a substitute person or approval. Automation must preserve the action's existing authority limits.

Operators need enough information to distinguish waiting, failure, partial effects, and completed recovery. A useful incident record states the affected intent, authority, evidence, and remaining duty. Manual intervention must use an authorized transition and retain its own record.

Good faith is not an input-validation strategy. Pack authors, counterparties, providers, and operators can make mistakes or act adversarially. Admission should verify what it can and identify the trust that remains.

## Research and implementation

The research program supplies models for programmable organizations, multiple harbors, compliance composition, executable rules, workflows, evidence, claims, settlement, and dispute resolution. These models inform design. A model becomes an implementation contract only when its objects and obligations are mapped to concrete interfaces and state.

The Lex, Op, gstore, and Stack projects provide distinct reference surfaces. Their names do not establish complete interoperability or deployed use. A consuming implementation must identify the exact imported contract and the adaptations it makes.

Formal results must state their fragment, assumptions, and conclusion. A closed proof can depend on an explicit unproved premise. A theorem whose conclusion is structurally trivial does not establish the operational property suggested by its title. A model-checking run explores its configured model and bounds.

Reference execution can demonstrate a mechanism such as direct continuation restoration or exact retry. Production realization additionally requires authenticated host identity, secure keys, current institutional grants, durable storage, and authoritative adapters. The book carries those obligations into the target architecture.

## Formal-result navigation

The following index records selected source-inspected formal statements and their actual models. Closed proof bodies were inspected, but the proof assistants were not rerun for this edition. The table summarizes those dated inspections by property, model, and remaining obligation. The retained proof sources are required for independent verification. These bounded results and open obligations do not certify the corresponding deployed system.

| Property and statement | Model and strongest supported scope | Remaining obligation |
|---|---|---|
| Mixed-axis impossibility | Contradiction under the stated meet-semilattice, audit-fix, and antichain hypotheses | Do not generalize to every conceivable compliance model; specify which hypotheses the product requires |
| Applicable residual | The three-state applicable fragment satisfies its meet/residual adjunction | Preserve applicability and mixed-axis obstructions when mapping to actual evaluations |
| Post-flight monotonicity | In the five-chain domain-array model, pointwise meet cannot raise the aggregate above its pre-state | Establish that the actual transition uses the modeled rule; the result does not reverse already committed effects |
| Op effect bound | A small effect-tracking machine bounds its trace by initial, declared, and compensation rows | Relate concrete compiler and host emissions, errors, and retained effects to those constrained step constructors |
| Op local diamond | Independent increments of two disjoint natural-number slots commute | Prove the stronger conditions needed for real workflows, shared resources, and external effects |
| Lex sanctions preservation | A worked oracle example's defined override preserves an already propagated bottom result | Establish oracle accuracy, identity binding, freshness, and enforcement at every affected admission path |
| gstore append preservation | Abstract append statement whose proof is explicitly admitted | Supply the concrete carrier and completed proof; an admitted statement is an open obligation |

The conditional structure matters. For example, a machine whose transition constructors already restrict emitted effects can have a valid trace theorem. That theorem still needs a correspondence argument before it constrains a production adapter. Likewise, proving an exclusion from a particular algebraic design does not prove that every alternative institutional model is impossible.

## Architecture acceptance matrix

| Property | Necessary evidence | Frequent incomplete result |
|---|---|---|
| Authored intent | Bound input and authenticated principal | Convenient synthesized values |
| Action authority | Current grant for the exact action and object | A valid session alone |
| Rule admission | Pinned rules, evidence, evaluator result | Schema or typecheck success alone |
| Durable mutation | Committed effect and transaction evidence | A preflight verdict |
| Complete workflow | Every required effect and acknowledgement | Operation creation or one successful step |
| Historical reproduction | Retained inputs and matching interpretation | Re-evaluation under current rules |
| Financial settlement | Correct custody, consumed intent, balances and receipt | A submitted batch |
| Native finality | Bound execution and accepted committee evidence | An inclusion proof without accepted finality |
| Award execution | Accepted destination instruction and its effect | A signed outcome or local enforcement status |
| Recovery | Reconciled value, beneficiary, asset and residual duty | Award face amount |
| Succession | Complete cut, receiver validation and effective fences | A copied archive |
| Formal assurance | Exact theorem scope and discharged assumptions | A proof count or passing compilation |

## Verification campaigns and their first falsifiers

Verification should begin with a property and a counterexample capable of disproving it. The retained evidence must preserve enough context to reproduce that counterexample. The following matrix defines campaigns for the specified architecture; it does not report that every campaign has passed.

| Requirement and test class | First material falsifier | Evidence to retain |
|---|---|---|
| Canonical identity: cross-implementation vectors and properties | Equivalent admitted objects yield different bytes, or distinct required meanings collapse | Input domain, canonical bytes, schema and encoder identities |
| Receipt linkage: chain and mutation integration | A receipt verifies against the wrong predecessor, intent, or effect | Complete witnesses, roots, causal identifiers, committed records |
| Compliance composition: algebraic properties and boundary cases | A forbidden action becomes admissible through composition or loss of applicability | Typed operands, rule identity, result and obstruction |
| Pack admission: schema, resolution, and semantic fixtures | A missing module or conflicting rule is accepted as complete | Requested and resolved content, diagnostics, identities |
| Authority: authenticated API integration | Revoked, wrong-entity, or insufficient authority changes durable business state | Actor binding, request, refusal, before/after authoritative state |
| VM metering: adversarial resource tests | An admitted host operation exceeds its charged resource bound | Program, host configuration, counters, measured work and termination |
| Callback handling: replay and fault injection | Duplicate or changed delivery repeats an effect or applies to another submission | Exact authenticated payloads, identities, transitions and resulting balances |
| Local atomicity: crash injection at commit boundaries | Business effect survives without required audit, outbox, or proof, or vice versa | Failure point, transaction result, restart state and reconciliation |
| Continuation and succession: restart and stale-owner execution | A restored computation changes its next effect or an obsolete owner still acts | Decoder image, logical work, custody generation, reservations and receipts |
| Settlement and recovery: complete financial journey | A result reports paid or recovered value absent from destination evidence | Entitlement, reserves, destination records, finality and remaining duty |

A finite model checker enumerates reachable states under its chosen model and bounds. A refinement argument connects an implementation transition to the modeled transition, including errors and host effects. A runtime trace demonstrates one execution under identified conditions. These methods answer different questions and should be linked by the same requirement, rather than combined into one undifferentiated pass count.

### A replay and partial-performance vector

Use an illustrative duty with principal 100 units and an admitted command authorizing performance of 40 units. Before execution, its 40-unit reservation is unavailable to other commands. After authoritative performance of 40, residual principal is 60, the command's receipt is retained, and its consumed authority cannot be used again. The reservation's release or consumption follows the settlement contract.

An exact replay of that command must return its retained receipt with residual principal still 60. A request that reuses the command identity with a changed amount must be refused without a new effect. If another admitted payment later supplies 10 units, residual principal becomes 50 under the duty's allocation rules. Closing the original command still cannot discharge that remaining 50.

This vector is a specification fixture, not a transcript of product execution. An implementation check must run through the actual admission and persistence boundary, interrupt after a possible commit, restart, and compare the retained receipt and balances. An in-memory function that reproduces the arithmetic cannot establish durable replay safety.

## Architectural decisions and reconsideration conditions

| Decision and governing constraint | Cost or limitation | Evidence that could justify revision |
|---|---|---|
| Common mutation admission for shared authority and evidence | Coordination and composition-root complexity | A replacement preserves sanctions, authored intent, atomic effects, and audit across every affected route |
| Domain-owned services and persistence facades | Cross-domain work needs explicit orchestration | A boundary change reduces coupling while preserving one accountable owner and transaction semantics |
| SQL transactions for local institutional effects | External systems remain outside the transaction | A different persistence mechanism supplies equivalent admitted atomicity, recovery, and operational evidence |
| Identified packs and historical interpretations | Authors must retain versions and resolve compatibility | New composition semantics preserve authority, effective time, old meaning, and work already in progress |
| Append-oriented evidence with retained witnesses | Storage, privacy, and archival obligations grow | Verified archival preserves required verification and correction while meeting the retention contract |
| Formal reasoning over explicit fragments | Proof coverage can lag real host and adapter behavior | A broader model and checked refinement establish the stronger claim without concealing assumptions |

These are reasons for the specified design and criteria for evaluating alternatives. They are not a reconstructed history of every implementation choice. A revision must be judged against the institutional and economic effects it preserves.

# Terms and notation

## Organizational and authority terms

**Action.** A requested transition under specified authority, with an identity and required effects.

**Actor.** The authenticated party that presents or performs an action. The actor can act for a distinct principal under a valid grant.

**Principal.** The party whose authority supports the action and whose scope constrains delegation.

**Organization.** A legal entity or other recognized organizational arrangement with governed state, duties, and authorized actors.

**Harbor.** A jurisdictional presence that binds an organization to identified registration, licensing, rule, and continuing-duty conditions.

**Jurisdiction.** The legal and institutional domain relevant to an action. Its identifier must remain distinct from a deployment or chain identifier.

**Deployment.** A configured running instance of the relevant service or network, with its own software, keys, rules, and authority context.

**Capability.** A bounded grant of authority. A capability's admissible actions depend on its issuer, scope, constraints, and current status.

**Attenuation.** Derivation of authority that admits a subset of the parent grant's actions.

**Consent.** A decision record under a defined electorate and approval rule. It can be one prerequisite for a later signed instrument or effect.

**Discretion.** A question whose answer requires an identified authorized decision beyond the executable rule fragment.

**Credential.** An issuer's signed claims about a subject, interpreted under a specified verification and trust policy.

## Rules and execution terms

**Admissibility.** Satisfaction of the conditions that permit a particular action at a particular boundary.

**Applicability.** Whether and on what basis a rule or compliance concern applies to the evaluated subject and action.

**Compliance degree.** The evaluation result within the applicable compliance fragment. It remains distinct from applicability and exemption provenance.

**Obstruction.** A structured reason why a proposed composition or transition cannot currently produce the required result.

**Lawpack.** Identified legal source material and its associated interpretation contract.

**Regpack.** Regulatory requirements and executable evaluation material for the relevant scope.

**Licensepack.** Requirements and conditions associated with licensed activities and their authorization.

**Procedurepack.** Executable operation definitions and their declared requirements, steps, and evidence contracts.

**Template pack.** An identified template and associated structural or authority conditions. Its exact contract depends on the owning system.

**Profile.** A named configuration or policy selection. A profile name alone does not identify immutable content.

**Pin.** A binding to the exact content or revision used for an evaluation or operation.

**Lex.** The rule-language contract and its reference semantics, with explicit boundaries between executable fragments and residual obligations.

**Op.** The typed workflow-language contract that represents computations, effects, and host interactions.

**Host.** The runtime boundary that supplies the permitted effects and external interactions for an execution language.

**Smart asset.** An asset representation with authorized lifecycle behavior, state, and evidence. Its autonomy is bounded by its mandate.

**SAVM.** The smart-asset virtual machine that evaluates supported instructions within its configured authority and resource boundaries.

**Continuation.** The retained execution state needed to resume an admitted computation, including pending interactions and the state that gives them meaning.

**Idempotency.** Repeated use of the same admitted request identity returns the committed result without applying its effect again.

**Replay.** Reproduction or retrieval associated with earlier work. The contract must distinguish receipt retrieval from fresh execution.

**Compensation.** A new authorized action that addresses an earlier effect under the operation's recovery policy.

**Outbox.** Durable delivery work recorded with the relevant local state, for later dispatch and acknowledgement.

**Fence.** A condition enforced at an action boundary that prevents an obsolete owner or execution generation from initiating a conflicting action.

## Evidence and storage terms

**Canonical bytes.** The prescribed byte representation of an object under an identified encoding contract.

**Content digest.** A digest of identified canonical content under a specified scheme and domain.

**Commitment.** A cryptographic binding to content. Authenticity, authority, availability, and truth require additional evidence.

**Attestation.** An authority's statement about a defined subject, property, scope, and time.

**Verdict.** The result of evaluating a specified action or claim against identified rules and evidence.

**Proof envelope.** A structured carrier of a claim, its subject and context, supporting references, status, and authentication material.

**Receipt.** A record of the result acknowledged by a particular action boundary. Its meaning follows the recorded action and status.

**Witness.** The data required to check a specified statement under its verification procedure.

**Merkle mountain range.** An append-oriented collection of Merkle trees whose root commitment and proofs follow a defined protocol.

**Content-addressed store.** A store that retrieves objects through content identities. Retrieval still requires availability and integrity checks.

**Projection.** A derived view of authoritative facts for a defined purpose. Its freshness and repair rules remain explicit.

**Epoch.** A period or revision domain used by a specific authority, key, schema, or policy mechanism. Different epoch types are not interchangeable.

**Supersedence.** An explicit relationship through which a later record changes the current interpretation of an earlier record while preserving its history.

**Anchor.** Evidence binding a commitment to another admitted record or authority. An anchor request differs from confirmed external anchoring.

## Claims, disputes, and economic terms

**Claim.** A right to a specified payoff under specified conditions, with economic terms and an institutional basis.

**PDCF.** Probability-weighted discounted cash flow, a valuation representation under identified model assumptions.

**AOT.** An admissible obligation transition that binds admission, obligations, evidence, execution, reserve, settlement, and resulting receipt conditions.

**Position.** A recorded exposure or entitlement in an instrument.

**Custody.** Control and holding of a specified asset under identified account and institutional arrangements.

**Reserve.** Value restricted for a specified obligation or risk condition.

**Clearing.** Determination of obligations and permissible offsets under the admitted clearing and netting contract.

**Settlement.** Application of the economic effects that discharge specified obligations under the settlement contract.

**Finality.** The accepted commitment status of a result under an identified system and policy. Legal recognition and external performance can require further evidence.

**Reliance.** Use of a result by a specified party for an admitted purpose under the governing recognition policy.

**Head of claim.** A distinct claim within a case, with its own subject, relief, and procedural requirements.

**Outcome.** A recorded determination, award, or settlement under an identified procedure and authority.

**Stay.** An admitted restriction on specified action while its governing conditions apply.

**Execution intent.** A request to perform a particular authorized disposition at an identified destination.

**Recovery.** Value or another effect actually obtained and reconciled to the entitled party after the relevant failure or disposition.

**Duty occurrence.** A particular instance of an obligation whose identity persists across delivery, retry, transfer, and partial performance.

**Residual exposure.** The remaining obligation or command exposure after admitted performance and adjustments under the applicable rules.

## Mathematical notation

| Symbol | Meaning |
|---|---|
| $s$, $S$ | State, with scope defined in the chapter |
| $a$, $x$ | An action or input under evaluation |
| $t$, $h$ | Time or block coordinate |
| $H(m)$ | Digest of message $m$ under the stated scheme |
| $x\wedge y$ | Meet where the stated order admits it |
| $x\Rightarrow y$ | Residual under the stated adjunction |
| $A\subseteq B$ | Every member of $A$ is a member of $B$ |
| $\lceil x\rceil$, $\lfloor x\rfloor$ | Integer ceiling and floor |
| $\mathbb{N}$ | Nonnegative integers unless the local definition states otherwise |

Symbols are local to their definitions. A type name is not a claim of wire compatibility across systems. Before implementing a boundary, use its actual schema, encoding, authority, and error contract.

# Standards and reference surfaces {.unnumbered}

The following sources define supporting standards and public reference surfaces. Their inclusion does not certify that every Mass interface conforms to every feature they describe.

The DID syntax, data model, verification relationships, and method requirements follow the vocabulary of [Decentralized Identifiers v1.0](https://www.w3.org/TR/did-1.0/). DID method behavior determines resolution and control semantics.

The issuer, holder, verifier, and credential vocabulary can be compared with the [Verifiable Credentials Data Model v2.0](https://www.w3.org/TR/vc-data-model-2.0/). The actual credential format and securing mechanism must be identified for each implemented boundary.

The [JSON Canonicalization Scheme, RFC 8785](https://www.rfc-editor.org/rfc/rfc8785), provides a reference for canonical JSON. An implementation must specify its actual accepted value domain and canonicalization behavior. Similar terminology does not establish byte-for-byte conformance.

[HotStuff: BFT Consensus in the Lens of Blockchain](https://arxiv.org/abs/1803.05069) provides the consensus research reference. Moxie's extensions, certificate policies, execution bindings, and deployment assumptions require their own verification.

Public language references are [Lex](https://github.com/momentum-sez/lex) and [Op](https://github.com/momentum-sez/op). [Stack](https://github.com/momentum-sez/stack) supplies an operator configuration surface. The gstore descriptions record dated source inspection, with implementation and proof records required for independent verification. The implementation-boundary chapters identify material differences between these reference surfaces, adapters, and executable services.
