---
title: Technical Architecture Brief
subtitle: Mass, Moxie, and Recourse
date: 2026-09-06
status: Proposed integrated design for technical review
classification: Public technical reference
confidential_label: PUBLIC TECHNICAL REFERENCE
header_title: Mass · Moxie · Recourse
title_page: true
toc: true
toc_depth: 1
article_page_breaks: false
hyphenation: false
---

# Technical Architecture Brief

## 1. Purpose and design status

Momentum builds the network. Mass runs companies, institutions, and deployments. Moxie prices and clears claims. Recourse runs dispute resolution and carries outcomes into execution.

This brief specifies how the three systems operate independently and together. It defines ownership, records, admission rules, execution, recovery, and evidence. It also defines the interfaces that connect organizational acts, economic obligations, disputes, and actual performance.

The design uses the research corpus, inspected implementations, and the Mass and Recourse owners' specifications. None of those inputs alone determines the ultimate design. Where inputs disagree, this brief identifies the conflict and proposes a concrete resolution.

Requirements in sections 2–24 describe the proposed target. They do not assert that deployed systems already satisfy them. Section 25 records the inspected implementation boundaries. Section 26 identifies decisions and verification obligations before adoption.

The proposal preserves existing signed bytes and historical verification. New schema names identify proposed contracts. Numeric wire tags, persistence versions, activation heights, institutions, providers, and production keys remain unallocated unless separately selected.

This technical specification presents the proposed design and dated implementation observations. Source descriptions identify evidence captured on 6 September 2026. Current production acceptance requires a separately bound source, binary, configuration, and execution record.

### 1.1 Product responsibilities

Mass maintains organizational identity, ownership, governance, fiscal records, rules, and operating programs. A sovereign Mass deployment controls its own records, keys, admission policies, and disclosures. It exchanges evidence through destination-approved recognition rules.

Moxie maintains claim execution, market state, clearing, settlement obligations, and native consensus finality. It consumes Mass issuance and compliance evidence under its own admission policy. It preserves the distinction between a claim's terms, market value, funded capacity, and completed payment.

Recourse administers disputes, preserves procedural authority, and carries outcomes to their destinations. Its sovereign nodes can use different institutions, rules, and recognition policies. They exchange authenticated records without acquiring authority over one another's databases.

Named licensed providers retain custody, banking, payment, and other regulated functions. Software coordinates their instructions and evidence. An internal ledger entry cannot create a provider license, beneficial title, or completed external transfer.

Treasury and other applications use these three systems. They do not become additional peers in the core stack. Their operating companies, customer obligations, provider accounts, and economic interests remain separately identified.

### 1.2 Design rules

1. Each authoritative object has one current writer domain.
2. Every consequential action has an identified principal and action-specific authority.
3. Every accepted effect binds its exact terms, inputs, governing rules, and resulting record.
4. Every external instruction has durable identity before dispatch.
5. Unknown external performance remains unknown until admissible evidence resolves it.
6. Retries preserve original results, payment attribution, and unfinished obligations.
7. Historical validity and permission for a new action use separate checks.
8. A transfer of live work preserves its complete state and fences the previous writer.
9. Current implementation claims require evidence beyond a type, route name, or manuscript statement.

Source keys beginning with S identify dated implementation and design records. Keys `P01`–`P15` identify the selected research manuscripts. Section 27 defines every key and the evidence each source supplies.

Sources: `S01`–`S05`, `P01`–`P15`.

## 2. Shared objects and meanings

An **actor** is a human, organization, software agent, institution, or service that submits or signs a statement. A **principal** is the party whose authority supports an action. An actor can represent a principal only through an applicable delegation.

A **deployment** is an independently operated system instance with its own trust and storage boundary. A **writer domain** identifies the deployment and authoritative store that can change an object. A **generation** identifies one active custody period for live work.

A **claim** records a right to specified performance under stated conditions. An **obligation** records the corresponding required performance. A **duty** includes performance that can remain unresolved, nonmonetary, conditional, or subject to continuing institutional requirements.

An **occurrence** is an identified event offered as evidence of performance or another contractual condition. Its identity belongs to the event source. A new observation of the occurrence does not create another occurrence.

An **admitted transition** is a state change accepted under the current authority, evidence, and resource rules. A **receipt** records an accepted transition or observation. Its schema states exactly what it proves.

A **continuation** is the retained machine state needed to resume a suspended program. It includes the program's control state and supporting commitments. A case snapshot or workflow status alone cannot restore the suspended computation.

A **custody cut** is the complete, consistent collection of records transferred with live work. A **fence** prevents an old writer from initiating further effects. An **outbox** records instructions that require later dispatch.

### 2.1 Keep these identities separate

| Identity | Meaning | Responsible source |
|---|---|---|
| Organizational identity | Continuing entity or institution | Mass and constituting instruments |
| Instrument identity | Continuing governed agreement | Issuer and governing parties |
| Claim content digest | One exact claim description | Claim admission |
| Obligation identity | Original duty and its continuing history | Originating authoritative ledger |
| Occurrence identity | One external event or performance | Admitted occurrence source |
| Command identity | One requested local transition | Caller and destination namespace |
| Delivery identity | One stable external instruction | Sending outbox and destination |
| Effect identity | One admitted destination effect | Destination ledger |
| Receipt identity | One retained result or observation | Receipt issuer |
| Custody generation | One current owner of live work | Transfer authority and fencing service |

An identifier's syntax establishes none of these authorities. Adapters retain the native identifier and its domain. They do not replace unrelated identifiers with one convenient universal identifier.

### 2.2 Separate state dimensions

Every interface reports the applicable dimensions explicitly:

- **Record state:** prepared, accepted locally, superseded, or rejected.
- **Authority state:** authentic, recognized for the action, expired, revoked, or unknown.
- **Execution state:** undispatched, submitted, outcome unknown, partially performed, or performed.
- **Consensus state:** uncommitted, committed, finalized under a named protocol, or disputed.
- **Provider state:** accepted, processed, settled, returned, reversed, or unknown.
- **Legal state:** asserted, determined, recognized under a named policy, stayed, or superseded.
- **Recovery state:** credited quantity, returned quantity, outstanding quantity, and unresolved evidence.

There is no universal `success` field that implies all dimensions. User interfaces can summarize progress while retaining these independent facts.

Sources: `P05`, `P08`, `P09`, `P14`, `P15`, `S03`, `S04`.

## 3. Topology and state ownership

The network consists of independently governed Mass deployments, Moxie consensus domains, Recourse nodes, and external providers. Each component can operate without another component's database. Integration uses authenticated commands, evidence, and retained receipts.

### 3.1 Deployment units

A Mass deployment contains an API gateway, program host, rule evaluator, domain services, authoritative database, artifact custody, and background workers. Operator configuration selects the jurisdictional packs, trust roots, provider adapters, and permitted network relations.

A Moxie consensus domain contains validators, durable transaction custody, event collection, deterministic execution, market and risk state, and settlement workers. Each validator maintains an independent store. Agreement concerns committed native state and the protocol's declared finality rules.

A Recourse node contains case administration, institutional trust, artifact custody, procedure execution, network exchange, and execution reconciliation. Its application programming interface (API), software development kit (SDK), Model Context Protocol (MCP) interface, and web application share one authorization model.

A provider adapter contains the protocol-specific encoder, authenticated transport, result decoder, and reconciliation logic. It also declares the provider's idempotency and cancellation guarantees. The adapter never invents those guarantees from its own local request log.

### 3.2 Ownership matrix

| Object family | Authoritative writer | Other systems retain |
|---|---|---|
| Entity, consent, ownership, fiscal record | Owning Mass deployment | Scoped evidence and projections |
| Mass program and local execution journal | Owning Mass host | Program commitments and receipts |
| Moxie order, position, native balance, clearing duty | Owning Moxie consensus domain | Finality-bound observations |
| Recourse case, procedure, appointment, outcome | Owning Recourse node and competent signers | Disclosed records and recognition decisions |
| Provider balance, custody, payment, physical delivery | Named provider or competent registry | Authenticated observations and reconciliation |
| Cross-domain transfer | Source and destination, each for its own records | Correlated transfer evidence |

A projection is a derived view. It cannot debit the original ledger or extinguish an original duty. Importing a projection as a new original requires explicit transfer admission and exclusion of concurrent ownership.

### 3.3 Availability and scaling

Scale reads through projections that expose their source revision and lag. Partition writes by authoritative aggregate, with explicit coordination for shared resources. Aggregate boundaries follow conservation and authority requirements.

Scale workers through durable leases and generation fences. A lease identifies the current worker but does not establish external exclusivity by itself. A provider or destination must reject fenced requests when the safety claim depends on that rejection.

Do not require a universal network clock or database transaction. Cross-domain work uses durable preparation, authenticated decisions, acknowledgement, and reconciliation. Pending work can remain pending while unrelated operations progress.

Sources: `P03`, `P06`, `P10`, `P15`, `S02`–`S04`.

## 4. Canonical records, signatures, and time

### 4.1 Common record discipline

Each versioned record declares its schema, issuer domain, object scope, semantic payload, and encoding. The verifier rejects duplicate keys, unknown required semantics, invalid bounds, and noncanonical numeric forms before admission.

Digests identify the algorithm and exact byte representation. Existing SHA-256, BLAKE3, canonical JSON, and native binary encodings retain their meanings. An adapter stores both the original bytes and any derived transport representation.

Signatures bind a purpose-specific domain, schema, issuer, destination or audience, payload digest, authority profile, and validity context. A key authenticates a signature. A separately configured policy determines the signer's permitted actions.

Every record distinguishes immutable content from current admission state. Immutable content includes original terms, source evidence, signatures, and committed results. Current state includes active keys, revocation, stays, remaining resources, and the current custody generation.

### 4.2 Proposed shared envelope

The following field set is a design contract. It does not replace native wire formats:

```text
RecordEnvelope {
  schema, encoding, digest_algorithm,
  network_id, issuer_domain, writer_store,
  object_kind, object_id, object_revision,
  payload_digest, predecessor_digest,
  issued_at, effective_interval,
  authority_profile_id, authority_profile_version,
  audience, purpose, signatures
}
```

`object_revision` orders one authoritative object. `predecessor_digest` commits to its exact prior state where the transition requires continuity. `audience` limits reliance or disclosure. It does not grant access to undisclosed records.

Existing objects can satisfy this contract through explicit mappings. A mapping identifies absent fields and the resulting unsupported claims. It never manufactures an absent signature or finality commitment.

### 4.3 Clock contract

Retain at least four separate times: source occurrence, local receipt, logical execution sample, and durable commit. External settlement and legal effectiveness can add further times. A wall-clock timestamp does not prove global order.

Logical execution uses a durable monotone anchor within its writer domain. The final logical sample follows local allocation and precedes commit. Logical-sample predicates use that sample. Durable-effect and provider-acceptance predicates use their respective boundary evidence.

A failed final logical-time check rolls back the transaction. A later retry can retrieve an earlier committed result under historical access authority. It cannot use an expired execution grant for a new effect.

Select each required validity basis explicitly: logical sample, durable effect, and provider acceptance. A profile can require several bases together. Permission at the logical sample does not establish permission at those later boundaries. Durable commit can finish after the sample's signed interval.

A durable-effect profile requires an admitted mechanism that enforces authority at that boundary. It remains unavailable without that mechanism and its evidence. Database locks serialize authority changes but do not stop wall-clock time.

Complete store rollback can also roll back a local clock. Protection against coherent rollback therefore requires an external freshness anchor or an equivalent independently enforced assumption.

### 4.4 Cryptographic agility

Trust profiles pin algorithms, key roles, principal identities, thresholds, and accepted historical versions. Distinct keys from one principal do not count as independent principals. Rotation retains historical verification material without granting old keys current execution power.

Algorithm migration uses an authenticated transition record. It specifies the old and new verification rules, activation boundary, and historical treatment. Signature aggregation does not remove signer-purpose or quorum checks.

Sources: `P03`, `P06`, `P10`, `P15`, `S03`–`S05`.

## 5. Mass: organizational primitives

Mass provides five native primitives: Entities, Ownership, Fiscal, Identity, and Consent. Domain services own their state transitions. A common program admission path supplies authority, evidence, transactional execution, and receipts.

### 5.1 Entities

An entity record contains its continuing identity, constituting instrument, legal form, governing authority, lifecycle, and harbor set. A harbor records recognition in one jurisdiction. It includes local identifiers, effective dates, obligations, and supporting evidence.

Formation starts from an authorized program and the required constituting evidence. The program creates the organizational record and outstanding registration duties atomically. External registration remains a separate instruction and result.

Onboarding imports a verified existing identity and records unresolved differences. It preserves original instruments and the authority that accepted them. It does not silently create a new legal person.

An entity can maintain one governance and ownership identity across several harbors. Each harbor retains local recognition and continuing duties. Adding a harbor does not imply automatic acceptance by every other jurisdiction.

Lifecycle transitions include preparation, constitution or onboarding, active operation, restriction, dissolution, and retained history. Each transition identifies its competent authority. Dissolution preserves unpaid duties, retention requirements, and access needed for later disputes.

### 5.2 Ownership

Ownership records distinguish registered ownership, beneficial entitlement, control, custody, and encumbrance. A position binds the instrument, owner, quantity, unit, restrictions, and authoritative ledger. Quantity calculations use exact admitted units.

An ownership transition consumes identified available positions and creates identified successor positions. It preserves total quantity unless an authorized issuance, cancellation, or correction explains the change. Pledges reserve rights without silently transferring every ownership interest.

Corporate actions bind the class, record date, eligibility snapshot, governing consent, and allocation rule. Rounding uses a declared deterministic policy. Residual quantities remain attributed rather than disappearing through repeated rounding.

The ownership service emits claim issuance or amendment evidence for Moxie. It does not directly modify a Moxie entitlement ledger. The receiver admits the exact instrument and position mapping.

### 5.3 Fiscal

Fiscal records identify the entity, ledger, account, asset, amount, accounting period, and source obligation. Journals retain debits, credits, reversals, and provider references. An accounting classification cannot prove that cash exists at a provider.

Invoices, payroll, taxes, distributions, and provider instructions become governed programs with explicit obligations. Their ledgers distinguish assessment, authorization, instruction, payment, return, and reconciliation. A return refers to the original attributed payment.

Fiscal rules pin jurisdiction, period, rule version, source facts, and rounding. Corrections append new entries and preserve the earlier assessment. Consolidation retains entity boundaries and intercompany attribution.

Bank and custody adapters expose account ownership, permitted operations, and observation freshness. Mass validates each instruction against the applicable mandate. Reconciliation compares provider evidence with the local obligation and allocation history.

### 5.4 Identity

Identity stores subjects, controllers, credentials, verified attributes, affiliations, and authentication methods. Each verified attribute identifies its issuer, evidence, scope, validity, and revocation source. Self-declared attributes remain distinguishable.

Delegation names the principal, delegate, permitted actions, object scope, limits, and validity. Attenuation can reduce authority but cannot create a missing permission. Revocation affects future admission according to the governing policy.

Recovery of an identity or signing key requires a separate authority procedure. It preserves the replaced key's historical meaning. An account administrator cannot acquire tribunal, corporate, or provider authority through password recovery.

### 5.5 Consent

Consent records the proposed act, eligible voters, voting rules, notice, votes, signatures, and effective result. The proposal digest fixes what participants approved. A changed act requires new approval unless an existing delegation covers the change.

Approval, document signing, external submission, and business effect are separate transitions. A provider callback identifies the exact signing submission and completed signers. The service checks those signers against the persisted designated identities.

The target callback contract authenticates the body, event identity, and freshness metadata together. It persists a retryable inbox before acknowledgement. It records downstream effects separately from receipt of the callback.

Cancellation creates durable obligations for provider archive or withdrawal when required. A completed local cancellation does not prove that the external submission disappeared. Reconciliation continues until the provider result resolves that obligation.

Sources: `P01`, `P03`, `S01`, `S02`. Source inspection identifies narrower callback behavior in section 25.

## 6. Mass: rules and compliance composition

### 6.1 Rule packages

A lawpack contains source instruments, structured rules, interpretation authority, jurisdiction, effective intervals, and executable commitments. Related packs define licenses, procedures, obligations, adapters, and application templates. A deployment lockfile pins the complete selected dependency set.

Rule publication preserves original source bytes and dated provenance. Rule adoption records the competent authority and deployment scope. Source publication and local adoption require separate acts.

A rule can require a human determination where its application needs discretion. The request names the question, evidence, permitted decision maker, and answer schema. The program resumes only with an admissible answer for that exact request.

### 6.2 Lex

Lex is the typed language for jurisdictional rules and their proof obligations. Its checker establishes the properties of the admitted language fragment. The runtime must declare which fragment, evaluator, and host profile it implements.

Rule certificates bind program or rule bytes, assumptions, scope, evidence, and checker identity. A certificate for one expression cannot discharge another expression's obligation. A checker result does not establish the truth of an external legal instrument.

The proposed production path uses deterministic evaluation over pinned inputs. Unresolved facts or discretion produce typed requests. Unsupported expressions produce explicit refusal. They do not become default compliance.

### 6.3 Compliance records

The compliance state covers 23 domains. It retains applicability separately from the grade of an applicable requirement. It also retains the decision about the particular requested act.

Each cell carries its jurisdiction, regulator, legal source, tradition, domain, rule, obligation, evidence, and effective interval. The witness map preserves these coordinates through composition. A single undifferentiated witness cannot replace the map.

Applicable grades combine through the declared restrictive operator. The result preserves every applicable restriction under the model's assumptions. Distinct authorities can validly report applicable, exempt, or not applicable findings for different owned requirements. Preserve those coordinates. Conflicting findings for the same owned requirement require resolution. Unsupported projection into a simpler model produces an explicit obstruction.

The interface returns one of three typed results:

```text
CompositionResult =
  Composed { cells, witness_map, retained_obligations, policy_digest }
  | Obstructed { coordinates, conflicting_sources, required_decision }
  | Pending { missing_inputs, scoped_requests, continuation_binding }
```

`Pending` records absent evidence. `Obstructed` records an incompatibility that more data alone may not resolve. Neither result permits a consequential effect that requires an admissible composed state.

### 6.4 Recognition and current use

Recognition maps declare which source evidence the destination accepts, for what purpose, and with which limitations. They can preserve or reduce an accepted grade. They retain local questions and obligations that the destination reserves.

Admission checks current source revisions, keys, revocation, purpose, and validity. It also checks absence predicates that influenced evaluation. A concurrently inserted restriction must invalidate an admission based on its earlier absence.

The storage contract therefore protects both existing rows and predicate generations. Every relevant writer advances the same generation records. A writer outside that contract makes the affected admission profile unavailable.

Historical verification reconstructs the rules and facts used for a past decision. It does not rerun that decision under today's rules and overwrite its earlier basis. A new use receives a new current-authority decision.

Sources: `P02`, `P03`, `P04`, `P06`, `S02`, `S05`.

## 7. Mass: authored programs and Op execution

### 7.1 Program admission

Op is the public instruction language for governed operations. A Mass program binds authored intent to Op bytes, Lex obligations, object scope, and execution policy. The author signs the canonical program representation.

The logical entry point is `propose(authority, program) -> result`. Resource APIs can lower requests into that path. They do not acquire a separate permission to bypass its checks.

Preparation validates structure and produces a proposed program. Simulation evaluates a declared snapshot and reports projected effects. Neither operation changes authoritative state or constitutes the author's signature.

A submitted program includes its exact code, interpreter profile, input commitments, operation multiplicity, resource limits, and replay policy. One-shot and repeatable programs require separate admission rules. A new command identifier cannot turn one-shot intent into unlimited execution authority.

The admission result is `Rejected`, `Pending`, or `Committed`. Rejection identifies the violated contract. Pending identifies missing evidence or external performance. Committed returns the retained effect and its exact receipt.

### 7.2 Typed execution and host boundary

The runtime preserves linear resources, fixed targets, required screening, and action-specific authority. Each external request has one permitted consumer. Partial performance changes the retained residual instead of restarting the original payment amount.

The host profile defines primitive calls, units, storage, callbacks, gas, and the interpretation of each result. The current Op integer dispatch quantity remains distinct from monetary fixed-point values and duty quantities. Adapters require exact conversion and divisibility.

A host result does not automatically discharge an obligation. It must identify the observed occurrence and the admitted attribution. A command can close while an underlying debt remains outstanding.

Model output can propose text, classify evidence, or prepare a program. It cannot manufacture a human signature, provider occurrence, or rule certificate. The host treats external material as evidence with declared trust.

### 7.3 Durable continuation contract

The proposed `mass.checked-continuation.v1` record contains:

```text
CheckedContinuation {
  original_host, original_instance, original_nonce,
  program_digest, interpreter_profile_digest,
  continuation_schema, admitted_decoder_digest,
  instruction_position, control_stack, environments,
  frame_stack, linear_resources, logical_work,
  request_ordinal, pending_request,
  signed_history_head, journal_head, effect_head,
  receipt_head, obligation_namespace_head,
  custody_generation, authenticated_custody_digest
}
```

The record commits to the actual suspended computation. Recovery restores that checked state directly. Reexecuting from the source root can repeat effects or lose the exact suspended environment.

The receiving host verifies the decoder, profile, integrity, and custody authorization. A successful serialization round trip proves representation consistency only. Reachability from admitted execution requires authenticated history or another explicit verification mechanism.

Consumption of a reply atomically updates the continuation, resource state, effect journal, and receipt. Invalid replies consume nothing. An exact repeated reply returns its original receipt without advancing the ordinal again.

### 7.4 Completion and returned credit

Distinguish `ReturnCredit` from `AdmittedDisposition`. ReturnCredit records an authenticated provider return and its original payment attribution. AdmittedDisposition determines how that return changes the authoritative obligations and funding permissions.

The disposition binds the original payment, return occurrence, exact quantity portions, account, asset, provider epoch, and governing authorities. It retains recipient-debit evidence where the policy requires it. Duplicate aliases resolve to one occurrence.

A cross-store disposition enters `ReopenPending` until the original ledger commits the reopening. Returned cash remains encumbered during that state. The host arms replacement funding only after it verifies the destination receipt and required current admissions.

Reopening never regenerates the original consumed cash interval. A replacement payment uses fresh admitted credit with its own attribution. Historical payment and return records remain immutable.

Sources: `P03`, `P05`, `P09`, `P15`, `S05`.

## 8. Mass: authoritative storage and atomic admission

### 8.1 Transaction boundary

The proposed PostgreSQL allocation profile applies one local allocation and its final proof in one database transaction. It includes the actual authoritative duty rows. A projection or precomputed allocation plan cannot substitute for those rows.

The transaction covers command identity, admission records, allocations, incurred duties, membership, result, continuation, audit, clock anchor, and required outbox records. It commits before the API exposes success.

External payment remains outside that transaction. The transaction can create a provider instruction and reserve its resources. It cannot guarantee an external effect without the provider's own acceptance and performance evidence.

### 8.2 Detached execution grant

The proposed `mass.execution-grant.v1` supplements an unchanged signed program envelope. It binds the program to one exact allocation and current authority context. It does not alter existing `mass-program-envelope-v0` signing bytes.

```text
ExecutionGrant {
  schema, approval_domain, owner_store, ledger_id,
  command_namespace, command_id, intent_multiplicity,
  program_digest, allocation_effect_digest,
  current_use_body_digest, catalog_digest,
  read_footprint_digest, expected_roots,
  obligation_template_digest, clock_domain,
  validity_requirements, interval_convention,
  enforcement_profile, valid_from, valid_until,
  required_participants, approvals
}
```

Every participant signs the same canonical body. Policy determines the required principal, role, and scope tuples. The verifier requires exact tuple coverage and current keys. An independence threshold counts distinct admitted principals, even when one principal holds several required roles.

Validity requirements can combine logical sample, durable effect, and provider acceptance predicates for each effect. Each predicate imposes an independent requirement. A profile must enforce every selected predicate at its named boundary.

The grant binds a `BoundAllocationEffectCore` containing the intended economic effect. That core excludes the final clock sample and resulting receipt. The committed `ExecutedEffectCore` adds the observed sample, actual state roots, and grant digest. This separation prevents circular digest definitions.

The semantic verifier checks more than digest equality. It proves that the allocation implements the admitted program's recipients, units, order, effects, and multiplicity. An unrelated valid program cannot authorize a separately chosen allocation.

### 8.3 Required execution sequence

1. Authenticate access to the requested historical result.
2. Look up the exact committed command and canonical request.
3. Return matching stored result and proof bytes without new execution.
4. Reject changed bytes under a committed command identity.
5. Begin the fresh-command transaction and create or lock its durable command fence.
6. Lock the ledger, catalog, predicate generations, revisions, authority records, and clock anchor in deterministic order.
7. Recheck replay, then re-read every admission input through the same transaction.
8. Validate the program, grant, semantic mapping, current permissions, and available resources.
9. Apply the actual ordered allocation to authoritative local rows.
10. Sample the final logical clock. Recheck the complete local admission predicate over the protected inputs and resulting allocation.
11. Derive the act, incurred duties, membership, result, continuation, and final proof.
12. Persist all required records and commit before returning success.

The proof producer must finish inside this boundary. If it needs later consensus or a remote signer, this profile is unavailable. Such work requires a separately declared pending-proof profile.

Proof construction failure, authority failure, or expiry rolls back the allocation. A crash after commit but before response returns the original stored result after restart. It does not create a new act or proof.

### 8.4 Predicate protection

The current-use catalog declares each predicate, its typed reads, and all writers that can affect it. Empty namespaces have durable generation sentinels before admission. Inserts, updates, deletes, imports, corrections, and migrations follow the same locking contract.

Predicates identify whether they inspect predecessor state or allocated state. The verifier repeats their evaluation at the appropriate point. Mixed database connections cannot substitute for one locked snapshot.

Historical retrieval requires current read permission, independently of execution permission. Ordinary revocation can stop future effects while preserving access to prior receipts. A retroactive compromise finding can affect current reliance without altering authentic stored bytes.

### 8.5 Event ownership and projections

The target event record commits atomically with the domain mutation and outbox. Deterministic projections expose their applied event cursor and source revision. Rebuilding a projection preserves original event identity and produces no external dispatch.

Existing post-commit event fanout remains a separate implementation boundary. It cannot establish that every domain state is already a complete event projection. Migration requires a verified genesis snapshot, event coverage, and replay equivalence.

Sources: `P03`, `P06`, `P09`, `P15`, `S02`, `S05`.

## 9. Mass: operating services and agent applications

### 9.1 Domain service contract

Each service exposes typed commands, queries, events, and its authoritative aggregate. Its contract declares required authority, rule inputs, resource effects, idempotency scope, and external obligations. Service ownership follows the native primitive architecture.

Sector modules cover formation, governance, ownership, employment, fiscal reporting, permits, licensing, trade, and asset operations. A module composes existing primitives and governed programs. It does not create an unreviewed path to provider accounts or another deployment's state.

Documents bind their template, data snapshot, program, and signing workflow. The artifact service preserves exact executed bytes. A later corrected document receives a new identity and an explicit relation to its predecessor.

Notifications and webhooks use durable outboxes. They include event identity, resource, revision, destination, and payload commitment. Consumers deduplicate and maintain cursors. A failed notification does not roll back an already committed business fact.

### 9.2 Agents and automation

An installed agent has a publisher, package digest, requested capabilities, permitted data, resource budget, and accountable principal. Installation authorizes only the admitted capability set. Runtime delegation can narrow that set further.

Schedulers create durable trigger records from timers, events, or explicit requests. Each trigger binds the rule version, input revision, and command namespace. Concurrent workers cannot execute the same trigger as separate economic instructions.

Plans preserve assumptions, alternative actions, resource limits, and unresolved questions. Execution rechecks current admission instead of trusting an earlier plan. Resource budgeting spans concurrent commands that share one obligation or funding pool.

Observations retain source, time, confidence or verification status, and permitted uses. Learning and telemetry cannot rewrite signed historical decisions. A promoted model or policy needs a new admitted version and bounded evaluation evidence.

Agent shutdown preserves pending requests, outbox instructions, reservations, and continuations. Revoked agents can lose future action rights while the institution retains the evidence needed for recovery.

### 9.3 Client surfaces

The API, SDK, Model Context Protocol tools, and user interface project the same capabilities and errors. A capability response identifies implemented modules and their selected profiles. Unconfigured operations remain unavailable.

The organization workspace shows current records, required decisions, pending provider performance, and recoverable failures. The regulator console shows records within its mandate. Neither receives cross-entity or cross-jurisdiction access through an interface role alone.

The application store publishes package provenance, declared effects, pricing, supported deployments, and required capabilities. Installation and fee acceptance are explicit records. A listing creates neither a regulatory license nor a provider mandate.

### 9.4 Durable application records

The package manifest binds publisher, package bytes, dependency digests, requested capabilities, declared effects, and pricing. Publication creates a durable package record. A lost response returns that same record on exact retry.

An installation grant binds organization, package version, principal, permitted operations, data scope, budgets, expiry, and governing approval. Upgrade creates a new admitted grant. Existing jobs retain their original package and grant history while they drain or transfer.

A `WorkOrder` binds the authorized objective, immutable inputs, plan, permitted actions, budget, and unresolved assumptions. External documents remain evidence. They cannot change the work order's permissions or signing principal.

A `ScheduledFiring` binds schedule identity, rule revision, occurrence coordinate, job identity, and command key. Cancellation and dispatch contend on that same durable record. A lost commit response cannot create another firing.

A co-sign request binds exact program bytes, target, current intent nonce, required principal-role tuples, threshold, and deadline. Signature completion does not establish current execution authority. Admission rechecks quorum, revocation, budget, and time at the selected boundary.

A telemetry record binds event identity, source, payload commitment, and durable acknowledgement. Conflicting bytes under one identity enter an explicit conflict record. Learning proposals retain evaluation evidence and require separate promotion authority before operational use.

### 9.5 Provider callbacks and executed documents

Separate provider occurrence, transport delivery, and callback effect. The occurrence belongs to the provider's admitted event namespace. A changed delivery timestamp or signature creates no additional occurrence.

Freeze the effect plan at occurrence admission. Each effect identity is `(occurrence, effect_plan_digest, ordinal)`. Expected subject revisions remain admission conditions. Revalidation after unrelated state changes preserves that effect identity.

Consent and templating share one `SigningSubmission` for the exact document, signer set, and provider submission. Signature completion and executed-artifact custody remain separate states. A dependent step advances only after its required custody check.

A durable custody job retries retrieval of the same executed bytes. It never regenerates a signed document or starts a replacement signing submission. The receipt binds object version, digest, storage profile, and released waiting step.

Sources: `P03`, `P05`, `P06`, `S01`, `S02`.

## 10. Mass: sovereign deployments and corridors

### 10.1 Deployment manifest

The target manifest identifies the sovereign operator, deployment, jurisdiction, primary legal tradition, recognized authorities, packs, keys, and residency rules. It also declares provider adapters, storage ownership, recovery authorities, and permitted peer relations.

Boot checks reject missing mandatory authority and tradition configuration. They verify pack digests and schema compatibility. A source type with a default value does not establish that this boot contract exists.

Operational sovereignty means control over the deployment's own normative and technical domain. It does not establish state recognition or immunity. External legal claims retain their own competent authorities and procedures.

### 10.2 Directional recognition

A corridor is a governed relation between deployments. Each direction selects its accepted evidence, reserved questions, fees, limits, and dispute routes. Treat each direction as a separate admission policy.

The corridor definition commits to participants, instruments, legal bases, trust anchors, rule maps, data permissions, settlement modes, and termination duties. Participant agreements accept exact definition bytes and record any permitted addenda.

Activation requires the specified current approvals. Technical peer enrollment authenticates keys and endpoints. It does not itself activate legal recognition or payment authority.

An accession instrument can reduce repeated negotiation through common terms and individual filings. The resulting relations still depend on effective notice, objections, exceptions, and the stated institutional assumptions. Software cannot assume universal reciprocal willingness.

### 10.3 Cross-domain operation

The initiating deployment prepares the exact operation, resource commitment, local decision, and required disclosures. The receiving deployment verifies those records under its own current policy. Each records its own decision and reservation.

Commit evidence binds the operation, both domains, nonce, epoch, resource commitments, and effective fences. Durable acknowledgement distinguishes local commit from remote commit. A best-effort notification cannot prove a joint result.

A timeout alone does not prove that a remote participant failed to commit. The target recovery protocol retains locks until authenticated decisions or effective fencing exclude conflicting remote performance. It never invents atomic external settlement from a local state machine.

Settlement instructions then pass to the appropriate licensed providers. Their acceptance, finality, return, and reconciliation remain distinct. A common final exchange is available only when the governing instruments and execution arrangements support it.

### 10.4 Data sovereignty

Classify payloads by category, jurisdiction, purpose, audience, and retention policy. Apply egress checks at every export path, including logs, telemetry, backups, model prompts, and support tooling. A standalone policy type cannot prove complete interception.

Metadata exchange precedes confidential record disclosure. Disclosure names exact content and recipient. Recognition of evidence does not authorize unrestricted replication of the underlying personal or commercial data.

Sources: `P01`, `P02`, `P06`, `P07`, `S02`.

## 11. Moxie: claims and product construction

### 11.1 Claim definition

A claim binds issuer, governed instrument, entitlement, payoff program, settlement asset, legal profile, and resolution mode. Its content digest identifies one exact description. The continuing instrument identity survives through explicitly related amendments.

The template pack defines a governed product family and its permitted structure. A typed claim graph records parties, rights, duties, conditions, and dependencies. Compilation validates that graph against the selected template.

The compiled transition retains both financial meaning and institutional provenance. Product families use generic execution rules where their semantics permit. A new product still requires eligible authority, custody, funding, and settlement support.

### 11.2 Payoff evaluation

The evaluator uses deterministic, bounded operations with exact admitted arithmetic. It checks overflow, scale, asset, sign, and rounding rules. Missing evidence produces a pending result rather than an invented value.

Historical references point to declared earlier observations. Certified same-event extensions require an explicit dependency order and supporting certificate. Cycles obstruct same-event admission. Missing admissible observations suspend evaluation with retained dependencies and continuation state.

Resolution records bind the input set, program, observation coordinates, result, and evidence. Path resolution can publish successive values without creating new payment entitlement each time. Terminal resolution fixes the value used by separately tracked holder redemptions.

A probability-weighted discounted cash-flow model supplies valuation inputs. It declares its scenario law, information set, discount curve, and payment interpretation. Market value remains separate from contractual amount and cash held in custody.

Historical reductions first select all scheduled members in the declared window. They then retrieve each member's original type, resolution identity, and evidence. Missing members neither change the divisor nor supply zero.

Compilation extracts complete data and control dependencies before optimization. It retains witnesses from zero-weight expressions and inactive branches when the source contract requires them. An auxiliary producer carries value evidence without acquiring a payment entitlement.

A continuation binds its fixed program, context, lineage revision, completed instructions, pending inputs, cached typed intervals, evidence, and cumulative counters. Resume uses the current shared ledger. It cannot restore a stale ledger over an intervening payment.

### 11.3 Issuance and reliance

Mass provides issuance authority, claim terms, compliance evidence, and their governed revisions. Moxie checks their authenticity, current eligibility, revocation, and intended use. It does not independently replace the originating legal analysis with an unsupported local summary.

The admitted reliance record binds the Mass source, claim, product profile, permitted parties, purposes, and finality assumptions. A later use checks its current admission conditions. Historical verification retains the original source and profile.

A pooled claim also requires an entitlement ledger. The pool operator's control does not establish beneficial ownership of every position. Transfer and redemption consume the exact admitted entitlement.

### 11.4 Claim lifecycle

The target lifecycle separates authored, admitted, funded, tradeable, restricted, resolved, redeemable, and economically completed states. Restrictions can coexist with outstanding settlement. Completion requires a retained accounting of every applicable obligation and residual.

An amendment preserves the original claim's history and creates a governed successor description. It never rewrites a finalized payoff or payment. Corrections produce directed adjustment obligations with their own authority and funding.

Sources: `P08`, `P09`, `P14`, `S01`, `S02`, `S05`.

## 12. Moxie: consensus, custody, and emergency control

### 12.1 Consensus scope

Byzantine fault tolerance (BFT) names the profile's declared tolerance of arbitrary validator faults. Validators agree on the complete native execution state. That state includes admitted event evidence, market effects, obligations, resources, pending instructions, and receipts. External uncertainty remains represented inside committed state.

The consensus profile fixes committee membership, voting power, thresholds, cryptographic suites, fault assumptions, and activation rules. Verification uses the exact committee at the relevant coordinates. A later committee cannot silently replace the historical signer set.

A quorum certificate proves the statement and threshold defined by its profile. It does not establish provider performance, legal recognition, or truth beyond its signed statement. Native finality proofs retain those limits.

### 12.2 Parent-fixed encrypted order

The proposed Event-Collect design commits the encrypted transaction order in an authenticated parent block. Decryption reveals instructions whose positions are already fixed. Event evidence can arrive while that reveal proceeds.

Durable custody records preserve the encrypted item, complete signed envelope, and availability obligations. Custody identity, materialized envelope identity, and proposal-local conflict keys remain separate. The encrypted inner identity remains unknown until reveal.

Certification alone does not establish readiness for execution. Readiness requires the selected availability, reveal, and admission conditions. A proposal conflict can defer inclusion while the item remains durably ready.

Decryption duties bind the item, committee epoch, share identity, recipient, and applicable deadline. Missing responses produce the protocol's explicit pending or timeout result. They do not permit an alternative plaintext or reordered execution.

### 12.3 Closed event collections

An event collection binds its query, authorized sources, response commitments, completeness rule, and closing evidence. The protocol validates the collection as a whole. It distinguishes adverse evidence from absent evidence.

Execution reads the agreed collection and deterministic parent state. It produces the same resulting state or explicit pending result at every conforming validator. Replacing event evidence after execution requires a later governed transition.

Ledger mutation commits atomically with duties, resource changes, and the durable external plan. External workers then dispatch that plan under its retained identities. Consensus can progress while external actions remain incomplete.

The paper's five-round lower bound concerns a specified protocol class. The parent-fixed construction lies outside that class. The bound does not establish a universal minimum for every implementation or deployed network.

### 12.4 Signed pause and resume

The target emergency record binds chain, authority epoch, authority root, action scope, pause identity, effective position, and signatures. A resume names the exact pause it resolves. Current authority and replay checks apply at native execution.

The restricted-operation phase (Phase-2) limits its exact governed action set. The continuity phase (Phase-3) permits only the settlement and recovery actions declared by the active emergency policy. Every phase retains its required conservation, authority, and evidence checks.

Pause state belongs in canonical durable state and its commitment. Restart, snapshot restore, and state synchronization preserve the same active pause and authority generation. An API acknowledgement without enforced state behavior supplies no acceptance evidence.

Two conflicting resumes, a stale authority root, or a resume for another pause must refuse. Ordinary transaction replay cannot reapply a superseded emergency act. Authorized rotation retains the previous record's historical verification.

### 12.5 Adoption and recovery

A new wire format requires an explicit activation method. Fresh genesis and authenticated checkpoint migration are distinct options. The deployment record selects one and binds exact schema, source, binary, committee, and state commitments.

Historical root functions retain their original meaning. Restore rejects unsupported active-state versions. A migration verifies all retained balances, obligations, custody, replay records, pending instructions, and emergency state before enabling writers.

Sources: `P10`, `P09`, `P15`, `S02`, `S05`. Emergency implementation acceptance remains separately owned and unestablished by this brief.

## 13. Moxie: markets, pricing, and derivatives

### 13.1 Market policy

A market policy binds the instrument, payoff, assets, units, price ticks, mechanism, fees, authority, oracle, risk model, and legal clearing set. Activation requires compatible issuance, custody, funding, and settlement records. A compatibility refusal preserves the active policy and economic state. Admission, trading restrictions, and venue stage remain separate dimensions.

Pricing snapshots and risk snapshots remain separate. Pricing identifies the valuation law, probabilities, curve, observations, and numerical error. Risk evaluates physical loss, liquidation impact, funding deadlines, and collateral deterioration.

A market-implied probability can inform valuation. Using it as a physical forecast or margin offset requires separate calibration. The system records that additional assumption and its evidence.

### 13.2 Order books and automated market makers

A central limit order book matches admitted orders under deterministic price-time priority. An order binds account, market, side, quantity, price, expiry, route, fee ceiling, and current authority. It reserves the resources required for its possible fills.

An order reports one state: reserved, resting, partially filled, filled, canceled, or expired. The proposed cancel-and-replace profile gives a successful replacement fresh priority. Failed replacement preserves the original order, reservation, and priority. Cancellation releases only the unfilled reservation. Protocol fees follow their separately admitted contract.

An automated market maker maintains real reserves, liquidity-provider entitlements, encumbrances, fee balances, and a selected curve. A swap fixes exact input or output, slippage limit, maximum fee, and expiry. It checks all resulting balances before committing.

A local multi-leg fill commits its balance, reserve, fee, position, and capital effects together. If that profile cannot support atomic completion, it advertises a different staged contract. A displayed quote is not reserved liquidity.

Routing compares quantity-dependent cost, including fees, impact, funding, and settlement. Each route consumes reserved physical inventory. Ordinary and liquidation routes share that capacity across different certificate keys and accounts. Retain consumed-key tombstones and inventory generations after release. A new key cannot reserve already encumbered inventory.

### 13.3 Batch clearing

A clearing batch fixes its input root, objective, constraints, rounding, deterministic tie-break, and work limit. Its certificate includes a solution, feasibility checks, and any claimed approximation or optimality bound. It also identifies funded settlement deltas.

Work exhaustion returns `Deferred`. An infeasibility claim requires a verified infeasibility certificate. Deferred computation retains its escrow and intermediate state. Timeout cancellation releases exact unused reservations once. Terminal resolution accounts for pending batches before releasing pool assets or holder entitlements.

Liquidity-provider withdrawal first calculates net entitlement after senior liabilities. It then checks available inventory after disjoint backing and depth reservations. Count each liability once in each applicable calculation. Insufficient availability prevents both share burn and transfer. A valuation increase creates no cash.

### 13.4 Prediction-linked pricing

Prediction-linked pools declare how a forecast changes the price rule and reserves. The selected mechanism specifies signal bounds, fee treatment, reserve floors, and the aggregate trading budget. A bounded signal response alone does not establish truthful reporting.

Two proposed profiles remain distinct. A reserve-reset profile changes the pricing parameter under a declared reserve rule. A funded-control profile makes an explicit sponsor transfer when the parameter changes.

The funded profile shares sponsor cash reservations across pools. Each reservation binds the exact admissible pool revision and inventory. Commit both cash entries, the control, reservation consumption, and replay result together. A stale or unfunded control change refuses. Its conservation proof must include actual fees, withdrawals, deposits, and external flows.

Budgets apply across all accounts using the pool, partial fills, and repeated signal updates. Each capacity record binds one pool and horizon. The incentive analysis includes outside trading exposure and sponsor interests. Order splitting cannot reset a pool-wide extraction limit.

### 13.5 Joint-event inference

An inference snapshot binds event definitions, aligned observations, quote provenance, sampling assumptions, drift evidence, confidence allocation, and numerical bounds. It also names the inferred quantity.

Joint-event prices can identify effective pair dependence under stated conditions. They do not generally identify every direct interaction in a larger network. Unsupported identification claims return an explicit nonidentified result.

Zero cells can produce boundary estimates with infinite endpoints. A globally infeasible probability specification requires a separate refusal. Preserve nonidentification and full-law drift bounds. Window selection follows a declared catalog and simultaneous confidence budget. Approximate numerical evaluation reports an enclosure or error bound rather than unsupported exactness.

Risk offsets require additional physical calibration and stress evidence. A fitted pricing model does not independently authorize lower collateral or larger positions.

### 13.6 Perpetual positions and funding

A position generation binds account, market, signed size, entry price, settlement asset, margin, funding index, accrued funding, realized claims, and lifecycle. One active generation can coexist with retained unsettled generations.

Before changing size or side, crystallize funding at the old size. Add that amount to durable accrued funding. Reset the entry index in the same transition.

Funding settlement reduces the accrued amount only through an actual committed settlement. Insufficient margin leaves a residual. Positive accrued funding denotes an amount owed by the position under the proposed convention.

A zero-size generation persists while margin, funding, or another claim remains. Reopening creates a new generation. Account equity includes all unsettled generations, so changing an active pointer cannot hide debt or credit.

The same rules apply to reductions, closes, liquidations, and automatic deleveraging. A profit haircut reduces an eligible claim. It does not independently debit posted margin or supply cash.

Sources: `P08`, `P11`, `P12`, `P13`, `S02`, `S05`, `S06`.

## 14. Moxie: clearing, collateral, and liquidity

### 14.1 Ordered obligation ledger

The clearing ledger retains each original duty, its authority, terms, occurrence basis, and ordered quantity portions. A representation can aggregate adjacent portions without changing their order. Split, merge, or migration preserves original economic identity.

An allocation binds the payment occurrence, source account, asset, quantity, destination duties, and excess partition. One shared record limits total attribution across claims. Repeated evidence or aliases cannot create additional supported payment.

The proposed obligation command has three typed branches: Duty, Physical, and Authority. Each branch supplies its own admissibility rules and effect semantics. All branches use the same command identity, serialization, conservation, and receipt discipline.

An unresolved payoff remains a continuing duty with its retained program and evidence. It is not converted into zero liability. A later resolution creates the payable amount under the original identity and history.

### 14.2 Collateral and margin

A collateral lot records asset, owner, custodian, funded quantity, senior encumbrances, reservations, haircut, conversion route, and availability deadline. Eligibility and valuation remain separate from actual custody and liquid availability.

The risk snapshot covers the complete portfolio and admitted legal netting set. It includes liquidity-provider exposure, unsettled funding, dependence stress, depegs, provider failure, and liquidation depth. A pairwise discount cannot replace that aggregate calculation.

The margin requirement is the maximum of independently admitted floors, stress, and applicable model requirements. The exact components belong to the versioned policy. A margin call remains a receivable until actual payment supports it.

### 14.3 Persistent model health

Model health records one state: uninitialized, healthy, or degraded. It retains the previous valid requirement, model and evidence identities, portfolio root, numerical bounds, and recovery history.

A degraded account retains the previous committed requirement and the current independent floor, stress, and physical-risk requirements. Each update takes their maximum. The retained requirement therefore cannot fall during degradation.

The account refuses increased risk and withdrawals. Authorized settlement and exposure reduction remain subject to conservation and current authority.

An uninitialized account cannot assume a zero historical requirement. Initialization requires a complete admitted evaluation of the current portfolio. Missing historical information remains identified.

A fresh healthy evaluation does not establish an unknown prior collateral requirement. Legacy collateral remains unavailable for release until the risk owner reconstructs its required history. Current risk initialization and legacy release eligibility are separate states.

Recovery requires complete recomputation, independent checks, and governing risk approval. One successful model call cannot clear the degraded state. The actual withdrawal route must enforce the same policy as the margin service.

### 14.4 Liquidation and default

Liquidation fixes the affected positions, evidence snapshot, permitted routes, and executable depth. It records actual proceeds, fees, remaining margin, and residual claims. Estimates do not count as realized liquidation proceeds.

The proposed waterfall applies available loss-bearing collateral, dedicated clearing capital, eligible funded insurance, capped survivor contributions, and eligible profit-claim reductions. Any remaining deficit stays explicit. This economic ordering requires separate governing selection.

Simultaneous defaults use one snapshot and proceed level by level. The clearing ledger consumes each funded reserve once. Deterministic allocation preserves seniority, caps, and existing reservations.

Automatic deleveraging reduces eligible unpaid profit claims. It supplies no immediate cash. A zero accounting deficit does not establish payment by a provider or receipt by a beneficiary.

Collateral whose value depends on the same liquidity supporting clearing requires explicit coupled stress analysis. Forced withdrawals can damage that support. External collateral and withdrawal restrictions address specified mechanisms but do not eliminate all price or position losses.

### 14.5 Funding and foreign exchange

A funding policy binds one feasible currency vector, deadlines, contingent actions, provider dependencies, quotes, inventory, expiry, and return rules. It reserves source cash and destination inventory under that same policy.

Componentwise minima from different feasible policies do not define one executable plan. Funding admission selects and retains a complete policy. Competing commands share its resource reservations.

Local Moxie inventory effects commit in the native state batch. Mass supplies authenticated requests and provider observations. A PostgreSQL observation cannot commit Moxie inventory.

External foreign exchange uses durable preparation, truthful performance observations, and recovery. A provider timeout preserves the reservation and uncertainty. Returned payments retain original attribution and require fresh replacement funding.

Sources: `P05`, `P08`, `P09`, `P12`, `P15`, `S05`, `S06`.

## 15. Moxie: physical assets and allocated title

### 15.1 Physical title records

Allocated title connects ownership to identified physical property. The record binds the governing instrument, original right, custodian, location, asset specification, quantity, unit, and restrictions. Physical custody and legal effect require the stated external evidence.

The physical ledger distinguishes owned quantity, accepted delivery, reserved quantity, shortage, lien, sale, unpaid proceeds, and continuing delivery duties. Lending or pledging property records the resulting rights and obligations explicitly.

A sale that transfers title while payment remains incomplete retains the unpaid proceeds obligation. A delivery shortage preserves the missing quantity. Software representation changes do not erase either duty.

### 15.2 Physical producer contract

The proposed physical producer binds original issuance, contract, occurrence, cohort, position lot, local schedule, accepted-value source, and earned leg. Each cohort receives a fresh lot. All cohorts consume one original quantity allowance.

Acceptance checks role evidence, disjoint occurrence intervals, exact unit conversion, remaining original quantity, and immutable price. It derives the earned amount and requires the admitted payoff evaluator to agree.

The producer identity retains issuance, position lot, local height, and leg. Equal local heights in different cohorts remain distinct through their lots. A fresh lot does not authorize additional original quantity.

Capacity exhaustion refuses without consuming the physical interval or creating a due. A separately admitted successor can accept the next interval if original capacity remains. Corrections preserve previously consumed physical quantity.

### 15.3 Exchange and correction

A common final exchange requires governing instruments and execution arrangements that couple title and payment. Without those premises, the system records each completed leg and the outstanding delivery or recovery duty.

Late corrections refer to the original target, its paid history, and the competent amendment. A reduction after payment creates a reverse obligation for the difference. It does not rewrite the earlier payment or recreate consumed credit.

The corrected 130-cohort witness uses 128 acceptances per cohort. Its occurrence supports the entire interval [0, 20000), so capacity is the only failing predicate in each overflow request. One original right of 20,000 units yields 16,640 accepted units and 3,360 remaining units. At price 10, original earned amounts total 166,400 units of money.

Those quantities specify an unexecuted acceptance witness. They provide no physical custody, provider, or runtime evidence. The exact cohort and correction tests appear in section 26.

Sources: `P08`, `P09`, `P14`, `S05`.

## 16. Recourse: sovereign nodes and institutional trust

### 16.1 Three components

Recourse Service administers the complete dispute lifecycle. Recourse Trust Infrastructure verifies and preserves authority, evidence, custody, conflicts, and restrictions. Recourse Execution Protocol carries outcomes and instructions to independently governed destinations.

Each sovereign node owns its database, identity, institutions, rules, keys, and peer configuration. A node can operate independently. The common protocol connects discovery, referral, disclosure, adjudication, recognition, execution, and recovery.

Anguilla, UAE, USA, and Botswana are candidate initial node configurations. This identifies planning scope. It establishes no operating institution, government approval, signed mandate, or live deployment.

### 16.2 Node configuration

The node manifest binds network, node, operator, jurisdiction, institutions, rule profiles, trusted signers, supported modules, peers, storage, and recovery policy. The database pins one sovereign identity. A request cannot install a new trust root.

Node jurisdiction, institution, arbitration seat, governing law, party jurisdiction, Mass zone, and Moxie chain remain separate fields. Discovery exposes supported profiles and capabilities without revealing private cases.

Peer configuration pins a peer identity, keys, permitted purposes, source rules, and fixed endpoint policy. Authentication of a peer does not imply recognition of its outcomes. The receiver makes a separate recognition decision.

### 16.3 Principals and permissions

Distinct roles include party, representative, software agent, administrator, institution, tribunal member, reviewer, executor, beneficiary, and reconciler. Each role requires the relevant appointment, delegation, or mandate.

Access grants bind tenant, actor, case or claim scope, operations, validity, and revocation. Case reads require the complete permitted read scope. A submit-only action returns a minimal receipt instead of a full case snapshot.

An administrator can manage permitted records. That credential cannot create a human award or override an independent conflict decision. Several keys controlled by one principal do not satisfy a multiparty quorum.

### 16.4 Signature contract

The current builder's signature scheme uses Ed25519 over a purpose-separated statement and canonical JSON. Its statement binds network, node, tenant, institution profile, case, purpose, exact payload digest, and validity.

The target retains this exact-byte discipline and permits explicit future suite profiles. Signers approve the displayed action and complete prior-state commitment. The service holds no principal signing key by default.

Every protocol action signs its expected revision and prior protocol-state digest. Outcome signatures also bind the selected evidence records in their declared order. The verifier rejects changes to that signed state or evidence context. A valid prefix still needs independent completeness and currentness evidence.

### 16.5 Artifact custody

Artifact custody preserves exact bytes, algorithm, digest, media type, size, uploader, source, and receipt time. SHA-256 and BLAKE3 remain distinct. Protocol references require verified prior custody where their checks depend on the bytes.

Custody does not prove authenticity, admissibility, or the truth of a document. Those findings identify their competent verifier and supporting evidence. A corrected submission appends a new record without modifying the original artifact.

Sources: `P15`, `S01`, `S03`, `S04`.

## 17. Recourse: complete case and procedure lifecycle

### 17.1 Filing and consent

A case contains parties, representation, agreement, institution, seat, law, heads of claim, related native objects, and evidence references. Each head identifies its requested relief, affected subjects, amount or quantity, and dependencies.

Filing records the submitter's assertions. Consent separately binds the complete filing, parties, claims, agreement, rules, seat, law, and institution. It also identifies principals permitted to administer, review, execute, and reconcile.

Each head records its parties and jurisdictional basis. A separate inquiry mandate can authorize examination of disputed consent or capacity. That mandate grants no merits authority.

Jurisdiction findings identify the competent decision maker and exact scope. They preserve contested points and available review. Identity, filing acceptance, and matching with counsel cannot substitute for jurisdiction or consent.

### 17.2 Service, notice, and deadlines

Service records distinguish dispatch evidence, delivery observations, and a competent finding of sufficient service. The adopted rule profile determines which event starts each deadline. Receipt time and legally effective service time remain separate.

Notices bind the affected claims, proposed procedure or decision, recipients, content, and response period. Objections and challenge windows are effective gates. A worker cannot advance a deadline merely because a notification job completed.

Deadline corrections preserve the original calculation and the authority for the new result. Missing or contested service evidence produces a pending requirement or an adjudicative question.

### 17.3 Procedure selection

The procedure engine distinguishes bounded record resolution, expedited tribunal proceedings, and full tribunal proceedings. A routing assessment proposes a procedure from the claim and adopted rules. A competent act adopts it after required notice and objections.

Record queries answer bounded factual questions against identified records. An affected party can request upward routing without grounds or leave. The request preserves lower-tier records as evidence. Downward routing requires every affected party's written agreement. Contested record integrity requires the full tribunal route.

Different heads can require different procedures. The case retains their dependency graph, common evidence, and restrictions. A resolved head does not silently resolve every related head.

### 17.4 Appointment, disclosure, and conflicts

Appointment binds institution authority, selected person, role, claims, rule profile, and term. Acceptance is a separate signed act. Qualifications distinguish declared information from verified credentials.

Neutrals disclose conflicts and relevant relationships. Challenges identify their basis and affected decisions. An independent authorized reviewer decides the challenge under the adopted rules.

A dated conflict record preserves actual control, material relationships, source evidence, and affirmative coverage. Distinct identifiers do not prove independence. Missing relationship evidence creates an obstruction. The competent appointment or review process determines the remedy.

A representative cannot become the same matter's neutral through a directory role change. Institutional administration cannot waive a required independent decision. Replacement preserves prior proceedings and states which acts remain effective.

### 17.5 AI-assisted case work

AI systems can organize evidence, prepare submissions, identify discrepancies, and draft analyses within a delegated scope. Each work record retains actor, mandate, inputs, model or tool provenance, output, and subsequent human decision where required.

Automated analysis remains distinguishable from an institutional determination or human-signed award. The system retains cited evidence and material uncertainty. Retrieved documents cannot enlarge a software agent's authority.

### 17.6 Outcomes and restrictions

Determinations, awards, and settlements use different record types. An award requires the valid accepted tribunal and its required human signatures. A settlement requires the parties' applicable consent. An independently binding settlement uses its own contractual basis and need not depend on adopted arbitration procedure.

An outcome binds claims, relief, reasoning or reasons artifact, evidence, effective terms, challenge route, and obligations. It distinguishes ordered performance from value already recovered. Later corrections create signed successors and explicit adjustment duties.

Stays can impose, vary, or lift restrictions over specified claims, assets, acts, and periods. Each stay binds its predecessor and competent authority. Current effect eligibility evaluates all controlling restrictions and their precedence.

Disposition can close, dismiss, supersede, or complete proceedings. `DispositionKind::Completed` means that proceedings are complete under the adopted procedure. It does not require economic recovery or discharge unpaid obligations.

Every disposition preserves obligation identities, execution history, and unresolved recovery. Execution completion and recovered quantity remain separate derived facts. Their values require independently verified performance evidence.

### 17.7 Fees

Fee records bind schedules, quotes, payer, beneficiary, accepted terms, node attribution, protocol attribution, and applicable provider instructions. The adopted instrument determines each entitlement. The design supplies no default commercial rate.

A charge remains distinct from payment and provider receipt. Returned fees preserve original attribution and any refund obligation. Practitioner compensation and tribunal compensation remain separately authorized.

Sources: `P15`, `S01`, `S03`, `S04`.

## 18. Recourse: network exchange and recognition

### 18.1 Discovery and referral

Signed discovery exposes node, institution, practitioner, and destination capabilities with exact profile versions. Matching identifies eligible choices and explains the relevant criteria. It does not appoint a tribunal or confer representation.

A referral first discloses permitted metadata. It binds source, recipient, case reference, purpose, expiry, and exact content. Both parties authorize the disclosures required by the selected contract.

Receiving acceptance is a signed local decision. A transport receipt only proves receipt of a message under its declared semantics. Opening a receiving case creates a new local identifier and immutable source mapping.

The new case does not inherit source consent or jurisdiction automatically. Local adoption establishes its own authority and procedure. Source and receiving records remain independently auditable.

### 18.2 Withdrawal and message ordering

A withdrawal can arrive before its referral. The receiver authenticates it and stores a durable tombstone under the stable referral identity. A later referral cannot revive the withdrawn request.

Attempt records retain exact bytes, endpoint, time, response, and uncertainty. Restart preserves withdrawals, accepted decisions, and pending delivery. A timeout cannot erase a receiving decision whose acknowledgement was lost.

### 18.3 Portable outcomes

A portable outcome includes the exact source record, required procedural history, evidence, rule snapshots, signatures, and disclosure authority. The source institution seals the disclosed snapshot. The receiver verifies it against independently configured trust.

History verification replays signatures, derived signers, prior-state commitments, source context, and rule versions. It checks the completeness of required stays, challenges, appointments, and evidence. Unsupported historical rule migrations produce an explicit obstruction.

The proposed `SourceCutEvidence` binds case revision, case digest, protocol head, assertion time, validity, and completeness authority. The source produces the case and head atomically. Historical profile versions remain available for verification.

Recognition binds the exact disclosed snapshot, receiving policy, purposes, scope, and decision maker. It does not prove that the snapshot is the latest source state. It also does not itself authorize an economic effect.

### 18.4 Current-source and revocation checks

Execution admission obtains the freshness evidence required by the destination policy. A source can supply a signed current head, restriction status, or narrowly scoped authority lease. The policy states the interval and failure behavior.

A disconnected node cannot assert knowledge of unseen legal changes. It either uses an admitted bounded freshness contract or refuses the dependent action. Availability assumptions remain visible in the effect's evidence.

Sources: `P06`, `P07`, `P15`, `S03`, `S04`.

## 19. Recourse: client interfaces and lawyer application

### 19.1 One contract across clients

The HTTP API provides versioned requests, bounded bodies, explicit revisions, stable mutation identities, and durable result retrieval. Generated OpenAPI describes mounted operations. Runtime discovery removes operations that lack a configured required module.

The TypeScript SDK uses that exact schema and preserves native errors, identifiers, and amounts. It does not choose new economic identities after timeout. It exposes preparation separately from signed submission.

The Model Context Protocol server provides real bounded tools over the same API. It declares read and write effects. Credentials remain outside tool arguments and logs.

Mutations require explicit signed action content and idempotency keys. Client preparation does not sign or approve an action. A protocol replay returns a permitted original receipt without bypassing current disclosure restrictions.

### 19.2 Lawyer and client matching

Practitioner profiles contain jurisdiction, practice, language, qualifications, availability, fees, and conflicts disclosures. Verified qualifications identify their verifier and validity. Self-declared experience remains labeled.

A client creates a private matter and reviews suitable practitioners with explanations. Selection authorizes disclosure only to the selected recipient and content scope. Representation begins through explicit acceptance and authority records.

Representation, fee acceptance, conflicts review, case access, and tribunal appointment remain separate acts. A matching score creates none of those powers. Declining representation preserves the matter's privacy and retained consent history.

### 19.3 Case workspace

The workspace displays case heads, evidence, procedure, deadlines, appointments, outcomes, restrictions, execution, and recovery. It identifies the next required action and its permitted signer. Pending external performance remains visible.

Users can select independent signers or import externally signed actions. The interface displays the exact action and affected objects before signing. It prevents silent account or beneficiary substitution between preparation and submission.

Empty, restricted, unavailable, and failed states have actionable explanations. Demonstration data remains identified. A local preview does not establish a hosted service or operating sovereign venue.

Sources: `S03`, `S04`, `P15`.

## 20. Integrated contract: outcome to exact destination effect

### 20.1 Three execution paths

A voluntary native transfer uses the source account's authority over exact native transaction bytes. Recourse additionally verifies its outcome, executor, obligor, beneficiary, mandate, and account mapping. The native transfer proves only its specified native effect.

A certified event resolution uses the destination's event authority, quorum certificate, oracle conditions, and current policy. An arbitration award cannot substitute for the required native certificate. Event resolution does not itself establish an award payment.

A general award carrier is a proposed destination capability. The destination must recognize the adjudicating authority and grant the exact requested power. Recourse administration or a tribunal signature cannot supply a missing destination debit authority.

### 20.2 Proposed award-effect record

The logical contract below has no allocated native wire identifier:

```text
AwardEffect {
  schema, effect_id, effect_digest,
  case_id, head_ids, outcome_id, award_digest,
  obligation_id, satisfaction_group_id, relief_id,
  predecessor_or_supersession,
  destination_domain, chain_or_zone, genesis_or_store,
  destination_object, selected_contract_revision,
  capability_profile_digest, native_schema_revision,
  legal_policy, dispute_policy, finality_policy, recovery_policy,
  recognition_or_execution_mandate,
  tribunal_and_appointment_evidence,
  executor, obligor, beneficiary,
  identity_to_account_bindings,
  action_kind, asset, exact_quantity, unit,
  affected_property, prerequisites,
  current_authority_generation, restriction_checkpoint,
  validity_basis, effective_interval,
  exact_instruction_bytes, native_digest, signing_context,
  independently_expected_proof_coordinates,
  required_recovery_evidence
}
```

The effect digest commits to the complete economic meaning. Its identity remains stable across transport attempts, endpoint aliases, and adapter revisions. Changed meaning under the same identity is a conflict.

The beneficiary signs or supplies an admitted mandate for the exact destination binding. This prevents substitution of a collector's address or another asset. The destination verifies ownership, custody, encumbrances, and the requested power independently.

An ordinary native transaction may lack a stable award-effect field. In that case, recovery retains its exact bytes and nonce while performance remains unresolved. A replacement transaction requires explicit linkage and new admission against the remaining obligation.

### 20.3 Destination acceptance

The destination verifies the selected contract, exact instruction, authority, restrictions, resources, replay identity, and current generation. A proposed native carrier repeats these checks at application. Sender-side preflight cannot establish destination admission.

The acceptance transaction atomically records the stable effect identity, accepted intent, local effect, result, and receipt. It also creates any continuing duties or outbox instructions. A refusal changes none of the protected economic state.

For Mass, the proof must expose the signed claim preimage and bind outcome, obligation, action, destination, authority, and actual allocation. The destination exports each generated commit identifier and its verification context when the caller cannot reconstruct them.

For Moxie, the native batch commits the exact effect and its receipt. The finality proof then binds that receipt to the selected chain and committee context. A later proof can be pending without repeating an already committed effect.

### 20.4 Dispatch and uncertainty

The sender commits intent, reservations, event, replay record, and outbox before dispatch. The worker commits an attempt before network submission. It retains the exact instruction and selected destination profile.

Immediately before submission, the worker rechecks current authority, stays, expiry, and lease. Its local serialized barrier excludes competing local changes during bounded submission. It cannot exclude an unseen foreign legal change without an admitted freshness contract.

A timeout or lost response enters `OutcomeUnknown`. The sender reconciles that exact instruction. It does not create a fresh economic identity or release possible exposure.

A stay after dispatch cannot recall an ordinary already-sent transaction. The system preserves uncertainty and later performance evidence. Cancellation requires proof of no dispatch or effective prevention of the effect. A signed `delivered=false` statement alone records absence at its stated observation cut. It supplies no permanent closure.

Replacement after uncertainty requires an authoritative complete source cut with no remaining original-command exposure. An effective fence rejects delayed and replayed original instructions. One protected transition binds closure to the sole admitted successor command.

The closure receipt retains original identity, exact request, source cut, consumed capacity, fence evidence, successor binding, and resulting obligation state. Reopening remains `ReopenPending` until the original ledger and required current admissions commit.

### 20.5 Native finality verification

Verification retains exact native binary bytes, transaction hash, signing digest, nonce, epoch, and signature suite. Money preserves the native asset, raw integer, and scale. A human decimal representation is a separate projection.

The verifier uses independently expected chain, genesis, block, state root, receipt root, transaction position, phase, and effect coordinates. It pins the applicable committee and trust profile. The response cannot choose its own trusted committee.

Receipt inclusion and a consensus decision prove only their defined native statement. Advisory legal envelopes require separate reliance verification. A proof without an independently bound chain domain cannot establish that association by itself.

The verifier also compares the selected SDK or adapter revision exactly. A nonempty revision string does not establish equality with the selected revision. Unsupported proof formats or missing signed fields leave finality unverified.

### 20.6 Recovery and shared satisfaction

A satisfaction group joins all claims and collectors that can satisfy the same liability. It tracks current authorized quantity, confirmed recovery, recognized noncash satisfaction, and unresolved reserved exposure. All participants use one authoritative attribution model.

New exposure cannot exceed the remaining quantity after those deductions. Timeout releases none. Partial performance moves only its authenticated portion from reserved exposure to recovered value.

Every recovery record identifies the original occurrence, provider, posting, asset, unit, quantity slice, and reconciliation authority. Duplicate or contradictory evidence remains recorded. It cannot receive a second economic credit.

An award reduction after recovery creates an explicit refund or adjustment duty. It does not rewrite the recovered history. Legal completion and financial recovery remain independently reported.

Sources: `P05`, `P08`–`P10`, `P14`, `P15`, `S03`–`S05`.

## 21. Integrated contract: complete custody transfer

### 21.1 Transfer scope

A transfer of live work preserves more than a case balance or output value. It includes every relevant namespace, pending computation, economic journal, reservation, undelivered message, authority requirement, and evidence route.

The namespace registry identifies each authority that issues case, command, obligation, payment, and contribution-right identities. Each authority certifies its scope and complete retained prefix. An empty local list is not completeness evidence.

### 21.2 Proposed custody-cut record

```text
CustodyCut {
  transfer_id, source_owner, successor_owner,
  source_generation, successor_generation,
  namespace_registry_revision, namespace_inventory,
  authenticated_complete_prefixes,
  live_machine_records, checked_continuations,
  canonical_economic_journals,
  funded_resources, owners, restrictions,
  duty_reservations, cash_reservations,
  pending_deliveries, received_deduplication_records,
  future_action_authorities,
  evidence_custody, disclosure_duties, notice_routes,
  preparation_head, admitted_deltas, sealed_cut_digest,
  decoder_acceptance, custody_acceptance,
  effective_fence_evidence, external_freshness_anchor
}
```

Duty identity retains issuer namespace, constituting act, and occurrence index. A new administrator, family name, or template does not create a replacement original. Economic amendments require separately admitted acts.

Duty reservations prevent double satisfaction. Cash reservations secure possible spending. The successor receives both with their original identities, restrictions, and owners.

An evaluator can finish before its duty-creation message reaches the obligation ledger. The cut must retain that message and its original delivery identity. Complete local prefixes alone cannot prove that no such message exists.

### 21.3 Transfer protocol

1. Prepare the namespace inventory, source heads, transfer authority, and proposed successor.
2. Fence new predecessor initiation at the declared generation.
3. Continue observation and reconciliation of previously sent instructions.
4. Transfer the complete cut and verify the receiving decoder and custody commitments.
5. Collect every admitted delta since preparation.
6. Compare current source revisions with the sealed cut and included deltas.
7. Commit one durable ownership transition that activates the successor and preserves predecessor fences.
8. Require the new generation and action-specific authority for every subsequent initiation.

The ownership transition compares the source generation, sealed cut, admitted delta frontier, and effective fences with the successor's accepted transfer record. That comparison and successor activation share one protected commit boundary.

Every reconciliation admitted before that boundary belongs to the accepted cut. Later observations route to the successor under their original identities. A changed revision requires an updated cut and renewed successor acceptance before activation.

An acknowledgement loss leaves the transfer uncertain. It does not permit the predecessor to resume automatically. Recovery queries the authoritative ownership decision.

Independently governed domains need an agreement and protocol that make the fences effective. A local database generation cannot stop an old message at an independent provider. Previously sent commands retain their original exposure until resolved.

A provider fence requires durable installation at the provider and serialization with its acceptance boundary. Delayed requests must encounter that same fence. An unsupported provider fence leaves the corresponding exclusivity claim unavailable.

### 21.4 Transfer invariants

Transfer changes the execution custodian and generation. It does not itself change economic rights, funded resources, reservations, pending messages, or performed effects. Transfer replay returns the prior result without executing a continuation or dispatching an instruction.

Two cloned stores can contain authentic state. Preventing both from acting requires an effective exclusive ownership boundary. Detecting coherent rollback requires a freshness anchor outside the rollback domain.

Unsupported decoding or an incomplete namespace produces an explicit obstruction. An identified custodian retains the work until a valid receiving route exists. The protocol cannot declare wind-down complete by omitting difficult records.

### 21.5 Worked continuity case

A duty is 125 units. The ledger records credit of 40 units. The original command can still deliver 85 units and retains an 85-unit reservation.

The successor receives the outstanding right, command, and both reservation types. It cannot send another 85-unit instruction. A late credit of 60 leaves 25 units outstanding and potentially exposed.

Only authoritative closure of the original command can release its unresolved exposure. A fresh admitted instruction may then address the residual 25. Closing the old command does not discharge that unpaid amount.

Sources: `P05`, `P08`, `P09`, `P15`, `S05`.

## 22. Integrated journeys

### 22.1 Formation, finance, dispute, and recovery

An organization forms or onboards through Mass with exact constituting evidence. It adopts ownership and governance records. A financing program creates a governed instrument and its continuing duties.

Mass issues claim evidence under the required consent and current rules. Moxie admits the instrument, entitlement, custody, and funding. Trading changes positions while preserving the original terms and settlement obligations.

An external payment remains incomplete. The original command, possible exposure, and reservation remain active. A party files a Recourse case that references the exact instrument, obligation, and occurrence evidence.

Recourse verifies consent, procedure, service, appointment, and outcome authority. Its award identifies the remaining duty. The award-effect contract then binds the exact destination instruction and beneficiary.

The destination admits its own effect and emits verifiable evidence. Recourse attributes actual performance to the shared satisfaction group. Partial recovery leaves the residual and any unresolved command exposure visible.

### 22.2 Physical delivery, correction, and returned payment

A physical claim identifies one original right, custody arrangement, and quantity allowance. An admitted occurrence supports a bounded acceptance. The physical producer creates the corresponding earned duty.

A payment of 6 against a duty of 10 precedes a return of 2. The return retains its original attribution. An authorized reopening and fresh payment of 6 complete the original due under the selected contract.

A successor later earns and independently pays another due of 10. A correction reduces the old target to 3. It creates a reverse due of 7, funded with fresh credit.

The resulting economic net is 13. Original accepted physical quantity and consumed cash remain consumed. The trace distinguishes correction, return, reopening, and replacement funding.

### 22.3 Cross-node dispute recognition

A source node proposes a referral with permitted metadata. Both parties authorize the exact disclosure. The receiver accepts and opens a separate local case under its own authority.

The source completes its procedure and seals a portable outcome. The receiver verifies the disclosed history and applies its recognition policy. It requests current-source evidence before admitting any dependent execution.

A withdrawal received before a delayed referral remains effective after restart. A controlling stay prevents eligible new execution. Already dispatched work remains subject to observation and recovery.

### 22.4 Institutional exit during live execution

An institution begins wind-down while programs, external commands, and cases remain open. It inventories every authoritative namespace and prepares the full custody cut. It identifies a successor with the required custody and action authorities.

The predecessor fences new initiation while observing old commands. The successor verifies continuations, resources, and preparation deltas. One ownership transition activates the new generation.

An old provider response arrives after transfer. The successor recognizes its original delivery and occurrence identity. It updates the original duty without a duplicate instruction or regenerated reservation.

Sources: `P01`, `P03`, `P05`–`P10`, `P14`, `P15`, `S03`–`S05`. These journeys specify proposed acceptance scenarios. They report no deployments.

## 23. Security, privacy, and operational control

### 23.1 Threat model

The design considers malicious callers, compromised keys, conflicting institutional statements, faulty validators, unavailable providers, stale replicas, and hostile evidence. It also considers process crashes, lost replies, reordered messages, concurrent writers, cloned stores, and coherent rollback.

Each assurance claim names the faults it tolerates and the external premises it needs. Cryptographic authenticity does not establish substantive legal truth. A local test cannot verify provider honesty or institutional competence.

### 23.2 Trust and secrets

Store signing keys under the operator's selected custody controls. Separate service authentication, institutional decisions, validator consensus, provider access, and recovery powers. Administrative access must not collapse those roles.

Rotate keys through authenticated versioned records. Retain historical verification material and compromise findings. Emergency access remains scoped, auditable, and subject to the required governing approvals.

Keep credentials out of API bodies, model prompts, logs, and exported evidence. Artifact access checks apply before content retrieval and before disclosure. Backups and support exports receive the same classification rules as primary storage.

### 23.3 Resource and denial-of-service controls

Bound bodies, collection sizes, nesting, execution work, proof verification, pagination, and network concurrency. Use exact errors for unsupported work and exhausted capacity. Limits must not silently truncate evidence used for a decision.

Separate compute budgets from economic authority. A compute limit cannot erase an accepted duty. Reserve operational capacity for reconciliation, cancellation, mandatory notices, and evidence preservation.

Admission failures consume no economic resource unless an explicit fee contract permits a separately recorded charge. Repeated invalid requests cannot advance continuation ordinals or exhaust another party's funding reservation.

### 23.4 Observability

Operational records join command, program, actor, authority, source revisions, effect, receipt, and external attempt. They distinguish measured events from inferred diagnoses. Redaction preserves identifiers needed for safe reconciliation without exposing unnecessary content.

Metrics include oldest unresolved exposure, outbox age, projection lag, stale authority inputs, unverified finality, custody gaps, and residual obligations. A green process-health endpoint does not establish complete business readiness.

Alerts identify an owner, affected state, evidence, and permitted next action. Incident recovery preserves original journals and committed receipts. It does not repair uncertainty by deleting inconvenient records.

### 23.5 Backup and restore

Backups bind application, schema, configuration, trust profiles, artifact inventory, journals, and their consistent snapshot coordinates. Restoration first disables new writers. It verifies the full retained state before admitting execution.

Reconstruct pending inbox, outbox, reservations, continuation heads, emergency state, and ownership fences. Reconcile uncertain external instructions before new related effects. Restore tests include actual process interruption and independently read durable state.

Backup integrity does not prove freshness. The operator identifies the independent anchor used to reject coherent rollback where required. A restored node cannot assume current authority from an old valid signature alone.

Sources: `P03`, `P05`, `P06`, `P09`, `P10`, `P15`, `S02`–`S05`.

## 24. Versioning, deployment, and adoption

### 24.1 Compatibility registry

Each component publishes supported schemas, encodings, interpreter profiles, signature suites, proof formats, and historical verification ranges. A relying system authenticates discovery evidence. Selection binds the exact compatible set before signing.

Unknown critical semantics fail closed. Adapters preserve native bytes and expose unsupported fields. They do not silently downgrade authority, precision, or proof strength.

Keep product release labels separate from API versions, native discriminants, storage schemas, and proof profiles. A new product release does not require renaming compatible routes. A changed signed meaning requires an explicit version decision.

### 24.2 Migration

A migration manifest binds the source state, destination schema, exact transformation, retained historical verifiers, authority, and activation boundary. It states how every obligation, reservation, receipt, continuation, and pending delivery survives.

A checkpoint import verifies source completeness and exclusive writer transfer. New empty partitions do not authorize importing existing liabilities without their history. Missing funding or authority history blocks the affected migration.

A fresh genesis creates a separate deployment boundary. It cannot erase existing obligations by relabeling their store as new. Existing deployments require their own exit, transfer, or continued operation procedure.

### 24.3 Adoption stages

Discovery establishes the institution, mandate, target journeys, and provider dependencies. Sandbox operation exercises the exact selected contracts with synthetic records. Parallel operation compares evidence without confusing duplicate records with duplicate legal acts.

Limited activation identifies the objects, institutions, users, providers, and authority actually admitted. Expanded activation adds scope only after its acceptance evidence. Performance, capacity, and availability claims use measured workloads and declared conditions.

The operator assigns key custody, content adoption, incident command, recovery approval, and exit duties. Each deployment retains a current capability record and unsupported-operation list. A template configuration supplies no live institution or provider mandate.

Sources: `S02`–`S05`, `P06`, `P07`, `P10`, `P15`.

## 25. Current implementation boundaries

This section distinguishes inspected records from the proposed target. Its evidence date is 6 September 2026. A source observation establishes behavior only within the inspected component and captured implementation.

### 25.1 Mass source and specification

The Mass Technical Specification supplies the product architecture and attributed implementation findings. `S02` identifies the chapters captured on 6 September 2026. Other chapter states require separate review.

The captured specification identifies gaps between domain services and the target common admission path. These include effects before final admission, event publication after domain commit, and plans without durable continuation custody. The target requires explicit correspondence at each affected caller.

An isolated Mass implementation candidate contains `CreateTarget` admission and a completion journal. Its service rejects financial events without their own source contract. This candidate differs from the separately inspected Mass implementation.

The inspected service binds journal, audit, proof, and commit in one transaction. It checks current program and account admission before replay. It supplies no historical retrieval after those execution conditions expire. These observations establish neither provider settlement nor checked continuation recovery.

The current host proposal specifies versioned command, effect, continuation, and commit records. It binds the canonical completion claim into the signed transition. That proposal does not install a general recognized-award carrier, native debit authority, permanent command closure, or reopening admission.

The pure Op module models a closed external command from its gross paid amount and evidence reference. It does not authenticate that evidence. This type supplies neither a complete execution cut nor a permanent provider fence. The current Mass service rejects that observation.

The principal candidate supplies a concrete detached grant and PostgreSQL allocation transaction. It remains a proposed implementation contract. The candidate does not establish deployment, current provider authority, or durable-effect validity beyond its declared logical-time boundary.

Existing signing formats and interpreter profiles remain authoritative for their own historical bytes. The proposed continuation and grant records require explicit version selection and adapter evidence. Their names in this brief confer no accepted wire allocation.

### 25.2 Moxie source and research

Moxie contains a claim graph and compiler lowering interface. The target therefore extends an existing structure. Complete correspondence from source terms to recipients, financial types, occurrence dependencies, and admitted effects still needs bound evidence.

The inspected payoff reduction averages available historical entries. The target scheduled reduction first fixes complete membership. Missing members retain a pending dependency. The source observation concerns that evaluator path, rather than every possible caller contract.

The selected research corpus contains 15 source/PDF pairs and 839 rendered pages. The selection dated 6 September 2026 binds their exact hashes. Availability and rendering establish neither whole-paper mathematical acceptance nor production correspondence.

The dated emergency-control audit found no direct conflict in the `P09`, `P10`, and `P15` texts it inspected. It also found no exact numbered Phase-2/Phase-3 wire contract. Runtime acceptance must bind the independently selected pause, resume, continuity, and restart interfaces.

Implementation candidates require separate identities. A later candidate label or date does not establish that it contains every feature of an earlier inspected implementation. The release record must identify the actual integrated source and binary.

### 25.3 Recourse implementation

The Recourse owner retains the full product objective: a usable dispute-resolution protocol with sovereign nodes, complete procedure, network exchange, execution, clients, and operations. Its specification is an acceptance contract with unfinished obligations.

The integrated core uses Rust, Axum, and SQLite. Its writer transaction precedes authorization, replay, and revision checks. Accepted core mutations retain the case state, event, and response together. The dated implementation manifest binds the source state covered by these local observations.

The current protocol defines `Completed` as completion of proceedings. Every disposition preserves obligation identifiers. Actual delivery and recovery remain independent facts. No economic-recovery gate should change that meaning.

The inspected procedure uses bilateral case-wide consent and a case-wide adopted tier. The target adds claim-specific parties, inquiry authority, and independent routing. It also separates competent substantive decisions from case administration.

The committed implementation includes signed proceedings, matching, document custody, node exchange, execution, reconciliation, the SDK, MCP server, and lawyer workspace. The dated evidence records 94 service tests and a separate transport-crash test. It also records 11 native-verifier tests and one API-to-native-child test.

Client evidence records 16 SDK/MCP tests and one actual-service journey. Workspace evidence records 36 unit tests and seven HTTP journeys against the rebuilt service. Formatting, lint, schema, peer-source, type, and build checks passed within their stated local scope. Browser interaction and visual layout remain unverified.

The transport-crash test kills the API after the destination receives complete request bytes and before any HTTP response. Restart preserves uncertainty and sends no duplicate request. Independently signed synthetic delivery and authorized reconciliation then support recovery. Exact replay survives another restart.

The native-child test exposed an input-pipe deadlock. The repair explicitly closes the extracted input pipe and retains the child's trust-byte hash check. The initial failure and passing repair evidence remain preserved. Synthetic native finality verification establishes no authentic economic transfer.

Restoration tests admit independently proved positive delivery against a retained intent from a pre-attempt database snapshot. They create no missing attempt. Negative statements remain uncertain. Recovery when the restored snapshot lacks the intent still requires a complete contract and predecessor controls.

Historical intake and 89-test observations remain separate from the current results. General native award effects, permanent original-command closure, current destination authority, hosted operation, and sovereign operational acceptance remain open. Local implementation records do not close those obligations.

### 25.4 Native execution evidence

The native verification record identifies the exact Moxie implementation tested on 6 September 2026. Its evidence records a clean production build, independently reconstructed genesis, signature verification, and durable acceptance of a signed synthetic submission.

Two bounded 90-second runs produced no committed transfer receipt. The diagnostic retained height zero and unchanged balances. The inspected proposal-replay path returns before local admission when configuration disables peer-to-peer networking.

These results establish the observed admission boundary and failure to reach the requested effect in those runs. They establish no transfer finality, durable economic proof replay, or compulsory award enforcement. All nodes in that lane stopped gracefully.

The Moxie owner must select a supported isolated runtime contract or supply repair evidence. The Recourse owner retains its existing source ownership. Neither this brief nor the diagnostic authorizes another writer or network activation.

A debtor-signed transfer demonstrates voluntary compliance when it actually commits. Generic human-award admission needs a separate native contract. The existing oracle-governed event-resolution route cannot supply that authority by relabeling an award.

Sources: `S02`–`S07` and the exact corpus map in section 27.

## 26. Decisions and acceptance obligations

### 26.1 Accountable decisions

Each row identifies one accountable role. Contributor review does not transfer that role's write or release authority. The proposed next-action date is 6 September 2026. This proposal records no new owner acceptance of these assignments or dates.

| Decision | Accountable owner | Required outcome and evidence |
|---|---|---|
| Shared semantic contract | Architecture owner | Reconcile the brief, paper interfaces, and implementation candidates in one decision record |
| Native and persistence versions | Principal protocol decision owner | Select exact tags, schemas, activation method, and historical verification behavior |
| Mass admission transaction | Mass implementation owner | Demonstrate actual allocation, protected reads, authority coverage, final sample, receipt, and commit |
| Moxie isolated runtime | Existing Moxie coordinator | Name the supported runtime contract and provide committed-effect and restart evidence |
| Native award effect | Moxie integration owner | Define admission, exact economic effect, trust, finality proof, and duplicate prevention |
| Recourse integration | Recourse integration owner | Preserve the verified local revision. Close native award, uncertain-command recovery, and hosted operational evidence |
| Risk and waterfall policy | Governing risk authority | Select economic ordering, calibration, release conditions, caps, and loss attribution |
| Provider and institutional routes | Relevant deployment operator | Bind actual mandates, accepted evidence, fencing, cancellation, and recovery duties |
| Custody transfer | Current custody owner | Demonstrate a complete cut and effective predecessor exclusion at every claimed boundary |

### 26.2 Common execution evidence

Each executed witness retains the selected source, dependency versions, binary digest, configuration, trust profiles, and exact initial state. It preserves signed input bytes, commands, logs, durable readback, and resulting proof bytes.

Record expected and observed state separately. A test name or green build cannot replace comparison with the required economic and authority invariants. A synthetic signature proves only the fixture's declared trust relation.

Independent implementations must agree on canonical bytes before signature or proof interoperability claims. Golden vectors include negative encodings, changed audiences, altered evidence context, duplicate keys, and unsupported critical semantics. Expected values come from an independently reviewed construction.

Fault witnesses interrupt the process at the actual storage and dispatch boundaries. A mocked return value alone cannot prove restart behavior. Keep failed runs and the exact reason that a later run differs.

### 26.3 Required semantic witnesses

These rows specify proposed acceptance requirements. Unless an accompanying receipt states otherwise, none is execution evidence.

| Witness | Required result |
|---|---|
| Exact retry after lost response | Original result and proof return. No new economic effect or external instruction |
| Changed request under completed identity | Refusal preserves protected economic state and the original result |
| One-shot intent with another command identifier | Intent admission prevents a second authorized effect |
| Concurrent absent-read insertion | Shared predicate generation detects the new restriction before admission |
| Authority rotation during allocation | One protected snapshot supplies every required role, scope, and current key |
| Two keys from one principal | An independence threshold counts that principal once |
| Final logical-time expiry | Allocation and proof roll back when the final sample falls outside the admitted interval |
| Durable-effect or provider deadline | The selected enforcement mechanism proves that separate boundary. Sample-time evidence alone fails |
| Late-discovered lock requirement | Release the complete transaction and restart with the expanded deterministic lock set |
| Wrong creditor with valid digests | Source-to-effect verification refuses the substituted recipient |
| Missing scheduled observation | Preserve complete membership and return Pending. Do not average only available entries |
| Unresolved continuation recovery | Restore checked control state against the current ledger, including intervening payments |
| Program substitution on resume | Refuse a different program unless an independently admitted transformation proves correspondence |
| Same cash occurrence through two aliases | Aggregate attribution remains within one occurrence's supported quantity |
| Payment return and restoration | Preserve allocation ownership and consumed cash. Reopen only through the governing disposition |
| New certificate over reserved depth | Ordinary and liquidation routes share the same physical capacity |
| Batch work exhaustion | Return Deferred with retained escrow. Claim no infeasibility without its certificate |
| Degraded risk sequence | Requirements 100, 120, and 140 retain the running committed maximum |
| Legacy risk initialization | Current healthy evaluation does not release collateral with unresolved historical requirements |
| Two pools sharing sponsor cash | Aggregate reservations prevent each pool from spending the same sponsor balance |
| Closed position with funding debt | Retain the unsettled generation and include it in account equity |
| Completed dispute with unpaid debt | Proceedings complete while the original duty, stay, and recovery history remain visible |
| Independent claim procedures | Escalation changes the affected head while preserving unrelated admitted procedures |
| Award evidence-context substitution | Original signed outcome rejects changed evidence descriptions under unchanged artifact bytes |
| Omitted later stay in portable history | Current-source completeness prevents execution from a valid but incomplete prefix |
| Partial destination performance | Attribute actual receipt once and retain every unresolved command remainder |
| Referral withdrawal before delivery | A durable withdrawal tombstone defeats delayed referral replay after restart |
| Emergency pause and resume | Resume binds the exact pause and authority state. Restart retains their controlling order |
| Custody transfer with late response | Successor reconciles the original command. Neither writer creates replacement exposure |
| Incomplete namespace or empty manifest | Explicit completeness checks reject omitted required state, including supposedly empty partitions |
| Coherent backup rollback | An independent freshness premise detects the older authentic state where the profile claims that protection |

The design corpus captured on 6 September 2026 contains ten packages and 90 fixture-family files. Each package retains its contract appendix or domain records, source index, and exact manifest. Its inputs and expected results remain synthetic and unexecuted.

The design record identifies each package and its fixture families. Package namespaces distinguish fixture identities. Artifact validation checks syntax, references, and retained hashes. It does not execute the proposed acceptance requirements.

### 26.4 Quantitative physical and cash witness

Start with one original right of 20,000 physical quanta and one occurrence supporting [0, 20000). Fix the price at 10 monetary quanta per physical quantum. Create 130 separately admitted cohorts with 128 successful acceptances each.

Each cohort uses a fresh lot and retains the original issuance. After its 128th acceptance, submit an otherwise valid overflow request. Refuse that request without consuming its physical interval or creating a duty.

For the first 129 cohorts, admit the successor against the exact current predecessor. Its first acceptance can use the prior refused interval. The final refused interval [16640, 16641) remains unused.

Required totals are 16,640 accepted quanta, 16,640 original dues, 166,400 earned monetary quanta, and 3,360 remaining physical quanta. There are 130 capacity refusals. Exact replay after restart changes none of these totals.

A separate correction witness pays 6, returns 2, admits reopening, and pays 6 with fresh credit against an original due of 10. Another delivery earns and receives 10. Correcting the first target to 3 creates a separately funded reverse due of 7.

The seller's net receipt is 13. Permanent credit attribution totals 29 across four fresh occurrences: 6, 6, 10, and 7. The return of 2 remains a separate debit. Both physical portions remain consumed.

### 26.5 Adoption record

The architecture owner records each requirement as proposed, selected, implemented, verified locally, verified across systems, or admitted for a named deployment. Each advancement links its evidence and competent decision. Status never advances from elapsed time alone.

A local proof or test retains its exact assumptions. Missing provider truth, legal authority, current-source completeness, exclusive custody, or cross-system correspondence remains an identified obligation. The complete product objective persists while these obligations remain open.

## 27. Source register

### 27.1 Evidence classes

**Confirmed** means the stated inspection or retained execution record supports the bounded claim. **Inferred** means the conclusion follows from identified source behavior but lacks a matching executed witness. **Proposed** identifies the target contract.

**Assumed** identifies a premise supplied for design or a synthetic witness. **Unknown** identifies missing evidence. An owner handoff can confirm ownership or a stated design decision without proving running behavior.

### 27.2 Implementation and design records

| Key | Source and evidence boundary |
|---|---|
| `S01` | Maintained product register and product/deal doctrine. Product identity and responsibilities |
| `S02` | Mass Technical Specification chapters and native-effects design captured on 6 September 2026. Design and attributed implementation findings |
| `S03` | Recourse specification, interfaces, implementation manifest, and local test records captured on 6 September 2026. Scope and bounded local execution evidence |
| `S04` | Native verification procedure and results captured on 6 September 2026. Bounded build, admission, and no-finality observations described in section 25.4 |
| `S05` | Protocol candidate and supporting design records captured on 6 September 2026. Proposed versions, PostgreSQL grant, physical cohorts, and risk decisions |
| `S06` | Mass and Moxie implementation inspections recorded on 6 September 2026. Function-level observations with the scope stated in section 25 |
| `S07` | `P09` continuation regression results recorded on 6 September 2026. Finite normal and optimized test evidence using unchanged dependencies |

The evidence descriptions above identify the captured records and their scope. Each observation retains its evidence date and class. Section 25 states the implementation behavior and limits that these records support.

The captured Mass specification and native-effects design have distinct evidence records. The observed native-effects chapter agrees with its supporting evidence. Each observation applies to its captured bytes.

Independent reproduction requires the selected implementation, dependencies, configuration, inputs, and execution record. The descriptions here do not establish production acceptance.

### 27.3 Research corpus

The research selection dated 6 September 2026 contains the 15 manuscripts below and 839 PDF pages. The selected source and PDF pairs define this reading set.

Paper claims retain their own assumptions, proof scope, and open research requirements. Selection and rendered page counts establish neither whole-paper mathematical acceptance nor production correspondence.

| Key | Selected manuscript |
|---|---|
| `P01` | One Entity in Many Jurisdictions |
| `P02` | How Compliance Composes |
| `P03` | Programmable Institutions |
| `P04` | Lex: A Logic for Jurisdictional Rules |
| `P05` | Op: Compliance-Carrying Operations |
| `P06` | The Sovereign Jurisdiction Network |
| `P07` | Accession Networks |
| `P08` | The Claim as Primitive |
| `P09` | Admissible Obligation Transitions |
| `P10` | Event-Collect BFT |
| `P11` | One-Way Coupling of Prediction Markets to Automated Market Makers |
| `P12` | Central Counterparty Risk in Automated Markets |
| `P13` | Parlay Identification of Ising Couplings |
| `P14` | Allocated Title |
| `P15` | Recourse |
